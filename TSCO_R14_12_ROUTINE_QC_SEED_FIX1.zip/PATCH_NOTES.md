# R14.12 isolated UAT QC seed — FIX1

Purpose: isolated `tsco-r14-12-isolated-check` only.

This overlay keeps the original R14.12 UAT QC seeder and corrects two Equipment Master method mappings that otherwise cause the normal QC domain validation to reject the current Routine Test contexts:

- EQ-23 / EQ-64: `IEC 60567 / ASTM D3612`
- EQ-69 / EQ-70: `IEC 60814 / ASTM D1533`

The platform's own laboratory guides already recognize both method families for DGA and Water. The patch changes only the controlled structural method mapping in `app/seed.py`; existing equipment operational status, calibration/verification dates, sample data, results, QC runs and other master data remain untouched by that reconciliation logic.

Before applying the QC seed, run the existing application `seed()` once so the isolated Neon Equipment Master is reconciled, then run the normal UAT QC seeder. Do not deploy this overlay to main UAT/production.
