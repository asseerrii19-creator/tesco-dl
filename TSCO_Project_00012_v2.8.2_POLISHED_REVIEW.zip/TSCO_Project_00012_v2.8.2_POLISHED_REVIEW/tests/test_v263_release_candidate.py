from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
import json

import pytest

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import (
    Asset, AuditLog, Client, ControlledDocument, CustodyEvent, Role, SamplingAssignment, SampleRequest, Site,
    TechnicalAssessmentRecord, TestPackageConfig as PackageConfig, User, UserClientAssignment,
)
from app.services.identifiers import next_request_identifiers, next_sampling_order_identifiers
from app.security import hash_password
from app.services.lab_operations import blank_operations_db, package_catalog, sync_sample_to_operations, validate_operations_update, _station_from_name
from app.storage import BARCODE_DIR
from app.routes.field import _validate_image_bytes


def login(client: TestClient, email: str, password: str = "Demo123!") -> None:
    response = client.post("/login", data={"email": email, "password": password}, follow_redirects=False)
    assert response.status_code == 303


def assign_all_workstations(client: TestClient, sample_key: str) -> None:
    client.post("/logout")
    login(client, "senior@tsco.local")
    loaded = client.get("/api/lab-operations/data").json()
    payload = loaded["db"]
    batch = next(b for b in payload["batches"] if sample_key in b.get("samples", []))
    stations = sorted({_station_from_name((t.get("test") if isinstance(t, dict) else str(t))) for t in batch.get("tests", [])})
    for i, station in enumerate(stations):
        payload["testAssignments"].append({
            "id": f"TEST-ASSIGN-{batch['id']}-{i}", "batch_id": batch["id"],
            "workstation": station, "mode": "ALL",
        })
    saved = client.put("/api/lab-operations/data", json={"db": payload, "clientRevision": loaded["revision"]})
    assert saved.status_code == 200, saved.text
    client.post("/logout")
    login(client, "chemist@tsco.local")


def test_admin_user_site_package_crud_and_assignment_replacement_is_stable():
    with TestClient(app) as client:
        login(client, "admin@tsco.local")
        with SessionLocal() as db:
            dmm = db.scalar(select(Site).where(Site.code == "DMM"))
            sec = db.scalar(select(Client).where(Client.code == "SEC"))
            arm = db.scalar(select(Client).where(Client.code == "ARM"))
            assert dmm and sec and arm
            dmm_id, sec_id, arm_id = dmm.id, sec.id, arm.id

        created = client.post(
            "/admin/users",
            data={
                "email": "qa.v263@tsco.local",
                "full_name": "QA v2.6.3 User",
                "role": Role.LAB_TECHNICIAN.value,
                "password": "TempPass123!",
                "site_id": str(dmm_id),
                "assigned_client_ids": [str(sec_id), str(arm_id)],
            },
            follow_redirects=False,
        )
        assert created.status_code == 303
        with SessionLocal() as db:
            user = db.scalar(select(User).where(User.email == "qa.v263@tsco.local"))
            assert user is not None
            user_id = user.id
            assert {row.client_id for row in user.client_assignments} == {sec_id, arm_id}

        # Replacing the same unique assignment set twice used to be vulnerable to flush ordering.
        for _ in range(2):
            response = client.post(
                f"/admin/users/{user_id}/assignments",
                data={"assigned_client_ids": [str(sec_id), str(arm_id)]},
                follow_redirects=False,
            )
            assert response.status_code == 303
        with SessionLocal() as db:
            rows = db.scalars(select(UserClientAssignment).where(UserClientAssignment.user_id == user_id)).all()
            assert len(rows) == 2
            assert {row.client_id for row in rows} == {sec_id, arm_id}

        updated = client.post(
            f"/admin/users/{user_id}/profile",
            data={
                "full_name": "QA v2.6.3 User Updated",
                "role": Role.QUALITY.value,
                "job_title": "QA Reviewer",
                "site_id": str(dmm_id),
            },
            follow_redirects=False,
        )
        assert updated.status_code == 303
        toggled = client.post(f"/admin/users/{user_id}/toggle", follow_redirects=False)
        assert toggled.status_code == 303
        with SessionLocal() as db:
            user = db.get(User, user_id)
            assert user.full_name == "QA v2.6.3 User Updated"
            assert user.role == Role.QUALITY.value
            assert user.active is False

        site_create = client.post(
            "/admin/sites",
            data={"code": "Q63", "name": "QA Site", "laboratory_name": "QA Laboratory"},
            follow_redirects=False,
        )
        assert site_create.status_code == 303
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "Q63"))
            assert site is not None
            site_id = site.id
        assert client.post(
            f"/admin/sites/{site_id}/update",
            data={"name": "QA Site Updated", "laboratory_name": "QA Laboratory Updated"},
            follow_redirects=False,
        ).status_code == 303
        assert client.post(f"/admin/sites/{site_id}/toggle", follow_redirects=False).status_code == 303
        with SessionLocal() as db:
            site = db.get(Site, site_id)
            assert site.name == "QA Site Updated" and site.active is False

        pkg_create = client.post(
            "/admin/test-packages",
            data={"code": "QA-V263", "name": "QA Package v263", "scope": "GENERAL", "tests": "Water Content | IEC 60814 | Water | mg/kg"},
            follow_redirects=False,
        )
        assert pkg_create.status_code == 303
        with SessionLocal() as db:
            pkg = db.scalar(select(PackageConfig).where(PackageConfig.code == "QA-V263"))
            assert pkg is not None
            pkg_id = pkg.id
            assert any(row["id"] == "QA-V263" for row in package_catalog(db, dmm_id))
        assert client.post(
            f"/admin/test-packages/{pkg_id}/update",
            data={"name": "QA Package v263 Updated", "scope": "DGA", "tests": "DGA | ASTM D3612 | DGA | ppm"},
            follow_redirects=False,
        ).status_code == 303
        assert client.post(f"/admin/test-packages/{pkg_id}/toggle", follow_redirects=False).status_code == 303
        with SessionLocal() as db:
            pkg = db.get(PackageConfig, pkg_id)
            assert pkg.name == "QA Package v263 Updated" and pkg.active is False
            assert all(row["id"] != "QA-V263" for row in package_catalog(db, dmm_id))


def test_controlled_document_revision_lifecycle_and_file_validation():
    with TestClient(app) as client:
        login(client, "admin@tsco.local")
        good_pdf = b"%PDF-1.4\n1 0 obj << /Type /Catalog >> endobj\n%%EOF\n"

        first = client.post(
            "/admin/documents",
            data={"document_type": "METHOD", "code": "QA-METHOD-263", "title": "QA Method", "revision": "00"},
            files={"document_file": ("qa-method.pdf", good_pdf, "application/pdf")},
            follow_redirects=False,
        )
        assert first.status_code == 303
        duplicate = client.post(
            "/admin/documents",
            data={"document_type": "METHOD", "code": "QA-METHOD-263", "title": "QA Method Duplicate", "revision": "00"},
            files={"document_file": ("qa-method.pdf", good_pdf, "application/pdf")},
            follow_redirects=True,
        )
        assert duplicate.status_code == 200
        assert "already exists" in duplicate.text

        second = client.post(
            "/admin/documents",
            data={"document_type": "METHOD", "code": "QA-METHOD-263", "title": "QA Method", "revision": "01"},
            files={"document_file": ("qa-method-r1.pdf", good_pdf, "application/pdf")},
            follow_redirects=False,
        )
        assert second.status_code == 303
        with SessionLocal() as db:
            docs = db.scalars(select(ControlledDocument).where(ControlledDocument.code == "QA-METHOD-263").order_by(ControlledDocument.revision)).all()
            assert [(d.revision, d.status) for d in docs] == [("00", "SUPERSEDED"), ("01", "ACTIVE")]
            old_id, new_id = docs[0].id, docs[1].id

        reactivate = client.post(f"/admin/documents/{old_id}/status", data={"status": "ACTIVE"}, follow_redirects=False)
        assert reactivate.status_code == 303
        with SessionLocal() as db:
            old = db.get(ControlledDocument, old_id)
            new = db.get(ControlledDocument, new_id)
            assert old.status == "ACTIVE" and new.status == "SUPERSEDED"

        spoof = client.post(
            "/admin/documents",
            data={"document_type": "SOP", "code": "QA-SPOOF-263", "title": "Spoof", "revision": "00"},
            files={"document_file": ("spoof.pdf", b"<html>not a pdf</html>", "application/pdf")},
            follow_redirects=True,
        )
        assert spoof.status_code == 200
        assert "does not match" in spoof.text
        with SessionLocal() as db:
            assert db.scalar(select(ControlledDocument).where(ControlledDocument.code == "QA-SPOOF-263")) is None


def _allocate_sample_identifier() -> str:
    with SessionLocal() as db:
        site = db.scalar(select(Site).where(Site.code == "DMM"))
        value, _, _ = next_request_identifiers(db, site)
        db.commit()
        return value


def _allocate_order_identifier() -> str:
    with SessionLocal() as db:
        site = db.scalar(select(Site).where(Site.code == "DMM"))
        value, _ = next_sampling_order_identifiers(db, site)
        db.commit()
        return value


def test_identifier_sequences_are_atomic_and_gap_free_for_concurrent_allocations():
    with TestClient(app):
        with ThreadPoolExecutor(max_workers=8) as pool:
            requests = list(pool.map(lambda _: _allocate_sample_identifier(), range(16)))
        request_numbers = sorted(int(value.rsplit("-", 1)[1]) for value in requests)
        assert len(set(request_numbers)) == 16
        assert request_numbers == list(range(request_numbers[0], request_numbers[0] + 16))

        with ThreadPoolExecutor(max_workers=8) as pool:
            orders = list(pool.map(lambda _: _allocate_order_identifier(), range(12)))
        order_numbers = sorted(int(value.rsplit("-", 1)[1]) for value in orders)
        assert len(set(order_numbers)) == 12
        assert order_numbers == list(range(order_numbers[0], order_numbers[0] + 12))


def test_server_backup_reset_restore_roundtrip_and_permissions():
    with TestClient(app) as client:
        login(client, "admin@tsco.local")
        backup_response = client.get("/api/lab-operations/backup")
        assert backup_response.status_code == 200
        backup = backup_response.json()
        assert backup["format"] == "TSCO-LAB-OPERATIONS-SERVER-BACKUP"
        original = backup["db"]
        revision = int(backup["revision"])

        reset = client.put(
            "/api/lab-operations/data",
            json={"operation": "reset-operational", "confirmation": "DELETE SITE DATA", "clientRevision": revision},
        )
        assert reset.status_code == 200
        reset_data = reset.json()
        assert reset_data["db"]["batches"] == []
        assert reset_data["db"]["results"] == []

        restored = client.put(
            "/api/lab-operations/data",
            json={"operation": "restore-backup", "backup": backup, "clientRevision": reset_data["revision"]},
        )
        assert restored.status_code == 200
        restored_db = restored.json()["db"]
        for key in ("batches", "results", "qc", "reports", "retained", "retests", "batchHistory"):
            assert restored_db[key] == original[key]
        with SessionLocal() as db:
            assert db.scalar(select(AuditLog).where(AuditLog.action == "LAB_OPERATIONS_BACKUP_RESTORED")) is not None

        client.post("/logout")
        login(client, "senior@tsco.local")
        assert client.get("/api/lab-operations/backup").status_code == 403
        current = client.get("/api/lab-operations/data").json()
        denied = client.put(
            "/api/lab-operations/data",
            json={"operation": "restore-backup", "backup": backup, "clientRevision": current["revision"]},
        )
        assert denied.status_code == 403


def test_direct_url_role_boundaries_and_management_navigation_are_server_enforced():
    with TestClient(app) as client:
        login(client, "client@sec.local")
        for path in ("/admin", "/field/new", "/lab/operations", "/api/lab-operations/data"):
            assert client.get(path).status_code == 403

        client.post("/logout")
        login(client, "chemist@tsco.local")
        assert client.get("/admin").status_code == 403
        assert client.get("/field/new").status_code == 403
        assert client.get("/lab/operations?section=workstations").status_code == 200

        client.post("/logout")
        login(client, "manager@tsco.local")
        # Management is a read-only management workspace and has no Laboratory Operations shell.
        assert client.get("/lab/operations?section=knowledge").status_code == 403
        assert client.get("/lab/operations/app?embed=1&section=knowledge").status_code == 403


def test_read_only_roles_cannot_cross_workflow_action_boundaries():
    with TestClient(app) as client:
        with SessionLocal() as db:
            sec = db.scalar(select(Client).where(Client.code == "SEC"))
            assert sec is not None
            sec_id = sec.id

        login(client, "quality@tsco.local")
        assert client.post("/lab/999999/status", data={"action": "START_TESTING"}).status_code == 403
        assert client.post("/assessment/999999", data={"decision": "APPROVED", "recommendation": "x"}).status_code == 403
        # Quality governs QC/validation but does not inherit Senior technical-assessment authority.
        assert client.get("/assessment").status_code == 403

        # Data Review and Physical Receiving are distinct accountability roles in the same journey.
        client.post("/logout")
        login(client, "intake@tsco.local")
        assert client.get("/intake").status_code == 200
        assert client.get("/receiving").status_code == 403
        assert client.post("/receiving/999999/receive", data={}).status_code == 403

        client.post("/logout")
        login(client, "receiving@tsco.local")
        assert client.get("/receiving").status_code == 200
        assert client.get("/intake").status_code == 403
        assert client.post("/intake/999999/decision", data={"action": "ACCEPT"}).status_code == 403

        client.post("/logout")
        login(client, "technical@tsco.local")
        # Technical Manager retains read/oversight access but cannot create Sampling Operations transactions.
        assert client.get("/operations").status_code == 200
        assert client.post("/operations/orders", data={"client_id": str(sec_id)}).status_code == 403
        assert client.post("/sampling-supervision/assignment/999999/assign", data={"sampler_id": "1"}).status_code == 403
        page = client.get("/operations")
        assert "Create Order" not in page.text


def test_visible_sidebar_links_are_crawlable_for_every_demo_role():
    import html as html_lib
    import re

    accounts = [
        "fieldman@tsco.local", "supervisor@tsco.local", "operations@tsco.local",
        "clientsampler@sec.local", "clientops@sec.local", "intake@tsco.local",
        "receiving@tsco.local", "chemist@tsco.local", "quality@tsco.local",
        "manager@tsco.local", "senior@tsco.local", "technical@tsco.local",
        "client@sec.local", "admin@tsco.local",
    ]
    href_re = re.compile(r'<a class="side-link[^\"]*" href="([^\"]+)"')
    with TestClient(app) as client:
        for email in accounts:
            client.post("/logout")
            login(client, email)
            home = client.get("/")
            assert home.status_code in {200, 303}, (email, home.status_code)
            if home.status_code == 303:
                home = client.get(home.headers["location"])
            links = {html_lib.unescape(x) for x in href_re.findall(home.text)}
            assert links, f"No sidebar links rendered for {email}"
            for href in sorted(links):
                response = client.get(href, follow_redirects=False)
                assert response.status_code < 500, (email, href, response.status_code)
                assert response.status_code != 403, (email, href, "visible link forbidden")


def test_cross_site_state_changes_are_rejected_before_route_processing():
    with TestClient(app) as client:
        response = client.post(
            "/login",
            data={"email": "admin@tsco.local", "password": "Demo123!"},
            headers={"Origin": "https://untrusted.example", "Sec-Fetch-Site": "cross-site"},
            follow_redirects=False,
        )
        assert response.status_code == 403
        assert "Cross-site" in response.json()["error"]


def test_sync_payload_size_limits_and_invalid_json_are_server_enforced():
    with TestClient(app) as client:
        login(client, "admin@tsco.local")
        too_large = client.put(
            "/api/lab-operations/data",
            content=b"{}",
            headers={"Content-Type": "application/json", "Content-Length": "5000001"},
        )
        assert too_large.status_code == 413

        invalid = client.put(
            "/api/lab-operations/data",
            content=b"{not-json",
            headers={"Content-Type": "application/json"},
        )
        assert invalid.status_code == 400
        assert "Invalid JSON" in invalid.json()["error"]

        client.post("/logout")
        login(client, "fieldman@tsco.local")
        field_large = client.post(
            "/field/offline-sync",
            content=b"{}",
            headers={"Content-Type": "application/json", "Content-Length": "38000001"},
        )
        assert field_large.status_code == 413

        malformed_numeric = client.post(
            "/field/offline-sync",
            json={
                "offline_barcode": "TSCO-OFFLINE-26399",
                "fields": {"client_id": "not-an-id", "container_count": "also-bad"},
                "photos": [],
            },
        )
        assert malformed_numeric.status_code == 400
        assert malformed_numeric.headers["content-type"].startswith("application/json")
        assert "Invalid numeric field" in malformed_numeric.json()["error"]

        malformed_photos = client.post(
            "/field/offline-sync",
            json={
                "offline_barcode": "TSCO-OFFLINE-26400",
                "fields": {"client_id": "1", "container_count": "1"},
                "photos": {"unexpected": "object"},
            },
        )
        # The endpoint always produces a structured JSON validation response instead of a generic HTML 400.
        assert malformed_photos.status_code in {400, 403}
        assert malformed_photos.headers["content-type"].startswith("application/json")


def test_superseded_document_direct_download_is_hidden_from_normal_lab_users():
    with TestClient(app) as client:
        login(client, "admin@tsco.local")
        good_pdf = b"%PDF-1.4\n1 0 obj << /Type /Catalog >> endobj\n%%EOF\n"
        for revision in ("00", "01"):
            response = client.post(
                "/admin/documents",
                data={"document_type": "METHOD", "code": "QA-DIRECT-263", "title": "Direct URL QA", "revision": revision},
                files={"document_file": (f"qa-direct-{revision}.pdf", good_pdf, "application/pdf")},
                follow_redirects=False,
            )
            assert response.status_code == 303
        with SessionLocal() as db:
            docs = db.scalars(select(ControlledDocument).where(ControlledDocument.code == "QA-DIRECT-263").order_by(ControlledDocument.revision)).all()
            assert docs[0].status == "SUPERSEDED" and docs[1].status == "ACTIVE"
            old_id, active_id = docs[0].id, docs[1].id

        # Admin may inspect revision history; ordinary laboratory roles see only ACTIVE controlled revisions.
        assert client.get(f"/documents/{old_id}/download").status_code == 200
        client.post("/logout")
        login(client, "chemist@tsco.local")
        assert client.get(f"/documents/{old_id}/download").status_code == 404
        active_download = client.get(f"/documents/{active_id}/download")
        assert active_download.status_code == 200
        assert active_download.headers.get("cache-control") == "private, no-store"


def test_legacy_bundled_method_urls_redirect_to_central_document_library():
    with TestClient(app) as client:
        login(client, "chemist@tsco.local")
        response = client.get("/lab-ops/documents/Method_Water_IEC60814.pdf", follow_redirects=False)
        assert response.status_code == 303
        assert response.headers["location"] == "/documents"


def test_health_endpoint_reports_current_build_version():
    with TestClient(app) as client:
        health = client.get("/api/v1/health")
        assert health.status_code == 200
        assert health.json()["version"] == "2.8.2"


def test_rendered_laboratory_boot_script_is_inserted_after_main_console_script():
    with TestClient(app) as client:
        login(client, "admin@tsco.local")
        page = client.get("/lab/operations/app?embed=1&section=general")
        assert page.status_code == 200
        html = page.text
        print_template_index = html.find("w.document.write(`")
        assert print_template_index > 0
        main_script_close = html.find("</script>", print_template_index)
        boot_index = html.rfind("const embedded=!!window.TSCO_PLATFORM_EMBED")
        assert main_script_close > print_template_index
        assert boot_index > main_script_close



def test_management_role_is_read_only_for_operations_state_api():
    with TestClient(app) as client:
        login(client, "manager@tsco.local")
        # Management uses the curated management workspace, not the raw laboratory state API.
        assert client.get("/api/lab-operations/data").status_code == 403
        assert client.put("/api/lab-operations/data", json={"clientRevision": 0, "db": {}}).status_code == 403


def test_missing_sample_label_artifact_is_regenerated_on_authorized_request():
    from datetime import datetime

    with TestClient(app) as client:
        with SessionLocal() as db:
            sec = db.scalar(select(Client).where(Client.code == "SEC"))
            asset = db.scalar(select(Asset).where(Asset.client_id == sec.id))
            sampler = db.scalar(select(User).where(User.email == "fieldman@tsco.local"))
            dmm = db.scalar(select(Site).where(Site.code == "DMM"))
            sample = SampleRequest(
                request_number="QA-LABEL-263",
                public_token="QA-LABEL-263-TOKEN",
                barcode_value="QA-LABEL-263-BAR",
                status="SUBMITTED",
                site_id=dmm.id,
                client_id=sec.id,
                asset_id=asset.id,
                sampler_id=sampler.id,
                sample_date_time=datetime.now(),
                sampling_point="Main Tank Bottom",
                requested_package="Routine Test",
            )
            db.add(sample)
            db.commit()
            sample_id = sample.id
        label_path = BARCODE_DIR / "QA-LABEL-263-BAR_label.pdf"
        label_path.unlink(missing_ok=True)
        login(client, "fieldman@tsco.local")
        response = client.get(f"/field/sample/{sample_id}/label")
        assert response.status_code == 200
        assert response.headers["content-type"].startswith("application/pdf")
        assert label_path.exists()


def test_private_tracking_is_scoped_for_html_and_api_direct_urls():
    from datetime import datetime

    with TestClient(app) as client:
        with SessionLocal() as db:
            sec = db.scalar(select(Client).where(Client.code == "SEC"))
            asset = db.scalar(select(Asset).where(Asset.client_id == sec.id))
            sampler = db.scalar(select(User).where(User.email == "fieldman@tsco.local"))
            dmm = db.scalar(select(Site).where(Site.code == "DMM"))
            sample = SampleRequest(
                request_number="QA-TRACK-263",
                public_token="QA-TRACK-263-TOKEN",
                barcode_value="QA-TRACK-263-BAR",
                status="SUBMITTED",
                site_id=dmm.id,
                client_id=sec.id,
                asset_id=asset.id,
                sampler_id=sampler.id,
                sample_date_time=datetime.now(),
                sampling_point="Main Tank Bottom",
                requested_package="Routine Test",
            )
            db.add(sample)
            db.commit()

        # Private tracking requires authentication when public tracking is disabled.
        html_anon = client.get("/track/QA-TRACK-263-TOKEN", follow_redirects=False)
        assert html_anon.status_code == 303
        assert html_anon.headers["location"].startswith("/login")
        assert client.get("/api/v1/tracking/QA-TRACK-263-TOKEN").status_code == 401

        # A different client must not be able to enumerate the token directly.
        login(client, "client@aramco.local")
        assert client.get("/track/QA-TRACK-263-TOKEN").status_code == 404
        assert client.get("/api/v1/tracking/QA-TRACK-263-TOKEN").status_code == 404

        client.post("/logout")
        login(client, "client@sec.local")
        assert client.get("/track/QA-TRACK-263-TOKEN").status_code == 200
        api = client.get("/api/v1/tracking/QA-TRACK-263-TOKEN")
        assert api.status_code == 200
        assert api.json()["request_number"] == "QA-TRACK-263"

        client.post("/logout")
        login(client, "fieldman@tsco.local")
        assert client.get("/api/v1/tracking/QA-TRACK-263-TOKEN").status_code == 200



def _create_platform_lab_sample(marker: str, *, status: str = "TESTING") -> tuple[int, str]:
    """Create a centrally linked lab sample for role/integrity regression tests."""
    with SessionLocal() as db:
        sec = db.scalar(select(Client).where(Client.code == "SEC"))
        asset = db.scalar(select(Asset).where(Asset.client_id == sec.id))
        sampler = db.scalar(select(User).where(User.email == "fieldman@tsco.local"))
        actor = db.scalar(select(User).where(User.email == "admin@tsco.local"))
        dmm = db.scalar(select(Site).where(Site.code == "DMM"))
        sample = SampleRequest(
            request_number=f"QA-{marker}-REQ",
            public_token=f"QA-{marker}-TOKEN",
            barcode_value=f"QA-{marker}-BAR",
            status=status,
            site_id=dmm.id,
            client_id=sec.id,
            asset_id=asset.id,
            sampler_id=sampler.id,
            sample_date_time=datetime.now(),
            sampling_point="Main Tank Bottom",
            requested_package="Routine Test",
            lms_number=f"QA-{marker}-LMS",
        )
        db.add(sample)
        db.flush()
        sync_sample_to_operations(db, sample, actor=actor, phase=status)
        db.commit()
        return sample.id, sample.lms_number


def test_technical_manager_ui_and_direct_posts_are_read_only_for_lab_and_assessment():
    with TestClient(app) as client:
        sample_id, _ = _create_platform_lab_sample("TM-READONLY", status="TECHNICAL_REVIEW")
        login(client, "technical@tsco.local")
        lab = client.get("/lab")
        assert lab.status_code == 200
        assert f'action="/lab/{sample_id}/status"' not in lab.text
        assert client.post(f"/lab/{sample_id}/status", data={"action": "SUBMIT_REVIEW", "note": "forged"}).status_code == 403

        assessment = client.get(f"/assessment?sample_id={sample_id}")
        assert assessment.status_code == 200
        assert "Save Technical Decision" not in assessment.text
        assert f'action="/assessment/{sample_id}"' not in assessment.text
        assert client.post(
            f"/assessment/{sample_id}",
            data={"decision": "APPROVED", "recommendation": "forged"},
        ).status_code == 403


def test_results_and_qc_history_are_append_only_and_result_revisions_are_explicit():
    with TestClient(app) as client:
        _, sample_key = _create_platform_lab_sample("APPEND", status="TESTING")
        login(client, "chemist@tsco.local")
        assign_all_workstations(client, sample_key)
        loaded = client.get("/api/lab-operations/data").json()
        payload = loaded["db"]
        payload["results"].append({
            "id": "QA-APPEND-RESULT-1",
            "sample": sample_key,
            "test": "Water Content KF @RT",
            "result": "12",
            "unit": "mg/kg",
            "analyst": "FORGED ACTOR",
            "ts": "2000-01-01T00:00:00",
        })
        payload["qc"].append({
            "id": "QA-APPEND-QC-1",
            "test": "Water Content KF @RT",
            "result": "10",
            "status": "PASS",
            "analyst": "FORGED ACTOR",
            "ts": "2000-01-01T00:00:00",
        })
        saved = client.put("/api/lab-operations/data", json={"db": payload, "clientRevision": loaded["revision"]})
        assert saved.status_code == 200, saved.text
        stored = saved.json()
        first_result = next(r for r in stored["db"]["results"] if r["id"] == "QA-APPEND-RESULT-1")
        first_qc = next(r for r in stored["db"]["qc"] if r["id"] == "QA-APPEND-QC-1")
        assert first_result["analyst"] == "Laboratory Chemist"
        assert first_result["recorded_by_user_id"]
        assert first_result["ts"] != "2000-01-01T00:00:00"
        assert first_qc["analyst"] == "Laboratory Chemist"
        assert first_qc["recorded_by_user_id"]

        # Editing or deleting historical rows is forbidden.
        tamper = json.loads(json.dumps(stored["db"]))
        next(r for r in tamper["results"] if r["id"] == "QA-APPEND-RESULT-1")["result"] = "999"
        denied = client.put("/api/lab-operations/data", json={"db": tamper, "clientRevision": stored["revision"]})
        assert denied.status_code == 403
        assert "cannot be changed or deleted" in denied.json()["error"]

        current = client.get("/api/lab-operations/data").json()
        tamper = json.loads(json.dumps(current["db"]))
        tamper["qc"] = [r for r in tamper["qc"] if r.get("id") != "QA-APPEND-QC-1"]
        denied = client.put("/api/lab-operations/data", json={"db": tamper, "clientRevision": current["revision"]})
        assert denied.status_code == 403

        # A second measurement of the same sample/test must be a linked revision.
        current = client.get("/api/lab-operations/data").json()
        repeated = json.loads(json.dumps(current["db"]))
        repeated["results"].append({
            "id": "QA-APPEND-RESULT-2",
            "sample": sample_key,
            "test": "Water Content KF @RT",
            "result": "13",
            "unit": "mg/kg",
        })
        denied = client.put("/api/lab-operations/data", json={"db": repeated, "clientRevision": current["revision"]})
        assert denied.status_code == 403
        assert "explicit revision" in denied.json()["error"]

        current = client.get("/api/lab-operations/data").json()
        revision = json.loads(json.dumps(current["db"]))
        revision["results"].append({
            "id": "QA-APPEND-RESULT-2",
            "sample": sample_key,
            "test": "Water Content KF @RT",
            "result": "13",
            "unit": "mg/kg",
            "revision_of": "QA-APPEND-RESULT-1",
            "analyst": "forged",
        })
        accepted = client.put("/api/lab-operations/data", json={"db": revision, "clientRevision": current["revision"]})
        assert accepted.status_code == 200, accepted.text
        row = next(r for r in accepted.json()["db"]["results"] if r["id"] == "QA-APPEND-RESULT-2")
        assert row["revision_of"] == "QA-APPEND-RESULT-1"
        assert row["analyst"] == "Laboratory Chemist"

        # Duplicate evidence identifiers are rejected even for newly appended records.
        current = client.get("/api/lab-operations/data").json()
        duplicate = json.loads(json.dumps(current["db"]))
        duplicate["results"].append(dict(next(r for r in duplicate["results"] if r["id"] == "QA-APPEND-RESULT-2")))
        denied = client.put("/api/lab-operations/data", json={"db": duplicate, "clientRevision": current["revision"]})
        assert denied.status_code == 403
        assert "Duplicate result record id" in denied.json()["error"]


def test_controlled_retest_request_and_completion_preserve_original_result():
    with TestClient(app) as client:
        _, sample_key = _create_platform_lab_sample("RETEST", status="TESTING")
        login(client, "chemist@tsco.local")
        assign_all_workstations(client, sample_key)
        loaded = client.get("/api/lab-operations/data").json()
        payload = loaded["db"]
        batch = next(b for b in payload["batches"] if sample_key in b.get("samples", []))
        payload["results"].append({
            "id": "QA-RETEST-ORIGINAL",
            "sample": sample_key,
            "batch": batch["id"],
            "test": "Water Content KF @RT",
            "result": "22",
            "unit": "mg/kg",
        })
        saved = client.put("/api/lab-operations/data", json={"db": payload, "clientRevision": loaded["revision"]})
        assert saved.status_code == 200, saved.text

        # Quality and Technical Manager are oversight roles here; they cannot mint a retest request.
        for email in ("quality@tsco.local", "technical@tsco.local"):
            client.post("/logout")
            login(client, email)
            current = client.get("/api/lab-operations/data").json()
            proposed = json.loads(json.dumps(current["db"]))
            proposed["retests"].append({
                "id": f"QA-RETEST-DENIED-{email.split('@')[0]}",
                "sample": sample_key,
                "batch": batch["id"],
                "test": "Water Content KF @RT",
                "reason": "verify",
                "status": "Requested",
            })
            denied = client.put("/api/lab-operations/data", json={"db": proposed, "clientRevision": current["revision"]})
            assert denied.status_code == 403

        client.post("/logout")
        login(client, "senior@tsco.local")
        current = client.get("/api/lab-operations/data").json()
        proposed = json.loads(json.dumps(current["db"]))
        proposed["retests"].append({
            "id": "QA-RETEST-REQUEST-1",
            "sample": sample_key,
            "batch": batch["id"],
            "test": "Water Content KF @RT",
            "reason": "Confirm atypical water result",
            "status": "Completed",  # server must force a new request back to Requested.
            "requested_by": "FORGED",
        })
        requested = client.put("/api/lab-operations/data", json={"db": proposed, "clientRevision": current["revision"]})
        assert requested.status_code == 200, requested.text
        request_row = next(r for r in requested.json()["db"]["retests"] if r["id"] == "QA-RETEST-REQUEST-1")
        assert request_row["status"] == "Requested"
        assert request_row["requested_by"] == "Senior Chemist"
        assert request_row["requested_at"]

        client.post("/logout")
        login(client, "chemist@tsco.local")
        current = client.get("/api/lab-operations/data").json()
        proposed = json.loads(json.dumps(current["db"]))
        retest = next(r for r in proposed["retests"] if r["id"] == "QA-RETEST-REQUEST-1")
        retest["status"] = "Completed"
        proposed["results"].append({
            "id": "QA-RETEST-RESULT-2",
            "sample": sample_key,
            "batch": batch["id"],
            "test": "Water Content KF @RT",
            "result": "20",
            "unit": "mg/kg",
            "isRetest": True,
            "retest_id": "QA-RETEST-REQUEST-1",
            "analyst": "FORGED",
        })
        completed = client.put("/api/lab-operations/data", json={"db": proposed, "clientRevision": current["revision"]})
        assert completed.status_code == 200, completed.text
        body = completed.json()["db"]
        rows = [r for r in body["results"] if r["id"] in {"QA-RETEST-ORIGINAL", "QA-RETEST-RESULT-2"}]
        assert len(rows) == 2
        assert next(r for r in rows if r["id"] == "QA-RETEST-ORIGINAL")["result"] == "22"
        retest_result = next(r for r in rows if r["id"] == "QA-RETEST-RESULT-2")
        assert retest_result["result"] == "20"
        assert retest_result["analyst"] == "Laboratory Chemist"
        final_request = next(r for r in body["retests"] if r["id"] == "QA-RETEST-REQUEST-1")
        assert final_request["status"] == "Completed"
        assert final_request["completed_by"] == "Laboratory Chemist"
        assert final_request["completed_at"]



def test_resample_decision_hands_off_to_operations_and_creates_new_field_sample():
    with TestClient(app) as client:
        original_id, _ = _create_platform_lab_sample("RESAMPLE", status="TECHNICAL_REVIEW")
        login(client, "senior@tsco.local")
        decision = client.post(
            f"/assessment/{original_id}",
            data={"decision": "RESAMPLE", "recommendation": "Collect a fresh bottle from the same sampling point."},
            follow_redirects=False,
        )
        assert decision.status_code == 303
        with SessionLocal() as db:
            record = db.scalar(select(TechnicalAssessmentRecord).where(TechnicalAssessmentRecord.sample_request_id == original_id))
            original = db.get(SampleRequest, original_id)
            assert record and record.decision == "RESAMPLE"
            assert original.status == "TECHNICAL_REVIEW"

        # Technical Manager can oversee the handoff but cannot create Sampling Operations transactions.
        client.post("/logout")
        login(client, "technical@tsco.local")
        oversight = client.get("/operations")
        assert oversight.status_code == 200
        assert "QA-RESAMPLE-REQ" in oversight.text
        assert f'action="/operations/resample/{original_id}"' not in oversight.text
        assert client.post(f"/operations/resample/{original_id}", follow_redirects=False).status_code == 403

        client.post("/logout")
        login(client, "operations@tsco.local")
        page = client.get("/operations")
        assert page.status_code == 200
        assert "Pending Resampling Requests" in page.text
        assert f'action="/operations/resample/{original_id}"' in page.text
        created = client.post(f"/operations/resample/{original_id}", follow_redirects=False)
        assert created.status_code == 303

        with SessionLocal() as db:
            assignment = db.scalar(select(SamplingAssignment).where(SamplingAssignment.resample_of_sample_id == original_id))
            assert assignment is not None
            assignment_id = assignment.id
            assignment_code = assignment.assignment_code
            assert assignment.status == "ASSIGNED"
            assert assignment.assigned_sampler.email == "fieldman@tsco.local"
            assert assignment.order.title == "Resample — QA-RESAMPLE-REQ"
            assert assignment.order.priority == "High"
            sec_id = assignment.order.client_id

        # Replaying the operations handoff is idempotent: it reuses the one linked assignment.
        replay = client.post(f"/operations/resample/{original_id}", follow_redirects=False)
        assert replay.status_code == 303
        with SessionLocal() as db:
            assert len(db.scalars(select(SamplingAssignment).where(SamplingAssignment.resample_of_sample_id == original_id)).all()) == 1

        client.post("/logout")
        login(client, "fieldman@tsco.local")
        field = client.get("/field")
        assert assignment_code in field.text
        replacement = client.post(
            "/field/new",
            data={
                "assignment_id": str(assignment_id), "client_id": str(sec_id), "quotation_id": "", "purchase_order_id": "",
                "existing_asset_id": "", "asset_code": "", "serial_number": "", "equipment_type": "Power Transformer",
                "manufacturer": "", "station_name": "", "asset_location_label": "", "voltage_kv": "", "rated_mva": "",
                "sample_date_time": datetime.now().strftime("%Y-%m-%dT%H:%M"), "sampling_point": "ignored by assignment",
                "requested_package": "ignored by assignment", "client_sample_reference": "QA-RESAMPLE-REPLACEMENT",
                "oil_temperature_c": "35", "ambient_temperature_c": "40", "ambient_humidity_pct": "30",
                "gps_latitude": "26.42", "gps_longitude": "50.08", "gps_accuracy_m": "5", "field_notes": "replacement bottle",
                "container_count": "1",
            },
            follow_redirects=False,
        )
        assert replacement.status_code == 303, replacement.text
        with SessionLocal() as db:
            assignment = db.get(SamplingAssignment, assignment_id)
            replacement_sample = db.get(SampleRequest, assignment.completed_sample_id)
            assert assignment.status == "COMPLETED"
            assert replacement_sample is not None
            assert replacement_sample.id != original_id
            assert replacement_sample.sampling_assignment_id == assignment_id
            assert replacement_sample.client_sample_reference == "QA-RESAMPLE-REPLACEMENT"
            original = db.get(SampleRequest, original_id)
            events = db.scalars(select(CustodyEvent).where(CustodyEvent.sample_request_id == original_id)).all()
            assert any(event.event_type == "TECHNICAL_RESAMPLE_COLLECTED" and replacement_sample.request_number in event.note for event in events)
            assert original.status == "TECHNICAL_REVIEW"



def test_non_dammam_lab_session_uses_assigned_site_end_to_end():
    with TestClient(app) as client:
        with SessionLocal() as db:
            jbl = db.scalar(select(Site).where(Site.code == "JBL"))
            assert jbl is not None
            jbl.active = True
            user = db.scalar(select(User).where(User.email == "jbl.chemist@tsco.local"))
            if not user:
                user = User(
                    email="jbl.chemist@tsco.local",
                    full_name="Jubail Laboratory Chemist",
                    password_hash=hash_password("JblTest123!"),
                    role=Role.LAB_TECHNICIAN.value,
                    site_id=jbl.id,
                    active=True,
                )
                db.add(user)
            else:
                user.site_id = jbl.id
                user.active = True
                user.password_hash = hash_password("JblTest123!")
            db.commit()

        login(client, "jbl.chemist@tsco.local", "JblTest123!")
        shell = client.get("/lab/operations?section=workstations")
        assert shell.status_code == 200
        assert "JBL Laboratory" in shell.text
        console = client.get("/lab/operations/app?embed=1&section=workstations")
        assert console.status_code == 200
        html = console.text
        assert 'window.TSCO_PLATFORM_SITE="JBL"' in html
        assert html.index("const CURRENT_SITE=") < html.index("const USER_SCOPE=")
        assert "DASH_SITE=CURRENT_SITE" in html
        assert "DB.settings.enabledSites=DB.settings.enabledSites||[CURRENT_SITE]" in html
        assert "DB.batches.forEach(b=>b.site=b.site||CURRENT_SITE)" in html
        assert "$('site').value=CURRENT_SITE" in html

        state = client.get("/api/lab-operations/data")
        assert state.status_code == 200
        payload = state.json()["db"]
        assert payload["settings"]["currentSite"] == "JBL"
        assert payload["settings"]["enabledSites"] == ["JBL"]
        assert payload["meta"]["site"] == "JBL"


def test_service_worker_and_field_offline_storage_do_not_share_authenticated_data():
    root = Path(__file__).resolve().parents[1]
    sw = (root / "app" / "static" / "service-worker.js").read_text(encoding="utf-8")
    field = (root / "app" / "static" / "field-form.js").read_text(encoding="utf-8")

    # Cache Storage is static-assets-only; authenticated routes must never become offline cache entries.
    assert "url.pathname.startsWith('/static/')" in sw
    static_decl = sw.split("const STATIC=", 1)[1].split(";", 1)[0]
    for protected_prefix in ("/field", "/lab", "/client", "/login", "/api"):
        assert f"\'{protected_prefix}" not in static_decl
        assert f'"{protected_prefix}' not in static_decl
    assert "Authenticated HTML/API responses are never written to Cache Storage" in sw

    # Offline drafts/IndexedDB are isolated per authenticated user + laboratory site.
    assert "dataset.userId" in field
    assert "dataset.siteCode" in field
    assert "tsco-field-draft-v3-${scope}" in field
    assert "tsco-field-offline-v3-${scope}" in field
    assert "document.body.dataset.siteCode" in field
    assert "`DMM-OFF-" not in field



def test_backup_restore_rejects_cross_site_and_malformed_payloads():
    with TestClient(app) as client:
        login(client, "admin@tsco.local")
        backup = client.get("/api/lab-operations/backup").json()
        current = client.get("/api/lab-operations/data").json()

        wrong_site = json.loads(json.dumps(backup))
        wrong_site["site"] = "JBL"
        denied = client.put(
            "/api/lab-operations/data",
            json={"operation": "restore-backup", "backup": wrong_site, "clientRevision": current["revision"]},
        )
        assert denied.status_code == 400
        assert "different laboratory site" in denied.json()["error"]

        malformed = json.loads(json.dumps(backup))
        malformed["db"]["qc"] = {"not": "a list"}
        denied = client.put(
            "/api/lab-operations/data",
            json={"operation": "restore-backup", "backup": malformed, "clientRevision": current["revision"]},
        )
        assert denied.status_code == 400
        assert "invalid list field" in denied.json()["error"]


def test_retest_and_report_duplicate_identity_guards():
    with SessionLocal() as db:
        site = db.scalar(select(Site).where(Site.code == "DMM"))
        senior = db.scalar(select(User).where(User.email == "senior@tsco.local"))
        technical = db.scalar(select(User).where(User.email == "technical@tsco.local"))
        assert site and senior and technical

        current = blank_operations_db(site)
        current["batches"] = [{
            "id": "B-1", "samples": ["S-1"], "tests": [{"test": "Water Content KF @RT", "station": "Water"}],
            "platform_sample_id": 1,
        }]
        current["results"] = [{"id": "R-1", "sample": "S-1", "test": "Water Content KF @RT", "result": "10"}]
        proposed = json.loads(json.dumps(current))
        proposed["retests"] = [
            {"id": "RT-DUP", "sample": "S-1", "batch": "B-1", "test": "Water Content KF @RT", "reason": "verify"},
            {"id": "RT-DUP", "sample": "S-1", "batch": "B-1", "test": "Water Content KF @RT", "reason": "verify again"},
        ]
        with pytest.raises(PermissionError, match="Duplicate retest record id"):
            validate_operations_update(current, proposed, senior, db=db, site_id=site.id)

        report_current = blank_operations_db(site)
        report_proposed = json.loads(json.dumps(report_current))
        report_proposed["reports"] = [
            {"sample": "S-1", "status": "Ready for LMS"},
            {"sample": "S-1", "status": "Ready for LMS"},
        ]
        with pytest.raises(PermissionError, match="one LMS-submission approval record"):
            validate_operations_update(report_current, report_proposed, technical, db=db, site_id=site.id)


def test_spoofed_office_zip_and_corrupt_image_evidence_are_rejected():
    with TestClient(app) as client:
        login(client, "admin@tsco.local")
        spoof = client.post(
            "/admin/documents",
            data={"document_type": "SOP", "code": "QA-SPOOF-DOCX-263", "title": "Spoof DOCX", "revision": "00"},
            files={"document_file": ("spoof.docx", b"PK\x03\x04not-an-office-container", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")},
            follow_redirects=True,
        )
        assert spoof.status_code == 200
        assert "does not match" in spoof.text
    with pytest.raises(ValueError, match="corrupt|supported"):
        _validate_image_bytes(b"\xff\xd8\xffthis-is-not-a-real-jpeg")


def test_docker_compose_persists_the_actual_tsco_data_directory():
    compose = (Path(__file__).resolve().parents[1] / "docker-compose.yml").read_text(encoding="utf-8")
    assert "TSCO_DATA_DIR: ${TSCO_DATA_DIR:-/var/data}" in compose
    assert "- tsco_data:/var/data" in compose
    assert "uploads:/app/app/data/uploads" not in compose
    assert "barcodes:/app/app/data/barcodes" not in compose
