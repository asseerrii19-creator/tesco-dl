from html import unescape
from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import Client, EquipmentAsset, Role, User
from app.responsibilities import senior_responsibility
from app.security import verify_password


def login(client, email, password="Demo123!"):
    r = client.post("/login", data={"email": email, "password": password}, follow_redirects=False)
    assert r.status_code == 303, r.text


def test_chemist_has_assigned_quality_tasks_not_full_qc_governance_or_asset_menu():
    with TestClient(app) as client:
        login(client, "chemist@tsco.local")
        page = client.get("/control/my-quality-tasks")
        assert page.status_code == 200
        assert "Routine QC checks" in page.text
        shell = client.get("/lab/operations?section=workstations")
        assert shell.status_code == 200
        assert "My QC / Validation Tasks" in shell.text
        assert "Transformer / Asset Structure" not in shell.text
        assert client.get("/lab/operations?section=quality").status_code == 403
        assert client.get("/assets/structure").status_code == 403


def test_senior_reports_and_read_only_asset_structure_are_authorized():
    with TestClient(app) as client:
        login(client, "senior@tsco.local")
        reports = client.get("/lab/operations?section=finalreport")
        assert reports.status_code == 200
        assets = client.get("/assets/structure")
        assert assets.status_code == 200
        assert "Read-only oversight" in assets.text
        assert "QC Oversight" not in reports.text


def test_all_authorized_clients_empty_query_does_not_raise_422_and_tree_has_demo_assets():
    with TestClient(app) as client:
        login(client, "operations@tsco.local")
        page = client.get("/assets/structure?client_id=")
        assert page.status_code == 200
        assert "All authorized clients" in page.text
        assert "SEC-DMM-TR-001" in page.text
        assert "ARM-ABQ-TR-001" in page.text
        assert "GPEL-DEMO-TR-001" in page.text


def test_continuous_improvement_is_single_quality_equipment_validation_audit_workspace():
    with TestClient(app) as client:
        login(client, "quality@tsco.local")
        page = client.get("/improvement")
        assert page.status_code == 200
        rendered = unescape(page.text)
        for label in ["Quality & QC", "Equipment & History", "Validation / Verification", "ILC / PT", "NCR / CAPA", "Competency", "Evidence", "Audit", "Troubleshooting Governance"]:
            assert label in rendered
        legacy = client.get("/control?tab=validation", follow_redirects=False)
        assert legacy.status_code == 303
        assert legacy.headers["location"] == "/improvement?tab=validation"


def test_fixed_senior_responsibility_slots_are_seeded_for_review():
    with SessionLocal() as db:
        mapping = {}
        for email in ["senior@tsco.local", "senior.maintenance@tsco.local", "senior.improvement@tsco.local"]:
            u = db.scalar(select(User).where(User.email == email))
            assert u is not None
            mapping[email] = senior_responsibility(u)
        assert mapping == {
            "senior@tsco.local": "TECHNICAL",
            "senior.maintenance@tsco.local": "EQUIPMENT",
            "senior.improvement@tsco.local": "IMPROVEMENT",
        }


def test_equipment_event_is_owned_by_equipment_senior_not_technical_senior():
    with SessionLocal() as db:
        eq = db.scalar(select(EquipmentAsset).order_by(EquipmentAsset.id))
        assert eq
        eid = eq.id
    with TestClient(app) as client:
        login(client, "senior@tsco.local")
        denied = client.post(f"/control/equipment/{eid}/event", data={"event_type":"MAINTENANCE","result":"PASS","details":"review test","next_due_at":""}, follow_redirects=False)
        assert denied.status_code == 403
        assert "Equipment & Maintenance Senior" in unescape(denied.text)
        client.post("/logout")
        login(client, "senior.maintenance@tsco.local")
        ok = client.post(f"/control/equipment/{eid}/event", data={"event_type":"MAINTENANCE","result":"PASS","details":"review test","next_due_at":""}, follow_redirects=False)
        assert ok.status_code == 303
        assert ok.headers["location"] == "/improvement?tab=equipment"


def test_browser_permission_error_is_branded_not_raw_json():
    with TestClient(app) as client:
        login(client, "client@sec.local")
        r = client.get("/lab/operations?section=finalreport")
        assert r.status_code == 403
        assert "Access changed" in r.text
        assert "TSCO · DIGITAL LABORATORY PLATFORM" in r.text
        assert '{"detail"' not in r.text
