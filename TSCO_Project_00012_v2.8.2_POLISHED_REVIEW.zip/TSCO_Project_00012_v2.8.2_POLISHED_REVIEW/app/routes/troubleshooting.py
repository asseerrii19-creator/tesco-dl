from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import EquipmentAsset, Role, Site, TroubleshootingRecord
from ..security import require_user

router = APIRouter(tags=["troubleshooting knowledge"])
ALLOWED = {
    Role.LAB_TECHNICIAN.value, Role.SENIOR_CHEMIST.value, Role.QUALITY.value,
    Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value,
}


def _site(db: Session, user) -> Site:
    site = db.get(Site, user.site_id) if user.site_id else None
    return site or db.scalar(select(Site).where(Site.code == "DMM"))


@router.get("/troubleshooting")
def knowledge(request: Request, q: str = "", db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    site = _site(db, user)
    published = db.scalars(
        select(TroubleshootingRecord)
        .where(TroubleshootingRecord.site_id == site.id, TroubleshootingRecord.status == "PUBLISHED")
        .order_by(TroubleshootingRecord.updated_at.desc())
    ).all()
    if q.strip():
        needle = q.strip().lower()
        published = [r for r in published if needle in " ".join([
            r.test_name or "", r.method_name or "", r.workstation or "", r.problem or "",
            r.symptoms or "", r.root_cause or "", r.actions_taken or "", r.lessons or "",
        ]).lower()]
    mine = db.scalars(
        select(TroubleshootingRecord)
        .where(TroubleshootingRecord.site_id == site.id, TroubleshootingRecord.created_by_id == user.id,
               TroubleshootingRecord.status != "PUBLISHED")
        .order_by(TroubleshootingRecord.updated_at.desc())
        .limit(50)
    ).all()
    equipment = db.scalars(
        select(EquipmentAsset).where(EquipmentAsset.site_id == site.id, EquipmentAsset.active.is_(True)).order_by(EquipmentAsset.equipment_id)
    ).all()
    return templates.TemplateResponse("troubleshooting_knowledge.html", {
        "request": request, "user": user, "site": site, "published": published, "mine": mine,
        "equipment": equipment, "q": q,
    })
