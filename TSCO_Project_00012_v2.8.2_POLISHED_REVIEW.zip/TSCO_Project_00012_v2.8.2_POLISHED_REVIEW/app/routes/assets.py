from __future__ import annotations

from collections import defaultdict
from fastapi import APIRouter, Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import Asset, Client, ClientUnit, Role, SampleRequest
from ..security import require_user
from ..services.scope import can_access_asset, can_access_client

router = APIRouter(prefix="/assets", tags=["asset structure"])
ALLOWED = {
    Role.CLIENT.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value,
    Role.FIELD_SAMPLER.value, Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value,
    Role.DATA_ENTRY.value, Role.SAMPLE_RECEIVING.value,
    Role.SENIOR_CHEMIST.value, Role.QUALITY.value, Role.TECHNICAL_MANAGER.value,
    Role.MANAGEMENT.value, Role.SYSTEM_ADMIN.value,
}


def _unit_path(unit: ClientUnit | None, by_id: dict[int, ClientUnit]) -> list[ClientUnit]:
    path: list[ClientUnit] = []
    seen: set[int] = set()
    while unit and unit.id not in seen:
        seen.add(unit.id)
        path.append(unit)
        unit = by_id.get(unit.parent_id) if unit.parent_id else None
    return list(reversed(path))


@router.get("/structure")
def structure(request: Request, client_id: str | None = None, asset_id: str | None = None, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    # Browser forms legitimately submit an empty value for "All authorized clients".
    # Parse it here instead of letting FastAPI reject client_id= with a raw 422 page.
    client_id_num = int(client_id) if client_id and str(client_id).isdigit() else None
    asset_id_num = int(asset_id) if asset_id and str(asset_id).isdigit() else None
    clients = [c for c in db.scalars(select(Client).where(Client.active.is_(True)).order_by(Client.name)).all() if can_access_client(db, user, c.id)]
    if client_id_num and client_id_num not in {c.id for c in clients}:
        client_id_num = None
    selected_client = next((c for c in clients if c.id == client_id_num), None) if client_id_num else (clients[0] if len(clients) == 1 else None)

    units_stmt = select(ClientUnit).where(ClientUnit.active.is_(True)).order_by(ClientUnit.client_id, ClientUnit.unit_type, ClientUnit.name)
    assets_stmt = select(Asset).where(Asset.active.is_(True)).order_by(Asset.client_id, Asset.asset_code)
    units = db.scalars(units_stmt).all()
    assets = [a for a in db.scalars(assets_stmt).all() if can_access_asset(db, user, a)]
    if selected_client:
        units = [u for u in units if u.client_id == selected_client.id]
        assets = [a for a in assets if a.client_id == selected_client.id]
    else:
        allowed_clients = {c.id for c in clients}
        units = [u for u in units if u.client_id in allowed_clients]

    by_id = {u.id: u for u in units}
    children: dict[int | None, list[ClientUnit]] = defaultdict(list)
    for unit in units:
        children[unit.parent_id].append(unit)
    assets_by_unit: dict[int | None, list[Asset]] = defaultdict(list)
    for asset in assets:
        assets_by_unit[asset.client_unit_id].append(asset)

    selected_asset = next((a for a in assets if a.id == asset_id_num), None) if asset_id_num else None
    sample_history = []
    if selected_asset:
        sample_history = db.scalars(
            select(SampleRequest).where(SampleRequest.asset_id == selected_asset.id).order_by(SampleRequest.sample_date_time.desc()).limit(30)
        ).all()

    asset_paths = [
        {
            "asset": a,
            "path": _unit_path(by_id.get(a.client_unit_id), by_id),
        }
        for a in assets
    ]

    client_groups = []
    for client in clients:
        group_units = [u for u in units if u.client_id == client.id]
        group_ids = {u.id for u in group_units}
        group_assets = [a for a in assets if a.client_id == client.id]
        group_roots = [u for u in group_units if not u.parent_id or u.parent_id not in group_ids]
        client_groups.append({"client": client, "root_units": group_roots, "assets": group_assets})
    return templates.TemplateResponse(
        "asset_structure.html",
        {
            "request": request, "user": user, "clients": clients, "selected_client": selected_client,
            "units": units, "root_units": children.get(None, []), "children": children,
            "assets": assets, "assets_by_unit": assets_by_unit, "asset_paths": asset_paths,
            "selected_asset": selected_asset, "sample_history": sample_history,
            "read_only": user.role in {Role.SENIOR_CHEMIST.value, Role.QUALITY.value, Role.TECHNICAL_MANAGER.value, Role.MANAGEMENT.value},
            "client_groups": client_groups,
        },
    )
