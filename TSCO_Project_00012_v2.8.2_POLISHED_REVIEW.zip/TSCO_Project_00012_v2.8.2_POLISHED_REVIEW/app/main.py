from __future__ import annotations

import os
from html import escape
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.gzip import GZipMiddleware
from starlette.middleware.sessions import SessionMiddleware

from .database import Base, engine
from .routes import admin, api, assessment, auth, client, documents, field, home, intake, lab, lab_operations, management, operations, receiving, sampling_supervision, control_center, organization, assets, improvement, review_guide, troubleshooting
from .seed import seed

BASE_DIR = Path(__file__).resolve().parent

APP_NAME = os.getenv("APP_NAME", "TSCO Digital Laboratory Platform")
APP_ENV = os.getenv("APP_ENV", "uat").strip().lower()
APP_SECRET = os.getenv("APP_SECRET", "development-only-change-me")
if APP_ENV in {"uat", "production"} and (APP_SECRET == "development-only-change-me" or len(APP_SECRET) < 32):
    raise RuntimeError("APP_SECRET must be a strong secret of at least 32 characters in UAT/production")

api_docs_enabled = os.getenv("ENABLE_API_DOCS", "true" if APP_ENV != "production" else "false").strip().lower() in {
    "1",
    "true",
    "yes",
    "on",
}


@asynccontextmanager
async def lifespan(_: FastAPI):
    # UAT/production schemas are migration-owned. create_all is permitted only
    # for disposable local/test environments so missing migrations cannot be masked.
    if APP_ENV in {"development", "testing", "local"}:
        Base.metadata.create_all(bind=engine)
    seed()
    yield


app = FastAPI(
    title=APP_NAME,
    version="2.8.2",
    lifespan=lifespan,
    docs_url="/docs" if api_docs_enabled else None,
    redoc_url=None,
    openapi_url="/openapi.json" if api_docs_enabled else None,
)
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.state.environment = APP_ENV

secure_session_cookie = os.getenv(
    "SESSION_HTTPS_ONLY", "true" if APP_ENV in {"uat", "production"} else "false"
).strip().lower() in {"1", "true", "yes", "on"}

app.add_middleware(
    SessionMiddleware,
    secret_key=APP_SECRET,
    same_site="lax",
    https_only=secure_session_cookie,
    max_age=8 * 60 * 60,
)




@app.exception_handler(HTTPException)
async def branded_http_error(request: Request, exc: HTTPException):
    # Preserve authentication/password redirects exactly as raised by require_user.
    if exc.status_code in {301, 302, 303, 307, 308} and exc.headers and exc.headers.get("Location"):
        return RedirectResponse(exc.headers["Location"], status_code=exc.status_code)
    accepts = request.headers.get("accept", "")
    if request.url.path.startswith("/api/") or "application/json" in accepts:
        return JSONResponse({"detail": exc.detail}, status_code=exc.status_code, headers=exc.headers)
    title = "Access changed" if exc.status_code in {401, 403} else "Page unavailable"
    message = escape(str(exc.detail or "This page is not available for the active session."))
    hint = "Your active browser session may belong to a different role. Return to the current workspace or sign in again." if exc.status_code in {401, 403} else "Return to the platform and continue from an authorized workspace."
    return HTMLResponse(
        f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
        <title>{title} — TSCO Digital Laboratory</title><style>
        body{{font-family:"Segoe UI Variable Text","Segoe UI Variable","Segoe UI",Tahoma,Arial,sans-serif;background:#f3f7f9;color:#16384a;margin:0;background-image:url('/static/engineering-corner.svg');background-repeat:no-repeat;background-position:right -70px top -25px;background-size:520px auto}}
        .shell{{max-width:780px;margin:10vh auto;padding:22px}}.card{{background:#fff;border:1px solid #d9e4e8;border-radius:20px;padding:30px;box-shadow:0 16px 45px #0c304414}}
        .brand{{font-weight:900;color:#0b6070;letter-spacing:.08em;font-size:.8rem}}h1{{font-size:1.7rem;margin:10px 0}}p{{line-height:1.6;color:#5d7380}}
        .actions{{display:flex;gap:10px;flex-wrap:wrap;margin-top:20px}}a{{text-decoration:none;padding:11px 16px;border-radius:10px;font-weight:800}}.primary{{background:#0b6f78;color:#fff}}.secondary{{border:1px solid #c9d7dd;color:#244b5f;background:#f8fbfc}}
        </style></head><body><div class='shell'><div class='card'><div class='brand'>TSCO · DIGITAL LABORATORY PLATFORM</div><h1>{title}</h1><p><b>{message}</b></p><p>{hint}</p><div class='actions'><a class='primary' href='/'>Go to current workspace</a><a class='secondary' href='/logout'>Sign in as another role</a></div></div></div></body></html>""",
        status_code=exc.status_code, headers=exc.headers
    )


@app.exception_handler(ValueError)
async def user_input_error(request: Request, exc: ValueError):
    message = str(exc) or "The request could not be completed."
    accepts = request.headers.get("accept", "")
    if request.url.path.startswith("/api/") or "application/json" in accepts:
        return JSONResponse({"error": message}, status_code=400)
    safe = escape(message)
    return HTMLResponse(
        f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
        <title>Request needs correction — TSCO Digital Laboratory</title>
        <style>body{{font-family:"Segoe UI Variable Text","Segoe UI Variable","Segoe UI",Tahoma,Arial,sans-serif;background:#f4f7fa;color:#15324a;margin:0;padding:32px;background-image:url('/static/engineering-corner.svg');background-repeat:no-repeat;background-position:right -70px top -25px;background-size:520px auto}}.box{{max-width:680px;margin:10vh auto;background:white;border:1px solid #d8e1e8;border-radius:16px;padding:28px;box-shadow:0 8px 30px #15324a12}}h1{{font-size:1.4rem;margin:0 0 12px}}p{{line-height:1.55}}button{{background:#0c6271;color:white;border:0;border-radius:9px;padding:11px 16px;font-weight:700;cursor:pointer}}</style></head>
        <body><div class='box'><h1>Check the selected information</h1><p>{safe}</p><button type='button' onclick='history.back()'>Go back and correct</button></div></body></html>""",
        status_code=400,
    )


@app.middleware("http")
async def security_headers(request: Request, call_next):
    # Browser-originated state changes must stay same-origin. This blocks ordinary
    # cross-site form/fetch submissions without weakening non-browser API clients.
    if request.method.upper() in {"POST", "PUT", "PATCH", "DELETE"}:
        fetch_site = request.headers.get("sec-fetch-site", "").strip().lower()
        if fetch_site == "cross-site":
            return JSONResponse({"error": "Cross-site state-changing request rejected"}, status_code=403)
        origin = request.headers.get("origin", "").strip().rstrip("/")
        if origin:
            expected = f"{request.url.scheme}://{request.headers.get('host', request.url.netloc)}".rstrip("/")
            if origin != expected:
                return JSONResponse({"error": "Cross-origin state-changing request rejected"}, status_code=403)

    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(self), geolocation=(self), microphone=()")
    response.headers.setdefault("Content-Security-Policy", "default-src 'self' data: blob:; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; frame-src 'self'; frame-ancestors 'self'; connect-src 'self';")
    if APP_ENV in {"uat", "production"}:
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    if request.url.path.startswith(("/login", "/change-password", "/admin", "/client", "/track", "/field", "/intake", "/receiving", "/lab", "/assessment", "/operations", "/sampling-supervision", "/management", "/documents", "/organization", "/assets", "/improvement", "/troubleshooting", "/review-guide", "/api")):
        response.headers.setdefault("Cache-Control", "no-store")
    return response


app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

app.include_router(auth.router)
app.include_router(admin.router)
app.include_router(home.router)
app.include_router(field.router)
app.include_router(intake.router)
app.include_router(receiving.router)
app.include_router(lab.router)
app.include_router(lab_operations.router)
app.include_router(assessment.router)
app.include_router(operations.router)
app.include_router(sampling_supervision.router)
app.include_router(client.router)
app.include_router(documents.router)
app.include_router(management.router)
app.include_router(control_center.router)
app.include_router(organization.router)
app.include_router(assets.router)
app.include_router(improvement.router)
app.include_router(troubleshooting.router)
app.include_router(review_guide.router)
app.include_router(api.router)
