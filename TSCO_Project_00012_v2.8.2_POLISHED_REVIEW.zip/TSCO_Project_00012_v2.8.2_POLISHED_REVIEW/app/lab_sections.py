from __future__ import annotations

from .models import Role

LAB_SECTION_INFO = {
    "dashboard": ("Operations Overview", "Laboratory flow, workload and operational status."),
    "labprogress": ("Laboratory Progress", "Live team board showing sample priority, assignment and completion progress."),
    "supervisor": ("Technical Supervision", "Senior Chemist workload, result review, retest/resample and technical supervision."),
    "batch": ("Batch Diagnostics", "Admin-only compatibility view. Operational sample batching is owned by Sample Intake & Distribution."),
    "workstations": ("Test Workstations", "Assigned analytical result entry with controlled method and calculation support."),
    "finalreport": ("Reports", "Controlled worksheet and reporting visibility up to the LMS approval boundary."),
    "retained": ("Retained Samples", "Storage location, retention period, due dates and controlled disposal."),
    "quality": ("Quality Control", "Asset-specific QC execution for laboratory employees and oversight/governance for Senior/Quality roles."),
    "knowledge": ("Methods & Procedures", "Controlled methods, SOPs, EOPs and quick operating guidance."),
    "tracking": ("Operations Records", "Searchable sample history, result actions and operational records."),
    "general": ("Laboratory Settings", "Site, staff, document and controlled calculation configuration."),
}

# This matrix is intentionally restrictive. Job seniority does not automatically inherit
# transactional rights from a lower operational role.
LAB_ROLE_SECTIONS = {
    Role.LAB_TECHNICIAN.value: {"workstations", "knowledge"},
    Role.SENIOR_CHEMIST.value: {"dashboard", "labprogress", "supervisor", "finalreport", "retained", "knowledge", "tracking"},
    Role.QUALITY.value: {"labprogress", "retained", "quality", "knowledge", "tracking"},
    Role.TECHNICAL_MANAGER.value: {"dashboard", "labprogress", "supervisor", "finalreport", "retained", "quality", "knowledge", "tracking", "general"},
    Role.MANAGEMENT.value: set(),
    Role.SYSTEM_ADMIN.value: set(LAB_SECTION_INFO),
}


def lab_section_allowed(role: str, section: str) -> bool:
    return section in LAB_ROLE_SECTIONS.get(role, set())
