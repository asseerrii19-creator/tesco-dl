from __future__ import annotations

import calendar
import json
import math
import re
from copy import deepcopy
from datetime import datetime
from uuid import uuid4
from pathlib import Path
from typing import Any

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..models import Client, OperationsState, Role, SampleRequest, SampleStatus, Site, TestPackageConfig, User, CompetencyRecord, StaffAvailability, StaffWorkPattern, EquipmentAsset

BASE_DIR = Path(__file__).resolve().parents[1]
PACKAGE_FILE = BASE_DIR / "data" / "lab_packages.json"


def package_catalog(db: Session | None = None, site_id: int | None = None) -> list[dict[str, Any]]:
    try:
        base = json.loads(PACKAGE_FILE.read_text(encoding="utf-8"))["packages"]
    except Exception:
        base = []
    if db is None:
        return base
    stmt = select(TestPackageConfig).where(TestPackageConfig.active.is_(True))
    if site_id is not None:
        stmt = stmt.where((TestPackageConfig.site_id.is_(None)) | (TestPackageConfig.site_id == site_id))
    rows = db.scalars(stmt.order_by(TestPackageConfig.name)).all()
    dynamic = []
    for row in rows:
        try:
            tests = json.loads(row.tests_json or "[]")
        except Exception:
            tests = []
        tests = [_normalize_package_test(item) for item in tests if isinstance(item, dict)] if isinstance(tests, list) else []
        dynamic.append({
            "id": row.code, "name": row.name, "scope": row.scope, "kind": "configured",
            "site_id": row.site_id, "tests": tests,
        })
    # Once a database session is available, PostgreSQL/SQL is the sole runtime master source.
    # lab_packages.json is bootstrap seed material only; it is not merged over central configuration.
    return dynamic


def ensure_baseline_test_packages(db: Session) -> None:
    """Seed built-in package definitions once into central SQL master data.

    Existing rows (including rows an administrator disabled) are never overwritten/re-enabled.
    """
    try:
        base = json.loads(PACKAGE_FILE.read_text(encoding="utf-8")).get("packages", [])
    except Exception:
        base = []
    for package in base:
        code = str(package.get("id") or "").strip().upper()
        name = str(package.get("name") or "").strip()
        if not code or not name:
            continue
        if db.scalar(select(TestPackageConfig.id).where(TestPackageConfig.code == code)) is not None:
            continue
        tests = package.get("tests") if isinstance(package.get("tests"), list) else []
        tests = [_normalize_package_test(item) for item in tests if isinstance(item, dict)]
        db.add(TestPackageConfig(
            code=code[:80],
            name=name[:160],
            scope=str(package.get("scope") or "GENERAL").strip().upper()[:80],
            tests_json=json.dumps(tests, ensure_ascii=False),
            active=True,
        ))
    db.flush()


QUALITY_ROUTINE_TASKS = (
    # Gas Supplies and the Gas Cylinder daily-record responsibility share the same
    # Primary/Backup pair for each period, matching the controlled paper distribution.
    {"key": "gas_supplies", "group": "gas_control", "name": "Gas Supplies Check", "domain": "Materials, Gases & Storage", "frequency": "period"},
    {"key": "gas_cylinder", "group": "gas_control", "name": "Gas Cylinder Status / Daily Record", "domain": "Materials, Gases & Storage", "frequency": "period"},
    {"key": "balances", "group": "balances", "name": "Balances Check", "domain": "Equipment & Safety", "frequency": "period"},
    {"key": "electrode", "group": "electrode", "name": "Electrode Check", "domain": "Equipment & Safety", "frequency": "period"},
    {"key": "chemical_inventory", "group": "chemical_inventory", "name": "Chemical Inventory Check", "domain": "Materials, Gases & Storage", "frequency": "period"},
    {"key": "sample_storage", "group": "sample_storage", "name": "Sample Storage Check", "domain": "Materials, Gases & Storage", "frequency": "period"},
    {"key": "shower_eye_wash", "group": "shower_eye_wash", "name": "Shower & Eye Wash Check", "domain": "Equipment & Safety", "frequency": "monthly"},
)


def _quality_staff_initials(name: str) -> str:
    words = [part for part in str(name or "").replace("-", " ").split() if part]
    return "".join(part[0].upper() for part in words[:4]) or "—"


def _quality_periods(year: int, month: int) -> list[dict[str, Any]]:
    last = calendar.monthrange(year, month)[1]
    return [
        {"key": "W1", "label": "Week 1 • 1–11", "start_day": 1, "end_day": min(11, last)},
        {"key": "W2", "label": "Week 2 • 12–18", "start_day": min(12, last), "end_day": min(18, last)},
        {"key": "W3", "label": "Week 3 • 19–25", "start_day": min(19, last), "end_day": min(25, last)},
        {"key": "W4", "label": f"Week 4 • 26–{last}", "start_day": min(26, last), "end_day": last},
    ]


def ensure_monthly_quality_distribution(
    payload: dict[str, Any], staff: list[User], *, when: datetime | None = None
) -> dict[str, Any] | None:
    """Create the current site's monthly Quality Control Distribution once.

    The schedule is server-owned. It follows the laboratory's four operational periods and
    automatically rotates a Primary and Backup chemist each month. Existing monthly schedules
    are never rewritten, preserving the historical distribution used at the time.
    """
    payload.setdefault("qualityDistributions", [])
    payload.setdefault("qualityTaskEvents", [])
    now = when or datetime.utcnow()
    month_key = now.strftime("%Y-%m")
    existing = [row for row in payload["qualityDistributions"] if str(row.get("month")) == month_key]

    eligible_roles = {Role.LAB_TECHNICIAN.value}
    eligible = sorted(
        [row for row in staff if row.active and row.role in eligible_roles],
        key=lambda row: (row.full_name.lower(), row.id or 0),
    )
    if not eligible:
        return max(existing, key=lambda row: int(row.get("revision") or 1)) if existing else None

    # Preserve historical/current revisions, but if the active month was generated under an old
    # role matrix (for example a Senior Chemist appeared as Backup) publish a new revision instead
    # of silently rewriting the old schedule. The same applies when a second eligible technician
    # becomes available and the current review distribution still has no backup.
    revision = 1
    if existing:
        latest = max(existing, key=lambda row: int(row.get("revision") or 1))
        eligible_ids = {int(row.id) for row in eligible if row.id is not None}
        assignments = latest.get("assignments", []) if isinstance(latest, dict) else []
        invalid = any(int(a.get("primary_user_id") or 0) not in eligible_ids for a in assignments)
        invalid = invalid or any(a.get("backup_user_id") and int(a.get("backup_user_id")) not in eligible_ids for a in assignments)
        if len(eligible) > 1:
            invalid = invalid or any(not a.get("backup_user_id") for a in assignments)
        if not invalid:
            return latest
        revision = max(int(row.get("revision") or 1) for row in existing) + 1

    periods = _quality_periods(now.year, now.month)
    month_index = now.year * 12 + now.month - 1
    assignments: list[dict[str, Any]] = []
    group_order = list(dict.fromkeys(str(task["group"]) for task in QUALITY_ROUTINE_TASKS))
    for task in QUALITY_ROUTINE_TASKS:
        group_index = group_order.index(str(task["group"]))
        task_periods = periods if task["frequency"] == "period" else [{
            "key": "MONTH", "label": "Monthly", "start_day": 1,
            "end_day": calendar.monthrange(now.year, now.month)[1],
        }]
        for period_index, period in enumerate(task_periods):
            # Responsibility is rotated by duty-group + period. Tasks in the same duty-group
            # (the two gas-control rows) intentionally receive the same pair for that period.
            slot = group_index * 4 + period_index
            primary_index = (month_index + slot) % len(eligible)
            primary = eligible[primary_index]
            backup = None
            if len(eligible) > 1:
                offset = 1 + ((month_index + group_index + period_index) % (len(eligible) - 1))
                backup = eligible[(primary_index + offset) % len(eligible)]
            assignment_id = f"QTA-{month_key}-{task['key']}-{period['key']}"
            assignments.append({
                "id": assignment_id,
                "task_key": task["key"], "task_group": task["group"], "task": task["name"], "domain": task["domain"],
                "frequency": task["frequency"], "period": period["key"], "period_label": period["label"],
                "start_day": period["start_day"], "end_day": period["end_day"],
                "primary_user_id": primary.id, "primary_name": primary.full_name,
                "primary_initials": _quality_staff_initials(primary.full_name),
                "backup_user_id": backup.id if backup else None,
                "backup_name": backup.full_name if backup else "",
                "backup_initials": _quality_staff_initials(backup.full_name) if backup else "—",
            })

    distribution = {
        "id": f"QDIST-{month_key}-R{revision}", "month": month_key, "revision": revision,
        "status": "PUBLISHED", "rotation": "AUTO_MONTHLY_PRIMARY_BACKUP",
        "generated_at": now.isoformat(), "generated_by": "System Monthly Rotation",
        "period_model": "W1 1-11 / W2 12-18 / W3 19-25 / W4 26-EOM",
        "assignments": assignments,
    }
    payload["qualityDistributions"].append(distribution)
    return distribution


def blank_operations_db(site: Site) -> dict[str, Any]:
    now = datetime.utcnow().isoformat()
    return {
        "batches": [], "results": [], "qc": [], "qualifiedQcProfiles": [], "reports": [],
        "retained": [], "retests": [], "storageAssignments": [], "batchHistory": [],
        "cancelledSamples": [], "supervisorNotes": [], "standards": [], "dgaAttachments": [],
        "qualityDistributions": [], "qualityTaskEvents": [], "testAssignments": [],
        "clients": [], "customPackages": [], "formulaDefinitions": [], "calculationDrafts": {},
        "staff": [], "samplePoints": ["Main Tank / Bottom", "Tap Changer 1", "Tap Changer 2", "Tap Changer 3", "Tap Changer H1", "Tap Changer H2", "Tap Changer H3", "Cable Box H1", "Cable Box H2", "Cable Box H3", "Cable Box Y", "Cable Box R", "Cable Box N", "Cable Box B", "Other"],
        "testUnits": {}, "drafts": {},
        "settings": {
            "labCode": "DM" if site.code == "DMM" else site.code,
            "yearCode": datetime.utcnow().strftime("%y"), "prefixPadding": "00",
            "normalRetentionDays": 15, "urgentRetentionDays": 15,
            "currentSite": site.code, "enabledSites": [site.code],
            "qcProfileSelections": {}, "activeSeniorChemist": "",
        },
        "meta": {"schema": 4, "site": site.code, "revision": 0, "updatedAt": now, "platformIntegrated": True},
    }


def get_operations_state(db: Session, site: Site) -> tuple[OperationsState, dict[str, Any]]:
    state = db.scalar(select(OperationsState).where(OperationsState.site_id == site.id))
    if not state:
        payload = blank_operations_db(site)
        state = OperationsState(site_id=site.id, json_data=json.dumps(payload, ensure_ascii=False), revision=0)
        db.add(state)
        db.flush()
    else:
        try:
            payload = json.loads(state.json_data or "{}")
        except json.JSONDecodeError:
            payload = blank_operations_db(site)
        if not isinstance(payload, dict) or "batches" not in payload:
            payload = blank_operations_db(site)

    # Refresh browser-visible master references from PostgreSQL on every load.
    clients = db.scalars(select(Client).where(Client.active.is_(True)).order_by(Client.name)).all()
    payload["clients"] = [{"id": str(row.id), "code": row.code, "name": row.name, "active": True} for row in clients]
    lab_roles = {Role.LAB_TECHNICIAN.value, Role.SENIOR_CHEMIST.value, Role.QUALITY.value, Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value}
    staff = db.scalars(select(User).where(User.active.is_(True), User.site_id == site.id, User.role.in_(lab_roles)).order_by(User.full_name)).all()
    payload["staff"] = [{"id": row.id, "name": row.full_name, "role": row.role, "active": True} for row in staff]
    payload["qualityDistributions"] = payload.get("qualityDistributions") if isinstance(payload.get("qualityDistributions"), list) else []
    payload["qualityTaskEvents"] = payload.get("qualityTaskEvents") if isinstance(payload.get("qualityTaskEvents"), list) else []
    payload["testAssignments"] = payload.get("testAssignments") if isinstance(payload.get("testAssignments"), list) else []
    for batch in payload.get("batches", []):
        if isinstance(batch, dict) and isinstance(batch.get("tests"), list):
            batch["tests"] = [_normalize_package_test(item) for item in batch["tests"] if isinstance(item, dict)]
    # The current-month schedule is deterministic and server-owned. It is materialized in the
    # returned payload and becomes durable on the next normal state save/backup restore; reading
    # state must never advance the optimistic-lock revision.
    ensure_monthly_quality_distribution(payload, staff)
    payload["customPackages"] = []
    payload["formulaDefinitions"] = []
    payload.pop("controlledDocuments", None)
    return state, payload


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _same(a: Any, b: Any) -> bool:
    return _canonical(a) == _canonical(b)


def _require_unchanged(current: dict[str, Any], proposed: dict[str, Any], keys: set[str]) -> None:
    changed = [key for key in keys if not _same(current.get(key), proposed.get(key))]
    if changed:
        raise PermissionError("Browser-side master data is read-only: " + ", ".join(sorted(changed)))


def _validate_append_only(current_rows: Any, proposed_rows: Any, label: str) -> list[dict[str, Any]]:
    """Reject history rewrites and return only records newly appended by the browser.

    Matching is performed on the complete canonical record, not merely on an id. This means an
    existing record cannot be silently edited while retaining its identifier. New records may be
    inserted anywhere in the browser array (some UI tables use ``unshift``), but every old record
    must still be present byte-for-byte at the JSON value level.
    """
    from collections import Counter

    if not isinstance(current_rows, list) or not isinstance(proposed_rows, list):
        raise ValueError(f"{label} must be a list")
    if any(not isinstance(row, dict) for row in current_rows + proposed_rows):
        raise ValueError(f"Every {label} record must be an object")

    remaining = Counter(_canonical(row) for row in current_rows)
    new_rows: list[dict[str, Any]] = []
    for row in proposed_rows:
        key = _canonical(row)
        if remaining[key]:
            remaining[key] -= 1
        else:
            new_rows.append(row)
    if any(remaining.values()):
        raise PermissionError(f"Existing {label} records cannot be changed or deleted; add a new record/revision instead")
    return new_rows


def _require_unique_record_ids(rows: list[dict[str, Any]], label: str, *, assign_missing: bool = False) -> None:
    seen: set[str] = set()
    for row in rows:
        rid = str(row.get("id") or "").strip()
        if not rid and assign_missing:
            rid = f"{label.upper().replace(' ', '-')}-{uuid4().hex}"
            row["id"] = rid
        if not rid:
            raise ValueError(f"Every {label} record requires an id")
        if rid in seen:
            raise PermissionError(f"Duplicate {label[:-1] if label.endswith('s') else label} record id is not permitted")
        seen.add(rid)


def _batch_for_sample(payload: dict[str, Any], sample: str) -> dict[str, Any] | None:
    return next((b for b in payload.get("batches", []) if sample in [str(x) for x in b.get("samples", [])]), None)


TAN_WORKSTATION = "TAN / Peroxide / RSH / H2S"
FURAN_PASSIVATOR_WORKSTATION = "Furan / Passivator"
GC_ADDITIVES_WORKSTATION = "DBDS / BHT / Toluene / PCB"
CORROSION_WORKSTATION = "Corrosion / CCD"
KNOWN_WORKSTATIONS = {
    "Water", "Electrical", "DGA", FURAN_PASSIVATOR_WORKSTATION,
    GC_ADDITIVES_WORKSTATION, TAN_WORKSTATION, CORROSION_WORKSTATION,
    "Physical / Chemistry", "Additives / Special Tests",
}

_WORKSTATION_ALIASES = {
    "Furan": FURAN_PASSIVATOR_WORKSTATION,
    "GC-ECD": GC_ADDITIVES_WORKSTATION,
    "GC-FID": GC_ADDITIVES_WORKSTATION,
    "GC Additives": GC_ADDITIVES_WORKSTATION,
    "Corrosion": CORROSION_WORKSTATION,
}

def _canonical_workstation_name(value: str) -> str:
    name = str(value or "").strip()
    return _WORKSTATION_ALIASES.get(name, name)


def _station_from_name(test: str) -> str:
    """Server-side workstation classifier used for authorization.

    The browser may provide a station label for configured package tests, but derived/calculated
    result codes are classified here so URL/UI manipulation cannot bypass assignment controls.
    """
    name = str(test or "").strip()
    low = name.lower()
    if low.startswith("water:") or low.startswith("water_calc:") or any(x in low for x in ("water content", "transformer oil temperature", "humidity in cellulose", "relative saturation", "mineral oil log cw")) or low == "cw":
        return "Water"
    if low.startswith("dga:") or low.startswith("dga_calc:") or "dissolved gas" in low or low == "dga" or "gas analysis" in low:
        return "DGA"
    if low.startswith("furan:") or low.startswith("furan_calc:") or any(x in low for x in ("furan", "furf", "2fal", "2-fal", "dp-value", "paper lifetime", "passivator", "irgamet", "tta", "bta")):
        return FURAN_PASSIVATOR_WORKSTATION
    if any(x in low for x in ("breakdown voltage", "bdv", "power factor", "dissipation factor", "resistivity")):
        return "Electrical"
    if any(x in low for x in ("dbds", "dibenzyl", "pcb", "polychlorinated", "bht", "antioxidant", "toluene")):
        return GC_ADDITIVES_WORKSTATION
    if any(x in low for x in ("corrosive sulfur", "potentially corrosive", "tarnish", "copper corrosion", "ccd")):
        return CORROSION_WORKSTATION
    if any(x in low for x in ("total acid number", "acid number", "peroxide", "hydroperoxide", "rsh", "mercaptan", "hydrogen sulfide", "h2s")):
        return TAN_WORKSTATION
    if any(x in low for x in ("color", "colour", "density", "viscosity", "flash point", "interfacial tension", "ift", "pour point", "appearance", "oil quality index", "oqi", "oqin")):
        return "Physical / Chemistry"
    return "Additives / Special Tests"


def _normalize_package_test(row: dict[str, Any]) -> dict[str, Any]:
    """Normalize configured package rows while preserving controlled master-data choices.

    Historical v2.6.7 rows are repaired when they carry a known stale/blank method or an old
    workstation alias.  Explicit current Admin configuration is otherwise authoritative so a
    future approved method revision or a newly configured test does not require a code change.
    """
    out = dict(row or {})
    test = str(out.get("test") or "").strip()
    low = test.lower()
    configured_station = _canonical_workstation_name(str(out.get("station") or "").strip())
    out["station"] = configured_station if configured_station in KNOWN_WORKSTATIONS else _station_from_name(test)

    method = str(out.get("method") or "").strip()
    method_upper = method.upper()
    if test == "Total Acid Number" and method_upper in {"", "-", "ASTM D664"}:
        # Controlled QDF [7]-07-E baseline correction. A future explicitly configured
        # approved method is preserved rather than hard-coded back to D974.
        out["method"] = "ASTM D974"
    elif low in {"h2s", "hydrogen sulfide gas (h2s)"} and method_upper in {"", "-"}:
        out["method"] = "UOP 163"
    elif low in {"ph", "ph-value"} and method_upper in {"", "-"}:
        out["method"] = "ASTM WK35536"
    else:
        out["method"] = method
    return out


def _workstation_for_test(batch: dict[str, Any], test: str) -> str:
    # Exact requested tests use their server-held package master-data workstation. Calculated
    # or derived result codes fall back to the protected classifier. Browser payloads cannot
    # rewrite batch test structure, so this keeps authorization controlled and configurable.
    for raw in batch.get("tests", []):
        row = raw if isinstance(raw, dict) else {"test": raw}
        if str(row.get("test") or "") != str(test or ""):
            continue
        configured = _canonical_workstation_name(str(row.get("station") or "").strip())
        if configured in KNOWN_WORKSTATIONS:
            return configured
        break
    return _station_from_name(test)


def _batch_workstations(batch: dict[str, Any]) -> set[str]:
    return {
        _workstation_for_test(batch, str((row if isinstance(row, dict) else {"test": row}).get("test", "")))
        for row in batch.get("tests", [])
    }


def _latest_assignment_for_key(payload: dict[str, Any], batch_id: str, workstation: str) -> dict[str, Any] | None:
    rows = [
        row for row in payload.get("testAssignments", [])
        if str(row.get("batch_id") or "") == str(batch_id or "")
        and _canonical_workstation_name(str(row.get("workstation") or "")) == _canonical_workstation_name(str(workstation or ""))
    ]
    if not rows:
        return None
    rows.sort(key=lambda row: (int(row.get("revision") or 0), str(row.get("assigned_at") or "")))
    return rows[-1]


def _current_test_assignment(payload: dict[str, Any], batch_id: str, workstation: str) -> dict[str, Any] | None:
    """Resolve assignment with a batch-specific override ahead of the site/workstation default.

    batch_id='*' represents the bench assignment that automatically applies to all current and
    future batches at the site. A Senior Chemist may still create a specific-batch override when
    workload or absence requires it.
    """
    exact = _latest_assignment_for_key(payload, str(batch_id or ""), workstation)
    if exact or str(batch_id or "") == "*":
        return exact
    return _latest_assignment_for_key(payload, "*", workstation)


def _assignment_allows_user(payload: dict[str, Any], batch: dict[str, Any], test: str, user: User) -> bool:
    # Visibility can be broader for Senior/Admin, but analytical write authority follows an
    # explicit workstation assignment. Senior Chemists can assign/reassign themselves when
    # they need to cover a bench; System Administrators do not author laboratory results.
    if user.role != Role.LAB_TECHNICIAN.value:
        return False
    workstation = _workstation_for_test(batch, test)
    assignment = _current_test_assignment(payload, str(batch.get("id") or ""), workstation)
    if not assignment:
        return False
    mode = str(assignment.get("mode") or "SINGLE").upper()
    if mode == "ALL":
        return True
    uid = int(user.id or 0)
    return uid in {int(assignment.get("primary_user_id") or 0), int(assignment.get("backup_user_id") or 0)}


def _qc_workstation(group: str) -> str:
    low = str(group or "").lower()
    if "water" in low:
        return "Water"
    if "dga" in low:
        return "DGA"
    if any(x in low for x in ("furan", "passivator", "irgamet", "tta", "bta")):
        return FURAN_PASSIVATOR_WORKSTATION
    if "bdv" in low or "power factor" in low or "dissipation" in low or "resist" in low or "electrode" == low.strip():
        return "Electrical"
    if any(x in low for x in ("dbds", "pcb", "bht", "toluene", "antioxidant")):
        return GC_ADDITIVES_WORKSTATION
    if any(x in low for x in ("tan", "acid", "peroxide", "rsh", "mercaptan", "h2s")):
        return TAN_WORKSTATION
    if any(x in low for x in ("corros", "tarnish", "copper", "ccd")):
        return CORROSION_WORKSTATION
    if any(x in low for x in ("color", "colour", "viscosity", "density", "flash", "ift", "interfacial")):
        return "Physical / Chemistry"
    return "Additives / Special Tests"


def _user_has_workstation_assignment(payload: dict[str, Any], workstation: str, user: User) -> bool:
    # Analytical/Test QC is performed by assigned laboratory chemists. Quality oversees and
    # qualifies QC profiles/materials through its dedicated controls; it is not an automatic
    # bench-operator override.
    if user.role != Role.LAB_TECHNICIAN.value:
        return False
    for batch in payload.get("batches", []):
        if workstation not in _batch_workstations(batch):
            continue
        assignment = _current_test_assignment(payload, str(batch.get("id") or ""), workstation)
        if not assignment:
            continue
        if str(assignment.get("mode") or "SINGLE").upper() == "ALL":
            return True
        uid = int(user.id or 0)
        if uid in {int(assignment.get("primary_user_id") or 0), int(assignment.get("backup_user_id") or 0)}:
            return True
    return False



def _assignment_allows_user_row(assignment: dict[str, Any], user: User) -> bool:
    """Return whether one explicit assignment row authorizes the authenticated chemist."""
    if user.role != Role.LAB_TECHNICIAN.value:
        return False
    if str(assignment.get("mode") or "SINGLE").upper() == "ALL":
        return True
    uid = int(user.id or 0)
    return uid in {
        int(assignment.get("primary_user_id") or 0),
        int(assignment.get("backup_user_id") or 0),
    }


def _current_user_assignment_map(payload: dict[str, Any], user: User) -> dict[tuple[str, str], dict[str, Any]]:
    """Current batch/workstation assignments that authorize this user.

    Historical superseded assignments are deliberately excluded. This map is used both for
    server-side read scoping and for analytical-QC authorization.
    """
    out: dict[tuple[str, str], dict[str, Any]] = {}
    for batch in payload.get("batches", []):
        if not isinstance(batch, dict):
            continue
        batch_id = str(batch.get("id") or "")
        if not batch_id:
            continue
        for workstation in _batch_workstations(batch):
            assignment = _current_test_assignment(payload, batch_id, workstation)
            if assignment and _assignment_allows_user_row(assignment, user):
                out[(batch_id, workstation)] = assignment
    return out


def scope_operations_payload(payload: dict[str, Any], user: User) -> dict[str, Any]:
    """Return the least-privilege laboratory payload for the authenticated user.

    Lab Technicians receive only the batches/tests/results/QC/retests and monthly routine-QC
    assignments that are relevant to their current assignments. Supervisory roles retain their
    approved site-level visibility. This is a data-boundary control, not merely a UI filter.
    """
    if user.role != Role.LAB_TECHNICIAN.value:
        return payload

    scoped = deepcopy(payload)
    allowed = _current_user_assignment_map(payload, user)
    allowed_pairs = set(allowed)
    allowed_workstations = {ws for _, ws in allowed_pairs}

    # Batches are visible only when at least one workstation is currently assigned to the user;
    # each batch is reduced to the tests within those assignments.
    scoped_batches: list[dict[str, Any]] = []
    sample_to_batch: dict[str, str] = {}
    for batch in payload.get("batches", []):
        if not isinstance(batch, dict):
            continue
        bid = str(batch.get("id") or "")
        allowed_ws = {ws for b, ws in allowed_pairs if b == bid}
        if not allowed_ws:
            continue
        copy_batch = deepcopy(batch)
        copy_batch["tests"] = [
            deepcopy(row) for row in batch.get("tests", [])
            if _station_from_name((row if isinstance(row, dict) else {"test": row}).get("test", "")) in allowed_ws
        ]
        if not copy_batch["tests"]:
            continue
        scoped_batches.append(copy_batch)
        for sample in copy_batch.get("samples", []):
            sample_to_batch[str(sample)] = bid
    scoped["batches"] = scoped_batches

    def result_allowed(row: dict[str, Any]) -> bool:
        sample = str(row.get("sample") or "")
        bid = sample_to_batch.get(sample)
        if not bid:
            return False
        return (bid, _station_from_name(str(row.get("test") or ""))) in allowed_pairs

    scoped["results"] = [deepcopy(r) for r in payload.get("results", []) if isinstance(r, dict) and result_allowed(r)]
    scoped["qc"] = [
        deepcopy(r) for r in payload.get("qc", [])
        if isinstance(r, dict) and _qc_workstation(str(r.get("test") or "")) in allowed_workstations
    ]
    scoped["qualifiedQcProfiles"] = [
        deepcopy(r) for r in payload.get("qualifiedQcProfiles", [])
        if isinstance(r, dict) and _qc_workstation(str(r.get("test") or "")) in allowed_workstations
    ]
    scoped["retests"] = [
        deepcopy(r) for r in payload.get("retests", [])
        if isinstance(r, dict)
        and (sample_to_batch.get(str(r.get("sample") or "")), _station_from_name(str(r.get("test") or ""))) in allowed_pairs
    ]
    scoped["dgaAttachments"] = [
        deepcopy(r) for r in payload.get("dgaAttachments", [])
        if isinstance(r, dict)
        and (sample_to_batch.get(str(r.get("sample") or "")), "DGA") in allowed_pairs
    ]

    # The technician needs only the current rows that actually authorize their own work.
    scoped["testAssignments"] = [deepcopy(a) for a in allowed.values()]

    # Routine/Monthly QC is a separate assignment domain. Expose only rows where the
    # authenticated technician is Primary or Backup, independent of analytical workstation.
    routine_assignment_ids: set[str] = set()
    scoped_distributions: list[dict[str, Any]] = []
    uid = int(user.id or 0)
    for distribution in payload.get("qualityDistributions", []):
        if not isinstance(distribution, dict):
            continue
        assigned = [
            deepcopy(a) for a in distribution.get("assignments", [])
            if isinstance(a, dict) and uid in {
                int(a.get("primary_user_id") or 0), int(a.get("backup_user_id") or 0)
            }
        ]
        if assigned:
            d = deepcopy(distribution)
            d["assignments"] = assigned
            scoped_distributions.append(d)
            routine_assignment_ids.update(str(a.get("id") or "") for a in assigned)
    scoped["qualityDistributions"] = scoped_distributions
    scoped["qualityTaskEvents"] = [
        deepcopy(e) for e in payload.get("qualityTaskEvents", [])
        if isinstance(e, dict) and str(e.get("assignment_id") or "") in routine_assignment_ids
    ]

    # Supervisory/report/retention history is not needed for the technician's approved pages.
    for key in ("reports", "retained", "storageAssignments", "batchHistory", "cancelledSamples", "supervisorNotes"):
        scoped[key] = []

    # Avoid leaking the complete laboratory staff directory into a bench payload. The current
    # user's identity is sufficient for result/QC evidence; Primary/Backup names are carried on
    # their assigned routine/test rows.
    scoped["staff"] = [
        deepcopy(row) for row in payload.get("staff", [])
        if isinstance(row, dict) and int(row.get("id") or 0) == uid
    ]
    return scoped


def _merge_rows_by_id(current_rows: list[dict[str, Any]], incoming_rows: list[dict[str, Any]], label: str) -> list[dict[str, Any]]:
    """Overlay scoped rows by immutable record id while preserving all unseen server rows."""
    if not isinstance(incoming_rows, list) or any(not isinstance(r, dict) for r in incoming_rows):
        raise ValueError(f"{label} must be a list of objects")
    merged = [deepcopy(r) for r in current_rows]
    index = {str(r.get("id")): i for i, r in enumerate(merged) if r.get("id") is not None}
    seen_incoming: set[str] = set()
    for row in incoming_rows:
        rid = str(row.get("id") or "").strip()
        if not rid:
            raise ValueError(f"Every {label} record requires an id")
        if rid in seen_incoming:
            raise PermissionError(f"Duplicate {label[:-1] if label.endswith('s') else label} record id is not permitted")
        seen_incoming.add(rid)
        if rid in index:
            merged[index[rid]] = deepcopy(row)
        else:
            index[rid] = len(merged)
            merged.append(deepcopy(row))
    return merged


def merge_scoped_operations_update(current: dict[str, Any], incoming: dict[str, Any], user: User) -> dict[str, Any]:
    """Merge a Lab Technician's assignment-scoped browser payload back into full server state."""
    if user.role != Role.LAB_TECHNICIAN.value:
        return incoming
    if not isinstance(incoming, dict):
        raise ValueError("Invalid operations database")
    unknown = set(incoming) - set(current)
    if unknown:
        raise PermissionError("Unknown browser database fields are not accepted: " + ", ".join(sorted(unknown)))

    # Compare all non-editable keys with the same scoped snapshot the technician was entitled
    # to receive. A forged batch/assignment/config change is rejected rather than silently ignored.
    baseline = scope_operations_payload(current, user)
    editable_lists = {"results", "qc", "retests", "qualityTaskEvents", "dgaAttachments"}
    editable_dicts = {"drafts", "calculationDrafts"}
    for key, value in incoming.items():
        if key in editable_lists or key in editable_dicts or key == "meta":
            continue
        if not _same(baseline.get(key), value):
            raise PermissionError(f"Assignment-scoped field '{key}' is read-only for Laboratory Technician")

    merged = deepcopy(current)
    # Records visible in the scoped payload retain their normal immutability/deletion rules;
    # scoping must not accidentally turn omission into a hidden delete/restore operation.
    for key in {"results", "qc", "retests", "qualityTaskEvents"}:
        if key in incoming:
            baseline_ids = {str(r.get("id")) for r in baseline.get(key, []) if isinstance(r, dict) and r.get("id") is not None}
            incoming_ids = {str(r.get("id")) for r in incoming.get(key, []) if isinstance(r, dict) and r.get("id") is not None}
            if baseline_ids - incoming_ids:
                raise PermissionError(f"Existing {key} records cannot be changed or deleted; preserve the record history")
    for key in editable_lists:
        if key in incoming:
            merged[key] = _merge_rows_by_id(current.get(key, []), incoming.get(key, []), key)
    for key in editable_dicts:
        if key in incoming:
            if not isinstance(incoming.get(key), dict):
                raise ValueError(f"{key} must be an object")
            combined = dict(current.get(key) or {})
            combined.update(deepcopy(incoming.get(key) or {}))
            merged[key] = combined
    # Server metadata/configuration remains authoritative.
    merged["meta"] = deepcopy(current.get("meta") or {})
    return merged


def _validate_analytical_qc_assignment(payload: dict[str, Any], row: dict[str, Any], user: User) -> None:
    """Bind a technician analytical-QC record to one current batch/workstation assignment."""
    workstation = _qc_workstation(str(row.get("test") or ""))
    if user.role != Role.LAB_TECHNICIAN.value:
        raise PermissionError("Only a Laboratory Technician can record Analytical / Test QC")
    assignment_id = str(row.get("assignment_id") or "").strip()
    batch_id = str(row.get("batch_id") or "").strip()
    if not assignment_id or not batch_id:
        # Backward-compatible server binding for pre-v2.6.8 browser records: choose only a
        # CURRENT assignment that authorizes this authenticated user. Superseded rows are never
        # considered. v2.6.8+ clients send the assignment explicitly.
        candidates: dict[str, dict[str, Any]] = {}
        global_assignment = _latest_assignment_for_key(payload, "*", workstation)
        if global_assignment and _assignment_allows_user_row(global_assignment, user):
            candidates[str(global_assignment.get("id") or "")] = global_assignment
        for candidate_batch in payload.get("batches", []):
            if workstation not in _batch_workstations(candidate_batch):
                continue
            current = _current_test_assignment(payload, str(candidate_batch.get("id") or ""), workstation)
            if current and _assignment_allows_user_row(current, user):
                candidates[str(current.get("id") or "")] = current
        if not candidates:
            raise PermissionError(f"Authenticated user is not assigned to the {workstation} workstation required for this analytical QC")
        chosen = sorted(candidates.values(), key=lambda a: (str(a.get("batch_id") or "") != "*", int(a.get("revision") or 0), str(a.get("assigned_at") or "")))[-1]
        assignment_id = str(chosen.get("id") or "")
        batch_id = str(chosen.get("batch_id") or "")
    batch = next((b for b in payload.get("batches", []) if str(b.get("id") or "") == batch_id), None) if batch_id != "*" else None
    if batch_id != "*" and (not batch or workstation not in _batch_workstations(batch)):
        raise PermissionError("Analytical QC assignment does not match an active batch workstation")
    current_assignment = _current_test_assignment(payload, batch_id, workstation)
    if not current_assignment or str(current_assignment.get("id") or "") != assignment_id:
        raise PermissionError("Analytical QC must reference the current (not superseded) workstation assignment")
    if not _assignment_allows_user_row(current_assignment, user):
        raise PermissionError(f"Authenticated user is not assigned to the {workstation} workstation required for this analytical QC")
    row["assignment_id"] = assignment_id
    row["batch_id"] = batch_id
    row["workstation"] = workstation


def _sanitize_test_assignments(
    current: dict[str, Any], proposed: dict[str, Any], user: User,
    db: Session | None = None, site_id: int | None = None,
) -> list[dict[str, Any]]:
    new_rows = _validate_append_only(current.get("testAssignments", []), proposed.get("testAssignments", []), "test assignment")
    _require_unique_record_ids(proposed.get("testAssignments", []), "test assignment", assign_missing=True)
    if new_rows and user.role not in {Role.SENIOR_CHEMIST.value, Role.SYSTEM_ADMIN.value}:
        raise PermissionError("Only Senior Chemist / System Administrator can assign or reassign laboratory workstations")
    now = datetime.utcnow().isoformat()
    eligible_roles = {Role.LAB_TECHNICIAN.value}
    for row in new_rows:
        batch_id = str(row.get("batch_id") or "").strip()
        workstation = _canonical_workstation_name(str(row.get("workstation") or "").strip())
        row["workstation"] = workstation
        if workstation not in KNOWN_WORKSTATIONS:
            raise ValueError("Test assignment requires a recognized laboratory workstation")
        if db is not None and site_id is not None:
            configured_equipment = db.query(EquipmentAsset).filter(EquipmentAsset.site_id == site_id, EquipmentAsset.workstation == workstation, EquipmentAsset.active.is_(True)).all()
            if configured_equipment:
                now_dt = datetime.utcnow()
                usable = [e for e in configured_equipment if e.status == "IN_SERVICE" and (e.next_calibration_at is None or e.next_calibration_at >= now_dt)]
                if not usable:
                    raise ValueError(f"No in-service, calibration-valid equipment is available for {workstation}")
        scope = str(row.get("scope") or ("WORKSTATION" if batch_id == "*" else "BATCH")).strip().upper()
        if scope not in {"WORKSTATION", "BATCH"}:
            raise ValueError("Assignment scope must be WORKSTATION or BATCH")
        if scope == "WORKSTATION":
            batch_id = "*"
            batch = None
        else:
            batch = next((b for b in proposed.get("batches", []) if str(b.get("id") or "") == batch_id), None)
            if not batch:
                raise ValueError("Batch-scoped assignment requires a valid laboratory batch")
            if workstation not in _batch_workstations(batch):
                raise ValueError("Assigned workstation is not part of the selected batch test package")
        mode = str(row.get("mode") or "SINGLE").strip().upper()
        if mode not in {"SINGLE", "PRIMARY_BACKUP", "ALL"}:
            raise ValueError("Assignment mode must be SINGLE, PRIMARY_BACKUP or ALL")
        primary_id = int(row.get("primary_user_id") or 0)
        backup_id = int(row.get("backup_user_id") or 0)
        if mode == "ALL":
            primary_id = backup_id = 0
        elif not primary_id:
            raise ValueError("Single / Primary+Backup assignment requires a Primary chemist")
        if mode == "SINGLE":
            backup_id = 0
        if backup_id and backup_id == primary_id:
            raise ValueError("Primary and Backup must be different users")

        def person(uid: int) -> User | None:
            if not uid or db is None:
                return None
            candidate = db.get(User, uid)
            if not candidate or not candidate.active or candidate.role not in eligible_roles:
                raise ValueError("Assigned chemist is missing, inactive, or not eligible for laboratory testing")
            if site_id is not None and candidate.site_id != site_id:
                raise ValueError("Assigned chemist must belong to the same laboratory site")
            # Competency gate activates once Quality has configured competency records for this workstation.
            # This preserves legacy UAT data while making controlled competence mandatory for configured benches.
            if site_id is not None:
                configured = db.query(CompetencyRecord).filter(CompetencyRecord.site_id == site_id, CompetencyRecord.workstation == workstation, CompetencyRecord.active.is_(True)).count()
                if configured:
                    now_dt = datetime.utcnow()
                    qualified = db.query(CompetencyRecord).filter(
                        CompetencyRecord.site_id == site_id, CompetencyRecord.user_id == uid, CompetencyRecord.workstation == workstation,
                        CompetencyRecord.active.is_(True), CompetencyRecord.authorization.in_(["INDEPENDENT", "SUPERVISED"]),
                    ).all()
                    qualified = [r for r in qualified if r.expires_at is None or r.expires_at >= now_dt]
                    if not qualified:
                        raise ValueError(f"{candidate.full_name} is not currently competent/authorized for {workstation}")
                    if any(r.authorization == "SUPERVISED" for r in qualified) and not any(r.authorization == "INDEPENDENT" for r in qualified):
                        # Supervised staff may be Backup but not the sole Primary analytical owner.
                        if uid == primary_id and mode == "SINGLE":
                            raise ValueError(f"{candidate.full_name} is authorized only under supervision for {workstation}")
                now_dt = datetime.utcnow()
                pattern = db.query(StaffWorkPattern).filter(
                    StaffWorkPattern.site_id == site_id, StaffWorkPattern.user_id == uid, StaffWorkPattern.active.is_(True)
                ).first()
                if pattern:
                    try:
                        operating_days = {int(x) for x in json.loads(pattern.weekdays_json or "[]")}
                    except (TypeError, ValueError, json.JSONDecodeError):
                        operating_days = set()
                    in_effect = (pattern.effective_from is None or now_dt >= pattern.effective_from) and (pattern.effective_to is None or now_dt <= pattern.effective_to.replace(hour=23, minute=59, second=59))
                    if in_effect and operating_days and now_dt.weekday() not in operating_days:
                        raise ValueError(f"{candidate.full_name} is off-pattern today ({pattern.name}); choose an on-pattern available employee")
                conflict = db.query(StaffAvailability).filter(
                    StaffAvailability.site_id == site_id, StaffAvailability.user_id == uid,
                    StaffAvailability.entry_type.in_(["LEAVE", "HOLIDAY", "TRAINING", "UNAVAILABLE"]),
                    StaffAvailability.status.in_(["APPROVED", "CONFIRMED", "APPROVED_FOR_ANNUAL_PLAN"]),
                    StaffAvailability.start_at <= now_dt, StaffAvailability.end_at >= now_dt,
                ).first()
                if conflict:
                    raise ValueError(f"{candidate.full_name} is unavailable due to approved {conflict.entry_type.lower()}")
            return candidate

        primary = person(primary_id)
        backup = person(backup_id)
        previous = _latest_assignment_for_key(current, batch_id, workstation)
        # Also consider earlier new rows in the same request when multiple revisions are intentionally appended.
        staged = _latest_assignment_for_key(proposed, batch_id, workstation)
        latest_revision = max(int(previous.get("revision") or 0) if previous else 0, int(staged.get("revision") or 0) if staged and staged is not row else 0)
        row["batch_id"] = batch_id
        row["scope"] = scope
        row["mode"] = mode
        row["primary_user_id"] = primary.id if primary else None
        row["primary_name"] = primary.full_name if primary else ""
        row["backup_user_id"] = backup.id if backup else None
        row["backup_name"] = backup.full_name if backup else ""
        row["assigned_by_user_id"] = user.id
        row["assigned_by"] = user.full_name
        row["assigned_at"] = now
        row["revision"] = latest_revision + 1
        row["access_scope"] = "ALL_SITE_LAB_STAFF" if mode == "ALL" else "NAMED_USERS"
    return new_rows


def _result_test_allowed(batch: dict[str, Any], test: str) -> bool:
    requested = [row if isinstance(row, dict) else {"test": row} for row in batch.get("tests", [])]
    if any(str(row.get("test", "")) == test for row in requested):
        return True
    stations = _batch_workstations(batch)
    if "Water" in stations and (test.startswith("WATER:") or test.startswith("WATER_CALC:")):
        return True
    if "DGA" in stations and (test.startswith("DGA:") or test.startswith("DGA_CALC:")):
        return True
    if FURAN_PASSIVATOR_WORKSTATION in stations and (test.startswith("FURAN:") or test.startswith("FURAN_CALC:")):
        return True
    return False




# Server-side parity for the automatic calculations shown in the laboratory workstation UI.
# The browser presents the calculation immediately, but the server independently validates the
# stored value so a manipulated client cannot persist a forged calculated result.
_OOMMEN_CURVES: dict[int, tuple[tuple[float, float], ...]] = {
    10: ((0, 0), (6.4, 3.9), (9.6, 5.08), (16, 7), (20, 8.06), (25, 10)),
    20: ((0, 0), (10, 3.4), (20, 5.5), (30, 7.5), (40, 10)),
    30: ((0, 0), (10, 2), (20, 3.8), (30, 5), (40, 6), (50, 7.2), (60, 8.8), (65, 10)),
    40: ((0, 0), (10, 1.8), (20, 2.8), (30, 3.54), (40, 4.3), (50, 5), (60, 5.8), (70, 6.5), (80, 7.3), (90, 8.71), (97.4, 10)),
    50: ((0, 0), (10, 1.2), (20, 2), (30, 2.5), (40, 3), (50, 3.5), (60, 4), (70, 4.35), (80, 4.8), (90, 5.28), (100, 5.8)),
    60: ((0, 0), (10, 0.8), (20, 1.5), (30, 2), (40, 2.44), (50, 2.77), (60, 3), (70, 3.2), (80, 3.5), (90, 3.8), (100, 4.06)),
    70: ((0, 0), (10, 0.7), (20, 1.07), (30, 1.44), (40, 1.8), (50, 2), (60, 2.2), (70, 2.4), (80, 2.6), (90, 2.8), (100, 3)),
    80: ((0, 0), (10, 0.5), (20, 0.8), (30, 1.1), (40, 1.3), (50, 1.5), (60, 1.7), (70, 1.8), (80, 2), (90, 2.1), (100, 2.2)),
    90: ((0, 0), (10, 0.5), (20, 0.7), (30, 0.8), (40, 1), (50, 1.2), (60, 1.3), (70, 1.4), (80, 1.5), (90, 1.6), (100, 1.8)),
    100: ((0, 0), (10, 0.3), (20, 0.5), (30, 0.7), (40, 0.8), (50, 0.9), (60, 1), (70, 1.1), (80, 1.2), (90, 1.3), (100, 1.4)),
}


def _normalize_result_state(value: Any) -> str:
    """Normalize controlled non-numeric result states used by laboratory workflows.

    TSCO operational terminology uses LTD (Less Than Detection). Legacy LDT/LDL
    inputs are normalized at the application boundary so new records/reports are
    consistent while historical source documents remain untouched.
    """
    text = str(value or "").strip().upper().replace(" ", "")
    if text in {"LTD", "LDT", "LDL"}:
        return "LTD"
    return ""

# Controlled reporting thresholds confirmed from the current TSCO Analysis Report.
# LTD is the single platform spelling for "Less Than Detection".  The table is
# deliberately field-specific: tests without a confirmed laboratory DL are not
# assigned an invented threshold.
_DETECTION_LIMIT_RULES: tuple[tuple[tuple[str, ...], float, str], ...] = (
    ((r"^furan:2fal$", r"2[- ]?furfural", r"2[- ]?fal"), 0.01, "mg/kg"),
    ((r"total acid number", r"^tan$", r"^acidity$"), 0.010, "mg KOH/g"),
    ((r"^dga:h2$", r"hydrogen \(h2\)"), 1.0, "ppm"),
    ((r"^dga:ch4$", r"methane \(ch4\)"), 1.0, "ppm"),
    ((r"^dga:c2h4$", r"ethylene \(c2h4\)"), 1.0, "ppm"),
    ((r"^dga:c2h6$", r"ethane \(c2h6\)"), 1.0, "ppm"),
    ((r"^dga:c2h2$", r"acetylene \(c2h2\)"), 1.0, "ppm"),
    ((r"^dga:co$", r"carbon monoxide"), 1.0, "ppm"),
    ((r"^dga:co2$", r"carbon dioxide"), 1.0, "ppm"),
)

def _confirmed_detection_limit(test: str, display_test: str = "") -> float | None:
    label = f"{test} {display_test}".strip().lower()
    for patterns, limit, _unit in _DETECTION_LIMIT_RULES:
        if any(re.search(pattern, label, re.I) for pattern in patterns):
            return limit
    return None

def _normalize_result_for_test(test: str, display_test: str, value: Any) -> Any:
    """Canonicalize LTD and convert confirmed below-DL numeric results to LTD."""
    if _normalize_result_state(value):
        return "LTD"
    numeric = _numeric_result(value)
    limit = _confirmed_detection_limit(test, display_test)
    if limit is not None and numeric is not None and numeric < limit:
        return "LTD"
    return value


def _numeric_result(value: Any) -> float | None:
    if value is None or _normalize_result_state(value):
        return None
    text = str(value).strip().replace(',', '.')
    match = re.search(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", text)
    if not match:
        return None
    try:
        return float(match.group())
    except ValueError:
        return None


def _round_half_up_int(value: float) -> int:
    """Round a positive reporting value to the nearest integer; .5 rounds up."""
    return int(math.floor(float(value) + 0.5))


def _latest_result_matching(
    payload: dict[str, Any], sample: str, include_patterns: tuple[str, ...], exclude_patterns: tuple[str, ...] = ()
) -> dict[str, Any] | None:
    rows = [
        row for row in payload.get("results", [])
        if str(row.get("sample") or "") == sample and not bool(row.get("isRetest"))
    ]
    for row in reversed(rows):
        label = f"{row.get('test', '')} {row.get('display_test', '')}".lower()
        if not any(re.search(pattern, label) for pattern in include_patterns):
            continue
        if any(re.search(pattern, label) for pattern in exclude_patterns):
            continue
        return row
    return None


def _interpolate_oommen(points: tuple[tuple[float, float], ...], water: float) -> float:
    if water <= points[0][0]:
        return points[0][1]
    for idx in range(1, len(points)):
        x2, y2 = points[idx]
        x1, y1 = points[idx - 1]
        if water <= x2:
            return y1 + (water - x1) * (y2 - y1) / (x2 - x1)
    x2, y2 = points[-1]
    x1, y1 = points[-2]
    if y2 >= 9.99:
        return 10.0
    return min(10.0, y2 + (water - x2) * (y2 - y1) / (x2 - x1))


def _oommen_humidity(water: float, temperature: float) -> float:
    tc = max(10.0, min(100.0, temperature))
    temps = sorted(_OOMMEN_CURVES)
    low, high = temps[0], temps[-1]
    for t in temps:
        if t <= tc:
            low = t
        if t >= tc:
            high = t
            break
    a = _interpolate_oommen(_OOMMEN_CURVES[low], water)
    b = _interpolate_oommen(_OOMMEN_CURVES[high], water)
    value = a if low == high else a + (tc - low) * (b - a) / (high - low)
    return min(10.0, max(0.0, value))


def _assert_calculated_value(row: dict[str, Any], expected: float, *, decimals: int, label: str) -> None:
    actual = _numeric_result(row.get("result"))
    if actual is None:
        raise ValueError(f"{label} calculated result must be numeric")
    rounded = round(expected, decimals)
    tolerance = max(10 ** (-(decimals + 1)), abs(rounded) * 1e-7)
    if not math.isclose(actual, rounded, rel_tol=0.0, abs_tol=tolerance):
        raise PermissionError(f"{label} calculated result failed server verification")


def _validate_calculated_result(payload: dict[str, Any], batch: dict[str, Any], row: dict[str, Any]) -> None:
    if not bool(row.get("calculated")):
        return
    sample = str(row.get("sample") or "")
    test = str(row.get("test") or "")
    low = test.lower()

    if low == "furan_calc:total":
        fal = _latest_result_matching(payload, sample, (r"\bfuran:2fal\b", r"2[- ]?furfural", r"2[- ]?fal"))
        source = fal.get("result") if fal else None
        if _normalize_result_state(source) == "LTD":
            if _normalize_result_state(row.get("result")) != "LTD":
                raise PermissionError("Total Furanic Compounds for LTD 2-FAL must be reported as LTD")
            row["result"] = "LTD"
            return
        raise PermissionError("Automatic Total Furanic Compounds is only fixed when 2-FAL is LTD; numeric total requires the controlled component calculation")

    if low == "furan_calc:indirect_dp":
        fal = _latest_result_matching(payload, sample, (r"\bfuran:2fal\b", r"2[- ]?furfural", r"2[- ]?fal"))
        source = fal.get("result") if fal else None
        if _normalize_result_state(source) == "LTD":
            if str(row.get("result") or "").strip() != ">1000":
                raise PermissionError("Indirect DP for LTD 2-FAL must be reported as >1000")
            return
        value = _numeric_result(source)
        if value is None or value <= 0:
            raise PermissionError("Indirect DP requires a valid 2-FAL source result")
        _assert_calculated_value(row, (1.5655 - math.log10(value)) / 0.0035, decimals=2, label="Indirect DP")
        return

    if low == "furan_calc:paper_life":
        fal = _latest_result_matching(payload, sample, (r"\bfuran:2fal\b", r"2[- ]?furfural", r"2[- ]?fal"))
        source = fal.get("result") if fal else None
        if _normalize_result_state(source) == "LTD":
            if str(row.get("result") or "").strip() != ">30":
                raise PermissionError("Paper Life for LTD 2-FAL must be reported as >30")
            return
        value = _numeric_result(source)
        if value is None or value <= 0:
            raise PermissionError("Paper Life calculation requires a valid 2-FAL source result")
        dp = (1.5655 - math.log10(value)) / 0.0035
        expected_years = _round_half_up_int(((dp / 1000.0) * 30.0) - 1.0)
        _assert_calculated_value(row, float(expected_years), decimals=0, label="Paper Life")
        return

    if low.startswith("water_calc:"):
        water = _latest_result_matching(payload, sample, (r"\bwater:kf_rt\b", r"water content kf", r"water content(?!.*20)"), (r"humidity", r"relative saturation"))
        temp = _latest_result_matching(payload, sample, (r"\bwater:temp\b", r"transformer oil temperature"))
        water_value = _numeric_result(water.get("result")) if water else None
        temp_value = _numeric_result(temp.get("result")) if temp else None
        if temp_value is None:
            meta = (batch.get("sample_meta") or {}).get(sample) or {}
            temp_value = _numeric_result(meta.get("temp"))
        if water_value is None or temp_value is None:
            raise PermissionError("Water calculations require Water @RT and transformer oil temperature")
        log_cw = (-1567.0 / (temp_value + 273.0)) + 7.0895
        cw = 10.0 ** log_cw
        expectations = {
            "water_calc:log_cw": (log_cw, 6, "Mineral Oil Log Cw"),
            "water_calc:cw": (cw, 3, "Cw"),
            "water_calc:at20": (water_value * 2.24 * math.exp(-0.04 * temp_value), 2, "Water @20°C"),
            "water_calc:rel_sat": (water_value * 100.0 / cw, 2, "Relative Saturation"),
            "water_calc:humidity": (_oommen_humidity(water_value, temp_value), 2, "Humidity in Cellulose"),
        }
        if low not in expectations:
            raise PermissionError("Unknown automatic Water calculation code")
        expected, decimals, label = expectations[low]
        _assert_calculated_value(row, expected, decimals=decimals, label=label)
        return

    if re.search(r"oil quality index|oqin", low):
        tan = _latest_result_matching(payload, sample, (r"total acid number", r"\btan\b", r"^acidity"), (r"oxidation", r"72h", r"164h", r"500h", r"rsh", r"mercaptan"))
        ift = _latest_result_matching(payload, sample, (r"interfacial tension", r"interfaical tension", r"\bift\b"))
        iv = _numeric_result(ift.get("result")) if ift else None
        if iv is None or not tan:
            raise PermissionError("Oil Quality Index requires IFT and TAN source results")
        tan_text = str(tan.get("result") or "").strip().upper()
        if _normalize_result_state(tan_text) == "LTD" or "<0.01" in tan_text:
            expected = iv / 0.01
            actual_text = str(row.get("result") or "").strip()
            actual = _numeric_result(actual_text)
            if not actual_text.startswith(">") or actual is None or not math.isclose(actual, round(expected), rel_tol=0.0, abs_tol=0.51):
                raise PermissionError("Oil Quality Index calculated result failed server verification")
            return
        tv = _numeric_result(tan.get("result"))
        if tv is None or tv <= 0:
            raise PermissionError("Oil Quality Index requires a positive TAN source result")
        _assert_calculated_value(row, iv / tv, decimals=2, label="Oil Quality Index")
        return

    raise PermissionError("Unsupported client-calculated result code")

def _sanitize_new_results(current: dict[str, Any], proposed: dict[str, Any], user: User) -> None:
    new_rows = _validate_append_only(current.get("results", []), proposed.get("results", []), "result")
    _require_unique_record_ids(proposed.get("results", []), "result")
    old_by_id = {str(row.get("id")): row for row in current.get("results", []) if row.get("id") is not None}
    now = datetime.utcnow().isoformat()
    for row in new_rows:
        sample = str(row.get("sample") or "").strip()
        test = str(row.get("test") or "").strip()
        if not sample or not test or row.get("result") in {None, ""}:
            raise ValueError("A new result requires sample, test and result")
        row["result"] = _normalize_result_for_test(test, str(row.get("display_test") or ""), row.get("result"))
        batch = _batch_for_sample(proposed, sample)
        if not batch:
            raise PermissionError("A laboratory result must belong to a current batch sample")
        batch_ref = str(row.get("batch") or row.get("batch_id") or "").strip()
        if batch_ref and batch_ref != str(batch.get("id") or ""):
            raise PermissionError("Result batch reference does not match the sample batch")
        if not _result_test_allowed(batch, test):
            raise PermissionError("Result test is not part of the sample's controlled test package")
        if not _assignment_allows_user(proposed, batch, test, user):
            raise PermissionError(f"Authenticated user is not assigned to the {_workstation_for_test(batch, test)} workstation for this batch")

        _validate_calculated_result(proposed, batch, row)

        prior = [r for r in current.get("results", []) if str(r.get("sample")) == sample and str(r.get("test")) == test]
        revision_of = str(row.get("revision_of") or "").strip()
        is_retest = bool(row.get("isRetest"))
        if prior and not is_retest:
            if not revision_of:
                raise PermissionError("A repeated result must be appended as an explicit revision")
            previous = old_by_id.get(revision_of)
            if not previous or str(previous.get("sample")) != sample or str(previous.get("test")) != test:
                raise PermissionError("Result revision_of must reference the prior result for the same sample and test")
        elif revision_of:
            previous = old_by_id.get(revision_of)
            if not previous or str(previous.get("sample")) != sample or str(previous.get("test")) != test:
                raise PermissionError("Invalid result revision reference")

        if is_retest:
            retest_id = str(row.get("retest_id") or "").strip()
            request = next((r for r in proposed.get("retests", []) if str(r.get("id")) == retest_id), None)
            if not request or str(request.get("sample")) != sample or str(request.get("test")) != test:
                raise PermissionError("Retest result must reference its controlled retest request")

        # The actor/timestamp are evidence fields and are always server-owned.
        row["analyst"] = user.full_name
        row["ts"] = now
        row["recorded_by_user_id"] = user.id


def _sanitize_new_qc(current: dict[str, Any], proposed: dict[str, Any], user: User) -> None:
    new_rows = _validate_append_only(current.get("qc", []), proposed.get("qc", []), "QC")
    _require_unique_record_ids(proposed.get("qc", []), "QC")
    now = datetime.utcnow().isoformat()
    for row in new_rows:
        if not str(row.get("test") or "").strip():
            raise ValueError("A new QC record requires a test/group")
        if str(row.get("mode") or "routine").lower() == "qualify":
            if user.role not in {Role.QUALITY.value, Role.SYSTEM_ADMIN.value}:
                raise PermissionError("Only Quality / System Administrator can qualify an Analytical QC profile")
            row["analyst"] = user.full_name
            row["ts"] = now
            row["recorded_by_user_id"] = user.id
            continue
        _validate_analytical_qc_assignment(proposed, row, user)
        row["analyst"] = user.full_name
        row["ts"] = now
        row["recorded_by_user_id"] = user.id

    new_profiles = _validate_append_only(current.get("qualifiedQcProfiles", []), proposed.get("qualifiedQcProfiles", []), "qualified QC profile")
    _require_unique_record_ids(proposed.get("qualifiedQcProfiles", []), "qualified QC profile")
    for row in new_profiles:
        if user.role not in {Role.QUALITY.value, Role.SYSTEM_ADMIN.value}:
            raise PermissionError("Only Quality / System Administrator can qualify a new QC profile")
        row["qualified_by"] = user.full_name
        row["qualified_at"] = now
        row["qualified_by_user_id"] = user.id

def _sanitize_technical_history(current: dict[str, Any], proposed: dict[str, Any], user: User) -> None:
    now = datetime.utcnow().isoformat()
    for key, label in (("batchHistory", "batch history"), ("cancelledSamples", "cancelled sample"), ("supervisorNotes", "technical note")):
        new_rows = _validate_append_only(current.get(key, []), proposed.get(key, []), label)
        _require_unique_record_ids(proposed.get(key, []), label, assign_missing=True)
        for row in new_rows:
            row["by"] = user.full_name
            row["ts"] = now
            row["actor_user_id"] = user.id


def _sanitize_qc_materials(current: dict[str, Any], proposed: dict[str, Any], user: User) -> None:
    new_rows = _validate_append_only(current.get("standards", []), proposed.get("standards", []), "QC material")
    _require_unique_record_ids(proposed.get("standards", []), "QC material")
    now = datetime.utcnow().isoformat()
    for row in new_rows:
        row["created_by"] = user.full_name
        row["created_at"] = now
        row["created_by_user_id"] = user.id


def _sanitize_quality_task_events(current: dict[str, Any], proposed: dict[str, Any], user: User) -> None:
    new_rows = _validate_append_only(
        current.get("qualityTaskEvents", []), proposed.get("qualityTaskEvents", []), "quality routine check"
    )
    _require_unique_record_ids(proposed.get("qualityTaskEvents", []), "quality routine check")
    distributions = {str(row.get("id")): row for row in current.get("qualityDistributions", []) if isinstance(row, dict)}
    now = datetime.utcnow().isoformat()
    allowed_status = {"PASS", "ATTENTION", "FAIL"}
    for row in new_rows:
        distribution = distributions.get(str(row.get("distribution_id") or ""))
        if not distribution:
            raise PermissionError("Quality routine check must reference a server-published monthly distribution")
        assignment_id = str(row.get("assignment_id") or "")
        assignment = next(
            (item for item in distribution.get("assignments", []) if str(item.get("id")) == assignment_id), None
        )
        if not assignment:
            raise PermissionError("Quality routine check assignment is not part of the published distribution")
        if user.role != Role.SYSTEM_ADMIN.value:
            assigned_ids = {assignment.get("primary_user_id"), assignment.get("backup_user_id")}
            if user.id not in assigned_ids:
                raise PermissionError("Only the assigned Primary or Backup chemist can complete this quality check")
        status = str(row.get("status") or "").strip().upper()
        if status not in allowed_status:
            raise ValueError("Quality routine check status must be PASS, ATTENTION or FAIL")
        note = str(row.get("note") or "").strip()
        if status in {"ATTENTION", "FAIL"} and not note:
            raise ValueError("A note is required for ATTENTION or FAIL quality checks")
        row["status"] = status
        row["task"] = assignment.get("task")
        row["task_key"] = assignment.get("task_key")
        row["domain"] = assignment.get("domain")
        row["period"] = assignment.get("period")
        row["period_label"] = assignment.get("period_label")
        row["completed_by"] = user.full_name
        row["completed_by_user_id"] = user.id
        row["completed_at"] = now


def _validate_batch_integrity(current: dict[str, Any], proposed: dict[str, Any]) -> None:
    """Keep platform-imported sample/batch identity under central server control.

    The browser JSON store is not allowed to mint new samples/batches or rewrite a centrally
    registered sample into another batch. Older non-platform batches remain readable and may be
    maintained by the existing Senior Chemist/Admin role gate for backward compatibility.
    """
    old_rows = current.get("batches", [])
    new_rows = proposed.get("batches", [])
    if not isinstance(old_rows, list) or not isinstance(new_rows, list):
        raise ValueError("batches must be a list")
    if any(not isinstance(row, dict) for row in old_rows + new_rows):
        raise ValueError("Every batch record must be an object")
    _require_unique_record_ids(new_rows, "batch")
    old_by_id = {str(row.get("id")): row for row in old_rows if row.get("id") is not None}
    new_by_id = {str(row.get("id")): row for row in new_rows if row.get("id") is not None}
    if set(old_by_id) - set(new_by_id):
        raise PermissionError("Existing laboratory batches cannot be deleted from the browser")
    added = set(new_by_id) - set(old_by_id)
    if added:
        raise PermissionError("New laboratory samples/batches must originate from central registration/LMS workflow")
    for bid, old in old_by_id.items():
        if old.get("platform_sample_id") and not _same(old, new_by_id[bid]):
            raise PermissionError("Centrally registered laboratory batch identity/details are read-only in the browser")


def _result_exists(payload: dict[str, Any], sample: str, test: str) -> bool:
    return any(str(r.get("sample", "")) == sample and str(r.get("test", "")) == test for r in payload.get("results", []))


def _test_complete(payload: dict[str, Any], sample: str, test_row: dict[str, Any]) -> bool:
    test = str(test_row.get("test", ""))
    station = _station_from_name(test)
    low = test.lower()
    if station == "DGA":
        components = ("H2", "O2", "N2", "CH4", "CO", "CO2", "C2H4", "C2H6", "C2H2")
        return all(_result_exists(payload, sample, f"DGA:{key}") for key in components)
    if station == FURAN_PASSIVATOR_WORKSTATION:
        if "indirect dp" in low:
            return _result_exists(payload, sample, "FURAN_CALC:INDIRECT_DP") or _result_exists(payload, sample, test)
        if "paper lifetime" in low:
            return _result_exists(payload, sample, "FURAN_CALC:PAPER_LIFE") or _result_exists(payload, sample, test)
        if any(x in low for x in ("2-furfural", "2fal", "2-fal", "furanic compounds")):
            return _result_exists(payload, sample, "FURAN:2FAL") or _result_exists(payload, sample, test)
        # Passivator and Direct DP are independent measured results.
        return _result_exists(payload, sample, test)
    if station == "Water":
        if "humidity" in low:
            return _result_exists(payload, sample, "WATER_CALC:HUMIDITY")
        if "@20" in low or "20 °c" in low or "20°c" in low:
            return _result_exists(payload, sample, "WATER_CALC:AT20")
        if "transformer oil temperature" in low:
            return _result_exists(payload, sample, "WATER:TEMP")
        return _result_exists(payload, sample, "WATER:KF_RT") and _result_exists(payload, sample, "WATER:TEMP")
    return _result_exists(payload, sample, test)


def _sample_complete(payload: dict[str, Any], sample: str) -> bool:
    batch = next((b for b in payload.get("batches", []) if sample in b.get("samples", [])), None)
    if not batch:
        return False
    tests = batch.get("tests", [])
    return bool(tests) and all(_test_complete(payload, sample, row if isinstance(row, dict) else {"test": row}) for row in tests)


def _sample_qc_failed(payload: dict[str, Any], sample: str) -> bool:
    return any(str(r.get("sample", "")) == sample and str(r.get("qc_status", "")).upper() == "FAIL" for r in payload.get("results", []))


def _sample_pending_retest(payload: dict[str, Any], sample: str) -> bool:
    return any(
        str(row.get("sample", "")) == sample and str(row.get("status", "Requested")).upper() != "COMPLETED"
        for row in payload.get("retests", []) if isinstance(row, dict)
    )


def platform_sample_lab_readiness(db: Session, sample: SampleRequest) -> tuple[bool, str]:
    """Return whether a platform sample can enter/complete technical approval.

    The laboratory OperationsState remains the current analytical source of truth. A centrally
    registered sample is ready only when every controlled package test is complete, no linked
    result carries QC=FAIL, and no controlled retest request remains open.
    """
    site = db.get(Site, sample.site_id)
    if not site:
        return False, "Laboratory site is unavailable"
    _, payload = get_operations_state(db, site)
    batch = next((
        row for row in payload.get("batches", [])
        if isinstance(row, dict) and (
            str(row.get("platform_sample_id") or "") == str(sample.id)
            or str(sample.id) in {str(x) for x in row.get("platform_sample_ids", [])}
        )
    ), None)
    if not batch:
        return False, "Sample is not registered in Laboratory Operations"
    candidate_keys = {sample.request_number.upper()}
    if sample.lms_number:
        candidate_keys.add(sample.lms_number.upper())
    sample_key = next((str(key) for key in batch.get("samples", []) if str(key).upper() in candidate_keys), None)
    if not sample_key:
        return False, "Laboratory batch identity does not match the platform sample"
    if not _sample_complete(payload, sample_key):
        return False, "All required laboratory tests must be complete before technical review/approval"
    if _sample_qc_failed(payload, sample_key):
        return False, "Technical review/approval is blocked while linked QC status is FAIL"
    if _sample_pending_retest(payload, sample_key):
        return False, "Technical review/approval is blocked while a controlled retest is pending"
    return True, ""


def _sanitize_retests(current: dict[str, Any], proposed: dict[str, Any], user: User) -> None:
    old_rows = current.get("retests", [])
    new_rows = proposed.get("retests", [])
    if not isinstance(old_rows, list) or not isinstance(new_rows, list):
        raise ValueError("retests must be a list")
    if any(not isinstance(row, dict) for row in old_rows + new_rows):
        raise ValueError("Every retest record must be an object")
    _require_unique_record_ids(new_rows, "retest")
    old_by_id = {str(row.get("id")): row for row in old_rows if row.get("id") is not None}
    new_by_id = {str(row.get("id")): row for row in new_rows if row.get("id") is not None}
    if set(old_by_id) - set(new_by_id):
        raise PermissionError("Retest requests cannot be deleted")
    request_roles = {Role.SENIOR_CHEMIST.value, Role.SYSTEM_ADMIN.value}
    result_roles = {Role.LAB_TECHNICIAN.value}
    for rid, old in old_by_id.items():
        new = new_by_id[rid]
        immutable = {"id", "sample", "batch", "test", "requested_by", "reason", "requested_at"}
        if any(not _same(old.get(k), new.get(k)) for k in immutable):
            raise PermissionError("Retest request identity/history cannot be rewritten")
        if _same(old, new):
            continue
        if user.role not in result_roles:
            raise PermissionError("This role cannot complete a retest")
        if str(old.get("status", "Requested")) != "Requested" or str(new.get("status")) != "Completed":
            raise PermissionError("Only Requested → Completed retest transition is permitted")
        linked_result = next((
            r for r in proposed.get("results", [])
            if bool(r.get("isRetest")) and str(r.get("retest_id") or "") == rid
            and str(r.get("sample") or "") == str(old.get("sample") or "")
            and str(r.get("test") or "") == str(old.get("test") or "")
        ), None)
        if not linked_result:
            raise PermissionError("A retest cannot be completed without its linked retest result")
        new["completed_by"] = user.full_name
        new["completed_at"] = datetime.utcnow().isoformat()
    for row in new_rows:
        rid = str(row.get("id")) if row.get("id") is not None else ""
        if rid not in old_by_id:
            if user.role not in request_roles:
                raise PermissionError("Only Technical Supervision can request retests")
            sample = str(row.get("sample") or "").strip()
            test = str(row.get("test") or "").strip()
            reason = str(row.get("reason") or "").strip()
            if not sample or not test or not reason:
                raise ValueError("A retest request requires sample, test and reason")
            batch = _batch_for_sample(proposed, sample)
            if not batch:
                raise PermissionError("Retest request must reference a current laboratory batch sample")
            if str(row.get("batch") or "").strip() != str(batch.get("id") or ""):
                raise PermissionError("Retest request batch does not match the sample batch")
            if not _result_test_allowed(batch, test):
                raise PermissionError("Retest request test is not part of the sample's controlled test package")
            if not any(str(r.get("sample") or "") == sample and str(r.get("test") or "") == test for r in current.get("results", [])):
                raise PermissionError("Retest request requires an existing original result")
            row["requested_by"] = user.full_name
            row["requested_at"] = datetime.utcnow().isoformat()
            row["status"] = "Requested"


def _linked_platform_sample(db: Session | None, site_id: int | None, payload: dict[str, Any], sample_key: str) -> SampleRequest | None:
    if db is None or site_id is None:
        return None
    batch = next((b for b in payload.get("batches", []) if sample_key in [str(x) for x in b.get("samples", [])]), None)
    if not batch:
        return None
    sample = db.scalar(
        select(SampleRequest).where(
            SampleRequest.site_id == site_id,
            or_(SampleRequest.request_number == sample_key, SampleRequest.lms_number == sample_key),
        )
    )
    return sample


def _sanitize_reports(
    current: dict[str, Any], proposed: dict[str, Any], user: User,
    db: Session | None = None, site_id: int | None = None,
) -> None:
    old_rows = current.get("reports", [])
    new_rows = proposed.get("reports", [])
    if not isinstance(old_rows, list) or not isinstance(new_rows, list):
        raise ValueError("reports must be a list")
    if any(not isinstance(row, dict) for row in old_rows + new_rows):
        raise ValueError("Every report record must be an object")
    report_samples = [str(row.get("sample") or "").strip() for row in new_rows]
    if any(not sample for sample in report_samples):
        raise ValueError("Every report record requires a sample")
    if len(report_samples) != len(set(report_samples)):
        raise PermissionError("Only one LMS-submission approval record is permitted per sample")
    if user.role not in {Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value}:
        if not _same(old_rows, new_rows):
            raise PermissionError("Approval for LMS submission/revision requires Technical Manager authorization")
        return
    old_by_sample = {str(row.get("sample")): row for row in old_rows if row.get("sample") is not None}
    new_by_sample = {str(row.get("sample")): row for row in new_rows if row.get("sample") is not None}
    if set(old_by_sample) - set(new_by_sample):
        raise PermissionError("LMS-submission approval records cannot be deleted")
    now = datetime.utcnow().isoformat()
    for sample, new in new_by_sample.items():
        old = old_by_sample.get(sample)
        if old is not None and _same(old, new):
            continue
        platform_sample = _linked_platform_sample(db, site_id, proposed, sample)
        if not platform_sample:
            raise PermissionError("LMS submission approval requires a centrally registered platform sample")
        if old is None and platform_sample.status != SampleStatus.REPORT_APPROVED.value:
            raise PermissionError("LMS submission approval requires completed Senior Chemist technical approval")
        if old is not None and platform_sample.status not in {SampleStatus.REPORT_APPROVED.value, SampleStatus.READY_FOR_LMS.value}:
            raise PermissionError("Submission revision is not permitted before technical approval/LMS submission approval")
        if old is None:
            if str(new.get("status", "")) != "Ready for LMS":
                raise ValueError("A new report record must represent controlled approval for LMS submission")
            if not _sample_complete(proposed, sample):
                raise PermissionError("Cannot approve LMS submission before all required tests are complete")
            if _sample_qc_failed(proposed, sample):
                raise PermissionError("Cannot approve LMS submission while linked QC status is FAIL")
            if _sample_pending_retest(proposed, sample):
                raise PermissionError("Cannot approve LMS submission while a controlled retest is pending")
            new["revision"] = 0
            new["approved_for_lms_by"] = user.full_name
            new["approved_for_lms_at"] = now
            continue
        if str(old.get("sample")) != str(new.get("sample")):
            raise PermissionError("Report sample identity cannot be changed")
        if str(old.get("status", "")) == "Ready for LMS" and str(new.get("status", "")) != "Ready for LMS":
            raise PermissionError("An LMS-ready report cannot be reverted from Ready for LMS status")
        old_rev = int(old.get("revision") or 0)
        new_rev = int(new.get("revision") or 0)
        if new_rev not in {old_rev, old_rev + 1}:
            raise PermissionError("Report revisions must advance one revision at a time")
        if not _sample_complete(proposed, sample):
            raise PermissionError("Cannot approve/revise LMS submission before all required tests are complete")
        if _sample_qc_failed(proposed, sample):
            raise PermissionError("Cannot approve/revise LMS submission while linked QC status is FAIL")
        if _sample_pending_retest(proposed, sample):
            raise PermissionError("Cannot approve/revise LMS submission while a controlled retest is pending")
        new["approved_for_lms_by"] = old.get("approved_for_lms_by") or user.full_name
        new["approved_for_lms_at"] = old.get("approved_for_lms_at") or now
        if new_rev == old_rev + 1:
            new["last_revision_by"] = user.full_name
            new["last_revision_at"] = now


def validate_operations_update(
    current: dict[str, Any], proposed: dict[str, Any], user: User,
    db: Session | None = None, site_id: int | None = None,
) -> dict[str, Any]:
    """Validate/sanitize a browser-originated OperationsState update.

    PostgreSQL/server state is authoritative. Historical result/QC records are append-only,
    approval for LMS submission is Technical Manager controlled, and browser-side master data is read-only.
    """
    if not isinstance(proposed, dict) or not isinstance(proposed.get("batches"), list):
        raise ValueError("Invalid operations database")
    unknown = set(proposed) - set(current)
    if unknown:
        raise PermissionError("Unknown browser database fields are not accepted: " + ", ".join(sorted(unknown)))

    # These entities are administered centrally through PostgreSQL/Admin, never by this browser JSON store.
    _require_unchanged(current, proposed, {
        "clients", "customPackages", "formulaDefinitions", "staff", "samplePoints", "testUnits"
    })

    role = user.role
    result_roles = {Role.LAB_TECHNICIAN.value}
    qc_roles = {Role.LAB_TECHNICIAN.value, Role.QUALITY.value, Role.SYSTEM_ADMIN.value}
    qc_profile_roles = {Role.QUALITY.value, Role.SYSTEM_ADMIN.value}
    batch_roles = {Role.SYSTEM_ADMIN.value}
    technical_roles = {Role.SENIOR_CHEMIST.value, Role.SYSTEM_ADMIN.value}

    _sanitize_test_assignments(current, proposed, user, db=db, site_id=site_id)

    if role not in result_roles and not _same(current.get("results"), proposed.get("results")):
        raise PermissionError("This role cannot enter laboratory results")
    _sanitize_new_results(current, proposed, user)

    if role not in qc_roles and not _same(current.get("qc"), proposed.get("qc")):
        raise PermissionError("This role cannot record Analytical / Test QC")
    if role not in qc_profile_roles and not _same(current.get("qualifiedQcProfiles"), proposed.get("qualifiedQcProfiles")):
        raise PermissionError("Only Quality can qualify a new QC profile")
    _sanitize_new_qc(current, proposed, user)

    if role not in batch_roles and not _same(current.get("batches"), proposed.get("batches")):
        raise PermissionError("Operational sample batching is controlled by Sample Intake & Distribution; Laboratory batch structure is not editable here")
    _validate_batch_integrity(current, proposed)
    if role not in technical_roles:
        for key in ("batchHistory", "cancelledSamples", "supervisorNotes"):
            if not _same(current.get(key), proposed.get(key)):
                raise PermissionError("Technical supervision history is not editable by this role")
    _sanitize_technical_history(current, proposed, user)

    _sanitize_retests(current, proposed, user)
    _sanitize_reports(current, proposed, user, db=db, site_id=site_id)

    # Retention/disposal is a controlled action, not a general page edit.
    if role not in {Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value}:
        for key in ("retained", "storageAssignments"):
            if not _same(current.get(key), proposed.get(key)):
                raise PermissionError("Retained sample operations require Senior Chemist / Technical Manager authorization")

    # QC material standards are controlled by Quality/Admin; records are append-only.
    if role not in {Role.QUALITY.value, Role.SYSTEM_ADMIN.value}:
        if not _same(current.get("standards"), proposed.get("standards")):
            raise PermissionError("This role cannot change QC material records")
    _sanitize_qc_materials(current, proposed, user)

    # Monthly Quality Distribution is generated/published by the server and cannot be rewritten in the browser.
    if not _same(current.get("qualityDistributions"), proposed.get("qualityDistributions")):
        raise PermissionError("Monthly Quality Distribution is server-controlled and read-only")
    quality_event_roles = {Role.LAB_TECHNICIAN.value, Role.SYSTEM_ADMIN.value}
    if role not in quality_event_roles and not _same(current.get("qualityTaskEvents"), proposed.get("qualityTaskEvents")):
        raise PermissionError("Only an assigned laboratory chemist can complete routine quality checks")
    _sanitize_quality_task_events(current, proposed, user)

    # Settings are not a second master-data source. Only QC profile selections may be changed here.
    old_settings = dict(current.get("settings") or {})
    new_settings = dict(proposed.get("settings") or {})
    old_qc = old_settings.pop("qcProfileSelections", {})
    new_qc = new_settings.pop("qcProfileSelections", {})
    if not _same(old_settings, new_settings):
        raise PermissionError("Laboratory configuration is read-only here; use central administration")
    if not _same(old_qc, new_qc) and role not in {Role.QUALITY.value, Role.SYSTEM_ADMIN.value}:
        raise PermissionError("Only Quality can select QC profiles")

    # Browser-only drafts may be mirrored only by roles that can enter results.
    for key in ("drafts", "calculationDrafts", "dgaAttachments"):
        if role not in result_roles and not _same(current.get(key), proposed.get(key)):
            raise PermissionError("This role cannot change laboratory working drafts")

    proposed["meta"] = dict(current.get("meta") or {})
    return proposed


def save_operations_state(db: Session, state: OperationsState, payload: dict[str, Any], actor: User | None = None) -> None:
    # The persisted revision is server-owned. Never trust a client-side meta.revision.
    next_revision = int(state.revision or 0) + 1
    payload.setdefault("meta", {})
    payload["meta"]["revision"] = next_revision
    payload["meta"]["updatedAt"] = datetime.utcnow().isoformat()
    payload["meta"]["platformIntegrated"] = True
    state.json_data = json.dumps(payload, ensure_ascii=False)
    state.revision = next_revision
    state.updated_by_id = actor.id if actor else None
    state.updated_at = datetime.utcnow()


def _select_package(db: Session, sample: SampleRequest) -> dict[str, Any]:
    packages = package_catalog(db, sample.site_id)
    wanted = (sample.requested_package or "Routine Test").strip().lower()
    aliases = {
        "sec package": "sec routine",
        "aramco package": "aramco routine",
        "gpel package": "gpel package",
        "routine": "routine test",
        "full": "full test",
    }
    wanted = aliases.get(wanted, wanted)
    for package in packages:
        if package.get("name", "").strip().lower() == wanted:
            return package
    for package in packages:
        if wanted in package.get("name", "").strip().lower():
            return package
    return next((p for p in packages if p.get("name") == "Routine Test"), {"id": "GEN_ROUTINE", "name": "Routine Test", "tests": []})


def _storage_slots() -> list[dict[str, Any]]:
    rows = [4, 4, 4, 4, 2]
    out: list[dict[str, Any]] = []
    cabinet = 1
    for row_index, cabinet_count in enumerate(rows, start=1):
        cabinets = list(range(cabinet, cabinet + cabinet_count))
        cabinet += cabinet_count
        for shelf in ["A", "B", "C", "D", "E", "F"]:
            for cab in cabinets:
                for slot in range(1, 11):
                    out.append({"row": row_index, "cabinet": cab, "shelf": shelf, "slot": slot})
    return out


def _storage_code(slot: dict[str, Any]) -> str:
    return f"R{slot['row']}-C{int(slot['cabinet']):02d}-{slot['shelf']}-{int(slot['slot']):02d}"


def _reserve_retained_storage(payload: dict[str, Any], sample_key: str) -> dict[str, Any]:
    assignments = payload.setdefault("storageAssignments", [])
    existing = next((row for row in assignments if str(row.get("sample")) == sample_key), None)
    if existing:
        return existing
    used = {_storage_code(row) for row in assignments if row.get("status") != "Released" and all(k in row for k in ("row", "cabinet", "shelf", "slot"))}
    slot = next((candidate for candidate in _storage_slots() if _storage_code(candidate) not in used), None)
    if slot is None:
        raise ValueError("Retained Sample Storage is full")
    assignment = {
        "sample": sample_key, **slot, "code": _storage_code(slot),
        "status": "Reserved", "assigned_at": datetime.utcnow().isoformat(),
    }
    assignments.append(assignment)
    return assignment


def activate_retention_after_lms(
    db: Session, sample: SampleRequest, actor: User | None = None, *, report_reference: str = ""
) -> None:
    """Activate the retained-sample clock after the official LMS report is issued.

    Storage is reserved at intake distribution. The configured retention period starts only
    after the LMS release boundary, keeping Senior Chemist operations and Quality oversight
    aligned with the official report lifecycle.
    """
    site = sample.site
    state, payload = get_operations_state(db, site)
    sample_key = (sample.lms_number or sample.request_number).upper()
    assignment = _reserve_retained_storage(payload, sample_key)
    assignment["status"] = "Active"
    assignment["retained_at"] = assignment.get("retained_at") or datetime.utcnow().isoformat()
    settings = payload.get("settings") or {}
    batch = _batch_for_sample(payload, sample_key) or {}
    priority = str(batch.get("priority") or "Normal").lower()
    days = int(settings.get("urgentRetentionDays" if priority == "urgent" else "normalRetentionDays") or 15)
    from datetime import timedelta
    due = (datetime.utcnow() + timedelta(days=days)).date().isoformat()
    assignment["due_date"] = due
    retained = payload.setdefault("retained", [])
    record = next((row for row in retained if str(row.get("sample")) == sample_key), None)
    values = {
        "sample": sample_key, "priority": batch.get("priority") or "Normal",
        "retained_at": assignment["retained_at"], "due_date": due,
        "room": f"Row {assignment['row']}", "rack": f"Cabinet {int(assignment['cabinet']):02d}",
        "shelf": assignment["shelf"], "position": f"{int(assignment['slot']):02d}",
        "storage_code": assignment["code"], "status": "Retained",
        "trigger": "LMS_OFFICIAL_REPORT", "report_reference": report_reference,
    }
    if record is None:
        retained.append(values)
    else:
        record.update(values)
    save_operations_state(db, state, payload, actor)


def sync_sample_to_operations(db: Session, sample: SampleRequest, actor: User | None = None, phase: str = "REGISTERED") -> None:
    site = sample.site
    state, payload = get_operations_state(db, site)
    sample_key = (sample.lms_number or sample.request_number).upper()
    existing = next((batch for batch in payload.get("batches", []) if sample_key in batch.get("samples", [])), None)
    package = _select_package(db, sample)
    client_entry = {"id": str(sample.client.id), "code": sample.client.code, "name": sample.client.name, "active": True}
    clients = payload.setdefault("clients", [])
    if not any(str(item.get("id")) == client_entry["id"] or item.get("code") == client_entry["code"] for item in clients):
        clients.append(client_entry)
    room_temp = "" if sample.ambient_temperature_c is None else str(sample.ambient_temperature_c)
    room_humidity = "" if sample.ambient_humidity_pct is None else str(sample.ambient_humidity_pct)
    oil_temp = "" if sample.oil_temperature_c is None else str(sample.oil_temperature_c)
    metadata = {
        "point": sample.sampling_point,
        "temp": oil_temp,
        "roomTemp": room_temp,
        "roomHumidity": room_humidity,
        "portalRequest": sample.request_number,
        "lmsNumber": sample.lms_number or "",
        "assetCode": sample.asset.asset_code,
        "serialNumber": sample.asset.serial_number,
        "stationName": sample.asset.station_name,
        "exactLocation": sample.asset.asset_location_label,
        "quotation": sample.quotation.number if sample.quotation else "",
        "purchaseOrder": sample.purchase_order.number if sample.purchase_order else "",
        "barcode": sample.barcode_value,
        "sourceChannel": sample.submission_channel,
    }
    status_map = {"REGISTERED": "Waiting Receipt", "RECEIVED": "Received", "READY_FOR_LAB": "Ready for Testing", "TESTING": "Testing", "TECHNICAL_REVIEW": "Technical Review"}
    if existing:
        existing["status"] = status_map.get(phase, existing.get("status", "Received"))
        existing.setdefault("sample_meta", {})[sample_key] = metadata
        existing["roomTemp"] = room_temp
        existing["roomHumidity"] = room_humidity
        existing["platform_updated_at"] = datetime.utcnow().isoformat()
    else:
        batch = {
            "id": f"PLATFORM-{sample.id}",
            "template": package.get("name", sample.requested_package),
            "package_id": package.get("id", "PLATFORM"),
            "client_id": str(sample.client.id), "client_name": sample.client.name, "client_code": sample.client.code,
            "priority": sample.sampling_assignment.order.priority if sample.sampling_assignment else "Normal",
            "site": site.code, "samples": [sample_key], "sample_meta": {sample_key: metadata},
            "roomTemp": room_temp, "roomHumidity": room_humidity,
            "note": f"Imported from platform {sample.request_number}. LMS: {sample.lms_number or 'pending'}",
            "tests": package.get("tests", []), "status": status_map.get(phase, "Waiting Receipt"),
            "created_at": datetime.utcnow().isoformat(), "platform_sample_id": sample.id,
        }
        payload.setdefault("batches", []).append(batch)
        _reserve_retained_storage(payload, sample_key)
        payload.setdefault("batchHistory", []).insert(0, {
            "id": f"BH-PLATFORM-{sample.id}", "action": "Platform Sample Imported", "sample": sample_key,
            "from_batch": "Field / Intake", "to_batch": batch["id"],
            "reason": f"{sample.request_number} released from Sample Intake & Distribution to Laboratory", "details": sample.submission_channel,
            "by": actor.full_name if actor else "TSCO Platform", "ts": datetime.utcnow().isoformat(),
        })
    save_operations_state(db, state, payload, actor)


def reconcile_operations_to_platform(db: Session, payload: dict[str, Any], site_id: int, actor: User | None = None) -> int:
    """Propagate laboratory progress and LMS-submission readiness back to the platform timeline.

    Official client report release is intentionally not created here; only the
    LMS connector may confirm that terminal state after LMS job closure/report issuance.
    """
    from ..models import CustodyEvent, SampleStatus

    samples = db.scalars(select(SampleRequest).where(SampleRequest.site_id == site_id)).all()
    results_keys = {str(row.get("sample", "")).upper() for row in payload.get("results", [])}
    reports = {str(row.get("sample", "")).upper(): row for row in payload.get("reports", [])}
    batch_status: dict[str, str] = {}
    for batch in payload.get("batches", []):
        for key in batch.get("samples", []):
            batch_status[str(key).upper()] = str(batch.get("status", ""))

    rank = {
        SampleStatus.SUBMITTED.value: 1,
        SampleStatus.ACCEPTED.value: 2,
        SampleStatus.AWAITING_RECEIPT.value: 3,
        SampleStatus.RECEIVED.value: 4,
        SampleStatus.READY_FOR_LAB.value: 5,
        SampleStatus.REGISTERED.value: 5,
        SampleStatus.TESTING.value: 6,
        SampleStatus.TECHNICAL_REVIEW.value: 7,
        SampleStatus.REPORT_APPROVED.value: 8,
        SampleStatus.READY_FOR_LMS.value: 9,
        SampleStatus.REPORT_RELEASED.value: 10,
    }
    changed = 0
    for sample in samples:
        keys = {sample.request_number.upper()}
        if sample.lms_number:
            keys.add(sample.lms_number.upper())
        target = sample.status
        report = next((reports[key] for key in keys if key in reports), None)
        statuses = [batch_status.get(key, "").lower() for key in keys]
        has_technical = any("technical" in value or "review" in value for value in statuses)
        has_testing = bool(keys & results_keys) or any("testing" in value for value in statuses)

        can_approve_lms = bool(actor and actor.role in {Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value})
        already_ready = sample.status in {SampleStatus.READY_FOR_LMS.value, SampleStatus.REPORT_RELEASED.value}
        if report and str(report.get("status", "")).lower() == "ready for lms" and (can_approve_lms or already_ready):
            target = SampleStatus.READY_FOR_LMS.value
        elif has_technical:
            target = SampleStatus.TECHNICAL_REVIEW.value
        elif has_testing:
            target = SampleStatus.TESTING.value

        if rank.get(target, 0) > rank.get(sample.status, 0):
            sample.status = target
            event_type = {
                SampleStatus.TESTING.value: "LAB_RESULTS_IN_PROGRESS",
                SampleStatus.TECHNICAL_REVIEW.value: "TECHNICAL_REVIEW_STARTED",
                SampleStatus.READY_FOR_LMS.value: "LMS_SUBMISSION_APPROVED",
            }.get(target, "LAB_STATUS_SYNC")
            exists = db.scalar(
                select(CustodyEvent.id).where(
                    CustodyEvent.sample_request_id == sample.id,
                    CustodyEvent.event_type == event_type,
                )
            )
            if not exists:
                db.add(
                    CustodyEvent(
                        sample_request_id=sample.id,
                        event_type=event_type,
                        status=target,
                        actor_id=actor.id if actor else None,
                        note="Synchronized from Full Laboratory Operations; official client report remains pending LMS issuance",
                        event_at=datetime.utcnow(),
                    )
                )
            changed += 1
    return changed
