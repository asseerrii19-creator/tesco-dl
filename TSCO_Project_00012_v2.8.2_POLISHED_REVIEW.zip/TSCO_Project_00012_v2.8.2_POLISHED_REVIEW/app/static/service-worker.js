const CACHE='tsco-platform-v3-static';
const STATIC=['/static/styles.css','/static/app.js','/static/field-form.js','/static/manifest.webmanifest'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(STATIC)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
  const request=event.request,url=new URL(request.url);
  if(request.method!=='GET'||url.origin!==location.origin)return;
  if(url.pathname.startsWith('/static/')){
    event.respondWith(caches.match(request).then(cached=>cached||fetch(request).then(response=>{
      if(response.ok){const copy=response.clone();caches.open(CACHE).then(c=>c.put(request,copy));}
      return response;
    })));
    return;
  }
  // Authenticated HTML/API responses are never written to Cache Storage.
  event.respondWith(fetch(request).catch(()=>new Response(
    '<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>Offline</title><main style="font-family:&quot;Segoe UI Variable Text&quot;,&quot;Segoe UI Variable&quot;,&quot;Segoe UI&quot;,Tahoma,Arial,sans-serif;padding:32px;max-width:680px;margin:auto"><h1>Offline</h1><p>Authenticated pages are not cached on this device. If a Field Sampling form is already open, keep that tab open and continue there; queued data will synchronize after sign-in and connectivity return.</p></main>',
    {status:503,headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'}}
  )));
});
