#!/usr/bin/env bash
set -euo pipefail
echo 'TSCO_BUILD_MARKER=TSCO-G-BASELINE-QC-AUTHORITY-R2-20261004'
[[ "$(tr -d '\r\n' < VERSION)" == "3.6.4-GQC" ]]
python -m py_compile app/services/lab_operations.py app/routes/lab_operations.py app/services/document_catalog.py
grep -Fq 'G-BASELINE + QC-LIFECYCLE-R1' app/lab_ops/index_template.html
grep -Fq "function currentTestAssignment(batchId,workstation){const exact=String(batchId)!=='*'?latestAssignmentForKey(batchId,workstation):null;const src=String(exact?.source||'').toUpperCase();if(exact&&['SENIOR_EXCEPTION','SENIOR_BATCH_EXCEPTION'].includes(src))return exact;return authoritativeGlobalAssignment(workstation)}" app/lab_ops/index_template.html
grep -Fq "candidates.forEach(w=>{const a=authoritativeGlobalAssignment(w);if(assignmentAllowsUser(a))out.add(w)}" app/lab_ops/index_template.html
! grep -Fq "function currentTestAssignment(batchId,workstation){return latestAssignmentForKey(batchId,workstation)" app/lab_ops/index_template.html
grep -Fq 'QC Material / Lot Control' app/lab_ops/index_template.html
grep -Fq 'SAVE QC FILE & RESULT' app/lab_ops/index_template.html
grep -Fq 'APPROVED LOT REQUIRED' app/lab_ops/index_template.html
grep -Fq "rescueSnapshot(local,'server-authority-refresh');" app/lab_ops/index_template.html
grep -Fq '_QC_ACCEPTABLE = {"PASS"}' app/services/lab_operations.py
grep -Fq 'def _parse_qc_csv_measurement(' app/services/lab_operations.py
grep -Fq 'def _sanitize_qc_lots(' app/services/lab_operations.py
grep -Fq 'def _sanitize_qc_lot_events(' app/services/lab_operations.py
grep -Fq 'def _qc_record_has_lifecycle_evidence(' app/services/lab_operations.py
grep -Fq 'def repair_known_uat_cycle_assignments(' app/services/lab_operations.py
grep -Fq 'repair_known_uat_cycle_assignments(payload, site.code)' app/routes/lab_operations.py
python - <<'PY'
from pathlib import Path
import re
h=Path('app/lab_ops/index_template.html').read_text()
Path('/tmp/gqc.js').write_text('\n'.join(re.findall(r'<script[^>]*>(.*?)</script>',h,flags=re.S|re.I)))
PY
node --check /tmp/gqc.js
pytest -q -W ignore --tb=short \
 tests/test_v354_electrical_qc_closeout.py \
 tests/test_v355_uat_behavioral_closeout.py \
 tests/test_v356_qc_lifecycle_file_first.py \
 tests/test_v349_qc_workstation_entrypoint.py \
 tests/test_v350_daily_analytical_qc_control.py \
 tests/test_v352_report_path_closeout.py \
 tests/test_v364_live_assignment_authority_fix.py
