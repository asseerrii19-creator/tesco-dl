from __future__ import annotations

import os
import smtplib
from dataclasses import dataclass
from datetime import datetime, timedelta
from email.message import EmailMessage
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import AuditLog, Notification, QualityCase, Role, StaffAvailability, User
from .lab_operations import get_operations_state


INTERNAL_ROLES = {
    Role.FIELD_SAMPLER.value,
    Role.SAMPLING_SUPERVISOR.value,
    Role.OPERATIONS_MANAGER.value,
    Role.DATA_ENTRY.value,
    Role.LAB_TECHNICIAN.value,
    Role.SENIOR_CHEMIST.value,
    Role.QUALITY.value,
    Role.TECHNICAL_MANAGER.value,
    Role.MANAGEMENT.value,
    Role.SALES_MARKETING.value,
    Role.CLIENT_COORDINATOR.value,
    Role.FINANCE.value,
    Role.EXCELLENCE.value,
    Role.SYSTEM_ADMIN.value,
}


@dataclass(frozen=True)
class BriefDelivery:
    status: str
    detail: str


def _parse_ts(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace('Z', '+00:00')).replace(tzinfo=None)
    except (TypeError, ValueError):
        return None


def _current_quality_snapshot(payload: dict[str, Any], user: User, now: datetime) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    """Return the same active QC ownership/due work shown in the Chemist QC workspace.

    The daily brief must never invent or independently rotate QC. It reads the latest
    published distribution for the active calendar month and only formats that source.
    """
    uid = int(user.id or 0)
    month = now.strftime('%Y-%m')
    distributions = [
        d for d in payload.get('qualityDistributions', [])
        if isinstance(d, dict) and str(d.get('month') or '') == month
    ]
    if not distributions:
        return [], []
    latest = max(distributions, key=lambda d: int(d.get('revision') or 1))

    equipment_rows: list[dict[str, str]] = []
    for owner in latest.get('analytical_ownership', []):
        if not isinstance(owner, dict):
            continue
        assigned_as = None
        if int(owner.get('primary_user_id') or 0) == uid:
            assigned_as = 'Primary'
        elif int(owner.get('backup_user_id') or 0) == uid:
            assigned_as = 'Backup'
        if assigned_as:
            equipment_rows.append({
                'assigned_as': assigned_as,
                'equipment_id': str(owner.get('equipment_id') or '—'),
                'equipment_name': str(owner.get('equipment_name') or 'Instrument'),
                'workstation': str(owner.get('workstation') or '—'),
                'method': str(owner.get('test_method') or '—'),
            })

    event_map: dict[str, dict[str, Any]] = {}
    for event in payload.get('qualityTaskEvents', []):
        if not isinstance(event, dict):
            continue
        assignment_id = str(event.get('assignment_id') or '')
        if assignment_id and (
            assignment_id not in event_map
            or str(event.get('completed_at') or '') > str(event_map[assignment_id].get('completed_at') or '')
        ):
            event_map[assignment_id] = event

    routine_rows: list[dict[str, str]] = []
    for item in latest.get('assignments', []):
        if not isinstance(item, dict):
            continue
        primary = int(item.get('primary_user_id') or 0) == uid
        backup = int(item.get('backup_user_id') or 0) == uid
        if not (primary or backup):
            continue
        assignment_id = str(item.get('id') or '')
        if assignment_id and assignment_id in event_map:
            continue
        try:
            start_day = int(item.get('start_day') or 1)
            end_day = int(item.get('end_day') or start_day)
        except (TypeError, ValueError):
            start_day, end_day = 1, now.day
        if now.day < start_day:
            continue
        status = 'Overdue' if now.day > end_day else 'Due now'
        try:
            due_at = datetime(now.year, now.month, end_day).strftime('%d %b')
        except (TypeError, ValueError):
            due_at = str(item.get('period_label') or 'Current window')
        routine_rows.append({
            'task': str(item.get('task') or 'QC task'),
            'domain': str(item.get('domain') or 'Routine QC'),
            'window': str(item.get('period_label') or 'Current window'),
            'assigned_as': 'Primary' if primary else 'Backup',
            'status': status,
            'due': due_at,
        })

    equipment_rows.sort(key=lambda row: (0 if row['assigned_as'] == 'Primary' else 1, row['equipment_id']))
    routine_rows.sort(key=lambda row: (0 if row['status'] == 'Overdue' else 1, row['task']))
    return equipment_rows, routine_rows


def _current_quality_tasks(payload: dict[str, Any], user: User, now: datetime) -> list[str]:
    """Backward-compatible text rows generated from the structured QC snapshot."""
    equipment_rows, routine_rows = _current_quality_snapshot(payload, user, now)
    rows = [
        f"Equipment: {row['assigned_as']} · {row['equipment_id']} · {row['equipment_name']} · {row['workstation']}"
        for row in equipment_rows
    ]
    rows.extend(
        f"{row['task']} — {row['assigned_as']} · {row['window']} · {row['status']}"
        for row in routine_rows
    )
    return rows


def _current_lab_assignments(payload: dict[str, Any], user: User) -> list[str]:
    uid = int(user.id or 0)
    batches = {str(b.get('id') or ''): b for b in payload.get('batches', []) if isinstance(b, dict)}
    rows: list[str] = []
    for item in payload.get('testAssignments', []):
        if not isinstance(item, dict):
            continue
        mode = str(item.get('mode') or 'SINGLE').upper()
        assigned = mode == 'ALL' or uid in {
            int(item.get('primary_user_id') or 0), int(item.get('backup_user_id') or 0)
        }
        if not assigned:
            continue
        bid = str(item.get('batch_id') or '')
        batch = batches.get(bid)
        label = str((batch or {}).get('label') or (batch or {}).get('batch_label') or bid or 'All active batches')
        rows.append(f"{item.get('workstation', 'Workstation')} — {label}")
    return list(dict.fromkeys(rows))


def _yesterday_results(payload: dict[str, Any], user: User, start: datetime, end: datetime) -> list[str]:
    rows: list[str] = []
    for item in payload.get('results', []):
        if not isinstance(item, dict) or str(item.get('analyst') or '').strip().casefold() != user.full_name.strip().casefold():
            continue
        ts = _parse_ts(item.get('ts'))
        if ts and start <= ts < end:
            rows.append(
                f"Result: {item.get('sample', 'Sample')} · {item.get('display_test') or item.get('test', 'Test')} = {item.get('result', '—')} {item.get('unit', '')}".strip()
            )
    return rows


def build_daily_brief(db: Session, user: User, *, now: datetime | None = None) -> dict[str, Any]:
    if user.role not in INTERNAL_ROLES:
        raise PermissionError('Daily Operational Brief is available to internal employees only')
    now = now or datetime.now()
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    tomorrow = today + timedelta(days=1)
    yesterday = today - timedelta(days=1)

    audit_rows = db.scalars(
        select(AuditLog)
        .where(AuditLog.actor_id == user.id, AuditLog.created_at >= yesterday, AuditLog.created_at < today)
        .order_by(AuditLog.created_at.desc())
        .limit(20)
    ).all()
    yesterday_items = [f"{row.summary or row.action}" for row in audit_rows]

    today_items: list[str] = []
    carry_over: list[str] = []
    qc_items: list[str] = []
    qc_equipment: list[dict[str, str]] = []
    qc_routine: list[dict[str, str]] = []
    overnight_items: list[str] = []

    if user.site_id and user.site:
        _, payload = get_operations_state(db, user.site)
        yesterday_items = _yesterday_results(payload, user, yesterday, today) + yesterday_items
        if user.role == Role.LAB_TECHNICIAN.value:
            today_items += _current_lab_assignments(payload, user)
            qc_equipment, qc_routine = _current_quality_snapshot(payload, user, now)
            qc_items += _current_quality_tasks(payload, user, now)
            for item in payload.get('retests', []):
                if isinstance(item, dict) and str(item.get('status') or 'Requested').upper() != 'COMPLETED':
                    carry_over.append(f"Retest pending: {item.get('sample', 'Sample')} · {item.get('test', 'Test')}")

    cases = db.scalars(
        select(QualityCase)
        .where(QualityCase.assigned_to_id == user.id, ~QualityCase.status.in_(['CLOSED', 'APPROVED']))
        .order_by(QualityCase.due_at, QualityCase.created_at)
        .limit(20)
    ).all()
    for row in cases:
        due = row.due_at.strftime('%d %b %H:%M') if row.due_at else 'No fixed due time'
        today_items.append(f"{row.case_type}: {row.title} · {row.test_name or 'General'} · {due}")

    schedules = db.scalars(
        select(StaffAvailability)
        .where(
            StaffAvailability.user_id == user.id,
            StaffAvailability.start_at < tomorrow,
            StaffAvailability.end_at >= today,
            StaffAvailability.status.in_(['PLANNED', 'APPROVED', 'CONFIRMED']),
        )
        .order_by(StaffAvailability.start_at)
    ).all()
    for row in schedules:
        if row.entry_type == 'HANDOVER':
            overnight_items.append(row.notes or row.shift_code or 'Shift handover')
        elif row.entry_type in {'SHIFT', 'ON_CALL'}:
            today_items.append(f"{row.entry_type}: {row.shift_code or 'Scheduled duty'} · {row.start_at.strftime('%H:%M')}–{row.end_at.strftime('%H:%M')}")

    unread = db.scalars(
        select(Notification)
        .where(Notification.user_id == user.id, Notification.read_at.is_(None))
        .order_by(Notification.priority.desc(), Notification.created_at.desc())
        .limit(20)
    ).all()
    for row in unread:
        carry_over.append(f"{row.title}: {row.message}".strip(': '))

    def clean(items: list[str], fallback: str) -> list[str]:
        values = [str(x).strip() for x in items if str(x).strip()]
        return list(dict.fromkeys(values))[:20] or [fallback]

    return {
        'date': now.strftime('%A, %d %B %Y'),
        'generated_at': now,
        'recipient_name': user.full_name,
        'recipient_email': user.email,
        'role': user.role,
        'yesterday': clean(yesterday_items, 'No completed activity was recorded for yesterday.'),
        'today': clean(today_items, 'No individual operational assignment is currently due today.'),
        'qc_due': clean(qc_items, 'No personal QC / routine responsibility is due today.'),
        'qc_equipment': qc_equipment,
        'qc_routine': qc_routine,
        'carry_over': clean(carry_over, 'No open carry-over item is currently assigned to you.'),
        'overnight': clean(overnight_items, 'No dedicated overnight handover note is recorded for your account.'),
    }


def render_daily_brief_text(brief: dict[str, Any]) -> str:
    sections = [
        ('YESTERDAY — COMPLETED / RECORDED', brief['yesterday']),
        ('TODAY — ASSIGNED WORK', brief['today']),
        ('QC / ROUTINE DUTIES DUE', brief['qc_due']),
        ('CARRY-OVER / OPEN ITEMS', brief['carry_over']),
        ('OVERNIGHT / NIGHT-TO-MORNING HANDOVER', brief['overnight']),
    ]
    lines = [
        'TSCO DIGITAL LABORATORY PLATFORM',
        f"Daily Operational Brief · {brief['date']}",
        f"Employee: {brief['recipient_name']}",
        f"Login email: {brief['recipient_email']}",
        '',
    ]
    for title, items in sections:
        lines.append(title)
        lines.extend(f"- {item}" for item in items)
        lines.append('')
    lines.append('Live platform status remains the source of truth for urgent changes after this brief is generated.')
    return '\n'.join(lines)


def render_daily_brief_html(brief: dict[str, Any]) -> str:
    """Email-safe HTML rendering that mirrors the in-system QC brief structure."""
    def esc(value: Any) -> str:
        import html
        return html.escape(str(value or ''))

    def list_section(title: str, items: list[str]) -> str:
        lis = ''.join(f'<li style="margin:0 0 6px 0">{esc(item)}</li>' for item in items)
        return f'<div style="margin:0 0 18px"><h3 style="margin:0 0 8px;font-size:15px;color:#123a52">{esc(title)}</h3><ul style="margin:0;padding-left:20px">{lis}</ul></div>'

    equipment_rows = brief.get('qc_equipment') or []
    routine_rows = brief.get('qc_routine') or []
    qc_html = '<p style="margin:0;color:#667085">No personal QC responsibility is currently assigned.</p>'
    if equipment_rows or routine_rows:
        parts = []
        if equipment_rows:
            rows = ''.join(
                '<tr>'
                f'<td style="padding:8px;border-bottom:1px solid #e6eaee"><b>{esc(r["assigned_as"])}</b></td>'
                f'<td style="padding:8px;border-bottom:1px solid #e6eaee"><b>{esc(r["equipment_id"])}</b><br><span style="color:#667085">{esc(r["equipment_name"])}</span></td>'
                f'<td style="padding:8px;border-bottom:1px solid #e6eaee">{esc(r["workstation"])}</td>'
                '</tr>' for r in equipment_rows
            )
            parts.append('<div style="margin:0 0 12px"><b style="font-size:13px">Monthly equipment responsibility</b>'
                         '<table role="presentation" style="width:100%;border-collapse:collapse;margin-top:6px;font-size:12px">'
                         '<thead><tr style="background:#f4f7f8"><th align="left" style="padding:8px">Role</th><th align="left" style="padding:8px">Equipment</th><th align="left" style="padding:8px">Workstation</th></tr></thead>'
                         f'<tbody>{rows}</tbody></table></div>')
        if routine_rows:
            rows = ''.join(
                '<tr>'
                f'<td style="padding:8px;border-bottom:1px solid #e6eaee"><b>{esc(r["task"])}</b><br><span style="color:#667085">{esc(r["domain"])}</span></td>'
                f'<td style="padding:8px;border-bottom:1px solid #e6eaee">{esc(r["window"])}</td>'
                f'<td style="padding:8px;border-bottom:1px solid #e6eaee">{esc(r["assigned_as"])}</td>'
                f'<td style="padding:8px;border-bottom:1px solid #e6eaee"><b>{esc(r["status"])}</b></td>'
                '</tr>' for r in routine_rows
            )
            parts.append('<div><b style="font-size:13px">QC action now</b>'
                         '<table role="presentation" style="width:100%;border-collapse:collapse;margin-top:6px;font-size:12px">'
                         '<thead><tr style="background:#f4f7f8"><th align="left" style="padding:8px">Check</th><th align="left" style="padding:8px">Window</th><th align="left" style="padding:8px">Role</th><th align="left" style="padding:8px">Status</th></tr></thead>'
                         f'<tbody>{rows}</tbody></table></div>')
        qc_html = ''.join(parts)

    return f'''<!doctype html><html><body style="margin:0;background:#f3f5f7;font-family:Arial,sans-serif;color:#1f2933">
    <div style="max-width:760px;margin:0 auto;padding:24px">
      <div style="background:#0d3448;color:white;padding:22px 24px;border-radius:12px 12px 0 0">
        <div style="font-size:11px;letter-spacing:1.2px;opacity:.8">TSCO DIGITAL LABORATORY PLATFORM</div>
        <h1 style="margin:5px 0 2px;font-size:22px">Daily Operational Brief</h1>
        <div style="opacity:.85;font-size:13px">{esc(brief['date'])} · {esc(brief['recipient_name'])}</div>
      </div>
      <div style="background:white;padding:22px 24px;border-radius:0 0 12px 12px">
        {list_section('Yesterday · completed / recorded', brief['yesterday'])}
        {list_section('Today · assigned work', brief['today'])}
        <div style="margin:0 0 18px;padding:14px;border:1px solid #dde5e8;border-radius:10px">
          <h3 style="margin:0 0 10px;font-size:15px;color:#123a52">QC / equipment responsibility</h3>{qc_html}
        </div>
        {list_section('Carry-over / open items', brief['carry_over'])}
        {list_section('Night-to-morning handover', brief['overnight'])}
        <div style="margin-top:18px;padding-top:12px;border-top:1px solid #e6eaee;color:#667085;font-size:11px">Live platform status remains the source of truth for urgent changes after this brief is generated.</div>
      </div>
    </div></body></html>'''


def deliver_daily_brief(brief: dict[str, Any]) -> BriefDelivery:
    host = os.getenv('SMTP_HOST', '').strip()
    sender = os.getenv('SMTP_FROM', '').strip()
    if not host or not sender:
        return BriefDelivery('PENDING_CONFIGURATION', 'SMTP_HOST and SMTP_FROM are not configured')

    port = int(os.getenv('SMTP_PORT', '587'))
    username = os.getenv('SMTP_USERNAME', '').strip()
    password = os.getenv('SMTP_PASSWORD', '')
    use_tls = os.getenv('SMTP_STARTTLS', '1').strip().lower() not in {'0', 'false', 'no'}

    message = EmailMessage()
    message['Subject'] = f"TSCO Daily Operational Brief — {brief['date']}"
    message['From'] = sender
    message['To'] = brief['recipient_email']
    message.set_content(render_daily_brief_text(brief))
    message.add_alternative(render_daily_brief_html(brief), subtype='html')

    with smtplib.SMTP(host, port, timeout=20) as smtp:
        if use_tls:
            smtp.starttls()
        if username:
            smtp.login(username, password)
        smtp.send_message(message)
    return BriefDelivery('SENT', f"Delivered to {brief['recipient_email']}")
