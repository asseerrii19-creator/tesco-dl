from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Role, SampleRequest, SampleStatus
from ..security import require_user
from ..services.audit import add_audit
from ..services.commercial import sync_case_from_sample
from ..services.month_close import assert_sample_period_open
from ..services.scope import can_access_site
from ..services.workflow import add_event

router = APIRouter(prefix="/receiving", tags=["legacy receiving alias"])
ALLOWED = {Role.DATA_ENTRY.value, Role.SYSTEM_ADMIN.value}


@router.get("")
def legacy_receiving(request: Request, barcode: str = "", error: str = "", db: Session = Depends(get_db)):
    require_user(request, db, ALLOWED)
    params = ["view=receiving"]
    if barcode:
        params.append(f"q={barcode}")
    if error:
        params.append(f"error={error}")
    return RedirectResponse("/intake?" + "&".join(params), status_code=303)


@router.post("/{sample_id}/receive")
def legacy_receive(
    sample_id: int,
    request: Request,
    seal_status: str = Form("Intact"),
    condition_note: str = Form(""),
    db: Session = Depends(get_db),
):
    """Backward-compatible transaction endpoint.

    It uses the same unified Sample Intake & Receiving authority and returns to the
    unified intake workspace. It does not represent a separate department/workspace.
    """
    user = require_user(request, db, ALLOWED)
    sample = db.get(SampleRequest, sample_id)
    if not sample or not can_access_site(user, sample.site_id):
        return RedirectResponse("/intake?view=receiving", status_code=303)
    assert_sample_period_open(db, sample)
    clean = seal_status.strip().upper()
    if clean not in {"INTACT", "BROKEN", "MISSING", "NOT APPLICABLE"}:
        raise ValueError("Unsupported seal status")
    if sample.status == SampleStatus.RECEIVED.value:
        return RedirectResponse("/intake?view=receiving&error=Sample+is+already+recorded+as+received", status_code=303)
    if not sample.lms_number:
        return RedirectResponse("/intake?view=receiving&error=Sample+must+be+accepted+and+registered+before+physical+receipt", status_code=303)
    if sample.status != SampleStatus.AWAITING_RECEIPT.value:
        return RedirectResponse("/intake?view=receiving&error=Sample+status+does+not+permit+physical+receipt", status_code=303)
    sample.status = SampleStatus.RECEIVED.value
    sample.received_at = datetime.utcnow()
    add_event(db, sample, user, "PHYSICAL_RECEIPT", sample.status, f"Seal: {clean}. {condition_note}".strip())
    sync_case_from_sample(db, sample, user, note="Physical sample received by Sample Intake & Receiving")
    add_audit(db, actor=user, request=request, action="PHYSICAL_SAMPLE_RECEIVED", entity_type="SampleRequest", entity_id=sample.id, summary=f"Received {sample.request_number}", details={"seal_status": clean, "condition_note": condition_note})
    db.commit()
    return RedirectResponse("/intake?view=distribution", status_code=303)
