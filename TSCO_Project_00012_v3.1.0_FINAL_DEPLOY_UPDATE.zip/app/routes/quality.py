from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import (
    AuditLog, CompetencyRecord, EquipmentAsset, EquipmentEvent, EvidenceRecord,
    QualityCase, Role, Site, User,
)
from ..security import require_user
from ..services.lab_operations import get_operations_state

router = APIRouter(prefix="/quality", tags=["quality"])
VIEW = {Role.QUALITY.value, Role.TECHNICAL_MANAGER.value, Role.MANAGEMENT.value, Role.SYSTEM_ADMIN.value}
WRITE = {Role.QUALITY.value, Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value}
TABS = [
    ("qc", "QC Ownership"),
    ("equipment", "Equipment & Calibration"),
    ("materials", "Materials / Gases / Storage"),
    ("validation", "Validation / Verification"),
    ("ilc_pt", "ILC / PT"),
    ("capa", "NCR / CAPA"),
    ("competency", "Competency"),
    ("evidence", "Evidence"),
    ("audit", "Audit"),
]


def _site(db: Session, user) -> Site:
    site = db.get(Site, user.site_id) if user.site_id else None
    return site or db.scalar(select(Site).where(Site.code == "DMM"))


@router.get("")
def quality_center(request: Request, tab: str = "qc", db: Session = Depends(get_db)):
    user = require_user(request, db, VIEW)
    site = _site(db, user)
    allowed = {k for k, _ in TABS}
    tab = tab if tab in allowed else "qc"

    staff_stmt = select(User).where(User.active.is_(True)).order_by(User.full_name)
    if user.site_id:
        staff_stmt = staff_stmt.where((User.site_id == user.site_id) | (User.site_id.is_(None)))
    staff = list(db.scalars(staff_stmt).all())
    equipment = list(db.scalars(select(EquipmentAsset).where(EquipmentAsset.site_id == site.id, EquipmentAsset.active.is_(True)).order_by(EquipmentAsset.equipment_id)).all())
    equipment_events = list(db.scalars(select(EquipmentEvent).join(EquipmentAsset).where(EquipmentAsset.site_id == site.id).order_by(EquipmentEvent.event_at.desc()).limit(150)).all())
    cases = list(db.scalars(select(QualityCase).where(QualityCase.site_id == site.id).order_by(QualityCase.created_at.desc()).limit(300)).all())
    competencies = list(db.scalars(select(CompetencyRecord).where(CompetencyRecord.site_id == site.id, CompetencyRecord.active.is_(True)).order_by(CompetencyRecord.created_at.desc()).limit(300)).all())
    evidence = list(db.scalars(select(EvidenceRecord).where(EvidenceRecord.site_id == site.id).order_by(EvidenceRecord.created_at.desc()).limit(200)).all())
    audits = list(db.scalars(select(AuditLog).where((AuditLog.site_id == site.id) | (AuditLog.site_id.is_(None))).order_by(AuditLog.created_at.desc()).limit(200)).all())

    _, payload = get_operations_state(db, site)
    distributions = sorted(payload.get("qualityDistributions", []), key=lambda x: str(x.get("month", "")), reverse=True)
    current_distribution = distributions[0] if distributions else None
    routine_owners = list(current_distribution.get("routine_owners", [])) if current_distribution else []
    analytical_ownership = list(current_distribution.get("analytical_ownership", [])) if current_distribution else []
    materials_assignments = [x for x in routine_owners if str(x.get("domain", "")) == "Materials, Gases & Storage"]
    controlled_materials = list(payload.get("standards", []))
    quality_events = list(payload.get("qualityTaskEvents", []))
    quality_event_map = {}
    for event in quality_events:
        aid = str(event.get("assignment_id") or "")
        if aid and (aid not in quality_event_map or str(event.get("completed_at") or "") > str(quality_event_map[aid].get("completed_at") or "")):
            quality_event_map[aid] = event

    return templates.TemplateResponse("quality_center.html", {
        "request": request, "user": user, "site": site, "tab": tab,
        "visible_tabs": TABS, "can_write": user.role in WRITE,
        "staff": staff, "equipment": equipment, "equipment_events": equipment_events,
        "cases": cases, "competencies": competencies, "evidence_rows": evidence, "audits": audits,
        "quality_distribution": current_distribution, "routine_owners": routine_owners,
        "analytical_ownership": analytical_ownership, "materials_assignments": materials_assignments,
        "controlled_materials": controlled_materials, "quality_events": quality_events,
        "quality_event_map": quality_event_map, "now": datetime.utcnow(),
    })
