from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends, Request
from fastapi.responses import FileResponse, RedirectResponse
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import ControlledDocument, Role, User
from ..security import require_user
from ..storage import CONTROLLED_DOCUMENT_DIR

from ..services.document_catalog import document_matches

router = APIRouter(tags=["controlled documents"])
ALLOWED = {
    Role.LAB_TECHNICIAN.value,
    Role.FIELD_SAMPLER.value, Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value,
    Role.DATA_ENTRY.value, Role.CLIENT_COORDINATOR.value, Role.EXCELLENCE.value,
    Role.SENIOR_CHEMIST.value,
    Role.QUALITY.value,
    Role.TECHNICAL_MANAGER.value,
    Role.MANAGEMENT.value,
    Role.SYSTEM_ADMIN.value,
}
DOC_DIR = CONTROLLED_DOCUMENT_DIR


def _user(request: Request, db: Session) -> User:
    return require_user(request, db, ALLOWED)


@router.get("/documents")
def document_library(request: Request, workstation: str = "", test: str = "", method: str = "", db: Session = Depends(get_db)):
    user = _user(request, db)
    stmt = select(ControlledDocument).where(ControlledDocument.status.in_(["ACTIVE", "REFERENCE"]))
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        stmt = stmt.where(or_(ControlledDocument.site_id.is_(None), ControlledDocument.site_id == user.site_id))
    clean_ws = workstation.strip()[:120]
    clean_test = test.strip()[:220]
    clean_method = method.strip()[:160]
    documents = db.scalars(stmt.order_by(ControlledDocument.document_type, ControlledDocument.code)).all()
    documents = [d for d in documents if document_matches(d, clean_ws, clean_test, clean_method)]
    return templates.TemplateResponse("documents.html", {"request": request, "user": user, "documents": documents, "workstation": clean_ws, "test": clean_test, "method": clean_method})


@router.get("/documents/by-code/{code}")
def open_document_code(code: str, request: Request, db: Session = Depends(get_db)):
    user = _user(request, db)
    stmt = select(ControlledDocument).where(ControlledDocument.code == code, ControlledDocument.status.in_(["ACTIVE", "REFERENCE"]))
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        stmt = stmt.where(or_(ControlledDocument.site_id.is_(None), ControlledDocument.site_id == user.site_id))
    rows = list(db.scalars(stmt).all())
    rows.sort(key=lambda d: (d.status == "ACTIVE", d.site_id == user.site_id, d.created_at), reverse=True)
    if not rows:
        return templates.TemplateResponse("not_found.html", {"request": request, "user": user}, status_code=404)
    return RedirectResponse(f"/documents/{rows[0].id}/download", status_code=303)


@router.get("/documents/{document_id}/download")
def download_document(document_id: int, request: Request, db: Session = Depends(get_db)):
    user = _user(request, db)
    doc = db.get(ControlledDocument, document_id)
    if not doc:
        return templates.TemplateResponse("not_found.html", {"request": request, "user": user}, status_code=404)
    if user.role != Role.SYSTEM_ADMIN.value and doc.status not in {"ACTIVE", "REFERENCE"}:
        return templates.TemplateResponse("not_found.html", {"request": request, "user": user}, status_code=404)
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id and doc.site_id not in {None, user.site_id}:
        return templates.TemplateResponse("not_found.html", {"request": request, "user": user}, status_code=404)
    path = DOC_DIR / Path(doc.stored_filename).name
    if not path.exists():
        return templates.TemplateResponse("not_found.html", {"request": request, "user": user}, status_code=404)
    response = FileResponse(path, filename=doc.original_filename)
    response.headers["Cache-Control"] = "private, no-store"
    return response
