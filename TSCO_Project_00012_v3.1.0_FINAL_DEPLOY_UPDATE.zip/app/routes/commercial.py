from __future__ import annotations

import hashlib
from datetime import datetime
from io import BytesIO
from pathlib import Path

from PIL import Image, UnidentifiedImageError
from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from fastapi.responses import FileResponse, RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import Client, CommercialAttachment, CommercialCase, Role, Site, User
from ..security import require_user
from ..services.audit import add_audit
from ..services.commercial import (
    COMMERCIAL_STAGES, STAGE_KEYS, STAGE_LABELS, advance_case, effective_stage,
    next_stage, role_can_transition,
)
from ..storage import UPLOAD_DIR

router = APIRouter(prefix="/commercial", tags=["business communication flow"])
VIEW = {
    Role.SALES_MARKETING.value, Role.FINANCE.value, Role.OPERATIONS_MANAGER.value,
    Role.SAMPLING_SUPERVISOR.value, Role.DATA_ENTRY.value, Role.CLIENT_COORDINATOR.value,
    Role.SENIOR_CHEMIST.value, Role.QUALITY.value, Role.TECHNICAL_MANAGER.value,
    Role.MANAGEMENT.value, Role.SYSTEM_ADMIN.value,
}
CREATE = {Role.SALES_MARKETING.value, Role.CLIENT_COORDINATOR.value, Role.SYSTEM_ADMIN.value}
ATTACHMENT_UPLOAD = {Role.CLIENT_COORDINATOR.value, Role.SYSTEM_ADMIN.value}
MAX_COMMERCIAL_ATTACHMENT_BYTES = 10_000_000
COMMERCIAL_DOCUMENT_TYPES = {"QUOTATION", "PURCHASE_ORDER", "CLIENT_REQUEST", "HANDOVER", "OTHER"}


def _validated_attachment(upload: UploadFile) -> tuple[bytes, str, str]:
    if not upload.filename:
        raise ValueError("Select a quotation, purchase order or client document to upload")
    raw = upload.file.read(MAX_COMMERCIAL_ATTACHMENT_BYTES + 1)
    if not raw:
        raise ValueError("The selected commercial document is empty")
    if len(raw) > MAX_COMMERCIAL_ATTACHMENT_BYTES:
        raise ValueError("Commercial attachments must be 10 MB or smaller")
    original = Path(upload.filename).name[:220]
    suffix = Path(original).suffix.lower()
    content_type = (upload.content_type or "").lower()
    if content_type == "application/pdf" or suffix == ".pdf":
        if not raw.startswith(b"%PDF-"):
            raise ValueError("The uploaded PDF is invalid")
        return raw, ".pdf", "application/pdf"
    if content_type.startswith("image/") or suffix in {".jpg", ".jpeg", ".png", ".webp"}:
        try:
            with Image.open(BytesIO(raw)) as image:
                image.verify()
                fmt = (image.format or "").upper()
        except (UnidentifiedImageError, OSError, SyntaxError, ValueError):
            raise ValueError("The uploaded commercial image is invalid or corrupt")
        mapping = {
            "JPEG": (".jpg", "image/jpeg"),
            "PNG": (".png", "image/png"),
            "WEBP": (".webp", "image/webp"),
        }
        if fmt not in mapping:
            raise ValueError("Commercial document images must be JPEG, PNG or WebP")
        ext, mime = mapping[fmt]
        return raw, ext, mime
    raise ValueError("Commercial attachments must be PDF, JPEG, PNG or WebP")


def _site(db: Session, user: User) -> Site:
    if user.site_id:
        row = db.get(Site, user.site_id)
    else:
        row = db.scalar(select(Site).where(Site.code == "DMM"))
    if not row:
        raise ValueError("Active site is required")
    return row


def _case_code(db: Session, site: Site) -> str:
    year = datetime.utcnow().year
    prefix = f"BC-{site.code}-{year}-"
    rows = db.scalars(select(CommercialCase.case_code).where(CommercialCase.case_code.like(f"{prefix}%"))).all()
    last = 0
    for value in rows:
        try: last = max(last, int(value.rsplit("-", 1)[-1]))
        except Exception: pass
    return f"{prefix}{last + 1:04d}"


@router.get("")
def workspace(request: Request, case_id: int | None = None, db: Session = Depends(get_db)):
    user = require_user(request, db, VIEW)
    site = _site(db, user)
    stmt = select(CommercialCase).where(CommercialCase.site_id == site.id).order_by(CommercialCase.updated_at.desc())
    cases = list(db.scalars(stmt.limit(200)).all())
    selected = db.get(CommercialCase, case_id) if case_id else (cases[0] if cases else None)
    if selected and selected.site_id != site.id:
        selected = None
    clients = list(db.scalars(select(Client).where(Client.active.is_(True)).order_by(Client.name)).all())
    effective = effective_stage(db, selected) if selected else ""
    expected = next_stage(effective) if selected else None
    can_advance = bool(selected and expected and role_can_transition(user, expected))
    return templates.TemplateResponse("commercial_flow.html", {
        "request": request, "user": user, "site": site, "cases": cases, "selected": selected,
        "clients": clients, "stages": COMMERCIAL_STAGES, "stage_keys": STAGE_KEYS,
        "stage_labels": STAGE_LABELS, "effective_stage": effective, "next_stage": expected,
        "can_advance": can_advance, "can_create": user.role in CREATE,
        "can_upload_attachment": user.role in ATTACHMENT_UPLOAD,
        "commercial_document_types": sorted(COMMERCIAL_DOCUMENT_TYPES),
    })


@router.post("/cases")
def create_case(
    request: Request,
    client_id: int = Form(...), lead_title: str = Form(...), lead_source: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, CREATE)
    site = _site(db, user)
    client = db.get(Client, client_id)
    if not client or not client.active:
        raise ValueError("Active client is required")
    title = lead_title.strip()
    if not title:
        raise ValueError("Lead / opportunity title is required")
    row = CommercialCase(
        case_code=_case_code(db, site), site_id=site.id, client_id=client.id, owner_id=user.id,
        current_stage="LEAD_GENERATION", lead_title=title[:220], lead_source=lead_source.strip()[:120],
    )
    db.add(row); db.flush()
    from ..models import CommercialEvent
    db.add(CommercialEvent(commercial_case_id=row.id, actor_id=user.id, from_stage="", to_stage="LEAD_GENERATION", note="Business opportunity opened"))
    add_audit(db, actor=user, request=request, action="COMMERCIAL_CASE_CREATED", entity_type="CommercialCase", entity_id=row.id, summary=row.case_code, details={"client_id": client.id})
    db.commit()
    return RedirectResponse(f"/commercial?case_id={row.id}", status_code=303)


@router.post("/cases/{case_id}/advance")
def advance(
    case_id: int, request: Request,
    target_stage: str = Form(...), note: str = Form(""), reference: str = Form(""),
    quotation_number: str = Form(""), purchase_order_number: str = Form(""),
    handover_commercial: str = Form(""), handover_technical: str = Form(""), handover_client_info: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, VIEW)
    case = db.get(CommercialCase, case_id)
    site = _site(db, user)
    if not case or case.site_id != site.id:
        raise ValueError("Business case was not found in the active site")
    before = effective_stage(db, case)
    advance_case(
        db, case, user, target_stage=target_stage, note=note, reference=reference,
        quotation_number=quotation_number, purchase_order_number=purchase_order_number,
        handover_commercial=handover_commercial, handover_technical=handover_technical,
        handover_client_info=handover_client_info,
    )
    add_audit(db, actor=user, request=request, action="COMMERCIAL_STAGE_ADVANCED", entity_type="CommercialCase", entity_id=case.id, summary=f"{case.case_code}: {before} -> {target_stage}", details={"reference": reference.strip()})
    db.commit()
    return RedirectResponse(f"/commercial?case_id={case.id}", status_code=303)


@router.post("/cases/{case_id}/attachments")
def upload_attachment(
    case_id: int,
    request: Request,
    document_type: str = Form(...),
    upload: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, ATTACHMENT_UPLOAD)
    case = db.get(CommercialCase, case_id)
    site = _site(db, user)
    if not case or case.site_id != site.id:
        raise ValueError("Business case was not found in the active site")
    kind = (document_type or "").strip().upper()
    if kind not in COMMERCIAL_DOCUMENT_TYPES:
        raise ValueError("Unsupported commercial document type")
    raw, ext, mime = _validated_attachment(upload)
    digest = hashlib.sha256(raw).hexdigest()
    folder = UPLOAD_DIR / "commercial"
    folder.mkdir(parents=True, exist_ok=True)
    stored = folder / f"case_{case.id}_{digest[:20]}{ext}"
    if not stored.exists():
        stored.write_bytes(raw)
    row = CommercialAttachment(
        commercial_case_id=case.id,
        document_type=kind,
        original_name=Path(upload.filename or f"document{ext}").name[:220],
        stored_path=str(stored),
        content_type=mime,
        sha256=digest,
        uploaded_by_id=user.id,
    )
    db.add(row)
    db.flush()
    add_audit(
        db, actor=user, request=request, action="COMMERCIAL_ATTACHMENT_UPLOADED",
        entity_type="CommercialAttachment", entity_id=row.id,
        summary=f"{case.case_code}: {kind} — {row.original_name}",
        details={"case_id": case.id, "document_type": kind, "sha256": digest},
    )
    db.commit()
    return RedirectResponse(f"/commercial?case_id={case.id}", status_code=303)


@router.get("/attachments/{attachment_id}")
def download_attachment(attachment_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, VIEW)
    row = db.get(CommercialAttachment, attachment_id)
    if not row:
        raise ValueError("Commercial attachment was not found")
    case = db.get(CommercialCase, row.commercial_case_id)
    site = _site(db, user)
    if not case or case.site_id != site.id:
        raise ValueError("Commercial attachment is outside the active site")
    path = Path(row.stored_path)
    if not path.is_file():
        raise ValueError("Commercial attachment file is unavailable")
    return FileResponse(
        path,
        media_type=row.content_type or "application/octet-stream",
        filename=Path(row.original_name).name,
        content_disposition_type="inline",
    )
