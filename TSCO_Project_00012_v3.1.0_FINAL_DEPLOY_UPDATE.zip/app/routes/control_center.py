from __future__ import annotations

import hashlib, json, secrets, os
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends, Form, Request, UploadFile, File, HTTPException
from fastapi.responses import RedirectResponse, JSONResponse
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import (Role, User, Site, SampleRequest, SampleStatus, EquipmentAsset, EquipmentEvent,
    CompetencyRecord, QualityCase, StaffAvailability, EvidenceRecord, TechnicalResultRule,
    TroubleshootingRecord, ControlledReport, Asset, AssetHistoryEvent, Notification, StaffWorkPattern)
from ..security import require_user
from ..services.audit import add_audit
from ..responsibilities import senior_responsibility, troubleshooting_domain
from ..services.commercial import sync_case_from_sample
from ..services.month_close import assert_sample_period_open
from ..services.lab_operations import get_operations_state, save_operations_state
from ..services.daily_brief import INTERNAL_ROLES, build_daily_brief
from ..role_matrix import ROLE_REVIEW_MATRIX

router = APIRouter(prefix="/control", tags=["quality and operations control"])
VIEW = {Role.SENIOR_CHEMIST.value,Role.QUALITY.value,Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value}
QUALITY_WRITE = {Role.QUALITY.value,Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value}
SENIOR_WRITE = {Role.SENIOR_CHEMIST.value,Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value}
UPLOAD_DIR = Path(os.getenv("TSCO_DATA_DIR", str(Path(__file__).resolve().parents[1] / "data"))) / "uploads" / "controlled-evidence"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

CONTROL_TAB_LABELS = [
    ("overview","Overview"),("equipment","Equipment / Calibration"),("validation","Validation / Verification"),
    ("ilc_pt","ILC / PT"),("capa","NCR / CAPA"),("competency","Competency"),
    ("schedule","Leave / Shift / On-call"),("rules","Result Rules / LTD"),("evidence","Evidence"),
    ("troubleshooting","Troubleshooting"),("assets","Asset History"),("reports","Reports / LMS")
]
CONTROL_ROLE_TABS = {
    Role.SENIOR_CHEMIST.value: {"overview","equipment","schedule","troubleshooting","assets","reports"},
    Role.QUALITY.value: {"overview","equipment","validation","ilc_pt","capa","competency","rules","evidence","troubleshooting","reports"},
    Role.TECHNICAL_MANAGER.value: {key for key,_ in CONTROL_TAB_LABELS},
    Role.SYSTEM_ADMIN.value: {key for key,_ in CONTROL_TAB_LABELS},
}


def _site(db,user):
    s=db.get(Site,user.site_id) if user.site_id else None
    return s or db.query(Site).filter(Site.code=="DMM").first()

def _dt(v:str|None):
    if not v: return None
    return datetime.fromisoformat(v.replace("Z","+00:00")).replace(tzinfo=None)

def _num(v:str|None):
    if v in (None,""): return None
    return float(v)

def _int(v:str|None):
    if v in (None,""): return None
    return int(v)

def _audit(db,request,user,action,etype,eid,summary):
    add_audit(db,actor=user,request=request,action=action,entity_type=etype,entity_id=eid,summary=summary)

def _notify(db,user_id:int,site_id:int|None,title:str,message:str,target_url:str,priority:str="NORMAL",category:str="WORK"):
    if user_id:
        db.add(Notification(site_id=site_id,user_id=user_id,category=category,title=title,message=message,target_url=target_url,priority=priority,email_status="PENDING_CONFIGURATION"))


def _result_ts(row: dict) -> str:
    return str(row.get("ts") or row.get("timestamp") or "")

def _latest_alias(rows: list[dict], matcher, *, display_test: str | None = None, default_method: str | None = None, default_unit: str | None = None) -> dict | None:
    matched=[r for r in rows if matcher(str(r.get("test") or r.get("display_test") or "").lower())]
    if not matched:
        return None
    row=dict(sorted(matched,key=_result_ts)[-1])
    if display_test: row["display_test"]=display_test
    if default_method and not str(row.get("method") or "").strip(): row["method"]=default_method
    if default_unit and not str(row.get("unit") or "").strip(): row["unit"]=default_unit
    return row

def _polish_report_buckets(buckets: dict[str,list[dict]]) -> dict[str,list[dict]]:
    # DGA aliases are common when an instrument import and a manual/result-entry label coexist.
    # Report one latest value per controlled gas so the controlled view never duplicates the same analyte.
    dga=buckets.get("dga",[])
    gas_specs=[
        ("H2","Hydrogen (H2)",lambda n: n.startswith("dga:h2") or "hydrogen" in n),
        ("O2","Oxygen (O2)",lambda n: n.startswith("dga:o2") or n=="oxygen (o2)" or n=="oxygen"),
        ("N2","Nitrogen (N2)",lambda n: n.startswith("dga:n2") or n=="nitrogen (n2)" or n=="nitrogen"),
        ("C2H4","Ethylene (C2H4)",lambda n: n.startswith("dga:c2h4") or "ethylene" in n),
        ("C2H6","Ethane (C2H6)",lambda n: n.startswith("dga:c2h6") or n.strip() in {"ethane","ethane (c2h6)"}),
        ("C2H2","Acetylene (C2H2)",lambda n: n.startswith("dga:c2h2") or "acetylene" in n),
        ("CH4","Methane (CH4)",lambda n: n.startswith("dga:ch4") or n.strip() in {"methane","methane (ch4)"}),
        ("CO","Carbon Monoxide (CO)",lambda n: n.startswith("dga:co") and not n.startswith("dga:co2") or "carbon monoxide" in n),
        ("CO2","Carbon Dioxide (CO2)",lambda n: n.startswith("dga:co2") or "carbon dioxide" in n),
    ]
    controlled=[]; consumed=set()
    for _,label,match in gas_specs:
        candidates=[r for r in dga if match(str(r.get("test") or r.get("display_test") or "").lower())]
        if candidates:
            latest=sorted(candidates,key=_result_ts)[-1]; consumed.update(id(r) for r in candidates)
            row=dict(latest); row["display_test"]=label
            if not str(row.get("unit") or "").strip(): row["unit"]="ppm"
            controlled.append(row)
    derived=[r for r in dga if id(r) not in consumed]
    buckets["dga"]=controlled+derived

    paper=buckets.get("paper",[])
    direct=_latest_alias(paper,lambda n: any(k in n for k in ("direct dp","dp-value of paper","dp value of paper","degree of polymerization","paper sample")),display_test="DP-value of Paper",default_method="IEC 60450")
    buckets["paper"]=[direct] if direct else []

    corrosion=buckets.get("corrosion",[])
    corrosive=_latest_alias(corrosion,lambda n: "corrosive sulfur" in n and "potentially" not in n,display_test="Corrosive Sulfur Status",default_method="ASTM D1275B",default_unit="Pass/Fail")
    tarnish=_latest_alias(corrosion,lambda n: "tarnish" in n,display_test="Tarnish Level",default_method="ASTM D1275B")
    ccd=_latest_alias(corrosion,lambda n: "potentially corrosive" in n or "ccd" in n,display_test="Potentially Corrosive Sulfur (CCD)",default_method="IEC 62535",default_unit="Pass/Fail")
    buckets["corrosion"]=[r for r in (corrosive,tarnish,ccd) if r]

    additives=buckets.get("additives",[])
    dbds=_latest_alias(additives,lambda n: "dbds" in n or "dibenzyl" in n,display_test="Dibenzyl Disulfide (DBDS)",default_method="IEC 62697",default_unit="mg/kg")
    bht=_latest_alias(additives,lambda n: "bht" in n or "antioxidant" in n,display_test="Antioxidant (BHT)",default_method="IEC 60666")
    toluene=_latest_alias(additives,lambda n: "toluene" in n,display_test="Toluene",default_method="ASTM D5580")
    controlled_add=[r for r in (dbds,bht,toluene) if r]
    remaining=[]
    for r in additives:
        n=str(r.get("test") or r.get("display_test") or "").lower()
        if ("dbds" in n or "dibenzyl" in n or "bht" in n or "antioxidant" in n or "toluene" in n):
            continue
        remaining.append(r)
    buckets["additives"]=controlled_add+remaining
    return buckets

@router.get("")
def center(request:Request, tab:str="overview", db:Session=Depends(get_db)):
    user=require_user(request,db,VIEW)
    # Legacy Control Center deep links are retained only as compatibility aliases.
    # Quality governance is independent from Continuous Improvement / Excellence.
    quality_tabs={"overview":"qc","equipment":"equipment","validation":"validation","verification":"validation",
                  "ilc_pt":"ilc_pt","capa":"capa","competency":"competency","evidence":"evidence",
                  "rules":"qc","assets":"equipment"}
    if tab == "troubleshooting":
        return RedirectResponse("/troubleshooting",303)
    if tab == "schedule":
        return RedirectResponse("/control/my-availability",303)
    if tab == "reports":
        return RedirectResponse("/management",303)
    return RedirectResponse(f"/quality?tab={quality_tabs.get(tab,'qc')}",303)

@router.post("/equipment")
def equipment_create(request:Request,equipment_id:str=Form(...),name:str=Form(...),workstation:str=Form(""),test_method:str=Form(""),status:str=Form("IN_SERVICE"),manufacturer:str=Form(""),model:str=Form(""),serial_number:str=Form(""),calibration_provider:str=Form(""),calibration_certificate:str=Form(""),next_calibration_at:str=Form(""),notes:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,QUALITY_WRITE); site=_site(db,user)
    if db.query(EquipmentAsset).filter_by(site_id=site.id,equipment_id=equipment_id.strip()).first(): raise ValueError("Equipment ID already exists at this site")
    row=EquipmentAsset(site_id=site.id,equipment_id=equipment_id.strip(),name=name.strip(),workstation=workstation.strip(),test_method=test_method.strip(),status=status.upper(),manufacturer=manufacturer.strip(),model=model.strip(),serial_number=serial_number.strip(),calibration_provider=calibration_provider.strip(),calibration_certificate=calibration_certificate.strip(),next_calibration_at=_dt(next_calibration_at),notes=notes.strip())
    db.add(row); db.flush(); _audit(db,request,user,"EQUIPMENT_CREATE","EquipmentAsset",row.id,f"Created {row.equipment_id}"); db.commit(); return RedirectResponse("/quality?tab=equipment",303)

@router.post("/equipment/{eid}/event")
def equipment_event(eid:int,request:Request,event_type:str=Form(...),result:str=Form(""),details:str=Form(""),next_due_at:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,QUALITY_WRITE | {Role.SENIOR_CHEMIST.value}); site=_site(db,user); eq=db.get(EquipmentAsset,eid)
    if not eq or eq.site_id!=site.id: raise ValueError("Equipment not found")
    if user.role==Role.SENIOR_CHEMIST.value and senior_responsibility(user)!="EQUIPMENT": raise HTTPException(status_code=403,detail="This equipment action belongs to the Equipment & Maintenance Senior responsibility")
    result=result.upper().strip(); ev=EquipmentEvent(equipment_asset_id=eq.id,event_type=event_type.upper(),status="CLOSED",result=result,details=details.strip(),performed_by_id=user.id,next_due_at=_dt(next_due_at)); db.add(ev)
    if result in {"FAIL","OUT_OF_TOLERANCE","DEFECTIVE"}: eq.status="OUT_OF_SERVICE"
    elif event_type.upper() in {"CALIBRATION","VERIFICATION"} and result in {"PASS","ACCEPTED"}: eq.status="IN_SERVICE"; eq.last_calibration_at=datetime.utcnow() if event_type.upper()=="CALIBRATION" else eq.last_calibration_at; eq.last_verification_at=datetime.utcnow() if event_type.upper()=="VERIFICATION" else eq.last_verification_at
    if ev.next_due_at:
        if event_type.upper()=="CALIBRATION": eq.next_calibration_at=ev.next_due_at
        if event_type.upper()=="VERIFICATION": eq.next_verification_at=ev.next_due_at
    _audit(db,request,user,"EQUIPMENT_EVENT","EquipmentAsset",eq.id,f"{event_type}: {result}"); db.commit(); return RedirectResponse("/quality?tab=equipment",303)

@router.post("/competency")
def competency_create(request:Request,user_id:int=Form(...),test_name:str=Form(...),method_name:str=Form(""),workstation:str=Form(""),category:int=Form(1),technical_score:str=Form(""),data_processing_score:str=Form(""),expires_at:str=Form(""),evidence_reference:str=Form(""),notes:str=Form(""),db:Session=Depends(get_db)):
    actor=require_user(request,db,QUALITY_WRITE); site=_site(db,actor); target=db.get(User,user_id)
    if not target or target.site_id!=site.id: raise ValueError("Employee is outside this laboratory site")
    tech=_num(technical_score); data=_num(data_processing_score); overall=None
    if tech is not None and data is not None: overall=round(tech*.75+data*.25,2)
    auth="TRAINING"
    if overall is not None: auth="INDEPENDENT" if overall>=91 else "SUPERVISED" if overall>=75 else "FAILED"
    if category>=4 and auth=="TRAINING": auth="INDEPENDENT"
    row=CompetencyRecord(site_id=site.id,user_id=target.id,test_name=test_name.strip(),method_name=method_name.strip(),workstation=workstation.strip(),category=max(1,min(category,5)),technical_score=tech,data_processing_score=data,overall_score=overall,authorization=auth,effective_at=datetime.utcnow(),expires_at=_dt(expires_at),evaluated_by_id=actor.id,evidence_reference=evidence_reference.strip(),notes=notes.strip())
    db.add(row); db.flush(); _audit(db,request,actor,"COMPETENCY_RECORD","CompetencyRecord",row.id,f"{target.full_name}: {test_name} → {auth}"); db.commit(); return RedirectResponse("/quality?tab=competency",303)

@router.post("/case")
def case_create(request:Request,case_type:str=Form(...),title:str=Form(...),test_name:str=Form(""),method_name:str=Form(""),equipment_asset_id:str=Form(""),assigned_to_id:str=Form(""),priority:str=Form("NORMAL"),due_at:str=Form(""),scheme_name:str=Form(""),evaluation_criteria:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,QUALITY_WRITE); site=_site(db,user); typ=case_type.upper(); seq=db.query(QualityCase).filter(QualityCase.site_id==site.id).count()+1; number=f"{typ}-{datetime.utcnow():%Y}-{seq:04d}"
    target_id=_int(assigned_to_id)
    if typ in {'VALIDATION','VERIFICATION','ILC_PT'} and target_id:
        target=db.get(User,target_id)
        if not target or target.site_id!=site.id or not target.active or target.role!=Role.LAB_TECHNICIAN.value:
            raise ValueError('Validation / Verification / ILC tasks can be assigned only to an active laboratory technician at this site')
    row=QualityCase(site_id=site.id,case_number=number,case_type=typ,title=title.strip(),test_name=test_name.strip(),method_name=method_name.strip(),equipment_asset_id=_int(equipment_asset_id),assigned_to_id=target_id,priority=priority.upper(),due_at=_dt(due_at),scheme_name=scheme_name.strip(),evaluation_criteria=evaluation_criteria.strip(),created_by_id=user.id)
    db.add(row); db.flush(); _audit(db,request,user,"QUALITY_CASE_CREATE","QualityCase",row.id,f"Created {number}");
    if row.assigned_to_id: _notify(db,row.assigned_to_id,site.id,f"Assigned {typ}: {number}",title.strip(),"/control/my-quality-tasks",priority.upper(),"QUALITY")
    db.commit(); return RedirectResponse("/quality?tab=" + ("validation" if typ in {"VALIDATION","VERIFICATION"} else "ilc_pt" if typ=="ILC_PT" else "capa"),303)

@router.post("/case/{cid}/update")
def case_update(cid:int,request:Request,status:str=Form(...),raw_runs_json:str=Form(""),calculation_json:str=Form(""),root_cause:str=Form(""),corrective_action:str=Form(""),effectiveness_review:str=Form(""),evidence_reference:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,QUALITY_WRITE); site=_site(db,user); row=db.get(QualityCase,cid)
    if not row or row.site_id!=site.id: raise ValueError("Quality case not found")
    target=status.upper(); raw=raw_runs_json.strip() or row.raw_runs_json; calc=calculation_json.strip() or row.calculation_json
    if target in {"CLOSED","APPROVED"}:
        if row.case_type in {"VALIDATION","VERIFICATION"} and (raw in {"","[]"} or calc in {"","{}"}): raise ValueError("Validation/verification closure requires raw runs and calculation evidence")
        if row.case_type in {"CAPA","NCR"} and not ((root_cause or row.root_cause).strip() and (corrective_action or row.corrective_action).strip() and (effectiveness_review or row.effectiveness_review).strip()): raise ValueError("CAPA/NCR closure requires root cause, corrective action and effectiveness review")
        if row.case_type=="ILC_PT" and not ((evidence_reference or row.evidence_reference).strip() and row.evaluation_criteria.strip()): raise ValueError("ILC/PT closure requires scheme evidence and evaluation criteria")
        row.closed_at=datetime.utcnow(); row.reviewed_by_id=user.id
    row.status=target; row.raw_runs_json=raw; row.calculation_json=calc; row.root_cause=(root_cause or row.root_cause).strip(); row.corrective_action=(corrective_action or row.corrective_action).strip(); row.effectiveness_review=(effectiveness_review or row.effectiveness_review).strip(); row.evidence_reference=(evidence_reference or row.evidence_reference).strip()
    _audit(db,request,user,"QUALITY_CASE_UPDATE","QualityCase",row.id,f"{row.case_number} → {target}"); db.commit(); return RedirectResponse("/quality?tab=" + ("validation" if row.case_type in {"VALIDATION","VERIFICATION"} else "ilc_pt" if row.case_type=="ILC_PT" else "capa"),303)

@router.post("/work-pattern")
def work_pattern_save(request:Request,user_id:int=Form(...),name:str=Form("Standard"),weekdays:list[int]=Form(...),shift_start:str=Form("08:00"),shift_end:str=Form("16:00"),effective_from:str=Form(""),effective_to:str=Form(""),db:Session=Depends(get_db)):
    actor=require_user(request,db,{Role.SENIOR_CHEMIST.value,Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value}); site=_site(db,actor); target=db.get(User,user_id)
    if not target or target.site_id!=site.id or target.role!=Role.LAB_TECHNICIAN.value or not target.active: raise ValueError("Work patterns can be assigned only to active laboratory chemist/technician accounts at this site")
    days=sorted(set(int(x) for x in weekdays if 0<=int(x)<=6))
    if not days: raise ValueError("Select at least one operating weekday")
    if len(shift_start)!=5 or len(shift_end)!=5 or ':' not in shift_start or ':' not in shift_end: raise ValueError("Shift time must use HH:MM")
    row=db.query(StaffWorkPattern).filter_by(site_id=site.id,user_id=target.id).first()
    if not row:
        row=StaffWorkPattern(site_id=site.id,user_id=target.id,created_by_id=actor.id); db.add(row)
    row.name=name.strip()[:100] or "Standard"; row.weekdays_json=json.dumps(days); row.shift_start=shift_start; row.shift_end=shift_end; row.effective_from=_dt(effective_from); row.effective_to=_dt(effective_to); row.active=True
    db.flush(); _audit(db,request,actor,"WORK_PATTERN_SAVED","StaffWorkPattern",row.id,f"{target.full_name}: {row.name} {days} {shift_start}-{shift_end}"); db.commit(); return RedirectResponse('/control?tab=schedule',303)


@router.post("/schedule")
def schedule_create(request:Request,user_id:int=Form(...),entry_type:str=Form(...),start_at:str=Form(...),end_at:str=Form(...),status:str=Form("PLANNED"),shift_code:str=Form(""),notes:str=Form(""),db:Session=Depends(get_db)):
    actor=require_user(request,db,SENIOR_WRITE); site=_site(db,actor); start,end=_dt(start_at),_dt(end_at)
    if not start or not end or end<=start: raise ValueError("Schedule end must be after start")
    target=db.get(User,user_id)
    if not target or target.site_id!=site.id: raise ValueError("Employee is outside this laboratory site")
    conflicts=db.query(StaffAvailability).filter(StaffAvailability.user_id==user_id,StaffAvailability.status.in_(["APPROVED","CONFIRMED"]),StaffAvailability.start_at<end,StaffAvailability.end_at>start).count()
    if conflicts and status.upper() in {"APPROVED","CONFIRMED"}: raise ValueError("Schedule conflicts with an approved leave/shift/on-call entry")
    row=StaffAvailability(site_id=site.id,user_id=user_id,entry_type=entry_type.upper(),start_at=start,end_at=end,status=status.upper(),shift_code=shift_code.strip(),notes=notes.strip(),approved_by_id=actor.id if status.upper() in {"APPROVED","CONFIRMED"} else None,created_by_id=actor.id); db.add(row); db.flush(); _audit(db,request,actor,"STAFF_SCHEDULE_CREATE","StaffAvailability",row.id,f"{target.full_name}: {entry_type}"); db.commit(); return RedirectResponse("/control?tab=schedule",303)

@router.post("/result-rule")
def result_rule(request:Request,test_name:str=Form(...),method_name:str=Form(""),result_field:str=Form(...),unit:str=Form(""),equipment_id:str=Form(""),allowed_states:str=Form("NUMERIC,LTD"),detection_limit:str=Form(""),working_range_min:str=Form(""),working_range_max:str=Form(""),decimals:str=Form(""),rounding_rule:str=Form("SOURCE_CONTROLLED"),report_display_rule:str=Form(""),downstream_rule:str=Form(""),source_reference:str=Form(""),effective_revision:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,QUALITY_WRITE); site=_site(db,user)
    row=TechnicalResultRule(site_id=site.id,test_name=test_name.strip(),method_name=method_name.strip(),result_field=result_field.strip(),unit=unit.strip(),equipment_id=equipment_id.strip(),allowed_states=allowed_states.strip().upper(),detection_limit=_num(detection_limit),working_range_min=_num(working_range_min),working_range_max=_num(working_range_max),decimals=_int(decimals),rounding_rule=rounding_rule.strip().upper(),report_display_rule=report_display_rule.strip(),downstream_rule=downstream_rule.strip(),source_reference=source_reference.strip(),effective_revision=effective_revision.strip())
    db.add(row); db.flush(); _audit(db,request,user,"RESULT_RULE_CREATE","TechnicalResultRule",row.id,f"{test_name}/{result_field}"); db.commit(); return RedirectResponse("/quality?tab=qc",303)

@router.post("/troubleshooting")
def trouble_create(request:Request,test_name:str=Form(""),method_name:str=Form(""),equipment_asset_id:str=Form(""),workstation:str=Form(""),problem:str=Form(...),symptoms:str=Form(""),actions_taken:str=Form(""),safety_impact:str=Form(""),result_integrity_impact:str=Form(""),lessons:str=Form(""),return_to:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value,Role.SENIOR_CHEMIST.value,Role.QUALITY.value,Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value}); site=_site(db,user)
    row=TroubleshootingRecord(site_id=site.id,test_name=test_name.strip(),method_name=method_name.strip(),equipment_asset_id=_int(equipment_asset_id),workstation=workstation.strip(),problem=problem.strip(),symptoms=symptoms.strip(),actions_taken=actions_taken.strip(),safety_impact=safety_impact.strip(),result_integrity_impact=result_integrity_impact.strip(),lessons=lessons.strip(),status="SUBMITTED",created_by_id=user.id); db.add(row); db.flush(); _audit(db,request,user,"TROUBLESHOOTING_SUBMIT","TroubleshootingRecord",row.id,problem[:120]); db.commit()
    target=return_to if return_to in {"/troubleshooting","/improvement?tab=troubleshooting"} else "/troubleshooting"
    return RedirectResponse(target,303)

@router.post("/troubleshooting/{rid}/transition")
def trouble_transition(rid:int,request:Request,status:str=Form(...),root_cause:str=Form(""),return_to:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.SENIOR_CHEMIST.value,Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value}); site=_site(db,user); row=db.get(TroubleshootingRecord,rid)
    if not row or row.site_id!=site.id: raise ValueError("Troubleshooting record not found")
    target=status.upper()
    if target=="SENIOR_VERIFIED":
        if user.role==Role.SENIOR_CHEMIST.value and senior_responsibility(user)!=troubleshooting_domain(row):
            raise HTTPException(status_code=403,detail=f"This issue is routed to the {troubleshooting_domain(row).title()} Senior responsibility")
        if user.role not in {Role.SENIOR_CHEMIST.value,Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value}: raise ValueError("Senior verification required")
        row.senior_verified_by_id=user.id
    elif target=="PUBLISHED":
        if user.role not in {Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value} or not row.senior_verified_by_id: raise ValueError("Technical Manager approval requires prior Senior verification")
        row.technical_approved_by_id=user.id
    else: raise ValueError("Unsupported troubleshooting transition")
    row.status=target; row.root_cause=(root_cause or row.root_cause).strip(); _audit(db,request,user,"TROUBLESHOOTING_TRANSITION","TroubleshootingRecord",row.id,target); db.commit(); target_url=return_to if return_to in {"/troubleshooting","/improvement?tab=troubleshooting"} else "/improvement?tab=troubleshooting"; return RedirectResponse(target_url,303)

@router.post("/evidence")
async def evidence_upload(request:Request,evidence_type:str=Form(...),title:str=Form(...),sample_request_id:str=Form(""),quality_case_id:str=Form(""),equipment_asset_id:str=Form(""),method_name:str=Form(""),run_reference:str=Form(""),upload:UploadFile=File(...),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value,Role.SENIOR_CHEMIST.value,Role.QUALITY.value,Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value}); site=_site(db,user); data=await upload.read()
    if len(data)>20_000_000: raise ValueError("Controlled evidence file exceeds 20 MB")
    digest=hashlib.sha256(data).hexdigest(); safe=f"{digest[:16]}_{Path(upload.filename or 'evidence.bin').name.replace('/','_')}"; path=UPLOAD_DIR/safe; path.write_bytes(data)
    eqid=_int(equipment_asset_id); eq=db.get(EquipmentAsset,eqid) if eqid else None
    row=EvidenceRecord(site_id=site.id,sample_request_id=_int(sample_request_id),quality_case_id=_int(quality_case_id),equipment_asset_id=eqid,evidence_type=evidence_type.upper(),title=title.strip(),original_filename=upload.filename or "",stored_path=str(path),sha256=digest,method_name=method_name.strip(),equipment_id_snapshot=eq.equipment_id if eq else "",run_reference=run_reference.strip(),uploaded_by_id=user.id); db.add(row); db.flush(); _audit(db,request,user,"EVIDENCE_UPLOAD","EvidenceRecord",row.id,f"{row.evidence_type}: {title}"); db.commit(); return RedirectResponse("/quality?tab=evidence",303)

@router.post("/report")
def report_create(request:Request,sample_request_id:int=Form(...),report_number:str=Form(...),condition_status:str=Form(""),interpretation:str=Form(""),recommendation:str=Form(""),dga_requested:str=Form(""),corrosive_requested:str=Form(""),paper_requested:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,SENIOR_WRITE); site=_site(db,user); sample=db.get(SampleRequest,sample_request_id)
    if not sample or sample.site_id!=site.id: raise ValueError("Sample not found")
    assert_sample_period_open(db, sample)
    payload={"dga_requested":dga_requested=="1","corrosive_sulfur_requested":corrosive_requested=="1","paper_dp_requested":paper_requested=="1","asset_id":sample.asset_id,"sample_origin":sample.sample_origin,"sampling_point":sample.sampling_point}
    row=ControlledReport(site_id=site.id,sample_request_id=sample.id,report_number=report_number.strip(),condition_status=condition_status.strip().upper(),interpretation=interpretation.strip(),recommendation=recommendation.strip(),report_payload_json=json.dumps(payload),qr_token=secrets.token_urlsafe(24),reviewed_by_id=user.id,status="TECHNICAL_REVIEW"); db.add(row); db.flush(); _audit(db,request,user,"REPORT_CREATE","ControlledReport",row.id,row.report_number); db.commit(); return RedirectResponse("/control?tab=reports",303)

@router.post("/report/{rid}/approve")
def report_approve(rid:int,request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value}); site=_site(db,user); row=db.get(ControlledReport,rid)
    if not row or row.site_id!=site.id: raise ValueError("Report not found")
    assert_sample_period_open(db, row.sample)
    payload=json.loads(row.report_payload_json or "{}"); types={e.evidence_type for e in db.query(EvidenceRecord).filter(EvidenceRecord.sample_request_id==row.sample_request_id).all()}
    if payload.get("dga_requested") and "DGA_SOURCE" not in types: raise ValueError("DGA report approval requires original DGA source evidence")
    if payload.get("corrosive_sulfur_requested"):
        strip_pair={"CORROSIVE_FRONT","CORROSIVE_BACK"}.issubset(types)
        ccd_set={"CORROSIVE_COPPER","CORROSIVE_PAPER_INNER","CORROSIVE_PAPER_OUTER"}.issubset(types)
        if not (strip_pair or ccd_set):
            raise ValueError("Corrosive Sulfur / CCD approval requires either Front + Back strip evidence or Copper + Paper Inner + Paper Outer evidence")
    row.status="READY_FOR_LMS"; row.approved_by_id=user.id; row.approved_at=datetime.utcnow(); row.sample.status=SampleStatus.READY_FOR_LMS.value
    sync_case_from_sample(db, row.sample, user, note="Technical Manager approved report for LMS submission")
    _audit(db,request,user,"REPORT_APPROVE_READY_FOR_LMS","ControlledReport",row.id,row.report_number);
    for p in db.query(User).filter(User.site_id==site.id,User.active.is_(True),User.role.in_([Role.SENIOR_CHEMIST.value,Role.MANAGEMENT.value])).all(): _notify(db,p.id,site.id,f"{row.report_number} ready for LMS","Technical approval complete; awaiting LMS official release.","/control?tab=reports","HIGH","REPORT")
    db.commit(); return RedirectResponse("/control?tab=reports",303)

@router.post("/asset/{aid}/history")
def asset_history(aid:int,request:Request,event_type:str=Form(...),event_at:str=Form(...),report_number:str=Form(""),details:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,SENIOR_WRITE); asset=db.get(Asset,aid)
    if not asset: raise ValueError("Asset not found")
    row=AssetHistoryEvent(asset_id=aid,event_type=event_type.upper(),event_at=_dt(event_at) or datetime.utcnow(),report_number=report_number.strip(),details=details.strip(),created_by_id=user.id); db.add(row); db.flush(); _audit(db,request,user,"ASSET_HISTORY_ADD","Asset",aid,event_type); db.commit(); return RedirectResponse("/control?tab=assets",303)

@router.get("/api/summary")
def api_summary(request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,VIEW); site=_site(db,user); now=datetime.utcnow()
    return {"site":site.code,"equipment":{"total":db.query(EquipmentAsset).filter_by(site_id=site.id).count(),"blocked":db.query(EquipmentAsset).filter(EquipmentAsset.site_id==site.id,EquipmentAsset.status.in_(["OUT_OF_SERVICE","CALIBRATION_DUE","DEFECTIVE"])).count()},"quality":{"open":db.query(QualityCase).filter(QualityCase.site_id==site.id,~QualityCase.status.in_(["CLOSED","APPROVED"])).count()},"competency":{"active":db.query(CompetencyRecord).filter_by(site_id=site.id,active=True).count()},"schedule":{"active_now":db.query(StaffAvailability).filter(StaffAvailability.site_id==site.id,StaffAvailability.start_at<=now,StaffAvailability.end_at>=now).count()},"reports":{"ready_for_lms":db.query(ControlledReport).filter_by(site_id=site.id,status="READY_FOR_LMS").count()}}

@router.get("/my-availability")
def my_availability(request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value,Role.SENIOR_CHEMIST.value,Role.QUALITY.value,Role.TECHNICAL_MANAGER.value,Role.MANAGEMENT.value,Role.SYSTEM_ADMIN.value}); site=_site(db,user)
    rows=db.query(StaffAvailability).filter(StaffAvailability.site_id==site.id)
    if user.role==Role.LAB_TECHNICIAN.value: rows=rows.filter(StaffAvailability.user_id==user.id)
    rows=rows.order_by(StaffAvailability.start_at.desc()).limit(300).all()
    staff=db.query(User).filter(User.site_id==site.id,User.active.is_(True)).order_by(User.full_name).all()
    return templates.TemplateResponse("my_availability.html",{"request":request,"user":user,"site":site,"rows":rows,"staff":staff})

@router.post("/availability/request")
def availability_request(request:Request,start_at:str=Form(...),end_at:str=Form(...),notes:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value,Role.SENIOR_CHEMIST.value,Role.QUALITY.value,Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value}); site=_site(db,user); start,end=_dt(start_at),_dt(end_at)
    if not start or not end or end<=start: raise ValueError("Leave-plan end must be after start")
    row=StaffAvailability(site_id=site.id,user_id=user.id,entry_type="LEAVE",start_at=start,end_at=end,status="PENDING_SENIOR",notes=notes.strip(),created_by_id=user.id); db.add(row); db.flush(); _audit(db,request,user,"LEAVE_PLAN_REQUEST","StaffAvailability",row.id,"Annual leave planning request"); db.commit(); return RedirectResponse('/control/my-availability',303)

@router.post("/availability/{sid}/transition")
def availability_transition(sid:int,request:Request,decision:str=Form(...),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.SENIOR_CHEMIST.value,Role.TECHNICAL_MANAGER.value,Role.MANAGEMENT.value,Role.SYSTEM_ADMIN.value}); site=_site(db,user); row=db.get(StaffAvailability,sid)
    if not row or row.site_id!=site.id: raise ValueError("Availability record not found")
    decision=decision.upper()
    if decision=='REJECTED': row.status='REJECTED'; row.approved_by_id=user.id
    elif row.status=='PENDING_SENIOR' and user.role in {Role.SENIOR_CHEMIST.value,Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value}: row.status='PENDING_MANAGEMENT'; row.approved_by_id=user.id
    elif row.status=='PENDING_MANAGEMENT' and user.role in {Role.MANAGEMENT.value,Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value}: row.status='APPROVED_FOR_ANNUAL_PLAN'; row.approved_by_id=user.id
    elif row.status=='APPROVED_FOR_ANNUAL_PLAN' and decision=='HR_CONFIRMED' and user.role in {Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value}: row.status='CONFIRMED'; row.approved_by_id=user.id
    else: raise ValueError("This role cannot perform the requested leave-plan transition")
    _audit(db,request,user,"LEAVE_PLAN_TRANSITION","StaffAvailability",row.id,row.status); db.commit(); return RedirectResponse('/control/my-availability',303)

@router.post("/schedule/generate-on-call")
def generate_on_call(request:Request,start_date:str=Form(...),end_date:str=Form(...),people_per_day:int=Form(2),db:Session=Depends(get_db)):
    from datetime import timedelta
    actor=require_user(request,db,SENIOR_WRITE); site=_site(db,actor); start=_dt(start_date+'T00:00'); end=_dt(end_date+'T23:59')
    if not start or not end or end<start or people_per_day<1 or people_per_day>5: raise ValueError("Invalid on-call generation window")
    people=db.query(User).filter(User.site_id==site.id,User.active.is_(True),User.role==Role.LAB_TECHNICIAN.value).all()
    if len(people)<people_per_day: raise ValueError("Not enough eligible laboratory staff for on-call roster")
    counts={p.id:db.query(StaffAvailability).filter(StaffAvailability.site_id==site.id,StaffAvailability.user_id==p.id,StaffAvailability.entry_type=='ON_CALL',StaffAvailability.status.in_(['APPROVED','CONFIRMED'])).count() for p in people}
    day=start
    while day.date()<=end.date():
        ds=day.replace(hour=0,minute=0,second=0); de=day.replace(hour=23,minute=59,second=0)
        eligible=[]
        for p in people:
            conflict=db.query(StaffAvailability).filter(StaffAvailability.site_id==site.id,StaffAvailability.user_id==p.id,StaffAvailability.entry_type.in_(['LEAVE','HOLIDAY']),StaffAvailability.status.in_(['APPROVED','CONFIRMED','APPROVED_FOR_ANNUAL_PLAN']),StaffAvailability.start_at<de,StaffAvailability.end_at>ds).first()
            if not conflict: eligible.append(p)
        eligible.sort(key=lambda p:(counts[p.id],p.full_name.lower()))
        if len(eligible)<people_per_day: raise ValueError(f"Not enough available staff for {day.date().isoformat()}")
        for p in eligible[:people_per_day]:
            db.add(StaffAvailability(site_id=site.id,user_id=p.id,entry_type='ON_CALL',start_at=ds,end_at=de,status='APPROVED',shift_code='HOLIDAY/ON_CALL',notes='System fair-roster suggestion approved by Senior',approved_by_id=actor.id,created_by_id=actor.id)); counts[p.id]+=1
        day+=timedelta(days=1)
    _audit(db,request,actor,'ON_CALL_ROSTER_GENERATED','StaffAvailability','',f'{start.date()} to {end.date()} · {people_per_day}/day'); db.commit(); return RedirectResponse('/control?tab=schedule',303)

@router.post("/schedule/generate-night")
def generate_night(request:Request,month:str=Form(...),people_per_day:int=Form(2),db:Session=Depends(get_db)):
    import calendar
    from datetime import timedelta
    actor=require_user(request,db,SENIOR_WRITE); site=_site(db,actor)
    try: year,mon=[int(x) for x in month.split('-')]
    except Exception: raise ValueError("Month must be YYYY-MM")
    if people_per_day not in {2,3}: raise ValueError("Night roster supports 2 or 3 employees per operating day")
    people=db.query(User).filter(User.site_id==site.id,User.active.is_(True),User.role==Role.LAB_TECHNICIAN.value).order_by(User.full_name).all()
    pattern_rows=db.query(StaffWorkPattern).filter(StaffWorkPattern.site_id==site.id,StaffWorkPattern.active.is_(True),StaffWorkPattern.user_id.in_([p.id for p in people] or [-1])).all()
    patterns={p.user_id:p for p in pattern_rows}
    if not patterns: raise ValueError("Configure employee Work Patterns before generating the Night Shift Roster")
    month_start=datetime(year,mon,1)
    next_month=datetime(year + (1 if mon==12 else 0), 1 if mon==12 else mon+1, 1)
    existing_roster=db.query(StaffAvailability).filter(StaffAvailability.site_id==site.id,StaffAvailability.entry_type=='SHIFT',StaffAvailability.shift_code.like('NIGHT / AUTO-ROSTER%'),StaffAvailability.start_at>=month_start,StaffAvailability.start_at<next_month).first()
    if existing_roster: raise ValueError('A generated Night Shift Roster already exists for this month; review/approve it instead of creating duplicates')
    configured_competency=db.query(CompetencyRecord).filter(CompetencyRecord.site_id==site.id,CompetencyRecord.active.is_(True),CompetencyRecord.user_id.in_([p.id for p in people] or [-1])).count()
    competent_ids=set()
    if configured_competency:
        for c in db.query(CompetencyRecord).filter(CompetencyRecord.site_id==site.id,CompetencyRecord.active.is_(True),CompetencyRecord.authorization.in_(['INDEPENDENT','SUPERVISED'])).all():
            if c.user_id in {p.id for p in people} and (c.expires_at is None or c.expires_at>=datetime.utcnow()): competent_ids.add(c.user_id)
    counts={p.id:db.query(StaffAvailability).filter(StaffAvailability.site_id==site.id,StaffAvailability.user_id==p.id,StaffAvailability.entry_type=='SHIFT',StaffAvailability.shift_code.like('NIGHT%'),StaffAvailability.start_at>=month_start).count() for p in people}
    created=0
    for daynum in range(1,calendar.monthrange(year,mon)[1]+1):
        day=datetime(year,mon,daynum)
        ds=day.replace(hour=14,minute=0,second=0); de=day.replace(hour=22,minute=0,second=0)
        eligible=[]
        for person in people:
            pattern=patterns.get(person.id)
            if not pattern: continue
            if configured_competency and person.id not in competent_ids: continue
            try: workdays=set(json.loads(pattern.weekdays_json or '[]'))
            except Exception: workdays=set()
            if day.weekday() not in workdays: continue
            if pattern.effective_from and day < pattern.effective_from.replace(hour=0,minute=0,second=0): continue
            if pattern.effective_to and day > pattern.effective_to.replace(hour=23,minute=59,second=59): continue
            conflict=db.query(StaffAvailability).filter(StaffAvailability.site_id==site.id,StaffAvailability.user_id==person.id,StaffAvailability.entry_type.in_(['LEAVE','HOLIDAY','TRAINING','UNAVAILABLE']),StaffAvailability.status.in_(['APPROVED','CONFIRMED','APPROVED_FOR_ANNUAL_PLAN']),StaffAvailability.start_at<de,StaffAvailability.end_at>ds).first()
            if not conflict: eligible.append(person)
        if not eligible: continue
        eligible.sort(key=lambda p:(counts[p.id],p.full_name.lower()))
        if len(eligible)<people_per_day: raise ValueError(f"Not enough available, on-pattern laboratory staff for {day.date().isoformat()}")
        for person in eligible[:people_per_day]:
            db.add(StaffAvailability(site_id=site.id,user_id=person.id,entry_type='SHIFT',start_at=ds,end_at=de,status='PLANNED',shift_code='NIGHT / AUTO-ROSTER',notes='Generated from Work Pattern + availability' + (' + competency gate' if configured_competency else ' · competency gate activates when Quality master data is configured'),approved_by_id=None,created_by_id=actor.id)); counts[person.id]+=1; created+=1
    if created==0: raise ValueError("No roster entries were created. Check Work Patterns and availability for the selected month")
    _audit(db,request,actor,'NIGHT_ROSTER_GENERATED','StaffAvailability','',f'{month} · {people_per_day}/operating day · work-pattern/availability/competency aware · pending Senior approval'); db.commit(); return RedirectResponse('/control?tab=schedule',303)

@router.post('/schedule/approve-night')
def approve_night(request:Request,month:str=Form(...),db:Session=Depends(get_db)):
    import calendar
    actor=require_user(request,db,SENIOR_WRITE); site=_site(db,actor)
    try: year,mon=[int(x) for x in month.split('-')]
    except Exception: raise ValueError('Month must be YYYY-MM')
    start=datetime(year,mon,1); end=datetime(year,mon,calendar.monthrange(year,mon)[1],23,59,59)
    rows=db.query(StaffAvailability).filter(StaffAvailability.site_id==site.id,StaffAvailability.entry_type=='SHIFT',StaffAvailability.shift_code.like('NIGHT / AUTO-ROSTER%'),StaffAvailability.start_at>=start,StaffAvailability.start_at<=end,StaffAvailability.status=='PLANNED').all()
    if not rows: raise ValueError('No pending generated Night Shift Roster exists for this month')
    for row in rows:
        row.status='APPROVED'; row.approved_by_id=actor.id; row.notes=(row.notes or '') + ' · reviewed and approved by Senior Chemist'
    _audit(db,request,actor,'NIGHT_ROSTER_APPROVED','StaffAvailability','',f'{month} · {len(rows)} planned shifts approved'); db.commit()
    return RedirectResponse('/control?tab=schedule',303)


_DGA_ALIASES={
    'H2':['h2','hydrogen'],'O2':['o2','oxygen'],'N2':['n2','nitrogen'],'CH4':['ch4','methane'],'CO':['co','carbon monoxide'],'CO2':['co2','carbon dioxide'],
    'C2H4':['c2h4','ethylene'],'C2H6':['c2h6','ethane'],'C2H2':['c2h2','acetylene']}

def _parse_dga_bytes(filename:str,data:bytes)->dict:
    import csv, io, re, zipfile, xml.etree.ElementTree as ET
    rows=[]; lower=filename.lower()
    if lower.endswith('.xlsx'):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            shared=[]
            if 'xl/sharedStrings.xml' in z.namelist():
                root=ET.fromstring(z.read('xl/sharedStrings.xml')); ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
                shared=[''.join(t.text or '' for t in si.findall('.//m:t',ns)) for si in root.findall('.//m:si',ns)]
            sheet=next((n for n in z.namelist() if n.startswith('xl/worksheets/sheet') and n.endswith('.xml')),None)
            if not sheet: raise ValueError('XLSX has no worksheet')
            root=ET.fromstring(z.read(sheet)); ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            for r in root.findall('.//m:row',ns):
                vals=[]
                for c in r.findall('m:c',ns):
                    v=c.find('m:v',ns); val='' if v is None else (shared[int(v.text)] if c.get('t')=='s' and v.text else v.text or '')
                    vals.append(val)
                if vals: rows.append(vals)
    else:
        text=data.decode('utf-8-sig',errors='replace'); dialect=csv.excel_tab if '\t' in text[:1000] else csv.excel
        rows=list(csv.reader(io.StringIO(text),dialect=dialect))
    found={}
    flat=[]
    for row in rows:
        for i,cell in enumerate(row): flat.append((str(cell).strip(),row,i))
    for gas,aliases in _DGA_ALIASES.items():
        for cell,row,i in flat:
            norm=re.sub(r'[^a-z0-9]+',' ',cell.lower()).strip()
            if any(a==norm or a in norm for a in aliases):
                candidates=row[i+1:i+4]+row[max(0,i-3):i]
                for cand in candidates:
                    m=re.search(r'[-+]?\d+(?:\.\d+)?',str(cand))
                    if m: found[gas]=float(m.group()); break
            if gas in found: break
    return {'gases':found,'recognized':len(found),'required':list(_DGA_ALIASES),'complete':len(found)==9}


@router.post('/dga/import')
async def dga_import(request:Request,sample_request_id:int=Form(...),equipment_asset_id:int=Form(...),method_name:str=Form(...),run_reference:str=Form(''),upload:UploadFile=File(...),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value,Role.SYSTEM_ADMIN.value}); site=_site(db,user); sample=db.get(SampleRequest,sample_request_id); eq=db.get(EquipmentAsset,equipment_asset_id)
    if not sample or sample.site_id!=site.id or not eq or eq.site_id!=site.id or eq.workstation!='DGA': raise ValueError('DGA import requires a valid site sample and DGA equipment asset')
    data=await upload.read(); parsed=_parse_dga_bytes(upload.filename or '',data)
    if not parsed['recognized']: raise ValueError('No DGA gas fields were recognized; preserve the source as evidence and configure the exact instrument export mapping during technical review')
    digest=hashlib.sha256(data).hexdigest(); safe=f"{digest[:16]}_{Path(upload.filename or 'dga.bin').name.replace('/','_')}"; path=UPLOAD_DIR/safe; path.write_bytes(data)
    row=EvidenceRecord(site_id=site.id,sample_request_id=sample.id,equipment_asset_id=eq.id,evidence_type='DGA_SOURCE',title=f'DGA import {sample.request_number}',original_filename=upload.filename or '',stored_path=str(path),sha256=digest,method_name=method_name.strip(),equipment_id_snapshot=eq.equipment_id,run_reference=run_reference.strip(),parsed_json=json.dumps(parsed),status='PENDING_CONFIRMATION',uploaded_by_id=user.id); db.add(row); db.flush(); _audit(db,request,user,'DGA_IMPORT_PREVIEW','EvidenceRecord',row.id,f"Recognized {parsed['recognized']}/9 gases"); db.commit(); return JSONResponse({'evidence_id':row.id,'status':row.status,'preview':parsed})

@router.post('/dga/{evidence_id}/confirm')
def dga_confirm(evidence_id:int,request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value,Role.SYSTEM_ADMIN.value}); site=_site(db,user); row=db.get(EvidenceRecord,evidence_id)
    if not row or row.site_id!=site.id or row.evidence_type!='DGA_SOURCE' or row.status!='PENDING_CONFIRMATION': raise ValueError('Pending DGA import not found')
    parsed=json.loads(row.parsed_json or '{}')
    if not parsed.get('recognized'): raise ValueError('DGA import contains no recognized gases')
    row.status='CONTROLLED'; _audit(db,request,user,'DGA_IMPORT_CONFIRMED','EvidenceRecord',row.id,f"Confirmed {parsed.get('recognized')}/9 parsed gases"); db.commit(); return {'status':'CONTROLLED','evidence_id':row.id,'preview':parsed}

@router.get('/report/{rid}/preview')
def report_preview(rid:int,request:Request,db:Session=Depends(get_db)):
    from ..services.lab_operations import get_operations_state
    user=require_user(request,db,VIEW|{Role.CLIENT.value}); row=db.get(ControlledReport,rid)
    if not row: raise ValueError('Report not found')
    if user.role==Role.CLIENT.value:
        if user.client_id!=row.sample.client_id:
            raise HTTPException(status_code=404, detail='Report not found')
        if row.sample.status!=SampleStatus.REPORT_RELEASED.value or row.status!=SampleStatus.REPORT_RELEASED.value:
            raise HTTPException(status_code=404, detail='Report is not yet officially issued')
    from ..services.technical_assessment import assess_sample
    site=db.get(Site,row.site_id); _,ops=get_operations_state(db,site)
    sample_keys={str(row.sample.request_number),str(row.sample.id)}
    if row.sample.lms_number: sample_keys.add(str(row.sample.lms_number))
    results=[r for r in ops.get('results',[]) if str(r.get('sample') or r.get('sample_id') or '') in sample_keys]
    buckets={'dga':[],'furan':[],'paper':[],'oil':[],'additives':[],'corrosion':[],'other':[]}
    for result in results:
        name=str(result.get('test') or result.get('display_test') or '').lower()
        if any(k in name for k in ['dga:','hydrogen','methane','ethylene','ethane','acetylene','carbon monoxide','carbon dioxide','tdcg','tcg','oxygen','nitrogen']): key='dga'
        elif any(k in name for k in ['direct dp','dp-value of paper','dp value of paper','degree of polymerization','paper sample']): key='paper'
        elif any(k in name for k in ['furan','2fal','2-fal','2fol','2acf','5hmf','5mef','paper life','indirect dp']): key='furan'
        elif any(k in name for k in ['dbds','bht','toluene','passivator','irgamet','tta','bta','pcb']): key='additives'
        elif any(k in name for k in ['corros','tarnish','ccd','copper strip','potentially corrosive']): key='corrosion'
        elif any(k in name for k in ['acid','tan','peroxide','mercaptan','rsh','h2s','water','ift','interfacial','breakdown','bdv','power factor','dissipation','resistivity','color','appearance','oil quality','flash','viscosity','density','pour point','particle','ph']): key='oil'
        else: key='other'
        buckets[key].append(result)
    buckets=_polish_report_buckets(buckets)
    evidence=db.query(EvidenceRecord).filter(EvidenceRecord.sample_request_id==row.sample_request_id).order_by(EvidenceRecord.created_at).all()
    dga_evidence=[e for e in evidence if e.evidence_type in {'DGA_SOURCE','DGA_CHROMATOGRAM'}]
    corrosive_evidence=[e for e in evidence if e.evidence_type.startswith('CORROSIVE_')]
    paper_evidence=[e for e in evidence if e.evidence_type.startswith('PAPER_')]
    other_evidence=[e for e in evidence if e not in dga_evidence and e not in corrosive_evidence and e not in paper_evidence]
    history=db.query(AssetHistoryEvent).filter(AssetHistoryEvent.asset_id==row.sample.asset_id).order_by(AssetHistoryEvent.event_at.desc()).limit(20).all()
    previous=db.query(ControlledReport).join(SampleRequest,ControlledReport.sample_request_id==SampleRequest.id).filter(SampleRequest.asset_id==row.sample.asset_id,ControlledReport.id!=row.id).order_by(ControlledReport.created_at.desc()).limit(3).all()
    try: assessment=assess_sample(db,row.sample)
    except Exception: assessment={}
    try: report_flags=json.loads(row.report_payload_json or '{}')
    except Exception: report_flags={}
    return templates.TemplateResponse('controlled_report_preview.html',{'request':request,'user':user,'report':row,'sample':row.sample,'asset':row.sample.asset,**buckets,'evidence':evidence,'dga_evidence':dga_evidence,'corrosive_evidence':corrosive_evidence,'paper_evidence':paper_evidence,'other_evidence':other_evidence,'history':history,'previous':previous,'assessment':assessment,'report_flags':report_flags})

@router.get('/report/{rid}/qr.png')
def report_qr(rid:int,request:Request,db:Session=Depends(get_db)):
    import io, qrcode
    from fastapi.responses import Response
    row=db.get(ControlledReport,rid)
    if not row: raise ValueError('Report not found')
    url=str(request.base_url).rstrip('/')+f'/verify/report/{row.qr_token}'
    img=qrcode.make(url); buf=io.BytesIO(); img.save(buf,format='PNG'); return Response(buf.getvalue(),media_type='image/png',headers={'Cache-Control':'no-store'})

def _routine_asset_matches(task_key: str, eq: EquipmentAsset) -> bool:
    """Tie asset-specific routine QC evidence to the correct equipment family."""
    key=(task_key or '').strip().lower()
    hay=' '.join([eq.name or '', eq.workstation or '', eq.test_method or '', eq.notes or '']).lower()
    if key == 'balances':
        return 'balance' in hay
    if key == 'electrode':
        return any(token in hay for token in ('electrode','titrando','titrator'))
    return True


def _quality_case_execution_view(row: QualityCase) -> dict:
    try:
        protocol=json.loads(row.protocol_json or '{}')
    except Exception:
        protocol={}
    default_runs=1 if row.case_type=='ILC_PT' else 3
    requested=protocol.get('required_runs',protocol.get('run_count',default_runs)) if isinstance(protocol,dict) else default_runs
    try: run_count=max(1,min(5,int(requested)))
    except (TypeError,ValueError): run_count=default_runs
    required_min=run_count
    try:
        raw=json.loads(row.raw_runs_json or '[]')
    except Exception:
        raw=[]
    run_values=[]
    if isinstance(raw,list):
        for item in raw[:run_count]:
            value=item.get('value') if isinstance(item,dict) else item
            try: run_values.append(float(value))
            except (TypeError,ValueError): run_values.append('')
    try:
        calc=json.loads(row.calculation_json or '{}')
    except Exception:
        calc={}
    if not isinstance(calc,dict): calc={}
    def fmt(value):
        if value in (None,''): return '—'
        try: return f'{float(value):.6g}'
        except (TypeError,ValueError): return str(value)
    if calc:
        calc=dict(calc)
        calc['mean_fmt']=fmt(calc.get('mean'))
        calc['stdev_fmt']=fmt(calc.get('stdev'))
        calc['rsd_fmt']=fmt(calc.get('rsd_pct'))
        calc['range_fmt']=fmt(calc.get('range'))
    return {'case':row,'run_count':run_count,'required_min':required_min,'run_values':run_values,'calculation':calc}


def _active_quality_distribution(payload: dict, now: datetime) -> dict | None:
    """Latest published revision for the calendar month that is actually active now."""
    month_key = now.strftime('%Y-%m')
    rows = [
        row for row in payload.get('qualityDistributions', [])
        if isinstance(row, dict) and str(row.get('month') or '') == month_key
    ]
    if not rows:
        return None
    return max(rows, key=lambda row: int(row.get('revision') or 1))


def _routine_period_state(assignment: dict, now: datetime) -> str:
    """OPEN / OVERDUE / FUTURE for an assignment in the active calendar month."""
    try:
        start_day = int(assignment.get('start_day') or 1)
        end_day = int(assignment.get('end_day') or start_day)
    except (TypeError, ValueError):
        return 'OPEN'
    if now.day < start_day:
        return 'FUTURE'
    if now.day > end_day:
        return 'OVERDUE'
    return 'OPEN'


def _routine_previous_assignments(distribution: dict, assignment: dict) -> list[dict]:
    """Earlier windows of the same controlled check, ordered by start day."""
    task_key = str(assignment.get('task_key') or '')
    try:
        current_start = int(assignment.get('start_day') or 1)
    except (TypeError, ValueError):
        current_start = 1
    rows=[]
    for row in distribution.get('assignments', []):
        if not isinstance(row, dict) or str(row.get('task_key') or '') != task_key:
            continue
        try: row_start = int(row.get('start_day') or 1)
        except (TypeError, ValueError): row_start = 1
        if row_start < current_start:
            rows.append(row)
    return sorted(rows, key=lambda row: int(row.get('start_day') or 1))


def _routine_sequence_ready(distribution: dict, assignment: dict, event_map: dict[str, dict]) -> bool:
    """Do not let a Chemist jump over an unfinished earlier QC window."""
    return all(str(row.get('id') or '') in event_map for row in _routine_previous_assignments(distribution, assignment))


@router.get('/my-quality-tasks')
def my_quality_tasks(request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value}); site=_site(db,user)
    cases=db.query(QualityCase).filter(QualityCase.site_id==site.id,QualityCase.assigned_to_id==user.id,QualityCase.case_type.in_(['VALIDATION','VERIFICATION','ILC_PT'])).order_by(QualityCase.due_at,QualityCase.created_at.desc()).all()
    rows=[_quality_case_execution_view(row) for row in cases]
    state,payload=get_operations_state(db,site)
    now=datetime.utcnow()
    current=_active_quality_distribution(payload,now)
    routine=[]; completed=[]
    analytical_ownership=[]
    event_map={}
    for ev in payload.get('qualityTaskEvents',[]):
        aid=str(ev.get('assignment_id') or '')
        if aid and (aid not in event_map or str(ev.get('completed_at') or '')>str(event_map[aid].get('completed_at') or '')): event_map[aid]=ev
    if current:
        for owner in current.get('analytical_ownership',[]):
            if user.id in {int(owner.get('primary_user_id') or 0), int(owner.get('backup_user_id') or 0)}:
                analytical_ownership.append({'owner':owner,'assigned_as':'Primary' if int(owner.get('primary_user_id') or 0)==user.id else 'Backup'})
        try: year,month=[int(x) for x in str(current.get('month') or '').split('-')]
        except Exception: year,month=now.year,now.month
        for a in current.get('assignments',[]):
            primary=int(a.get('primary_user_id') or 0)==user.id
            backup=int(a.get('backup_user_id') or 0)==user.id
            if not (primary or backup):
                continue
            try: due_label=datetime(year,month,int(a.get('end_day') or 1)).strftime('%d %b %Y')
            except Exception: due_label=str(a.get('period_label') or 'Current period')
            ev=event_map.get(str(a.get('id')))
            period_state=_routine_period_state(a,now)
            sequence_ready=_routine_sequence_ready(current,a,event_map)
            view={
                'assignment':a,'event':ev,'assigned_as':'Primary' if primary else 'Backup',
                'due_label':due_label,'asset_label':str(a.get('asset_label') or a.get('equipment_id') or '').strip(),
                'period_state':period_state,'sequence_ready':sequence_ready,
                'can_record':(ev is None and period_state in {'OPEN','OVERDUE'} and sequence_ready),
            }
            if ev:
                completed.append(view)
            elif period_state!='FUTURE':
                routine.append(view)
    equipment=db.query(EquipmentAsset).filter(EquipmentAsset.site_id==site.id,EquipmentAsset.active.is_(True)).order_by(EquipmentAsset.equipment_id).all()
    for item in routine+completed:
        key=str(item['assignment'].get('task_key') or '')
        item['equipment_options']=[eq for eq in equipment if _routine_asset_matches(key,eq)] if key in {'balances','electrode'} else []
    routine.sort(key=lambda item:(0 if item['period_state']=='OVERDUE' else 1,int(item['assignment'].get('end_day') or 99),str(item['assignment'].get('task') or '')))
    completed.sort(key=lambda item:str(item['event'].get('completed_at') or ''),reverse=True)
    return templates.TemplateResponse('my_quality_tasks.html',{
        'request':request,'user':user,'rows':rows,'routine_tasks':routine,'completed_routine_tasks':completed[:8],
        'quality_month':current.get('month') if current else '',
        'analytical_ownership': analytical_ownership,
        'active_day':now.day,
    })


@router.post('/my-quality-tasks/routine/{assignment_id}')
def submit_routine_quality_task(assignment_id:str,request:Request,status:str=Form(...),note:str=Form(''),equipment_asset_id:str=Form(''),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value}); site=_site(db,user); state,payload=get_operations_state(db,site)
    now=datetime.utcnow(); current=_active_quality_distribution(payload,now)
    if not current: raise ValueError('No published routine QC distribution is available for the active month')
    assignment=next((a for a in current.get('assignments',[]) if str(a.get('id'))==assignment_id),None)
    if not assignment: raise ValueError('Routine QC assignment not found in the active month')
    if user.id not in {int(assignment.get('primary_user_id') or 0),int(assignment.get('backup_user_id') or 0)}: raise HTTPException(status_code=403,detail='This routine QC check is not assigned to the active employee')
    event_map={str(ev.get('assignment_id') or ''):ev for ev in payload.get('qualityTaskEvents',[]) if isinstance(ev,dict) and ev.get('assignment_id')}
    if assignment_id in event_map: raise ValueError('This QC assignment has already been recorded')
    period_state=_routine_period_state(assignment,now)
    if period_state=='FUTURE': raise ValueError('This QC period is not open yet')
    if not _routine_sequence_ready(current,assignment,event_map):
        raise ValueError('Complete the earlier period for this QC check before recording the next period')
    clean=status.strip().upper()
    if clean not in {'PASS','ATTENTION','FAIL'}: raise ValueError('Routine QC status must be PASS, ATTENTION or FAIL')
    if clean in {'ATTENTION','FAIL'} and not note.strip(): raise ValueError('A note is required for ATTENTION or FAIL')
    asset_required=str(assignment.get('task_key') or '') in {'balances','electrode'}
    eq=None
    if equipment_asset_id.strip():
        try: eq=db.get(EquipmentAsset,int(equipment_asset_id))
        except (TypeError,ValueError): eq=None
        if not eq or eq.site_id!=site.id or not eq.active: raise ValueError('Selected QC equipment is not available in the active site master')
    if asset_required and not eq: raise ValueError('Select the exact Equipment ID checked before recording this QC task')
    if asset_required and not _routine_asset_matches(str(assignment.get('task_key') or ''),eq):
        raise ValueError('The selected Equipment ID does not match this QC check. Use the verified asset from Equipment Master.')
    payload.setdefault('qualityTaskEvents',[]).append({'id':f"QTE-{secrets.token_hex(6)}",'distribution_id':current.get('id'),'assignment_id':assignment_id,'status':clean,'note':note.strip(),'equipment_asset_id':eq.id if eq else None,'equipment_id':eq.equipment_id if eq else '','equipment_name':eq.name if eq else '','completed_by':user.full_name,'completed_by_user_id':user.id,'completed_at':datetime.utcnow().isoformat()})
    save_operations_state(db,state,payload,actor=user); _audit(db,request,user,'ROUTINE_QC_RECORDED','QualityDistribution',assignment_id,f"{assignment.get('task')} → {clean}"); db.commit(); return RedirectResponse('/control/my-quality-tasks',303)

@router.post('/my-quality-tasks/{cid}/submit')
async def submit_quality_task(
    cid:int,request:Request,
    run_1:str=Form(''),run_2:str=Form(''),run_3:str=Form(''),run_4:str=Form(''),run_5:str=Form(''),
    raw_runs_json:str=Form(''),evidence_reference:str=Form(''),evidence_file:UploadFile|None=File(None),
    db:Session=Depends(get_db)
):
    import statistics
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value}); site=_site(db,user); row=db.get(QualityCase,cid)
    if not row or row.site_id!=site.id or row.assigned_to_id!=user.id: raise ValueError('Quality task is not assigned to this employee')
    view=_quality_case_execution_view(row)
    values=[]
    supplied=[run_1,run_2,run_3,run_4,run_5][:view['run_count']]
    for idx,value in enumerate(supplied,1):
        if str(value).strip()=='': continue
        try: values.append(float(value))
        except (TypeError,ValueError): raise ValueError(f'Run {idx} must be numeric')
    # Backward-compatible parser for an older controlled client; never exposed in the Chemist UI.
    if not values and raw_runs_json.strip():
        try: legacy=json.loads(raw_runs_json)
        except Exception: raise ValueError('Legacy raw runs are not valid JSON')
        if isinstance(legacy,list):
            for item in legacy[:view['run_count']]:
                value=item.get('value') if isinstance(item,dict) else item
                try: values.append(float(value))
                except (TypeError,ValueError): pass
    if len(values)<view['required_min']:
        raise ValueError(f"{row.case_type.replace('_',' ')} requires {view['required_min']} numerical run(s) before submission")
    calc={'n':len(values),'mean':sum(values)/len(values),'min':min(values),'max':max(values),'range':max(values)-min(values)}
    if len(values)>1:
        calc['stdev']=statistics.stdev(values); calc['rsd_pct']=(calc['stdev']/calc['mean']*100) if calc['mean'] else None
    row.raw_runs_json=json.dumps(values); row.calculation_json=json.dumps(calc); row.evidence_reference=evidence_reference.strip()
    if evidence_file and evidence_file.filename:
        data=await evidence_file.read()
        if len(data)>20_000_000: raise ValueError('Controlled evidence file exceeds 20 MB')
        digest=hashlib.sha256(data).hexdigest(); safe=f"{digest[:16]}_{Path(evidence_file.filename or 'evidence.bin').name.replace('/','_')}"; path=UPLOAD_DIR/safe; path.write_bytes(data)
        eq=row.equipment
        evidence_type='ILC_PT' if row.case_type=='ILC_PT' else 'VALIDATION'
        evidence=EvidenceRecord(site_id=site.id,quality_case_id=row.id,equipment_asset_id=row.equipment_asset_id,evidence_type=evidence_type,title=f'{row.case_number} execution evidence',original_filename=evidence_file.filename or '',stored_path=str(path),sha256=digest,method_name=row.method_name or '',equipment_id_snapshot=eq.equipment_id if eq else '',run_reference=evidence_reference.strip(),uploaded_by_id=user.id)
        db.add(evidence)
        if not row.evidence_reference: row.evidence_reference=evidence_file.filename or ''
    row.status='QUALITY_REVIEW'; _audit(db,request,user,'QUALITY_TASK_SUBMITTED','QualityCase',row.id,f'{row.case_number} returned to Quality')
    for q in db.query(User).filter(User.site_id==row.site_id,User.active.is_(True),User.role.in_([Role.QUALITY.value,Role.TECHNICAL_MANAGER.value])).all(): _notify(db,q.id,row.site_id,f'{row.case_number} ready for Quality review',row.title,'/quality?tab=validation','HIGH','QUALITY')
    db.commit(); return RedirectResponse('/control/my-quality-tasks',303)

@router.get('/daily-brief')
def daily_brief(request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,INTERNAL_ROLES)
    brief=build_daily_brief(db,user)
    role_name=ROLE_REVIEW_MATRIX.get(user.role,{}).get('name',user.job_title or user.role.replace('_',' ').title())
    return templates.TemplateResponse('daily_brief.html',{'request':request,'user':user,'brief':brief,'role_name':role_name})

@router.get('/notifications')
def notifications(request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,{r.value for r in Role if r.value!='client'}); rows=db.query(Notification).filter(Notification.user_id==user.id).order_by(Notification.created_at.desc()).limit(200).all(); return templates.TemplateResponse('notifications.html',{'request':request,'user':user,'rows':rows})

@router.post('/notifications/{nid}/read')
def notification_read(nid:int,request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,{r.value for r in Role if r.value!='client'}); row=db.get(Notification,nid)
    if not row or row.user_id!=user.id: raise ValueError('Notification not found')
    row.read_at=datetime.utcnow(); db.commit(); return RedirectResponse('/control/notifications',303)
