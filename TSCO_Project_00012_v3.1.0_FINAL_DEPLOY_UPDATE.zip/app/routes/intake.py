from __future__ import annotations

from datetime import datetime
from io import BytesIO
from pathlib import Path

from PIL import Image, UnidentifiedImageError
from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from fastapi.responses import RedirectResponse
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import (
    Asset, Client, CommercialAttachment, DataQualityIssue, PurchaseOrder, Quotation, Role, SamplePhoto,
    SampleRequest, SampleStatus, Site,
)
from ..security import require_user
from ..services.workflow import add_event, register_in_lms
from ..services.audit import add_audit
from ..services.scope import can_access_site
from ..services.identifiers import next_request_identifiers
from ..services.barcodes import generate_assets
from ..services.lab_operations import package_catalog, sync_sample_to_operations
from ..services.commercial import resolve_handover_case, require_complete_handover, link_sample, sync_case_from_sample
from ..services.month_close import assert_site_period_open, assert_sample_period_open
from ..storage import BARCODE_DIR, UPLOAD_DIR

router = APIRouter(prefix="/intake", tags=["sample intake and distribution"])
ALLOWED = {Role.DATA_ENTRY.value, Role.SYSTEM_ADMIN.value}
MAX_DIRECT_DOCUMENT_BYTES = 10_000_000


def _optional_int(value: str, label: str) -> int | None:
    clean = (value or "").strip()
    if not clean:
        return None
    if not clean.isdigit():
        raise ValueError(f"{label} is invalid")
    return int(clean)


def _safe_direct_document(upload: UploadFile | None) -> tuple[bytes, str, str] | None:
    if upload is None or not upload.filename:
        return None
    raw = upload.file.read(MAX_DIRECT_DOCUMENT_BYTES + 1)
    if len(raw) > MAX_DIRECT_DOCUMENT_BYTES:
        raise ValueError("Client submission document must be 10 MB or smaller")
    content_type = (upload.content_type or "").lower()
    suffix = Path(upload.filename).suffix.lower()
    if content_type == "application/pdf" or suffix == ".pdf":
        if not raw.startswith(b"%PDF-"):
            raise ValueError("Uploaded PDF is invalid")
        return raw, ".pdf", Path(upload.filename).name[:220]
    if content_type.startswith("image/") or suffix in {".jpg", ".jpeg", ".png", ".webp"}:
        try:
            with Image.open(BytesIO(raw)) as image:
                image.verify()
                fmt = (image.format or "").upper()
        except (UnidentifiedImageError, OSError, SyntaxError, ValueError):
            raise ValueError("Client submission image is invalid or corrupt")
        ext = {"JPEG": ".jpg", "PNG": ".png", "WEBP": ".webp"}.get(fmt)
        if not ext:
            raise ValueError("Client submission image must be JPEG, PNG or WebP")
        return raw, ext, Path(upload.filename).name[:220]
    raise ValueError("Client submission document must be PDF, JPEG, PNG or WebP")


def _site_for_user(db: Session, user) -> Site:
    site = db.get(Site, user.site_id) if user.site_id else db.scalar(select(Site).where(Site.code == "DMM"))
    if not site or not site.active:
        raise ValueError("An active laboratory site is required")
    return site


@router.get("")
def queue(request: Request, q: str = "", view: str = "incoming", db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    site = _site_for_user(db, user)
    stmt = select(SampleRequest).order_by(SampleRequest.submitted_at.desc(), SampleRequest.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        stmt = stmt.where(SampleRequest.site_id == user.site_id)
    view = (view or "incoming").strip().lower()
    view_statuses = {
        "incoming": [SampleStatus.SUBMITTED.value, SampleStatus.RETURNED.value, SampleStatus.ACCEPTED.value],
        "receiving": [SampleStatus.AWAITING_RECEIPT.value],
        "distribution": [SampleStatus.RECEIVED.value],
        "released": [SampleStatus.READY_FOR_LAB.value],
    }
    if view in view_statuses:
        stmt = stmt.where(SampleRequest.status.in_(view_statuses[view]))
    elif view != "all":
        view = "incoming"
        stmt = stmt.where(SampleRequest.status.in_(view_statuses[view]))
    if q.strip():
        term = f"%{q.strip()}%"
        stmt = stmt.where(
            or_(
                SampleRequest.request_number.ilike(term),
                SampleRequest.barcode_value.ilike(term),
                SampleRequest.lms_number.ilike(term),
                SampleRequest.client_sample_reference.ilike(term),
            )
        )
    samples = db.scalars(stmt.limit(150)).all()
    clients = db.scalars(select(Client).where(Client.active.is_(True)).order_by(Client.name)).all()
    quotes = db.scalars(select(Quotation).where(Quotation.status == "ACTIVE").order_by(Quotation.number)).all()
    pos = db.scalars(select(PurchaseOrder).where(PurchaseOrder.status == "ACTIVE").order_by(PurchaseOrder.number)).all()
    assets = db.scalars(select(Asset).where(Asset.active.is_(True)).order_by(Asset.asset_code)).all()
    return templates.TemplateResponse(
        "intake_queue.html",
        {
            "request": request, "user": user, "samples": samples, "q": q, "view": view,
            "clients": clients, "quotes": quotes, "pos": pos, "assets": assets,
            "package_names": [row["name"] for row in package_catalog(db, site.id)],
        },
    )


@router.post("/direct")
def create_direct_client_intake(
    request: Request,
    client_id: int = Form(...),
    asset_id: int = Form(...),
    quotation_id: str = Form(""),
    purchase_order_id: str = Form(""),
    requested_package: str = Form("Routine Test"),
    sampling_point: str = Form(""),
    sample_date_time: str = Form(""),
    container_count: int = Form(1),
    client_sample_reference: str = Form(""),
    notes: str = Form(""),
    priority: str = Form("NORMAL"),
    required_tat: str = Form(""),
    due_at: str = Form(""),
    submission_document: UploadFile | None = File(None),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, ALLOWED)
    site = _site_for_user(db, user)
    assert_site_period_open(db, site.id)
    client = db.get(Client, client_id)
    asset = db.get(Asset, asset_id)
    if not client or not client.active:
        raise ValueError("Active client is required")
    if not asset or not asset.active or asset.client_id != client.id:
        raise ValueError("Selected asset is not active for the selected client")
    quote_id = _optional_int(quotation_id, "Quotation")
    po_id = _optional_int(purchase_order_id, "Purchase order")
    if not quote_id or not po_id:
        raise ValueError("Client-originated intake requires the approved quotation and purchase order from the commercial handover")
    quote = db.get(Quotation, quote_id) if quote_id else None
    po = db.get(PurchaseOrder, po_id) if po_id else None
    if quote and (quote.client_id != client.id or quote.status != "ACTIVE"):
        raise ValueError("Quotation is not active for the selected client")
    if po and (po.client_id != client.id or po.status != "ACTIVE"):
        raise ValueError("Purchase order is not active for the selected client")
    if po and quote and po.quotation_id and po.quotation_id != quote.id:
        raise ValueError("Purchase order is linked to a different quotation")
    commercial_case = resolve_handover_case(db, site_id=site.id, client_id=client.id, quotation_id=quote_id, purchase_order_id=po_id)
    require_complete_handover(commercial_case)
    active_packages = {row["name"] for row in package_catalog(db, site.id)}
    if requested_package not in active_packages:
        raise ValueError("Requested test package is not active for this site")
    if container_count < 1 or container_count > 100:
        raise ValueError("Container count must be between 1 and 100")
    sampling_point = (sampling_point or "").strip()[:100]
    if not sampling_point:
        raise ValueError("Sampling point is required and must describe the transformer location; Client Delivered is a sample origin, not a sampling point")
    if sampling_point.lower() in {"client delivered", "client-originated", "client originated", "direct delivery"}:
        raise ValueError("Client Delivered is a sample origin, not a sampling point")
    client_sample_reference = (client_sample_reference or "").strip()[:100]
    notes = (notes or "").strip()[:4000]
    try:
        sample_dt = datetime.fromisoformat(sample_date_time) if sample_date_time else datetime.utcnow()
    except ValueError:
        raise ValueError("Sample date/time is invalid")
    document = _safe_direct_document(submission_document)

    request_number, barcode_value, public_token = next_request_identifiers(db, site)
    sample = SampleRequest(
        request_number=request_number,
        public_token=public_token,
        barcode_value=barcode_value,
        status=SampleStatus.SUBMITTED.value,
        site_id=site.id,
        client_id=client.id,
        quotation_id=quote.id if quote else None,
        purchase_order_id=po.id if po else None,
        commercial_case_id=commercial_case.id if commercial_case else None,
        asset_id=asset.id,
        sampler_id=None,
        sampling_assignment_id=None,
        submission_channel="CLIENT_DELIVERED",
        sample_date_time=sample_dt,
        sampling_point=sampling_point,
        requested_package=requested_package,
        sample_origin="Client-Originated / Direct Delivery",
        priority=priority.strip().upper() if priority.strip().upper() in {"NORMAL","HIGH","URGENT"} else "NORMAL",
        required_tat=required_tat.strip(),
        due_at=datetime.fromisoformat(due_at) if due_at else None,
        client_sample_reference=client_sample_reference,
        field_notes=notes,
        container_count=container_count,
        submitted_at=datetime.utcnow(),
    )
    db.add(sample)
    db.flush()
    if commercial_case:
        link_sample(db, commercial_case, sample, user)
    add_event(db, sample, user, "DIRECT_CLIENT_INTAKE_CREATED", sample.status, "Client-delivered sample registered from paper/direct submission")

    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    written: Path | None = None
    artifacts: dict[str, str] = {}
    try:
        if document:
            raw, ext, original_name = document
            written = UPLOAD_DIR / f"sample_{sample.id}_client_submission_{datetime.utcnow().timestamp():.0f}{ext}"
            written.write_bytes(raw)
            db.add(SamplePhoto(
                sample_request_id=sample.id,
                kind="CLIENT_SUBMISSION_DOCUMENT",
                original_name=original_name,
                stored_path=str(written),
            ))
        artifacts = generate_assets(barcode_value, request_number, client.name, asset.asset_code, BARCODE_DIR)
        add_audit(
            db, actor=user, request=request, action="DIRECT_CLIENT_SAMPLE_CREATED",
            entity_type="SampleRequest", entity_id=sample.id,
            summary=f"Created direct client intake {sample.request_number}",
            details={"client": client.code, "asset": asset.asset_code, "document": bool(document)},
        )
        db.commit()
    except Exception:
        db.rollback()
        if written:
            written.unlink(missing_ok=True)
        for path in artifacts.values():
            Path(path).unlink(missing_ok=True)
        raise
    return RedirectResponse(f"/intake/{sample.id}", status_code=303)


@router.post("/{sample_id}/receive")
def receive_sample(
    sample_id: int, request: Request, seal_status: str = Form("Intact"), condition_note: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, ALLOWED)
    sample = db.get(SampleRequest, sample_id)
    if not sample or not can_access_site(user, sample.site_id):
        return RedirectResponse("/intake?view=receiving", status_code=303)
    assert_sample_period_open(db, sample)
    clean_seal = seal_status.strip().upper()
    if clean_seal not in {"INTACT", "BROKEN", "MISSING", "NOT APPLICABLE"}:
        raise ValueError("Unsupported seal status")
    if sample.status == SampleStatus.RECEIVED.value:
        return RedirectResponse("/intake?view=receiving&error=Sample+is+already+recorded+as+received", status_code=303)
    if not sample.lms_number:
        return RedirectResponse("/intake?view=receiving&error=Sample+must+be+accepted+and+registered+before+physical+receipt", status_code=303)
    if sample.status != SampleStatus.AWAITING_RECEIPT.value:
        return RedirectResponse("/intake?view=receiving&error=Sample+status+does+not+permit+physical+receipt", status_code=303)
    sample.status = SampleStatus.RECEIVED.value
    sample.received_at = datetime.utcnow()
    add_event(db, sample, user, "PHYSICAL_RECEIPT", sample.status, f"Seal: {clean_seal}. {condition_note}".strip())
    sync_case_from_sample(db, sample, user, note="Physical sample received by Sample Intake & Receiving")
    add_audit(db, actor=user, request=request, action="PHYSICAL_SAMPLE_RECEIVED", entity_type="SampleRequest", entity_id=sample.id, summary=f"Received {sample.request_number}", details={"seal_status": clean_seal, "condition_note": condition_note})
    db.commit()
    return RedirectResponse("/intake?view=distribution", status_code=303)


@router.get("/{sample_id}")
def review(sample_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    sample = db.get(SampleRequest, sample_id)
    if not sample or not can_access_site(user, sample.site_id):
        return RedirectResponse("/intake", status_code=303)
    commercial_attachments = []
    if sample.commercial_case_id:
        commercial_attachments = list(db.scalars(
            select(CommercialAttachment)
            .where(CommercialAttachment.commercial_case_id == sample.commercial_case_id)
            .order_by(CommercialAttachment.created_at.desc())
        ).all())
    return templates.TemplateResponse(
        "intake_review.html",
        {"request": request, "user": user, "sample": sample, "commercial_attachments": commercial_attachments},
    )


@router.post("/{sample_id}/decision")
def decision(
    sample_id: int,
    request: Request,
    action: str = Form(...),
    note: str = Form(""),
    issue_type: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, ALLOWED)
    sample = db.get(SampleRequest, sample_id)
    if not sample or not can_access_site(user, sample.site_id):
        return RedirectResponse("/intake", status_code=303)
    assert_sample_period_open(db, sample)

    action = action.upper()
    reviewable = {SampleStatus.SUBMITTED.value, SampleStatus.RETURNED.value}
    if action in {"ACCEPT_AND_REGISTER", "ACCEPT", "RETURN", "REJECT"} and sample.status not in reviewable:
        raise ValueError(f"Intake action {action} is not permitted from status {sample.status}")
    if action == "REGISTER_LMS" and sample.status != SampleStatus.ACCEPTED.value:
        raise ValueError(f"LMS registration is not permitted from status {sample.status}")
    if action == "DISTRIBUTE_TO_LAB" and sample.status != SampleStatus.RECEIVED.value:
        raise ValueError(f"Laboratory distribution is not permitted from status {sample.status}")
    if action not in {"ACCEPT_AND_REGISTER", "ACCEPT", "RETURN", "REJECT", "REGISTER_LMS", "DISTRIBUTE_TO_LAB"}:
        raise ValueError("Unsupported intake action")
    if action in {"RETURN", "REJECT"} and not note.strip():
        raise ValueError("A reason is required when returning or rejecting a sample")
    clean_issue_type = issue_type.strip()
    if len(clean_issue_type) > 80:
        raise ValueError("Issue type must be 80 characters or fewer")

    if action == "ACCEPT_AND_REGISTER":
        sample.status = SampleStatus.ACCEPTED.value
        sample.accepted_at = datetime.utcnow()
        sample.data_entry_note = note.strip()
        add_event(db, sample, user, "DATA_ACCEPTANCE", sample.status, note.strip())
        register_in_lms(db, sample, user)
    elif action == "ACCEPT":
        sample.status = SampleStatus.ACCEPTED.value
        sample.accepted_at = datetime.utcnow()
        sample.data_entry_note = note.strip()
        add_event(db, sample, user, "DATA_ACCEPTANCE", sample.status, note.strip())
    elif action == "RETURN":
        sample.status = SampleStatus.RETURNED.value
        sample.return_reason = note.strip()
        add_event(db, sample, user, "RETURN_FOR_CORRECTION", sample.status, note.strip())
        db.add(DataQualityIssue(
            sample_request_id=sample.id,
            issue_type=clean_issue_type or "FIELD_DATA_ERROR",
            severity="MEDIUM",
            description=note.strip() or "Returned for correction",
            reported_by_id=user.id,
        ))
    elif action == "REJECT":
        sample.status = SampleStatus.REJECTED.value
        sample.rejection_reason = note.strip()
        add_event(db, sample, user, "REJECTION", sample.status, note.strip())
        db.add(DataQualityIssue(
            sample_request_id=sample.id,
            issue_type=clean_issue_type or "SAMPLE_REJECTED",
            severity="HIGH",
            description=note.strip() or "Sample rejected",
            reported_by_id=user.id,
        ))
    elif action == "REGISTER_LMS":
        if sample.lms_number:
            raise ValueError("This sample is already registered in LMS")
        register_in_lms(db, sample, user)
    elif action == "DISTRIBUTE_TO_LAB":
        if not sample.lms_number or not sample.received_at:
            raise ValueError("LMS registration and physical receiving must be complete before laboratory distribution")
        sample.status = SampleStatus.READY_FOR_LAB.value
        add_event(db, sample, user, "BATCHED_AND_DISTRIBUTED", sample.status, note.strip() or "Sample batched/released to Laboratory Operations")
        sync_sample_to_operations(db, sample, user, phase="READY_FOR_LAB")
        sync_case_from_sample(db, sample, user, note="Sample released to laboratory distribution")

    add_audit(
        db,
        actor=user,
        request=request,
        action=f"INTAKE_{action}",
        entity_type="SampleRequest",
        entity_id=sample.id,
        summary=f"{sample.request_number}: {action}",
        details={"note": note, "issue_type": issue_type, "status": sample.status},
    )
    db.commit()
    return RedirectResponse(f"/intake/{sample.id}", status_code=303)
