from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import ImprovementItem, Role, User
from app.services.lab_operations import ensure_monthly_quality_distribution, blank_operations_db
from app.models import Site


def login(client: TestClient, email: str, password: str = "Demo123!") -> None:
    response = client.post("/login", data={"email": email, "password": password}, follow_redirects=False)
    assert response.status_code == 303, response.text


def test_public_welcome_contains_vision_journey_asset_architecture_and_one_sign_in():
    with TestClient(app) as client:
        page = client.get("/welcome")
        assert page.status_code == 200
        for text in (
            "VISION",
            "Six controlled steps",
            "Request",
            "Sampling / Delivery",
            "Receiving",
            "Laboratory",
            "Technical Review",
            "Report",
            "Secure Sign In",
        ):
            assert text in page.text
        assert "WHO WE ARE" not in page.text
        assert "OUR JOURNEY" not in page.text
        assert "Employee Portal" not in page.text
        assert "Client Portal" not in page.text
        assert "Field Sampling" not in page.text


def test_lab_technician_lands_on_workstations_and_cannot_open_supervisory_sections():
    with TestClient(app) as client:
        login(client, "chemist@tsco.local")
        home = client.get("/", follow_redirects=False)
        assert home.status_code == 303
        assert home.headers["location"] == "/lab/operations?section=workstations"
        assert client.get("/lab/operations?section=workstations").status_code == 200
        assert client.get("/lab/operations?section=supervisor").status_code == 403
        assert client.get("/lab/operations?section=retained").status_code == 403


def test_senior_workspace_is_supervisory_and_personal_qc_task_route_is_blocked():
    with TestClient(app) as client:
        login(client, "senior@tsco.local")
        page = client.get("/lab/operations?section=supervisor")
        assert page.status_code == 200
        assert "Technical Supervision" in page.text
        assert "QC Oversight" not in page.text
        assert "My Responsibilities" in page.text
        assert "My QC / Validation Tasks" not in page.text
        assert client.get("/control/my-quality-tasks").status_code == 403
        assert client.get("/lab/operations?section=workstations").status_code == 403


def test_quality_rotation_uses_technicians_only_not_senior_chemists():
    with SessionLocal() as db:
        site = db.scalar(select(Site).where(Site.code == "DMM"))
        users = db.scalars(select(User).where(User.site_id == site.id, User.active.is_(True))).all()
        payload = blank_operations_db(site)
        distribution = ensure_monthly_quality_distribution(payload, users)
        assert distribution is not None
        assigned_ids = {
            uid
            for row in distribution["assignments"]
            for uid in (row.get("primary_user_id"), row.get("backup_user_id"))
            if uid
        }
        assigned_roles = set(db.scalars(select(User.role).where(User.id.in_(assigned_ids))).all())
        assert assigned_roles == {Role.LAB_TECHNICIAN.value}
        senior_ids = set(db.scalars(select(User.id).where(User.role == Role.SENIOR_CHEMIST.value)).all())
        assert not (assigned_ids & senior_ids)


def test_intake_tabs_have_distinct_stage_content_and_all_records_has_no_new_intake_form():
    with TestClient(app) as client:
        login(client, "intake@tsco.local")
        expected = {
            "incoming": "Validate client / asset / commercial references",
            "receiving": "Physical Receiving Queue",
            "distribution": "Only physically received, LMS-registered samples",
            "released": "Released to Laboratory",
            "all": "complete intake history without showing a new-intake form",
        }
        texts = {}
        for view, marker in expected.items():
            page = client.get(f"/intake?view={view}")
            assert page.status_code == 200
            assert marker in page.text
            texts[view] = page.text
        assert 'id="directIntakeForm"' in texts["incoming"]
        for view in ("receiving", "distribution", "released", "all"):
            assert 'id="directIntakeForm"' not in texts[view]


def test_operations_has_clear_ownership_and_management_is_read_only():
    with TestClient(app) as client:
        login(client, "operations@tsco.local")
        page = client.get("/operations")
        assert page.status_code == 200
        assert "What Operations controls" in page.text
        assert "Sampling demand" in page.text
        assert "Laboratory owns" in page.text
        orders = client.get("/operations/orders")
        assert "Create Sampling Order" in orders.text
        client.post("/logout")
        login(client, "manager@tsco.local")
        page = client.get("/operations/orders")
        assert page.status_code == 200
        assert "Read-only operational oversight" in page.text
        assert "Create Sampling Order" not in page.text
        assert client.get("/lab/operations?section=dashboard").status_code == 403


def test_continuous_improvement_permissions_are_explicit_and_management_cannot_mutate():
    with TestClient(app) as client:
        login(client, "manager@tsco.local")
        page = client.get("/improvement")
        assert page.status_code == 200
        assert "MANAGEMENT" in page.text and "Read-only visibility" in page.text
        assert "EXCELLENCE" in page.text and "Register governance" in page.text
        assert "Quality retains its own separate Quality Center" in page.text
        created = client.post(
            "/improvement",
            data={"title": "Management review test", "problem_statement": "Review-only mutation test", "category": "WORKFLOW"},
            follow_redirects=False,
        )
        assert created.status_code == 303
        with SessionLocal() as db:
            item = db.scalar(select(ImprovementItem).where(ImprovementItem.title == "Management review test").order_by(ImprovementItem.id.desc()))
            assert item is not None
            item_id = item.id
        denied = client.post(
            f"/improvement/{item_id}/update",
            data={"status": "CLOSED", "owner_id": "", "due_at": "", "action_plan": "", "result_summary": "", "evidence_reference": "", "note": ""},
            follow_redirects=False,
        )
        assert denied.status_code == 403


def test_asset_structure_and_employee_organization_are_first_class_review_pages():
    with TestClient(app) as client:
        login(client, "senior@tsco.local")
        assets = client.get("/assets/structure")
        assert assets.status_code == 200
        for marker in ("Transformer / Asset Structure", "How the structure changes the platform", "Field", "Intake", "Laboratory & review", "Client portal"):
            assert marker in assets.text
        org = client.get("/organization")
        assert org.status_code == 200
        for marker in ("Organization & System Roles", "Salah Al-Shajira", "SENIOR CHEMISTS", "TECHNICIANS", "RBAC enforces authority"):
            assert marker in org.text
        client.post("/logout")
        login(client, "client@sec.local")
        assert client.get("/organization").status_code == 403
        assert client.get("/improvement").status_code == 403
        assert client.get("/assets/structure").status_code == 200


def test_report_template_contains_tsco_brand_transformer_context_all_result_groups_and_signoff():
    root = Path(__file__).resolve().parents[1]
    text = (root / "app" / "templates" / "controlled_report_preview.html").read_text(encoding="utf-8")
    for marker in (
        "TSCO ANALYTICAL LAB",
        "TRANSFORMER OIL ANALYSIS REPORT",
        "HV/LV",
        "Sampling From",
        "DGA - IEC 60567",
        "Furanic Derivatives",
        "GC Additives / Special Compounds",
        "Corrosive Sulfur / CCD / Tarnish Results",
        "Technical Interpretation & Recommendation",
        "Authorization & Release Boundary",
        "OFFICIAL LMS REFERENCE",
    ):
        assert marker in text


def test_role_matrix_and_review_guide_are_consistent_with_current_review_baseline():
    with TestClient(app) as client:
        login(client, "admin@tsco.local")
        guide = client.get("/review-guide")
        assert guide.status_code == 200
        assert "Senior Chemist" in guide.text
        assert "Personal QC / Validation task execution" in guide.text
        assert "Review Guide" in guide.text
        assert "direct-URL protection" in guide.text


def test_runtime_and_backup_metadata_report_v280():
    with TestClient(app) as client:
        assert client.get("/api/v1/health").json()["version"] == "3.1.0"
        login(client, "admin@tsco.local")
        backup = client.get("/api/lab-operations/backup")
        assert backup.status_code == 200
        assert backup.json()["version"] == "3.1.0"
