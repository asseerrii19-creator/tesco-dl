from types import SimpleNamespace

from app.models import Role
from app.services.commercial import COMMERCIAL_STAGES, role_can_transition


def _user(role):
    return SimpleNamespace(role=role)


def test_business_communication_flow_matches_controlled_lead_to_payment_chain():
    assert [label for _, label, _ in COMMERCIAL_STAGES] == [
        'Lead Generation','Quotation','Proposal','Client Follow-up','Purchase Order',
        'Purchase Order Received','Complete Handover','Client Coordination','Sampling',
        'Sample Delivery to Laboratory','Testing','Review','Report Approval','Report Release',
        'Report Submission to Client','Invoicing','Payment Collection','Closed',
    ]


def test_operational_and_laboratory_business_stages_are_derived_not_manual():
    ops=_user(Role.OPERATIONS_MANAGER.value)
    senior=_user(Role.SENIOR_CHEMIST.value)
    technical=_user(Role.TECHNICAL_MANAGER.value)
    for stage in ('CLIENT_COORDINATION','SAMPLING','SAMPLE_DELIVERY','TESTING','REVIEW','REPORT_APPROVAL','REPORT_RELEASE'):
        assert role_can_transition(ops, stage) is False
        assert role_can_transition(senior, stage) is False
        assert role_can_transition(technical, stage) is False


def test_manual_business_actions_are_split_between_sales_coordinator_and_finance():
    sales=_user(Role.SALES_MARKETING.value)
    coordinator=_user(Role.CLIENT_COORDINATOR.value)
    finance=_user(Role.FINANCE.value)
    for stage in ('LEAD_GENERATION','PROPOSAL'):
        assert role_can_transition(sales, stage) is True
    assert role_can_transition(sales, 'CLIENT_FOLLOW_UP') is False
    for stage in ('QUOTATION','CLIENT_FOLLOW_UP','PURCHASE_ORDER','PURCHASE_ORDER_RECEIVED','COMPLETE_HANDOVER','REPORT_SUBMISSION'):
        assert role_can_transition(coordinator, stage) is True
        assert role_can_transition(sales, stage) is False
    for stage in ('INVOICING','PAYMENT_COLLECTION','CLOSED'):
        assert role_can_transition(finance, stage) is True
