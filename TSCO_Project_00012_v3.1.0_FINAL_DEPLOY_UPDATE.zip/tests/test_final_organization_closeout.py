from pathlib import Path
from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import CommercialAttachment, CommercialCase, Department, Role, User, WorkflowDefinition, WorkflowStep
from app.routes.admin import ROLE_OPTIONS
from app.role_matrix import ROLE_REVIEW_MATRIX
from app.services.commercial import role_can_transition


def login(client, email, password="Demo123!"):
    response = client.post("/login", data={"email": email, "password": password}, follow_redirects=False)
    assert response.status_code == 303


def test_final_department_role_structure_is_explicit_and_nonduplicated():
    assert Role.CLIENT_COORDINATOR.value in ROLE_REVIEW_MATRIX
    assert Role.SAMPLE_RECEIVING.value not in ROLE_OPTIONS
    assert ROLE_REVIEW_MATRIX[Role.DATA_ENTRY.value]["name"] == "Sample Intake & Receiving"
    assert "independent Continuous Improvement / Excellence" in ROLE_REVIEW_MATRIX[Role.EXCELLENCE.value]["purpose"]

    with TestClient(app):
        with SessionLocal() as db:
            departments = {d.code: d.name for d in db.scalars(select(Department)).all()}
            assert departments["RCV"] == "Sample Intake & Receiving"
            assert departments["OPS"] == "Field Operations & Client Coordination"
            assert departments["QLT"] == "Quality"
            assert departments["EXC"] == "Continuous Improvement / Excellence"
            assert departments["SAM"] == "Sales & Marketing"

            intake = db.scalar(select(User).where(User.email == "intake@tsco.local"))
            legacy = db.scalar(select(User).where(User.email == "receiving@tsco.local"))
            sales = db.scalar(select(User).where(User.email == "sales@tsco.local"))
            coordinator = db.scalar(select(User).where(User.email == "coordinator@tsco.local"))
            assert intake and intake.role == Role.DATA_ENTRY.value
            # pytest keeps only a compatibility alias; it must never be a separate receiving role.
            assert legacy and legacy.role == Role.DATA_ENTRY.value
            assert sales and sales.role == Role.SALES_MARKETING.value
            assert coordinator and coordinator.role == Role.CLIENT_COORDINATOR.value


def test_sample_lifecycle_assigns_receiving_to_unified_intake_role():
    with TestClient(app):
        with SessionLocal() as db:
            flow = db.scalar(select(WorkflowDefinition).where(WorkflowDefinition.code == "LAB-SAMPLE-LIFECYCLE", WorkflowDefinition.active.is_(True)))
            assert flow is not None
            steps = {row.step_key: row.responsible_role for row in db.scalars(select(WorkflowStep).where(WorkflowStep.workflow_id == flow.id)).all()}
            assert steps["data_entry"] == Role.DATA_ENTRY.value
            assert steps["lms_registration"] == Role.DATA_ENTRY.value
            assert steps["receiving"] == Role.DATA_ENTRY.value
            assert steps["batch_distribution"] == Role.DATA_ENTRY.value
            assert Role.SAMPLE_RECEIVING.value not in steps.values()


def test_unified_intake_workspace_handles_receiving_without_second_workspace():
    with TestClient(app) as client:
        login(client, "intake@tsco.local")
        page = client.get("/intake?view=receiving")
        assert page.status_code == 200
        assert "Sample Intake" in page.text
        assert "Physical Receiving" in page.text
        legacy = client.get("/receiving", follow_redirects=False)
        assert legacy.status_code == 303
        assert legacy.headers["location"].startswith("/intake?view=receiving")


def test_quality_and_excellence_are_independent_workspaces():
    with TestClient(app) as client:
        login(client, "quality@tsco.local")
        quality = client.get("/quality")
        assert quality.status_code == 200
        assert "QUALITY · INDEPENDENT WORKSPACE" in quality.text
        assert "Continuous Improvement" in quality.text  # boundary statement only
        client.post("/logout")

        login(client, "excellence@tsco.local")
        improvement = client.get("/improvement")
        assert improvement.status_code == 200
        assert "INDEPENDENT DEPARTMENT" in improvement.text
        assert "Quality retains its own separate Quality Center" in improvement.text
        assert "Quality & QC" not in improvement.text


def test_sales_and_client_coordinator_have_distinct_commercial_authority():
    class U:
        def __init__(self, role):
            self.role = role

    sales = U(Role.SALES_MARKETING.value)
    coordinator = U(Role.CLIENT_COORDINATOR.value)
    assert role_can_transition(sales, "LEAD_GENERATION") is True
    assert role_can_transition(sales, "PROPOSAL") is True
    assert role_can_transition(sales, "CLIENT_FOLLOW_UP") is False
    for stage in ("QUOTATION", "CLIENT_FOLLOW_UP", "PURCHASE_ORDER", "PURCHASE_ORDER_RECEIVED", "COMPLETE_HANDOVER", "REPORT_SUBMISSION"):
        assert role_can_transition(coordinator, stage) is True
        assert role_can_transition(sales, stage) is False


def test_business_workflow_assigns_follow_up_and_po_to_client_coordinator():
    with TestClient(app):
        with SessionLocal() as db:
            flow = db.scalar(select(WorkflowDefinition).where(WorkflowDefinition.code == "BUSINESS-COMMUNICATION-FLOW", WorkflowDefinition.active.is_(True)))
            assert flow is not None and flow.version >= 3
            steps = {row.step_key: row.responsible_role for row in db.scalars(select(WorkflowStep).where(WorkflowStep.workflow_id == flow.id)).all()}
            assert steps["lead_generation"] == Role.SALES_MARKETING.value
            assert steps["proposal"] == Role.SALES_MARKETING.value
            assert steps["quotation"] == Role.CLIENT_COORDINATOR.value
            assert steps["client_follow_up"] == Role.CLIENT_COORDINATOR.value
            assert steps["purchase_order"] == Role.CLIENT_COORDINATOR.value
            assert steps["purchase_order_received"] == Role.CLIENT_COORDINATOR.value
            assert steps["complete_handover"] == Role.CLIENT_COORDINATOR.value


def test_coordinator_can_attach_po_document_and_intake_can_see_case_documents():
    with TestClient(app) as client:
        login(client, "coordinator@tsco.local")
        with SessionLocal() as db:
            coordinator = db.scalar(select(User).where(User.email == "coordinator@tsco.local"))
            case = db.scalar(select(CommercialCase).order_by(CommercialCase.id))
            assert coordinator and case
            case_id = case.id

        fake_pdf = b"%PDF-1.4\n% controlled test document\n%%EOF\n"
        response = client.post(
            f"/commercial/cases/{case_id}/attachments",
            data={"document_type": "PURCHASE_ORDER"},
            files={"upload": ("PO-TEST.pdf", fake_pdf, "application/pdf")},
            follow_redirects=False,
        )
        assert response.status_code == 303
        with SessionLocal() as db:
            row = db.scalar(select(CommercialAttachment).where(CommercialAttachment.commercial_case_id == case_id).order_by(CommercialAttachment.id.desc()))
            assert row and row.document_type == "PURCHASE_ORDER" and row.sha256


def test_public_landing_has_permanent_desktop_grid_fix_and_no_generic_sketch():
    root = Path(__file__).resolve().parents[1]
    html = (root / "app" / "templates" / "welcome.html").read_text(encoding="utf-8")
    css = (root / "app" / "static" / "styles.css").read_text(encoding="utf-8")
    assert "industrial-sketch" not in html
    assert ".public-v304 .journey-track-six{display:grid!important" in css
    assert "grid-template-columns:repeat(6,minmax(0,1fr))" in css


def test_quality_navigation_is_dedicated_and_not_nested_under_improvement():
    base = (Path(__file__).resolve().parents[1] / "app" / "templates" / "base.html").read_text(encoding="utf-8")
    assert "'/quality','Quality Center'" in base or '"/quality","Quality Center"' in base or "/quality','Quality Center" in base
    assert "/improvement?tab=quality" not in base
