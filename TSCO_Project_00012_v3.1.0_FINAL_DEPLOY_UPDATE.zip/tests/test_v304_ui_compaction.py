from pathlib import Path
from fastapi.testclient import TestClient

from app.main import app


def login(client, email, password="Demo123!"):
    r = client.post("/login", data={"email": email, "password": password}, follow_redirects=False)
    assert r.status_code == 303


def test_chemist_qc_equipment_is_compact_with_details_disclosure():
    with TestClient(app) as client:
        login(client, "chemist@tsco.local")
        page = client.get("/control/my-quality-tasks")
        assert page.status_code == 200
        assert "My assigned equipment" in page.text
        assert "qc-ownership-list" in page.text
        assert "qc-assignment-details" in page.text
        assert ">Details<" in page.text
        assert "Maximum: one Primary instrument + one Backup instrument" not in page.text


def test_validation_cards_use_progressive_disclosure():
    template = (Path(__file__).resolve().parents[1] / "app" / "templates" / "my_quality_tasks.html").read_text()
    assert "validation-task-collapsed" in template
    assert "Details &amp; entry" in template or "Details & entry" in template


def test_public_home_uses_side_rail_without_generic_industrial_sketch():
    with TestClient(app) as client:
        page = client.get("/welcome")
        assert page.status_code == 200
        assert "public-info-rail" in page.text
        assert "Our Vision" in page.text
        assert "Who We Are" in page.text
        assert "Our Laboratories" in page.text
        assert "industrial-sketch" not in page.text
        css = (Path(__file__).resolve().parents[1] / "app" / "static" / "styles.css").read_text()
        assert ".public-v304 .journey-track-six{display:grid!important" in css
        assert page.text.count('class="public-rail-item"') == 3
        assert "welcome-vision" not in page.text


def test_internal_department_navigation_remains_collapsible():
    with TestClient(app) as client:
        login(client, "chemist@tsco.local")
        page = client.get("/lab/operations?section=workstations")
        assert page.status_code == 200
        assert "nav-group" in page.text
        assert "nav-label" in page.text
