# v3.1.0 — FINAL ORGANIZATION / ROLE / RESPONSIVE CLOSEOUT (2026-09-16)

- Unified Data Entry/Intake and physical Receiving into one **Sample Intake & Receiving** department/workspace; no standalone Receiving role/login.
- Added distinct **Client Coordinator** role under the Field Operations & Client Coordination function.
- Sales & Marketing owns Lead Generation + Proposal; Client Coordinator owns client request/Quotation, Client Follow-up, Purchase Order, supporting commercial documents, Complete Handover and Report Submission.
- Added controlled commercial attachments for quotation/PO/client/handover evidence linked through the business case to the sampling/sample journey.
- Split Quality into a dedicated **Quality Center** and kept Continuous Improvement / Excellence independent.
- Aligned the in-system organization view to the supplied Analytical Lab organizational structure.
- Preserved monthly exact-Equipment-ID QC ownership, Primary/Backup anti-overload and `COVERAGE_REQUIRED`.
- Permanently integrated desktop responsive Journey fix and removed the generic industrial sketch.
- Added Alembic revision `e31a7f4b9c20` for commercial attachments.
- Final verification: **196 collected / 196 passed**, compile PASS, reversible fresh migrations PASS.

# v3.0.3 - ANALYTICAL LAB PROFILE / ROLE NAVIGATION AUDIT (2026-09-16)

- Integrated official TSCO Vision/Mission and Analytical Lab reference content without expanding the landing page into a long editorial layout.
- Added 23-page reader-opened Analytical Lab Profile; removed the source Thank You page.
- Removed unsupported public lab-photo placeholders; approved site photos remain deferred to IT.
- Added source-grounded capability cards for Transformer Oil, Hydrocarbon/Crude & Fuel, Lubricating Oil, Environmental & Water, Firefighting Foam, and R&D/Training.
- Added cross-role visible-navigation regression across 14 internal roles.
- Total regression: 179 passed / 0 failed.

# v3.0.2 — INFORMATION ARCHITECTURE / NAVIGATION CLOSEOUT (2026-09-16)

- Collapsible department navigation across the authenticated platform.
- Operations Display removed from Senior Chemist and Quality workspaces; one dedicated Technical Manager/System Admin access point.
- Laboratory knowledge consolidated: Methods / SOPs / EOPs live inside the Laboratory group; duplicate generic document link removed for lab roles.
- Public Project Vision made explicit; About Us and Our Laboratories added as compact expandable drawers with a photo-gallery structure ready for approved images.

# v3.0.1 — QC / UX CLOSEOUT (2026-09-16)

- Monthly analytical-equipment ownership with exact Equipment IDs and anti-overload limits.
- Routine responsibilities separated from analytical instrument ownership.
- Duplicate My Today/My Day workspace removed; Brief Archive retained as the in-system reference.
- Public landing reduced from stacked editorial layout.

