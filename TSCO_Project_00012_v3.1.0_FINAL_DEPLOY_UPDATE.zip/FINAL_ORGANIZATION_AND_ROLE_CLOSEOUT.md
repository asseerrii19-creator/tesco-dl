# TSCO Digital Laboratory Platform — Final Organization & Role Closeout

**Project:** 00012  
**Closeout:** 16 September 2026  
**Package:** `TSCO_Project_00012_FINAL_CLOSEOUT`

This document is the final authority for the organization/role corrections applied after the v3.0.5 review baseline. Where an older document conflicts with this closeout, this document and `MASTER_REQUIREMENTS_TRACEABILITY_FINAL_SUPPLEMENT.md` supersede it.

## 1. Sample Intake & Receiving — one department / one workspace

- `Data Entry / Intake` and physical `Receiving` are not separate departments or separate active system roles.
- The active role is `data_entry`, displayed as **Sample Intake & Receiving**.
- One controlled workspace owns data verification, LMS registration, physical receiving, label/custody confirmation, batching and release to laboratory.
- The historical `/receiving` route is retained only as a compatibility alias and redirects to the Receiving view inside `/intake`.
- `sample_receiving` remains only as a legacy enum/import compatibility value. It is excluded from active Admin role choices. Existing legacy users are migrated to `data_entry`; the legacy review account is deactivated outside testing.

## 2. Quality and Continuous Improvement / Excellence — independent departments

### Quality
Owns the dedicated **Quality Center** (`/quality`):
- monthly QC ownership and exact Equipment IDs;
- equipment/calibration/verification governance;
- materials/gases/storage oversight;
- validation / verification;
- ILC / PT;
- NCR / CAPA;
- competency;
- controlled quality evidence;
- quality audit visibility.

### Continuous Improvement / Excellence
Owns the independent **Continuous Improvement** workspace (`/improvement`):
- improvement opportunities;
- register governance;
- action ownership;
- validation evidence for improvement closure;
- department review model;
- Project 00012 roadmap.

Quality can raise an improvement proposal but does not govern the Excellence register. Excellence does not inherit Quality authority.

## 3. Sales & Marketing and Client Coordinator — separate functions

- **Sales & Marketing** owns Lead Generation and Proposal.
- **Client Coordinator** owns client requests/Quotation, Client Follow-up, Purchase Order and supporting attachments, Purchase Order Received, Complete Handover and Report Submission to Client.
- Quotation/PO/client documents are stored as controlled commercial attachments on the business case; the linked sampling order/sample sees the same documents through that case rather than duplicating files.
- Operational/laboratory lifecycle stages remain derived from their authoritative workflows rather than being manually advanced by Sales/Coordinator.
- Finance owns Invoicing, Payment Collection and commercial closure.

## 4. QC rule preserved

The authoritative QC model remains unchanged by this organizational closeout:
- ownership is fixed by calendar month;
- exact Equipment ID is mandatory;
- each analytical instrument has Primary + Backup;
- each eligible technician/chemist may hold at most one Primary analytical instrument and at most one Backup analytical instrument in the same month;
- insufficient competent coverage is shown as `COVERAGE_REQUIRED` rather than stacking assignments;
- routine responsibilities remain separate from analytical instrument ownership;
- check frequency is controlled independently from monthly ownership.

## 5. UI / responsive closeout

- The public Laboratory Journey grid has a permanent desktop CSS fix (`display:grid`) inside the package source.
- Desktop uses the available horizontal width; tablet/mobile use separate responsive layouts.
- The generic industrial sketch was removed from the public landing page.
- No external CSS hotfix file is required for this package.

## 6. Verification

- Python compile check: PASS.
- Test discovery: **196 tests**.
- All **196 / 196** passed across exhaustive regression batches after the final structural corrections.
- Fresh Alembic migration `base → e31a7f4b9c20`, downgrade `head → base`, and re-upgrade `base → head`: **PASS**.
