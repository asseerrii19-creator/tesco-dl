"""add controlled commercial attachments

Revision ID: e31a7f4b9c20
Revises: c06f4e83aa12
"""
from alembic import op
import sqlalchemy as sa

revision = "e31a7f4b9c20"
down_revision = "c06f4e83aa12"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "commercial_attachments",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("commercial_case_id", sa.Integer(), sa.ForeignKey("commercial_cases.id"), nullable=False),
        sa.Column("document_type", sa.String(40), nullable=False),
        sa.Column("original_name", sa.String(220), nullable=False),
        sa.Column("stored_path", sa.String(500), nullable=False),
        sa.Column("content_type", sa.String(120), nullable=False, server_default="application/octet-stream"),
        sa.Column("sha256", sa.String(64), nullable=False),
        sa.Column("uploaded_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    for col in ("commercial_case_id", "document_type", "sha256", "uploaded_by_id", "created_at"):
        op.create_index(f"ix_commercial_attachments_{col}", "commercial_attachments", [col])


def downgrade():
    op.drop_table("commercial_attachments")
