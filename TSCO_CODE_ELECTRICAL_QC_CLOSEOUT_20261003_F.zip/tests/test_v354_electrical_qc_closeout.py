from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'app/lab_ops/index_template.html').read_text(encoding='utf-8')

def test_live_equipment_mapping_has_controlled_fallbacks():
    assert 'function equipmentClassSupportsContext' in HTML
    for eid in ['EQ-24','EQ-25','EQ-30','EQ-26','EQ-49','EQ-130','EQ-79','EQ-80']:
        assert eid in HTML
    assert 'const strict=sameWs.filter(eq=>methodsMatch(eq.test_method,ctx.method));if(strict.length)return strict' in HTML

def test_bdv_and_pf_have_separate_instrument_imports():
    assert 'data-kind="BDV"' in HTML
    assert 'data-kind="PF"' in HTML
    assert 'BDV Instrument Result File (CSV)' in HTML
    assert 'PF Instrument Result File (CSV)' in HTML
    assert 'BDV six runs → Average + RSD' in HTML

def test_rsd_is_derived_child_not_independent_electrical_entry():
    assert "calculated:true" in HTML
    assert "source:'Derived from BDV six-run set'" in HTML
    assert "standardElectrical=tests.filter(t=>!/breakdown voltage|rsd% of bdv|power factor" in HTML
