from types import SimpleNamespace

from app.services import final_report_data, report_ordering, technical_assessment
from app.services import lab_operations


def _sample():
    return SimpleNamespace(
        request_number='FS-DMM-26-000003', id=3, barcode_value='BC-3',
        lms_number=None, client_sample_reference=None,
    )


def test_operational_report_family_order_is_exact():
    assert report_ordering.REPORT_GROUP_ORDER == [
        'dga', 'water_electrical', 'physical_visual', 'tan_family', 'oqi',
        'furan', 'gc_additives', 'corrosion_flash_metals', 'other',
    ]
    assert [report_ordering.report_group_label(x) for x in report_ordering.REPORT_GROUP_ORDER[:-1]] == [
        'DGA (Dissolved Gas Analysis)',
        'Water / BDV / PF / Lab Room Conditions',
        'IFT / Color / Appearance',
        'TAN / RSH / Peroxide',
        'Oil Quality Index',
        'Furan / Paper',
        'DBDS / Toluene / BHT / PCB',
        'Corrosive Sulfur / Flash Point / Metals',
    ]


def test_all_nine_dga_gases_stay_in_dga_family():
    gases = [
        'Hydrogen (H2)', 'Oxygen (O2)', 'Nitrogen (N2)', 'Methane (CH4)',
        'Ethane (C2H6)', 'Ethylene (C2H4)', 'Acetylene (C2H2)',
        'Carbon Monoxide (CO)', 'Carbon Dioxide (CO2)',
    ]
    assert all(report_ordering.report_group_key(g) == 'dga' for g in gases)


def test_water_reports_use_only_controlled_average_not_eq_raw_rows():
    ops = {'results': [
        {'sample':'FS-DMM-26-000003','test':'WATER:KF_RT:EQ-69','display_test':'Water Content KF @RT — EQ-69','result':'8','ts':'2026-10-07T08:00:00'},
        {'sample':'FS-DMM-26-000003','test':'WATER:KF_RT:EQ-70','display_test':'Water Content KF @RT — EQ-70','result':'50','ts':'2026-10-07T08:00:01'},
        {'sample':'FS-DMM-26-000003','test':'WATER:KF_RT','display_test':'Water Content KF @RT','result':'29','ts':'2026-10-07T08:00:02'},
    ]}
    rows = final_report_data._sample_results(ops, _sample())
    assert rows['Water Content KF @RT']['result'] == '29'
    assert len([k for k in rows if k == 'Water Content KF @RT']) == 1
    assert technical_assessment._controlled_water_average(ops['results']) == ('Water Content KF @RT', 29.0)


def test_rsd_and_paper_lifetime_are_whole_number_display():
    assert report_ordering.report_display_result('RSD% of BDV @2.5mm', '0.66') == '1'
    assert report_ordering.report_display_result('Paper Lifetime Remaining Years', '27.6') == '28'


def test_assignment_groups_follow_lab_distribution_and_oqi_has_no_assignment():
    assert lab_operations._assignment_group_name('Water') == lab_operations.WATER_ELECTRICAL_WORKSTATION
    assert lab_operations._assignment_group_name('Electrical') == lab_operations.WATER_ELECTRICAL_WORKSTATION
    assert lab_operations._station_from_name('Interfacial Tension (IFT)') == lab_operations.PHYSICAL_VISUAL_WORKSTATION
    assert lab_operations._station_from_name('Total Mercaptan (RSH)') == lab_operations.TAN_WORKSTATION
    assert lab_operations._station_from_name('Dibenzyl Disulfide (DBDS)') == lab_operations.GC_ADDITIVES_WORKSTATION
    assert lab_operations._station_from_name('Flash Point (Closed Cup)') == lab_operations.CORROSION_FLASH_METALS_WORKSTATION
    assert lab_operations._station_from_name('Copper (Cu)') == lab_operations.CORROSION_FLASH_METALS_WORKSTATION
    payload={'results':[{'sample':'S1','test':'ROOM:LAB_TEMP'},{'sample':'S1','test':'ROOM:LAB_RH'}]}
    assert lab_operations._test_complete(payload,'S1',{'test':'Room Test Temperature'})
    assert lab_operations._test_complete(payload,'S1',{'test':'Room Test Humidity'})
    batch = {'tests': [
        {'test':'Water Content KF @RT','method':'IEC 60814','station':'Water'},
        {'test':'Breakdown Voltage @2.5mm- AVG','method':'IEC 60156','station':'Electrical'},
        {'test':'Oil Quality Index','method':'calculation','station':'Physical / Chemistry'},
        {'test':'Copper (Cu)','method':'ASTM D5185','station':'Additives / Special Tests'},
    ]}
    stations = lab_operations._batch_workstations(batch)
    assert lab_operations.WATER_ELECTRICAL_WORKSTATION in stations
    assert lab_operations.CORROSION_FLASH_METALS_WORKSTATION in stations
    assert '' not in stations
    assert 'Additives / Special Tests' not in stations


def test_room_conditions_belong_to_water_workgroup_and_snapshot_with_water():
    html = open('app/lab_ops/index_template.html', encoding='utf-8').read()
    assert 'LAB ROOM CONDITIONS · BOARD READING' in html
    assert 'save-room-condition' in html
    assert "test:'ROOM:LAB_TEMP'" in html
    assert "test:'ROOM:LAB_RH'" in html
    assert 'Record the current Lab Room Temperature and Humidity from the room board before saving Water.' in html
    assert "roomDay!==todayDay" in html
    assert "b.sample_meta[s].roomConditionAt=nowIso()" in html
    assert 'id="ebRoomTemp"' not in html
    assert 'id="ebRoomHumidity"' not in html


def test_senior_review_keeps_visual_model_and_decision_support():
    html = open('app/templates/senior_final_report_review.html', encoding='utf-8').read()
    assert 'SYSTEM TECHNICAL SCREENING · DECISION SUPPORT' in html
    assert 'NOT SELECTED — Senior decision required' in html
    assert 'TECHNICAL REVIEW COMPLETE → LAB OPERATIONAL & TECHNICAL MANAGER' in html
    assert 'group-NORMAL' in html and 'group-CAUTION' in html and 'group-CRITICAL' in html
    assert '{{x.trend.symbol}}' in html
    assert 'Suggested draft wording' in html
    assert html.count('<script>') == 1


def test_internal_and_official_reports_use_same_grouping_and_separate_lab_conditions():
    internal = open('app/templates/internal_worksheets.html', encoding='utf-8').read()
    preview = open('app/templates/controlled_report_preview.html', encoding='utf-8').read()
    data = open('app/services/final_report_data.py', encoding='utf-8').read()
    assert 'w.groups' in internal
    assert 'p.report_groups' in preview
    assert 'Laboratory Room Conditions' in preview
    assert 'separate from field/sampling ambient conditions' in preview
    assert "'lab_room': lab_room" in data
    assert "key':'corrosion_flash_metals'" in data or "'key': 'corrosion_flash_metals'" in data


def test_missing_sample_does_not_silently_disappear_from_report_register():
    route = open('app/routes/control_center.py', encoding='utf-8').read()
    template = open('app/templates/controlled_reports.html', encoding='utf-8').read()
    assert 'blocked_samples' in route
    assert 'Pending report eligibility' in template
    assert 'platform_sample_lab_projection' in route


def test_dga_workstation_source_bridges_release_evidence_gate():
    route = open('app/routes/control_center.py', encoding='utf-8').read()
    assert 'def _operations_dga_source' in route
    assert 'result-import' in route
    assert 'workstation DGA source' in route or 'DGA workstation' in route


def _room_state():
    return {
        'batches': [{
            'id': 'B1', 'platform_sample_id': 3, 'samples': ['FS-DMM-26-000003'],
            'tests': [
                {'test':'Water Content KF @RT','method':'IEC 60814','station':'Water'},
                {'test':'Breakdown Voltage @2.5mm- AVG','method':'IEC 60156','station':'Electrical'},
                {'test':'Power Factor @25°C/60Hz','method':'ASTM D924','station':'Electrical'},
            ],
            'sample_meta': {'FS-DMM-26-000003': {'temp':'40'}},
        }],
        'testAssignments': [{
            'id':'A-W','batch_id':'*','workstation':lab_operations.WATER_ELECTRICAL_WORKSTATION,
            'mode':'SINGLE','revision':1,'primary_user_id':18,'backup_user_id':None,
        }],
        'results': [], 'qc': [], 'qualifiedQcProfiles': [], 'retests': [], 'dgaAttachments': [],
        'resultEvidence': [], 'assignmentCompletions': [], 'qualityDistributions': [], 'qualityTaskEvents': [],
        'reports': [], 'retained': [], 'storageAssignments': [], 'batchHistory': [], 'cancelledSamples': [],
        'supervisorNotes': [], 'standards': [], 'staff': [], 'clients': [], 'samplePoints': [],
        'customPackages': [], 'formulaDefinitions': [], 'testUnits': {}, 'settings': {}, 'meta': {'revision':1},
        'drafts': {}, 'calculationDrafts': {},
    }


def test_room_board_batch_fields_are_allowed_only_for_assigned_water_employee():
    from copy import deepcopy
    current = _room_state()
    proposed = deepcopy(current)
    b = proposed['batches'][0]
    b.update({'roomTemp':'23.5','roomHumidity':'45','roomConditionAt':'2026-10-07T09:00:00','roomConditionBy':'Tech 18'})
    b['sample_meta']['FS-DMM-26-000003'].update({
        'activeRoomTemp':'23.5','activeRoomHumidity':'45','activeRoomConditionAt':'2026-10-07T09:00:00','activeRoomConditionBy':'Tech 18'
    })
    user = SimpleNamespace(id=18, role='lab_technician', full_name='Tech 18')
    lab_operations._sanitize_room_condition_batch_updates(current, proposed, user)
    lab_operations._validate_batch_integrity(current, proposed, allow_room_changes=True)

    bad = deepcopy(proposed)
    bad['batches'][0]['tests'][0]['method'] = 'UNCONTROLLED CHANGE'
    try:
        lab_operations._sanitize_room_condition_batch_updates(current, bad, user)
        assert False, 'non-room batch mutation must be blocked'
    except PermissionError:
        pass


def test_room_result_codes_use_water_assignment_and_do_not_require_analytical_qc():
    batch = _room_state()['batches'][0]
    assert lab_operations._station_from_name('ROOM:LAB_TEMP') == 'Water'
    assert lab_operations._result_test_allowed(batch, 'ROOM:LAB_TEMP')
    assert lab_operations._result_test_allowed(batch, 'ROOM:LAB_RH')
    payload = _room_state()
    user = SimpleNamespace(id=18, role='lab_technician', full_name='Tech 18')
    row = {'id':'R-ROOM','sample':'FS-DMM-26-000003','test':'ROOM:LAB_TEMP','display_test':'Room Test Temperature','result':'23.5'}
    lab_operations._bind_required_qc_to_result(payload, batch, row, user)
    assert row['qc_status'] == 'NOT_APPLICABLE'
    assert row['workstation'] == lab_operations.WATER_ELECTRICAL_WORKSTATION


def test_scoped_water_assignment_includes_water_bdv_pf_under_one_group():
    from copy import deepcopy
    state = _room_state()
    state['results'] = [
        {'id':'R1','sample':'FS-DMM-26-000003','test':'WATER:KF_RT','display_test':'Water Content KF @RT','result':'29'},
        {'id':'R2','sample':'FS-DMM-26-000003','test':'Breakdown Voltage @2.5mm- AVG','display_test':'Breakdown Voltage @2.5mm- AVG','result':'68'},
        {'id':'R3','sample':'FS-DMM-26-000003','test':'Power Factor @25°C/60Hz','display_test':'Power Factor @25°C/60Hz','result':'0.1'},
    ]
    user = SimpleNamespace(id=18, role='lab_technician', full_name='Tech 18')
    scoped = lab_operations.scope_operations_payload(deepcopy(state), user)
    tests = {x['test'] for x in scoped['batches'][0]['tests']}
    assert tests == {'Water Content KF @RT','Breakdown Voltage @2.5mm- AVG','Power Factor @25°C/60Hz'}
    assert {x['id'] for x in scoped['results']} == {'R1','R2','R3'}


def test_legacy_workstation_labels_remain_compatible_with_new_assignment_groups():
    assert lab_operations._same_workstation_group('Water', lab_operations.WATER_ELECTRICAL_WORKSTATION)
    assert lab_operations._same_workstation_group('Electrical', lab_operations.WATER_ELECTRICAL_WORKSTATION)
    assert 'Water' in lab_operations._workstation_equivalents(lab_operations.WATER_ELECTRICAL_WORKSTATION)
    assert 'Electrical' in lab_operations._workstation_equivalents(lab_operations.WATER_ELECTRICAL_WORKSTATION)
    assert 'Physical / Chemistry' in lab_operations._workstation_equivalents(lab_operations.PHYSICAL_VISUAL_WORKSTATION)
    assert 'TAN / Peroxide / RSH / H2S' in lab_operations._workstation_equivalents(lab_operations.TAN_WORKSTATION)
    assert 'Corrosion / CCD' in lab_operations._workstation_equivalents(lab_operations.CORROSION_FLASH_METALS_WORKSTATION)


def test_legacy_water_assignment_can_close_new_combined_workstation():
    state = _room_state()
    state['testAssignments'] = [{
        'id':'A-W','batch_id':'*','workstation':'Water',
        'mode':'SINGLE','revision':1,'primary_user_id':18,'backup_user_id':None,
    }]
    state['results'] = [
        {'id':'R1','sample':'FS-DMM-26-000003','test':'WATER:KF_RT','display_test':'Water Content KF @RT','result':'29'},
        {'id':'R2','sample':'FS-DMM-26-000003','test':'Breakdown Voltage @2.5mm- AVG','display_test':'Breakdown Voltage @2.5mm- AVG','result':'68'},
        {'id':'R3','sample':'FS-DMM-26-000003','test':'Power Factor @25°C/60Hz','display_test':'Power Factor @25°C/60Hz','result':'0.1'},
    ]
    assert lab_operations._workstation_complete(
        state, state['batches'][0], lab_operations.WATER_ELECTRICAL_WORKSTATION
    )
