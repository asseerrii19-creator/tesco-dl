#!/usr/bin/env bash
set -euo pipefail
MARKER="TSCO-UAT-CONSOLIDATED-CLOSEOUT-20261007-R11"
echo "TSCO_BUILD_MARKER=${MARKER}"
echo "TSCO_RELEASE_AUTHORITY_SCOPE=PHASE1_ROLES+SERVER_AUTHORITY+SENIOR_ASSIGNMENT+LAB_MANAGER_REVIEW+OPERATIONS+GM+QC+OQI"
python -m compileall -q app
for f in app/static/app.js app/static/field-form.js app/static/service-worker.js; do node --check "$f"; done
echo "TSCO_CODE_SYNTAX_ASSERTION=PASS"
if [[ -f ../TSCO_CODE_UAT_BEHAVIORAL_CLOSEOUT_20261003_G.zip ]]; then
  echo "TSCO_CODE_UAT_BEHAVIORAL_CLOSEOUT_SHA256=$(sha256sum ../TSCO_CODE_UAT_BEHAVIORAL_CLOSEOUT_20261003_G.zip | awk '{print $1}')"
fi
python - <<'PY'
from pathlib import Path
p=Path('app/lab_ops/index_template.html')
html=p.read_text(encoding='utf-8')
required=[
    'Analytical QC — Result Validity',
    'Analytical QC readiness',
    "$('queues').innerHTML=qcHtml+",
    'function applyAnalyticalQcActionLocks()',
    'STARTUP QC',
    'SAVE BOTH READINGS + AVERAGE',
    'WATER_DUAL_AVERAGE',
    'EQUIPMENT NOT READY',
    'Blind CRM verification.',
    'DGA QC / CRM Instrument CSV',
    'DGA results</b> · Import the GC/TOGA CSV when available.',
    'DGA RESULTS COMPLETE',
    'Required gases:',
    'IEC 60156 uses 6 breakdowns; ASTM D1816/D877 use 5.',
    'BDV method / gap',
    'PF Instrument Result File (CSV)',
    'function renderGroupedSampleTests',
    "const CORROSIVE_STATUS_OPTIONS=['Non-corrosive','Corrosive']",
    'Workstation closeout',
    'function reconcile409AndRetry(localPayload)',
    'function equipmentClassSupportsContext',
    'const online=await cloudLoad(true);',
    "if((STORAGE.dirty||STORAGE.saving)&&!force)return false;",
    "const READ_ONLY_PLATFORM_VIEW=['dashboard','labprogress','tracking','finalreport','knowledge'].includes(CURRENT_PLATFORM_SECTION);",
    'if(!READ_ONLY_PLATFORM_VIEW)scheduleCloudSave()',
    'function scheduleCloudSave(){if(READ_ONLY_PLATFORM_VIEW)return;',
    "if(READ_ONLY_PLATFORM_VIEW&&operation==='merge'){setSyncState('connected','READ ONLY');return false}",
    'function saveDraftInput(el){if(READ_ONLY_PLATFORM_VIEW)return;',
    'id="additiveHead" style="display:none"',
]
missing=[x for x in required if x not in html]
if missing:
    raise SystemExit('QC UI deployment assertion failed; missing: '+', '.join(missing))
print('TSCO_QC_UI_ASSERTION=PASS')
PY
python - <<'PY_CLOCK'
from pathlib import Path
files=[
    Path('tests/test_v350_daily_analytical_qc_control.py'),
    Path('tests/test_v351_dual_water_workflow.py'),
    Path('tests/test_v352_report_path_closeout.py'),
    Path('tests/test_qc_framework_global.py'),
]
legacy='2026-10-02'
found=[str(p) for p in files if legacy in p.read_text(encoding='utf-8')]
if found:
    raise SystemExit('QC release tests still contain a fixed lab-day date: '+', '.join(found))
print('TSCO_QC_CLOCK_ASSERTION=PASS')
PY_CLOCK
python - <<'PY_R10'
from pathlib import Path
version=Path('VERSION').read_text(encoding='utf-8').strip()
if version != '3.6.9-R11-UAT-CONSOLIDATED-CLOSEOUT-20261007':
    raise SystemExit(f'Unexpected R11 VERSION: {version}')
service=Path('app/services/technical_review_assignments.py').read_text(encoding='utf-8')
for email in ('senior.technical@tsco.local','senior.equipment@tsco.local','senior.improvement@tsco.local'):
    if email not in service:
        raise SystemExit(f'Canonical Senior missing from review assignment authority: {email}')
if 'senior@tsco.local' in service or 'senior.maintenance@tsco.local' in service:
    raise SystemExit('Legacy Senior alias leaked into canonical review-assignment authority')
print('TSCO_PHASE1_ROLE_AUTHORITY_ASSERTION=PASS')
PY_R10
if [[ -f app/reference_documents/catalog.json ]]; then
  echo 'TSCO_REFERENCE_ASSETS=LOCAL_PRESENT'
  python - <<'PY_REF'
import json
from pathlib import Path
p=Path('app/reference_documents/catalog.json')
data=json.loads(p.read_text(encoding='utf-8'))
if not data:
    raise SystemExit('Reference-document catalog is empty')
print('TSCO_REFERENCE_CATALOG_ASSERTION=PASS')
PY_REF
else
  echo 'TSCO_REFERENCE_ASSETS=LITE_EXTERNAL'
fi
# R11 authority: run the consolidated release regression set. Historic tests that assert
# retired workstation labels are intentionally superseded by v370, which verifies the
# approved operational families and backward compatibility for existing DB records.
pytest -q \
  tests/test_v368_consolidated_review_qc_closeout.py \
  tests/test_v369_uat_dga_evidence_bridge.py \
  tests/test_v370_uat_consolidated_closeout.py \
  tests/test_v355_uat_behavioral_closeout.py \
  tests/test_v354_electrical_qc_closeout.py \
  tests/test_v356_dga_results_closeout.py \
  tests/test_v359_qc_append_only_matrix.py \
  tests/test_v367_post_senior_report_experience.py \
  tests/test_v353_uat_blocker_closeout.py \
  tests/test_closeout_result_rules.py
echo 'TSCO_RELEASE_CHECK=PASS'
