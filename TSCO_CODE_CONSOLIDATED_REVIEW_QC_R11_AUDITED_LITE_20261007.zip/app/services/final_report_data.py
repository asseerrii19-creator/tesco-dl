from __future__ import annotations

import json
import re
import math
from datetime import datetime
from typing import Any

from sqlalchemy.orm import Session

from ..models import (
    AssetHistoryEvent,
    ControlledReport,
    EvidenceRecord,
    SampleRequest,
    SampleStatus,
    Site,
    TechnicalResultRule,
)
from .lab_operations import get_operations_state
from .technical_assessment import assess_sample
from .report_ordering import REPORT_GROUP_ORDER, report_group_key, report_group_label, report_display_result, normalized_test_text, report_sort_key, is_raw_water_instrument_row


DGA_ORDER = [
    'Hydrogen (H2)', 'Oxygen (O2)', 'Nitrogen (N2)', 'Ethylene (C2H4)',
    'Ethane (C2H6)', 'Acetylene (C2H2)', 'Methane (CH4)',
    'Carbon Monoxide (CO)', 'Carbon Dioxide (CO2)', 'Total Volume of Gases',
    'Equilibrium Gas Pressure @40°C', 'CO2/CO Ratio',
]
FURAN_ORDER = [
    '2-Furfural (2FAL)', 'Total Furanic Compounds', 'Paper Lifetime Remaining Years',
]
OIL_ORDER = [
    'Total Acid Number', 'Water Content KF @RT', 'Transformer Oil Temperature',
    'Water Content @20 °C', 'Humidity in Cellulose', 'Relative Saturation Water in Oil',
    'Interfacial Tension (IFT)', 'Breakdown Voltage @2.5mm AVG', 'RSD% of BDV @2.5mm',
    'Breakdown Voltage @1mm AVG', 'RSD% of BDV @1mm',
    'Power Factor @25°C/60Hz', 'Power Factor @100°C/60Hz',
    'Dissipation Factor @90°C/60Hz', 'Resistivity', 'Oil Quality Index',
    'Color ASTM', 'Appearance', 'Room Test Temperature', 'Room Test Humidity',
]

# Baseline presentation values mirror the supplied controlled TSCO Analysis Report.
# Active TechnicalResultRule data overrides DL and method/unit where available.
REPORT_SPECS: dict[str, dict[str, str]] = {
    'Hydrogen (H2)': {'unit':'ppm','uncertainty':'+/- 5.5 %','normal':'50','caution':'150','dl':'1'},
    'Oxygen (O2)': {'unit':'ppm'}, 'Nitrogen (N2)': {'unit':'ppm'},
    'Ethylene (C2H4)': {'unit':'ppm','uncertainty':'+/- 5.9 %','normal':'60','caution':'280','dl':'1'},
    'Ethane (C2H6)': {'unit':'ppm','uncertainty':'+/- 4.1 %','normal':'20','caution':'90','dl':'1'},
    'Acetylene (C2H2)': {'unit':'ppm','uncertainty':'+/- 4.4 %','normal':'2','caution':'20','dl':'1'},
    'Methane (CH4)': {'unit':'ppm','uncertainty':'+/- 4.7 %','normal':'30','caution':'130','dl':'1'},
    'Carbon Monoxide (CO)': {'unit':'ppm','uncertainty':'+/- 2 %','normal':'400','caution':'600','dl':'1'},
    'Carbon Dioxide (CO2)': {'unit':'ppm','uncertainty':'+/- 5.2 %','normal':'3800','caution':'14000','dl':'1'},
    'Total Volume of Gases': {'unit':'%','method':'Calculated'},
    'Equilibrium Gas Pressure @40°C': {'unit':'hPa','method':'Calculated','normal':'1013'},
    'CO2/CO Ratio': {'unit':'-','normal':'Acceptable if >3'},
    '2-Furfural (2FAL)': {'unit':'mg/kg','method':'IEC 61198','uncertainty':'0.2','normal':'<0.05','caution':'>2.0','dl':'0.01'},
    'Total Furanic Compounds': {'unit':'mg/kg','method':'IEC 61198'},
    'Paper Lifetime Remaining Years': {'unit':'Years','method':'Calculated'},
    'Total Acid Number': {'unit':'mg KOH/g','method':'IEC 62021 / ASTM D664','uncertainty':'+/- 1.8 %','normal':'<0.15','caution':'>0.30','dl':'0.010'},
    'Water Content KF @RT': {'unit':'ppm','method':'ASTM D1533 / IEC 60814','uncertainty':'+/- 3.1 %','normal':'<30','caution':'>40'},
    'Transformer Oil Temperature': {'unit':'°C','method':'Recorded'},
    'Water Content @20 °C': {'unit':'ppm','method':'IEC 60422','normal':'—','caution':'—'},
    'Humidity in Cellulose': {'unit':'%','method':'Oommen Chart','normal':'<2','caution':'>4.5'},
    'Relative Saturation Water in Oil': {'unit':'%','method':'IEC 60422','normal':'<10','caution':'>20'},
    'Interfacial Tension (IFT)': {'unit':'mN/m','method':'ASTM D971','uncertainty':'+/- 8 %','normal':'>28','caution':'<22'},
    'Breakdown Voltage @2.5mm AVG': {'unit':'kV','method':'IEC 60156','uncertainty':'+/- 3.2 %','normal':'>40','caution':'<30'},
    'RSD% of BDV @2.5mm': {'unit':'%','method':'Calculated'},
    'Breakdown Voltage @1mm AVG': {'unit':'kV','method':'ASTM D1816','uncertainty':'+/- 3.2 %'},
    'RSD% of BDV @1mm': {'unit':'%','method':'Calculated'},
    'Power Factor @25°C/60Hz': {'unit':'%','method':'ASTM D924','uncertainty':'+/- 2 %','caution':'>0.50'},
    'Power Factor @100°C/60Hz': {'unit':'%','method':'ASTM D924','uncertainty':'+/- 2 %','caution':'>5.0'},
    'Dissipation Factor @90°C/60Hz': {'unit':'%','method':'IEC 60247'},
    'Resistivity': {'unit':'GΩ·m','method':'ASTM D1169'},
    'Oil Quality Index': {'unit':'-','method':'Calculated','normal':'>300'},
    'Color ASTM': {'unit':'-','method':'ASTM D1500','normal':'<2.0','caution':'>6.0'},
    'Appearance': {'unit':'-','method':'ASTM D1524'},
    'Room Test Temperature': {'unit':'°C'}, 'Room Test Humidity': {'unit':'%'},
}


def _fmt_date(value: Any) -> str:
    if value is None:
        return '—'
    if isinstance(value, datetime):
        return value.strftime('%d/%m/%Y')
    text = str(value)
    try:
        return datetime.fromisoformat(text.replace('Z','+00:00')).strftime('%d/%m/%Y')
    except Exception:
        return text[:10] if text else '—'


def _sample_keys(sample: SampleRequest) -> set[str]:
    keys = {str(sample.request_number), str(sample.id), str(sample.barcode_value)}
    if sample.lms_number:
        keys.add(str(sample.lms_number))
    if sample.client_sample_reference:
        keys.add(str(sample.client_sample_reference))
    return {x for x in keys if x and x != 'None'}


def _result_ts(row: dict) -> str:
    return str(row.get('ts') or row.get('timestamp') or '')


def _latest(rows: list[dict]) -> dict | None:
    if not rows:
        return None
    return dict(sorted(rows, key=_result_ts)[-1])


def canonical_test_name(row: dict) -> str:
    raw = str(row.get('display_test') or row.get('test') or '').strip()
    n = normalized_test_text(raw)
    # DGA
    if n.startswith('dga:h2') or 'hydrogen (h2)' in n or n == 'hydrogen': return 'Hydrogen (H2)'
    if n.startswith('dga:o2') or n in {'oxygen','oxygen (o2)'}: return 'Oxygen (O2)'
    if n.startswith('dga:n2') or n in {'nitrogen','nitrogen (n2)'}: return 'Nitrogen (N2)'
    if n.startswith('dga:c2h4') or 'ethylene' in n: return 'Ethylene (C2H4)'
    if n.startswith('dga:c2h6') or n in {'ethane','ethane (c2h6)'}: return 'Ethane (C2H6)'
    if n.startswith('dga:c2h2') or 'acetylene' in n: return 'Acetylene (C2H2)'
    if n.startswith('dga:ch4') or n in {'methane','methane (ch4)'}: return 'Methane (CH4)'
    if n.startswith('dga:co2') or 'carbon dioxide' in n: return 'Carbon Dioxide (CO2)'
    if (n.startswith('dga:co') and not n.startswith('dga:co2')) or 'carbon monoxide' in n: return 'Carbon Monoxide (CO)'
    if 'total volume' in n: return 'Total Volume of Gases'
    if 'equilibrium' in n and ('press' in n or 'gas' in n): return 'Equilibrium Gas Pressure @40°C'
    if 'co2/co' in n: return 'CO2/CO Ratio'
    # Furan / DP
    if '2fal' in n or '2-fal' in n or '2-furfural' in n: return '2-Furfural (2FAL)'
    if 'total furan' in n or 'furan_calc:total' in n: return 'Total Furanic Compounds'
    if 'paper lifetime' in n or 'paper_life' in n: return 'Paper Lifetime Remaining Years'
    if 'indirect dp' in n or 'furan_calc:indirect_dp' in n: return 'Indirect DP-value'
    if 'direct dp' in n or 'dp-value of paper' in n or 'degree of polymerization' in n: return 'Direct DP-value'
    # Oil quality core
    if 'total acid number' in n or n == 'acidity' or n.startswith('tan'): return 'Total Acid Number'
    if 'water content kf' in n or n in {'water','water content'}: return 'Water Content KF @RT'
    if 'transformer oil temperature' in n or n in {'water:temp','oil temperature'}: return 'Transformer Oil Temperature'
    if 'water content @20' in n or 'water content @ 20' in n: return 'Water Content @20 °C'
    if 'humidity in cellulose' in n: return 'Humidity in Cellulose'
    if 'relative saturation' in n: return 'Relative Saturation Water in Oil'
    if 'interfacial tension' in n or n == 'ift': return 'Interfacial Tension (IFT)'
    if ('breakdown voltage' in n or 'bdv' in n) and ('2.5' in n or '2,5' in n) and 'rsd' not in n: return 'Breakdown Voltage @2.5mm AVG'
    if 'rsd' in n and ('2.5' in n or '2,5' in n): return 'RSD% of BDV @2.5mm'
    if ('breakdown voltage' in n or 'bdv' in n) and '1mm' in n and 'rsd' not in n: return 'Breakdown Voltage @1mm AVG'
    if 'rsd' in n and '1mm' in n: return 'RSD% of BDV @1mm'
    if ('power factor' in n or 'pf' in n) and '25' in n: return 'Power Factor @25°C/60Hz'
    if ('power factor' in n or 'pf' in n) and '100' in n: return 'Power Factor @100°C/60Hz'
    if 'dissipation factor' in n and '90' in n: return 'Dissipation Factor @90°C/60Hz'
    if 'resistivity' in n: return 'Resistivity'
    if 'oil quality index' in n or n == 'oqi': return 'Oil Quality Index'
    if 'color' in n: return 'Color ASTM'
    if 'appearance' in n: return 'Appearance'
    if 'room test temperature' in n: return 'Room Test Temperature'
    if 'room test humidity' in n: return 'Room Test Humidity'
    # Corrosion
    if 'potentially corrosive' in n or n == 'ccd' or 'iec 62535' in n: return 'Potentially Corrosive Sulfur (CCD)'
    if 'corrosive sulfur' in n: return 'Corrosive Sulfur'
    if 'tarnish' in n: return 'Tarnish Level'
    if 'copper corrosion' in n or 'copper strip' in n: return 'ASTM Copper Corrosion (Cu Strip)'
    return raw or 'Unnamed Test'


def _group_for_name(name: str) -> str:
    if name in DGA_ORDER: return 'dga'
    if name in FURAN_ORDER or name == 'Indirect DP-value': return 'furan'
    if name in {'Corrosive Sulfur','Tarnish Level','Potentially Corrosive Sulfur (CCD)','ASTM Copper Corrosion (Cu Strip)'}: return 'corrosion'
    return 'oil'


def _sample_results(ops: dict, sample: SampleRequest) -> dict[str, dict]:
    keys = _sample_keys(sample)
    matched = [r for r in ops.get('results', []) if str(r.get('sample') or r.get('sample_id') or '') in keys]
    by_name: dict[str, list[dict]] = {}
    for r in matched:
        raw_test = str(r.get('display_test') or r.get('test') or '')
        code = str(r.get('test') or '')
        if is_raw_water_instrument_row(raw_test) or is_raw_water_instrument_row(code):
            # EQ-69 / EQ-70 (and future per-instrument Water rows) remain audit evidence only.
            # Senior review and both reports consume only the controlled WATER:KF_RT average.
            continue
        name = canonical_test_name(r)
        by_name.setdefault(name, []).append(r)
    return {name: _latest(rows) for name, rows in by_name.items() if rows}


def _rule_overlay(db: Session, site_id: int, name: str, row: dict | None) -> dict[str, str]:
    spec = dict(REPORT_SPECS.get(name, {}))
    method = str((row or {}).get('method') or spec.get('method') or '').strip()
    unit = str((row or {}).get('unit') or spec.get('unit') or '').strip()
    candidates = db.query(TechnicalResultRule).filter(
        TechnicalResultRule.status == 'ACTIVE',
        (TechnicalResultRule.site_id == site_id) | (TechnicalResultRule.site_id.is_(None)),
    ).all()
    lname = name.lower()
    best = None
    for rule in candidates:
        hay = ' '.join([rule.test_name or '', rule.result_field or '', rule.method_name or '']).lower()
        raw = str((row or {}).get('test') or '').lower()
        if lname in hay or (raw and raw in hay) or any(tok in hay for tok in re.findall(r'[a-z0-9]+', lname) if len(tok) > 4):
            best = rule; break
    if best:
        if best.unit: unit = best.unit
        if best.method_name: method = best.method_name
        if best.detection_limit is not None: spec['dl'] = f'{best.detection_limit:g}'
        # Optional structured display rule: {"uncertainty":"+/- 2 %","normal":"<30","caution":">40"}
        raw_rule = (best.report_display_rule or '').strip()
        if raw_rule.startswith('{'):
            try:
                extra = json.loads(raw_rule)
                for key in ('uncertainty','normal','caution','dl'):
                    if extra.get(key) not in (None,''): spec[key] = str(extra[key])
            except Exception:
                pass
    spec['method'] = method or '—'
    spec['unit'] = unit or '—'
    return {k: str(v) if v not in (None,'') else '—' for k,v in spec.items()}


def _report_display_result(name: str, value: object) -> str:
    return report_display_result(name, value)

def _historical_group(db: Session, site: Site, reports: list[ControlledReport], ops: dict, names_order: list[str], group_name: str) -> dict:
    columns = []
    sample_maps: dict[int, dict[str,dict]] = {}
    for report in reports:
        sample = report.sample
        sample_maps[sample.id] = _sample_results(ops, sample)
        columns.append({
            'sample_id': sample.id, 'number': report.report_number or sample.request_number,
            'date': _fmt_date(report.approved_at or sample.sample_date_time),
            'current': report.id == reports[0].id,
        })
    all_names = []
    for name in names_order:
        if any(name in sample_maps.get(r.sample.id,{}) for r in reports): all_names.append(name)
    extras = []
    for r in reports:
        for name in sample_maps.get(r.sample.id,{}):
            if _group_for_name(name)==group_name and name not in all_names and name not in {'Indirect DP-value','Direct DP-value'}:
                extras.append(name)
    for name in sorted(set(extras)):
        all_names.append(name)
    rows = []
    for name in all_names:
        current = sample_maps.get(reports[0].sample.id,{}).get(name)
        source = current or next((sample_maps.get(r.sample.id,{}).get(name) for r in reports[1:] if sample_maps.get(r.sample.id,{}).get(name)), None)
        spec = _rule_overlay(db, site.id, name, source)
        values = {}
        for r in reports:
            rr = sample_maps.get(r.sample.id,{}).get(name)
            values[str(r.sample.id)] = _report_display_result(name, (rr or {}).get('result') or '—')
        rows.append({
            'test': name, 'unit': spec.get('unit','—'), 'method': spec.get('method','—'),
            'uncertainty': spec.get('uncertainty','—'), 'normal': spec.get('normal','—'),
            'caution': spec.get('caution','—'), 'dl': spec.get('dl','—'), 'values': values,
        })
    return {'columns': columns, 'rows': rows}


def _history_value(events: list[AssetHistoryEvent], *tokens: str) -> str:
    for ev in events:
        text = f'{ev.event_type} {ev.details}'.lower()
        if any(tok.lower() in text for tok in tokens):
            return ev.details or ev.event_type.replace('_',' ').title()
    return '—'


def _condition_text(condition: str) -> str:
    c = (condition or '').upper()
    return {'NORMAL':'Green','CAUTION':'Orange','CRITICAL':'Red'}.get(c, c or 'Under Review')


def _number(value: Any) -> float | None:
    if value in (None,'','—'): return None
    m = re.search(r'-?\d+(?:\.\d+)?', str(value))
    try: return float(m.group(0)) if m else None
    except Exception: return None


def build_final_report_payload(db: Session, row: ControlledReport, site: Site, *, verification_url: str = '') -> dict:
    _, ops = get_operations_state(db, site)
    current = row
    previous = (db.query(ControlledReport)
        .join(SampleRequest, ControlledReport.sample_request_id == SampleRequest.id)
        .filter(
            SampleRequest.asset_id == row.sample.asset_id,
            ControlledReport.id != row.id,
            ControlledReport.status == SampleStatus.REPORT_RELEASED.value,
        )
        .order_by(ControlledReport.approved_at.desc(), ControlledReport.created_at.desc()).limit(3).all())
    reports = [current] + previous
    sample = row.sample; asset = sample.asset; client = sample.client
    current_results = _sample_results(ops, sample)
    batch = next((b for b in ops.get('batches', []) if sample.request_number in [str(x) for x in b.get('samples', [])]), None)
    sample_meta = ((batch or {}).get('sample_meta') or {}).get(sample.request_number, {}) if batch else {}
    room_temp_row = current_results.get('Room Test Temperature') or {}
    room_humidity_row = current_results.get('Room Test Humidity') or {}
    lab_room = {
        'temperature_c': str(room_temp_row.get('result') or sample_meta.get('roomTemp') or (batch or {}).get('roomTemp') or '—'),
        'humidity_pct': str(room_humidity_row.get('result') or sample_meta.get('roomHumidity') or (batch or {}).get('roomHumidity') or '—'),
        'recorded_at': str(room_temp_row.get('ts') or room_humidity_row.get('ts') or sample_meta.get('roomConditionAt') or (batch or {}).get('roomConditionAt') or '—'),
        'recorded_by': str(room_temp_row.get('analyst') or room_humidity_row.get('analyst') or sample_meta.get('roomConditionBy') or (batch or {}).get('roomConditionBy') or '—'),
        'source': 'Laboratory room condition board / Water-BDV-PF work group',
    }
    events = db.query(AssetHistoryEvent).filter(AssetHistoryEvent.asset_id == asset.id).order_by(AssetHistoryEvent.event_at.desc()).limit(40).all()
    evidence = db.query(EvidenceRecord).filter(EvidenceRecord.sample_request_id == sample.id).order_by(EvidenceRecord.created_at).all()
    try: flags = json.loads(row.report_payload_json or '{}')
    except Exception: flags = {}
    try: assessment = assess_sample(db, sample)
    except Exception: assessment = {}

    dga = _historical_group(db, site, reports, ops, DGA_ORDER, 'dga')
    furan = _historical_group(db, site, reports, ops, FURAN_ORDER, 'furan')
    oil = _historical_group(db, site, reports, ops, OIL_ORDER, 'oil')
    dga['standard'] = 'STANDARD IEC 60567 / IEC 60599'
    furan['standard'] = 'STANDARD IEC 61198'
    dga['interpretation'] = row.interpretation if dga['rows'] else ''
    furan['interpretation'] = 'Furanic compounds and derived paper condition are interpreted against transformer history and the approved laboratory method.' if furan['rows'] else ''
    oil['interpretation'] = row.interpretation if oil['rows'] and not dga['rows'] else 'Oil-quality parameters are reviewed together with trend, method-specific limits and transformer operating context.'

    # Present the client report in the same operational family sequence used by the laboratory.
    # DGA and Furan retain their controlled history groups; oil/physical/additive rows are split
    # without changing their analytical values or historical columns.
    report_groups = []
    if dga.get('rows'):
        report_groups.append({'key':'dga','label':report_group_label('dga'),**dga})
    oil_buckets = {key: [] for key in REPORT_GROUP_ORDER}
    for item in oil.get('rows') or []:
        key = report_group_key(str(item.get('test') or ''), 'Oil Quality')
        oil_buckets.setdefault(key, []).append(item)
    for key in ('water_electrical','physical_visual','tan_family','oqi'):
        rows = oil_buckets.get(key) or []
        if rows:
            report_groups.append({'key':key,'label':report_group_label(key),'columns':oil.get('columns',[]),'rows':rows,'interpretation':''})
    if furan.get('rows'):
        report_groups.append({'key':'furan','label':report_group_label('furan'),**furan})
    for key in ('gc_additives','corrosion_flash_metals','other'):
        rows = oil_buckets.get(key) or []
        if rows:
            report_groups.append({'key':key,'label':report_group_label(key),'columns':oil.get('columns',[]),'rows':rows,'interpretation':''})

    dga_diag = {}
    if assessment.get('dga'):
        ratios = {k: ('—' if v is None else f'{v:.3g}') for k,v in (assessment['dga'].get('ratios') or {}).items()}
        dga_diag = {
            'ratios': ratios,
            'methods': [
                {'name':'IEC Ratio', 'result': assessment['dga'].get('fault') or 'Not defined'},
                {'name':'System Screening', 'result': assessment.get('overall') or 'Review'},
            ],
        }

    dp_row = current_results.get('Indirect DP-value') or {}
    dp_val = str(dp_row.get('result') or '—')
    # The current controlled workstation calculates one indirect-DP model from 2-FAL.
    # The supplied client template displays three literature-model columns.  Do not
    # fabricate De Pablo/Stebbin values from the single controlled calculation.
    # For an LTD 2-FAL result the approved report convention is >1000 for all three;
    # otherwise only the controlled system calculation is populated until dedicated
    # formula/rule masters for the other models are configured.
    if dp_val != '—':
        if dp_val.strip().startswith('>'):
            furan_dp = {'chendong': dp_val, 'de_pablo': dp_val, 'stebbin': dp_val}
        else:
            furan_dp = {'chendong': dp_val, 'de_pablo': '—', 'stebbin': '—'}
    else:
        furan_dp = {}

    corr_rows = []
    for name in ('ASTM Copper Corrosion (Cu Strip)','Corrosive Sulfur','Tarnish Level','Potentially Corrosive Sulfur (CCD)'):
        if name in current_results:
            rr = current_results[name]; corr_rows.append({'test':name,'result':str(rr.get('result') or '—'),'method':str(rr.get('method') or REPORT_SPECS.get(name,{}).get('method') or '—')})
    corr_image = next((e.stored_path for e in evidence if e.evidence_type.startswith('CORROSIVE_') and str(e.stored_path).lower().endswith(('.jpg','.jpeg','.png','.webp'))), '')
    conclusion = ''
    for rr in corr_rows:
        if rr['test'] in {'Corrosive Sulfur','Potentially Corrosive Sulfur (CCD)'}:
            conclusion = rr['result']; break
    corrosion = {
        'requested': bool(flags.get('corrosive_sulfur_requested')),
        'rows': corr_rows,
        'image_path': corr_image,
        'conclusion': conclusion,
        'principle': 'The controlled method evaluates corrosive sulfur by the approved copper / paper exposure and visual classification procedure. The retained image evidence and method-specific result are part of this report record.',
    }

    # Put corrosive-sulfur / CCD rows into the same ordered result-family stream as every
    # other test.  Visual evidence remains a separate controlled evidence panel; the result
    # itself is not duplicated later in the report.
    if corr_rows:
        family = next((g for g in report_groups if g.get('key') == 'corrosion_flash_metals'), None)
        if family is None:
            family = {
                'key': 'corrosion_flash_metals', 'label': report_group_label('corrosion_flash_metals'),
                'columns': list(oil.get('columns') or []), 'rows': [], 'interpretation': '',
            }
            report_groups.append(family)
        existing_names = {str(x.get('test') or '') for x in family.get('rows') or []}
        for rr in corr_rows:
            name = str(rr.get('test') or '')
            if name in existing_names:
                continue
            source = current_results.get(name) or {}
            spec = _rule_overlay(db, site.id, name, source)
            values = {str(c.get('sample_id')): '—' for c in family.get('columns') or []}
            values[str(sample.id)] = _report_display_result(name, rr.get('result') or '—')
            family['rows'].append({
                'test': name, 'unit': spec.get('unit','—'), 'method': rr.get('method') or spec.get('method','—'),
                'uncertainty': spec.get('uncertainty','—'), 'normal': spec.get('normal','—'),
                'caution': spec.get('caution','—'), 'dl': spec.get('dl','—'), 'values': values,
            })
            existing_names.add(name)
    report_groups.sort(key=lambda g: REPORT_GROUP_ORDER.index(g.get('key')) if g.get('key') in REPORT_GROUP_ORDER else len(REPORT_GROUP_ORDER))
    for group in report_groups:
        group['rows'] = sorted(group.get('rows') or [], key=lambda x: report_sort_key(str(x.get('test') or ''), str(group.get('label') or '')))

    # Direct DP is a destructive paper-sample result and must never be mixed with
    # indirect DP calculated from furan. Keep it as a separately controlled client
    # result, while allowing the report presentation to place specialty paper / 
    # corrosive-sulfur evidence together when both were requested.
    direct_dp = current_results.get('Direct DP-value') or {}
    paper_dp = {
        'requested': bool(flags.get('paper_dp_requested')),
        'title': 'Direct DP-value on Paper Sample',
        'result': str(direct_dp.get('result') or '—'),
        'unit': str(direct_dp.get('unit') or '-'),
        'method': str(direct_dp.get('method') or 'IEC 60450'),
        'analyst': str(direct_dp.get('analyst') or '—'),
        'available': bool(direct_dp),
    }

    last = previous[0] if previous else None
    latest_report_event = next((e for e in events if e.report_number), None)
    transformer_history = {
        'last_report_date': _fmt_date(last.approved_at if last else (latest_report_event.event_at if latest_report_event else None)),
        'last_report_number': (last.report_number if last else (latest_report_event.report_number if latest_report_event else '—')),
        'fluid_treatment': _history_value(events,'fluid treatment','oil treatment','replacement'),
        'tap_changer_maintenance': _history_value(events,'tap changer','oltc'),
        'fluid_supplement': _history_value(events,'fluid supplement','oil supplement'),
        'events_observed': _history_value(events,'event observed','incident','fault'),
        'repairs': _history_value(events,'repair','modification'),
    }

    sampler = sample.sampler.full_name if sample.sampler else ('Client' if 'client' in (sample.sample_origin or '').lower() else '—')
    report_status = row.status.replace('_',' ').title()
    payload = {
        'template_code': 'QDF-[7]-08-A',
        'report': {
            'id': row.id, 'number': row.report_number, 'revision': row.revision,
            'condition': row.condition_status or 'UNDER REVIEW', 'condition_color': _condition_text(row.condition_status),
            'status': report_status, 'interpretation': row.interpretation or '', 'recommendation': row.recommendation or '',
            'verification_url': verification_url,
        },
        'client': {
            'name': client.name if client else '—', 'address': '—', 'contact_name': '—',
            'email': client.contact_email if client else '—', 'phone': client.contact_phone if client else '—',
        },
        'asset': {
            'serial_number': asset.serial_number, 'reference': asset.asset_code,
            'voltage': f"{asset.hv_voltage_kv if asset.hv_voltage_kv is not None else asset.voltage_kv or '—'} / {asset.lv_voltage_kv if asset.lv_voltage_kv is not None else '—'}",
            'sealing_system': asset.sealing_system, 'tag_number': asset.tag_number, 'rated_mva': asset.rated_mva,
            'cooling_type': asset.cooling_type, 'equipment_type': asset.equipment_type, 'load_pct': '—',
            'manufacturer_country': asset.manufacturer_country, 'location': asset.asset_location_label,
            'operating_period': asset.operating_period, 'manufacturer': asset.manufacturer,
            'substation': asset.station_name, 'phase': asset.phase, 'manufacture_year': asset.manufacture_year,
            'oil_type': asset.oil_type, 'oil_weight': (f'{asset.oil_weight_kg:g} kg' if asset.oil_weight_kg is not None else '—'),
            'owner': asset.owner_name or (client.name if client else '—'), 'tap_changer_type': asset.tap_changer_type,
            'tap_changer_chamber': asset.tap_changer_chamber,
        },
        'sample': {
            'request_number': sample.request_number, 'sampling_from': sample.sampling_point, 'sampler': sampler,
            'sampling_date': _fmt_date(sample.sample_date_time), 'arrival_date': _fmt_date(sample.received_at or sample.registered_at),
            'oil_temp': sample.oil_temperature_c, 'ambient_temp': sample.ambient_temperature_c, 'humidity': sample.ambient_humidity_pct,
            'equipment_status': sample.equipment_status, 'sampling_reason': sample.sampling_reason,
            'po_number': (sample.purchase_order.number if sample.purchase_order else '—'), 'work_order': sample.work_order_number,
            'sap_number': sample.sap_number, 'origin': sample.sample_origin,
        },
        'transformer_history': transformer_history, 'lab_room': lab_room,
        'dga': dga, 'dga_diagnostics': dga_diag, 'furan': furan, 'furan_dp': furan_dp, 'oil': oil, 'report_groups': report_groups,
        'paper_dp': paper_dp, 'corrosion': corrosion,
        'approval': {
            'reviewed_by': row.reviewed_by.full_name if row.reviewed_by else '—',
            'approved_by': row.approved_by.full_name if row.approved_by else '—',
            'approved_at': _fmt_date(row.approved_at),
        },
    }

    # Nine trends used on the supplied client report's graph page.
    trend_names = ['Hydrogen (H2)','Carbon Monoxide (CO)','Carbon Dioxide (CO2)','Acetylene (C2H2)','Ethylene (C2H4)','Ethane (C2H6)','Total Acid Number','Water Content KF @RT','Interfacial Tension (IFT)']
    sample_maps = {r.sample.id: _sample_results(ops, r.sample) for r in reports}
    charts = []
    for name in trend_names:
        values=[]; labels=[]
        for r in reversed(reports):
            rr = sample_maps.get(r.sample.id,{}).get(name)
            labels.append(_fmt_date(r.approved_at or r.sample.sample_date_time))
            values.append(_number((rr or {}).get('result')))
        if any(v is not None for v in values): charts.append({'title':name,'labels':labels,'values':values})
    payload['charts'] = charts
    return payload
