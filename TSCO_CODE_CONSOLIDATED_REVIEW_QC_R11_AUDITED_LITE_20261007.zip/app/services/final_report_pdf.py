from __future__ import annotations

import io
import os
from pathlib import Path
from typing import Any

import qrcode
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.shapes import Drawing, String
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    Image,
    KeepTogether,
    LongTable,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

PAGE_W, PAGE_H = A4
BLUE = colors.HexColor('#1f4f88')
LIGHT_BLUE = colors.HexColor('#cfe7f5')
PALE_BLUE = colors.HexColor('#eef6fb')
PALE_GREEN = colors.HexColor('#d8f2df')
MID_GREEN = colors.HexColor('#8ed69d')
PALE_ORANGE = colors.HexColor('#fff0d8')
PALE_RED = colors.HexColor('#f9dada')
GRID = colors.HexColor('#9fb7c8')
TEXT = colors.HexColor('#1d2630')
MUTED = colors.HexColor('#5b6773')

REPORT_TEMPLATE_CODE = 'QDF-[7]-08-A'
DEFAULT_FOOTER = (
    'Address: Kingdom of Saudi Arabia, Port Gate - Dammam   |   '
    'Email: analytical@gccelab.com   |   CR:2050115585   |   '
    'Telephone: +966 13 8689800 Ext. 370 - Ext. 465'
)


def _s(value: Any, fallback: str = '—') -> str:
    if value is None:
        return fallback
    text = str(value).strip()
    return text if text else fallback


def _p(text: Any, style: ParagraphStyle) -> Paragraph:
    return Paragraph(_s(text).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;'), style)


def _qr_image(url: str, size_mm: float = 24) -> Image:
    img = qrcode.make(url or 'TSCO Digital Laboratory Platform')
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    buf.seek(0)
    return Image(buf, width=size_mm * mm, height=size_mm * mm)


def _condition_fill(condition: str):
    value = (condition or '').upper()
    if value == 'NORMAL':
        return PALE_GREEN
    if value == 'CAUTION':
        return PALE_ORANGE
    if value == 'CRITICAL':
        return PALE_RED
    return colors.white


def _header_footer(canvas, doc, logo_path: str | None, footer_text: str):
    canvas.saveState()
    if logo_path and Path(logo_path).exists():
        try:
            canvas.drawImage(logo_path, 17 * mm, PAGE_H - 28 * mm, width=37 * mm, height=14 * mm, preserveAspectRatio=True, mask='auto')
        except Exception:
            pass
    # Accreditation marks are controlled assets.  They are deliberately not
    # scraped/cropped from a previous client report.  Quality can provide the
    # approved current mark files through these deployment paths.
    accreditation = [
        os.getenv('TSCO_REPORT_ACCREDITATION_LOGO_1', '').strip(),
        os.getenv('TSCO_REPORT_ACCREDITATION_LOGO_2', '').strip(),
    ]
    x = PAGE_W - 62 * mm
    for mark in [m for m in accreditation if m and Path(m).exists()]:
        try:
            canvas.drawImage(mark, x, PAGE_H - 28 * mm, width=18 * mm, height=14 * mm, preserveAspectRatio=True, mask='auto')
            x += 19 * mm
        except Exception:
            continue
    canvas.setFont('Helvetica', 17)
    canvas.setFillColor(colors.black)
    canvas.drawCentredString(PAGE_W / 2, PAGE_H - 20 * mm, 'ANALYSIS REPORT')
    canvas.setFont('Helvetica', 7)
    canvas.drawRightString(PAGE_W - 16 * mm, PAGE_H - 10 * mm, REPORT_TEMPLATE_CODE)
    canvas.setStrokeColor(BLUE)
    canvas.setLineWidth(0.8)
    canvas.line(16 * mm, PAGE_H - 31 * mm, PAGE_W - 16 * mm, PAGE_H - 31 * mm)

    canvas.setStrokeColor(BLUE)
    canvas.setLineWidth(0.6)
    canvas.line(16 * mm, 14 * mm, PAGE_W - 16 * mm, 14 * mm)
    canvas.setFont('Helvetica', 5.8)
    canvas.setFillColor(colors.HexColor('#434b53'))
    canvas.drawString(16 * mm, 9 * mm, footer_text[:190])
    canvas.setFillColor(BLUE)
    canvas.drawRightString(PAGE_W - 16 * mm, 9 * mm, f'Page {doc.page}')
    canvas.restoreState()


def _styles():
    base = getSampleStyleSheet()
    return {
        'body': ParagraphStyle('report-body', parent=base['BodyText'], fontName='Helvetica', fontSize=7.4, leading=9.4, textColor=TEXT),
        'small': ParagraphStyle('report-small', parent=base['BodyText'], fontName='Helvetica', fontSize=6.2, leading=7.5, textColor=MUTED),
        'tiny': ParagraphStyle('report-tiny', parent=base['BodyText'], fontName='Helvetica', fontSize=5.6, leading=6.7, textColor=MUTED),
        'label': ParagraphStyle('report-label', parent=base['BodyText'], fontName='Helvetica-Bold', fontSize=6.4, leading=7.4, textColor=BLUE),
        'section': ParagraphStyle('report-section', parent=base['Heading2'], fontName='Helvetica', fontSize=11, leading=13, textColor=BLUE, spaceBefore=3 * mm, spaceAfter=2 * mm),
        'subsection': ParagraphStyle('report-subsection', parent=base['Heading3'], fontName='Helvetica-Bold', fontSize=8.5, leading=10, textColor=BLUE, spaceBefore=2 * mm, spaceAfter=1 * mm),
        'center': ParagraphStyle('report-center', parent=base['BodyText'], fontName='Helvetica', fontSize=7, leading=8.5, alignment=TA_CENTER, textColor=TEXT),
        'center_bold': ParagraphStyle('report-center-bold', parent=base['BodyText'], fontName='Helvetica-Bold', fontSize=7.1, leading=8.4, alignment=TA_CENTER, textColor=TEXT),
        'interpret': ParagraphStyle('report-interpret', parent=base['BodyText'], fontName='Helvetica', fontSize=7.5, leading=9.5, textColor=TEXT, borderColor=GRID, borderWidth=.4, borderPadding=5, backColor=colors.HexColor('#edf6f1')),
    }


def _report_identity(payload: dict, styles: dict) -> Table:
    report = payload['report']
    asset = payload['asset']
    rows = [[
        _p('Report N°:', styles['label']), _p(report['number'], styles['body']),
        _p('Substation:', styles['label']), _p(asset.get('substation'), styles['body']),
        _p('Transformer Ref:', styles['label']), _p(asset.get('reference'), styles['body']),
    ]]
    t = Table(rows, colWidths=[19*mm, 34*mm, 20*mm, 38*mm, 24*mm, 48*mm])
    t.setStyle(TableStyle([
        ('GRID',(0,0),(-1,-1),0.55,colors.HexColor('#495057')),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('BACKGROUND',(0,0),(-1,-1),colors.white),
        ('LEFTPADDING',(0,0),(-1,-1),4),('RIGHTPADDING',(0,0),(-1,-1),4),
        ('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4),
    ]))
    return t


def _kv_table(items: list[tuple[str, Any]], styles: dict, columns: int = 3) -> Table:
    rows = []
    cells = []
    for label, value in items:
        cells.extend([_p(label.upper(), styles['label']), _p(value, styles['body'])])
        if len(cells) == columns * 2:
            rows.append(cells); cells = []
    if cells:
        while len(cells) < columns * 2:
            cells.extend(['',''])
        rows.append(cells)
    widths = []
    pair_total = 178 * mm / columns
    for _ in range(columns):
        widths.extend([pair_total * .34, pair_total * .66])
    t = Table(rows, colWidths=widths, repeatRows=0)
    t.setStyle(TableStyle([
        ('GRID',(0,0),(-1,-1),0.35,GRID),('VALIGN',(0,0),(-1,-1),'MIDDLE'),
        ('BACKGROUND',(0,0),(-1,-1),colors.white),
        ('LEFTPADDING',(0,0),(-1,-1),3),('RIGHTPADDING',(0,0),(-1,-1),3),
        ('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3),
    ]))
    return t


def _history_table(payload: dict, styles: dict) -> Table:
    hist = payload.get('transformer_history', {})
    rows = [
        [_p('LAST REPORT (DATE)', styles['label']), _p(hist.get('last_report_date'), styles['body']), _p('LAST REPORT NUMBER', styles['label']), _p(hist.get('last_report_number'), styles['body'])],
        [_p('FLUID TREATMENT/REPLACEMENT', styles['label']), _p(hist.get('fluid_treatment'), styles['body']), _p('TAP CHANGER MAINTENANCE', styles['label']), _p(hist.get('tap_changer_maintenance'), styles['body'])],
        [_p('FLUID SUPPLEMENT', styles['label']), _p(hist.get('fluid_supplement'), styles['body']), _p('EVENTS OBSERVED', styles['label']), _p(hist.get('events_observed'), styles['body'])],
        [_p('REPAIRING OR MODIFICATIONS', styles['label']), _p(hist.get('repairs'), styles['body']), '', ''],
    ]
    t = Table(rows, colWidths=[37*mm,52*mm,37*mm,52*mm])
    t.setStyle(TableStyle([
        ('GRID',(0,0),(-1,-1),0.35,GRID),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('SPAN',(1,3),(3,3)),
        ('LEFTPADDING',(0,0),(-1,-1),3),('RIGHTPADDING',(0,0),(-1,-1),3),
        ('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3),
    ]))
    return t


def _condition_block(payload: dict, styles: dict) -> Table:
    report = payload['report']
    asset = payload['asset']
    condition = report.get('condition') or 'UNDER REVIEW'
    legend = Table([
        [Paragraph('<font color="#178c4d">●</font>', styles['center_bold']), _p('Green : NORMAL CONDITION (No Action Required)', styles['tiny'])],
        [Paragraph('<font color="#e38616">●</font>', styles['center_bold']), _p('Orange : CAUTION CONDITION (Prepare maintenance operation)', styles['tiny'])],
        [Paragraph('<font color="#c83333">●</font>', styles['center_bold']), _p('Red : CRITICAL CONDITION (Action Required)', styles['tiny'])],
    ], colWidths=[6*mm,74*mm])
    legend.setStyle(TableStyle([
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),1),('TOPPADDING',(0,0),(-1,-1),1),('BOTTOMPADDING',(0,0),(-1,-1),1),
    ]))
    status = Table([
        [_p('SUBSTATION', styles['label']), _p(asset.get('substation'), styles['body'])],
        [_p('TRANSFORMER REF', styles['label']), _p(asset.get('reference'), styles['body'])],
        ['', _p(condition, styles['center_bold'])],
    ], colWidths=[29*mm,38*mm])
    status.setStyle(TableStyle([
        ('GRID',(0,0),(-1,-1),0.35,GRID),('BACKGROUND',(1,2),(1,2),_condition_fill(condition)),('SPAN',(0,2),(0,2)),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),3),('RIGHTPADDING',(0,0),(-1,-1),3),('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3),
    ]))
    wrapper = Table([[legend,status]], colWidths=[107*mm,71*mm])
    wrapper.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),0)]))
    return wrapper


def _historical_table(title: str, section_label: str, group: dict, styles: dict, interpretation: str = '') -> list:
    flow = [_p(title, styles['section'])]
    if section_label:
        flow.append(_p(section_label, styles['small']))
        flow.append(Spacer(1, 1.5*mm))
    columns = group.get('columns', [])
    rows = group.get('rows', [])
    if not rows:
        flow.append(_p('No controlled results are available for this section.', styles['body']))
        return flow
    header = [_p('Test Name', styles['center_bold']), _p('Unit', styles['center_bold'])]
    from html import escape
    for col in columns:
        header.append(Paragraph(f"{escape(str(col.get('number','')))}<br/><font size='5'>{escape(str(col.get('date','')))}</font>", styles['center_bold']))
    header.extend([
        _p('Method', styles['center_bold']), Paragraph('Uncertainty<br/>k=2', styles['center_bold']),
        _p('Normal', styles['center_bold']), _p('Caution', styles['center_bold']), _p('DL', styles['center_bold'])
    ])
    data = [header]
    for item in rows:
        row = [_p(item.get('test'), styles['body']), _p(item.get('unit'), styles['center'])]
        for i, col in enumerate(columns):
            value = (item.get('values') or {}).get(str(col.get('sample_id')), '—')
            row.append(_p(value, styles['center_bold'] if i == 0 else styles['center']))
        row.extend([
            _p(item.get('method'), styles['center']), _p(item.get('uncertainty'), styles['center']),
            _p(item.get('normal'), styles['center']), _p(item.get('caution'), styles['center']), _p(item.get('dl'), styles['center'])
        ])
        data.append(row)
    hist_count = max(1, len(columns))
    fixed = 28 + 12 + 25 + 16 + 13 + 13 + 10
    remaining = 178 - fixed
    hist_w = max(15, remaining / hist_count)
    widths = [28*mm,12*mm] + [hist_w*mm for _ in columns] + [25*mm,16*mm,13*mm,13*mm,10*mm]
    t = LongTable(data, colWidths=widths, repeatRows=1)
    style = [
        ('GRID',(0,0),(-1,-1),0.35,GRID),('BACKGROUND',(0,0),(-1,0),LIGHT_BLUE),
        ('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),2),('RIGHTPADDING',(0,0),(-1,-1),2),
        ('TOPPADDING',(0,0),(-1,-1),2.5),('BOTTOMPADDING',(0,0),(-1,-1),2.5),
    ]
    if columns:
        style.append(('BACKGROUND',(2,1),(2,-1),PALE_GREEN))
    t.setStyle(TableStyle(style))
    flow.append(t)
    if interpretation:
        flow.extend([Spacer(1,2.5*mm), _p(f'INTERPRETATION: {interpretation}', styles['interpret'])])
    return flow


def _dga_diagnostics(payload: dict, styles: dict) -> list:
    d = payload.get('dga_diagnostics') or {}
    if not d:
        return []
    ratios = d.get('ratios') or {}
    ratio_data = [[_p(k, styles['center_bold']) for k in ratios.keys()], [_p(v, styles['center']) for v in ratios.values()]] if ratios else []
    flow = [_p('CONCENTRATION RATIOS & DIAGNOSTICS', styles['subsection'])]
    if ratio_data:
        t = Table(ratio_data, colWidths=[178*mm/len(ratios)]*len(ratios))
        t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.35,GRID),('BACKGROUND',(0,0),(-1,0),LIGHT_BLUE),('VALIGN',(0,0),(-1,-1),'MIDDLE')]))
        flow.append(t)
    methods = d.get('methods') or []
    if methods:
        m = [[_p('Method', styles['center_bold'])] + [_p(x.get('name'), styles['center_bold']) for x in methods],
             [_p('Result', styles['center_bold'])] + [_p(x.get('result'), styles['center']) for x in methods]]
        t = Table(m, colWidths=[26*mm]+[(152*mm/max(1,len(methods)))]*len(methods))
        t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.35,GRID),('BACKGROUND',(0,0),(-1,0),LIGHT_BLUE),('VALIGN',(0,0),(-1,-1),'MIDDLE')]))
        flow.extend([Spacer(1,2*mm), t])
    return flow


def _corrosion_page(payload: dict, styles: dict) -> list:
    c = payload.get('corrosion') or {}
    paper = payload.get('paper_dp') or {}
    if not c.get('requested') and not c.get('rows') and not paper.get('requested') and not paper.get('available'):
        return []
    flow = [PageBreak(), _report_identity(payload, styles), Spacer(1,5*mm), _p('SPECIALTY PAPER / CORROSION RESULTS', styles['section'])]
    flow.append(_p('Direct paper DP and corrosive-sulfur / CCD / tarnish are shown together when requested, while remaining distinct controlled test results.', styles['body']))
    if paper.get('requested') or paper.get('available'):
        flow.extend([Spacer(1,4*mm), _p('DIRECT DP-VALUE ON PAPER SAMPLE', styles['subsection'])])
        t = Table([
            [_p('Test',styles['center_bold']),_p('Result',styles['center_bold']),_p('Unit',styles['center_bold']),_p('Method',styles['center_bold'])],
            [_p('Degree of Polymerization - Direct Paper',styles['small']),_p(paper.get('result') or '—',styles['center_bold']),_p(paper.get('unit') or '-',styles['center']),_p(paper.get('method') or 'IEC 60450',styles['center'])],
        ], colWidths=[75*mm,30*mm,22*mm,51*mm])
        t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.35,GRID),('BACKGROUND',(0,0),(-1,0),LIGHT_BLUE),('VALIGN',(0,0),(-1,-1),'MIDDLE')]))
        flow.append(t)
    if c.get('requested') or c.get('rows'):
        flow.extend([Spacer(1,5*mm), _p('DETECTION OF CORROSIVE SULFUR RESULT', styles['section']), _p('CORROSIVE SULFUR / CCD / TARNISH', styles['subsection'])])
        flow.append(_p(c.get('principle') or 'Controlled corrosive-sulfur / copper-paper evaluation. Method-specific evidence and classification are retained with the report.', styles['body']))
        # The analytical classification/result is already emitted in the ordered
        # Corrosive Sulfur / Flash Point / Metals family table.  This specialty page
        # retains only method context and controlled visual evidence, avoiding duplicates.
        img_path = c.get('image_path')
        if img_path and Path(img_path).exists() and Path(img_path).suffix.lower() in {'.jpg','.jpeg','.png','.webp'}:
            try:
                img = Image(img_path, width=120*mm, height=86*mm, kind='proportional')
                wrap = Table([[img]], colWidths=[128*mm])
                wrap.setStyle(TableStyle([('BOX',(0,0),(-1,-1),1,BLUE),('ALIGN',(0,0),(-1,-1),'CENTER'),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),3),('RIGHTPADDING',(0,0),(-1,-1),3),('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3)]))
                flow.extend([Spacer(1,5*mm),wrap])
            except Exception:
                pass
        conclusion = c.get('conclusion') or 'Evidence attached - see controlled result classification.'
        flow.extend([Spacer(1,4*mm), _p(conclusion.upper(), styles['center_bold'])])
    return flow


def _mini_chart(title: str, labels: list[str], values: list[float | None], width=54*mm, height=47*mm):
    drawing = Drawing(width, height)
    drawing.add(String(width/2, height-7, title, fontName='Helvetica-Bold', fontSize=6.5, textAnchor='middle', fillColor=colors.HexColor('#24364c')))
    numeric = [float(v) if v is not None else 0.0 for v in values]
    chart = VerticalBarChart()
    chart.x = 10
    chart.y = 12
    chart.height = height - 24
    chart.width = width - 16
    chart.data = [numeric]
    chart.valueAxis.valueMin = 0
    vmax = max(numeric or [1])
    chart.valueAxis.valueMax = max(1, vmax * 1.18)
    chart.valueAxis.valueStep = max(1, chart.valueAxis.valueMax / 4)
    chart.valueAxis.labels.fontSize = 4.5
    chart.categoryAxis.categoryNames = [x[-8:] if len(x)>8 else x for x in labels]
    chart.categoryAxis.labels.fontSize = 4.2
    chart.categoryAxis.labels.angle = 0
    chart.bars[0].fillColor = BLUE
    chart.bars[0].strokeColor = None
    drawing.add(chart)
    return drawing


def _graphs_page(payload: dict, styles: dict) -> list:
    charts = payload.get('charts') or []
    if not charts:
        return []
    flow = [PageBreak(), _report_identity(payload, styles), Spacer(1,4*mm), _p('GRAPHS', styles['section'])]
    cells = []
    for ch in charts[:9]:
        cells.append(_mini_chart(ch.get('title','Trend'), ch.get('labels',[]), ch.get('values',[])))
    rows = []
    for i in range(0, len(cells), 3):
        row = cells[i:i+3]
        while len(row)<3: row.append('')
        rows.append(row)
    t = Table(rows, colWidths=[59*mm]*3)
    t.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('ALIGN',(0,0),(-1,-1),'CENTER'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),0),('TOPPADDING',(0,0),(-1,-1),1),('BOTTOMPADDING',(0,0),(-1,-1),1)]))
    flow.append(t)
    flow.extend([Spacer(1,5*mm), _p('RECOMMENDATION', styles['section']), _p(payload['report'].get('recommendation') or 'No additional recommendation recorded.', styles['interpret'])])
    return flow


def build_final_report_pdf(payload: dict, output_path: str | Path, *, qr_url: str = '', logo_path: str | None = None, footer_text: str | None = None) -> Path:
    """Render the official TSCO client report from an immutable report payload.

    The layout mirrors the controlled six-part Analysis Report supplied by the lab:
    identity/condition, DGA, Furan/DP, oil quality, corrosive-sulfur evidence, trends/recommendation.
    Pages are included only when the corresponding controlled result set is present/requested.
    """
    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    logo = logo_path or os.getenv('TSCO_REPORT_LOGO', '').strip() or str(Path(__file__).resolve().parents[1] / 'static' / 'tsco-analytical-brand.png')
    footer = footer_text or os.getenv('TSCO_REPORT_FOOTER', DEFAULT_FOOTER)
    styles = _styles()

    doc = SimpleDocTemplate(
        str(out), pagesize=A4, rightMargin=16*mm, leftMargin=16*mm,
        topMargin=37*mm, bottomMargin=19*mm, title=f"Analysis Report {payload['report']['number']}",
        author='TSCO Digital Laboratory Platform', subject='Controlled Transformer Oil Analysis Report'
    )

    story = []
    # Page 1: condition / identity / equipment / sampling / history
    story.append(_report_identity(payload, styles))
    story.extend([Spacer(1,4*mm), _condition_block(payload, styles), Spacer(1,3*mm)])
    client = payload['client']; asset = payload['asset']; sample = payload['sample']
    story.append(_kv_table([
        ('Name', client.get('name')), ('Address', client.get('address')), ('Contact Name', client.get('contact_name')),
        ('Email', client.get('email')), ('Tel.', client.get('phone')), ('Report Status', payload['report'].get('status')),
    ], styles, 3))
    story.extend([Spacer(1,3*mm), _p('EQUIPMENT DATA', styles['section'])])
    story.append(_kv_table([
        ('Serial Number', asset.get('serial_number')), ('Tension [HV/LV] (kV)', asset.get('voltage')), ('Sealing System', asset.get('sealing_system')),
        ('Tag Number', asset.get('tag_number')), ('Operated Rate Power (MVA)', asset.get('rated_mva')), ('Cooling Type', asset.get('cooling_type')),
        ('Equipment Type', asset.get('equipment_type')), ('Load %', asset.get('load_pct')), ('Manufacture Country', asset.get('manufacturer_country')),
        ('Location', asset.get('location')), ('Operating Period', asset.get('operating_period')), ('Manufacture Name', asset.get('manufacturer')),
        ('Substation', asset.get('substation')), ('Phase Number', asset.get('phase')), ('Manufacture Year', asset.get('manufacture_year')),
        ('Oil Type', asset.get('oil_type')), ('Oil Weight', asset.get('oil_weight')), ('Owner', asset.get('owner')),
        ('TC Type', asset.get('tap_changer_type')), ('TC Chamber', asset.get('tap_changer_chamber')), ('Asset Code', asset.get('reference')),
    ], styles, 3))
    story.extend([Spacer(1,3*mm), _p('SAMPLING DATA', styles['section'])])
    story.append(_kv_table([
        ('Sampling From', sample.get('sampling_from')), ('Sample Man', sample.get('sampler')), ('Sampling Date', sample.get('sampling_date')),
        ('Sample Arrival', sample.get('arrival_date')), ('Oil Temp., °C', sample.get('oil_temp')), ('Ambient Temp., °C', sample.get('ambient_temp')),
        ('Humidity, %', sample.get('humidity')), ('Equipment Status', sample.get('equipment_status')), ('Sampling Reason', sample.get('sampling_reason')),
        ('PO/CN Number', sample.get('po_number')), ('WO. No', sample.get('work_order')), ('SAP No.', sample.get('sap_number')),
    ], styles, 3))
    lab_room = payload.get('lab_room', {})
    story.extend([Spacer(1,3*mm), _p('LABORATORY ROOM CONDITIONS', styles['section'])])
    story.append(_kv_table([
        ('Lab Room Temperature, °C', lab_room.get('temperature_c')), ('Lab Room Humidity, %RH', lab_room.get('humidity_pct')), ('Recorded At', lab_room.get('recorded_at')),
        ('Recorded By', lab_room.get('recorded_by')), ('Source', lab_room.get('source')), ('Scope', 'Laboratory result snapshot'),
    ], styles, 3))
    story.extend([Spacer(1,3*mm), _p('TRANSFORMER EVENTS AND HISTORY', styles['section']), _history_table(payload, styles), Spacer(1,3*mm)])
    approval = payload.get('approval', {})
    qr = _qr_image(qr_url or payload['report'].get('verification_url',''))
    auth = Table([
        [_p('REVIEWED BY', styles['label']), _p(approval.get('reviewed_by'), styles['small'])],
        [_p('APPROVED BY', styles['label']), _p(approval.get('approved_by'), styles['small'])],
        [_p('RELEASED', styles['label']), _p(approval.get('approved_at'), styles['small'])],
        [_p('REVISION', styles['label']), _p(payload['report'].get('revision'), styles['small'])],
    ], colWidths=[30*mm, 105*mm])
    auth.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.3,GRID),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),3),('RIGHTPADDING',(0,0),(-1,-1),3),('TOPPADDING',(0,0),(-1,-1),2),('BOTTOMPADDING',(0,0),(-1,-1),2)]))
    sign = Table([[qr, auth]], colWidths=[34*mm, 144*mm])
    sign.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'BOTTOM'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),0)]))
    story.append(sign)

    # Results are emitted in the same operational family sequence used by Senior review.
    for group in payload.get('report_groups', []):
        if not group.get('rows'):
            continue
        story.append(PageBreak())
        story.append(_report_identity(payload, styles)); story.append(Spacer(1,3*mm))
        story.extend(_historical_table(str(group.get('label') or 'CONTROLLED RESULTS').upper(), str(group.get('standard') or ''), group, styles, str(group.get('interpretation') or '')))
        if group.get('key') == 'dga':
            story.extend(_dga_diagnostics(payload, styles))
        if group.get('key') == 'furan':
            dp = payload.get('furan_dp') or {}
            if dp:
                story.extend([Spacer(1,3*mm), _p('INTERPRETATION - CALCULATED AVERAGE DP', styles['subsection'])])
                dp_table = Table([
                    [_p('ACCORDING TO CHENDONG',styles['center_bold']), _p('ACCORDING TO DE PABLO',styles['center_bold']), _p('ACCORDING TO STEBBIN',styles['center_bold'])],
                    [_p(dp.get('chendong'),styles['center']), _p(dp.get('de_pablo'),styles['center']), _p(dp.get('stebbin'),styles['center'])]
                ], colWidths=[59.3*mm]*3)
                dp_table.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.35,GRID),('BACKGROUND',(0,0),(-1,0),LIGHT_BLUE)]))
                story.append(dp_table)

    story.extend(_corrosion_page(payload, styles))
    story.extend(_graphs_page(payload, styles))

    doc.build(story, onFirstPage=lambda c,d:_header_footer(c,d,logo,footer), onLaterPages=lambda c,d:_header_footer(c,d,logo,footer))
    return out
