from __future__ import annotations

import math
import re
from typing import Any

REPORT_GROUP_ORDER = [
    "dga",
    "water_electrical",
    "physical_visual",
    "tan_family",
    "oqi",
    "furan",
    "gc_additives",
    "corrosion_flash_metals",
    "other",
]

REPORT_GROUP_LABELS = {
    "dga": "DGA (Dissolved Gas Analysis)",
    "water_electrical": "Water / BDV / PF / Lab Room Conditions",
    "physical_visual": "IFT / Color / Appearance",
    "tan_family": "TAN / RSH / Peroxide",
    "oqi": "Oil Quality Index",
    "furan": "Furan / Paper",
    "gc_additives": "DBDS / Toluene / BHT / PCB",
    "corrosion_flash_metals": "Corrosive Sulfur / Flash Point / Metals",
    "other": "Other Tests",
}

_SUBSCRIPT_MAP = str.maketrans({
    "₀":"0","₁":"1","₂":"2","₃":"3","₄":"4","₅":"5","₆":"6","₇":"7","₈":"8","₉":"9",
})


_GROUP_TEST_ORDER = {
    "dga": ("hydrogen (h2)", "oxygen (o2)", "nitrogen (n2)", "methane (ch4)", "ethane (c2h6)", "ethylene (c2h4)", "acetylene (c2h2)", "carbon monoxide", "carbon dioxide", "total combustible gas", "total volume", "equilibrium gas", "co2/co"),
    "water_electrical": ("water content kf @rt", "room test temperature", "room test humidity", "breakdown voltage @2.5", "rsd% of bdv @2.5", "breakdown voltage @1mm", "rsd% of bdv @1mm", "power factor @25", "power factor @100", "dissipation factor", "resistivity", "transformer oil temperature", "water content @20", "humidity in cellulose", "relative saturation", "mineral oil log cw", "cw"),
    "physical_visual": ("interfacial tension", "color", "colour", "appearance"),
    "tan_family": ("total acid number", "acid number", "rsh", "mercaptan", "peroxide", "hydroperoxide", "hydrogen sulfide", "h2s"),
    "oqi": ("oil quality index", "oqi", "oqin"),
    "furan": ("2-furfural", "2fal", "total furan", "indirect dp", "paper lifetime", "direct dp", "polymerization"),
    "gc_additives": ("dbds", "dibenzyl", "toluene", "bht", "antioxidant", "pcb", "polychlorinated"),
    "corrosion_flash_metals": ("corrosive sulfur", "potentially corrosive", "tarnish", "copper corrosion", "flash point"),
}

_METAL_TOKENS = (
    "aluminum", "aluminium", "barium", "boron", "calcium", "chromium", "copper", "iron", "lead",
    "magnesium", "manganese", "molybdenum", "nickel", "phosphorous", "phosphorus", "potassium",
    "silicon", "silver", "sodium", "tin", "titanium", "vanadium", "zinc",
)


def normalized_test_text(value: Any) -> str:
    return str(value or "").translate(_SUBSCRIPT_MAP).lower().replace("–", "-").replace("—", "-").strip()


def report_group_key(test: str, source_group: str = "") -> str:
    name = normalized_test_text(test)
    source = normalized_test_text(source_group)
    if source == "dga" or name.startswith("dga:") or any(x in name for x in (
        "hydrogen (h2)", "oxygen (o2)", "nitrogen (n2)", "methane (ch4)", "ethane (c2h6)",
        "ethylene (c2h4)", "acetylene (c2h2)", "carbon monoxide", "carbon dioxide",
        "total combustible gas", "total volume of gas", "equilibrium gas pressure", "co2/co ratio",
    )):
        return "dga"
    if source.startswith("furan") or any(x in name for x in (
        "furan", "furf", "2fal", "2-fal", "indirect dp", "paper lifetime", "polymerization",
    )):
        return "furan"
    if any(x in name for x in (
        "water content", "humidity in cellulose", "relative saturation", "mineral oil log cw", "cw",
        "breakdown voltage", "rsd% of bdv", "power factor", "dissipation factor", "resistivity",
        "room test temperature", "room test humidity", "lab room temperature", "lab room humidity",
    )):
        return "water_electrical"
    if any(x in name for x in ("interfacial tension", "color", "colour", "appearance")):
        return "physical_visual"
    if any(x in name for x in (
        "total acid number", "acid number", "peroxide", "hydroperoxide", "mercaptan", "rsh", "hydrogen sulfide", "h2s",
    )):
        return "tan_family"
    if "oil quality index" in name or name in {"oqi", "oqin"}:
        return "oqi"
    if any(x in name for x in ("dbds", "dibenzyl", "toluene", "bht", "antioxidant", "pcb", "polychlorinated")):
        return "gc_additives"
    if source.startswith("corros") or any(x in name for x in (
        "corrosive sulfur", "potentially corrosive", "tarnish", "copper corrosion", "ccd", "flash point",
    )) or any(token in name for token in _METAL_TOKENS):
        return "corrosion_flash_metals"
    return "other"


def report_group_label(key: str) -> str:
    return REPORT_GROUP_LABELS.get(key, REPORT_GROUP_LABELS["other"])


def report_sort_key(test: str, source_group: str = "") -> tuple[int, int, str]:
    key = report_group_key(test, source_group)
    try:
        group_rank = REPORT_GROUP_ORDER.index(key)
    except ValueError:
        group_rank = len(REPORT_GROUP_ORDER)
    name = normalized_test_text(test)
    family = _GROUP_TEST_ORDER.get(key, ())
    item_rank = next((i for i, token in enumerate(family) if token in name), len(family))
    # Metals follow the explicit corrosion / flash rows, but stay within the same family.
    if key == "corrosion_flash_metals" and any(token in name for token in _METAL_TOKENS):
        item_rank = max(item_rank, len(family))
    return group_rank, item_rank, name


def is_raw_water_instrument_row(test: str) -> bool:
    name = normalized_test_text(test)
    return (
        "water raw" in name
        or name.startswith("water:kf_rt:")
        or name.startswith("water:kf-rt:")
        or ("water content kf @rt" in name and ("eq-" in name or " eq " in name or "equipment" in name or "instrument" in name))
    )


def report_display_result(test: str, value: Any) -> str:
    text = str(value if value not in (None, "") else "—")
    name = normalized_test_text(test)
    if "rsd% of bdv" in name or "paper lifetime remaining" in name:
        match = re.search(r"-?\d+(?:\.\d+)?", text)
        if match:
            number = float(match.group(0))
            rounded = int(math.floor(number + 0.5)) if number >= 0 else int(math.ceil(number - 0.5))
            prefix = ">" if text.strip().startswith(">") else "<" if text.strip().startswith("<") else ""
            return f"{prefix}{rounded}"
    return text
