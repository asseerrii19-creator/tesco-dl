"""Controlled batch scan evidence and atomic receiving.

Revision ID: e8b4a1c90320
Revises: c6a2f9e81740
"""
from alembic import op
import sqlalchemy as sa

revision = 'e8b4a1c90320'
down_revision = 'c6a2f9e81740'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table('receiving_batch_scans',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('nonce', sa.String(32), nullable=False),
        sa.Column('actor_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=False),
        sa.Column('site_id', sa.Integer(), sa.ForeignKey('sites.id'), nullable=False),
        sa.Column('commercial_case_id', sa.Integer(), sa.ForeignKey('commercial_cases.id'), nullable=False),
        sa.Column('form_number', sa.Integer(), nullable=False),
        sa.Column('review_json', sa.Text(), nullable=False),
        sa.Column('evidence_blob', sa.LargeBinary(), nullable=False),
        sa.Column('evidence_sha256', sa.String(64), nullable=False),
        sa.Column('original_name', sa.String(220), nullable=False),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.Column('accepted_at', sa.DateTime(), nullable=True),
        sa.Column('sample_ids_json', sa.Text(), nullable=False),
    )
    op.create_index('ix_receiving_batch_scans_nonce', 'receiving_batch_scans', ['nonce'], unique=True)


def downgrade():
    op.drop_index('ix_receiving_batch_scans_nonce', table_name='receiving_batch_scans')
    op.drop_table('receiving_batch_scans')
