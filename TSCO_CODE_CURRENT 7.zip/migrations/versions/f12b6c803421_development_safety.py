"""Add isolated employee development and safety records; no core data mutation."""
from alembic import op
import sqlalchemy as sa
revision='f12b6c803421'
down_revision='e8b4a1c90320'
branch_labels=None
depends_on=None


def upgrade():
    op.create_table('employee_development_records',
        sa.Column('id',sa.Integer(),primary_key=True),sa.Column('site_id',sa.Integer(),sa.ForeignKey('sites.id'),nullable=False),
        sa.Column('employee_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False),sa.Column('kind',sa.String(30),nullable=False),sa.Column('title',sa.String(220),nullable=False),
        sa.Column('status',sa.String(40),nullable=False),sa.Column('details_json',sa.Text(),nullable=False),sa.Column('evidence_blob',sa.LargeBinary(),nullable=True),
        sa.Column('evidence_name',sa.String(220),nullable=False),sa.Column('evidence_sha256',sa.String(64),nullable=False),sa.Column('revision',sa.Integer(),nullable=False),
        sa.Column('created_by_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False),sa.Column('approved_by_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=True),
        sa.Column('approved_at',sa.DateTime(),nullable=True),sa.Column('valid_until',sa.DateTime(),nullable=True),sa.Column('hr_sync_status',sa.String(30),nullable=False),sa.Column('hr_reference',sa.String(160),nullable=False),
        sa.Column('created_at',sa.DateTime(),nullable=False),sa.Column('updated_at',sa.DateTime(),nullable=False))
    for name in ('site_id','employee_id','kind','status'):op.create_index('ix_employee_development_records_'+name,'employee_development_records',[name])
    op.create_table('safety_asset_records',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('site_id',sa.Integer(),sa.ForeignKey('sites.id'),nullable=False),sa.Column('asset_code',sa.String(80),nullable=False),sa.Column('equipment_type',sa.String(100),nullable=False),sa.Column('location',sa.String(220),nullable=False),sa.Column('checklist_json',sa.Text(),nullable=False),sa.Column('status',sa.String(30),nullable=False),sa.Column('next_due',sa.DateTime(),nullable=False),sa.Column('created_by_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False),sa.Column('created_at',sa.DateTime(),nullable=False),sa.UniqueConstraint('site_id','asset_code',name='uq_safety_asset_site_code'))
    for name in ('site_id','next_due'):op.create_index('ix_safety_asset_records_'+name,'safety_asset_records',[name])
    op.create_table('safety_inspection_records',sa.Column('id',sa.Integer(),primary_key=True),sa.Column('asset_id',sa.Integer(),sa.ForeignKey('safety_asset_records.id'),nullable=False),sa.Column('inspector_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False),sa.Column('inspected_at',sa.DateTime(),nullable=False),sa.Column('outcome',sa.String(20),nullable=False),sa.Column('checklist_json',sa.Text(),nullable=False),sa.Column('findings',sa.Text(),nullable=False),sa.Column('corrective_action',sa.Text(),nullable=False),sa.Column('next_due',sa.DateTime(),nullable=False),sa.Column('evidence_blob',sa.LargeBinary(),nullable=False),sa.Column('evidence_name',sa.String(220),nullable=False),sa.Column('evidence_sha256',sa.String(64),nullable=False))
    op.create_index('ix_safety_inspection_records_asset_id','safety_inspection_records',['asset_id'])


def downgrade():
    # Downgrade is explicit only; never invoked automatically during deployment.
    op.drop_table('safety_inspection_records');op.drop_table('safety_asset_records');op.drop_table('employee_development_records')
