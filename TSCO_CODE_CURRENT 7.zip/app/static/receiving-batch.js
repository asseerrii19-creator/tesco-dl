(() => {
  const root=document.getElementById('receivingBatch'); if(!root)return;
  const el=id=>document.getElementById(id), status=el('batchScanStatus'), form=el('batchAcceptForm'), accept=el('batchAcceptButton');
  let ready=false, busy=false;
  const camera=el('batchCamera'), upload=el('batchUpload');
  el('batchCameraButton').addEventListener('click',()=>camera.click());
  el('batchUploadButton').addEventListener('click',()=>upload.click());
  const text=(tag,value)=>{const node=document.createElement(tag);node.textContent=String(value||'—');return node;};
  function lock(){accept.disabled=busy||!ready||!form.elements.physical_confirmed.checked||(!el('batchNewAsset').hidden&&!el('batchAssetReviewed').checked);}
  form.addEventListener('change',lock);
  function reset(){ready=false;form.reset();el('batchReviewToken').value='';el('batchMatch').hidden=true;lock();}
  async function send(url,data){const response=await fetch(url,{method:'POST',body:data,headers:{Accept:'application/json'}});
    const type=response.headers.get('content-type')||'';
    if(!type.includes('application/json'))throw new Error('Session expired or upload failed. Sign in and scan again.');
    const value=await response.json();if(!response.ok)throw new Error(value.error||value.detail||'Receiving request failed');return value;}
  async function scan(event){const file=event.target.files[0];event.target.value='';if(!file||busy)return;
    reset();busy=true;status.textContent='Reading all QR codes from the Data Form…';
    el('batchCameraButton').disabled=true;el('batchUploadButton').disabled=true;
    try{const data=new FormData();data.append('upload',file);const match=await send('/intake/batch-scan',data);
      el('batchFacts').replaceChildren();for(const [label,value] of [['Business Case',match.business_case],['Sales Order',match.sales_order],['Transformer Serial',match.transformer_serial],['Data Form',match.form_number],['Expected quantity',match.expected],['Detected / matched',match.matched]]){el('batchFacts').append(text('dt',label),text('dd',value));}
      el('batchSampleRows').replaceChildren();for(const sample of match.samples){const row=document.createElement('li');row.append(text('strong',sample.sample_id),text('span',sample.sampling_identity),text('span',sample.status));if(!sample.matched)row.className='batch-missing';el('batchSampleRows').append(row);}
      el('batchMatchCount').textContent=`Matched ${match.matched}/${match.expected}`;
      const missing=match.samples.filter(s=>!s.matched).map(s=>`${s.sample_id} · ${s.sampling_identity}`);
      const issues=[...match.issues,...(missing.length?[`Missing QR: ${missing.join(', ')}. Retake the whole sheet.`]:[])];
      el('batchIssues').textContent=issues.join(' · ');el('batchIssues').hidden=!issues.length;
      el('batchNewAsset').hidden=!match.new_serials.length;
      const asset=match.asset_review||{};
      el('batchAssetDetails').textContent=[match.new_serials.join(', '),asset.tag_number,asset.manufacturer_name,asset.rated_power_mva,asset.voltage_rating_hv_lv,asset.substation].filter(Boolean).join(' · ');
      el('batchReviewToken').value=match.review_token;accept.textContent=`Accept All ${match.expected} Samples`;
      ready=match.can_accept;el('batchMatch').hidden=false;
      status.textContent=ready?'Batch matched. Verify the physical samples, then accept once.':'Review required. No samples have been received.';
    }catch(error){status.textContent=error.message;reset();}
    finally{busy=false;el('batchCameraButton').disabled=false;el('batchUploadButton').disabled=false;lock();}
  }
  camera.addEventListener('change',scan);upload.addEventListener('change',scan);
  form.addEventListener('submit',async event=>{event.preventDefault();if(accept.disabled||busy)return;busy=true;lock();status.textContent='Accepting the matched batch…';
    try{const result=await send('/intake/batch-scan/accept',new FormData(form));status.textContent=`Received / Registered ${result.received}/${result.received}`;window.location.assign(result.next_url);}
    catch(error){status.textContent=error.message;busy=false;lock();}
  });
})();
