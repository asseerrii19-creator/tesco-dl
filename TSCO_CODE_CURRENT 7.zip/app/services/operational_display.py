"""Presentation helpers. Never mutate canonical dates, identities or persisted evidence."""
import re
from datetime import datetime,timezone,timedelta
RIYADH=timezone(timedelta(hours=3))
DIGITS=str.maketrans('٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹','01234567890123456789')


def operational_date(value,time=False):
    if not value:return '—'
    if isinstance(value,datetime):
        date=value if value.tzinfo else value.replace(tzinfo=timezone.utc)
        return date.astimezone(RIYADH).strftime('%d/%m/%Y %H:%M' if time else '%d/%m/%Y')
    return display_text(value)


def display_text(value):
    text=str(value).translate(DIGITS)
    def iso(m):
        try:
            date=datetime.fromisoformat(m.group(0).replace('Z','+00:00'))
            if date.tzinfo:date=date.astimezone(RIYADH)
            return date.strftime('%d/%m/%Y %H:%M' if m.group(4) else '%d/%m/%Y')
        except ValueError:return m.group(0)
    text=re.sub(r'\b(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:\d{2})?)?\b',iso,text)
    def named(m):
        try:return datetime.strptime(m.group(0),'%d-%b-%Y'+(' %H:%M' if m.group(1) else '')).strftime('%d/%m/%Y'+(' %H:%M' if m.group(1) else ''))
        except ValueError:return m.group(0)
    return re.sub(r'\b\d{1,2}-[A-Za-z]{3}-\d{4}( \d{2}:\d{2})?\b',named,text)
