from __future__ import annotations

import os
import re
from urllib.parse import urlsplit

from ..models import PlannedSample

_TOKEN = re.compile(r"[A-Za-z0-9_-]{1,128}\Z")


def qr_return_path(token: str) -> str | None:
    return f"/intake/p/{token}" if _TOKEN.fullmatch(token) else None


def validated_qr_return(value: object) -> str | None:
    if not isinstance(value, str) or not value.startswith("/intake/p/"):
        return None
    return qr_return_path(value[len("/intake/p/"):])


def planned_sample_url(plan: PlannedSample) -> str:
    path = qr_return_path(plan.public_token)
    if not path:
        raise ValueError("Planned sample has no valid permanent QR token")
    # Render supplies this automatically. Other hosts configure PUBLIC_BASE_URL.
    base = (os.getenv("PUBLIC_BASE_URL") or os.getenv("RENDER_EXTERNAL_URL") or "http://localhost:8000").strip().rstrip("/")
    parsed = urlsplit(base)
    if parsed.scheme not in {"https", "http"} or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path:
        raise ValueError("PUBLIC_BASE_URL must be an absolute origin URL")
    if parsed.scheme != "https" and parsed.hostname not in {"localhost", "127.0.0.1", "testserver"}:
        raise ValueError("Planned sample QR requires HTTPS outside local development")
    return base + path
