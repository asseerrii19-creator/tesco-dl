"""Controlled lot lifecycle in the canonical OperationsState QC collection."""
from __future__ import annotations
import base64, hashlib, hmac, json, math, os
from datetime import datetime, timezone
from uuid import uuid4


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def evidence(value):
    name, data = str(value.get('name') or '').strip(), str(value.get('data') or '')
    if not name or not data.startswith('data:') or ';base64,' not in data:
        raise ValueError('Original certificate / preparation / run evidence is required')
    try: raw = base64.b64decode(data.split(',', 1)[1], validate=True)
    except Exception as exc: raise ValueError('Invalid source evidence') from exc
    if not raw or len(raw) > 900000: raise ValueError('Evidence must contain 1–900000 bytes')
    return {'name': name[:200], 'data': data, 'sha256': hashlib.sha256(raw).hexdigest()}


def active_lot(payload, context, equipment_id, at=None):
    at = at or datetime.now(timezone.utc)
    if at.tzinfo is None: at = at.replace(tzinfo=timezone.utc)
    matches = []
    for lot in payload.get('qualifiedQcProfiles', []):
        if lot.get('lifecycle') != 'CONTROLLED_LOT' or lot.get('status') != 'ACTIVE' or not lot.get('signature'): continue
        if (lot.get('context_test'),lot.get('method_name'),lot.get('test')) != (context.get('test'),context.get('method'),context.get('group')): continue
        if str(equipment_id) not in [str(x) for x in lot.get('equipment_ids', [])]: continue
        try:
            start, end = [datetime.fromisoformat(lot[k].replace('Z', '+00:00')) for k in ('valid_from','valid_until')]
        except (KeyError,ValueError): continue
        if start <= at <= end: matches.append(lot)
    return max(matches,key=lambda x:x.get('approved_at','')) if matches else None


def register_lot(payload, body, user, db, site_id):
    from .lab_operations import _result_qc_context, _validated_qc_equipment, _assignment_allows_user_row, _current_test_assignment, _qc_source_package_test, _batch_test_rows
    if user.role not in {'lab_technician','senior_chemist','technical_manager'}: raise PermissionError('Only laboratory or technical staff may register QC lots')
    batch = next((x for x in payload.get('batches',[]) if str(x.get('id')) == str(body.get('batch_id'))),None)
    test = str(body.get('context_test') or '')
    if not batch or not any(x.get('test') == test and _qc_source_package_test(x) for x in _batch_test_rows(batch)): raise ValueError('Select an exact measured test from an existing batch')
    context = _result_qc_context(batch,{'test':test})
    if user.role == 'lab_technician' and not _assignment_allows_user_row(_current_test_assignment(payload,str(batch['id']),context['workstation']) or {},user): raise PermissionError('Current assignment does not authorize lot preparation')
    ids = body.get('equipment_ids')
    if not isinstance(ids,list) or not ids or len(ids) != len(set(map(str,ids))): raise ValueError('Select exact Equipment Master IDs')
    ids = [int(x) for x in ids]
    for eid in ids: _validated_qc_equipment(db,site_id,equipment_asset_id=eid,workstation=context['workstation'],method_name=context['method'])
    source = body.get('source_type')
    if source not in {'INTERNAL','EXTERNAL_CRM'}: raise ValueError('Select Internal or External CRM')
    name, number = str(body.get('material') or '').strip(),str(body.get('lot_number') or '').strip()
    if not name or not number: raise ValueError('Material and Lot Number are required')
    if any(x.get('lifecycle') == 'CONTROLLED_LOT' and x.get('material') == name and x.get('lot_number') == number and x.get('context_test') == test and x.get('method_name') == context['method'] for x in payload.get('qualifiedQcProfiles',[])): raise ValueError('This Material / Lot / Test / Method is already registered')
    start,end = [datetime.fromisoformat(str(body.get(k) or '').replace('Z','+00:00')) for k in ('valid_from','valid_until')]
    if start.tzinfo is None or end.tzinfo is None or end <= start or end <= datetime.now(timezone.utc): raise ValueError('Future expiry and timezone-qualified validity dates required')
    target,low,high = [float(body[k]) for k in ('target','lower_limit','upper_limit')]
    if not all(math.isfinite(x) for x in (target,low,high)) or not low < high or not low <= target <= high: raise ValueError('Finite target within independently established limits required')
    document = evidence(body.get('evidence') or {})
    qualification = str(body.get('qualification') or '').strip()
    if not qualification: raise ValueError('Qualification / establishment rationale required')
    supplier,certificate,uncertainty = [str(body.get(k) or '').strip() for k in ('supplier','certificate','uncertainty')]
    if source == 'EXTERNAL_CRM' and not all((supplier,certificate,uncertainty)): raise ValueError('CRM supplier, certificate and certified uncertainty required')
    lot = {'id':'QCL-'+uuid4().hex,'lifecycle':'CONTROLLED_LOT','status':'PENDING_SENIOR','active':False,'test':context['group'],'context_test':test,'method_name':context['method'],'workstation':context['workstation'],'equipment_ids':ids,'material':name,'lot_number':number,'label':name+' / '+number,'source_type':source,'supplier':supplier,'certificate':certificate,'uncertainty':uncertainty,'valid_from':start.isoformat(),'valid_until':end.isoformat(),'mean':target,'lcl2':low,'ucl2':high,'lcl3':low,'ucl3':high,'qualification':qualification,'evidence':document,'prepared_by':user.full_name,'prepared_by_user_id':user.id,'prepared_at':now_iso(),'history':[]}
    if context['group'] == 'DGA':
        targets = body.get('component_targets'); required = {'H2','O2','N2','CH4','CO','CO2','C2H4','C2H6','C2H2'}
        if not isinstance(targets,dict) or set(targets) != required: raise ValueError('DGA requires nine certified component targets')
        lot['component_targets'] = {k:float(v) for k,v in targets.items()};lot['tolerance_pct'] = float(body.get('tolerance_pct') or 5)
        if not all(math.isfinite(v) and v > 0 for v in lot['component_targets'].values()) or not 0 < lot['tolerance_pct'] <= 100: raise ValueError('Invalid component targets / tolerance')
    lot['history'].append({'action':'REGISTERED','actor_id':user.id,'actor':user.full_name,'at':lot['prepared_at']})
    payload.setdefault('qualifiedQcProfiles',[]).append(lot)
    return lot


def decide_lot(payload,lot_id,body,user,db,site_id):
    from .lab_operations import _validated_qc_equipment
    if user.role != 'senior_chemist' or str(getattr(user,'senior_responsibility_domain','TECHNICAL') or '').upper() != 'TECHNICAL': raise PermissionError('Senior Chemist — Technical approval/signature required')
    lot = next((x for x in payload.get('qualifiedQcProfiles',[]) if x.get('id') == lot_id and x.get('lifecycle') == 'CONTROLLED_LOT'),None)
    if not lot: raise ValueError('QC Lot not found')
    action = body.get('action')
    if action not in {'ACTIVATE','REJECT','CLOSE'} or not str(body.get('reason') or '').strip(): raise ValueError('Decision and review rationale required')
    if action in {'ACTIVATE','REJECT'} and lot['status'] != 'PENDING_SENIOR': raise ValueError('Lot is no longer pending review')
    if action == 'CLOSE' and lot['status'] != 'ACTIVE': raise ValueError('Only an active lot can be closed')
    if action == 'ACTIVATE':
        if body.get('signed') is not True: raise ValueError('Explicit authenticated electronic signature confirmation required')
        if lot['prepared_by_user_id'] == user.id: raise PermissionError('An independent Senior Chemist must review their own prepared lot')
        if datetime.fromisoformat(lot['valid_until']) <= datetime.now(timezone.utc): raise ValueError('Expired lot cannot be activated')
        for eid in lot['equipment_ids']: _validated_qc_equipment(db,site_id,equipment_asset_id=eid,workstation=lot['workstation'],method_name=lot['method_name'])
        for old in payload.get('qualifiedQcProfiles',[]):
            if old.get('status') == 'ACTIVE' and old.get('context_test') == lot['context_test'] and old.get('method_name') == lot['method_name'] and set(old.get('equipment_ids',[])) & set(lot['equipment_ids']):
                old['status'],old['active'] = 'SUPERSEDED',False
                old.setdefault('history',[]).append({'action':'SUPERSEDED','actor_id':user.id,'at':now_iso(),'replacement':lot_id})
        lot['status'],lot['active'] = 'ACTIVE',True
        lot['approved_by'],lot['approved_by_user_id'],lot['approved_at'] = user.full_name,user.id,now_iso()
        signed = json.dumps({k:v for k,v in lot.items() if k != 'history'},sort_keys=True).encode()
        lot['signature'] = hmac.new(os.environ['APP_SECRET'].encode(),signed,hashlib.sha256).hexdigest()
    else: lot['status'],lot['active'] = ('REJECTED' if action == 'REJECT' else 'CLOSED'),False
    lot.setdefault('history',[]).append({'action':action,'actor_id':user.id,'actor':user.full_name,'at':now_iso(),'reason':str(body['reason'])})
    return lot


def parse_run_value(row):
    """Derive supported CSV values from retained bytes; never trust a browser average."""
    import csv, io, re
    raw = base64.b64decode(row['source_data'].split(',',1)[1],validate=True)
    is_bdv = row.get('test') == 'BDV'
    is_pf = bool(re.search(r'power factor|dissipation factor',str(row.get('context_test')),re.I))
    if not str(row.get('source_file','')).lower().endswith(('.csv','.txt')):
        if is_bdv or is_pf: raise ValueError('BDV / PF QC requires a parseable original CSV run set')
        if not str(row.get('fallback_reason') or '').strip(): raise ValueError('Documented measured-value fallback reason required for this file format')
        return None
    text = raw.decode('utf-8-sig')
    try: dialect = csv.Sniffer().sniff(text[:4096],delimiters=',;\t')
    except csv.Error: dialect = csv.excel
    rows = list(csv.reader(io.StringIO(text),dialect))
    norm = lambda x:re.sub(r'[^a-z0-9]','',str(x).lower())
    def number(x):
        try:
            n=float(str(x).strip().replace(',','.'));return n if math.isfinite(n) else None
        except ValueError:return None
    values={};records=[]
    for index,header in enumerate(rows):
        run_columns=[j for j,x in enumerate(header) if re.fullmatch(r'(?:r|run|result|breakdown)[1-6]',norm(x))]
        if not run_columns:continue
        candidates=[r for r in rows[index+1:] if len(r)>=len(header) and all(number(r[j]) is not None for j in run_columns)]
        if len(candidates)>1:
            id_column=next((j for j,x in enumerate(header) if norm(x) in {'id','resultid','testid','recordid'}),None)
            selected=[r for r in candidates if id_column is not None and str(r[id_column]).strip()==str(row.get('source_record_id') or '').strip()]
            if len(selected)!=1:raise ValueError('Multiple instrument records detected; select the exact source record ID')
            rows=[header,selected[0]]
        break
    for i,r in enumerate(rows):
        for j,cell in enumerate(r):
            k=norm(cell)
            match=re.fullmatch(r'(?:r|run|result|breakdown)([1-6])',k)
            value=number(r[j+1]) if j+1 < len(r) else None
            if value is None and i+1 < len(rows) and j < len(rows[i+1]): value=number(rows[i+1][j])
            if match and value is not None:
                if int(match[1]) in values:raise ValueError('Multiple instrument records detected; provide the exact single QC run record')
                values[int(match[1])]=value
            if is_pf and ('powerfactor' in k or k.startswith('pf') or k.startswith('tandelta')):
                temp='100' if '100' in str(row.get('context_test')) else '25'
                if temp in k and value is not None: return value
            if not is_bdv and not is_pf and k in {'result','qcresult','watercontent','actualresult','value'} and value is not None: records.append(value)
    if is_bdv:
        count=6 if 'IEC 60156' in str(row.get('method_name')).upper() else 5
        if set(values) != set(range(1,count+1)): raise ValueError(f'QC requires the complete {count}-run method-specific BDV set')
        runs=[values[k] for k in range(1,count+1)]
        if any(v<=0 for v in runs): raise ValueError('BDV run values must be positive')
        mean=sum(runs)/count;sd=math.sqrt(sum((x-mean)**2 for x in runs)/(count-1))
        row['derived_run_set']={'runs':runs,'average':mean,'rsd_pct':sd/mean*100}
        return mean
    if is_pf: raise ValueError('Original PF CSV must contain the exact 25 C / 100 C value')
    if len(records)==1:return records[0]
    if not str(row.get('fallback_reason') or '').strip(): raise ValueError('CSV format not recognized; document the measured-value fallback reason')
    return None
