from __future__ import annotations
from contextlib import closing
from threading import Lock

import hashlib
import io
import json
import secrets
from datetime import datetime, timedelta
from urllib.parse import urlsplit

from PIL import Image, ImageOps, UnidentifiedImageError
from sqlalchemy import select, func
from sqlalchemy.orm import Session

from ..models import Asset, AssetHistoryEvent, CommercialCase, PlannedSample, ReceivingBatchScan, SampleRequest, SampleStatus
from .planned_sample_qr import planned_sample_url, validated_qr_return
from .sampling_data_form import current_data_form, sample_rows_by_index, data_form_forms
from .commercial import require_complete_handover, link_sample, sync_case_from_sample
from .planned_samples import claim_planned_identity
from .month_close import assert_site_period_open, assert_sample_period_open
from .workflow import add_event, register_in_tsco
from .audit import add_audit

MAX_SCAN_BYTES = 8_000_000
_PDF_LOCK = Lock()
_READY = {SampleStatus.SUBMITTED.value, SampleStatus.RETURNED.value, SampleStatus.ACCEPTED.value, SampleStatus.AWAITING_RECEIPT.value, SampleStatus.IN_TRANSIT.value}


def decode_document(raw: bytes) -> list[str]:
    """Read every QR from a bounded photo/PDF; never request QR URLs over the network."""
    import zxingcpp
    import pypdfium2 as pdfium
    if not raw or len(raw) > MAX_SCAN_BYTES:
        raise ValueError('Upload a Data Form photo/PDF smaller than 8 MB')
    found = set()
    def decode(image):
        if image.width * image.height > 30_000_000:
            raise ValueError('Photo/page is too large; use a clear A4 photo')
        image = ImageOps.exif_transpose(image).convert('RGB')
        for item in zxingcpp.read_barcodes(image, formats=zxingcpp.BarcodeFormat.QRCode):
            if item.valid:
                found.add(item.text)
    try:
        if raw.startswith(b'%PDF-'):
            with _PDF_LOCK, closing(pdfium.PdfDocument(raw)) as pdf:
                if len(pdf) > 6:
                    raise ValueError('Scan one Data Form, or a PDF of at most 6 pages')
                for i in range(len(pdf)):
                    with closing(pdf[i]) as page:
                        w, h = page.get_size()
                        if w*h*9 > 30_000_000:
                            raise ValueError('PDF page is too large')
                        with closing(page.render(scale=3)) as bitmap:
                            decode(bitmap.to_pil())
        else:
            with Image.open(io.BytesIO(raw)) as im:
                if im.format not in {'JPEG','PNG','WEBP'}:
                    raise ValueError('Use a JPEG, PNG, WebP photo or PDF')
                decode(im)
    except (UnidentifiedImageError, OSError, pdfium.PdfiumError) as exc:
        raise ValueError('The photo/PDF could not be read; retake or upload a clear Data Form') from exc
    if not found:
        raise ValueError('No QR codes detected. Photograph the whole Data Form clearly, then try again')
    if len(found) > 100:
        raise ValueError('Too many QR codes in this upload')
    return sorted(found)


def match_document(db: Session, values: list[str], site_id: int) -> dict:
    tokens=[]
    for value in values:
        url=urlsplit(value)
        if url.query or url.fragment or url.username or url.password or not validated_qr_return(url.path):
            raise ValueError('Unknown/mismatched QR detected. Use the controlled Sampling Data Form')
        tokens.append(url.path.rsplit('/',1)[-1])
    plans=list(db.scalars(select(PlannedSample).where(PlannedSample.public_token.in_(tokens))).all())
    if len(plans) != len(set(tokens)) or any(p.site_id != site_id for p in plans):
        raise ValueError('A QR does not match an authorized planned sample at this site')
    for value in values:
        p=next(p for p in plans if p.public_token==urlsplit(value).path.rsplit('/',1)[-1])
        if value != planned_sample_url(p):
            raise ValueError('QR origin does not match this platform')
    cases={p.commercial_case_id for p in plans}
    if len(cases)!=1:
        raise ValueError('Mixed Business Cases detected. Scan one Data Form at a time')
    case=db.get(CommercialCase,next(iter(cases)))
    if case.status != 'ACTIVE' or not case.quotation_id or not case.purchase_order_id or case.quotation.status != 'CLIENT_ACCEPTED':
        raise ValueError('An active approved quotation and Purchase Order are required')
    require_complete_handover(case)
    form=current_data_form(db,case.id)
    rows=sample_rows_by_index(form)
    form_numbers={rows.get(p.form_sample_index,{}).get('form_number') for p in plans}
    if len(form_numbers)!=1 or None in form_numbers:
        raise ValueError('Mixed or obsolete Data Forms detected. Scan one current confirmed Data Form')
    number=int(next(iter(form_numbers)))
    sheet=next(f for f in data_form_forms(form) if int(f['form_number'])==number)
    if sheet.get('status') != 'CONFIRMED' and form.status != 'LOCKED':
        raise ValueError('Data Form must be confirmed before receipt')
    expected_indices={i for i,r in rows.items() if int(r['form_number'])==number}
    expected=list(db.scalars(select(PlannedSample).where(PlannedSample.commercial_case_id==case.id,PlannedSample.form_sample_index.in_(expected_indices)).order_by(PlannedSample.form_sample_index)).all())
    if len(expected)!=len(expected_indices):
        raise ValueError('Planned sample allocation is incomplete; Coordinator review required')
    detected={p.id for p in plans}; result=[]; issues=[]; assets={}; new=[]
    for p in expected:
        sample=db.get(SampleRequest,p.sample_request_id) if p.sample_request_id else None
        matched=p.id in detected
        status='Matched' if matched else 'Missing QR'
        if p.status in {'VOID','CANCELLED'}:
            status='Closed / Review required';issues.append(p.request_number+' is closed')
        elif sample:
            if (sample.request_number,sample.barcode_value,sample.public_token,sample.commercial_case_id,sample.commercial_request_line_id,sample.site_id,sample.client_id,sample.sampling_point,str(sample.asset.serial_number or '').upper())!=(p.request_number,p.barcode_value,p.public_token,case.id,p.commercial_request_line_id,p.site_id,p.client_id,p.sampling_point,p.expected_serial_number.upper()):
                status='Identity conflict';issues.append(p.request_number+' identity conflict')
            elif sample.status not in _READY:
                status='Already received' if sample.received_at else 'Not ready for receiving'
                issues.append(p.request_number+' '+status)
        elif p.status not in {'EXPECTED','ASSIGNED','IN_TRANSIT'}:
            status='Not ready for receiving';issues.append(p.request_number+' '+status)
        serial=p.expected_serial_number.strip()
        if p.sampling_point != rows[p.form_sample_index].get('sampling_point_label'):
            issues.append(p.request_number+' sampling identity does not match the confirmed form')
        if not serial or serial.upper()!=str(rows[p.form_sample_index].get('serial_number','')).upper():
            issues.append(p.request_number+' serial does not match the confirmed form')
        if serial not in assets:
            matches=list(db.scalars(select(Asset).where(Asset.client_id==case.client_id,Asset.active.is_(True),func.upper(Asset.serial_number)==serial.upper())).all())
            if len(matches)>1:
                issues.append(serial+' has duplicate Asset Master records')
            assets[serial]=matches[0] if len(matches)==1 else None
            if not matches:new.append(serial)
        result.append({'planned_id':p.id,'sample_id':p.request_number,'sampling_identity':p.sampling_point,'status':status,'matched':matched})
    fingerprint={'case_id':case.id,'quotation_id':case.quotation_id,'purchase_order_id':case.purchase_order_id,
                 'form_revision':form.revision,'sheet':sheet,'identities':[(p.id,p.request_number,p.public_token,p.barcode_value,p.expected_serial_number,p.sampling_point) for p in expected]}
    return {'case':case,'form':form,'sheet':sheet,'plans':expected,'assets':assets,'rows':rows,'values':values,
            'fingerprint':hashlib.sha256(json.dumps(fingerprint,sort_keys=True,default=str).encode()).hexdigest(),
            'summary':{'business_case':case.case_code,'sales_order':case.sales_order_number,'transformer_serial':sheet.get('asset',{}).get('serial_number'),
                       'form_number':number,'expected':len(expected),'matched':len(detected),'samples':result,'issues':issues,'new_serials':new,
                       'asset_review':sheet.get('asset',{}),'can_accept':len(detected)==len(expected) and not issues}}


def create_review(db: Session, *, raw: bytes, filename: str, user, site_id: int, request) -> dict:
    match=match_document(db,decode_document(raw),site_id)
    review=ReceivingBatchScan(nonce=secrets.token_hex(16),actor_id=user.id,site_id=site_id,commercial_case_id=match['case'].id,
        form_number=match['summary']['form_number'],review_json=json.dumps({'values':match['values'],'fingerprint':match['fingerprint']}),
        evidence_blob=raw,evidence_sha256=hashlib.sha256(raw).hexdigest(),original_name=filename[:220])
    db.add(review);db.flush()
    add_audit(db,actor=user,request=request,action='RECEIVING_BATCH_SCAN_REVIEWED',entity_type='ReceivingBatchScan',entity_id=review.id,
        summary=f"{match['case'].case_code}: matched {match['summary']['matched']}/{match['summary']['expected']}",details={'sha256':review.evidence_sha256})
    db.commit()
    return {**match['summary'],'review_token':review.nonce}


def accept_review(db: Session, *, nonce: str, user, site_id: int, request, physical_confirmed: bool, new_asset_reviewed: bool, seal: str, note: str) -> dict:
    from ..routes.intake import _create_intake_asset, _remember_sampling_point
    review=db.scalar(select(ReceivingBatchScan).where(ReceivingBatchScan.nonce==nonce).with_for_update())
    if not review or review.actor_id!=user.id or review.site_id!=site_id:
        raise ValueError('Receiving review not found in this account/site')
    if review.accepted_at:
        return {'received':len(json.loads(review.sample_ids_json)),'already_accepted':True,'next_url':'/intake?view=distribution&batch_received='+str(len(json.loads(review.sample_ids_json)))}
    if review.created_at < datetime.utcnow()-timedelta(minutes=30):
        raise ValueError('Receiving review expired. Rescan the Data Form')
    if not physical_confirmed:
        raise ValueError('Confirm the carton/sample identities and physical quantity before accepting')
    clean_seal=seal.strip().upper()
    if clean_seal not in {'INTACT','BROKEN','MISSING','NOT APPLICABLE'}:
        raise ValueError('Unsupported physical condition')
    if clean_seal not in {'INTACT','NOT APPLICABLE'} and not note.strip():
        raise ValueError('Record the physical-condition exception before accepting')
    case=db.scalar(select(CommercialCase).where(CommercialCase.id==review.commercial_case_id).with_for_update())
    stored=json.loads(review.review_json)
    # Serialize competing scans of the same case before taking identity locks in a fixed order.
    locked_plans=list(db.scalars(select(PlannedSample).where(PlannedSample.commercial_case_id==case.id).order_by(PlannedSample.id).with_for_update()).all())
    linked_ids=[p.sample_request_id for p in locked_plans if p.sample_request_id]
    if linked_ids:
        list(db.scalars(select(SampleRequest).where(SampleRequest.id.in_(linked_ids)).order_by(SampleRequest.id).with_for_update().execution_options(populate_existing=True)).all())
    match=match_document(db,stored['values'],site_id)
    if match['fingerprint'] != stored['fingerprint']:
        raise ValueError('Approved request/Data Form changed. Rescan and review the current form')
    if not match['summary']['can_accept']:
        raise ValueError('Batch is incomplete or no longer ready. Rescan and resolve missing/conflicting samples')
    if match['summary']['new_serials'] and not new_asset_reviewed:
        raise ValueError('New Serial Number — Review Required. Confirm the asset information once')
    assert_site_period_open(db,site_id)
    sheet=match['sheet'];metadata=sheet.get('asset',{});samplings=sheet.get('sampling',{})
    for serial,asset in match['assets'].items():
        if not asset:
            master_meta={'manufacturer':metadata.get('manufacturer_name'),'tag_number':metadata.get('tag_number'),'oil_type':metadata.get('oil_type'),
                         'cooling_type':metadata.get('cooling_type'),'station_name':metadata.get('substation') or metadata.get('location')}
            year=str(metadata.get('manufacture_year') or '')
            if year.isdigit():master_meta['manufacture_year']=int(year)
            for source,target in (('rated_power_mva','rated_mva'),):
                try:master_meta[target]=float(metadata[source])
                except (KeyError,ValueError,TypeError):pass
            match['assets'][serial]=_create_intake_asset(db,client=case.client,serial=serial,case=case,metadata=master_meta,user=user,request=request)
            db.add(AssetHistoryEvent(asset_id=match['assets'][serial].id,event_type='APPROVED_DATA_FORM_METADATA',event_at=datetime.utcnow(),created_by_id=user.id,
                details=json.dumps({'batch_scan_id':review.id,'business_case':case.case_code,'asset':metadata},ensure_ascii=False)))
    now=datetime.utcnow();sample_ids=[]
    for plan in match['plans']:
        sample=db.scalar(select(SampleRequest).where(SampleRequest.id==plan.sample_request_id).with_for_update()) if plan.sample_request_id else None
        if not sample:
            sample=SampleRequest(request_number=plan.request_number,public_token=plan.public_token,barcode_value=plan.barcode_value,
                status=SampleStatus.SUBMITTED.value,site_id=site_id,client_id=case.client_id,quotation_id=case.quotation_id,purchase_order_id=case.purchase_order_id,
                commercial_case_id=case.id,commercial_request_line_id=plan.commercial_request_line_id,asset_id=match['assets'][plan.expected_serial_number].id,
                submission_channel='CLIENT_DELIVERED',sample_origin='Client-Originated / Direct Delivery',sample_date_time=now,
                sampling_point=plan.sampling_point,requested_package=plan.requested_package,requested_method_family=plan.requested_method_family,
                requested_tests_json=plan.requested_tests_json,priority=plan.priority,required_tat=plan.required_tat,due_at=plan.due_at,
                submitted_at=now,container_count=1,sampling_reason=str(samplings.get('reason_of_sampling') or '')[:180],
                field_notes=f"Batch Data Form receipt {review.id}; client sampler: {samplings.get('sample_man_name') or ''}")
            # Preserve sampling metadata; physical receiving time is a separate system timestamp.
            raw_dt=str(samplings.get('sampling_date_time') or '')
            for fmt in ('%d-%b-%Y %H:%M','%Y-%m-%dT%H:%M','%Y-%m-%d %H:%M'):
                try:sample.sample_date_time=datetime.strptime(raw_dt,fmt);break
                except ValueError:pass
            for source,target in (('unit_oil_temperature_c','oil_temperature_c'),('ambient_temperature_c','ambient_temperature_c'),('ambient_humidity_pct','ambient_humidity_pct')):
                try:setattr(sample,target,float(samplings[source]))
                except (KeyError,ValueError,TypeError):pass
            db.add(sample);db.flush();claim_planned_identity(plan,sample);link_sample(db,case,sample,user)
            _remember_sampling_point(sample.asset,plan.sampling_point)
            add_event(db,sample,user,'EXPECTED_SAMPLE_MATCHED',sample.status,f'Data Form QR batch {review.id}')
        assert_sample_period_open(db,sample)
        if sample.status in {SampleStatus.SUBMITTED.value,SampleStatus.RETURNED.value,SampleStatus.IN_TRANSIT.value}:
            sample.status=SampleStatus.ACCEPTED.value;sample.accepted_at=now;sample.data_entry_note=f'QR batch {review.id}: matched physical sample'
            add_event(db,sample,user,'DATA_ACCEPTANCE',sample.status,sample.data_entry_note)
        if sample.status==SampleStatus.ACCEPTED.value:register_in_tsco(db,sample,user)
        sample.status=SampleStatus.RECEIVED.value;sample.received_at=now
        add_event(db,sample,user,'PHYSICAL_RECEIPT',sample.status,f'Batch {review.id}; Seal: {clean_seal}. {note.strip()[:1000]}')
        sync_case_from_sample(db,sample,user,note=f'QR batch receipt: {review.id}')
        add_audit(db,actor=user,request=request,action='EXPECTED_QR_BATCH_RECEIVED',entity_type='SampleRequest',entity_id=sample.id,
            summary=f'Received {sample.request_number}',details={'batch_scan_id':review.id,'planned_sample_id':plan.id,'sha256':review.evidence_sha256,'seal_status':clean_seal})
        sample_ids.append(sample.id)
    review.accepted_at=now;review.sample_ids_json=json.dumps(sample_ids)
    add_audit(db,actor=user,request=request,action='RECEIVING_BATCH_ACCEPTED',entity_type='ReceivingBatchScan',entity_id=review.id,
        summary=f'{case.case_code}: {len(sample_ids)}/{len(sample_ids)} physically received',details={'sample_ids':sample_ids,'new_asset_reviewed':new_asset_reviewed})
    db.commit()
    return {'received':len(sample_ids),'already_accepted':False,'next_url':f'/intake?view=distribution&batch_received={len(sample_ids)}'}
