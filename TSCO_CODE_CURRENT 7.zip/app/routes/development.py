from __future__ import annotations
import hashlib,json
from datetime import datetime,timedelta,timezone
from fastapi import APIRouter,Depends,Request,Form,UploadFile,File,HTTPException
from fastapi.responses import RedirectResponse,Response
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..database import get_db
from ..dependencies import templates
from ..models import Role,User,EmployeeDevelopmentRecord,ControlledDocument,EquipmentAsset,SampleRequest,AuditLog
from ..security import require_user
from ..services.audit import add_audit
router=APIRouter(prefix='/development',tags=['employee development'])
INTERNAL={r.value for r in Role}-{Role.CLIENT.value,Role.CLIENT_OPERATIONS.value,Role.CLIENT_SAMPLER.value}
COORDINATORS={'training_coordinator','corporate_support'}
TECHNICAL={'senior_chemist','technical_manager'}
MANAGERS=COORDINATORS|TECHNICAL
def technical_authority(user):
    return user.role=='technical_manager' or user.role=='senior_chemist' and str(getattr(user,'senior_responsibility_domain','TECHNICAL') or '').upper()=='TECHNICAL'


KINDS={'PROFILE','CV','CERTIFICATE','TRAINING','ONBOARDING','COMPETENCY','TRAINEE'}


def scoped_user(db,actor,employee_id):
    target=db.get(User,employee_id)
    if not actor.site_id or not target or target.site_id!=actor.site_id or not target.active or target.role not in INTERNAL: raise HTTPException(404,'Employee not found')
    if target.id!=actor.id and actor.role not in MANAGERS: raise HTTPException(403,'Employee development is private')
    return target


def scoped_record(db,actor,rid,lock=False):
    stmt=select(EmployeeDevelopmentRecord).where(EmployeeDevelopmentRecord.id==rid)
    if lock:stmt=stmt.with_for_update()
    row=db.scalar(stmt)
    if not row:raise HTTPException(404,'Record not found')
    scoped_user(db,actor,row.employee_id)
    return row


def approved_document(db,actor,doc_id):
    doc=db.get(ControlledDocument,int(doc_id or 0))
    if not doc or doc.site_id not in {None,actor.site_id} or not (doc.status=='APPROVED' or doc.status=='ACTIVE' and doc.manager_approved_by_id):raise ValueError('An approved controlled Method / SOP is required')
    return doc


def transition(row,body,user,db):
    data=json.loads(row.details_json or '{}');action=body.get('action');reason=str(body.get('reason') or '').strip();own=row.employee_id==user.id
    if not reason:raise ValueError('Action notes / rationale required')
    old=row.status
    if row.kind=='COMPETENCY':
        next_states={'READ_METHOD':('ASSIGNED','READING_COMPLETE'),'OBSERVE':('READING_COMPLETE','OBSERVATION_COMPLETE'),'START_PRACTICE':('OBSERVATION_COMPLETE','SUPERVISED_PRACTICE'),'ASSESS':('SUPERVISED_PRACTICE','ASSESSED'),'AUTHORIZE':('ASSESSED','AUTHORIZED')}
        if action=='REASSESS':
            if not technical_authority(user) or own or old not in {'AUTHORIZED','SUSPENDED','ASSESSED'}:raise PermissionError('Independent technical authority initiates reassessment')
            data.setdefault('authorization_history',[]).append({'approved_by_id':row.approved_by_id,'approved_at':row.approved_at.isoformat() if row.approved_at else None,'assessment':data.get('assessment'),'valid_until':row.valid_until.isoformat() if row.valid_until else None,'practice_runs':data.get('practice_runs',[])})
            data['practice_runs']=[];data['assessment']=None;row.status='ASSIGNED';row.approved_by_id=None;row.approved_at=None
        elif action=='PRACTICE_RUN':
            if old!='SUPERVISED_PRACTICE' or not technical_authority(user) or own:raise PermissionError('Supervised practice must be attested by a technical supervisor')
            sample=db.get(SampleRequest,int(body.get('sample_id') or 0));equipment=db.get(EquipmentAsset,int(body.get('equipment_id') or 0))
            if not sample or sample.site_id!=row.site_id or not equipment or equipment.site_id!=row.site_id or equipment.status!='IN_SERVICE' or not equipment.active:raise ValueError('Exact site Sample and in-service Equipment references required')
            if data.get('supervisor_id') and data['supervisor_id']!=user.id:raise PermissionError('Only the assigned technical supervisor may attest practice')
            if equipment.id not in data.get('equipment_ids',[]):raise ValueError('Equipment does not match the training scope')
            if body.get('performance') not in {'ACCEPTED','REPEAT_REQUIRED'}:raise ValueError('Practice performance is required')
            data.setdefault('practice_runs',[]).append({'sample_id':sample.id,'sample_number':sample.request_number,'test':data['test'],'equipment_id':equipment.id,'supervisor_id':user.id,'at':datetime.utcnow().isoformat(),'performance':body['performance'],'notes':reason})
        elif action in {'WITHDRAW','SUSPEND'}:
            if not technical_authority(user) or own or old!='AUTHORIZED':raise PermissionError('Technical authority may suspend / withdraw an active authorization')
            row.status='WITHDRAWN' if action=='WITHDRAW' else 'SUSPENDED'
        elif action in next_states:
            before,after=next_states[action]
            if old!=before:raise ValueError('Complete the preceding competency stage first')
            if action=='READ_METHOD':
                if not own:raise PermissionError('Employee must acknowledge their assigned controlled Method / SOP')
                doc=approved_document(db,user,data.get('document_id'));data['read_revision']=doc.revision;data['read_at']=datetime.utcnow().isoformat()
            else:
                if not technical_authority(user) or own:raise PermissionError('Independent technical assessment / authorization required')
                if action=='ASSESS':
                    accepted=sum(r['performance']=='ACCEPTED' for r in data.get('practice_runs',[]))
                    if accepted<int(data.get('required_runs') or 1):raise ValueError('Required supervised practice runs are not complete')
                    if body.get('assessment') not in {'PASS','FAIL'}:raise ValueError('Assessment PASS / FAIL required')
                    if not row.evidence_blob:raise ValueError('Competency assessment evidence is required')
                    data['assessment']=body['assessment'];data['assessed_by']=user.id;data['assessment_evidence_sha256']=row.evidence_sha256
                if action=='AUTHORIZE':
                    if data.get('assessment')!='PASS' or not row.evidence_blob or not row.valid_until or row.valid_until<=datetime.utcnow():raise ValueError('Passed assessment, evidence and future authorization validity required')
                    doc=approved_document(db,user,data.get('document_id'))
                    if doc.revision!=data.get('read_revision'):raise ValueError('Method revision changed; reassessment and fresh reading required')
                    for eid in data.get('equipment_ids',[]):
                        eq=db.get(EquipmentAsset,eid)
                        if not eq or eq.site_id!=row.site_id or not eq.active or eq.status!='IN_SERVICE':raise ValueError('Equipment authorization scope is no longer valid')
                    row.approved_by_id=user.id;row.approved_at=datetime.utcnow()
            row.status=after
        else:raise ValueError('Unsupported competency action')
    else:
        if action in {'ATTENDANCE','PROGRESS','ONBOARDING_STEP'}:
            if row.kind not in {'TRAINING','ONBOARDING'} or old!='ASSIGNED':raise ValueError('Only assigned training / onboarding accepts progress')
            if action=='ATTENDANCE' and (user.role not in MANAGERS or own):raise PermissionError('Attendance must be recorded by an independent coordinator')
            if action!='ATTENDANCE' and not own and user.role not in MANAGERS:raise PermissionError('Only the employee / coordinator records progress')
            if action=='PROGRESS':
                percent=int(body.get('progress') or 0)
                if not 0<=percent<=100:raise ValueError('Progress must be 0–100')
                data['progress']=percent
            if action=='ONBOARDING_STEP':
                step=body.get('step')
                if step not in data.get('onboarding_steps',[]):raise ValueError('Select a required onboarding step')
                data.setdefault('completed_steps',[]).append(step) if step not in data.get('completed_steps',[]) else None
            if action=='ATTENDANCE':data.setdefault('attendance',[]).append({'at':datetime.utcnow().isoformat(),'actor_id':user.id,'notes':reason})
        elif action=='SUBMIT':
            if old!='DRAFT' or not own and user.role not in MANAGERS:raise PermissionError('Only the owner / coordinator may submit drafts')
            if row.kind in {'CV','CERTIFICATE'} and not row.evidence_blob:raise ValueError('Original CV / certificate attachment required')
            row.status='SUBMITTED'
        elif action=='COMPLETE_TRAINING':
            if row.kind not in {'TRAINING','ONBOARDING'} or old!='ASSIGNED' or not own:raise PermissionError('Only the assigned employee may submit completed training')
            if not row.evidence_blob:raise ValueError('Attendance / completion evidence required')
            if row.kind=='ONBOARDING' and set(data.get('onboarding_steps',[]))-set(data.get('completed_steps',[])):raise ValueError('Complete all required onboarding steps first')
            row.status='SUBMITTED'
        elif action=='VERIFY':
            if user.role not in MANAGERS or own or old!='SUBMITTED':raise PermissionError('Independent verification required')
            data['verified_by']=user.id;data['verified_at']=datetime.utcnow().isoformat();row.status='VERIFIED'
        elif action=='APPROVE':
            if user.role not in MANAGERS or own or old!='VERIFIED':raise PermissionError('Independent approval follows verification')
            row.status='APPROVED';row.approved_by_id=user.id;row.approved_at=datetime.utcnow()
        elif action=='REJECT':
            if user.role not in MANAGERS or own or old not in {'SUBMITTED','VERIFIED'}:raise PermissionError('Only an independent reviewer may reject submitted work')
            row.status='REJECTED'
        else:raise ValueError('Unsupported development action')
    data.setdefault('history',[]).append({'action':action,'before':old,'after':row.status,'actor_id':user.id,'actor':user.full_name,'at':datetime.utcnow().isoformat(),'notes':reason})
    row.details_json=json.dumps(data);row.revision+=1;row.updated_at=datetime.utcnow()
    # No HR connection exists. Approval never creates a fictitious Synced status.
    row.hr_sync_status='NOT_CONNECTED'


@router.get('')
def workspace(request:Request,employee_id:int=0,db:Session=Depends(get_db)):
    user=require_user(request,db,INTERNAL);target=scoped_user(db,user,employee_id or user.id)
    records=list(db.scalars(select(EmployeeDevelopmentRecord).where(EmployeeDevelopmentRecord.employee_id==target.id,EmployeeDevelopmentRecord.site_id==target.site_id).order_by(EmployeeDevelopmentRecord.updated_at.desc())))
    data={r.id:json.loads(r.details_json or '{}') for r in records}
    people=list(db.scalars(select(User).where(User.site_id==user.site_id,User.active.is_(True),User.role.in_(INTERNAL)).order_by(User.full_name))) if user.role in MANAGERS else [user]
    docs=list(db.scalars(select(ControlledDocument).where((ControlledDocument.site_id==None)|(ControlledDocument.site_id==user.site_id))))
    docs=[d for d in docs if d.status=='APPROVED' or d.status=='ACTIVE' and d.manager_approved_by_id]
    if user.role=='trainee':
        assigned_docs={d.get('document_id') for d in data.values()};docs=[d for d in docs if d.id in assigned_docs]
    equipment=list(db.scalars(select(EquipmentAsset).where(EquipmentAsset.site_id==user.site_id,EquipmentAsset.active.is_(True))))
    if user.role=='trainee':
        assigned_eq={eid for d in data.values() for eid in d.get('equipment_ids',[])};equipment=[eq for eq in equipment if eq.id in assigned_eq]
    return templates.TemplateResponse('development.html',{'request':request,'user':user,'employee':target,'records':records,'record_data':data,'people':people,'documents':docs,'equipment':equipment,'active_authorizations':sum(r.status=='AUTHORIZED' and bool(r.valid_until) and r.valid_until>datetime.utcnow() for r in records),'can_manage':user.role in MANAGERS,'technical':technical_authority(user),'now':datetime.utcnow()})


@router.post('/records')
async def create_record(request:Request,employee_id:int=Form(...),kind:str=Form(...),title:str=Form(...),summary:str=Form(''),test:str=Form(''),document_id:int=Form(0),equipment_ids:list[int]=Form([]),required_runs:int=Form(1),supervisor_id:int=Form(0),provider:str=Form(''),certificate_number:str=Form(''),start_date:str=Form(''),end_date:str=Form(''),valid_until:str=Form(''),education:str=Form(''),job_title:str=Form(''),skills:str=Form(''),onboarding_steps:str=Form('Orientation\nSafety induction\nControlled documentation\nSupervised work'),upload:UploadFile|None=File(None),db:Session=Depends(get_db)):
    user=require_user(request,db,INTERNAL);employee=scoped_user(db,user,employee_id);kind=kind.upper()
    if kind not in KINDS or not title.strip() or len(title)>220:raise HTTPException(400,'Valid record type and title required')
    if kind in {'COMPETENCY','TRAINING','ONBOARDING','TRAINEE'} and user.role not in MANAGERS:raise HTTPException(403,'A coordinator / technical supervisor assigns development work')
    if kind=='COMPETENCY' and not technical_authority(user):raise HTTPException(403,'Technical staff assign competency pathways')
    if kind=='TRAINEE' and employee.role!='trainee':raise HTTPException(400,'Trainee profile requires a limited trainee account')
    try:
        details={'education':education,'job_title':job_title,'skills':skills,'onboarding_steps':[x.strip() for x in onboarding_steps.splitlines() if x.strip()][:30] if kind=='ONBOARDING' else [],'completed_steps':[],'attendance':[],'progress':0,'summary':summary,'test':test,'provider':provider,'certificate_number':certificate_number,'start_date':start_date,'end_date':end_date,'supervisor_id':supervisor_id or user.id,'required_runs':required_runs,'equipment_ids':equipment_ids,'document_id':document_id,'practice_runs':[],'history':[]}
        if not 1<=required_runs<=1000:raise ValueError('Required runs must be 1–1000')
        if supervisor_id:
            supervisor=scoped_user(db,user,supervisor_id)
            if kind=='COMPETENCY' and (supervisor.role not in TECHNICAL or supervisor.id==employee.id):raise ValueError('An independent technical supervisor is required')
        if kind=='COMPETENCY':
            doc=approved_document(db,user,document_id)
            if doc.document_type not in {'METHOD','SOP','EOP'}:raise ValueError('Competency requires an approved Method / SOP / Equipment Procedure')
            if not test.strip() or not equipment_ids:raise ValueError('Test, controlled Method/SOP and equipment scope required')
            details['method']=doc.method_name;details['document_revision']=doc.revision
        for eid in equipment_ids:
            eq=db.get(EquipmentAsset,eid)
            if not eq or eq.site_id!=user.site_id or not eq.active:raise ValueError('Equipment outside site scope')
            if kind=='COMPETENCY':
                from ..services.lab_operations import _equipment_supports_method
                if eq.status!='IN_SERVICE' or not _equipment_supports_method(eq.test_method,details['method']):raise ValueError('Equipment is not authorized for the controlled training method')
        expiry=datetime.fromisoformat(valid_until) if valid_until else None
        if expiry:expiry=(expiry if expiry.tzinfo else expiry.replace(tzinfo=timezone(timedelta(hours=3)))).astimezone(timezone.utc).replace(tzinfo=None)
        if expiry and expiry<=datetime.utcnow():raise ValueError('Expiry must be in the future')
        raw=await upload.read(1000001) if upload and upload.filename else b''
        if len(raw)>1000000:raise ValueError('Attachment must be at most 1 MB')
        row=EmployeeDevelopmentRecord(site_id=employee.site_id,employee_id=employee.id,kind=kind,title=title.strip(),status='ASSIGNED' if kind in {'COMPETENCY','TRAINING','ONBOARDING'} else 'DRAFT',details_json=json.dumps(details),evidence_blob=raw or None,evidence_name=(upload.filename or '')[:220] if raw else '',evidence_sha256=hashlib.sha256(raw).hexdigest() if raw else '',created_by_id=user.id,valid_until=expiry)
        db.add(row);db.flush();add_audit(db,actor=user,request=request,action='DEVELOPMENT_RECORD_CREATED',entity_type='EmployeeDevelopmentRecord',entity_id=row.id,summary=kind+': '+row.title,details={'employee_id':employee.id,'status':row.status});db.commit()
    except (ValueError,TypeError) as exc:db.rollback();raise HTTPException(400,str(exc)) from exc
    return RedirectResponse('/development?employee_id='+str(employee.id),303)


@router.post('/records/{rid}/action')
async def action_record(rid:int,request:Request,action:str=Form(...),revision:int=Form(...),reason:str=Form(...),sample_id:str=Form(''),equipment_id:str=Form(''),performance:str=Form(''),assessment:str=Form(''),progress:int=Form(0),step:str=Form(''),valid_until:str=Form(''),upload:UploadFile|None=File(None),db:Session=Depends(get_db)):
    user=require_user(request,db,INTERNAL);row=scoped_record(db,user,rid,True)
    if revision!=row.revision:raise HTTPException(409,'Record changed; refresh before continuing')
    try:
        if valid_until:
            if action!='AUTHORIZE' or not technical_authority(user) or row.employee_id==user.id:raise PermissionError('Only independent technical approval sets authorization validity')
            expiry=datetime.fromisoformat(valid_until)
            expiry=(expiry if expiry.tzinfo else expiry.replace(tzinfo=timezone(timedelta(hours=3)))).astimezone(timezone.utc).replace(tzinfo=None)
            if expiry<=datetime.utcnow():raise ValueError('Authorization validity must be in the future')
            row.valid_until=expiry
        if upload and upload.filename:
            raw=await upload.read(1000001)
            if not raw or len(raw)>1000000:raise ValueError('Evidence must be 1–1000000 bytes')
            data=json.loads(row.details_json or '{}');data.setdefault('evidence_history',[]).append({'name':row.evidence_name,'sha256':row.evidence_sha256,'data':row.evidence_blob.hex() if row.evidence_blob else '', 'at':datetime.utcnow().isoformat()})
            row.details_json=json.dumps(data);row.evidence_blob=raw;row.evidence_name=upload.filename[:220];row.evidence_sha256=hashlib.sha256(raw).hexdigest()
        transition(row,{'action':action,'reason':reason,'sample_id':sample_id,'equipment_id':equipment_id,'performance':performance,'assessment':assessment,'progress':progress,'step':step},user,db)
        add_audit(db,actor=user,request=request,action='DEVELOPMENT_'+action,entity_type='EmployeeDevelopmentRecord',entity_id=row.id,summary=row.title+' / '+row.status,details={'employee_id':row.employee_id,'revision':row.revision,'evidence_sha256':row.evidence_sha256});db.commit()
    except PermissionError as exc:db.rollback();raise HTTPException(403,str(exc)) from exc
    except (ValueError,KeyError,TypeError) as exc:db.rollback();raise HTTPException(400,str(exc)) from exc
    return RedirectResponse('/development?employee_id='+str(row.employee_id),303)


@router.get('/records/{rid}/evidence')
def record_evidence(rid:int,request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,INTERNAL);row=scoped_record(db,user,rid)
    if not row.evidence_blob:raise HTTPException(404,'Evidence not found')
    return Response(row.evidence_blob,media_type='application/octet-stream',headers={'Content-Disposition':'attachment; filename="development_evidence_'+str(rid)+'"','X-Content-SHA256':row.evidence_sha256,'Cache-Control':'no-store'})


@router.get('/materials/{doc_id}')
def training_material(doc_id:int,request:Request,db:Session=Depends(get_db)):
    from ..storage import CONTROLLED_DOCUMENT_DIR
    from fastapi.responses import FileResponse
    user=require_user(request,db,INTERNAL)
    try:doc=approved_document(db,user,doc_id)
    except ValueError as exc:raise HTTPException(404,str(exc)) from exc
    if user.role=='trainee':
        rows=db.scalars(select(EmployeeDevelopmentRecord).where(EmployeeDevelopmentRecord.employee_id==user.id,EmployeeDevelopmentRecord.site_id==user.site_id))
        if not any(json.loads(r.details_json or '{}').get('document_id')==doc_id for r in rows):raise HTTPException(403,'Only assigned approved training material is available')
    path=CONTROLLED_DOCUMENT_DIR/doc.stored_filename
    if not path.is_file():raise HTTPException(404,'Controlled source file unavailable')
    return FileResponse(path,filename=doc.original_filename,headers={'Cache-Control':'no-store'})


@router.get('/hr-export/{employee_id}')
def hr_export(employee_id:int,request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,COORDINATORS|TECHNICAL);employee=scoped_user(db,user,employee_id)
    rows=list(db.scalars(select(EmployeeDevelopmentRecord).where(EmployeeDevelopmentRecord.employee_id==employee.id,EmployeeDevelopmentRecord.status.in_(['APPROVED','AUTHORIZED']))))
    return {'connection':'NOT_CONNECTED','employee_id':employee.id,'corporate_email':employee.email,'records':[{'id':r.id,'kind':r.kind,'title':r.title,'approved_at':r.approved_at.isoformat() if r.approved_at else None,'valid_until':r.valid_until.isoformat() if r.valid_until else None,'sync_status':'NOT_CONNECTED'} for r in rows]}
