from __future__ import annotations
import hashlib,json
from datetime import datetime,timedelta,timezone
from fastapi import APIRouter,Depends,Request,Form,UploadFile,File,HTTPException
from fastapi.responses import RedirectResponse,Response
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..database import get_db
from ..dependencies import templates
from ..models import SafetyAssetRecord,SafetyInspectionRecord,ControlledDocument
from ..security import require_user
from ..services.audit import add_audit
from .development import INTERNAL,approved_document
router=APIRouter(prefix='/safety',tags=['safety management'])
MANAGE={'safety_officer','technical_manager','excellence'}
ASSET_TYPES={'Fire Extinguisher','Eye Wash','Safety Shower','Spill Kit','First Aid Kit','Fire Alarm','Emergency Exit','Safety Cabinet','Other'}


def asset_scope(db,user,aid,lock=False):
    stmt=select(SafetyAssetRecord).where(SafetyAssetRecord.id==aid,SafetyAssetRecord.site_id==user.site_id)
    if lock:stmt=stmt.with_for_update()
    row=db.scalar(stmt)
    if not row:raise HTTPException(404,'Safety asset not found')
    return row


def inspection_state(row,now=None):
    now=now or datetime.utcnow()
    if row.status=='OUT_OF_SERVICE':return 'Out of Service'
    if row.next_due<now:return 'Overdue'
    if row.next_due<=now+timedelta(days=7):return 'Due / Upcoming'
    return 'Current' if row.status=='INSPECTED' else 'Inspection Required'


@router.get('')
def workspace(request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,INTERNAL)
    if not user.site_id:raise HTTPException(400,'Site scope required')
    assets=list(db.scalars(select(SafetyAssetRecord).where(SafetyAssetRecord.site_id==user.site_id).order_by(SafetyAssetRecord.next_due)))
    inspections=list(db.scalars(select(SafetyInspectionRecord).join(SafetyAssetRecord,SafetyInspectionRecord.asset_id==SafetyAssetRecord.id).where(SafetyAssetRecord.site_id==user.site_id).order_by(SafetyInspectionRecord.inspected_at.desc())))
    docs=list(db.scalars(select(ControlledDocument).where(ControlledDocument.document_type.in_(['SAFETY','SDS','EMERGENCY']), (ControlledDocument.site_id==None)|(ControlledDocument.site_id==user.site_id))))
    docs=[d for d in docs if d.status=='APPROVED' or d.status=='ACTIVE' and d.manager_approved_by_id]
    states={a.id:inspection_state(a) for a in assets};checklists={a.id:json.loads(a.checklist_json) for a in assets}
    return templates.TemplateResponse('safety.html',{'request':request,'user':user,'assets':assets,'inspections':inspections,'documents':docs,'states':states,'checklists':checklists,'asset_types':sorted(ASSET_TYPES),'can_manage':user.role in MANAGE,'overdue':sum(x=='Overdue' for x in states.values()),'due':sum(x=='Due / Upcoming' for x in states.values()),'out_of_service':sum(x=='Out of Service' for x in states.values())})


@router.post('/assets')
def create_asset(request:Request,asset_code:str=Form(...),equipment_type:str=Form(...),location:str=Form(...),next_due:str=Form(...),checklist:str=Form(...),db:Session=Depends(get_db)):
    user=require_user(request,db,MANAGE)
    if not user.site_id:raise HTTPException(400,'Site scope required')
    items=[x.strip() for x in checklist.splitlines() if x.strip()]
    if not asset_code.strip() or len(asset_code)>80 or equipment_type not in ASSET_TYPES or not location.strip() or not items or len(items)!=len(set(items)):raise HTTPException(400,'Unique asset identification, location and checklist required')
    if db.scalar(select(SafetyAssetRecord.id).where(SafetyAssetRecord.site_id==user.site_id,SafetyAssetRecord.asset_code==asset_code.strip())):raise HTTPException(409,'Asset ID already registered')
    try:
        due=datetime.fromisoformat(next_due)
        due=(due if due.tzinfo else due.replace(tzinfo=timezone(timedelta(hours=3)))).astimezone(timezone.utc).replace(tzinfo=None)
    except ValueError as exc:raise HTTPException(400,'Valid next inspection date required') from exc
    row=SafetyAssetRecord(site_id=user.site_id,asset_code=asset_code.strip(),equipment_type=equipment_type,location=location.strip(),checklist_json=json.dumps(items),next_due=due,created_by_id=user.id)
    db.add(row);db.flush();add_audit(db,actor=user,request=request,action='SAFETY_ASSET_REGISTERED',entity_type='SafetyAssetRecord',entity_id=row.id,summary=row.asset_code+' / '+row.location);db.commit()
    return RedirectResponse('/safety',303)


@router.post('/assets/{aid}/inspect')
async def inspect_asset(aid:int,request:Request,expected_due:str=Form(...),checks:list[str]=Form([]),outcome:str=Form(...),findings:str=Form(''),corrective_action:str=Form(''),next_due:str=Form(...),upload:UploadFile=File(...),db:Session=Depends(get_db)):
    user=require_user(request,db,MANAGE);asset=asset_scope(db,user,aid,True)
    if expected_due!=asset.next_due.isoformat():raise HTTPException(409,'Inspection state changed; refresh')
    required=json.loads(asset.checklist_json)
    if outcome not in {'PASS','FAIL'} or set(checks)!=set(required):raise HTTPException(400,'Complete every checklist item and record PASS / FAIL')
    if outcome=='FAIL' and (not findings.strip() or not corrective_action.strip()):raise HTTPException(400,'Failed inspection requires findings and corrective action')
    try:
        due=datetime.fromisoformat(next_due)
        due=(due if due.tzinfo else due.replace(tzinfo=timezone(timedelta(hours=3)))).astimezone(timezone.utc).replace(tzinfo=None)
    except ValueError as exc:raise HTTPException(400,'Valid next inspection date required') from exc
    if due<=datetime.utcnow():raise HTTPException(400,'Next due date must be in the future')
    raw=await upload.read(1000001)
    if not raw or len(raw)>1000000:raise HTTPException(400,'Original inspection evidence must be 1–1000000 bytes')
    row=SafetyInspectionRecord(asset_id=asset.id,inspector_id=user.id,outcome=outcome,checklist_json=json.dumps({'checked':checks,'result':outcome}),findings=findings,corrective_action=corrective_action,next_due=due,evidence_blob=raw,evidence_name=(upload.filename or 'inspection')[:220],evidence_sha256=hashlib.sha256(raw).hexdigest())
    db.add(row);db.flush();asset.status='INSPECTED' if outcome=='PASS' else 'OUT_OF_SERVICE';asset.next_due=due
    add_audit(db,actor=user,request=request,action='SAFETY_INSPECTION_RECORDED',entity_type='SafetyInspectionRecord',entity_id=row.id,summary=asset.asset_code+' / '+outcome,details={'asset_id':asset.id,'checklist':checks,'findings':findings,'corrective_action':corrective_action,'evidence_sha256':row.evidence_sha256});db.commit()
    return RedirectResponse('/safety',303)


@router.get('/inspections/{iid}/evidence')
def inspection_evidence(iid:int,request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,INTERNAL);row=db.get(SafetyInspectionRecord,iid)
    if not row:raise HTTPException(404,'Inspection not found')
    asset_scope(db,user,row.asset_id)
    return Response(row.evidence_blob,media_type='application/octet-stream',headers={'Content-Disposition':f'attachment; filename="inspection_{iid}_evidence"','X-Content-SHA256':row.evidence_sha256,'Cache-Control':'no-store'})


@router.get('/library/{doc_id}')
def safety_document(doc_id:int,request:Request,db:Session=Depends(get_db)):
    from ..storage import CONTROLLED_DOCUMENT_DIR
    from fastapi.responses import FileResponse
    user=require_user(request,db,INTERNAL)
    try:doc=approved_document(db,user,doc_id)
    except ValueError as exc:raise HTTPException(404,str(exc)) from exc
    if doc.document_type not in {'SAFETY','SDS','EMERGENCY'}:raise HTTPException(404,'Safety source not found')
    path=CONTROLLED_DOCUMENT_DIR/doc.stored_filename
    if not path.is_file():raise HTTPException(404,'Controlled source unavailable')
    return FileResponse(path,filename=doc.original_filename,headers={'Cache-Control':'no-store'})
