from __future__ import annotations

from .models import Role

LAB_SECTION_INFO = {
    "dashboard": ("Operations Overview", "Laboratory flow, workload and operational status."),
    "labprogress": ("Laboratory Operations Display", "Dedicated read-only wallboard for laboratory status; not a normal departmental workspace."),
    "supervisor": ("Technical Supervision", "Senior Chemist workload, result review, retest/resample and technical supervision."),
    "batch": ("Batch Diagnostics", "Admin-only compatibility view. Operational sample batching is owned by Sample Intake & Distribution."),
    "workstations": ("Test Workstations", "Assigned analytical result entry with controlled method and calculation support."),
    "finalreport": ("Result Worksheets", "Technical result worksheets for review/print only. Final approval and official TSCO release live in Final Controlled Reports."),
    "retained": ("Retained Samples", "Storage location, retention period, due dates and controlled disposal."),
    "quality": ("Quality Control Governance", "Controlled QC lots, Senior technical activation and assigned routine QC."),
    "knowledge": ("Methods & Procedures", "Controlled methods, SOPs, EOPs and quick operating guidance."),
    "tracking": ("Operations Records", "Searchable sample history, result actions and operational records."),
    "general": ("Laboratory Settings", "Site, staff, document and controlled calculation configuration."),
}

# This matrix is intentionally restrictive. Job seniority does not automatically inherit
# transactional rights from a lower operational role.
LAB_ROLE_SECTIONS = {
    Role.LAB_TECHNICIAN.value: {"workstations", "quality", "knowledge"},
    Role.SENIOR_CHEMIST.value: {"finalreport", "retained", "quality", "knowledge", "tracking"},
    Role.QUALITY.value: set(),
    Role.TECHNICAL_MANAGER.value: {"labprogress", "finalreport", "retained", "quality", "knowledge", "tracking", "general"},
    Role.MANAGEMENT.value: set(),
    Role.SYSTEM_ADMIN.value: {"general"},
}


def lab_section_allowed(role: str, section: str) -> bool:
    return section in LAB_ROLE_SECTIONS.get(role, set())
