R14.11 - QR Data Form + Batch Receiving (2026-10-11)

This unified release supersedes the un-deployed R14.10 QR package and retains the deployed R14.9 commercial corrections.

Normal receiving: Camera / Upload Photo or PDF -> all QR detection -> one compact reviewed batch -> Accept All -> Received/Registered -> Batch & Distribution.
- Native rear-camera capture control for iPad/mobile; JPEG/PNG/WebP/PDF fallback upload.
- Server-side QR detection resolves existing permanent Planned Sample tokens without fetching external URLs.
- Exact confirmed Data Form scope; missing sample IDs/identities shown and acceptance blocked.
- Foreign/unknown/site-mismatched QR and mixed cases/forms are blocked.
- Physical identity/quantity confirmation required; condition exceptions folded by default.
- New transformer serial shown once for review; one controlled Asset Master registration per transformer.
- Asset audit retains the full approved Data Form transformer metadata.
- Same Planned Sample IDs, barcode values, QR tokens and original service/method/priority/TAT mapping.
- Existing field-materialized records reused; no duplicate physical sample.
- One database transaction, with review/case/planned/sample locks and server-owned scan evidence.
- 30-minute actor/site-bound review; stale scope, missing codes, duplicate assets or incomplete approval block acceptance.
- Retry of the same accepted review is idempotent; competing scans cannot create a second receipt.
- Physical timestamp, registration, custody and audit recorded; client request shows received quantity.
- Manual queues and Exceptional / Unplanned Intake remain available as collapsed fallbacks.
- Receiving does not automatically bypass controlled Batch & Distribution / laboratory release.

R14.10 retained: 18 mm vector QR with quiet zone; four samples fit one A4 page; readable fixed IDs; authenticated clickable QR; no client container-label requirement.

Validation: 124 tests passed, fresh and in-place migration checks passed, locked lab/QC/report authority unchanged, JavaScript review/accept gates passed. Rotated JPEG photo, generated A4 PDF, 3/4 missing identity, mixed cases, unknown QR, review ownership/expiry, stale form, duplicate assets, field-record reuse, rollback and retry tested. Device-native camera interaction and actual printed paper scan remain post-deployment UAT checks.

Migration: e8b4a1c90320, adds receiving_batch_scans only; preserves existing data and identities.
Dependencies added: zxing-cpp 3.1.1, pypdfium2 4.30.0. No external OCR/service needed.
Render: upload this ZIP, retain TSCO_REFERENCE_ASSETS.zip, update Build Command. Start command unchanged (alembic upgrade head before uvicorn).
