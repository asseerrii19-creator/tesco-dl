# QC forensic comparison before repair
Baseline: supplied R14.11 SHA c0666a29c0f0bee1ba05361b9f76d9042ccd7b01e50e3f1b39e54d3a811bb374.
Current live R14.9 was previously inspected read-only; browser session currently requires login.
GitHub history was unavailable because its connector was not connected. Two Library H ZIP variants were obtained for comparison. Neither contains the controlled QC lot lifecycle described in the supplied v3.5.6 verification documents. Those claims cannot be treated as tested current code.

Affected sources: app/lab_sections.py, app/templates/base.html, app/routes/lab_operations.py, app/services/lab_operations.py, app/lab_ops/index_template.html.
Before: Senior denied quality section. Technical Manager alone could append/select profiles. Three-run qualification directly selected a profile. Profiles resolved by broad QC group with no material/lot approval, expiry or exact equipment binding. Daily schedule existed, including Water startup two runs and ten-result cadence. QR/receiving did not modify QC.
Minimal plan: keep canonical quality route and state collection; add controlled lot registration/independent Senior signature endpoints; retain legacy profiles/history without treating them as new approved lots; enforce exact context and expiry on every routine QC/result gate; preserve assignments and report release authority. No data reset or Sample ID migration.
