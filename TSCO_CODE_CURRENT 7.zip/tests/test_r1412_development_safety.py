from datetime import datetime,timedelta
import json
from types import SimpleNamespace
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select
from app.main import app
from app.database import SessionLocal
from app.models import User,EmployeeDevelopmentRecord,SafetyAssetRecord,SafetyInspectionRecord
from app.routes.development import transition,scoped_user
from app.routes.safety import inspection_state
from test_v3712_commercial_flow_batch import login


def test_training_completion_does_not_grant_authorization_and_approval_is_independent():
    employee=SimpleNamespace(id=10,role='lab_technician',full_name='Employee')
    manager=SimpleNamespace(id=20,role='training_coordinator',full_name='Coordinator')
    record=SimpleNamespace(employee_id=10,kind='TRAINING',status='ASSIGNED',details_json='{}',evidence_blob=b'attendance',revision=0,hr_sync_status='',updated_at=None)
    transition(record,{'action':'COMPLETE_TRAINING','reason':'Training evidence submitted'},employee,None)
    assert record.status=='SUBMITTED'
    with pytest.raises(PermissionError):transition(record,{'action':'APPROVE','reason':'Self approve'},employee,None)
    transition(record,{'action':'VERIFY','reason':'Attendance verified'},manager,None)
    transition(record,{'action':'APPROVE','reason':'Completion approved'},manager,None)
    assert record.status=='APPROVED' and record.status!='AUTHORIZED' and record.hr_sync_status=='NOT_CONNECTED'


def test_technical_authorization_cannot_skip_controlled_stages():
    record=SimpleNamespace(employee_id=10,kind='COMPETENCY',status='ASSIGNED',details_json='{}',revision=0)
    manager=SimpleNamespace(id=20,role='senior_chemist',full_name='Senior')
    with pytest.raises(ValueError,match='preceding'):transition(record,{'action':'AUTHORIZE','reason':'Attempt skip'},manager,None)


def test_safety_alerts_follow_real_due_and_out_of_service():
    now=datetime.utcnow()
    row=SimpleNamespace(status='UNINSPECTED',next_due=now-timedelta(days=1))
    assert inspection_state(row,now)=='Overdue'
    row.next_due=now+timedelta(days=2);assert inspection_state(row,now)=='Due / Upcoming'
    row.status='OUT_OF_SERVICE';assert inspection_state(row,now)=='Out of Service'


def test_private_development_and_safety_receiving_routes():
    with TestClient(app) as browser:
        login(browser,'chemist@tsco.local')
        assert browser.get('/development').status_code==200
        assert browser.get('/safety').status_code==200
        with SessionLocal() as db:
            others=list(db.scalars(select(User).where(User.email!='chemist@tsco.local',User.site_id!=None)))
            oid=others[0].id
        assert browser.get('/development?employee_id='+str(oid)).status_code in {403,404}
        assert browser.post('/safety/assets',data={'asset_code':'BAD','equipment_type':'Fire Extinguisher','location':'Lab','next_due':'2027-01-01','checklist':'Pressure'}).status_code==403
        login(browser,'client@sec.local');assert browser.get('/development').status_code==403
        assert browser.get('/safety').status_code==403
        assert browser.get('/lab/operations?section=quality').status_code==403


def test_safety_inspection_requires_all_checks_and_preserves_failed_evidence():
    with TestClient(app) as browser:
        login(browser,'lab.manager@tsco.local')
        response=browser.post('/safety/assets',data={'asset_code':'FE-TEST','equipment_type':'Fire Extinguisher','location':'Test Lab','next_due':'2027-01-01','checklist':'Pressure\nSeal'},follow_redirects=False)
        assert response.status_code==303,response.text
        with SessionLocal() as db:a=db.scalar(select(SafetyAssetRecord).where(SafetyAssetRecord.asset_code=='FE-TEST'));aid=a.id;due=a.next_due.isoformat()
        fields={'expected_due':due,'checks':['Pressure'],'outcome':'PASS','next_due':'2027-02-01'}
        files={'upload':('inspection.txt',b'Original inspection evidence','text/plain')}
        assert browser.post(f'/safety/assets/{aid}/inspect',data=fields,files=files).status_code==400
        fields.update({'checks':['Pressure','Seal'],'outcome':'FAIL','findings':'Pressure low','corrective_action':'Remove from service and refill'})
        response=browser.post(f'/safety/assets/{aid}/inspect',data=fields,files=files,follow_redirects=False);assert response.status_code==303,response.text
        with SessionLocal() as db:
            a=db.get(SafetyAssetRecord,aid);r=db.scalar(select(SafetyInspectionRecord).where(SafetyInspectionRecord.asset_id==aid))
            assert a.status=='OUT_OF_SERVICE' and r.evidence_blob==b'Original inspection evidence'
            iid=r.id
        assert browser.get(f'/safety/inspections/{iid}/evidence').content==b'Original inspection evidence'
