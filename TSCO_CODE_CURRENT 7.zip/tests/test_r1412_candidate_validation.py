from datetime import datetime,timedelta,timezone
from types import SimpleNamespace
import json
import pytest
from test_r1412_qc_lifecycle import setup_lot
from app.services.qc_lifecycle import decide_lot
from app.services.lab_operations import _analytical_qc_schedule_state
from app.routes.development import transition


def test_water_checkpoint_after_ten_results_requires_new_qc(monkeypatch):
    monkeypatch.setenv('APP_SECRET','test-secret-at-least-32-characters-long')
    p,l,c,t,s,_=setup_lot();decide_lot(p,l['id'],{'action':'ACTIVATE','signed':True,'reason':'Reviewed'},s,None,None)
    now=datetime.now(timezone.utc)
    for n in range(2):
        p['qc'].append({'id':f'QC-{n}','test':'Water','context_test':c['test'],'method_name':c['method'],'workstation':c['workstation'],'equipment_asset_id':69,'batch_id':'B1','status':'PASS','qc_lot_id':l['id'],'lot_signature':l['signature'],'ts':(now-timedelta(minutes=2-n)).isoformat()})
    for n in range(9):
        p['results'].append({'id':str(n),'batch':'B1','qc_context_test':c['test'],'qc_group':'Water','test_method':c['method'],'workstation':c['workstation'],'equipment_asset_id':69,'qc_lot_id':l['id'],'ts':now.isoformat()})
    assert _analytical_qc_schedule_state(p,c,69)['ready']
    p['results'].append(dict(p['results'][0],id='tenth'))
    assert _analytical_qc_schedule_state(p,c,69)['reason']=='WATER_10_RESULT_CHECKPOINT'
    p['qc'].append(dict(p['qc'][-1],id='QC-CHECKPOINT',ts=(now+timedelta(seconds=1)).isoformat()))
    assert _analytical_qc_schedule_state(p,c,69)['ready']


def test_competency_full_controlled_sequence_and_reassessment():
    from app.models import ControlledDocument,EquipmentAsset,SampleRequest
    employee=SimpleNamespace(id=10,role='lab_technician',full_name='Employee',site_id=1)
    senior=SimpleNamespace(id=20,role='senior_chemist',senior_responsibility_domain='TECHNICAL',full_name='Senior',site_id=1)
    doc=SimpleNamespace(site_id=1,status='APPROVED',revision='03')
    equipment=SimpleNamespace(id=69,site_id=1,status='IN_SERVICE',active=True)
    sample=SimpleNamespace(id=5,site_id=1,request_number='FS-DMM-26-000005')
    class DB:
        def get(self,model,key):return {ControlledDocument:doc,EquipmentAsset:equipment,SampleRequest:sample}[model]
    row=SimpleNamespace(employee_id=10,site_id=1,kind='COMPETENCY',status='ASSIGNED',details_json=json.dumps({'document_id':1,'equipment_ids':[69],'test':'Water','required_runs':1,'supervisor_id':20}),evidence_blob=b'assessment evidence',evidence_sha256='stored-sha',revision=0,approved_by_id=None,approved_at=None,valid_until=datetime.utcnow()+timedelta(days=30),hr_sync_status='',updated_at=None)
    def act(action,actor=senior,**body):transition(row,{'action':action,'reason':'Controlled evidence reviewed',**body},actor,DB())
    act('READ_METHOD',employee);act('OBSERVE');act('START_PRACTICE')
    with pytest.raises(ValueError,match='not complete'):act('ASSESS',assessment='PASS')
    act('PRACTICE_RUN',sample_id=5,equipment_id=69,performance='ACCEPTED')
    act('ASSESS',assessment='FAIL')
    with pytest.raises(ValueError,match='Passed assessment'):act('AUTHORIZE')
    act('REASSESS');act('READ_METHOD',employee);act('OBSERVE');act('START_PRACTICE');act('PRACTICE_RUN',sample_id=5,equipment_id=69,performance='ACCEPTED');act('ASSESS',assessment='PASS');act('AUTHORIZE')
    assert row.status=='AUTHORIZED' and row.approved_by_id==20
    act('SUSPEND');assert row.status=='SUSPENDED'
    act('REASSESS');assert row.status=='ASSIGNED' and json.loads(row.details_json)['practice_runs']==[]


def test_a4_report_geometry_and_sample_continuity(tmp_path):
    from copy import deepcopy
    from pypdf import PdfReader
    from test_v341_final_analysis_report import _payload
    from app.services.final_report_pdf import build_final_report_pdf
    p=_payload();cols=[{'sample_id':f's{i}','number':f'FS-DMM-26-{i+5:06d}','date':'11/10/2026'} for i in range(12)]
    for key in ['dga','furan','oil']:
        p[key]['columns']=cols
        for row in p[key]['rows']:row['values']={c['sample_id']:'12.4' for c in cols}
    p['report_groups']=[dict(p[k],key=k,label=k.upper()) for k in ['dga','furan','oil']]
    p['report']['recommendation']='Review original evidence. '*160
    out=tmp_path/'review.pdf';build_final_report_pdf(p,out)
    pages=PdfReader(out).pages
    assert all(abs(float(page.mediabox.width)-595.2756)<.1 and abs(float(page.mediabox.height)-841.8898)<.1 for page in pages)
    content=''.join(''.join((page.extract_text() or '').split()) for page in pages)
    assert all(c['number'] in content for c in cols)
