from contextlib import closing
from datetime import datetime, timedelta
from io import BytesIO
from uuid import uuid4
import json

import pytest
import pypdfium2 as pdfium
from fastapi.testclient import TestClient
from sqlalchemy import select, func
from PIL import Image
from reportlab.pdfgen.canvas import Canvas
from app.main import app
from app.database import SessionLocal
from app.models import Asset, ClientSamplingDataForm, CommercialCase, PlannedSample, ReceivingBatchScan, SampleRequest, CustodyEvent, AuditLog, User
from app.services.sampling_data_form import update_form_payload, render_pdf_bytes, _planned_qr
from app.services.receiving_batch import decode_document, match_document
from app.services.planned_sample_qr import planned_sample_url
from app.services.lab_operations import resolved_sample_package
from test_v3712_commercial_flow_batch import make_case, login, confirm

HEADERS={'Accept':'application/json'}


def approved_case(browser):
    case_id, line_id, code=make_case()
    with SessionLocal() as db:
        case=db.get(CommercialCase,case_id)
        form=ClientSamplingDataForm(commercial_case_id=case_id,revision=1,status='DRAFT',entry_method='ONLINE',created_by_id=case.owner_id)
        db.add(form);db.flush()
        serial='QR-BATCH-'+uuid4().hex[:10]
        actor=db.get(User,case.owner_id)
        update_form_payload(form,1,client={'company_name':case.client.name},asset={'serial_number':serial,'tag_number':'TAG-QR','manufacturer_name':'WESCOSA'},
            sampling={'test_priority':'Normal','sampling_date_time':'11-Oct-2026 09:45','unit_oil_temperature_c':'48','reason_of_sampling':'Routine'},
            samples=[{'sampling_from':'Bottom Tank'}]+[{'sampling_from':'Tap Changer','sampling_detail':str(n)} for n in (1,2,3)],actor=actor,confirm=True)
        db.commit()
    login(browser);assert confirm(browser,case_id).status_code==303
    with SessionLocal() as db:quote_id=db.get(CommercialCase,case_id).quotation_id
    login(browser,'client@sec.local')
    assert browser.post(f'/client/requests/{case_id}/quotation-decision',data={'decision':'ACCEPT','reviewed_quote_id':quote_id,'quotation_reviewed':'yes'},follow_redirects=False).status_code==303
    assert browser.post(f'/client/requests/{case_id}/purchase-order',data={'purchase_order_number':'PO-QR-'+uuid4().hex[:6]},files={'upload':('po.pdf',b'%PDF-1.4\n%test\n','application/pdf')},follow_redirects=False).status_code==303
    login(browser)
    assert browser.post(f'/commercial/cases/{case_id}/advance',data={'target_stage':'COMPLETE_HANDOVER','handover_commercial':'Accepted quotation and PO','handover_technical':'4 Routine ASTM','handover_client_info':'SEC'},follow_redirects=False).status_code==303
    with SessionLocal() as db:
        case=db.get(CommercialCase,case_id)
        form=db.scalar(select(ClientSamplingDataForm).where(ClientSamplingDataForm.commercial_case_id==case_id))
        raw=render_pdf_bytes(db,form,case)
        plans=list(db.scalars(select(PlannedSample).where(PlannedSample.commercial_case_id==case_id).order_by(PlannedSample.id)))
        ids=[p.request_number for p in plans];values=[planned_sample_url(p) for p in plans]
    login(browser,'data.entry@tsco.local')
    return case_id,serial,raw,ids,values


def scan(browser,raw,name='Data_Form.pdf'):
    return browser.post('/intake/batch-scan',files={'upload':(name,raw,'application/pdf' if name.endswith('.pdf') else 'image/jpeg')},headers=HEADERS)


def accept(browser,review,**extra):
    return browser.post('/intake/batch-scan/accept',data={'review_token':review['review_token'],'physical_confirmed':'yes','new_asset_reviewed':'yes',**extra},headers=HEADERS)


def synthetic_pdf(values):
    buffer=BytesIO();canvas=Canvas(buffer)
    from reportlab.graphics.barcode import qr
    from reportlab.graphics.shapes import Drawing
    for n,value in enumerate(values):
        widget=qr.QrCodeWidget(value,barBorder=4)
        d=Drawing(100,100);d.add(widget);d.drawOn(canvas,40+120*(n%4),500-120*(n//4))
    canvas.showPage();canvas.save();return buffer.getvalue()


def test_photo_and_pdf_scan_then_atomic_four_sample_receipt(monkeypatch):
    monkeypatch.setenv('PUBLIC_BASE_URL','https://tsco-v285-final-review.onrender.com')
    with TestClient(app) as browser:
        case_id,serial,raw,ids,values=approved_case(browser)
        assert set(decode_document(raw))==set(values)
        with closing(pdfium.PdfDocument(raw)) as pdf:
            with closing(pdf[0]) as page:
                with closing(page.render(scale=3)) as bitmap:
                    image=bitmap.to_pil().copy().rotate(90,expand=True)
        buf=BytesIO();image.save(buf,format='JPEG',quality=85)
        result=scan(browser,buf.getvalue(),'camera.jpg');assert result.status_code==200,result.text
        review=result.json();assert review['matched']==review['expected']==4 and review['can_accept']
        assert review['new_serials']==[serial]
        assert [r['sampling_identity'] for r in review['samples']]==['Bottom Tank','Tap Changer — 1','Tap Changer — 2','Tap Changer — 3']
        assert accept(browser,review,new_asset_reviewed='').status_code==400
        with SessionLocal() as db:
            assert db.scalar(select(func.count()).select_from(SampleRequest).where(SampleRequest.commercial_case_id==case_id))==0
            assert db.scalar(select(func.count()).select_from(Asset).where(Asset.serial_number==serial))==0
        response=accept(browser,review);assert response.status_code==200,response.text
        assert response.json()['received']==4
        with SessionLocal() as db:
            samples=list(db.scalars(select(SampleRequest).where(SampleRequest.commercial_case_id==case_id).order_by(SampleRequest.id)))
            plans=list(db.scalars(select(PlannedSample).where(PlannedSample.commercial_case_id==case_id).order_by(PlannedSample.id)))
            assert [s.request_number for s in samples]==ids
            assert [planned_sample_url(p) for p in plans]==values
            assert {s.status for s in samples}=={'RECEIVED'}
            assert len({s.received_at for s in samples})==1 and all(s.registered_at for s in samples)
            assert len({s.asset_id for s in samples})==1
            assert all(s.oil_temperature_c==48 and s.sample_date_time==datetime(2026,10,11,9,45) for s in samples)
            assert all(s.requested_method_family=='ASTM' and not any(t.get('method_conflict') for t in resolved_sample_package(db,s)['tests']) for s in samples)
            assert db.scalar(select(func.count()).select_from(CustodyEvent).where(CustodyEvent.sample_request_id.in_([s.id for s in samples]),CustodyEvent.event_type=='PHYSICAL_RECEIPT'))==4
            before=db.scalar(select(func.count()).select_from(AuditLog).where(AuditLog.action=='RECEIVING_BATCH_ACCEPTED'))
            stored=db.scalar(select(ReceivingBatchScan).where(ReceivingBatchScan.nonce==review['review_token']))
            assert stored.evidence_blob and stored.accepted_at and len(json.loads(stored.sample_ids_json))==4
        repeat=accept(browser,review);assert repeat.status_code==200 and repeat.json()['already_accepted']
        with SessionLocal() as db:
            assert db.scalar(select(func.count()).select_from(AuditLog).where(AuditLog.action=='RECEIVING_BATCH_ACCEPTED'))==before
        assert scan(browser,raw).json()['can_accept'] is False
        page=browser.get(response.json()['next_url']);assert page.status_code==200 and 'Received / Registered 4 / 4' in page.text
        login(browser,'client@sec.local')
        page=browser.get(f'/client/requests/{case_id}')
        assert page.status_code==200 and 'Physical receiving: 4 / 4 received' in page.text


def test_missing_qr_shows_exact_sample_and_accepts_nothing(monkeypatch):
    monkeypatch.setenv('PUBLIC_BASE_URL','https://tsco-v285-final-review.onrender.com')
    with TestClient(app) as browser:
        case_id,serial,raw,ids,values=approved_case(browser)
        response=scan(browser,synthetic_pdf(values[:3]));assert response.status_code==200,response.text
        review=response.json();assert review['matched']==3 and review['expected']==4 and not review['can_accept']
        missing=[r for r in review['samples'] if not r['matched']]
        assert len(missing)==1 and missing[0]['sample_id']==ids[-1] and missing[0]['sampling_identity']=='Tap Changer — 3'
        assert accept(browser,review).status_code==400
        with SessionLocal() as db:
            assert db.scalar(select(func.count()).select_from(SampleRequest).where(SampleRequest.commercial_case_id==case_id))==0


def test_mixed_unknown_foreign_qr_rejected_and_expired_review(monkeypatch):
    monkeypatch.setenv('PUBLIC_BASE_URL','https://tsco-v285-final-review.onrender.com')
    with TestClient(app) as browser:
        first=approved_case(browser);second=approved_case(browser)
        assert scan(browser,synthetic_pdf(first[4]+second[4])).status_code==400
        assert scan(browser,synthetic_pdf(first[4]+['https://evil.example/intake/p/unknown'])).status_code==400
        result=scan(browser,first[2]);assert result.status_code==200
        with SessionLocal() as db:
            review=db.scalar(select(ReceivingBatchScan).where(ReceivingBatchScan.nonce==result.json()['review_token']))
            review.created_at=datetime.utcnow()-timedelta(hours=1);db.commit()
        assert accept(browser,result.json()).status_code==400
        login(browser,'client@sec.local')
        assert scan(browser,first[2]).status_code==403


def test_failure_rolls_back_entire_batch_and_stale_form_blocks(monkeypatch):
    monkeypatch.setenv('PUBLIC_BASE_URL','https://tsco-v285-final-review.onrender.com')
    with TestClient(app) as browser:
        case_id,serial,raw,ids,values=approved_case(browser)
        review=scan(browser,raw).json()
        import app.services.receiving_batch as batch
        real=batch.register_in_tsco;calls=[]
        def fail_second(db,sample,user):
            calls.append(sample.id)
            if len(calls)==2:raise ValueError('Simulated controlled registration failure')
            return real(db,sample,user)
        monkeypatch.setattr(batch,'register_in_tsco',fail_second)
        assert accept(browser,review).status_code==400
        with SessionLocal() as db:
            assert db.scalar(select(func.count()).select_from(SampleRequest).where(SampleRequest.commercial_case_id==case_id))==0
            assert db.scalar(select(func.count()).select_from(Asset).where(Asset.serial_number==serial))==0
            assert all(p.sample_request_id is None for p in db.scalars(select(PlannedSample).where(PlannedSample.commercial_case_id==case_id)))
            form=db.scalar(select(ClientSamplingDataForm).where(ClientSamplingDataForm.commercial_case_id==case_id));form.revision+=1;db.commit()
        assert accept(browser,review).status_code==400


def test_camera_upload_and_exceptional_intake_are_compact():
    from pathlib import Path
    root=Path(__file__).resolve().parents[1]
    template=(root/'app/templates/receiving_batch_scan.html').read_text()
    assert 'capture="environment"' in template and 'Upload Photo / PDF' in template
    queue=(root/'app/templates/intake_queue.html').read_text()
    assert 'Exceptional / Unplanned Intake</summary>' in queue and 'receiving_batch_scan.html' in queue
    assert 'accept.disabled=busy||!ready' in (root/'app/static/receiving-batch.js').read_text()


def test_field_materialized_sample_reused_without_second_identity(monkeypatch):
    monkeypatch.setenv('PUBLIC_BASE_URL','https://tsco-v285-final-review.onrender.com')
    with TestClient(app) as browser:
        case_id,serial,raw,ids,values=approved_case(browser)
        with SessionLocal() as db:
            case=db.get(CommercialCase,case_id)
            asset=Asset(client_id=case.client_id,asset_code='FIELD-'+uuid4().hex[:8],serial_number=serial,active=True)
            db.add(asset);db.flush()
            plans=list(db.scalars(select(PlannedSample).where(PlannedSample.commercial_case_id==case_id).order_by(PlannedSample.id)))
            plan=plans[0]
            sample=SampleRequest(request_number=plan.request_number,public_token=plan.public_token,barcode_value=plan.barcode_value,
                status='SUBMITTED',site_id=plan.site_id,client_id=plan.client_id,commercial_case_id=case_id,commercial_request_line_id=plan.commercial_request_line_id,
                quotation_id=case.quotation_id,purchase_order_id=case.purchase_order_id,asset_id=asset.id,sample_date_time=datetime(2026,10,11,8),
                sampling_point=plan.sampling_point,requested_package=plan.requested_package,requested_method_family=plan.requested_method_family)
            db.add(sample);db.flush()
            from app.services.planned_samples import claim_planned_identity
            claim_planned_identity(plan,sample);db.commit();sample_id=sample.id
        review=scan(browser,raw).json();assert not review['new_serials'] and review['can_accept']
        assert accept(browser,review,new_asset_reviewed='').status_code==200
        with SessionLocal() as db:
            samples=list(db.scalars(select(SampleRequest).where(SampleRequest.commercial_case_id==case_id)))
            assert len(samples)==4 and {s.request_number for s in samples}==set(ids)
            assert db.get(SampleRequest,sample_id).received_at and db.get(SampleRequest,sample_id).sample_date_time==datetime(2026,10,11,8)


def test_review_is_owned_and_duplicate_codes_deduplicated(monkeypatch):
    monkeypatch.setenv('PUBLIC_BASE_URL','https://tsco-v285-final-review.onrender.com')
    with TestClient(app) as browser:
        case_id,serial,raw,ids,values=approved_case(browser)
        review=scan(browser,synthetic_pdf(values+values)).json()
        assert review['matched']==4 and review['expected']==4
        assert accept(browser,review,physical_confirmed='').status_code==400
        with SessionLocal() as db:
            from app.security import hash_password
            actor=db.scalar(select(User).where(User.email=='data.entry@tsco.local'))
            email='receiver-'+uuid4().hex[:8]+'@tsco.local'
            user=User(email=email,password_hash=hash_password('Demo123!'),full_name='Other Receiver',role='data_entry',site_id=actor.site_id,active=True,must_change_password=False)
            db.add(user);db.commit()
        login(browser,email)
        assert accept(browser,review).status_code==400
        login(browser,'data.entry@tsco.local')
        assert scan(browser,b'not-an-image','broken.jpg').status_code==400
        with SessionLocal() as db:
            case=db.get(CommercialCase,case_id)
            db.add_all([Asset(client_id=case.client_id,asset_code='DUP1-'+uuid4().hex[:8],serial_number=serial,active=True),
                        Asset(client_id=case.client_id,asset_code='DUP2-'+uuid4().hex[:8],serial_number=serial,active=True)])
            db.commit()
        summary=scan(browser,raw).json();assert not summary['can_accept'] and any('duplicate' in issue for issue in summary['issues'])
        assert accept(browser,summary).status_code==400


def test_receiving_javascript_match_gate_and_retry_controls():
    import subprocess
    from pathlib import Path
    root=Path(__file__).resolve().parents[1]
    result=subprocess.run(['node','tests/receiving_batch_ui_check.cjs'],cwd=root,capture_output=True,text=True)
    assert result.returncode==0,result.stdout+result.stderr
    assert 'BATCH_CAMERA_MATCH_ACCEPT_UI=PASS' in result.stdout


def test_rendered_receiving_form_is_folded_and_distribution_stays_visible():
    from html.parser import HTMLParser
    class Structure(HTMLParser):
        def __init__(self):
            super().__init__();self.details=[];self.direct_folded=False;self.smart_folded=None
        def handle_starttag(self,tag,attrs):
            a=dict(attrs)
            if tag=='details':self.details.append('open' not in a)
            if a.get('id')=='directIntakeForm':self.direct_folded=bool(self.details and self.details[-1])
        def handle_endtag(self,tag):
            if tag=='details' and self.details:self.details.pop()
        def handle_data(self,data):
            if 'SMART BATCH CARDS' in data:self.smart_folded=any(self.details)
    with TestClient(app) as browser:
        login(browser,'data.entry@tsco.local')
        page=browser.get('/intake?view=incoming')
        assert page.status_code==200
        parsed=Structure();parsed.feed(page.text);assert parsed.direct_folded
        page=browser.get('/intake?view=distribution');parsed=Structure();parsed.feed(page.text)
        assert page.status_code==200 and parsed.smart_folded is False
