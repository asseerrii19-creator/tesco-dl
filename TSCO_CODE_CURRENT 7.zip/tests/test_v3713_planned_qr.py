from io import BytesIO

from fastapi.testclient import TestClient
from pypdf import PdfReader
from sqlalchemy import create_engine, select
from sqlalchemy.orm import Session

from app.database import Base, SessionLocal
from app.main import app
from app.models import PlannedSample, Site, User
from app.services.planned_samples import ensure_planned_samples
from app.services.planned_sample_qr import planned_sample_url, validated_qr_return
from app.services.sampling_data_form import render_pdf_bytes, update_form_payload, _planned_qr
from test_v375_multi_data_form_custody import _base
from test_v3712_commercial_flow_batch import login


def four_samples(db):
    site, client, user, case, form = _base(db)
    update_form_payload(form, 1, client={"company_name":client.name},
        asset={"serial_number":"UAT-SEC-TR-004", "tag_number":"UAT-TAG-004", "voltage_rating_hv_lv":"115 / 13.8", "rated_power_mva":"20 / 25", "sap_number":"UAT-SAP-000004", "manufacturer_name":"WESCOSA", "manufacture_year":"2020", "country_of_manufacture":"Saudi Arabia", "substation":"Dammam West Substation", "location":"Dammam", "load_pct":"72", "oil_type":"Mineral insulating oil", "sealing_system":"Conservator with Bladder", "cooling_type":"Other", "cooling_type_other":"ONAN / ONAF", "oil_weight":"12.5 ton", "tap_changer_type":"On-load", "tap_changer_chamber":"Not Connected"},
        sampling={"test_priority":"Normal", "sampling_date_time":"11-Oct-2026 09:45"},
        samples=[{"sampling_from":"Bottom Tank"}] + [
            {"sampling_from":"Tap Changer", "sampling_detail":str(n)} for n in (1,2,3)],
        actor=user, confirm=True)
    from app.models import CommercialRequestLine
    db.add(CommercialRequestLine(commercial_case_id=case.id, line_number=1, quantity=4, requested_package="Routine Test", sample_indices_json="[1,2,3,4]", method_family="ASTM", priority="NORMAL", status="ACTIVE", created_by_id=user.id))
    db.flush()
    return case, form


def test_four_qr_samples_fit_single_a4_page_and_keep_identities(monkeypatch):
    monkeypatch.setenv("PUBLIC_BASE_URL", "https://tsco-v285-final-review.onrender.com")
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        case, form = four_samples(db)
        before = PdfReader(BytesIO(render_pdf_bytes(db, form, case)))
        assert len(before.pages) == 1 and not before.pages[0].get("/Annots")
        plans = ensure_planned_samples(db, case)
        identities = [(p.request_number, p.public_token, p.sampling_point) for p in plans]
        assert [p.sampling_point for p in plans] == ["Bottom Tank", "Tap Changer — 1", "Tap Changer — 2", "Tap Changer — 3"]
        raw = render_pdf_bytes(db, form, case)
        reader = PdfReader(BytesIO(raw))
        assert len(reader.pages) == 1
        assert len(reader.pages[0]["/Annots"]) == 4
        assert {a.get_object()["/A"]["/URI"] for a in reader.pages[0]["/Annots"]} == {planned_sample_url(p) for p in plans}
        assert abs(float(reader.pages[0].mediabox.width) - 595.276) < 0.1
        text = reader.pages[0].extract_text()
        for p in plans:
            assert p.request_number in text
            drawing = _planned_qr(p)
            assert abs(drawing.width - 18*72/25.4) < .01
            assert drawing.contents[0].value == planned_sample_url(p)
        assert "Container labels are not required" in text
        assert [(p.request_number, p.public_token, p.sampling_point) for p in ensure_planned_samples(db, case)] == identities


def test_qr_login_continuation_and_site_authorization():
    with TestClient(app) as browser:
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "DMM"))
            receiver = db.scalar(select(User).where(User.email == "data.entry@tsco.local"))
            from app.models import Client
            client = db.scalar(select(Client).where(Client.code == "SEC"))
            from app.models import CommercialCase
            from uuid import uuid4
            token = uuid4().hex
            case = CommercialCase(case_code="BC-QR-"+token, site_id=site.id, client_id=client.id, owner_id=receiver.id,
                                  current_stage="COMPLETE_HANDOVER", request_status="HANDOVER_COMPLETE", status="ACTIVE")
            db.add(case); db.flush()
            from app.models import CommercialRequestLine
            line=CommercialRequestLine(commercial_case_id=case.id,line_number=1,quantity=1,requested_package="Routine Test",status="ACTIVE")
            db.add(line);db.flush()
            plan = PlannedSample(commercial_request_line_id=line.id,commercial_case_id=case.id, site_id=site.id, client_id=client.id, sequence_no=1,
                form_sample_index=1, request_number="FS-QR-"+token, barcode_value="BC-QR-"+token,
                public_token=token, expected_serial_number="TR-QR", sampling_point="Bottom Tank", status="EXPECTED")
            db.add(plan); db.commit(); plan_id=plan.id
        path="/intake/p/"+token
        response=browser.get(path, follow_redirects=False)
        assert response.status_code == 303 and response.headers["location"] == "/login"
        response=browser.post("/login", data={"email":"data.entry@tsco.local", "password":"Demo123!"}, follow_redirects=False)
        assert response.headers["location"] == path
        response=browser.get(path, follow_redirects=False)
        assert response.headers["location"] == f"/intake?view=incoming&planned_id={plan_id}"
        page=browser.get(response.headers["location"])
        assert page.status_code == 200 and "FS-QR-"+token in page.text and "TR-QR" in page.text
        assert browser.get("/intake/p/missing-token",follow_redirects=False).status_code == 404
        with SessionLocal() as db:
            from datetime import datetime
            from app.models import SampleRequest, Asset
            from app.services.planned_samples import claim_planned_identity
            plan=db.get(PlannedSample,plan_id)
            assert plan.status == "EXPECTED" and not plan.sample_request_id
            asset=Asset(client_id=plan.client_id,asset_code="QR-"+token,serial_number="TR-QR")
            db.add(asset);db.flush()
            sample=SampleRequest(request_number=plan.request_number,public_token=plan.public_token,barcode_value=plan.barcode_value,
                site_id=plan.site_id,client_id=plan.client_id,asset_id=asset.id,commercial_case_id=plan.commercial_case_id,
                sample_date_time=datetime.utcnow(),sampling_point="Bottom Tank")
            db.add(sample);db.flush();claim_planned_identity(plan,sample);db.commit();sample_id=sample.id
        response=browser.get(path,follow_redirects=False)
        assert response.headers["location"] == f"/intake/{sample_id}?barcode_matched=1"
        with SessionLocal() as db:
            plan=db.get(PlannedSample,plan_id)
            assert plan.public_token == token
            plan.status="VOID";db.commit()
        assert browser.get(path,follow_redirects=False).status_code == 409
        with SessionLocal() as db:
            plan=db.get(PlannedSample,plan_id)
            plan.status="EXPECTED"
            other=Site(code="QRX",name="Other QR Site",laboratory_name="Other",active=True)
            db.add(other);db.flush();plan.site_id=other.id;db.commit()
        assert browser.get(path,follow_redirects=False).status_code == 404
        browser.post("/logout")
        login(browser,"client@sec.local")
        assert browser.get(path,follow_redirects=False).status_code == 403


def test_qr_return_rejects_external_redirects():
    for value in ("https://evil.example/", "//evil.example", "/intake/p/x?next=evil", "/intake/p/../logout", None):
        assert validated_qr_return(value) is None
    assert validated_qr_return("/intake/p/abc_-123") == "/intake/p/abc_-123"
