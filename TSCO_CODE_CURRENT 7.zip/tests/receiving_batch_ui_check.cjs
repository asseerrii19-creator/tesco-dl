const fs=require('fs'),vm=require('vm'),assert=require('assert');
class El{constructor(){this.hidden=false;this.disabled=false;this.checked=false;this.textContent='';this.value='';this.children=[];this.handlers={};this.files=[];}addEventListener(n,f){this.handlers[n]=f;}append(...n){this.children.push(...n);}replaceChildren(){this.children=[];}click(){this.clicked=true;}}
const ids=['receivingBatch','batchScanStatus','batchAcceptForm','batchAcceptButton','batchCamera','batchUpload','batchCameraButton','batchUploadButton','batchNewAsset','batchAssetReviewed','batchReviewToken','batchMatch','batchFacts','batchSampleRows','batchMatchCount','batchIssues','batchAssetDetails'];
const els=Object.fromEntries(ids.map(id=>[id,new El()]));els.batchMatch.hidden=true;
const physical=new El();els.batchAcceptForm.elements={physical_confirmed:physical};els.batchAcceptForm.reset=()=>{physical.checked=false;els.batchAssetReviewed.checked=false;};
const replies=[];let requests=0,redirect='';
class FD{constructor(form){this.items=form?[['review_token',els.batchReviewToken.value]]:[];}append(k,v){this.items.push([k,v]);}}
const sandbox={document:{getElementById:id=>els[id],createElement:()=>new El()},FormData:FD,
fetch:async()=>{requests++;const item=replies.shift();return {ok:item.ok!==false,headers:{get:()=> 'application/json'},json:async()=>item.data};},window:{location:{assign:u=>redirect=u}}};
vm.runInNewContext(fs.readFileSync('app/static/receiving-batch.js','utf8'),sandbox);
const summary=(n=4)=>({business_case:'BC-TEST',sales_order:'SO-TEST',transformer_serial:'TR-TEST',form_number:1,expected:4,matched:n,
 samples:Array.from({length:4},(_,i)=>({sample_id:`FS-${i+1}`,sampling_identity:i?'Tap Changer '+i:'Bottom Tank',matched:i<n,status:i<n?'Matched':'Missing QR'})),issues:[],new_serials:['TR-TEST'],asset_review:{manufacturer_name:'MFR'},can_accept:n===4,review_token:'review-1'});
async function scan(data,ok=true){replies.push({data,ok});els.batchUpload.files=[{name:'form.jpg'}];await els.batchUpload.handlers.change({target:els.batchUpload});}
(async()=>{
 els.batchCameraButton.handlers.click();assert(els.batchCamera.clicked);
 await scan(summary());assert.equal(els.batchMatchCount.textContent,'Matched 4/4');assert.equal(els.batchSampleRows.children.length,4);assert(els.batchAcceptButton.disabled);
 physical.checked=true;els.batchAcceptForm.handlers.change();assert(els.batchAcceptButton.disabled);
 els.batchAssetReviewed.checked=true;els.batchAcceptForm.handlers.change();assert(!els.batchAcceptButton.disabled);
 await scan(summary(3));physical.checked=true;els.batchAssetReviewed.checked=true;els.batchAcceptForm.handlers.change();assert(els.batchAcceptButton.disabled);assert(els.batchIssues.textContent.includes('FS-4'));
 await scan({error:'Unreadable photo'},false);assert(els.batchMatch.hidden&&els.batchAcceptButton.disabled);assert.equal(els.batchReviewToken.value,'');
 await scan(summary());physical.checked=true;els.batchAssetReviewed.checked=true;els.batchAcceptForm.handlers.change();
 replies.push({data:{received:4,next_url:'/intake?view=distribution&batch_received=4'}});await els.batchAcceptForm.handlers.submit({preventDefault(){}});assert.equal(redirect,'/intake?view=distribution&batch_received=4');
 console.log('BATCH_CAMERA_MATCH_ACCEPT_UI=PASS');
})().catch(e=>{console.error(e);process.exitCode=1;});
