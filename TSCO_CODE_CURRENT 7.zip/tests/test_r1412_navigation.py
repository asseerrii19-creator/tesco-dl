import json
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit
from fastapi.testclient import TestClient
from sqlalchemy import select
from app.main import app
from app.database import SessionLocal
from app.models import User,Role
from test_v3712_commercial_flow_batch import login

class Links(HTMLParser):
    def __init__(self):super().__init__();self.urls=set()
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='a' and a.get('href','').startswith('/') and not a['href'].startswith('//'):self.urls.add(a['href'].split('#')[0])
        if tag=='iframe' and a.get('src','').startswith('/'):self.urls.add(a['src'])


def test_visible_navigation_major_roles_and_new_roles():
    report=[];errors=[]
    with TestClient(app) as browser:
        with SessionLocal() as db:
            users=list(db.scalars(select(User).where(User.active.is_(True)).order_by(User.id)))
            representatives={u.role:u.email for u in users if u.site_id or u.role=='system_admin'}
            tech=next(u for u in users if u.email=='chemist@tsco.local')
            from app.security import hash_password
            for role in ['trainee','training_coordinator','safety_officer']:
                row=User(email=f'qa.{role}@tsco.local',full_name=f'QA {role}',role=role,site_id=tech.site_id,active=True,password_hash=hash_password('Demo123!'))
                db.add(row);representatives[role]=row.email
            db.commit()
        for role,email in representatives.items():
            browser.post('/logout');login(browser,email)
            root=browser.get('/');assert root.status_code==200,(role,root.status_code)
            parser=Links();parser.feed(root.text);pending=list(parser.urls);seen=set()
            while pending and len(seen)<180:
                url=pending.pop(0)
                if not url or url in seen or url in {'/logout'} or url.startswith(('/static/','/reset','/admin/reset','/api/')):continue
                seen.add(url)
                print('CRAWL',role,url,flush=True)
                response=browser.get(url,follow_redirects=False)
                report.append({'role':role,'path':url,'status':response.status_code})
                Path('../qa').mkdir(exist_ok=True);Path('../qa/route_crawl.json').write_text(json.dumps({'requests':report,'errors':errors},indent=2))
                if response.status_code in {404,500,403,422}:errors.append((role,url,response.status_code))
                if response.status_code in {301,302,303,307,308}:
                    target=response.headers.get('location','')
                    if target.startswith('/'):pending.append(target)
                if response.status_code==200 and response.headers.get('content-type','').startswith('text/html'):
                    more=Links();more.feed(response.text);pending.extend(sorted(more.urls-seen))
            if role=='trainee':
                assert browser.get('/lab/operations?section=quality').status_code==403
                assert browser.get('/api/lab-operations/data').status_code==403
                assert browser.get('/intake').status_code==403
    Path('../qa').mkdir(exist_ok=True)
    Path('../qa/route_crawl.json').write_text(json.dumps({'requests':report,'errors':errors},indent=2))
    assert not errors,errors
