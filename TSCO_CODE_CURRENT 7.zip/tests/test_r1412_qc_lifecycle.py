from copy import deepcopy
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
import base64
import pytest
from app.services.qc_lifecycle import register_lot, decide_lot, active_lot
from app.services.lab_operations import _server_qc_status, _analytical_qc_schedule_state


def setup_lot():
    tech=SimpleNamespace(id=18,role='lab_technician',full_name='Analyst')
    senior=SimpleNamespace(id=19,role='senior_chemist',full_name='Senior')
    payload={'batches':[{'id':'B1','samples':['S1'],'tests':[{'test':'Water Content KF @RT','method':'IEC 60814','station':'Water'}]}], 'testAssignments':[{'id':'A1','batch_id':'B1','workstation':'Water','primary_user_id':18,'mode':'SINGLE','revision':1}], 'qualifiedQcProfiles':[], 'qc':[], 'results':[]}
    now=datetime.now(timezone.utc)
    body={'batch_id':'B1','context_test':'Water Content KF @RT','equipment_ids':[69,70],'source_type':'INTERNAL','material':'Oil QC','lot_number':'LOT1','valid_from':(now-timedelta(days=1)).isoformat(),'valid_until':(now+timedelta(days=30)).isoformat(),'target':10,'lower_limit':9,'upper_limit':11,'qualification':'Independent establishment: reference runs with uncertainty assessed','evidence':{'name':'qualification.csv','data':'data:text/csv;base64,'+base64.b64encode(b'Run,Result\n1,10\n2,10.2\n3,9.9').decode()}}
    lot=register_lot(payload,body,tech,None,None)
    ctx={'group':'Water','test':body['context_test'],'method':'IEC 60814','workstation':'Water','batch_id':'B1'}
    return payload,lot,ctx,tech,senior,body


def test_pending_cannot_release_and_only_independent_senior_signs(monkeypatch):
    monkeypatch.setenv('APP_SECRET','test-secret-at-least-32-characters-long')
    p,l,c,t,s,_=setup_lot()
    assert active_lot(p,c,69) is None
    for actor in [t,SimpleNamespace(id=22,role='technical_manager',full_name='Manager'),SimpleNamespace(id=23,role='senior_chemist',senior_responsibility_domain='EQUIPMENT',full_name='Equipment Senior')]:
        with pytest.raises(PermissionError):decide_lot(p,l['id'],{'action':'ACTIVATE','signed':True,'reason':'Reviewed'},actor,None,None)
    with pytest.raises(ValueError):decide_lot(p,l['id'],{'action':'ACTIVATE','signed':False,'reason':'Reviewed'},s,None,None)
    decide_lot(p,l['id'],{'action':'ACTIVATE','signed':True,'reason':'Independent qualification and evidence reviewed'},s,None,None)
    assert active_lot(p,c,69) is l and active_lot(p,c,70) is l
    assert l['signature'] and l['approved_by_user_id']==19
    assert active_lot(p,{**c,'method':'ASTM D1533'},69) is None
    assert active_lot(p,{**c,'test':'Water Other'},69) is None
    assert active_lot(p,c,71) is None
    assert active_lot(p,c,69,datetime.now(timezone.utc)+timedelta(days=31)) is None


def test_water_two_runs_and_fail_blocks_and_lot_change_invalidates(monkeypatch):
    monkeypatch.setenv('APP_SECRET','test-secret-at-least-32-characters-long')
    p,l,c,t,s,b=setup_lot();decide_lot(p,l['id'],{'action':'ACTIVATE','signed':True,'reason':'Reviewed'},s,None,None)
    def run(n,v=10):
        q={'id':'QC'+str(n),'mode':'routine','test':'Water','context_test':c['test'],'method_name':c['method'],'workstation':'Water','batch_id':'B1','equipment_asset_id':69,'lot':l['id'],'result':v,'blind_entry':True,'source_file':'run.csv','source_data':'data:text/csv;base64,'+base64.b64encode(f'Result\n{v}'.encode()).decode(),'ts':datetime.now(timezone.utc).isoformat()}
        q['status'],_,_=_server_qc_status(p,q);p['qc'].append(q);return q
    assert not _analytical_qc_schedule_state(p,c,69)['ready']
    run(1);assert _analytical_qc_schedule_state(p,c,69)['reason']=='WATER_STARTUP_2'
    run(2);assert _analytical_qc_schedule_state(p,c,69)['ready']
    assert not _analytical_qc_schedule_state(p,c,70)['ready']
    run(3,20);assert not _analytical_qc_schedule_state(p,c,69)['ready']
    b['lot_number']='LOT2';new=register_lot(p,b,t,None,None);decide_lot(p,new['id'],{'action':'ACTIVATE','signed':True,'reason':'New lot established independently'},s,None,None)
    assert l['status']=='SUPERSEDED'
    assert not _analytical_qc_schedule_state(p,c,69)['ready']


def test_crm_and_limits_and_source_evidence_are_mandatory():
    p,l,c,t,s,b=setup_lot();b['lot_number']='LOT2';b['source_type']='EXTERNAL_CRM'
    with pytest.raises(ValueError,match='supplier'):register_lot(p,b,t,None,None)
    b['source_type']='INTERNAL';b['upper_limit']=float('nan')
    with pytest.raises(ValueError,match='Finite'):register_lot(p,b,t,None,None)


def test_water_startup_cannot_reuse_another_batch_day_evidence(monkeypatch):
    monkeypatch.setenv('APP_SECRET','test-secret-at-least-32-characters-long')
    p,l,c,t,s,b=setup_lot();decide_lot(p,l['id'],{'action':'ACTIVATE','signed':True,'reason':'Reviewed'},s,None,None)
    for n in range(2):
        p['qc'].append({'id':f'OTHER-{n}','test':'Water','context_test':c['test'],'method_name':c['method'],'workstation':c['workstation'],'equipment_asset_id':69,'batch_id':'OTHER','status':'PASS','qc_lot_id':l['id'],'lot_signature':l['signature'],'ts':datetime.now(timezone.utc).isoformat()})
    p['results'].append({'id':'OTHER-RESULT','batch':'OTHER','test':c['test'],'qc_context_test':c['test'],'qc_group':'Water','test_method':c['method'],'workstation':c['workstation'],'equipment_asset_id':69,'qc_lot_id':l['id'],'ts':datetime.now(timezone.utc).isoformat()})
    state=_analytical_qc_schedule_state(p,c,69)
    assert not state['ready'] and state['reason']=='WATER_STARTUP_1'


def test_supported_qc_run_files_derive_full_bdv_and_exact_pf():
    from app.services.qc_lifecycle import parse_run_value
    def source(text,**scope):return {'source_file':'run.csv','source_data':'data:text/csv;base64,'+base64.b64encode(text.encode()).decode(),**scope}
    row=source('Result1,Result2,Result3,Result4,Result5,Result6\n60,61,62,63,64,65',test='BDV',method_name='IEC 60156',context_test='Breakdown Voltage @2.5mm- AVG')
    assert parse_run_value(row)==62.5 and len(row['derived_run_set']['runs'])==6
    with pytest.raises(ValueError,match='complete 6-run'):parse_run_value(source('R1,R2,R3,R4,R5\n60,61,62,63,64',test='BDV',method_name='IEC 60156'))
    assert parse_run_value(source('PF25,PF100\n0.01,0.20',test='Power Factor',context_test='Power Factor @100 C'))==.20
    with pytest.raises(ValueError,match='Multiple instrument'):parse_run_value(source('R1,R2,R3,R4,R5\n60,61,62,63,64\n70,71,72,73,74',test='BDV',method_name='ASTM D1816'))
