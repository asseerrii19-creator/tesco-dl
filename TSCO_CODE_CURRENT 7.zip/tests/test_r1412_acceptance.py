import json
from copy import deepcopy
from datetime import datetime,timedelta
from uuid import uuid4
from fastapi.testclient import TestClient
from sqlalchemy import select,delete
from app.main import app
from app.database import SessionLocal
from app.models import User,Site,Asset,Client,SampleRequest,ControlledReport,CompetencyRecord,EmployeeDevelopmentRecord,AuditLog
from app.services.lab_operations import get_operations_state,save_operations_state,_analytical_candidate_available
from app.services.technical_review_assignments import ensure_review_assignment
from test_v3712_commercial_flow_batch import login


def test_r15_authorization_isolated_from_live_assignment_eligibility():
    with TestClient(app):
        with SessionLocal() as db:
            employee=db.scalar(select(User).where(User.email=='chemist@tsco.local'))
            db.execute(delete(CompetencyRecord).where(CompetencyRecord.user_id==employee.id))
            db.add(EmployeeDevelopmentRecord(site_id=employee.site_id,employee_id=employee.id,created_by_id=employee.id,kind='COMPETENCY',title='Isolated method authorization',status='AUTHORIZED',valid_until=datetime.utcnow()+timedelta(days=30),details_json=json.dumps({'test':'Water Content KF @RT','method':'IEC 60814','equipment_ids':[69]})))
            db.flush()
            now=datetime.utcnow()
            assert not _analytical_candidate_available(db,employee.site_id,employee,'Water',now,now+timedelta(days=1))
            assert db.scalar(select(CompetencyRecord).where(CompetencyRecord.user_id==employee.id)) is None
            db.rollback()


def test_controlled_http_return_and_retest_preserves_original_and_blocks_shortcut():
    with TestClient(app) as browser:
        with SessionLocal() as db:
            senior=db.scalar(select(User).where(User.email=='senior.technical@tsco.local'))
            analyst=db.scalar(select(User).where(User.email=='chemist@tsco.local'))
            site=db.get(Site,senior.site_id);client=db.scalar(select(Client).where(Client.code=='SEC'))
            asset=db.scalar(select(Asset).where(Asset.client_id==client.id))
            name='ACCEPTANCE-'+uuid4().hex[:10]
            sample=SampleRequest(request_number=name,barcode_value=name,public_token=uuid4().hex,site_id=site.id,client_id=client.id,asset_id=asset.id,status='TECHNICAL_REVIEW',sampling_point='Bottom Tank',sample_date_time=datetime.utcnow())
            db.add(sample);db.flush()
            assignment=ensure_review_assignment(db,sample);assert assignment
            assignment.primary_senior_id=senior.id
            report=ControlledReport(site_id=site.id,sample_request_id=sample.id,report_number='REPORT-'+name,status='TECHNICAL_REVIEW',qr_token=uuid4().hex)
            db.add(report);db.flush();rid=report.id;sid=sample.id
            state,payload=get_operations_state(db,site)
            batch={'id':'B-'+name,'samples':[name],'tests':[{'test':'Appearance','method':'ASTM D1524','station':'IFT / Color / Appearance'}]}
            original={'id':'ORIGINAL-'+name,'sample':name,'test':'Appearance','result':'Clear','batch':batch['id'],'ts':datetime.utcnow().isoformat(),'qc_group':'Appearance','qc_status':'RECORDED','workstation':'IFT / Color / Appearance','test_method':'ASTM D1524'}
            payload['batches'].append(batch);payload['results'].append(original)
            payload['testAssignments'].append({'id':'A-'+name,'batch_id':batch['id'],'workstation':'IFT / Color / Appearance','primary_user_id':analyst.id,'mode':'SINGLE','revision':1})
            site_id=site.id;analyst_id=analyst.id
            save_operations_state(db,state,payload,senior);db.commit()
        login(browser,'senior.technical@tsco.local')
        response=browser.post(f'/control/report/{rid}/review',data={'action':'RETURN','correction_test':'Appearance','recommendation':'Verify the original visual observation by a controlled repeat.','interpretation':'Repeat requested.'},follow_redirects=False)
        assert response.status_code==303,response.text
        with SessionLocal() as db:
            _,payload=get_operations_state(db,db.get(Site,site_id))
            retest=next(x for x in payload['retests'] if x['sample']==name)
            assert retest['status']=='Requested' and db.get(SampleRequest,sid).status=='TESTING'
            assert next(x for x in payload['results'] if x['id']==original['id'])==original
            assert db.scalar(select(AuditLog).where(AuditLog.action=='REPORT_SENIOR_RETURNED_FOR_CORRECTION',AuditLog.entity_id==str(rid)))
        # A request cannot be dismissed without a linked repeat result.
        login(browser,'chemist@tsco.local')
        state=browser.get('/api/lab-operations/data').json();incoming=state['db']
        next(x for x in incoming['retests'] if x['id']==retest['id'])['status']='Completed'
        blocked=browser.put('/api/lab-operations/data',json={'db':incoming,'clientRevision':state['revision']})
        assert blocked.status_code in {400,403},blocked.text
        state=browser.get('/api/lab-operations/data').json();incoming=state['db']
        incoming['results'].append({'id':'REPEAT-'+name,'sample':name,'test':'Appearance','result':'Clear & Bright','batch':batch['id'],'isRetest':True,'retest_id':retest['id']})
        next(x for x in incoming['retests'] if x['id']==retest['id'])['status']='Completed'
        received=browser.put('/api/lab-operations/data',json={'db':incoming,'clientRevision':state['revision']})
        assert received.status_code==200,received.text
        with SessionLocal() as db:
            _,payload=get_operations_state(db,db.get(Site,site_id))
            assert next(x for x in payload['results'] if x['id']==original['id'])==original
            final=next(x for x in payload['retests'] if x['id']==retest['id']);assert final['status']=='Completed' and final['completed_by']
            repeat=next(x for x in payload['results'] if x['id']=='REPEAT-'+name)
            assert repeat['recorded_by_user_id']==analyst_id and repeat['qc_status']=='RECORDED'


def test_retest_transition_cannot_escape_workstation_scope():
    import pytest
    from types import SimpleNamespace
    from app.services.lab_operations import blank_operations_db,scope_operations_payload,merge_scoped_operations_update
    user=SimpleNamespace(id=17,role='lab_technician',full_name='Assigned Analyst',site_id=1)
    payload=blank_operations_db(SimpleNamespace(id=1,code='DMM'))
    payload['batches']=[{'id':'B1','samples':['S1'],'tests':[{'test':'Water Content KF @RT','method':'IEC 60814','station':'Water'}]},{'id':'B2','samples':['S2'],'tests':[{'test':'Dissolved Gas Analysis','method':'IEC 60567','station':'DGA'}]}]
    payload['testAssignments']=[{'id':'A1','batch_id':'B1','workstation':'Water','primary_user_id':17,'mode':'SINGLE','revision':1}]
    payload['retests']=[{'id':'HIDDEN','sample':'S2','batch':'B2','test':'Dissolved Gas Analysis','status':'Requested','reason':'Senior review'}]
    incoming=scope_operations_payload(payload,user);assert not incoming['retests']
    incoming['retests'].append(dict(payload['retests'][0],status='Completed'))
    with pytest.raises(PermissionError,match='outside the assigned'):merge_scoped_operations_update(payload,incoming,user)
