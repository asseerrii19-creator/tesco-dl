from copy import deepcopy
import json
from fastapi.testclient import TestClient
from sqlalchemy import select
from app.main import app
from app.database import SessionLocal
from app.models import User,Site,EquipmentAsset
from app.services.lab_operations import get_operations_state,save_operations_state,_analytical_qc_schedule_state,_server_qc_status
from test_r1412_qc_lifecycle import setup_lot
from test_v3712_commercial_flow_batch import login


def test_exact_water_lot_http_registration_senior_activation_and_dual_startup():
    with TestClient(app) as browser:
        with SessionLocal() as db:
            tech=db.scalar(select(User).where(User.email=='chemist@tsco.local'));site=db.get(Site,tech.site_id)
            senior=db.scalar(select(User).where(User.email=='senior.technical@tsco.local'))
            state,payload=get_operations_state(db,site)
            fixture,_,ctx,_,_,body=setup_lot();fixture['qualifiedQcProfiles']=[]
            fixture['testAssignments'][0]['primary_user_id']=tech.id
            ids=[]
            for code in ['EQ-69','EQ-70']:
                eq=db.scalar(select(EquipmentAsset).where(EquipmentAsset.site_id==site.id,EquipmentAsset.equipment_id==code));assert eq
                eq.test_method='IEC 60814';eq.workstation='Water / BDV / PF / Room Conditions';eq.status='IN_SERVICE';eq.next_calibration_at=None;eq.next_verification_at=None
                ids.append(eq.id)
            payload.update({k:fixture[k] for k in ['batches','testAssignments','qualifiedQcProfiles','qc','results']})
            save_operations_state(db,state,payload,tech);db.commit();revision=state.revision;site_id=site.id;senior_id=senior.id
        login(browser,'chemist@tsco.local')
        assert browser.get('/lab/operations?section=quality').status_code==200
        body.update(equipment_ids=ids,revision=revision)
        response=browser.post('/lab-operations/qc-lots',json=body);assert response.status_code==200,response.text
        lot_id=response.json()['id'];revision=response.json()['revision']
        decision={'action':'ACTIVATE','signed':True,'reason':'Qualification, limits, scope and evidence independently reviewed','revision':revision}
        assert browser.post(f'/lab-operations/qc-lots/{lot_id}/decision',json=decision).status_code==403
        browser.post('/logout');login(browser,'senior.technical@tsco.local')
        assert browser.get('/lab/operations?section=quality').status_code==200
        response=browser.post(f'/lab-operations/qc-lots/{lot_id}/decision',json=decision);assert response.status_code==200,response.text
        browser.post('/logout');login(browser,'chemist@tsco.local')
        with SessionLocal() as db:
            state,payload=get_operations_state(db,db.get(Site,site_id));lot=next(x for x in payload['qualifiedQcProfiles'] if x['id']==lot_id)
            assert lot['approved_by_user_id']==senior_id and lot['signature']
            import base64
            from datetime import datetime,timezone
            for eq_id in ids:
                for run in range(2):
                    q={'id':f'HTTPQC-{eq_id}-{run}','mode':'routine','test':'Water','context_test':ctx['test'],'method_name':ctx['method'],'workstation':ctx['workstation'],'batch_id':'B1','equipment_asset_id':eq_id,'lot':lot_id,'result':10,'blind_entry':True,'source_file':'run.csv','source_data':'data:text/csv;base64,'+base64.b64encode(b'Result\n10').decode(),'ts':datetime.now(timezone.utc).isoformat()}
                    state_data=browser.get('/api/lab-operations/data').json();incoming=state_data['db'];incoming['qc'].append(q)
                    saved=browser.put('/api/lab-operations/data',json={'db':incoming,'clientRevision':state_data['revision']});assert saved.status_code==200,saved.text
                    accepted=next(x for x in saved.json()['db']['qc'] if x['id']==q['id']);assert accepted['status']=='PASS'
                    payload['qc'].append(accepted)
                assert _analytical_qc_schedule_state(payload,ctx,eq_id)['ready']
            # The authoritative result-confirmation gate resolves both exact instruments,
            # then stamps the immutable approved lot and source evidence onto the result.
            import pytest
            from app.services.lab_operations import _bind_required_qc_to_result
            db.expire_all()
            state,payload=get_operations_state(db,db.get(Site,site_id))
            analyst=db.scalar(select(User).where(User.email=='chemist@tsco.local'))
            row={'id':'WATER-RESULT','test':ctx['test'],'sample':'S1','equipment_asset_id':ids[0]}
            _bind_required_qc_to_result(payload,payload['batches'][0],row,analyst,db,site_id)
            assert row['qc_status']=='PASS' and row['qc_lot_id']==lot_id and row['qc_lot_signature']==lot['signature']
            missing_second=deepcopy(payload);missing_second['qc']=[q for q in payload['qc'] if q['equipment_asset_id']!=ids[1]]
            with pytest.raises(PermissionError):_bind_required_qc_to_result(missing_second,missing_second['batches'][0],dict(row,id='BLOCKED'),analyst,db,site_id)
