from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import User


def login(client: TestClient, email: str) -> None:
    r = client.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303


def test_operations_page_forces_server_first_bootstrap_and_hides_additives_by_default():
    with TestClient(app) as client:
        login(client, 'chemist@tsco.local')
        page = client.get('/lab/operations?section=workstations')
        assert page.status_code == 200
        html = page.text
        assert 'const online=await cloudLoad(true);' in html
        assert "if((STORAGE.dirty||STORAGE.saving)&&!force)return false;" in html
        assert 'id="additiveHead" style="display:none"' in html
        assert "(DB.testAssignments||[]).forEach(a=>{if(assignmentAllowsUser(a)&&a.workstation)out.add(canonicalWs(a.workstation))})" in html


def test_scoped_payload_includes_current_global_bench_assignment_for_user():
    with TestClient(app) as client:
        login(client, 'chemist@tsco.local')
        response = client.get('/api/lab-operations/data')
        assert response.status_code == 200
        data = response.json()['db']
        with SessionLocal() as db:
            chemist_id = db.scalar(select(User.id).where(User.email == 'chemist@tsco.local'))
        global_rows = [
            a for a in data.get('testAssignments', [])
            if str(a.get('batch_id')) == '*'
            and chemist_id in {int(a.get('primary_user_id') or 0), int(a.get('backup_user_id') or 0)}
        ]
        assert global_rows, data.get('testAssignments', [])
        assert all(a.get('workstation') != 'Additives / Special Tests' for a in global_rows)
