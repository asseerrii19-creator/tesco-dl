from __future__ import annotations

import calendar
import json
import math
import re
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from uuid import uuid4
from pathlib import Path
from functools import lru_cache
from typing import Any

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..models import Client, CommercialCase, OperationsState, Role, SampleRequest, SampleStatus, Site, TestPackageConfig, User, CompetencyRecord, StaffAvailability, StaffWorkPattern, EquipmentAsset, NightShiftMonthPlan

BASE_DIR = Path(__file__).resolve().parents[1]
PACKAGE_FILE = BASE_DIR / "data" / "lab_packages.json"
LAB_TEMPLATE_FILE = BASE_DIR / "lab_ops" / "index_template.html"


@lru_cache(maxsize=1)
def _embedded_qc_config() -> dict[str, Any]:
    """Load the source-controlled QC rules/profiles used by the browser so the server can independently verify QC status."""
    try:
        text = LAB_TEMPLATE_FILE.read_text(encoding="utf-8")
        start = text.index("const CFG=") + len("const CFG=")
        end = text.index(";\n", start)
        cfg = json.loads(text[start:end])
        return {"qcRules": cfg.get("qcRules", {}), "qcProfiles": cfg.get("qcProfiles", [])}
    except Exception:
        return {"qcRules": {}, "qcProfiles": []}


def package_catalog(db: Session | None = None, site_id: int | None = None) -> list[dict[str, Any]]:
    try:
        base = json.loads(PACKAGE_FILE.read_text(encoding="utf-8"))["packages"]
    except Exception:
        base = []
    if db is None:
        return base
    stmt = select(TestPackageConfig).where(TestPackageConfig.active.is_(True))
    if site_id is not None:
        stmt = stmt.where((TestPackageConfig.site_id.is_(None)) | (TestPackageConfig.site_id == site_id))
    rows = db.scalars(stmt.order_by(TestPackageConfig.name)).all()
    dynamic = []
    for row in rows:
        try:
            tests = json.loads(row.tests_json or "[]")
        except Exception:
            tests = []
        tests = [_normalize_package_test(item) for item in tests if isinstance(item, dict)] if isinstance(tests, list) else []
        dynamic.append({
            "id": row.code, "name": row.name, "scope": row.scope, "kind": "configured",
            "site_id": row.site_id, "tests": tests,
        })
    # Once a database session is available, PostgreSQL/SQL is the sole runtime master source.
    # lab_packages.json is bootstrap seed material only; it is not merged over central configuration.
    return dynamic


def ensure_baseline_test_packages(db: Session) -> None:
    """Seed built-in package definitions once into central SQL master data.

    Existing rows (including rows an administrator disabled) are never overwritten/re-enabled.
    """
    try:
        base = json.loads(PACKAGE_FILE.read_text(encoding="utf-8")).get("packages", [])
    except Exception:
        base = []
    for package in base:
        code = str(package.get("id") or "").strip().upper()
        name = str(package.get("name") or "").strip()
        if not code or not name:
            continue
        if db.scalar(select(TestPackageConfig.id).where(TestPackageConfig.code == code)) is not None:
            continue
        tests = package.get("tests") if isinstance(package.get("tests"), list) else []
        tests = [_normalize_package_test(item) for item in tests if isinstance(item, dict)]
        db.add(TestPackageConfig(
            code=code[:80],
            name=name[:160],
            scope=str(package.get("scope") or "GENERAL").strip().upper()[:80],
            tests_json=json.dumps(tests, ensure_ascii=False),
            active=True,
        ))
    db.flush()


QUALITY_ROUTINE_TASKS = (
    # Gas Supplies and the Gas Cylinder daily-record responsibility share the same
    # Primary/Backup pair for each period, matching the controlled paper distribution.
    {"key": "gas_supplies", "group": "gas_control", "name": "Gas Supplies Check", "domain": "Materials, Gases & Storage", "frequency": "period"},
    {"key": "gas_cylinder", "group": "gas_control", "name": "Gas Cylinder Status / Daily Record", "domain": "Materials, Gases & Storage", "frequency": "period"},
    {"key": "balances", "group": "balances", "name": "Balances Check", "domain": "Equipment & Safety", "frequency": "period"},
    {"key": "electrode", "group": "electrode", "name": "Electrode Check", "domain": "Equipment & Safety", "frequency": "period"},
    {"key": "chemical_inventory", "group": "chemical_inventory", "name": "Chemical Inventory Check", "domain": "Materials, Gases & Storage", "frequency": "period"},
    {"key": "sample_storage", "group": "sample_storage", "name": "Sample Storage Check", "domain": "Materials, Gases & Storage", "frequency": "period"},
    {"key": "shower_eye_wash", "group": "shower_eye_wash", "name": "Shower & Eye Wash Check", "domain": "Equipment & Safety", "frequency": "monthly"},
)


def _quality_staff_initials(name: str) -> str:
    words = [part for part in str(name or "").replace("-", " ").split() if part]
    return "".join(part[0].upper() for part in words[:4]) or "—"


def _quality_periods(year: int, month: int) -> list[dict[str, Any]]:
    last = calendar.monthrange(year, month)[1]
    return [
        {"key": "W1", "label": "Week 1 • 1–11", "start_day": 1, "end_day": min(11, last)},
        {"key": "W2", "label": "Week 2 • 12–18", "start_day": min(12, last), "end_day": min(18, last)},
        {"key": "W3", "label": "Week 3 • 19–25", "start_day": min(19, last), "end_day": min(25, last)},
        {"key": "W4", "label": f"Week 4 • 26–{last}", "start_day": min(26, last), "end_day": last},
    ]


def _monthly_analytical_ownership(
    eligible: list[User], equipment: list[EquipmentAsset], *, when: datetime,
    db: Session | None = None, site_id: int | None = None,
) -> list[dict[str, Any]]:
    """Assign exact analytical assets without silently overloading technicians.

    A technician can own at most one analytical instrument as Primary and at most one
    analytical instrument as Backup in a calendar month. When competent/available
    coverage is exhausted, the asset stays visible as COVERAGE_REQUIRED.
    """
    if not equipment:
        return []
    month_start = datetime(when.year, when.month, 1)
    month_end = datetime(when.year, when.month, calendar.monthrange(when.year, when.month)[1], 23, 59, 59)

    def available(person: User) -> bool:
        if db is None or site_id is None or person.id is None:
            return True
        conflict = db.query(StaffAvailability).filter(
            StaffAvailability.site_id == site_id,
            StaffAvailability.user_id == person.id,
            StaffAvailability.entry_type.in_(["LEAVE", "HOLIDAY", "TRAINING", "UNAVAILABLE"]),
            StaffAvailability.status.in_(["APPROVED", "CONFIRMED", "APPROVED_FOR_ANNUAL_PLAN"]),
            StaffAvailability.start_at <= month_end,
            StaffAvailability.end_at >= month_start,
        ).first()
        if conflict:
            return False
        pattern = db.query(StaffWorkPattern).filter(
            StaffWorkPattern.site_id == site_id,
            StaffWorkPattern.user_id == person.id,
            StaffWorkPattern.active.is_(True),
        ).first()
        if pattern and (pattern.effective_from is None or pattern.effective_from <= month_end) and (pattern.effective_to is None or pattern.effective_to >= month_start):
            try:
                days = {int(x) for x in json.loads(pattern.weekdays_json or "[]")}
            except (TypeError, ValueError, json.JSONDecodeError):
                days = set()
            if pattern.weekdays_json and not days:
                return False
        return True

    base = [p for p in eligible if available(p)]
    month_index = when.year * 12 + when.month - 1
    if base:
        shift = month_index % len(base)
        base = base[shift:] + base[:shift]

    used_primary: set[int] = set()
    used_backup: set[int] = set()
    rows: list[dict[str, Any]] = []
    assets = sorted(
        [e for e in equipment if getattr(e, 'active', True) and str(getattr(e, 'status', '') or 'IN_SERVICE').upper() == 'IN_SERVICE' and str(getattr(e, 'workstation', '') or '').strip()],
        key=lambda e: str(getattr(e, 'equipment_id', '') or ''),
    )

    for eq in assets:
        primary_pool = list(base)
        backup_pool = list(base)
        if db is not None and site_id is not None:
            now_dt = when
            auth_rows = db.query(CompetencyRecord).filter(
                CompetencyRecord.site_id == site_id,
                CompetencyRecord.workstation == eq.workstation,
                CompetencyRecord.active.is_(True),
                CompetencyRecord.user_id.in_([p.id for p in base if p.id is not None]),
                CompetencyRecord.authorization.in_(["INDEPENDENT", "SUPERVISED"]),
            ).all()
            valid = [r for r in auth_rows if r.expires_at is None or r.expires_at >= now_dt]
            independent_ids = {r.user_id for r in valid if r.authorization == "INDEPENDENT"}
            authorized_ids = {r.user_id for r in valid}
            primary_pool = [p for p in base if p.id in independent_ids]
            backup_pool = [p for p in base if p.id in authorized_ids]

        primary = next((p for p in primary_pool if p.id is not None and int(p.id) not in used_primary), None)
        backup = next((p for p in backup_pool if p.id is not None and p.id != getattr(primary, 'id', None) and int(p.id) not in used_backup), None)
        if primary and primary.id is not None:
            used_primary.add(int(primary.id))
        if backup and backup.id is not None:
            used_backup.add(int(backup.id))
        missing=[]
        if not primary: missing.append('PRIMARY')
        if not backup: missing.append('BACKUP')
        rows.append({
            "id": f"QEQ-{when.strftime('%Y-%m')}-{eq.equipment_id}",
            "equipment_asset_id": eq.id,
            "equipment_id": eq.equipment_id,
            "equipment_name": eq.name,
            "workstation": eq.workstation,
            "test_method": eq.test_method,
            "primary_user_id": primary.id if primary else None,
            "primary_name": primary.full_name if primary else "",
            "primary_initials": _quality_staff_initials(primary.full_name) if primary else "—",
            "backup_user_id": backup.id if backup else None,
            "backup_name": backup.full_name if backup else "",
            "backup_initials": _quality_staff_initials(backup.full_name) if backup else "—",
            "status": "ACTIVE" if not missing else "COVERAGE_REQUIRED",
            "coverage_missing": missing,
        })
    return rows


def _quality_period_bounds(when: datetime, period: dict[str, Any]) -> tuple[datetime, datetime]:
    start = datetime(when.year, when.month, int(period.get("start_day") or 1), 0, 0, 0)
    end = datetime(when.year, when.month, int(period.get("end_day") or 1), 23, 59, 59)
    return start, end


def _quality_person_available(
    db: Session | None, site_id: int | None, person: User, start: datetime, end: datetime,
) -> bool:
    """True when the employee has at least one workable day in the QC window.

    A configured Work Pattern is honored. If none exists yet, the controlled fallback is the
    site standard Sunday–Thursday pattern so the QC plan remains usable while configuration is
    being completed. Approved leave/holiday/training/unavailability removes the affected day.
    """
    if db is None or site_id is None or person.id is None:
        return True
    pattern = db.query(StaffWorkPattern).filter(
        StaffWorkPattern.site_id == site_id, StaffWorkPattern.user_id == person.id,
        StaffWorkPattern.active.is_(True),
    ).first()
    if pattern:
        try:
            workdays = {int(x) for x in json.loads(pattern.weekdays_json or "[]")}
        except Exception:
            workdays = set()
        if not workdays:
            return False
    else:
        # Python weekday: Mon=0 ... Sun=6. Site-standard fallback = Sun–Thu.
        workdays = {6, 0, 1, 2, 3}
    day = start.replace(hour=12, minute=0, second=0, microsecond=0)
    while day.date() <= end.date():
        if day.weekday() in workdays:
            if pattern and pattern.effective_from and day < pattern.effective_from.replace(hour=0, minute=0, second=0):
                day += timedelta(days=1); continue
            if pattern and pattern.effective_to and day > pattern.effective_to.replace(hour=23, minute=59, second=59):
                day += timedelta(days=1); continue
            ds = day.replace(hour=0, minute=0, second=0)
            de = day.replace(hour=23, minute=59, second=59)
            conflict = db.query(StaffAvailability).filter(
                StaffAvailability.site_id == site_id, StaffAvailability.user_id == person.id,
                StaffAvailability.entry_type.in_(["LEAVE", "HOLIDAY", "TRAINING", "UNAVAILABLE"]),
                StaffAvailability.status.in_(["APPROVED", "CONFIRMED", "APPROVED_FOR_ANNUAL_PLAN", "MANAGER_APPROVED"]),
                StaffAvailability.start_at <= de, StaffAvailability.end_at >= ds,
            ).first()
            if not conflict:
                return True
        day += timedelta(days=1)
    return False


def _quality_competency_ok(
    db: Session | None, site_id: int | None, person: User, workstation: str, when: datetime, *, primary: bool,
) -> bool:
    if db is None or site_id is None or person.id is None or not str(workstation or "").strip():
        return True
    configured = db.query(CompetencyRecord).filter(
        CompetencyRecord.site_id == site_id, CompetencyRecord.workstation == workstation,
        CompetencyRecord.active.is_(True),
    ).count()
    if not configured:
        return True
    allowed = ["INDEPENDENT"] if primary else ["INDEPENDENT", "SUPERVISED"]
    row = db.query(CompetencyRecord).filter(
        CompetencyRecord.site_id == site_id, CompetencyRecord.user_id == person.id,
        CompetencyRecord.workstation == workstation, CompetencyRecord.active.is_(True),
        CompetencyRecord.authorization.in_(allowed),
    ).order_by(CompetencyRecord.created_at.desc()).first()
    return bool(row and (row.expires_at is None or row.expires_at >= when))


def _quality_routine_items(periods: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Build one controlled routine assignment per responsibility per week.

    Gas Supplies and Gas Cylinder records deliberately stay one weekly responsibility because
    they share the same controlled Primary/Backup owner in the approved paper workflow.
    """
    groups: dict[str, list[dict[str, Any]]] = {}
    for task in QUALITY_ROUTINE_TASKS:
        groups.setdefault(str(task["group"]), []).append(task)
    rows: list[dict[str, Any]] = []
    for group, tasks in groups.items():
        monthly = all(str(t.get("frequency")) == "monthly" for t in tasks)
        target_periods = [periods[-1]] if monthly else periods
        task_name = " + ".join(str(t["name"]) for t in tasks)
        domain = str(tasks[0]["domain"])
        task_key = group if len(tasks) > 1 else str(tasks[0]["key"])
        for period in target_periods:
            rows.append({
                "kind": "ROUTINE", "task_key": task_key, "task_keys": [str(t["key"]) for t in tasks],
                "task_group": group, "task": task_name, "domain": domain,
                "frequency": "monthly" if monthly else "period", "period": period,
            })
    return rows


def _routine_asset_candidates(task_key: str, equipment: list[EquipmentAsset]) -> list[EquipmentAsset]:
    key = str(task_key or "").lower()
    if key == "balances":
        terms = ("balance", "weigh")
    elif key == "electrode":
        terms = ("electrode", "titrator")
    elif key == "shower_eye_wash":
        terms = ("shower", "eye wash", "eyewash")
    else:
        return []
    return [e for e in equipment if getattr(e, "active", True) and str(getattr(e, "status", "") or "IN_SERVICE").upper() == "IN_SERVICE" and any(t in f"{getattr(e,'name','')} {getattr(e,'workstation','')}".lower() for t in terms)]


def ensure_monthly_quality_distribution(
    payload: dict[str, Any], staff: list[User], *, when: datetime | None = None,
    equipment: list[EquipmentAsset] | None = None, db: Session | None = None,
    site_id: int | None = None,
) -> dict[str, Any] | None:
    """Publish the approved weekly QC rotation for one calendar month.

    Final model: one actionable Primary QC responsibility per employee per week by default,
    exact equipment ID when the task is asset-specific, a distinct standby Backup, and
    availability/Work Pattern/competency gates. Analytical/Test QC before a sample result remains
    a separate control and is not represented by this recurring equipment/routine rotation.
    """
    payload.setdefault("qualityDistributions", [])
    payload.setdefault("qualityTaskEvents", [])
    now = when or datetime.utcnow()
    month_key = now.strftime("%Y-%m")
    existing = [row for row in payload["qualityDistributions"] if str(row.get("month")) == month_key]
    eligible = sorted(
        [row for row in staff if row.active and row.role == Role.LAB_TECHNICIAN.value],
        key=lambda row: (row.full_name.lower(), row.id or 0),
    )
    if not eligible:
        return max(existing, key=lambda row: int(row.get("revision") or 1)) if existing else None

    equipment_rows = sorted([
        e for e in (equipment or []) if getattr(e, "active", True) and str(getattr(e, "status", "") or "IN_SERVICE").upper() == "IN_SERVICE"
    ], key=lambda e: str(getattr(e, "equipment_id", "") or ""))
    expected_asset_ids = {str(e.equipment_id) for e in equipment_rows if str(getattr(e, "workstation", "") or "").strip()}
    revision = 1
    if existing:
        latest = max(existing, key=lambda row: int(row.get("revision") or 1))
        latest_asset_ids = {str(a.get("equipment_id") or "") for a in latest.get("analytical_ownership", []) if a.get("equipment_id")}
        valid_model = str(latest.get("ownership_model") or "") == "WEEKLY_ROTATION_PRIMARY_BACKUP_V3"
        valid_people = {int(p.id) for p in eligible if p.id is not None}
        assignments = latest.get("assignments", []) if isinstance(latest, dict) else []
        valid_assignments = all(
            (not a.get("primary_user_id") or int(a.get("primary_user_id")) in valid_people)
            and (not a.get("backup_user_id") or int(a.get("backup_user_id")) in valid_people)
            for a in assignments if isinstance(a, dict)
        )
        if valid_model and valid_assignments and latest_asset_ids == expected_asset_ids:
            return latest
        revision = max(int(row.get("revision") or 1) for row in existing) + 1

    periods = _quality_periods(now.year, now.month)
    period_load = {p["key"]: 0 for p in periods}
    work_items = _quality_routine_items(periods)
    for item in work_items:
        period_load[item["period"]["key"]] += 1

    # Exact analytical assets are spread evenly across weeks before employee selection.
    for eq in [e for e in equipment_rows if str(getattr(e, "workstation", "") or "").strip()]:
        period = min(periods, key=lambda p: (period_load[p["key"]], p["start_day"]))
        period_load[period["key"]] += 1
        work_items.append({
            "kind": "EQUIPMENT", "task_key": f"equipment:{eq.equipment_id}", "task_keys": [f"equipment:{eq.equipment_id}"],
            "task_group": "analytical_equipment", "task": f"Equipment QC · {eq.equipment_id} · {eq.name}",
            "domain": "Analytical Equipment QC", "frequency": "period", "period": period,
            "equipment_asset_id": eq.id, "equipment_id": eq.equipment_id, "equipment_name": eq.name,
            "workstation": eq.workstation, "test_method": eq.test_method,
        })

    # Where Equipment Master contains exact Balance/Electrode/Shower assets, bind the weekly
    # routine to a verified ID instead of making the employee choose an arbitrary asset later.
    category_cursor: dict[str, int] = {}
    for item in work_items:
        if item["kind"] != "ROUTINE":
            continue
        matches = _routine_asset_candidates(item["task_key"], equipment_rows)
        if matches:
            idx = category_cursor.get(item["task_key"], 0) % len(matches)
            eq = matches[idx]; category_cursor[item["task_key"]] = idx + 1
            item.update({"equipment_asset_id": eq.id, "equipment_id": eq.equipment_id, "equipment_name": eq.name, "workstation": eq.workstation, "test_method": eq.test_method})

    # Stable ordering: weekly responsibility first, then exact analytical equipment.
    work_items.sort(key=lambda x: (int(x["period"]["start_day"]), 0 if x["kind"] == "ROUTINE" else 1, str(x.get("task_key") or "")))
    primary_used: dict[str, set[int]] = {p["key"]: set() for p in periods}
    backup_counts: dict[tuple[str, int], int] = {}
    month_primary_counts = {int(p.id): 0 for p in eligible if p.id is not None}
    assignments: list[dict[str, Any]] = []

    for item in work_items:
        period = item["period"]
        p_start, p_end = _quality_period_bounds(now, period)
        workstation = str(item.get("workstation") or "")
        available_primary = [p for p in eligible if p.id is not None and int(p.id) not in primary_used[period["key"]] and _quality_person_available(db, site_id, p, p_start, p_end) and _quality_competency_ok(db, site_id, p, workstation, p_start, primary=True)]
        available_primary.sort(key=lambda p: (month_primary_counts.get(int(p.id), 0), p.full_name.lower()))
        primary = available_primary[0] if available_primary else None
        if primary and primary.id is not None:
            primary_used[period["key"]].add(int(primary.id)); month_primary_counts[int(primary.id)] = month_primary_counts.get(int(primary.id), 0) + 1
        available_backup = [p for p in eligible if p.id is not None and p.id != getattr(primary, "id", None) and _quality_person_available(db, site_id, p, p_start, p_end) and _quality_competency_ok(db, site_id, p, workstation, p_start, primary=False)]
        available_backup.sort(key=lambda p: (1 if int(p.id) in primary_used[period["key"]] else 0, backup_counts.get((period["key"], int(p.id)), 0), month_primary_counts.get(int(p.id), 0), p.full_name.lower()))
        backup = available_backup[0] if available_backup else None
        if backup and backup.id is not None:
            backup_counts[(period["key"], int(backup.id))] = backup_counts.get((period["key"], int(backup.id)), 0) + 1
        missing = []
        if not primary: missing.append("PRIMARY")
        if not backup: missing.append("BACKUP")
        if item["kind"] == "ROUTINE" and item["task_key"] in {"balances", "electrode"} and not item.get("equipment_asset_id"):
            missing.append("EQUIPMENT_MAPPING")
        row = {
            "id": f"QTA-{month_key}-{item['task_key'].replace(':','-')}-{period['key']}",
            "kind": item["kind"], "task_key": item["task_key"], "task_keys": item.get("task_keys", [item["task_key"]]),
            "task_group": item["task_group"], "task": item["task"], "domain": item["domain"],
            "frequency": item["frequency"], "period": period["key"], "period_label": period["label"],
            "start_day": period["start_day"], "end_day": period["end_day"],
            "primary_user_id": primary.id if primary else None, "primary_name": primary.full_name if primary else "",
            "primary_initials": _quality_staff_initials(primary.full_name) if primary else "—",
            "backup_user_id": backup.id if backup else None, "backup_name": backup.full_name if backup else "",
            "backup_initials": _quality_staff_initials(backup.full_name) if backup else "—",
            "active_user_id": primary.id if primary else None, "active_role": "PRIMARY" if primary else "UNASSIGNED",
            "status": "ACTIVE" if not missing else "COVERAGE_REQUIRED", "coverage_missing": missing,
        }
        for field in ("equipment_asset_id", "equipment_id", "equipment_name", "workstation", "test_method"):
            if item.get(field) not in (None, ""):
                row[field] = item[field]
        assignments.append(row)

    analytical = [dict(a) for a in assignments if a.get("kind") == "EQUIPMENT"]
    routine_owners = [dict(a) for a in assignments if a.get("kind") == "ROUTINE"]
    distribution = {
        "id": f"QDIST-{month_key}-R{revision}", "month": month_key, "revision": revision,
        "status": "PUBLISHED", "rotation": "AUTO_WEEKLY_PRIMARY_BACKUP",
        "ownership_model": "WEEKLY_ROTATION_PRIMARY_BACKUP_V3",
        "generated_at": now.isoformat(), "generated_by": "System Weekly Rotation",
        "period_model": "Weekly Primary action + standby Backup; max one active Primary QC responsibility per employee per week by default",
        "routine_owners": routine_owners, "analytical_ownership": analytical, "assignments": assignments,
    }
    payload["qualityDistributions"].append(distribution)
    return distribution

def blank_operations_db(site: Site) -> dict[str, Any]:
    now = datetime.utcnow().isoformat()
    return {
        "batches": [], "results": [], "qc": [], "qualifiedQcProfiles": [], "reports": [],
        "retained": [], "retests": [], "storageAssignments": [], "batchHistory": [],
        "cancelledSamples": [], "supervisorNotes": [], "standards": [], "dgaAttachments": [], "resultEvidence": [],
        "qualityDistributions": [], "qualityTaskEvents": [], "testAssignments": [], "assignmentCompletions": [],
        "clients": [], "customPackages": [], "formulaDefinitions": [], "calculationDrafts": {},
        "staff": [], "samplePoints": ["Main Tank / Bottom", "Tap Changer 1", "Tap Changer 2", "Tap Changer 3", "Tap Changer H1", "Tap Changer H2", "Tap Changer H3", "Cable Box H1", "Cable Box H2", "Cable Box H3", "Cable Box Y", "Cable Box R", "Cable Box N", "Cable Box B", "Other"],
        "testUnits": {}, "drafts": {},
        "settings": {
            "labCode": "DM" if site.code == "DMM" else site.code,
            "yearCode": datetime.utcnow().strftime("%y"), "prefixPadding": "00",
            "normalRetentionDays": 15, "urgentRetentionDays": 15,
            "currentSite": site.code, "enabledSites": [site.code],
            "qcProfileSelections": {}, "activeSeniorChemist": "",
        },
        "meta": {"schema": 4, "site": site.code, "revision": 0, "updatedAt": now, "platformIntegrated": True},
    }


def get_operations_state(db: Session, site: Site) -> tuple[OperationsState, dict[str, Any]]:
    state = db.scalar(select(OperationsState).where(OperationsState.site_id == site.id))
    if not state:
        payload = blank_operations_db(site)
        state = OperationsState(site_id=site.id, json_data=json.dumps(payload, ensure_ascii=False), revision=0)
        db.add(state)
        db.flush()
    else:
        try:
            payload = json.loads(state.json_data or "{}")
        except json.JSONDecodeError:
            payload = blank_operations_db(site)
        if not isinstance(payload, dict) or "batches" not in payload:
            payload = blank_operations_db(site)

    # Forward-compatible defaults for older controlled workflow records.
    payload.setdefault("assignmentCompletions", [])
    payload.setdefault("dgaAttachments", [])
    payload.setdefault("resultEvidence", [])
    # Older browser builds stored DGA evidence without immutable ids. Normalize those rows
    # deterministically before scoping/merging so a legitimate later save is not rejected.
    for idx, row in enumerate(payload.get("dgaAttachments", [])):
        if isinstance(row, dict) and not str(row.get("id") or "").strip():
            sample_key = re.sub(r"[^A-Za-z0-9_-]+", "-", str(row.get("sample") or "sample"))[:48]
            row["id"] = f"DGA-LEGACY-{idx+1}-{sample_key}"

    # Refresh browser-visible master references from PostgreSQL on every load.
    clients = db.scalars(select(Client).where(Client.active.is_(True)).order_by(Client.name)).all()
    payload["clients"] = [{"id": str(row.id), "code": row.code, "name": row.name, "active": True} for row in clients]
    lab_roles = {Role.LAB_TECHNICIAN.value, Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value}
    staff = db.scalars(select(User).where(User.active.is_(True), User.site_id == site.id, User.role.in_(lab_roles)).order_by(User.full_name)).all()
    payload["staff"] = [{"id": row.id, "name": row.full_name, "role": row.role, "active": True} for row in staff]
    payload["qualityDistributions"] = payload.get("qualityDistributions") if isinstance(payload.get("qualityDistributions"), list) else []
    payload["qualityTaskEvents"] = payload.get("qualityTaskEvents") if isinstance(payload.get("qualityTaskEvents"), list) else []
    payload["testAssignments"] = payload.get("testAssignments") if isinstance(payload.get("testAssignments"), list) else []
    for batch in payload.get("batches", []):
        if isinstance(batch, dict) and isinstance(batch.get("tests"), list):
            batch["tests"] = [_normalize_package_test(item) for item in batch["tests"] if isinstance(item, dict)]
    # Batch sample metadata is a projection of the authoritative Intake / Data Form record,
    # not an immutable snapshot.  Samples may be enriched after batch release (for example when
    # linked Client Data Form fields are backfilled).  Refresh controlled metadata on every
    # operations load so Water and downstream workstations immediately see the current Intake
    # values without recreating the sample or Lab Batch.
    _refresh_controlled_batch_metadata_from_intake(db, payload, site.id)
    # The current-month schedule is deterministic and server-owned. It is materialized in the
    # returned payload and becomes durable on the next normal state save/backup restore; reading
    # state must never advance the optimistic-lock revision.
    qc_equipment = db.scalars(select(EquipmentAsset).where(EquipmentAsset.site_id == site.id, EquipmentAsset.active.is_(True)).order_by(EquipmentAsset.equipment_id)).all()
    ensure_monthly_quality_distribution(payload, staff, equipment=qc_equipment, db=db, site_id=site.id)
    payload["customPackages"] = []
    payload["formulaDefinitions"] = []
    payload.pop("controlledDocuments", None)
    return state, payload


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _same(a: Any, b: Any) -> bool:
    return _canonical(a) == _canonical(b)


def _require_unchanged(current: dict[str, Any], proposed: dict[str, Any], keys: set[str]) -> None:
    changed = [key for key in keys if not _same(current.get(key), proposed.get(key))]
    if changed:
        raise PermissionError("Browser-side master data is read-only: " + ", ".join(sorted(changed)))


def _validate_append_only(current_rows: Any, proposed_rows: Any, label: str) -> list[dict[str, Any]]:
    """Reject history rewrites and return only records newly appended by the browser.

    Matching is performed on the complete canonical record, not merely on an id. This means an
    existing record cannot be silently edited while retaining its identifier. New records may be
    inserted anywhere in the browser array (some UI tables use ``unshift``), but every old record
    must still be present byte-for-byte at the JSON value level.
    """
    from collections import Counter

    if not isinstance(current_rows, list) or not isinstance(proposed_rows, list):
        raise ValueError(f"{label} must be a list")
    if any(not isinstance(row, dict) for row in current_rows + proposed_rows):
        raise ValueError(f"Every {label} record must be an object")

    remaining = Counter(_canonical(row) for row in current_rows)
    new_rows: list[dict[str, Any]] = []
    for row in proposed_rows:
        key = _canonical(row)
        if remaining[key]:
            remaining[key] -= 1
        else:
            new_rows.append(row)
    if any(remaining.values()):
        raise PermissionError(f"Existing {label} records cannot be changed or deleted; add a new record/revision instead")
    return new_rows


def _require_unique_record_ids(rows: list[dict[str, Any]], label: str, *, assign_missing: bool = False) -> None:
    seen: set[str] = set()
    for row in rows:
        rid = str(row.get("id") or "").strip()
        if not rid and assign_missing:
            rid = f"{label.upper().replace(' ', '-')}-{uuid4().hex}"
            row["id"] = rid
        if not rid:
            raise ValueError(f"Every {label} record requires an id")
        if rid in seen:
            raise PermissionError(f"Duplicate {label[:-1] if label.endswith('s') else label} record id is not permitted")
        seen.add(rid)


def _batch_for_sample(payload: dict[str, Any], sample: str) -> dict[str, Any] | None:
    return next((b for b in payload.get("batches", []) if sample in [str(x) for x in b.get("samples", [])]), None)


TAN_WORKSTATION = "TAN / Peroxide / RSH / H2S"
FURAN_PASSIVATOR_WORKSTATION = "Furan / Passivator"
PAPER_DP_WORKSTATION = "Paper DP / Furan"
GC_ADDITIVES_WORKSTATION = "DBDS / BHT / Toluene / PCB"
CORROSION_WORKSTATION = "Corrosion / CCD"
KNOWN_WORKSTATIONS = {
    "Water", "Electrical", "DGA", FURAN_PASSIVATOR_WORKSTATION, PAPER_DP_WORKSTATION,
    GC_ADDITIVES_WORKSTATION, TAN_WORKSTATION, CORROSION_WORKSTATION,
    "Physical / Chemistry", "Additives / Special Tests",
}

_WORKSTATION_ALIASES = {
    "Furan": FURAN_PASSIVATOR_WORKSTATION,
    "Paper / DP": PAPER_DP_WORKSTATION,
    "GC-ECD": GC_ADDITIVES_WORKSTATION,
    "GC-FID": GC_ADDITIVES_WORKSTATION,
    "GC Additives": GC_ADDITIVES_WORKSTATION,
    "Corrosion": CORROSION_WORKSTATION,
}

def _canonical_workstation_name(value: str) -> str:
    name = str(value or "").strip()
    return _WORKSTATION_ALIASES.get(name, name)


def _station_from_name(test: str) -> str:
    """Server-side workstation classifier used for authorization.

    The browser may provide a station label for configured package tests, but derived/calculated
    result codes are classified here so URL/UI manipulation cannot bypass assignment controls.
    """
    name = str(test or "").strip()
    low = name.lower()
    if low.startswith("water:") or low.startswith("water_calc:") or any(x in low for x in ("water content", "transformer oil temperature", "humidity in cellulose", "relative saturation", "mineral oil log cw")) or low == "cw":
        return "Water"
    if low.startswith("dga:") or low.startswith("dga_calc:") or "dissolved gas" in low or low == "dga" or "gas analysis" in low:
        return "DGA"
    if (("direct dp" in low and "indirect dp" not in low) or any(x in low for x in ("dp-value of paper", "dp value of paper", "degree of polymerization", "paper sample"))):
        return PAPER_DP_WORKSTATION
    if low.startswith("furan:") or low.startswith("furan_calc:") or any(x in low for x in ("furan", "furf", "2fal", "2-fal", "indirect dp", "paper lifetime", "passivator", "irgamet", "tta", "bta")):
        return FURAN_PASSIVATOR_WORKSTATION
    if any(x in low for x in ("breakdown voltage", "bdv", "power factor", "dissipation factor", "resistivity")):
        return "Electrical"
    if any(x in low for x in ("dbds", "dibenzyl", "pcb", "polychlorinated", "bht", "antioxidant", "toluene")):
        return GC_ADDITIVES_WORKSTATION
    if any(x in low for x in ("corrosive sulfur", "potentially corrosive", "tarnish", "copper corrosion", "ccd")):
        return CORROSION_WORKSTATION
    if any(x in low for x in ("total acid number", "acid number", "peroxide", "hydroperoxide", "rsh", "mercaptan", "hydrogen sulfide", "h2s")):
        return TAN_WORKSTATION
    if any(x in low for x in ("color", "colour", "density", "viscosity", "flash point", "interfacial tension", "ift", "pour point", "appearance", "oil quality index", "oqi", "oqin")):
        return "Physical / Chemistry"
    return "Additives / Special Tests"


def _normalize_package_test(row: dict[str, Any]) -> dict[str, Any]:
    """Normalize configured package rows while preserving controlled master-data choices.

    Historical v2.6.7 rows are repaired when they carry a known stale/blank method or an old
    workstation alias.  Explicit current Admin configuration is otherwise authoritative so a
    future approved method revision or a newly configured test does not require a code change.
    """
    out = dict(row or {})
    test = str(out.get("test") or "").strip()
    low = test.lower()
    configured_station = _canonical_workstation_name(str(out.get("station") or "").strip())
    out["station"] = configured_station if configured_station in KNOWN_WORKSTATIONS else _station_from_name(test)

    method = str(out.get("method") or "").strip()
    method_upper = method.upper()
    if test == "Total Acid Number" and method_upper in {"", "-", "ASTM D974", "ASTM D664"}:
        # Current controlled laboratory baseline: potentiometric TAN uses ASTM D664.
        # Normalize stale D974 rows carried forward from older package snapshots.
        out["method"] = "ASTM D664"
    elif low in {"h2s", "hydrogen sulfide gas (h2s)"} and method_upper in {"", "-"}:
        out["method"] = "UOP 163"
    elif low in {"ph", "ph-value"} and method_upper in {"", "-"}:
        out["method"] = "ASTM WK35536"
    else:
        out["method"] = method
    return out


def _workstation_for_test(batch: dict[str, Any], test: str) -> str:
    # Exact requested tests use their server-held package master-data workstation. Calculated
    # or derived result codes fall back to the protected classifier. Browser payloads cannot
    # rewrite batch test structure, so this keeps authorization controlled and configurable.
    for raw in batch.get("tests", []):
        row = raw if isinstance(raw, dict) else {"test": raw}
        if str(row.get("test") or "") != str(test or ""):
            continue
        configured = _canonical_workstation_name(str(row.get("station") or "").strip())
        if configured in KNOWN_WORKSTATIONS:
            return configured
        break
    return _station_from_name(test)


def _batch_workstations(batch: dict[str, Any]) -> set[str]:
    return {
        _workstation_for_test(batch, str((row if isinstance(row, dict) else {"test": row}).get("test", "")))
        for row in batch.get("tests", [])
    }


def _latest_assignment_for_key(payload: dict[str, Any], batch_id: str, workstation: str) -> dict[str, Any] | None:
    rows = [
        row for row in payload.get("testAssignments", [])
        if str(row.get("batch_id") or "") == str(batch_id or "")
        and _canonical_workstation_name(str(row.get("workstation") or "")) == _canonical_workstation_name(str(workstation or ""))
    ]
    if not rows:
        return None
    rows.sort(key=lambda row: (int(row.get("revision") or 0), str(row.get("assigned_at") or "")))
    return rows[-1]


def _current_test_assignment(payload: dict[str, Any], batch_id: str, workstation: str) -> dict[str, Any] | None:
    """Resolve assignment with a batch-specific override ahead of the site/workstation default.

    batch_id='*' represents the bench assignment that automatically applies to all current and
    future batches at the site. A Senior Chemist may still create a specific-batch override when
    workload or absence requires it.
    """
    exact = _latest_assignment_for_key(payload, str(batch_id or ""), workstation)
    if exact or str(batch_id or "") == "*":
        return exact
    return _latest_assignment_for_key(payload, "*", workstation)


ANALYTICAL_ROTATION_DAYS = 14
ANALYTICAL_ROTATION_ANCHOR = datetime(2026, 1, 4)


def _analytical_rotation_cycle(when: datetime | None = None) -> tuple[str, datetime, datetime, int]:
    """Return the deterministic 14-day analytical assignment cycle containing ``when``."""
    now = when or datetime.utcnow()
    anchor = ANALYTICAL_ROTATION_ANCHOR
    index = (now.date() - anchor.date()).days // ANALYTICAL_ROTATION_DAYS
    start = anchor + timedelta(days=index * ANALYTICAL_ROTATION_DAYS)
    end = start + timedelta(days=ANALYTICAL_ROTATION_DAYS, seconds=-1)
    return f"{start:%Y%m%d}-{end:%Y%m%d}", start, end, index


def _analytical_candidate_available(
    db: Session, site_id: int, person: User, workstation: str, cycle_start: datetime, cycle_end: datetime,
) -> bool:
    """Eligibility gate for automatic analytical rotation."""
    if person.id is None or not person.active or person.role != Role.LAB_TECHNICIAN.value or person.site_id != site_id:
        return False
    now = datetime.utcnow()
    competency = db.query(CompetencyRecord).filter(
        CompetencyRecord.site_id == site_id,
        CompetencyRecord.user_id == person.id,
        CompetencyRecord.workstation == workstation,
        CompetencyRecord.active.is_(True),
        CompetencyRecord.authorization == "INDEPENDENT",
    ).order_by(CompetencyRecord.created_at.desc()).first()
    if not competency:
        return False
    if competency.effective_at and competency.effective_at > cycle_end:
        return False
    if competency.expires_at and competency.expires_at < now:
        return False
    if not _quality_person_available(db, site_id, person, cycle_start, cycle_end):
        return False
    return True


def _night_shift_overlap_count(db: Session, site_id: int, user_id: int, start: datetime, end: datetime) -> int:
    # Prefer the detailed generated/approved Night Shift sequence when it exists. This is the same
    # roster employees see in Workforce, so the analytical rotation and the Night Shift plan do not
    # drift into separate scheduling systems. Planned rows are included because a new 14-day cycle can
    # be published before the Senior performs the final roster approval.
    detailed = db.query(StaffAvailability).filter(
        StaffAvailability.site_id == site_id, StaffAvailability.user_id == user_id,
        StaffAvailability.entry_type == "SHIFT", StaffAvailability.shift_code.like("NIGHT%"),
        StaffAvailability.status.in_(["PLANNED", "APPROVED", "CONFIRMED"]),
        StaffAvailability.start_at <= end, StaffAvailability.end_at >= start,
    ).count()
    if detailed:
        return int(detailed)

    # If the detailed month has not been generated yet, the published annual month plan is the
    # controlled fallback. Count it as one overlap marker per affected month rather than ignoring it.
    months: set[tuple[int, int]] = set()
    cursor = datetime(start.year, start.month, 1)
    terminal = datetime(end.year, end.month, 1)
    while cursor <= terminal:
        months.add((cursor.year, cursor.month))
        cursor = datetime(cursor.year + (1 if cursor.month == 12 else 0), 1 if cursor.month == 12 else cursor.month + 1, 1)
    return sum(1 for year, month in months if db.scalar(select(NightShiftMonthPlan.id).where(
        NightShiftMonthPlan.site_id == site_id, NightShiftMonthPlan.user_id == user_id,
        NightShiftMonthPlan.year == year, NightShiftMonthPlan.month == month, NightShiftMonthPlan.status == "PUBLISHED",
    )) is not None)


def ensure_analytical_rotation_assignments(
    db: Session,
    site_id: int,
    payload: dict[str, Any],
    workstations: set[str] | list[str] | tuple[str, ...],
    *,
    when: datetime | None = None,
) -> list[dict[str, Any]]:
    """Publish missing workstation defaults for the active 14-day analytical cycle.

    Routine laboratory work does not wait for a Senior Chemist to assign every batch. The server
    publishes one named Primary owner per workstation for the active 14-day cycle, using only
    active, site-matched and independently competent laboratory employees. A Senior Chemist can
    still append a batch-specific exception override without rewriting the rotation history.
    """
    cycle_key, cycle_start, cycle_end, cycle_index = _analytical_rotation_cycle(when)
    requested = sorted({
        _canonical_workstation_name(ws)
        for ws in workstations
        if _canonical_workstation_name(ws) in KNOWN_WORKSTATIONS
    })
    if not requested:
        return []

    technicians = list(db.scalars(
        select(User).where(
            User.site_id == site_id,
            User.role == Role.LAB_TECHNICIAN.value,
            User.active.is_(True),
        ).order_by(User.id)
    ).all())
    if not technicians:
        raise ValueError("No active laboratory chemist/technician is available for automatic assignment")

    load: dict[int, int] = {int(person.id): 0 for person in technicians if person.id is not None}
    for row in payload.get("testAssignments", []):
        if not isinstance(row, dict):
            continue
        assigned_at = str(row.get("assigned_at") or "")
        if str(row.get("batch_id") or "") != "*" or assigned_at < cycle_start.isoformat() or assigned_at > cycle_end.isoformat():
            continue
        uid = int(row.get("primary_user_id") or 0)
        if uid in load:
            load[uid] += 1

    created: list[dict[str, Any]] = []
    for workstation in requested:
        cycle_rows = [
            row for row in payload.get("testAssignments", [])
            if isinstance(row, dict)
            and str(row.get("batch_id") or "") == "*"
            and _canonical_workstation_name(str(row.get("workstation") or "")) == workstation
            and cycle_start.isoformat() <= str(row.get("assigned_at") or "") <= cycle_end.isoformat()
        ]
        if cycle_rows:
            continue

        eligible = [
            person for person in technicians
            if _analytical_candidate_available(db, site_id, person, workstation, cycle_start, cycle_end)
        ]
        if not eligible:
            raise ValueError(f"No independently competent and available employee is eligible for {workstation}")

        ordered = sorted(eligible, key=lambda person: int(person.id or 0))
        offset = cycle_index % len(ordered)
        ordered = ordered[offset:] + ordered[:offset]
        rank = {int(person.id or 0): idx for idx, person in enumerate(ordered)}
        night_overlap = {int(person.id or 0): _night_shift_overlap_count(db, site_id, int(person.id or 0), cycle_start, cycle_end) for person in ordered}
        primary = min(ordered, key=lambda person: (load.get(int(person.id or 0), 0), night_overlap.get(int(person.id or 0), 0), rank[int(person.id or 0)]))
        previous = _latest_assignment_for_key(payload, "*", workstation)
        revision = int(previous.get("revision") or 0) + 1 if previous else 1
        row = {
            "id": f"WSA-AUTO-{cycle_key}-{re.sub(r'[^A-Z0-9]+', '-', workstation.upper()).strip('-')}",
            "batch_id": "*",
            "scope": "WORKSTATION",
            "workstation": workstation,
            "mode": "SINGLE",
            "primary_user_id": primary.id,
            "primary_name": primary.full_name,
            "backup_user_id": None,
            "backup_name": "",
            "revision": revision,
            "assigned_by_user_id": None,
            "assigned_by": "TSCO Auto Assignment",
            "assigned_at": (when or datetime.utcnow()).isoformat(),
            "access_scope": "NAMED_USERS",
            "source": "AUTO_14_DAY_ROTATION",
            "cycle_key": cycle_key,
            "cycle_start": cycle_start.isoformat(),
            "cycle_end": cycle_end.isoformat(),
            "night_shift_overlap": bool(night_overlap.get(int(primary.id or 0), 0)),
            "shift_context": "Detailed Night Shift sequence / annual month plan considered in automatic rotation ranking",
        }
        payload.setdefault("testAssignments", []).append(row)
        load[int(primary.id or 0)] = load.get(int(primary.id or 0), 0) + 1
        created.append(row)
    return created


def _assignment_allows_user(payload: dict[str, Any], batch: dict[str, Any], test: str, user: User) -> bool:
    # Visibility can be broader for Senior/Admin, but analytical write authority follows an
    # explicit workstation assignment. Senior Chemists can assign/reassign themselves when
    # they need to cover a bench; System Administrators do not author laboratory results.
    if user.role != Role.LAB_TECHNICIAN.value:
        return False
    workstation = _workstation_for_test(batch, test)
    assignment = _current_test_assignment(payload, str(batch.get("id") or ""), workstation)
    if not assignment:
        return False
    mode = str(assignment.get("mode") or "SINGLE").upper()
    if mode == "ALL":
        # Legacy broad-access assignments are not authoritative.
        return False
    uid = int(user.id or 0)
    return uid in {int(assignment.get("primary_user_id") or 0), int(assignment.get("backup_user_id") or 0)}


def _qc_workstation(group: str) -> str:
    low = str(group or "").lower()
    if "water" in low:
        return "Water"
    if "dga" in low:
        return "DGA"
    if any(x in low for x in ("direct dp", "paper dp", "degree of polymerization")):
        return PAPER_DP_WORKSTATION
    if any(x in low for x in ("furan", "passivator", "irgamet", "tta", "bta")):
        return FURAN_PASSIVATOR_WORKSTATION
    if "bdv" in low or "power factor" in low or "dissipation" in low or "resist" in low or "electrode" == low.strip():
        return "Electrical"
    if any(x in low for x in ("dbds", "pcb", "bht", "toluene", "antioxidant")):
        return GC_ADDITIVES_WORKSTATION
    if any(x in low for x in ("tan", "acid", "peroxide", "rsh", "mercaptan", "h2s")):
        return TAN_WORKSTATION
    if any(x in low for x in ("corros", "tarnish", "copper", "ccd")):
        return CORROSION_WORKSTATION
    if any(x in low for x in ("color", "colour", "viscosity", "density", "flash", "ift", "interfacial", "appearance", "oil quality", "oqi", "oqin", "pour point")):
        return "Physical / Chemistry"
    return "Additives / Special Tests"


def _user_has_workstation_assignment(payload: dict[str, Any], workstation: str, user: User) -> bool:
    # Analytical/Test QC is performed by assigned laboratory chemists. Quality oversees and
    # qualifies QC profiles/materials through its dedicated controls; it is not an automatic
    # bench-operator override.
    if user.role != Role.LAB_TECHNICIAN.value:
        return False
    for batch in payload.get("batches", []):
        if workstation not in _batch_workstations(batch):
            continue
        assignment = _current_test_assignment(payload, str(batch.get("id") or ""), workstation)
        if not assignment:
            continue
        if str(assignment.get("mode") or "SINGLE").upper() == "ALL":
            continue
        uid = int(user.id or 0)
        if uid in {int(assignment.get("primary_user_id") or 0), int(assignment.get("backup_user_id") or 0)}:
            return True
    return False



def _assignment_allows_user_row(assignment: dict[str, Any], user: User) -> bool:
    """Return whether one explicit assignment row authorizes the authenticated chemist."""
    if user.role != Role.LAB_TECHNICIAN.value:
        return False
    if str(assignment.get("mode") or "SINGLE").upper() == "ALL":
        return False
    uid = int(user.id or 0)
    return uid in {
        int(assignment.get("primary_user_id") or 0),
        int(assignment.get("backup_user_id") or 0),
    }


def _current_user_assignment_map(payload: dict[str, Any], user: User) -> dict[tuple[str, str], dict[str, Any]]:
    """Current batch/workstation assignments that authorize this user.

    Historical superseded assignments are deliberately excluded. This map is used both for
    server-side read scoping and for analytical-QC authorization.
    """
    out: dict[tuple[str, str], dict[str, Any]] = {}
    for batch in payload.get("batches", []):
        if not isinstance(batch, dict):
            continue
        batch_id = str(batch.get("id") or "")
        if not batch_id:
            continue
        for workstation in _batch_workstations(batch):
            assignment = _current_test_assignment(payload, batch_id, workstation)
            if assignment and _assignment_allows_user_row(assignment, user):
                out[(batch_id, workstation)] = assignment
    return out


def scope_operations_payload(payload: dict[str, Any], user: User) -> dict[str, Any]:
    """Return the least-privilege laboratory payload for the authenticated user.

    Lab Technicians receive only the batches/tests/results/QC/retests and monthly routine-QC
    assignments that are relevant to their current assignments. Supervisory roles retain their
    approved site-level visibility. This is a data-boundary control, not merely a UI filter.
    """
    if user.role != Role.LAB_TECHNICIAN.value:
        return payload

    scoped = deepcopy(payload)
    allowed = _current_user_assignment_map(payload, user)
    allowed_pairs = set(allowed)
    uid = int(user.id or 0)
    allowed_workstations = {ws for _, ws in allowed_pairs}

    # Batches are visible only when at least one workstation is currently assigned to the user;
    # each batch is reduced to the tests within those assignments.
    scoped_batches: list[dict[str, Any]] = []
    sample_to_batch: dict[str, str] = {}
    for batch in payload.get("batches", []):
        if not isinstance(batch, dict):
            continue
        bid = str(batch.get("id") or "")
        allowed_ws = {ws for b, ws in allowed_pairs if b == bid}
        if not allowed_ws:
            continue
        copy_batch = deepcopy(batch)
        copy_batch["tests"] = [
            deepcopy(row) for row in batch.get("tests", [])
            if _station_from_name((row if isinstance(row, dict) else {"test": row}).get("test", "")) in allowed_ws
        ]
        if not copy_batch["tests"]:
            continue
        scoped_batches.append(copy_batch)
        for sample in copy_batch.get("samples", []):
            sample_to_batch[str(sample)] = bid
    scoped["batches"] = scoped_batches

    def result_allowed(row: dict[str, Any]) -> bool:
        sample = str(row.get("sample") or "")
        bid = sample_to_batch.get(sample)
        if not bid:
            return False
        return (bid, _station_from_name(str(row.get("test") or ""))) in allowed_pairs

    scoped["results"] = [deepcopy(r) for r in payload.get("results", []) if isinstance(r, dict) and result_allowed(r)]
    scoped["qc"] = [
        deepcopy(r) for r in payload.get("qc", [])
        if isinstance(r, dict) and _qc_workstation(str(r.get("test") or "")) in allowed_workstations
    ]
    scoped["qualifiedQcProfiles"] = [
        deepcopy(r) for r in payload.get("qualifiedQcProfiles", [])
        if isinstance(r, dict) and _qc_workstation(str(r.get("test") or "")) in allowed_workstations
    ]
    scoped["retests"] = [
        deepcopy(r) for r in payload.get("retests", [])
        if isinstance(r, dict)
        and (sample_to_batch.get(str(r.get("sample") or "")), _station_from_name(str(r.get("test") or ""))) in allowed_pairs
    ]
    scoped["dgaAttachments"] = [
        deepcopy(r) for r in payload.get("dgaAttachments", [])
        if isinstance(r, dict)
        and (sample_to_batch.get(str(r.get("sample") or "")), "DGA") in allowed_pairs
    ]
    scoped["resultEvidence"] = [
        deepcopy(r) for r in payload.get("resultEvidence", [])
        if isinstance(r, dict)
        and sample_to_batch.get(str(r.get("sample") or ""))
        and (sample_to_batch.get(str(r.get("sample") or "")), _station_from_name(str(r.get("test") or ""))) in allowed_pairs
    ]

    # The technician needs only the current rows that actually authorize their own work.
    scoped["testAssignments"] = [deepcopy(a) for a in allowed.values()]
    scoped["assignmentCompletions"] = [
        deepcopy(row) for row in payload.get("assignmentCompletions", [])
        if isinstance(row, dict)
        and (str(row.get("batch_id") or ""), _canonical_workstation_name(str(row.get("workstation") or ""))) in {
            (bid, _canonical_workstation_name(ws)) for bid, ws in allowed_pairs
        }
        and int(row.get("completed_by_user_id") or 0) == uid
    ]

    # Monthly/routine Quality Distribution is governed outside the Laboratory Operations browser
    # console. Technicians execute only their personal queue at /control/my-quality-tasks.
    # Do not leak the distribution matrix or its event history into the bench application.
    scoped["qualityDistributions"] = []
    scoped["qualityTaskEvents"] = []

    # Supervisory/report/retention history is not needed for the technician's approved pages.
    for key in ("reports", "retained", "storageAssignments", "batchHistory", "cancelledSamples", "supervisorNotes"):
        scoped[key] = []

    # Avoid leaking the complete laboratory staff directory into a bench payload. The current
    # user's identity is sufficient for result/QC evidence; Primary/Backup names are carried on
    # their assigned routine/test rows.
    scoped["staff"] = [
        deepcopy(row) for row in payload.get("staff", [])
        if isinstance(row, dict) and int(row.get("id") or 0) == uid
    ]
    return scoped


def _merge_rows_by_id(current_rows: list[dict[str, Any]], incoming_rows: list[dict[str, Any]], label: str) -> list[dict[str, Any]]:
    """Overlay scoped rows by immutable record id while preserving all unseen server rows."""
    if not isinstance(incoming_rows, list) or any(not isinstance(r, dict) for r in incoming_rows):
        raise ValueError(f"{label} must be a list of objects")
    merged = [deepcopy(r) for r in current_rows]
    index = {str(r.get("id")): i for i, r in enumerate(merged) if r.get("id") is not None}
    seen_incoming: set[str] = set()
    for row in incoming_rows:
        rid = str(row.get("id") or "").strip()
        if not rid:
            raise ValueError(f"Every {label} record requires an id")
        if rid in seen_incoming:
            raise PermissionError(f"Duplicate {label[:-1] if label.endswith('s') else label} record id is not permitted")
        seen_incoming.add(rid)
        if rid in index:
            merged[index[rid]] = deepcopy(row)
        else:
            index[rid] = len(merged)
            merged.append(deepcopy(row))
    return merged


def merge_scoped_operations_update(current: dict[str, Any], incoming: dict[str, Any], user: User) -> dict[str, Any]:
    """Merge a Lab Technician's assignment-scoped browser payload back into full server state."""
    if user.role != Role.LAB_TECHNICIAN.value:
        return incoming
    if not isinstance(incoming, dict):
        raise ValueError("Invalid operations database")
    # Older persisted states may predate newly introduced forward-compatible fields.
    # Normalize both sides before the strict unknown-field check so a legitimate
    # browser payload cannot be rejected only because the durable row is older.
    current = deepcopy(current)
    current.setdefault("dgaAttachments", [])
    current.setdefault("resultEvidence", [])
    unknown = set(incoming) - set(current)
    if unknown:
        raise PermissionError("Unknown browser database fields are not accepted: " + ", ".join(sorted(unknown)))

    # Compare all non-editable keys with the same scoped snapshot the technician was entitled
    # to receive. A forged batch/assignment/config change is rejected rather than silently ignored.
    baseline = scope_operations_payload(current, user)
    editable_lists = {"results", "qc", "retests", "dgaAttachments", "resultEvidence", "assignmentCompletions"}
    editable_dicts = {"drafts", "calculationDrafts"}
    for key, value in incoming.items():
        if key in editable_lists or key in editable_dicts or key == "meta":
            continue
        if key == "testAssignments":
            # Only the order is presentation-specific. No assignment may be added,
            # removed, duplicated, or altered by a technician.
            expected, received = baseline.get(key), value
            def indexed_assignments(rows):
                if not isinstance(rows, list) or any(
                    not isinstance(row, dict) or not str(row.get("id") or "").strip()
                    for row in rows
                ):
                    return None
                by_id = {str(row["id"]): row for row in rows}
                return by_id if len(by_id) == len(rows) else None
            expected_ids = indexed_assignments(expected)
            received_ids = indexed_assignments(received)
            if expected_ids is not None and received_ids is not None and _same(expected_ids, received_ids):
                continue
        if not _same(baseline.get(key), value):
            raise PermissionError(f"Assignment-scoped field '{key}' is read-only for Laboratory Technician")

    merged = deepcopy(current)
    # Records visible in the scoped payload retain their normal immutability/deletion rules;
    # scoping must not accidentally turn omission into a hidden delete/restore operation.
    for key in {"results", "qc", "retests", "assignmentCompletions"}:
        if key in incoming:
            baseline_ids = {str(r.get("id")) for r in baseline.get(key, []) if isinstance(r, dict) and r.get("id") is not None}
            incoming_ids = {str(r.get("id")) for r in incoming.get(key, []) if isinstance(r, dict) and r.get("id") is not None}
            if baseline_ids - incoming_ids:
                raise PermissionError(f"Existing {key} records cannot be changed or deleted; preserve the record history")
    for key in editable_lists:
        if key in incoming:
            merged[key] = _merge_rows_by_id(current.get(key, []), incoming.get(key, []), key)
    for key in editable_dicts:
        if key in incoming:
            if not isinstance(incoming.get(key), dict):
                raise ValueError(f"{key} must be an object")
            combined = dict(current.get(key) or {})
            combined.update(deepcopy(incoming.get(key) or {}))
            merged[key] = combined
    # Server metadata/configuration remains authoritative.
    merged["meta"] = deepcopy(current.get("meta") or {})
    return merged


def _validate_analytical_qc_assignment(
    payload: dict[str, Any], row: dict[str, Any], user: User,
    db: Session | None = None, site_id: int | None = None,
) -> None:
    """Bind Analytical/Test QC to exact package test + method + equipment + current assignment.

    Recurring equipment/routine QC rotation remains a separate governance schedule. This
    control is the run-level analytical prerequisite for sample results and uses the same
    Equipment Master as the single source of instrument identity.
    """
    if user.role != Role.LAB_TECHNICIAN.value:
        raise PermissionError("Only a Laboratory Technician can record Analytical / Test QC")

    group = str(row.get("test") or "").strip()
    context_test = str(row.get("context_test") or "").strip()
    batch_id = str(row.get("batch_id") or "").strip()
    assignment_id = str(row.get("assignment_id") or "").strip()
    if not group:
        raise ValueError("Analytical QC requires a test/group")
    if not batch_id or batch_id == "*":
        raise PermissionError("Analytical/Test QC must be linked to the active laboratory batch/test context")
    batch = next((b for b in payload.get("batches", []) if str(b.get("id") or "") == batch_id), None)
    if not batch:
        raise PermissionError("Analytical/Test QC batch context is not active")

    if not context_test:
        # Backward-compatible inference is allowed only when one unambiguous measured package test
        # maps to the selected QC group in this batch. New UI always sends context_test explicitly.
        matches = [
            item for item in _batch_test_rows(batch)
            if _qc_source_package_test(item)
            and _qc_group_for_result_test(str(item.get("test") or ""), str(item.get("test") or "")) == group
        ]
        if len(matches) != 1:
            raise PermissionError("Select the exact requested test/method context for Analytical/Test QC")
        context_test = str(matches[0].get("test") or "")

    context_item = next((item for item in _batch_test_rows(batch) if str(item.get("test") or "") == context_test), None)
    if context_item is not None and not _qc_source_package_test(context_item):
        raise PermissionError(
            "Analytical/Test QC must be recorded against the independently measured source test, "
            "not an operational or derived/calculated output"
        )

    context = _result_qc_context(batch, {"test": context_test, "display_test": context_test, "method_name": row.get("method_name") or ""})
    if context["group"] != group:
        raise PermissionError("Analytical QC group does not match the selected test context")
    workstation = context["workstation"]
    if workstation not in _batch_workstations(batch):
        raise PermissionError("Analytical QC context does not match an active batch workstation")

    current_assignment = _current_test_assignment(payload, batch_id, workstation)
    if not current_assignment:
        raise PermissionError(f"No current {workstation} analytical assignment exists for this batch")
    if assignment_id and str(current_assignment.get("id") or "") != assignment_id:
        raise PermissionError("Analytical QC must reference the current (not superseded) workstation assignment")
    if not _assignment_allows_user_row(current_assignment, user):
        raise PermissionError(f"Authenticated user is not assigned to the {workstation} workstation required for this analytical QC")

    equipment = _validated_qc_equipment(
        db, site_id,
        equipment_asset_id=row.get("equipment_asset_id"),
        workstation=workstation,
        method_name=context["method"],
    )

    row["assignment_id"] = str(current_assignment.get("id") or "")
    row["batch_id"] = batch_id
    row["workstation"] = workstation
    row["context_test"] = context["test"]
    row["method_name"] = context["method"]
    if equipment is not None:
        row["equipment_asset_id"] = equipment.id
        row["equipment_id"] = equipment.equipment_id
        row["equipment_name"] = equipment.name
        # Preserve the legacy display field, but server-own it from Equipment Master.
        row["instrument"] = f"{equipment.equipment_id} · {equipment.name}"


def _sanitize_test_assignments(
    current: dict[str, Any], proposed: dict[str, Any], user: User,
    db: Session | None = None, site_id: int | None = None,
) -> list[dict[str, Any]]:
    new_rows = _validate_append_only(current.get("testAssignments", []), proposed.get("testAssignments", []), "test assignment")
    _require_unique_record_ids(proposed.get("testAssignments", []), "test assignment", assign_missing=True)
    if new_rows and user.role != Role.SENIOR_CHEMIST.value:
        raise PermissionError("Only a Senior Chemist can assign or reassign laboratory workstations")
    now = datetime.utcnow().isoformat()
    eligible_roles = {Role.LAB_TECHNICIAN.value}
    for row in new_rows:
        batch_id = str(row.get("batch_id") or "").strip()
        workstation = _canonical_workstation_name(str(row.get("workstation") or "").strip())
        row["workstation"] = workstation
        if workstation not in KNOWN_WORKSTATIONS:
            raise ValueError("Test assignment requires a recognized laboratory workstation")
        if db is not None and site_id is not None:
            configured_equipment = db.query(EquipmentAsset).filter(EquipmentAsset.site_id == site_id, EquipmentAsset.workstation == workstation, EquipmentAsset.active.is_(True)).all()
            if configured_equipment:
                now_dt = datetime.utcnow()
                usable = [e for e in configured_equipment if e.status == "IN_SERVICE" and (e.next_calibration_at is None or e.next_calibration_at >= now_dt) and (e.next_verification_at is None or e.next_verification_at >= now_dt)]
                if not usable:
                    raise ValueError(f"No in-service equipment with current calibration and verification is available for {workstation}")
        scope = str(row.get("scope") or ("WORKSTATION" if batch_id == "*" else "BATCH")).strip().upper()
        if scope not in {"WORKSTATION", "BATCH"}:
            raise ValueError("Assignment scope must be WORKSTATION or BATCH")
        if scope == "WORKSTATION":
            batch_id = "*"
            batch = None
        else:
            batch = next((b for b in proposed.get("batches", []) if str(b.get("id") or "") == batch_id), None)
            if not batch:
                raise ValueError("Batch-scoped assignment requires a valid laboratory batch")
            if workstation not in _batch_workstations(batch):
                raise ValueError("Assigned workstation is not part of the selected batch test package")
        mode = str(row.get("mode") or "SINGLE").strip().upper()
        if mode not in {"SINGLE", "PRIMARY_BACKUP"}:
            raise ValueError("Assignment mode must be SINGLE or PRIMARY_BACKUP; broad ALL-staff assignments are not permitted")
        primary_id = int(row.get("primary_user_id") or 0)
        backup_id = int(row.get("backup_user_id") or 0)
        if not primary_id:
            raise ValueError("Single / Primary+Backup assignment requires a Primary chemist")
        if mode == "SINGLE":
            backup_id = 0
        if backup_id and backup_id == primary_id:
            raise ValueError("Primary and Backup must be different users")

        def person(uid: int) -> User | None:
            if not uid or db is None:
                return None
            candidate = db.get(User, uid)
            if not candidate or not candidate.active or candidate.role not in eligible_roles:
                raise ValueError("Assigned chemist is missing, inactive, or not eligible for laboratory testing")
            if site_id is not None and candidate.site_id != site_id:
                raise ValueError("Assigned chemist must belong to the same laboratory site")
            # Production assignment is always competency-gated. No workstation may be assigned
            # merely because no competency records have been configured yet.
            if site_id is not None:
                now_dt = datetime.utcnow()
                qualified = db.query(CompetencyRecord).filter(
                    CompetencyRecord.site_id == site_id, CompetencyRecord.user_id == uid, CompetencyRecord.workstation == workstation,
                    CompetencyRecord.active.is_(True), CompetencyRecord.authorization.in_(["INDEPENDENT", "SUPERVISED"]),
                ).all()
                qualified = [r for r in qualified if r.expires_at is None or r.expires_at >= now_dt]
                if not qualified:
                    raise ValueError(f"{candidate.full_name} is not currently competent/authorized for {workstation}")
                if any(r.authorization == "SUPERVISED" for r in qualified) and not any(r.authorization == "INDEPENDENT" for r in qualified):
                    # Supervised staff may be Backup but not the sole Primary analytical owner.
                    if uid == primary_id and mode == "SINGLE":
                        raise ValueError(f"{candidate.full_name} is authorized only under supervision for {workstation}")
                pattern = db.query(StaffWorkPattern).filter(
                    StaffWorkPattern.site_id == site_id, StaffWorkPattern.user_id == uid, StaffWorkPattern.active.is_(True)
                ).first()
                if pattern:
                    try:
                        operating_days = {int(x) for x in json.loads(pattern.weekdays_json or "[]")}
                    except (TypeError, ValueError, json.JSONDecodeError):
                        operating_days = set()
                    in_effect = (pattern.effective_from is None or now_dt >= pattern.effective_from) and (pattern.effective_to is None or now_dt <= pattern.effective_to.replace(hour=23, minute=59, second=59))
                    if in_effect and operating_days and now_dt.weekday() not in operating_days:
                        raise ValueError(f"{candidate.full_name} is off-pattern today ({pattern.name}); choose an on-pattern available employee")
                conflict = db.query(StaffAvailability).filter(
                    StaffAvailability.site_id == site_id, StaffAvailability.user_id == uid,
                    StaffAvailability.entry_type.in_(["LEAVE", "HOLIDAY", "TRAINING", "UNAVAILABLE"]),
                    StaffAvailability.status.in_(["APPROVED", "CONFIRMED", "APPROVED_FOR_ANNUAL_PLAN"]),
                    StaffAvailability.start_at <= now_dt, StaffAvailability.end_at >= now_dt,
                ).first()
                if conflict:
                    raise ValueError(f"{candidate.full_name} is unavailable due to approved {conflict.entry_type.lower()}")
            return candidate

        primary = person(primary_id)
        backup = person(backup_id)
        previous = _latest_assignment_for_key(current, batch_id, workstation)
        # Also consider earlier new rows in the same request when multiple revisions are intentionally appended.
        staged = _latest_assignment_for_key(proposed, batch_id, workstation)
        latest_revision = max(int(previous.get("revision") or 0) if previous else 0, int(staged.get("revision") or 0) if staged and staged is not row else 0)
        row["batch_id"] = batch_id
        row["scope"] = scope
        row["mode"] = mode
        row["primary_user_id"] = primary.id if primary else None
        row["primary_name"] = primary.full_name if primary else ""
        row["backup_user_id"] = backup.id if backup else None
        row["backup_name"] = backup.full_name if backup else ""
        row["assigned_by_user_id"] = user.id
        row["assigned_by"] = user.full_name
        row["assigned_at"] = now
        row["revision"] = latest_revision + 1
        row["access_scope"] = "NAMED_USERS"
    return new_rows


def _result_test_allowed(batch: dict[str, Any], test: str) -> bool:
    requested = [row if isinstance(row, dict) else {"test": row} for row in batch.get("tests", [])]
    if any(str(row.get("test", "")) == test for row in requested):
        return True
    stations = _batch_workstations(batch)
    if "Water" in stations and (test.startswith("WATER:") or test.startswith("WATER_CALC:")):
        return True
    if "DGA" in stations and (test.startswith("DGA:") or test.startswith("DGA_CALC:")):
        return True
    if FURAN_PASSIVATOR_WORKSTATION in stations and (test.startswith("FURAN:") or test.startswith("FURAN_CALC:")):
        return True
    return False




# Server-side parity for the automatic calculations shown in the laboratory workstation UI.
# The browser presents the calculation immediately, but the server independently validates the
# stored value so a manipulated client cannot persist a forged calculated result.
_OOMMEN_CURVES: dict[int, tuple[tuple[float, float], ...]] = {
    10: ((0, 0), (6.4, 3.9), (9.6, 5.08), (16, 7), (20, 8.06), (25, 10)),
    20: ((0, 0), (10, 3.4), (20, 5.5), (30, 7.5), (40, 10)),
    30: ((0, 0), (10, 2), (20, 3.8), (30, 5), (40, 6), (50, 7.2), (60, 8.8), (65, 10)),
    40: ((0, 0), (10, 1.8), (20, 2.8), (30, 3.54), (40, 4.3), (50, 5), (60, 5.8), (70, 6.5), (80, 7.3), (90, 8.71), (97.4, 10)),
    50: ((0, 0), (10, 1.2), (20, 2), (30, 2.5), (40, 3), (50, 3.5), (60, 4), (70, 4.35), (80, 4.8), (90, 5.28), (100, 5.8)),
    60: ((0, 0), (10, 0.8), (20, 1.5), (30, 2), (40, 2.44), (50, 2.77), (60, 3), (70, 3.2), (80, 3.5), (90, 3.8), (100, 4.06)),
    70: ((0, 0), (10, 0.7), (20, 1.07), (30, 1.44), (40, 1.8), (50, 2), (60, 2.2), (70, 2.4), (80, 2.6), (90, 2.8), (100, 3)),
    80: ((0, 0), (10, 0.5), (20, 0.8), (30, 1.1), (40, 1.3), (50, 1.5), (60, 1.7), (70, 1.8), (80, 2), (90, 2.1), (100, 2.2)),
    90: ((0, 0), (10, 0.5), (20, 0.7), (30, 0.8), (40, 1), (50, 1.2), (60, 1.3), (70, 1.4), (80, 1.5), (90, 1.6), (100, 1.8)),
    100: ((0, 0), (10, 0.3), (20, 0.5), (30, 0.7), (40, 0.8), (50, 0.9), (60, 1), (70, 1.1), (80, 1.2), (90, 1.3), (100, 1.4)),
}


def _normalize_result_state(value: Any) -> str:
    """Normalize controlled non-numeric result states used by laboratory workflows.

    TSCO operational terminology uses LTD (Less Than Detection). Legacy LDT/LDL
    inputs are normalized at the application boundary so new records/reports are
    consistent while historical source documents remain untouched.
    """
    text = str(value or "").strip().upper().replace(" ", "")
    if text in {"LTD", "LDT", "LDL"}:
        return "LTD"
    return ""

# Controlled reporting thresholds confirmed from the current TSCO Analysis Report.
# LTD is the single platform spelling for "Less Than Detection".  The table is
# deliberately field-specific: tests without a confirmed laboratory DL are not
# assigned an invented threshold.
_DETECTION_LIMIT_RULES: tuple[tuple[tuple[str, ...], float, str], ...] = (
    ((r"^furan:2fal$", r"2[- ]?furfural", r"2[- ]?fal"), 0.01, "mg/kg"),
    ((r"total acid number", r"^tan$", r"^acidity$"), 0.010, "mg KOH/g"),
    ((r"^dga:h2$", r"hydrogen \(h2\)"), 1.0, "ppm"),
    ((r"^dga:ch4$", r"methane \(ch4\)"), 1.0, "ppm"),
    ((r"^dga:c2h4$", r"ethylene \(c2h4\)"), 1.0, "ppm"),
    ((r"^dga:c2h6$", r"ethane \(c2h6\)"), 1.0, "ppm"),
    ((r"^dga:c2h2$", r"acetylene \(c2h2\)"), 1.0, "ppm"),
    ((r"^dga:co$", r"carbon monoxide"), 1.0, "ppm"),
    ((r"^dga:co2$", r"carbon dioxide"), 1.0, "ppm"),
)

def _confirmed_detection_limit(test: str, display_test: str = "") -> float | None:
    label = f"{test} {display_test}".strip().lower()
    for patterns, limit, _unit in _DETECTION_LIMIT_RULES:
        if any(re.search(pattern, label, re.I) for pattern in patterns):
            return limit
    return None

def _normalize_result_for_test(test: str, display_test: str, value: Any) -> Any:
    """Canonicalize LTD and convert confirmed below-DL numeric results to LTD."""
    if _normalize_result_state(value):
        return "LTD"
    numeric = _numeric_result(value)
    limit = _confirmed_detection_limit(test, display_test)
    if limit is not None and numeric is not None and numeric < limit:
        return "LTD"
    return value


def _numeric_result(value: Any) -> float | None:
    if value is None or _normalize_result_state(value):
        return None
    text = str(value).strip().replace(',', '.')
    match = re.search(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?", text)
    if not match:
        return None
    try:
        return float(match.group())
    except ValueError:
        return None


def _round_half_up_int(value: float) -> int:
    """Round a positive reporting value to the nearest integer; .5 rounds up."""
    return int(math.floor(float(value) + 0.5))


def _latest_result_matching(
    payload: dict[str, Any], sample: str, include_patterns: tuple[str, ...], exclude_patterns: tuple[str, ...] = ()
) -> dict[str, Any] | None:
    rows = [
        row for row in payload.get("results", [])
        if str(row.get("sample") or "") == sample and not bool(row.get("isRetest"))
    ]
    for row in reversed(rows):
        label = f"{row.get('test', '')} {row.get('display_test', '')}".lower()
        if not any(re.search(pattern, label) for pattern in include_patterns):
            continue
        if any(re.search(pattern, label) for pattern in exclude_patterns):
            continue
        return row
    return None


def _interpolate_oommen(points: tuple[tuple[float, float], ...], water: float) -> float:
    if water <= points[0][0]:
        return points[0][1]
    for idx in range(1, len(points)):
        x2, y2 = points[idx]
        x1, y1 = points[idx - 1]
        if water <= x2:
            return y1 + (water - x1) * (y2 - y1) / (x2 - x1)
    x2, y2 = points[-1]
    x1, y1 = points[-2]
    if y2 >= 9.99:
        return 10.0
    return min(10.0, y2 + (water - x2) * (y2 - y1) / (x2 - x1))


def _oommen_humidity(water: float, temperature: float) -> float:
    tc = max(10.0, min(100.0, temperature))
    temps = sorted(_OOMMEN_CURVES)
    low, high = temps[0], temps[-1]
    for t in temps:
        if t <= tc:
            low = t
        if t >= tc:
            high = t
            break
    a = _interpolate_oommen(_OOMMEN_CURVES[low], water)
    b = _interpolate_oommen(_OOMMEN_CURVES[high], water)
    value = a if low == high else a + (tc - low) * (b - a) / (high - low)
    return min(10.0, max(0.0, value))


def _assert_calculated_value(row: dict[str, Any], expected: float, *, decimals: int, label: str) -> None:
    actual = _numeric_result(row.get("result"))
    if actual is None:
        raise ValueError(f"{label} calculated result must be numeric")
    rounded = round(expected, decimals)
    tolerance = max(10 ** (-(decimals + 1)), abs(rounded) * 1e-7)
    if not math.isclose(actual, rounded, rel_tol=0.0, abs_tol=tolerance):
        raise PermissionError(f"{label} calculated result failed server verification")


def _validate_bdv_series_result(row: dict[str, Any]) -> None:
    """Verify any BDV result produced from the controlled six-run calculation without bypassing QC."""
    label = f"{row.get('test') or ''} {row.get('display_test') or ''}".lower()
    if not ("breakdown voltage" in label or "rsd% of bdv" in label or "bdv" in label):
        return
    calc = row.get("calculation")
    if not isinstance(calc, dict) or not calc.get("inputs"):
        # Manual fallback remains possible; instrument/six-run claims may never omit their raw runs.
        if "six-run" in str(row.get("source") or "").lower() or "instrument csv" in str(row.get("source") or "").lower():
            raise PermissionError("BDV instrument result requires six raw breakdown readings")
        return
    inputs = calc.get("inputs") or {}
    calc_method = str(calc.get("method") or row.get("test_method") or "").upper()
    # Method-defined run set: IEC 60156 uses six breakdowns in the controlled workflow;
    # the configured ASTM D1816 / D877 workflows use five. Never force one protocol onto another.
    expected_runs = 5 if ("ASTM D1816" in calc_method or "ASTM D877" in calc_method) else 6
    values = []
    for idx in range(1, expected_runs + 1):
        value = _numeric_result(inputs.get(f"R{idx}"))
        if value is None:
            raise PermissionError(f"BDV calculation requires exactly {expected_runs} numeric breakdown readings")
        values.append(value)
    expected_keys = {f"R{i}" for i in range(1, expected_runs + 1)}
    if set(inputs) != expected_keys:
        raise PermissionError(
            "BDV calculation inputs must be "
            + ("R1 through R6 only" if expected_runs == 6 else "R1 through R5 only")
        )
    mean = sum(values) / float(expected_runs)
    variance = sum((x - mean) ** 2 for x in values) / float(expected_runs - 1)
    sd = math.sqrt(variance)
    rsd = (sd / mean * 100.0) if mean else 0.0
    if "rsd" in label:
        _assert_calculated_value(row, rsd, decimals=2, label="BDV RSD")
    else:
        decimals = 2
        _assert_calculated_value(row, mean, decimals=decimals, label="BDV Average")


def _validate_calculated_result(payload: dict[str, Any], batch: dict[str, Any], row: dict[str, Any], db: Session | None = None, site_id: int | None = None) -> None:
    if not bool(row.get("calculated")):
        return
    sample = str(row.get("sample") or "")
    test = str(row.get("test") or "")
    low = test.lower()

    # BDV RSD/CV is a verified derived child of the same controlled run set.
    # _validate_bdv_series_result() runs immediately before this function and verifies
    # the raw run count plus the server-recomputed RSD, so no second unsupported-calculation
    # rejection is appropriate here.
    if re.search(r"rsd%? of bdv", low):
        return

    if low == "furan_calc:total":
        fal = _latest_result_matching(payload, sample, (r"\bfuran:2fal\b", r"2[- ]?furfural", r"2[- ]?fal"))
        source = fal.get("result") if fal else None
        if _normalize_result_state(source) == "LTD":
            if _normalize_result_state(row.get("result")) != "LTD":
                raise PermissionError("Total Furanic Compounds for LTD 2-FAL must be reported as LTD")
            row["result"] = "LTD"
            return
        raise PermissionError("Automatic Total Furanic Compounds is only fixed when 2-FAL is LTD; numeric total requires the controlled component calculation")

    if low == "furan_calc:indirect_dp":
        fal = _latest_result_matching(payload, sample, (r"\bfuran:2fal\b", r"2[- ]?furfural", r"2[- ]?fal"))
        source = fal.get("result") if fal else None
        if _normalize_result_state(source) == "LTD":
            if str(row.get("result") or "").strip() != ">1000":
                raise PermissionError("Indirect DP for LTD 2-FAL must be reported as >1000")
            return
        value = _numeric_result(source)
        if value is None or value <= 0:
            raise PermissionError("Indirect DP requires a valid 2-FAL source result")
        _assert_calculated_value(row, (1.5655 - math.log10(value)) / 0.0035, decimals=2, label="Indirect DP")
        return

    if low == "furan_calc:paper_life":
        fal = _latest_result_matching(payload, sample, (r"\bfuran:2fal\b", r"2[- ]?furfural", r"2[- ]?fal"))
        source = fal.get("result") if fal else None
        if _normalize_result_state(source) == "LTD":
            if str(row.get("result") or "").strip() != ">30":
                raise PermissionError("Paper Life for LTD 2-FAL must be reported as >30")
            return
        value = _numeric_result(source)
        if value is None or value <= 0:
            raise PermissionError("Paper Life calculation requires a valid 2-FAL source result")
        dp = (1.5655 - math.log10(value)) / 0.0035
        expected_years = _round_half_up_int(((dp / 1000.0) * 30.0) - 1.0)
        _assert_calculated_value(row, float(expected_years), decimals=0, label="Paper Life")
        return

    if low == "water:kf_rt":
        context = _result_qc_context(batch, {"test": "WATER:KF_RT", "display_test": "Water Content KF @RT"})
        required_ids = _required_water_equipment_ids(payload, context, db=db, site_id=site_id)
        if len(required_ids) < 2:
            raise PermissionError("Water final average requires two active in-service Water instruments")
        raw_rows = [
            r for r in payload.get("results", [])
            if isinstance(r, dict)
            and str(r.get("sample") or "") == sample
            and not bool(r.get("calculated"))
            and str(r.get("test") or "").startswith("WATER:KF_RT:")
        ]
        latest_by_eq: dict[str, dict[str, Any]] = {}
        for raw in raw_rows:
            eq = str(raw.get("equipment_asset_id") or "")
            if eq:
                latest_by_eq[eq] = raw
        missing = [eq for eq in required_ids if str(eq) not in latest_by_eq]
        if missing:
            raise PermissionError("Water final average requires one accepted reading from each active Water instrument")
        values = [_numeric_result(latest_by_eq[str(eq)].get("result")) for eq in required_ids]
        if any(v is None for v in values):
            raise PermissionError("Water final average source readings must be numeric")
        expected = sum(float(v) for v in values if v is not None) / len(values)
        _assert_calculated_value(row, expected, decimals=2, label="Water dual-instrument average")
        return

    if low.startswith("water_calc:"):
        water = _latest_result_matching(payload, sample, (r"\bwater:kf_rt\b", r"water content kf", r"water content(?!.*20)"), (r"humidity", r"relative saturation"))
        temp = _latest_result_matching(payload, sample, (r"\bwater:temp\b", r"transformer oil temperature"))
        water_value = _numeric_result(water.get("result")) if water else None
        temp_value = _numeric_result(temp.get("result")) if temp else None
        if temp_value is None:
            meta = (batch.get("sample_meta") or {}).get(sample) or {}
            temp_value = _numeric_result(meta.get("temp"))
        if water_value is None or temp_value is None:
            raise PermissionError("Water calculations require Water @RT and transformer oil temperature")
        log_cw = (-1567.0 / (temp_value + 273.0)) + 7.0895
        cw = 10.0 ** log_cw
        expectations = {
            "water_calc:log_cw": (log_cw, 6, "Mineral Oil Log Cw"),
            "water_calc:cw": (cw, 3, "Cw"),
            "water_calc:at20": (water_value * 2.24 * math.exp(-0.04 * temp_value), 2, "Water @20°C"),
            "water_calc:rel_sat": (water_value * 100.0 / cw, 2, "Relative Saturation"),
            "water_calc:humidity": (_oommen_humidity(water_value, temp_value), 2, "Humidity in Cellulose"),
        }
        if low not in expectations:
            raise PermissionError("Unknown automatic Water calculation code")
        expected, decimals, label = expectations[low]
        _assert_calculated_value(row, expected, decimals=decimals, label=label)
        return

    if re.search(r"oil quality index|oqin", low):
        tan = _latest_result_matching(payload, sample, (r"total acid number", r"\btan\b", r"^acidity"), (r"oxidation", r"72h", r"164h", r"500h", r"rsh", r"mercaptan"))
        ift = _latest_result_matching(payload, sample, (r"interfacial tension", r"interfaical tension", r"\bift\b"))
        iv = _numeric_result(ift.get("result")) if ift else None
        if iv is None or not tan:
            raise PermissionError("Oil Quality Index requires IFT and TAN source results")
        tan_text = str(tan.get("result") or "").strip().upper()
        if _normalize_result_state(tan_text) == "LTD" or "<0.01" in tan_text:
            expected = iv / 0.01
            actual_text = str(row.get("result") or "").strip()
            actual = _numeric_result(actual_text)
            if not actual_text.startswith(">") or actual is None or not math.isclose(actual, round(expected), rel_tol=0.0, abs_tol=0.51):
                raise PermissionError("Oil Quality Index calculated result failed server verification")
            return
        tv = _numeric_result(tan.get("result"))
        if tv is None or tv <= 0:
            raise PermissionError("Oil Quality Index requires a positive TAN source result")
        _assert_calculated_value(row, iv / tv, decimals=2, label="Oil Quality Index")
        return

    raise PermissionError("Unsupported client-calculated result code")

def _qc_group_for_result_test(test: str, display_test: str = "") -> str:
    t = f"{test} {display_test}".lower()
    if "dga:" in t or "dissolved gas" in t or re.search(r"\bdga\b", t): return "DGA"
    if "water" in t or "humidity in cellulose" in t: return "Water"
    if "color" in t or "colour" in t: return "Color"
    # Direct paper DP is an independent IEC 60450 analytical test. It must never inherit
    # the Furan/HPLC QC just because the display text contains "DP-value".
    if ("direct dp" in t and "indirect" not in t) or "dp-value of paper" in t or "degree of polymerization" in t:
        return "Paper DP"
    if any(x in t for x in ("furan", "2fal", "2-furf", "indirect dp", "paper lifetime")): return "Furan"
    if "dbds" in t: return "DBDS"
    if "toluene" in t: return "Toluene"
    if "bht" in t or "antioxidant" in t: return "BHT"
    if "viscosity" in t: return "Viscosity"
    if "density" in t: return "Density"
    if "flash point" in t: return "Flash Point"
    if "methanol" in t: return "Methanol"
    if any(x in t for x in ("passivator", "irgamet", "tta", "bta")): return "Passivator"
    if "sediment" in t or "sludge" in t: return "Sediment and Sludge"
    if "acid number" in t or re.search(r"\btan\b", t) or "acidity" in t: return "TAN"
    if "rsh" in t or "mercaptan" in t: return "RSH"
    if "breakdown" in t or "bdv" in t: return "BDV"
    # Every non-calculated analytical result requires a QC run. Tests without a qualified
    # statistical profile use a controlled RECORDED QC evidence state rather than inventing limits.
    return str(display_test or test or "").strip()



_METHOD_TOKEN_RE = re.compile(
    r"\b(?:ASTM\s+[A-Z]{0,3}\s*\d+[A-Z]?(?:-\d+)?|IEC\s+\d+(?:-\d+)?|UOP\s+\d+|IP\s+\d+|ISO\s+\d+|NAS\s+\d+)\b",
    re.IGNORECASE,
)


def _method_tokens(value: Any) -> set[str]:
    """Extract comparable controlled method identifiers from free-form master text."""
    text = str(value or "").upper().replace("_", " ")
    tokens: set[str] = set()
    for match in _METHOD_TOKEN_RE.findall(text):
        token = re.sub(r"\s+", " ", match.strip().upper())
        token = re.sub(r"^(ASTM)\s+([A-Z]{1,3})\s+(\d)", r"\1 \2\3", token)
        tokens.add(token)
    return tokens


def _equipment_supports_method(equipment_method: str, requested_method: str) -> bool:
    """Return whether Equipment Master explicitly covers the requested controlled method.

    When a requested test has no standard/method identifier (for example a true visual/manual
    check), workstation/equipment identity is sufficient. If the requested test *does* name a
    standard, the Equipment Master must name at least one matching standard; a generic blank
    method field is not silently treated as authorization.
    """
    requested = _method_tokens(requested_method)
    if not requested:
        return True
    configured = _method_tokens(equipment_method)
    return bool(configured and configured.intersection(requested))


def _batch_test_rows(batch: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        _normalize_package_test(row if isinstance(row, dict) else {"test": row})
        for row in batch.get("tests", [])
        if isinstance(row, (dict, str))
    ]


_QC_NON_SOURCE_TEST_RE = re.compile(
    r"room test temperature|room test humidity|transformer oil temperature|"
    r"water content\s*@20|humidity in cellulose|relative saturation|"
    r"oil quality index|oqin|rsd%? of bdv|indirect dp|paper lifetime|appearance",
    re.IGNORECASE,
)


def _qc_source_package_test(row: dict[str, Any]) -> bool:
    """Return True only for independently measured analytical package tests.

    Operational conditions and derived/calculated outputs are deliberately excluded from
    the QC-entry context. Their values are controlled elsewhere or inherit the QC evidence
    of the measured source result. Every other requested analytical test is QC-gated.
    """
    method = str(row.get("method") or "").strip().lower()
    if "calculation" in method:
        return False
    name = str(row.get("test") or "").strip()
    return bool(name) and not _QC_NON_SOURCE_TEST_RE.search(name)


def _result_qc_context(batch: dict[str, Any], row: dict[str, Any]) -> dict[str, str]:
    """Resolve one measured result to its controlled package test/method/workstation context."""
    result_test = str(row.get("test") or "").strip()
    display = str(row.get("display_test") or "").strip()
    group = _qc_group_for_result_test(result_test, display)
    workstation = _workstation_for_test(batch, result_test)
    tests = _batch_test_rows(batch)

    # Appearance is a controlled visual observation only. It has no independent Equipment ID
    # and no Analytical QC event. Never inherit Color QC just because both are in one package.
    if re.search(r"\bappearance\b", f"{result_test} {display}", re.IGNORECASE):
        return {
            "group": "Appearance", "test": result_test, "method": str(row.get("method_name") or "ASTM D1524"),
            "workstation": _canonical_workstation_name(workstation), "observational": "1",
        }

    exact = next((item for item in tests if str(item.get("test") or "") == result_test), None)
    if exact:
        # BDV RSD is a derived statistic from the same six-breakdown run, not a separate
        # analytical test/QC event. Bind it to the matching measured BDV parent context.
        if re.search(r"\brsd%?\s+of\s+bdv\b", str(exact.get("test") or ""), re.IGNORECASE):
            exact_method = str(exact.get("method") or "")
            parent = next((
                item for item in tests
                if _qc_group_for_result_test(str(item.get("test") or ""), str(item.get("test") or "")) == "BDV"
                and not re.search(r"\brsd%?\s+of\s+bdv\b", str(item.get("test") or ""), re.IGNORECASE)
                and _equipment_supports_method(str(item.get("method") or ""), exact_method)
                and _equipment_supports_method(exact_method, str(item.get("method") or ""))
            ), None)
            if parent:
                return {
                    "group": "BDV",
                    "test": str(parent.get("test") or result_test),
                    "method": str(parent.get("method") or exact_method),
                    "workstation": _canonical_workstation_name(str(parent.get("station") or workstation)),
                }
        return {
            "group": group,
            "test": str(exact.get("test") or result_test),
            "method": str(exact.get("method") or ""),
            "workstation": _canonical_workstation_name(str(exact.get("station") or workstation)),
        }

    # Component-style result codes (DGA:H2, FURAN:2FAL, etc.) inherit the requested parent test.
    # Prefer the same QC group + workstation, then use display-label token overlap to break ties.
    candidates = []
    display_words = set(re.findall(r"[A-Z0-9]+", display.upper()))
    method_hint = str((row.get("calculation") or {}).get("method") or row.get("method_name") or "")
    hinted = _method_tokens(method_hint)
    for item in tests:
        if not _qc_source_package_test(item):
            continue
        item_test = str(item.get("test") or "")
        method = str(item.get("method") or "")
        item_ws = _canonical_workstation_name(str(item.get("station") or _station_from_name(item_test)))
        if item_ws != _canonical_workstation_name(workstation):
            continue
        if _qc_group_for_result_test(item_test, item_test) != group:
            continue
        score = 0
        words = set(re.findall(r"[A-Z0-9]+", item_test.upper()))
        score += len(words.intersection(display_words)) * 3
        if hinted and _method_tokens(method).intersection(hinted):
            score += 20
        candidates.append((score, item))
    if candidates:
        candidates.sort(key=lambda pair: (pair[0], str(pair[1].get("test") or "")))
        item = candidates[-1][1]
        return {
            "group": group,
            "test": str(item.get("test") or result_test),
            "method": str(item.get("method") or ""),
            "workstation": _canonical_workstation_name(str(item.get("station") or workstation)),
        }

    return {"group": group, "test": result_test, "method": method_hint, "workstation": _canonical_workstation_name(workstation)}


def _validated_qc_equipment(
    db: Session | None, site_id: int | None, *, equipment_asset_id: Any,
    workstation: str, method_name: str,
) -> EquipmentAsset | None:
    if db is None or site_id is None:
        return None
    try:
        eq_id = int(equipment_asset_id or 0)
    except (TypeError, ValueError):
        eq_id = 0
    if not eq_id:
        raise PermissionError("Analytical/Test QC requires the exact Equipment ID used for the run")
    equipment = db.get(EquipmentAsset, eq_id)
    if not equipment or equipment.site_id != site_id or not equipment.active:
        raise PermissionError("Selected analytical Equipment ID is not available in this laboratory site")
    if str(equipment.status or "").upper() != "IN_SERVICE":
        raise PermissionError(f"{equipment.equipment_id} is {equipment.status or 'NOT IN SERVICE'} and cannot be used for analytical QC/result entry")
    expected_ws = _canonical_workstation_name(workstation)
    actual_ws = _canonical_workstation_name(str(equipment.workstation or ""))
    if actual_ws != expected_ws:
        raise PermissionError(f"{equipment.equipment_id} belongs to {actual_ws or 'an unconfigured workstation'}, not {expected_ws}")
    now = datetime.utcnow()
    if equipment.next_calibration_at and equipment.next_calibration_at < now:
        raise PermissionError(f"{equipment.equipment_id} calibration is overdue")
    if equipment.next_verification_at and equipment.next_verification_at < now:
        raise PermissionError(f"{equipment.equipment_id} verification is overdue")
    if not _equipment_supports_method(str(equipment.test_method or ""), method_name):
        raise PermissionError(
            f"Equipment Master for {equipment.equipment_id} does not authorize method {method_name or 'UNSPECIFIED'}; "
            "Quality/Technical Management must correct the equipment-method mapping before use"
        )
    return equipment

def _required_water_equipment_ids(
    payload: dict[str, Any], context: dict[str, str], db: Session | None = None, site_id: int | None = None,
) -> list[Any]:
    """Return the controlled Water equipment set that must be QC-ready together.

    In production this comes from active IN_SERVICE Equipment Master rows for the Water
    workstation and controlled method. Unit-level callers without a database infer the
    equipment set from today's QC evidence so schedule tests remain deterministic.
    """
    if db is not None and site_id is not None:
        now = datetime.utcnow()
        rows = db.scalars(
            select(EquipmentAsset).where(
                EquipmentAsset.site_id == site_id,
                EquipmentAsset.active.is_(True),
                EquipmentAsset.workstation == context.get("workstation"),
            ).order_by(EquipmentAsset.equipment_id)
        ).all()
        eligible = [
            eq for eq in rows
            if str(eq.status or "").upper() == "IN_SERVICE"
            and (not eq.next_calibration_at or eq.next_calibration_at >= now)
            and (not eq.next_verification_at or eq.next_verification_at >= now)
            and _equipment_supports_method(str(eq.test_method or ""), str(context.get("method") or ""))
        ]
        return [eq.id for eq in eligible]
    ids: list[Any] = []
    for q in payload.get("qc", []):
        if not isinstance(q, dict) or not _qc_context_matches(q, context) or not q.get("equipment_asset_id"):
            continue
        eq = q.get("equipment_asset_id")
        if str(eq) not in {str(x) for x in ids}:
            ids.append(eq)
    return ids


def _canonical_qc_profile(payload: dict[str, Any], row: dict[str, Any]) -> dict[str, Any] | None:
    profile_id = str(row.get("profile_id") or "").strip()
    if not profile_id:
        return None
    group = str(row.get("test") or "").strip()
    candidates = [
        p for p in payload.get("qualifiedQcProfiles", []) if isinstance(p, dict)
    ] + [
        p for p in _embedded_qc_config().get("qcProfiles", []) if isinstance(p, dict)
    ]
    profile = next((p for p in candidates if str(p.get("id") or "") == profile_id), None)
    if not profile or str(profile.get("test") or "") != group:
        raise PermissionError("QC profile does not match the selected analytical test/group")
    return profile


def _server_qc_status(payload: dict[str, Any], row: dict[str, Any]) -> tuple[str, str, dict[str, Any] | None]:
    group = str(row.get("test") or "").strip()
    if group == "DGA" and isinstance(row.get("qc_components"), list):
        components = row.get("qc_components") or []
        if not components:
            raise ValueError("DGA Analytical QC requires certified gas components")
        rule = (_embedded_qc_config().get("qcRules", {}) or {}).get("DGA", {"type": "percent", "tol": 5})
        try:
            tol = float(rule.get("tol") if rule.get("tol") is not None else 5.0)
        except (TypeError, ValueError):
            tol = 5.0
        canonical = []
        overall = "PASS"
        for item in components:
            name = str((item or {}).get("name") or (item or {}).get("key") or "").strip()
            try:
                target = float((item or {}).get("target"))
                result = float((item or {}).get("result"))
            except (TypeError, ValueError) as exc:
                raise ValueError(f"DGA QC component {name or 'UNKNOWN'} requires numeric certified target and result") from exc
            delta = abs(target) * tol / 100.0
            low, high = target - delta, target + delta
            status = "PASS" if low <= result <= high else "FAIL"
            if status == "FAIL":
                overall = "FAIL"
            deviation = ((result - target) / target * 100.0) if target else 0.0
            canonical.append({
                "key": str((item or {}).get("key") or name),
                "name": name,
                "target": target,
                "result": result,
                "deviation_pct": round(deviation, 3),
                "low": low,
                "high": high,
                "status": status,
            })
        row["qc_components"] = canonical
        row["result"] = f"{sum(1 for x in canonical if x['status']=='PASS')}/{len(canonical)} components PASS"
        row["target"] = f"Certified component targets ±{tol:g}%"
        detail = "; ".join(f"{x['name'] or x['key']}: {x['status']}" for x in canonical)
        return overall, detail, None
    try:
        result = float(row.get("result"))
    except (TypeError, ValueError) as exc:
        raise ValueError("Analytical QC requires a numeric result") from exc
    profile = _canonical_qc_profile(payload, row)
    if profile:
        try:
            l2, u2 = float(profile["lcl2"]), float(profile["ucl2"])
            l3, u3 = float(profile["lcl3"]), float(profile["ucl3"])
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError("Selected QC profile is incomplete") from exc
        if l2 <= result <= u2:
            return "PASS", f"Within 2σ: {l2}–{u2}", profile
        if l3 <= result <= u3:
            return "WARNING", f"Outside 2σ, inside 3σ: {l3}–{u3}", profile
        return "FAIL", f"Outside 3σ: {l3}–{u3}", profile
    rule = (_embedded_qc_config().get("qcRules", {}) or {}).get(group, {"type": "configurable"})
    rule_type = str(rule.get("type") or "configurable").lower()
    try:
        target = float(row.get("target"))
    except (TypeError, ValueError):
        target = None
    try:
        tol = float(rule.get("tol"))
    except (TypeError, ValueError):
        tol = None
    if rule_type == "percent" and target is not None and tol is not None:
        delta = abs(target) * tol / 100.0
        low, high = target - delta, target + delta
        return ("PASS" if low <= result <= high else "FAIL"), f"{low}–{high}", None
    if rule_type == "absolute" and target is not None and tol is not None:
        low, high = target - tol, target + tol
        return ("PASS" if low <= result <= high else "FAIL"), f"{low}–{high}", None
    return "RECORDED", "Controlled QC run recorded; no statistical acceptance limits are configured", None



LAB_OPERATION_TZ = timezone(timedelta(hours=3))
_QC_ACCEPTABLE = {"PASS", "RECORDED"}


def _parse_control_timestamp(value: Any) -> datetime:
    text = str(value or "").strip()
    if not text:
        return datetime.min.replace(tzinfo=timezone.utc)
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return datetime.min.replace(tzinfo=timezone.utc)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _lab_day(value: Any = None) -> str:
    instant = _parse_control_timestamp(value) if value else datetime.now(timezone.utc)
    return instant.astimezone(LAB_OPERATION_TZ).date().isoformat()


def _qc_context_matches(row: dict[str, Any], context: dict[str, str]) -> bool:
    if str(row.get("mode") or "routine").lower() != "routine":
        return False
    if str(row.get("test") or "") != str(context.get("group") or ""):
        return False
    row_ws = str(row.get("workstation") or "").strip()
    if row_ws and _canonical_workstation_name(row_ws) != _canonical_workstation_name(str(context.get("workstation") or "")):
        return False
    requested = _method_tokens(context.get("method"))
    if requested:
        return bool(_method_tokens(row.get("method_name")).intersection(requested))
    return str(row.get("method_name") or "") == str(context.get("method") or "")


def _result_matches_qc_scope(row: dict[str, Any], context: dict[str, str], equipment_asset_id: Any) -> bool:
    if bool(row.get("calculated")):
        return False
    if str(row.get("qc_group") or _qc_group_for_result_test(str(row.get("test") or ""), str(row.get("display_test") or ""))) != str(context.get("group") or ""):
        return False
    if _canonical_workstation_name(str(row.get("workstation") or "")) != _canonical_workstation_name(str(context.get("workstation") or "")):
        return False
    if str(row.get("equipment_asset_id") or "") != str(equipment_asset_id or ""):
        return False
    requested = _method_tokens(context.get("method"))
    if requested:
        return bool(_method_tokens(row.get("test_method")).intersection(requested))
    return str(row.get("test_method") or "") == str(context.get("method") or "")


def _analytical_qc_schedule_state(
    payload: dict[str, Any], context: dict[str, str], equipment_asset_id: Any, *,
    exclude_qc_id: str = "", exclude_result_id: str = "", exclude_sample: str = "", now: datetime | None = None,
) -> dict[str, Any]:
    """Return today's result-validity QC state for one Test + Method + Equipment.

    Policy supplied by the laboratory:
    - Water: two acceptable startup QC runs before first result, then one QC after every ten results.
    - Every other measured analytical test: one acceptable daily QC before first result.
    - A newer WARNING/FAIL blocks results; an older PASS is never allowed to mask it.
    This is intentionally separate from recurring Equipment QC / equipment checks.
    """
    day = (now or datetime.now(timezone.utc)).astimezone(LAB_OPERATION_TZ).date().isoformat()
    rows = [
        q for q in payload.get("qc", []) if isinstance(q, dict)
        and str(q.get("id") or "") != str(exclude_qc_id or "")
        and _qc_context_matches(q, context)
        and str(q.get("equipment_asset_id") or "") == str(equipment_asset_id or "")
        and str(q.get("qc_day") or _lab_day(q.get("ts"))) == day
    ]
    rows.sort(key=lambda q: _parse_control_timestamp(q.get("ts")))
    latest = rows[-1] if rows else None
    acceptable_streak = 0
    for q in reversed(rows):
        if str(q.get("status") or "").upper() not in _QC_ACCEPTABLE:
            break
        acceptable_streak += 1

    results = [
        r for r in payload.get("results", []) if isinstance(r, dict)
        and str(r.get("id") or "") != str(exclude_result_id or "")
        and (not exclude_sample or str(r.get("sample") or "") != str(exclude_sample))
        and _result_matches_qc_scope(r, context, equipment_asset_id)
        and _lab_day(r.get("ts")) == day
    ]

    if str(context.get("group") or "") == "Water":
        if not results and acceptable_streak < 2:
            return {
                "ready": False, "required": True, "day": day,
                "reason": f"WATER_STARTUP_{acceptable_streak + 1}",
                "label": f"Water startup QC {acceptable_streak + 1} of 2 required",
                "latest": latest, "results_since_qc": 0,
            }
        if latest and str(latest.get("status") or "").upper() not in _QC_ACCEPTABLE:
            return {
                "ready": False, "required": True, "day": day,
                "reason": "RECOVERY_AFTER_FAIL", "label": "Water QC recovery required",
                "latest": latest, "results_since_qc": 0,
            }
        last_accepted = next((q for q in reversed(rows) if str(q.get("status") or "").upper() in _QC_ACCEPTABLE), None)
        if not last_accepted:
            return {
                "ready": False, "required": True, "day": day,
                "reason": "WATER_STARTUP_1", "label": "Water startup QC 1 of 2 required",
                "latest": None, "results_since_qc": 0,
            }
        checkpoint = _parse_control_timestamp(last_accepted.get("ts"))
        since = sum(1 for r in results if _parse_control_timestamp(r.get("ts")) > checkpoint)
        if since >= 10:
            return {
                "ready": False, "required": True, "day": day,
                "reason": "WATER_10_RESULT_CHECKPOINT", "label": "Water QC required after 10 results",
                "latest": last_accepted, "results_since_qc": since,
            }
        return {
            "ready": True, "required": False, "day": day,
            "reason": "READY", "label": f"Water QC ready · {since}/10",
            "latest": last_accepted, "results_since_qc": since,
        }

    if latest is None:
        return {
            "ready": False, "required": True, "day": day,
            "reason": "DAILY_STARTUP", "label": "Daily Analytical QC required",
            "latest": None, "results_since_qc": 0,
        }
    if str(latest.get("status") or "").upper() not in _QC_ACCEPTABLE:
        return {
            "ready": False, "required": True, "day": day,
            "reason": "RECOVERY_AFTER_FAIL", "label": "Analytical QC recovery required",
            "latest": latest, "results_since_qc": 0,
        }
    return {
        "ready": True, "required": False, "day": day,
        "reason": "READY", "label": "Daily Analytical QC ready",
        "latest": latest, "results_since_qc": 0,
    }


def _valid_qc_state_for_result(
    payload: dict[str, Any], context: dict[str, str], row: dict[str, Any],
    db: Session | None = None, site_id: int | None = None,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Select a currently valid QC state. The linked client snapshot is advisory; server state wins.

    Water is dual-instrument controlled: every active Water instrument must be QC-ready before
    any sample reading is accepted, and an individual raw reading is bound to the exact
    instrument/QC record that produced it.
    """
    exclude_result_id = str(row.get("id") or "")
    relevant = [q for q in payload.get("qc", []) if isinstance(q, dict) and _qc_context_matches(q, context) and q.get("equipment_asset_id")]

    if str(context.get("group") or "") == "Water":
        required_ids = _required_water_equipment_ids(payload, context, db=db, site_id=site_id)
        if len(required_ids) < 2:
            return None, None
        states: dict[str, dict[str, Any]] = {}
        for eq in required_ids:
            st = _analytical_qc_schedule_state(payload, context, eq, exclude_result_id=exclude_result_id, exclude_sample=str(row.get("sample") or ""))
            if not st.get("ready") or not isinstance(st.get("latest"), dict) or str(st["latest"].get("status") or "").upper() not in _QC_ACCEPTABLE:
                return None, None
            states[str(eq)] = st
        requested_eq = row.get("equipment_asset_id")
        if requested_eq:
            state = states.get(str(requested_eq))
            if not state:
                return None, None
            return state.get("latest"), state
        # A Water final/legacy measured row without exact equipment cannot be accepted.
        return None, None

    equipment_ids: list[Any] = []
    requested_eq = row.get("equipment_asset_id")
    if requested_eq:
        equipment_ids.append(requested_eq)
    linked_id = str(row.get("qc_record_id") or "").strip()
    linked = next((q for q in relevant if str(q.get("id") or "") == linked_id), None) if linked_id else None
    if linked and str(linked.get("equipment_asset_id")) not in {str(x) for x in equipment_ids}:
        equipment_ids.append(linked.get("equipment_asset_id"))
    for q in reversed(sorted(relevant, key=lambda x: _parse_control_timestamp(x.get("ts")))):
        eq = q.get("equipment_asset_id")
        if str(eq) not in {str(x) for x in equipment_ids}:
            equipment_ids.append(eq)
    ready: list[tuple[datetime, dict[str, Any], dict[str, Any]]] = []
    for eq in equipment_ids:
        state = _analytical_qc_schedule_state(payload, context, eq, exclude_result_id=exclude_result_id)
        qc = state.get("latest")
        if state.get("ready") and isinstance(qc, dict) and str(qc.get("status") or "").upper() in _QC_ACCEPTABLE:
            ready.append((_parse_control_timestamp(qc.get("ts")), qc, state))
    if not ready:
        return None, None
    ready.sort(key=lambda x: x[0])
    _, qc, state = ready[-1]
    return qc, state

def _bind_required_qc_to_result(
    payload: dict[str, Any], batch: dict[str, Any], row: dict[str, Any], user: User,
    db: Session | None = None, site_id: int | None = None,
) -> None:
    """Enforce the daily Analytical QC schedule before every measured result.

    QC validity is scoped to Test + Method + Workstation + exact Equipment ID for the laboratory
    day, not to one batch. Batch assignment still controls who may enter the result. This keeps
    result-validity QC separate from recurring Equipment QC / equipment checks.
    """
    if bool(row.get("calculated")):
        return
    context = _result_qc_context(batch, row)
    group = context["group"]
    if not group:
        return
    workstation = context["workstation"]
    assignment = _current_test_assignment(payload, str(batch.get("id") or ""), workstation)
    if not assignment or not _assignment_allows_user_row(assignment, user):
        raise PermissionError(f"Authenticated user is not assigned to the {workstation} workstation")

    if context.get("observational") == "1":
        row["qc_group"] = "Appearance"
        row["qc_status"] = "RECORDED"
        row["qc_record_id"] = ""
        row["qc_ts"] = datetime.utcnow().isoformat()
        row["qc_checked_at"] = row["qc_ts"]
        row["qc_schedule_reason"] = "CONTROLLED_OBSERVATION"
        row["qc_context_test"] = context["test"]
        row["test_method"] = context["method"]
        row["workstation"] = workstation
        row["equipment_asset_id"] = None
        row["equipment_id"] = ""
        row["equipment_name"] = "Controlled visual observation"
        return

    qc, state = _valid_qc_state_for_result(payload, context, row, db=db, site_id=site_id)
    if qc is None or state is None:
        # Report the most useful current schedule reason if any QC/equipment context exists.
        relevant = [q for q in payload.get("qc", []) if isinstance(q, dict) and _qc_context_matches(q, context) and q.get("equipment_asset_id")]
        reasons = []
        equipment_ids = _required_water_equipment_ids(payload, context, db=db, site_id=site_id) if group == "Water" else list({q.get("equipment_asset_id") for q in relevant})
        if group == "Water" and len(equipment_ids) < 2:
            raise PermissionError("Water requires two active in-service IEC 60814 Equipment IDs before result entry")
        for eq in equipment_ids:
            st = _analytical_qc_schedule_state(payload, context, eq, exclude_result_id=str(row.get("id") or ""), exclude_sample=str(row.get("sample") or "") if group == "Water" else "")
            if st.get("required"):
                eq_row = next((q for q in relevant if str(q.get("equipment_asset_id")) == str(eq)), None)
                eq_label = str((eq_row or {}).get("equipment_id") or eq)
                reasons.append(f"{eq_label}: {st.get('label') or 'Analytical QC required'}")
        label = reasons[0] if reasons else ("Water dual-instrument QC is not ready" if group == "Water" else "Daily Analytical QC required")
        raise PermissionError(f"{group} Analytical/Test QC must be completed: {label} before result entry")

    status = str(qc.get("status") or "").upper()
    if status not in _QC_ACCEPTABLE:
        raise PermissionError(f"{group} Analytical QC status is {status or 'MISSING'}; result entry requires acceptable QC")

    equipment = _validated_qc_equipment(
        db, site_id,
        equipment_asset_id=qc.get("equipment_asset_id"),
        workstation=workstation,
        method_name=context["method"],
    )
    if equipment is not None and str(qc.get("equipment_id") or "") not in {"", equipment.equipment_id}:
        raise PermissionError("QC Equipment ID snapshot does not match the current Equipment Master record")

    row["qc_group"] = group
    row["qc_status"] = status
    row["qc_record_id"] = qc.get("id")
    row["qc_ts"] = qc.get("ts") or ""
    row["qc_checked_at"] = qc.get("ts") or ""
    row["qc_day"] = str(qc.get("qc_day") or _lab_day(qc.get("ts")))
    row["qc_schedule_reason"] = state.get("reason") or "READY"
    row["qc_context_test"] = context["test"]
    row["test_method"] = context["method"]
    row["workstation"] = workstation
    row["equipment_asset_id"] = qc.get("equipment_asset_id")
    row["equipment_id"] = qc.get("equipment_id") or (equipment.equipment_id if equipment is not None else "")
    row["equipment_name"] = qc.get("equipment_name") or (equipment.name if equipment is not None else "")
    for target, source in (
        ("qc_profile_id", "profile_id"), ("qc_profile_name", "profile_label"),
        ("qc_profile_source", "profile_source"), ("qc_profile_sheet", "profile_sheet"),
        ("qc_mean", "profile_mean"), ("qc_sd", "profile_sd"),
        ("qc_2sd_low", "profile_lcl2"), ("qc_2sd_high", "profile_ucl2"),
        ("qc_3sd_low", "profile_lcl3"), ("qc_3sd_high", "profile_ucl3"),
    ):
        row[target] = qc.get(source)


def _sanitize_new_dga_attachments(current: dict[str, Any], proposed: dict[str, Any], user: User) -> None:
    new_rows = _validate_append_only(current.get("dgaAttachments", []), proposed.get("dgaAttachments", []), "DGA evidence")
    _require_unique_record_ids(proposed.get("dgaAttachments", []), "DGA evidence")
    now = datetime.utcnow().isoformat()
    for row in new_rows:
        sample = str(row.get("sample") or "").strip()
        if not sample or not str(row.get("name") or "").strip():
            raise ValueError("DGA evidence requires sample and file name")
        batch = _batch_for_sample(proposed, sample)
        if not batch:
            raise PermissionError("DGA evidence must belong to a controlled batch sample")
        dga_tests = [
            str(t.get("test") if isinstance(t, dict) else t)
            for t in batch.get("tests", [])
            if _workstation_for_test(batch, str(t.get("test") if isinstance(t, dict) else t)) == "DGA"
        ]
        if not dga_tests:
            raise PermissionError("DGA evidence can be attached only when DGA is requested")
        if not any(_assignment_allows_user(proposed, batch, t, user) for t in dga_tests):
            raise PermissionError("Authenticated user is not assigned to the DGA workstation")
        batch_ref = str(row.get("batch_id") or "").strip()
        if batch_ref and batch_ref != str(batch.get("id") or ""):
            raise PermissionError("DGA evidence batch reference does not match the sample batch")
        data = str(row.get("data") or "")
        if data and len(data) > 1_500_000:
            raise ValueError("DGA evidence is too large")
        row["batch_id"] = str(batch.get("id") or "")
        row["by"] = user.full_name
        row["recorded_by_user_id"] = user.id
        row["ts"] = now


def _sanitize_new_result_evidence(current: dict[str, Any], proposed: dict[str, Any], user: User) -> None:
    new_rows = _validate_append_only(current.get("resultEvidence", []), proposed.get("resultEvidence", []), "result evidence")
    _require_unique_record_ids(proposed.get("resultEvidence", []), "result evidence")
    now = datetime.utcnow().isoformat()
    for row in new_rows:
        sample = str(row.get("sample") or "").strip()
        test = str(row.get("test") or "").strip()
        if not sample or not test or not str(row.get("name") or "").strip():
            raise ValueError("Result evidence requires sample, test and file name")
        batch = _batch_for_sample(proposed, sample)
        if not batch or not _result_test_allowed(batch, test):
            raise PermissionError("Result evidence must belong to a requested sample/test")
        if not _assignment_allows_user(proposed, batch, test, user):
            raise PermissionError("Authenticated user is not assigned to this evidence test/workstation")
        data = str(row.get("data") or "")
        if data and len(data) > 1_500_000:
            raise ValueError("Result evidence is too large")
        row["by"] = user.full_name
        row["recorded_by_user_id"] = user.id
        row["ts"] = now


def _sanitize_new_results(current: dict[str, Any], proposed: dict[str, Any], user: User, db: Session | None = None, site_id: int | None = None) -> None:
    new_rows = _validate_append_only(current.get("results", []), proposed.get("results", []), "result")
    _require_unique_record_ids(proposed.get("results", []), "result")
    old_by_id = {str(row.get("id")): row for row in current.get("results", []) if row.get("id") is not None}
    now = datetime.utcnow().isoformat()
    for row in new_rows:
        sample = str(row.get("sample") or "").strip()
        test = str(row.get("test") or "").strip()
        if not sample or not test or row.get("result") in {None, ""}:
            raise ValueError("A new result requires sample, test and result")
        row["result"] = _normalize_result_for_test(test, str(row.get("display_test") or ""), row.get("result"))
        label = str(row.get("display_test") or test).strip().lower()
        if label == "color astm":
            allowed_color = {"<0.5", "<1.0", "<1.5", "<2.0", "<2.5", "<3.0", "<3.5", "<4.0", "<4.5", "<5.0", "<5.5", "<6.0", "6.0"}
            if str(row.get("result") or "").strip() not in allowed_color:
                raise PermissionError("Color ASTM must use the controlled D1500 selection")
        if label == "appearance":
            allowed_appearance = {"Clear", "Clear & Bright", "Cloudy", "Particles"}
            if str(row.get("result") or "").strip() not in allowed_appearance:
                raise PermissionError("Appearance must use a controlled selection")
            if str(row.get("result") or "").strip() not in {"Clear", "Clear & Bright"}:
                evidence = [
                    x for x in proposed.get("resultEvidence", [])
                    if isinstance(x, dict)
                    and str(x.get("sample") or "") == sample
                    and str(x.get("test") or "").strip().lower() == "appearance"
                    and str(x.get("data") or "").startswith("data:image/")
                ]
                if not evidence:
                    raise PermissionError("Abnormal Appearance requires photo evidence")
        if test == "WATER:TEMP" and user.role == Role.LAB_TECHNICIAN.value:
            raise PermissionError("Transformer Oil Temperature is controlled Intake/Data Form data and cannot be entered by the laboratory technician")
        if test == "WATER:KF_RT" and not bool(row.get("calculated")):
            raise PermissionError("Final Water @RT is system-calculated from the two instrument readings and cannot be entered manually")
        if test.startswith("WATER:KF_RT:") and bool(row.get("calculated")):
            raise PermissionError("Water instrument readings must be recorded as measured results, not calculated results")
        batch = _batch_for_sample(proposed, sample)
        if not batch:
            raise PermissionError("A laboratory result must belong to a current batch sample")
        batch_ref = str(row.get("batch") or row.get("batch_id") or "").strip()
        if batch_ref and batch_ref != str(batch.get("id") or ""):
            raise PermissionError("Result batch reference does not match the sample batch")
        if not _result_test_allowed(batch, test):
            raise PermissionError("Result test is not part of the sample's controlled test package")
        if not _assignment_allows_user(proposed, batch, test, user):
            raise PermissionError(f"Authenticated user is not assigned to the {_workstation_for_test(batch, test)} workstation for this batch")

        _bind_required_qc_to_result(proposed, batch, row, user, db=db, site_id=site_id)
        if test.startswith("WATER:KF_RT:"):
            suffix = test.split(":", 2)[-1]
            if not row.get("equipment_asset_id") or not row.get("equipment_id"):
                raise PermissionError("Water instrument reading requires exact Equipment ID traceability")
            if suffix != str(row.get("equipment_id") or ""):
                raise PermissionError("Water reading code does not match the exact Equipment ID used")
        _validate_bdv_series_result(row)
        _validate_calculated_result(proposed, batch, row, db=db, site_id=site_id)

        prior = [r for r in current.get("results", []) if str(r.get("sample")) == sample and str(r.get("test")) == test]
        revision_of = str(row.get("revision_of") or "").strip()
        is_retest = bool(row.get("isRetest"))
        if prior and not is_retest:
            if not revision_of:
                raise PermissionError("A repeated result must be appended as an explicit revision")
            previous = old_by_id.get(revision_of)
            if not previous or str(previous.get("sample")) != sample or str(previous.get("test")) != test:
                raise PermissionError("Result revision_of must reference the prior result for the same sample and test")
        elif revision_of:
            previous = old_by_id.get(revision_of)
            if not previous or str(previous.get("sample")) != sample or str(previous.get("test")) != test:
                raise PermissionError("Invalid result revision reference")

        if is_retest:
            retest_id = str(row.get("retest_id") or "").strip()
            request = next((r for r in proposed.get("retests", []) if str(r.get("id")) == retest_id), None)
            if not request or str(request.get("sample")) != sample or str(request.get("test")) != test:
                raise PermissionError("Retest result must reference its controlled retest request")

        # The actor/timestamp are evidence fields and are always server-owned.
        row["analyst"] = user.full_name
        row["ts"] = now
        row["recorded_by_user_id"] = user.id


def _sanitize_new_qc(current: dict[str, Any], proposed: dict[str, Any], user: User, db: Session | None = None, site_id: int | None = None) -> None:
    new_rows = _validate_append_only(current.get("qc", []), proposed.get("qc", []), "QC")
    _require_unique_record_ids(proposed.get("qc", []), "QC")
    now = datetime.utcnow().isoformat()
    for row in new_rows:
        if not str(row.get("test") or "").strip():
            raise ValueError("A new QC record requires a test/group")
        if str(row.get("mode") or "routine").lower() == "qualify":
            if user.role != Role.TECHNICAL_MANAGER.value:
                raise PermissionError("Only the Lab Operational & Technical Manager can qualify an Analytical QC profile")
            row["analyst"] = user.full_name
            row["ts"] = now
            row["recorded_by_user_id"] = user.id
            continue
        _validate_analytical_qc_assignment(proposed, row, user, db=db, site_id=site_id)
        batch = next((b for b in proposed.get("batches", []) if str(b.get("id") or "") == str(row.get("batch_id") or "")), None)
        if not batch:
            raise PermissionError("Analytical QC batch context is not active")
        context = _result_qc_context(batch, {"test": row.get("context_test") or "", "display_test": row.get("context_test") or "", "method_name": row.get("method_name") or ""})
        schedule = _analytical_qc_schedule_state(
            proposed, context, row.get("equipment_asset_id"), exclude_qc_id=str(row.get("id") or "")
        )
        if not schedule.get("required"):
            raise PermissionError("Analytical QC is already current; the next QC run is not due yet")
        row["qc_day"] = schedule["day"]
        row["schedule_reason"] = schedule["reason"]
        row["schedule_label"] = schedule["label"]
        row["results_since_previous_qc"] = int(schedule.get("results_since_qc") or 0)
        status, detail, profile = _server_qc_status(proposed, row)
        row["status"] = status
        row["detail"] = detail
        if profile:
            row["profile_id"] = profile.get("id")
            row["profile_label"] = profile.get("label") or ""
            row["profile_source"] = profile.get("source") or ""
            row["profile_sheet"] = profile.get("sheet") or ""
            row["profile_mean"] = profile.get("mean")
            row["profile_sd"] = profile.get("sd")
            row["profile_lcl2"] = profile.get("lcl2")
            row["profile_ucl2"] = profile.get("ucl2")
            row["profile_lcl3"] = profile.get("lcl3")
            row["profile_ucl3"] = profile.get("ucl3")
        else:
            for key in ("profile_id", "profile_label", "profile_source", "profile_sheet", "profile_mean", "profile_sd", "profile_lcl2", "profile_ucl2", "profile_lcl3", "profile_ucl3"):
                row[key] = "" if key in {"profile_id", "profile_label", "profile_source", "profile_sheet"} else None
        row["analyst"] = user.full_name
        row["ts"] = now
        row["recorded_by_user_id"] = user.id

    new_profiles = _validate_append_only(current.get("qualifiedQcProfiles", []), proposed.get("qualifiedQcProfiles", []), "qualified QC profile")
    _require_unique_record_ids(proposed.get("qualifiedQcProfiles", []), "qualified QC profile")
    for row in new_profiles:
        if user.role != Role.TECHNICAL_MANAGER.value:
            raise PermissionError("Only the Lab Operational & Technical Manager can qualify a new QC profile")
        row["qualified_by"] = user.full_name
        row["qualified_at"] = now
        row["qualified_by_user_id"] = user.id

def _sanitize_technical_history(current: dict[str, Any], proposed: dict[str, Any], user: User) -> None:
    now = datetime.utcnow().isoformat()
    for key, label in (("batchHistory", "batch history"), ("cancelledSamples", "cancelled sample"), ("supervisorNotes", "technical note")):
        new_rows = _validate_append_only(current.get(key, []), proposed.get(key, []), label)
        _require_unique_record_ids(proposed.get(key, []), label, assign_missing=True)
        for row in new_rows:
            row["by"] = user.full_name
            row["ts"] = now
            row["actor_user_id"] = user.id


def _sanitize_qc_materials(current: dict[str, Any], proposed: dict[str, Any], user: User) -> None:
    new_rows = _validate_append_only(current.get("standards", []), proposed.get("standards", []), "QC material")
    _require_unique_record_ids(proposed.get("standards", []), "QC material")
    now = datetime.utcnow().isoformat()
    for row in new_rows:
        row["created_by"] = user.full_name
        row["created_at"] = now
        row["created_by_user_id"] = user.id


def _sanitize_quality_task_events(current: dict[str, Any], proposed: dict[str, Any], user: User) -> None:
    new_rows = _validate_append_only(
        current.get("qualityTaskEvents", []), proposed.get("qualityTaskEvents", []), "quality routine check"
    )
    _require_unique_record_ids(proposed.get("qualityTaskEvents", []), "quality routine check")
    distributions = {str(row.get("id")): row for row in current.get("qualityDistributions", []) if isinstance(row, dict)}
    now = datetime.utcnow().isoformat()
    allowed_status = {"PASS", "ATTENTION", "FAIL"}
    for row in new_rows:
        distribution = distributions.get(str(row.get("distribution_id") or ""))
        if not distribution:
            raise PermissionError("Quality routine check must reference a server-published monthly distribution")
        assignment_id = str(row.get("assignment_id") or "")
        assignment = next(
            (item for item in distribution.get("assignments", []) if str(item.get("id")) == assignment_id), None
        )
        if not assignment:
            raise PermissionError("Quality routine check assignment is not part of the published distribution")
        assigned_ids = {assignment.get("primary_user_id"), assignment.get("backup_user_id")}
        if user.id not in assigned_ids:
            raise PermissionError("Only the assigned Primary or Backup chemist can complete this quality check")
        status = str(row.get("status") or "").strip().upper()
        if status not in allowed_status:
            raise ValueError("Quality routine check status must be PASS, ATTENTION or FAIL")
        note = str(row.get("note") or "").strip()
        if status in {"ATTENTION", "FAIL"} and not note:
            raise ValueError("A note is required for ATTENTION or FAIL quality checks")
        row["status"] = status
        row["task"] = assignment.get("task")
        row["task_key"] = assignment.get("task_key")
        row["domain"] = assignment.get("domain")
        row["period"] = assignment.get("period")
        row["period_label"] = assignment.get("period_label")
        row["completed_by"] = user.full_name
        row["completed_by_user_id"] = user.id
        row["completed_at"] = now


def _validate_batch_integrity(current: dict[str, Any], proposed: dict[str, Any]) -> None:
    """Keep platform-imported sample/batch identity under central server control.

    The browser JSON store is not allowed to mint new samples/batches or rewrite a centrally
    registered sample into another batch. Older non-platform batches remain readable and may be
    maintained by the existing Senior Chemist/Admin role gate for backward compatibility.
    """
    old_rows = current.get("batches", [])
    new_rows = proposed.get("batches", [])
    if not isinstance(old_rows, list) or not isinstance(new_rows, list):
        raise ValueError("batches must be a list")
    if any(not isinstance(row, dict) for row in old_rows + new_rows):
        raise ValueError("Every batch record must be an object")
    _require_unique_record_ids(new_rows, "batch")
    old_by_id = {str(row.get("id")): row for row in old_rows if row.get("id") is not None}
    new_by_id = {str(row.get("id")): row for row in new_rows if row.get("id") is not None}
    if set(old_by_id) - set(new_by_id):
        raise PermissionError("Existing laboratory batches cannot be deleted from the browser")
    added = set(new_by_id) - set(old_by_id)
    if added:
        raise PermissionError("New laboratory samples/batches must originate from the central TSCO registration workflow")
    for bid, old in old_by_id.items():
        if old.get("platform_sample_id") and not _same(old, new_by_id[bid]):
            raise PermissionError("Centrally registered laboratory batch identity/details are read-only in the browser")


def _result_exists(payload: dict[str, Any], sample: str, test: str) -> bool:
    return any(str(r.get("sample", "")) == sample and str(r.get("test", "")) == test for r in payload.get("results", []))


def _test_complete(payload: dict[str, Any], sample: str, test_row: dict[str, Any]) -> bool:
    test = str(test_row.get("test", ""))
    station = _station_from_name(test)
    low = test.lower()
    if station == "DGA":
        components = ("H2", "O2", "N2", "CH4", "CO", "CO2", "C2H4", "C2H6", "C2H2")
        return all(_result_exists(payload, sample, f"DGA:{key}") for key in components)
    if station == PAPER_DP_WORKSTATION:
        return _result_exists(payload, sample, test)
    if station == FURAN_PASSIVATOR_WORKSTATION:
        if "indirect dp" in low:
            return _result_exists(payload, sample, "FURAN_CALC:INDIRECT_DP") or _result_exists(payload, sample, test)
        if "paper lifetime" in low:
            return _result_exists(payload, sample, "FURAN_CALC:PAPER_LIFE") or _result_exists(payload, sample, test)
        if any(x in low for x in ("2-furfural", "2fal", "2-fal", "furanic compounds")):
            return _result_exists(payload, sample, "FURAN:2FAL") or _result_exists(payload, sample, test)
        # Passivator and Direct DP are independent measured results.
        return _result_exists(payload, sample, test)
    if station == "Water":
        batch = _batch_for_sample(payload, sample)
        meta = (batch or {}).get("sample_meta", {}).get(sample, {}) if isinstance((batch or {}).get("sample_meta", {}), dict) else {}
        intake_temp = meta.get("temp") if isinstance(meta, dict) else None
        try:
            has_intake_temp = intake_temp is not None and str(intake_temp).strip() != "" and math.isfinite(float(str(intake_temp).strip()))
        except (TypeError, ValueError):
            has_intake_temp = False
        has_temp = has_intake_temp or _result_exists(payload, sample, "WATER:TEMP")
        if "humidity" in low:
            return _result_exists(payload, sample, "WATER_CALC:HUMIDITY")
        if "@20" in low or "20 °c" in low or "20°c" in low:
            return _result_exists(payload, sample, "WATER_CALC:AT20")
        if "transformer oil temperature" in low:
            return has_temp
        return _result_exists(payload, sample, "WATER:KF_RT") and has_temp
    return _result_exists(payload, sample, test)


def _sample_complete(payload: dict[str, Any], sample: str) -> bool:
    batch = next((b for b in payload.get("batches", []) if sample in b.get("samples", [])), None)
    if not batch:
        return False
    tests = batch.get("tests", [])
    return bool(tests) and all(_test_complete(payload, sample, row if isinstance(row, dict) else {"test": row}) for row in tests)


def _workstation_complete(payload: dict[str, Any], batch: dict[str, Any], workstation: str) -> bool:
    tests = [
        row if isinstance(row, dict) else {"test": row}
        for row in batch.get("tests", [])
        if _workstation_for_test(batch, str((row if isinstance(row, dict) else {"test": row}).get("test", ""))) == workstation
    ]
    if not tests or not batch.get("samples"):
        return False
    return all(_test_complete(payload, str(sample), test_row) for sample in batch.get("samples", []) for test_row in tests)


def _current_assignment_completion(payload: dict[str, Any], batch: dict[str, Any], workstation: str) -> dict[str, Any] | None:
    assignment = _current_test_assignment(payload, str(batch.get("id") or ""), workstation)
    if not assignment:
        return None
    aid = str(assignment.get("id") or "")
    rows = [
        row for row in payload.get("assignmentCompletions", []) if isinstance(row, dict)
        and str(row.get("batch_id") or "") == str(batch.get("id") or "")
        and _canonical_workstation_name(str(row.get("workstation") or "")) == _canonical_workstation_name(workstation)
        and str(row.get("assignment_id") or "") == aid
    ]
    rows.sort(key=lambda row: str(row.get("completed_at") or ""))
    return rows[-1] if rows else None


def _batch_assignments_complete(payload: dict[str, Any], batch: dict[str, Any]) -> bool:
    workstations = _batch_workstations(batch)
    return bool(workstations) and all(_current_assignment_completion(payload, batch, workstation) for workstation in workstations)


def _sanitize_assignment_completions(current: dict[str, Any], proposed: dict[str, Any], user: User) -> None:
    old_rows = current.get("assignmentCompletions", [])
    new_rows = proposed.get("assignmentCompletions", [])
    rows = _validate_append_only(old_rows, new_rows, "assignment completion")
    _require_unique_record_ids(new_rows, "assignment completion")
    for row in rows:
        if user.role != Role.LAB_TECHNICIAN.value:
            raise PermissionError("Only the assigned Chemist / Chemical Technician can complete analytical work")
        batch_id = str(row.get("batch_id") or "").strip()
        workstation = _canonical_workstation_name(str(row.get("workstation") or ""))
        batch = next((b for b in proposed.get("batches", []) if str(b.get("id") or "") == batch_id), None)
        if not batch or workstation not in {_canonical_workstation_name(ws) for ws in _batch_workstations(batch)}:
            raise PermissionError("Assignment completion must reference a current batch workstation")
        assignment = _current_test_assignment(proposed, batch_id, workstation)
        if not assignment or not _assignment_allows_user_row(assignment, user):
            raise PermissionError("Authenticated user is not the current assignee for this workstation")
        if str(row.get("assignment_id") or "") != str(assignment.get("id") or ""):
            raise PermissionError("Assignment completion must reference the current assignment revision")
        if not _workstation_complete(proposed, batch, workstation):
            raise PermissionError("Complete My Assignment is blocked until all required workstation results are complete")
        # QC-gated measured results are already server-bound to PASS. Do not accept completion if
        # any result in this workstation explicitly carries a non-PASS QC state.
        for result in proposed.get("results", []):
            if not isinstance(result, dict) or str(result.get("sample") or "") not in {str(x) for x in batch.get("samples", [])}:
                continue
            if _workstation_for_test(batch, str(result.get("test") or "")) != workstation or bool(result.get("calculated")):
                continue
            group = _qc_group_for_result_test(str(result.get("test") or ""), str(result.get("display_test") or ""))
            if group and str(result.get("qc_status") or "").upper() not in {"PASS", "RECORDED"}:
                raise PermissionError(f"{group} QC must be acceptable before completing this assignment")
        row["workstation"] = workstation
        row["completed_by"] = user.full_name
        row["completed_by_user_id"] = user.id
        row["completed_at"] = datetime.utcnow().isoformat()


def _sample_qc_failed(payload: dict[str, Any], sample: str) -> bool:
    return any(str(r.get("sample", "")) == sample and str(r.get("qc_status", "")).upper() == "FAIL" for r in payload.get("results", []))


def _sample_pending_retest(payload: dict[str, Any], sample: str) -> bool:
    return any(
        str(row.get("sample", "")) == sample and str(row.get("status", "Requested")).upper() != "COMPLETED"
        for row in payload.get("retests", []) if isinstance(row, dict)
    )


def _platform_sample_lab_readiness_from_payload(payload: dict[str, Any], sample: SampleRequest) -> tuple[bool, str]:
    """Evaluate technical-review readiness against one validated OperationsState payload."""
    batch = next((
        row for row in payload.get("batches", [])
        if isinstance(row, dict) and (
            str(row.get("platform_sample_id") or "") == str(sample.id)
            or str(sample.id) in {str(x) for x in row.get("platform_sample_ids", [])}
        )
    ), None)
    if not batch:
        return False, "Sample is not registered in Laboratory Operations"
    candidate_keys = {sample.request_number.upper()}
    if sample.lms_number:
        candidate_keys.add(sample.lms_number.upper())
    sample_key = next((str(key) for key in batch.get("samples", []) if str(key).upper() in candidate_keys), None)
    if not sample_key:
        return False, "Laboratory batch identity does not match the platform sample"
    if not _sample_complete(payload, sample_key):
        return False, "All required laboratory tests must be complete before technical review/approval"
    if not _batch_assignments_complete(payload, batch):
        return False, "Every assigned workstation must be closed with Complete My Assignment before technical review/approval"
    if _sample_qc_failed(payload, sample_key):
        return False, "Technical review/approval is blocked while linked QC status is FAIL"
    if _sample_pending_retest(payload, sample_key):
        return False, "Technical review/approval is blocked while a controlled retest is pending"
    return True, ""


def platform_sample_lab_readiness(db: Session, sample: SampleRequest) -> tuple[bool, str]:
    """Return whether a platform sample can enter/complete technical approval.

    The laboratory OperationsState remains the current analytical source of truth. A centrally
    registered sample is ready only when every controlled package test is complete, every current
    workstation assignment is explicitly closed, no linked result carries QC=FAIL, and no
    controlled retest request remains open.
    """
    site = db.get(Site, sample.site_id)
    if not site:
        return False, "Laboratory site is unavailable"
    _, payload = get_operations_state(db, site)
    return _platform_sample_lab_readiness_from_payload(payload, sample)


def _sanitize_retests(current: dict[str, Any], proposed: dict[str, Any], user: User) -> None:
    old_rows = current.get("retests", [])
    new_rows = proposed.get("retests", [])
    if not isinstance(old_rows, list) or not isinstance(new_rows, list):
        raise ValueError("retests must be a list")
    if any(not isinstance(row, dict) for row in old_rows + new_rows):
        raise ValueError("Every retest record must be an object")
    _require_unique_record_ids(new_rows, "retest")
    old_by_id = {str(row.get("id")): row for row in old_rows if row.get("id") is not None}
    new_by_id = {str(row.get("id")): row for row in new_rows if row.get("id") is not None}
    if set(old_by_id) - set(new_by_id):
        raise PermissionError("Retest requests cannot be deleted")
    request_roles = {Role.SENIOR_CHEMIST.value}
    result_roles = {Role.LAB_TECHNICIAN.value}
    for rid, old in old_by_id.items():
        new = new_by_id[rid]
        immutable = {"id", "sample", "batch", "test", "requested_by", "reason", "requested_at"}
        if any(not _same(old.get(k), new.get(k)) for k in immutable):
            raise PermissionError("Retest request identity/history cannot be rewritten")
        if _same(old, new):
            continue
        if user.role not in result_roles:
            raise PermissionError("This role cannot complete a retest")
        if str(old.get("status", "Requested")) != "Requested" or str(new.get("status")) != "Completed":
            raise PermissionError("Only Requested → Completed retest transition is permitted")
        linked_result = next((
            r for r in proposed.get("results", [])
            if bool(r.get("isRetest")) and str(r.get("retest_id") or "") == rid
            and str(r.get("sample") or "") == str(old.get("sample") or "")
            and str(r.get("test") or "") == str(old.get("test") or "")
        ), None)
        if not linked_result:
            raise PermissionError("A retest cannot be completed without its linked retest result")
        new["completed_by"] = user.full_name
        new["completed_at"] = datetime.utcnow().isoformat()
    for row in new_rows:
        rid = str(row.get("id")) if row.get("id") is not None else ""
        if rid not in old_by_id:
            if user.role not in request_roles or str(getattr(user, "senior_responsibility_domain", "") or "").upper() != "TECHNICAL":
                raise PermissionError("Only Senior Chemist — Technical can request retests")
            sample = str(row.get("sample") or "").strip()
            test = str(row.get("test") or "").strip()
            reason = str(row.get("reason") or "").strip()
            if not sample or not test or not reason:
                raise ValueError("A retest request requires sample, test and reason")
            batch = _batch_for_sample(proposed, sample)
            if not batch:
                raise PermissionError("Retest request must reference a current laboratory batch sample")
            if str(row.get("batch") or "").strip() != str(batch.get("id") or ""):
                raise PermissionError("Retest request batch does not match the sample batch")
            if not _result_test_allowed(batch, test):
                raise PermissionError("Retest request test is not part of the sample's controlled test package")
            if not any(str(r.get("sample") or "") == sample and str(r.get("test") or "") == test for r in current.get("results", [])):
                raise PermissionError("Retest request requires an existing original result")
            row["requested_by"] = user.full_name
            row["requested_at"] = datetime.utcnow().isoformat()
            row["status"] = "Requested"


def _linked_platform_sample(db: Session | None, site_id: int | None, payload: dict[str, Any], sample_key: str) -> SampleRequest | None:
    if db is None or site_id is None:
        return None
    batch = next((b for b in payload.get("batches", []) if sample_key in [str(x) for x in b.get("samples", [])]), None)
    if not batch:
        return None
    sample = db.scalar(
        select(SampleRequest).where(
            SampleRequest.site_id == site_id,
            or_(SampleRequest.request_number == sample_key, SampleRequest.lms_number == sample_key),
        )
    )
    return sample


def _sanitize_reports(
    current: dict[str, Any], proposed: dict[str, Any], user: User,
    db: Session | None = None, site_id: int | None = None,
) -> None:
    """Keep legacy Lab Operations report rows read-only.

    Official reporting is owned by ControlledReport. Result Worksheets in the laboratory
    workspace are technical views only and cannot approve, release, revise or issue reports.
    """
    old_rows = current.get("reports", [])
    new_rows = proposed.get("reports", [])
    if not isinstance(old_rows, list) or not isinstance(new_rows, list):
        raise ValueError("reports must be a list")
    if not _same(old_rows, new_rows):
        raise PermissionError("Result Worksheets are read-only; official report review/release is controlled in Final Controlled Reports")

def validate_operations_update(
    current: dict[str, Any], proposed: dict[str, Any], user: User,
    db: Session | None = None, site_id: int | None = None,
) -> dict[str, Any]:
    """Validate/sanitize a browser-originated OperationsState update.

    PostgreSQL/server state is authoritative. Historical result/QC records are append-only,
    official report approval/release is controlled in Final Controlled Reports, and browser-side master data is read-only.
    """
    if not isinstance(proposed, dict) or not isinstance(proposed.get("batches"), list):
        raise ValueError("Invalid operations database")
    unknown = set(proposed) - set(current)
    if unknown:
        raise PermissionError("Unknown browser database fields are not accepted: " + ", ".join(sorted(unknown)))

    # These entities are administered centrally through PostgreSQL/Admin, never by this browser JSON store.
    _require_unchanged(current, proposed, {
        "clients", "customPackages", "formulaDefinitions", "staff", "samplePoints", "testUnits"
    })

    role = user.role
    result_roles = {Role.LAB_TECHNICIAN.value}
    qc_roles = {Role.LAB_TECHNICIAN.value, Role.TECHNICAL_MANAGER.value}
    qc_profile_roles = {Role.TECHNICAL_MANAGER.value}
    batch_roles = set()
    technical_roles = {Role.SENIOR_CHEMIST.value}

    _sanitize_test_assignments(current, proposed, user, db=db, site_id=site_id)

    if role not in qc_roles and not _same(current.get("qc"), proposed.get("qc")):
        raise PermissionError("This role cannot record Analytical / Test QC")
    if role not in qc_profile_roles and not _same(current.get("qualifiedQcProfiles"), proposed.get("qualifiedQcProfiles")):
        raise PermissionError("Only the Lab Operational & Technical Manager can qualify a new QC profile")
    _sanitize_new_qc(current, proposed, user, db=db, site_id=site_id)

    if role not in result_roles and not _same(current.get("results"), proposed.get("results")):
        raise PermissionError("This role cannot enter laboratory results")
    _sanitize_new_dga_attachments(current, proposed, user)
    _sanitize_new_result_evidence(current, proposed, user)
    _sanitize_new_results(current, proposed, user, db=db, site_id=site_id)
    if role != Role.LAB_TECHNICIAN.value and not _same(current.get("assignmentCompletions"), proposed.get("assignmentCompletions")):
        raise PermissionError("Only assigned laboratory employees can complete their analytical assignment")
    _sanitize_assignment_completions(current, proposed, user)

    if role not in batch_roles and not _same(current.get("batches"), proposed.get("batches")):
        raise PermissionError("Operational sample batching is controlled by Sample Intake & Distribution; Laboratory batch structure is not editable here")
    _validate_batch_integrity(current, proposed)
    if role not in technical_roles:
        for key in ("batchHistory", "cancelledSamples", "supervisorNotes"):
            if not _same(current.get(key), proposed.get(key)):
                raise PermissionError("Technical supervision history is not editable by this role")
    _sanitize_technical_history(current, proposed, user)

    _sanitize_retests(current, proposed, user)
    _sanitize_reports(current, proposed, user, db=db, site_id=site_id)

    # Retention/disposal is a controlled technical disposition. Senior Chemist — Technical
    # owns the laboratory-side decision; the Lab Operational & Technical Manager retains
    # management oversight/fallback. Other Senior responsibility domains remain read-only.
    can_manage_retained = role == Role.TECHNICAL_MANAGER.value or (
        role == Role.SENIOR_CHEMIST.value
        and str(getattr(user, "senior_responsibility_domain", "") or "").upper() == "TECHNICAL"
    )
    if not can_manage_retained:
        for key in ("retained", "storageAssignments"):
            if not _same(current.get(key), proposed.get(key)):
                raise PermissionError("Retained sample disposition requires Senior Chemist — Technical / Lab Operational & Technical Manager authorization")

    # QC material standards are controlled by the Technical Manager; records are append-only.
    if role != Role.TECHNICAL_MANAGER.value:
        if not _same(current.get("standards"), proposed.get("standards")):
            raise PermissionError("Only the Lab Operational & Technical Manager can change QC material records")
    _sanitize_qc_materials(current, proposed, user)

    # Monthly Quality Distribution is generated/published by the server and cannot be rewritten in the browser.
    if not _same(current.get("qualityDistributions"), proposed.get("qualityDistributions")):
        raise PermissionError("Monthly Quality Distribution is server-controlled and read-only")
    quality_event_roles = {Role.LAB_TECHNICIAN.value}
    if role not in quality_event_roles and not _same(current.get("qualityTaskEvents"), proposed.get("qualityTaskEvents")):
        raise PermissionError("Only an assigned laboratory chemist can complete routine quality checks")
    _sanitize_quality_task_events(current, proposed, user)

    # Settings are not a second master-data source. Only QC profile selections may be changed here.
    old_settings = dict(current.get("settings") or {})
    new_settings = dict(proposed.get("settings") or {})
    old_qc = old_settings.pop("qcProfileSelections", {})
    new_qc = new_settings.pop("qcProfileSelections", {})
    if not _same(old_settings, new_settings):
        raise PermissionError("Laboratory configuration is read-only here; use central administration")
    if not _same(old_qc, new_qc) and role != Role.TECHNICAL_MANAGER.value:
        raise PermissionError("Only the Lab Operational & Technical Manager can select QC profiles")

    # Browser-only drafts may be mirrored only by roles that can enter results.
    for key in ("drafts", "calculationDrafts", "dgaAttachments", "resultEvidence"):
        if role not in result_roles and not _same(current.get(key), proposed.get(key)):
            raise PermissionError("This role cannot change laboratory working drafts")

    proposed["meta"] = dict(current.get("meta") or {})
    return proposed


def save_operations_state(db: Session, state: OperationsState, payload: dict[str, Any], actor: User | None = None) -> None:
    # The persisted revision is server-owned. Never trust a client-side meta.revision.
    next_revision = int(state.revision or 0) + 1
    payload.setdefault("meta", {})
    payload["meta"]["revision"] = next_revision
    payload["meta"]["updatedAt"] = datetime.utcnow().isoformat()
    payload["meta"]["platformIntegrated"] = True
    state.json_data = json.dumps(payload, ensure_ascii=False)
    state.revision = next_revision
    state.updated_by_id = actor.id if actor else None
    state.updated_at = datetime.utcnow()


def _method_family_of(method: str) -> str:
    value = str(method or "").strip().upper()
    if value.startswith("ASTM"):
        return "ASTM"
    if value.startswith("IEC"):
        return "IEC"
    return "OTHER" if value and value not in {"-", "CALCULATION"} else ""


def _controlled_test_catalog(db: Session, site_id: int) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str, str]] = set()
    for package in package_catalog(db, site_id):
        for raw in package.get("tests", []):
            if not isinstance(raw, dict):
                continue
            row = _normalize_package_test(raw)
            key = (str(row.get("test") or ""), str(row.get("method") or ""), str(row.get("station") or ""), str(row.get("unit") or ""))
            if key in seen:
                continue
            seen.add(key); out.append(row)
    return out


def _family_adjusted_tests(db: Session, site_id: int, tests: list[dict[str, Any]], family: str) -> list[dict[str, Any]]:
    requested = str(family or "DEFAULT").strip().upper()
    rows = [_normalize_package_test(deepcopy(row)) for row in tests if isinstance(row, dict)]
    if requested not in {"ASTM", "IEC"}:
        return rows
    catalog = _controlled_test_catalog(db, site_id)

    # DGA has a directly controlled ASTM/IEC method-family choice even when the selected package
    # carries only one default method.
    for row in rows:
        if "dissolved gas analysis" in str(row.get("test") or "").lower():
            row["method"] = "ASTM D3612" if requested == "ASTM" else "IEC 60567"

    # BDV is a family-level client choice. Keep one controlled BDV pair matching the request;
    # do not silently run both IEC and ASTM variants when the client selected a family.
    bdv_positions = [i for i, row in enumerate(rows) if "breakdown voltage" in str(row.get("test") or "").lower() or "rsd% of bdv" in str(row.get("test") or "").lower()]
    if bdv_positions:
        candidates = [row for row in catalog if ("breakdown voltage" in str(row.get("test") or "").lower() or "rsd% of bdv" in str(row.get("test") or "").lower()) and _method_family_of(str(row.get("method") or "")) == requested]
        if candidates:
            preferred_method = "ASTM D1816" if requested == "ASTM" else "IEC 60156"
            preferred = [row for row in candidates if str(row.get("method") or "").upper().startswith(preferred_method)]
            chosen_source = preferred or candidates
            chosen: list[dict[str, Any]] = []
            for kind in ("breakdown voltage", "rsd% of bdv"):
                row = next((deepcopy(item) for item in chosen_source if kind in str(item.get("test") or "").lower()), None)
                if row:
                    chosen.append(_normalize_package_test(row))
            first = min(bdv_positions)
            rows = [row for i, row in enumerate(rows) if i not in set(bdv_positions)]
            for offset, row in enumerate(chosen):
                rows.insert(first + offset, row)

    # For other tests, switch only when an approved alternate with the same test name exists in
    # central package master data. Fixed-method tests remain unchanged rather than inventing a method.
    by_name: dict[str, list[dict[str, Any]]] = {}
    for row in catalog:
        by_name.setdefault(str(row.get("test") or "").strip().lower(), []).append(row)
    for row in rows:
        name = str(row.get("test") or "").strip().lower()
        if not name or "dissolved gas analysis" in name or "breakdown voltage" in name or "rsd% of bdv" in name:
            continue
        alternatives = [item for item in by_name.get(name, []) if _method_family_of(str(item.get("method") or "")) == requested]
        if alternatives and _method_family_of(str(row.get("method") or "")) != requested:
            alt = alternatives[0]
            row["method"] = alt.get("method", row.get("method", ""))
            row["station"] = alt.get("station", row.get("station", ""))
            row["unit"] = alt.get("unit", row.get("unit", ""))
    return rows


def resolved_sample_package(db: Session, sample: SampleRequest) -> dict[str, Any]:
    packages = package_catalog(db, sample.site_id)
    raw = (sample.requested_package or "Routine Test").strip()
    requested_family = (sample.requested_method_family or "DEFAULT").strip().upper()
    custom_names: list[str] = []
    try:
        parsed = json.loads(sample.requested_tests_json or "[]")
        custom_names = [str(x).strip() for x in parsed if str(x).strip()] if isinstance(parsed, list) else []
    except Exception:
        custom_names = []

    if raw.upper() == "CUSTOM" or custom_names:
        if not custom_names:
            raise ValueError("Custom request has no requested tests")
        catalog = _controlled_test_catalog(db, sample.site_id)
        chosen: list[dict[str, Any]] = []
        for name in custom_names:
            candidates = [row for row in catalog if str(row.get("test") or "").strip().lower() == name.lower()]
            if not candidates:
                raise ValueError(f"Requested custom test '{name}' is not active in controlled master data")
            family_candidates = [row for row in candidates if _method_family_of(str(row.get("method") or "")) == requested_family] if requested_family in {"ASTM", "IEC"} else []
            chosen.append(deepcopy((family_candidates or candidates)[0]))
        chosen = _family_adjusted_tests(db, sample.site_id, chosen, requested_family)
        return {"id": "CUSTOM_REQUEST", "name": "Custom Tests", "scope": "CLIENT_REQUEST", "kind": "request", "tests": chosen}

    wanted = raw.lower()
    aliases = {
        "sec package": "sec routine",
        "aramco package": "aramco routine",
        "gpel package": "gpel package",
        "routine": "routine test",
        "full": "full test",
    }
    wanted = aliases.get(wanted, wanted)
    for package in packages:
        if package.get("name", "").strip().lower() == wanted:
            resolved = deepcopy(package)
            resolved["tests"] = _family_adjusted_tests(db, sample.site_id, list(resolved.get("tests", [])), requested_family)
            return resolved
    raise ValueError(f"Requested test package '{raw}' is not active for this site; correct Intake before release")


def _select_package(db: Session, sample: SampleRequest) -> dict[str, Any]:
    return resolved_sample_package(db, sample)


def _storage_slots() -> list[dict[str, Any]]:
    rows = [4, 4, 4, 4, 2]
    out: list[dict[str, Any]] = []
    cabinet = 1
    for row_index, cabinet_count in enumerate(rows, start=1):
        cabinets = list(range(cabinet, cabinet + cabinet_count))
        cabinet += cabinet_count
        for shelf in ["A", "B", "C", "D", "E", "F"]:
            for cab in cabinets:
                for slot in range(1, 11):
                    out.append({"row": row_index, "cabinet": cab, "shelf": shelf, "slot": slot})
    return out


def _storage_code(slot: dict[str, Any]) -> str:
    return f"R{slot['row']}-C{int(slot['cabinet']):02d}-{slot['shelf']}-{int(slot['slot']):02d}"


def _reserve_retained_storage(payload: dict[str, Any], sample_key: str) -> dict[str, Any]:
    assignments = payload.setdefault("storageAssignments", [])
    existing = next((row for row in assignments if str(row.get("sample")) == sample_key), None)
    if existing:
        return existing
    used = {_storage_code(row) for row in assignments if row.get("status") != "Released" and all(k in row for k in ("row", "cabinet", "shelf", "slot"))}
    slot = next((candidate for candidate in _storage_slots() if _storage_code(candidate) not in used), None)
    if slot is None:
        raise ValueError("Retained Sample Storage is full")
    assignment = {
        "sample": sample_key, **slot, "code": _storage_code(slot),
        "status": "Reserved", "assigned_at": datetime.utcnow().isoformat(),
    }
    assignments.append(assignment)
    return assignment


def activate_retention_after_report_release(
    db: Session, sample: SampleRequest, actor: User | None = None, *, report_reference: str = ""
) -> None:
    """Activate the retained-sample clock after the official TSCO report is released.

    Storage is reserved at intake distribution. The configured retention period starts only
    after the controlled TSCO report release, keeping Senior Chemist operations and Quality
    oversight aligned with the standalone report lifecycle.
    """
    site = sample.site
    state, payload = get_operations_state(db, site)
    sample_key = (sample.lms_number or sample.request_number).upper()
    assignment = _reserve_retained_storage(payload, sample_key)
    assignment["status"] = "Active"
    assignment["retained_at"] = assignment.get("retained_at") or datetime.utcnow().isoformat()
    settings = payload.get("settings") or {}
    batch = _batch_for_sample(payload, sample_key) or {}
    priority = str(batch.get("priority") or "Normal").lower()
    days = int(settings.get("urgentRetentionDays" if priority == "urgent" else "normalRetentionDays") or 15)
    from datetime import timedelta
    due = (datetime.utcnow() + timedelta(days=days)).date().isoformat()
    assignment["due_date"] = due
    retained = payload.setdefault("retained", [])
    record = next((row for row in retained if str(row.get("sample")) == sample_key), None)
    values = {
        "sample": sample_key, "priority": batch.get("priority") or "Normal",
        "retained_at": assignment["retained_at"], "due_date": due,
        "room": f"Row {assignment['row']}", "rack": f"Cabinet {int(assignment['cabinet']):02d}",
        "shelf": assignment["shelf"], "position": f"{int(assignment['slot']):02d}",
        "storage_code": assignment["code"], "status": "Retained",
        "trigger": "TSCO_OFFICIAL_REPORT", "report_reference": report_reference,
    }
    if record is None:
        retained.append(values)
    else:
        record.update(values)
    save_operations_state(db, state, payload, actor)


# Legacy alias retained for old imports/migrations; standalone runtime uses the TSCO name.
def activate_retention_after_lms(db: Session, sample: SampleRequest, actor: User | None = None, *, report_reference: str = "") -> None:  # pragma: no cover
    return activate_retention_after_report_release(db, sample, actor, report_reference=report_reference)


def _priority_label(value: str | None) -> str:
    clean = str(value or "NORMAL").strip().upper()
    return {"URGENT": "Urgent", "HIGH": "High", "NORMAL": "Normal"}.get(clean, "Normal")


METHOD_OPTIONAL_INPUT_TESTS = {
    "Transformer Oil Temperature",
    "Room Test Temperature",
    "Room Test Humidity",
}


def package_method_configuration_issues(package: dict[str, Any]) -> list[str]:
    """Return analytical package tests that do not yet have a controlled method.

    Environmental/input rows and controlled calculations are allowed without an analytical
    standard. Actual analytical tests are not silently executed with a blank method.
    """
    issues: list[str] = []
    tests = package.get("tests", [])
    if not isinstance(tests, list) or not tests:
        return ["No tests configured in package"]
    for raw in tests:
        row = raw if isinstance(raw, dict) else {"test": str(raw or ""), "method": ""}
        test = str(row.get("test") or "").strip()
        method = str(row.get("method") or "").strip()
        if not test or test in METHOD_OPTIONAL_INPUT_TESTS:
            continue
        if method.upper() == "CALCULATION":
            continue
        if not method or method == "-":
            issues.append(test)
    return issues


def _package_method_family(package: dict[str, Any]) -> str:
    families: list[str] = []
    for row in package.get("tests", []):
        item = row if isinstance(row, dict) else {"method": ""}
        method = str(item.get("method") or "").strip().upper()
        if method.startswith("IEC") and "IEC" not in families:
            families.append("IEC")
        elif method.startswith("ASTM") and "ASTM" not in families:
            families.append("ASTM")
        elif method and method not in {"-", "CALCULATION"} and "OTHER" not in families:
            families.append("OTHER")
    return "+".join(families) or "GENERAL"


def _sample_project_reference(db: Session, sample: SampleRequest) -> str:
    assignment = sample.sampling_assignment
    if assignment and assignment.order and assignment.order.operational_project:
        return assignment.order.operational_project.project_reference or ""
    if sample.commercial_case_id:
        case = db.get(CommercialCase, sample.commercial_case_id)
        if case and case.operational_project:
            return case.operational_project.project_reference or ""
    return ""


def _refresh_controlled_batch_metadata_from_intake(db: Session, payload: dict[str, Any], site_id: int) -> int:
    """Refresh existing Lab Batch metadata from authoritative Sample Intake records.

    Laboratory Operations stores batch structure/results in OperationsState, while identity and
    sampling metadata are controlled by PostgreSQL SampleRequest/Asset records.  A linked Client
    Data Form may populate missing Intake fields after a batch has already been released.  This
    projection refresh keeps those existing batches current without changing Batch IDs, Sample
    IDs, chain of custody, assignments, or analytical results.
    """
    batches = [row for row in payload.get("batches", []) if isinstance(row, dict)]
    raw_ids: set[int] = set()
    for batch in batches:
        for value in batch.get("platform_sample_ids", []) or []:
            try:
                raw_ids.add(int(value))
            except (TypeError, ValueError):
                continue
        single = batch.get("platform_sample_id")
        if single is not None:
            try:
                raw_ids.add(int(single))
            except (TypeError, ValueError):
                pass
    if not raw_ids:
        return 0

    rows = list(db.scalars(
        select(SampleRequest).where(
            SampleRequest.site_id == site_id, SampleRequest.id.in_(sorted(raw_ids))
        )
    ).all())
    by_id = {int(row.id): row for row in rows if row.id is not None}
    changed = 0
    for batch in batches:
        ids: list[int] = []
        for value in batch.get("platform_sample_ids", []) or []:
            try:
                ids.append(int(value))
            except (TypeError, ValueError):
                continue
        if not ids and batch.get("platform_sample_id") is not None:
            try:
                ids = [int(batch.get("platform_sample_id"))]
            except (TypeError, ValueError):
                ids = []
        if not ids:
            continue

        sample_meta = batch.setdefault("sample_meta", {})
        if not isinstance(sample_meta, dict):
            sample_meta = {}
            batch["sample_meta"] = sample_meta
        batch_samples = {str(x).upper() for x in (batch.get("samples") or [])}
        refreshed: list[dict[str, Any]] = []
        for sample_id in ids:
            sample = by_id.get(sample_id)
            if not sample:
                continue
            key = str(sample.lms_number or sample.request_number or "").strip().upper()
            if not key or (batch_samples and key not in batch_samples):
                continue
            current = sample_meta.get(key) if isinstance(sample_meta.get(key), dict) else {}
            authoritative = _lab_sample_metadata(db, sample)
            if current != authoritative:
                sample_meta[key] = authoritative
                changed += 1
            refreshed.append(authoritative)

        # Batch-level room conditions are only a convenience projection for legacy UI areas;
        # preserve the per-sample values above and derive these from the current Intake data.
        if refreshed:
            room_temp = next((m.get("roomTemp") for m in refreshed if m.get("roomTemp")), "")
            room_humidity = next((m.get("roomHumidity") for m in refreshed if m.get("roomHumidity")), "")
            if batch.get("roomTemp", "") != room_temp:
                batch["roomTemp"] = room_temp
            if batch.get("roomHumidity", "") != room_humidity:
                batch["roomHumidity"] = room_humidity
    return changed


def _lab_sample_metadata(db: Session, sample: SampleRequest) -> dict[str, Any]:
    room_temp = "" if sample.ambient_temperature_c is None else str(sample.ambient_temperature_c)
    room_humidity = "" if sample.ambient_humidity_pct is None else str(sample.ambient_humidity_pct)
    oil_temp = "" if sample.oil_temperature_c is None else str(sample.oil_temperature_c)
    return {
        "point": sample.sampling_point,
        "temp": oil_temp,
        "roomTemp": room_temp,
        "roomHumidity": room_humidity,
        "portalRequest": sample.request_number,
        "registrationReference": sample.request_number,
        "legacyExternalReference": sample.lms_number or "",
        "assetCode": sample.asset.asset_code,
        "serialNumber": sample.asset.serial_number,
        "stationName": sample.asset.station_name,
        "exactLocation": sample.asset.asset_location_label,
        "quotation": sample.quotation.number if sample.quotation else "",
        "purchaseOrder": sample.purchase_order.number if sample.purchase_order else "",
        "barcode": sample.barcode_value,
        "sourceChannel": sample.submission_channel,
        "priority": _priority_label(sample.priority),
        "requiredTat": sample.required_tat or "",
        "requestedMethodFamily": sample.requested_method_family or "DEFAULT",
        "requestedTests": json.loads(sample.requested_tests_json or "[]") if sample.requested_tests_json else [],
        "dueAt": sample.due_at.isoformat() if sample.due_at else "",
        "projectReference": _sample_project_reference(db, sample),
    }


def sync_samples_to_operations(
    db: Session,
    samples: list[SampleRequest],
    actor: User | None = None,
    phase: str = "READY_FOR_LAB",
    batch_id: str | None = None,
) -> str:
    """Release one or more compatible intake samples as one controlled laboratory batch.

    The intake batch is authoritative for priority/TAT/project context. Samples may be grouped only
    when site, client, package/method family, priority and requested test set are compatible. Urgent
    work therefore cannot be silently buried in a normal/high-priority batch.
    """
    if not samples:
        raise ValueError("At least one sample is required for laboratory batch release")
    site = samples[0].site
    if any(sample.site_id != site.id for sample in samples):
        raise ValueError("A laboratory batch cannot mix sites")

    prepared: list[tuple[SampleRequest, dict[str, Any], str]] = []
    for sample in samples:
        package = _select_package(db, sample)
        missing_methods = package_method_configuration_issues(package)
        if missing_methods:
            preview = ", ".join(missing_methods[:5])
            suffix = f" (+{len(missing_methods) - 5} more)" if len(missing_methods) > 5 else ""
            raise ValueError(
                f"{package.get('name', sample.requested_package)} cannot be released: controlled package/method configuration is required for {preview}{suffix}"
            )
        requested_family = str(sample.requested_method_family or "DEFAULT").strip().upper()
        family = requested_family if requested_family in {"ASTM", "IEC"} else _package_method_family(package)
        prepared.append((sample, package, family))

    first_sample, first_package, first_family = prepared[0]
    first_tests = json.dumps(first_package.get("tests", []), sort_keys=True, ensure_ascii=False)
    first_priority = _priority_label(first_sample.priority)
    first_tat = str(first_sample.required_tat or "").strip().upper()
    first_exact_due = first_sample.due_at.replace(second=0, microsecond=0) if first_tat == "EXACT_DUE" and first_sample.due_at else None
    for sample, package, family in prepared[1:]:
        if sample.client_id != first_sample.client_id:
            raise ValueError("Selected samples belong to different clients and cannot share one Lab Batch")
        if str(package.get("id") or package.get("name")) != str(first_package.get("id") or first_package.get("name")):
            raise ValueError("Selected samples use different test packages and cannot share one Lab Batch")
        if json.dumps(package.get("tests", []), sort_keys=True, ensure_ascii=False) != first_tests or family != first_family:
            raise ValueError("Selected samples use incompatible method/test requirements")
        if _priority_label(sample.priority) != first_priority:
            raise ValueError("Selected samples have different priorities; release urgent/high/normal work separately")
        sample_tat = str(sample.required_tat or "").strip().upper()
        if sample_tat != first_tat:
            raise ValueError("Selected samples have different TAT classes; release Standard/12H/24H/Exact-Due work separately")
        sample_exact_due = sample.due_at.replace(second=0, microsecond=0) if sample_tat == "EXACT_DUE" and sample.due_at else None
        if sample_tat == "EXACT_DUE" and sample_exact_due != first_exact_due:
            raise ValueError("Selected Exact-Due samples have different deadlines and cannot share one Lab Batch")

    state, payload = get_operations_state(db, site)
    sample_keys = [(sample.lms_number or sample.request_number).upper() for sample, _, _ in prepared]
    collisions = [
        str(batch.get("id") or "") for batch in payload.get("batches", [])
        if any(key in batch.get("samples", []) for key in sample_keys)
    ]
    if collisions:
        raise ValueError("One or more selected samples are already present in Laboratory Operations")

    client_entry = {
        "id": str(first_sample.client.id), "code": first_sample.client.code,
        "name": first_sample.client.name, "active": True,
    }
    clients = payload.setdefault("clients", [])
    if not any(str(item.get("id")) == client_entry["id"] or item.get("code") == client_entry["code"] for item in clients):
        clients.append(client_entry)

    sample_meta = {}
    for sample, _, _ in prepared:
        key = (sample.lms_number or sample.request_number).upper()
        sample_meta[key] = _lab_sample_metadata(db, sample)

    due_values = sorted(sample.due_at for sample, _, _ in prepared if sample.due_at is not None)
    tat_values = sorted({str(sample.required_tat or "").strip() for sample, _, _ in prepared if str(sample.required_tat or "").strip()})
    project_refs = sorted({ref for sample, _, _ in prepared if (ref := _sample_project_reference(db, sample))})
    generated_id = batch_id or f"LB-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}-{uuid4().hex[:6].upper()}"
    room_temp = next((m["roomTemp"] for m in sample_meta.values() if m.get("roomTemp")), "")
    room_humidity = next((m["roomHumidity"] for m in sample_meta.values() if m.get("roomHumidity")), "")
    status_map = {"REGISTERED": "Waiting Receipt", "RECEIVED": "Received", "READY_FOR_LAB": "Ready for Testing", "TESTING": "Testing", "TECHNICAL_REVIEW": "Technical Review"}
    batch = {
        "id": generated_id,
        "template": first_package.get("name", first_sample.requested_package),
        "package_id": first_package.get("id", "PLATFORM"),
        "method_family": first_family,
        "client_id": str(first_sample.client.id), "client_name": first_sample.client.name, "client_code": first_sample.client.code,
        "priority": first_priority,
        "required_tat": tat_values[0] if len(tat_values) == 1 else (" / ".join(tat_values) if tat_values else ""),
        "due_at": due_values[0].isoformat() if due_values else "",
        "project_reference": project_refs[0] if len(project_refs) == 1 else (" / ".join(project_refs) if project_refs else ""),
        "site": site.code,
        "samples": sample_keys,
        "sample_meta": sample_meta,
        "roomTemp": room_temp,
        "roomHumidity": room_humidity,
        "note": f"Released from Sample Intake & Receiving as one controlled Lab Batch ({len(sample_keys)} sample{'s' if len(sample_keys) != 1 else ''}).",
        "tests": first_package.get("tests", []),
        "status": status_map.get(phase, "Ready for Testing"),
        "created_at": datetime.utcnow().isoformat(),
        "platform_sample_ids": [sample.id for sample, _, _ in prepared],
    }
    if len(prepared) == 1:
        batch["platform_sample_id"] = first_sample.id
    payload.setdefault("batches", []).append(batch)
    auto_assignments = ensure_analytical_rotation_assignments(
        db,
        site.id,
        payload,
        _batch_workstations(batch),
    )
    if auto_assignments:
        payload.setdefault("batchHistory", []).insert(0, {
            "id": f"BH-AUTO-ASSIGN-{generated_id}",
            "action": "Automatic 14-Day Analytical Assignment",
            "sample": " / ".join(sample_keys),
            "from_batch": generated_id,
            "to_batch": generated_id,
            "reason": "Routine analytical workstations assigned automatically for the active 14-day cycle.",
            "details": " · ".join(f"{row['workstation']} → {row['primary_name']}" for row in auto_assignments),
            "by": "TSCO Auto Assignment",
            "ts": datetime.utcnow().isoformat(),
        })

    for sample, _, _ in prepared:
        key = (sample.lms_number or sample.request_number).upper()
        _reserve_retained_storage(payload, key)
        payload.setdefault("batchHistory", []).insert(0, {
            "id": f"BH-PLATFORM-{sample.id}-{generated_id}",
            "action": "Platform Sample Released in Lab Batch",
            "sample": key,
            "from_batch": "Sample Intake & Receiving",
            "to_batch": generated_id,
            "reason": f"{sample.request_number} released in controlled Lab Batch {generated_id}",
            "details": f"{first_sample.client.name} · {first_family} · {first_package.get('name', first_sample.requested_package)} · {first_priority}",
            "by": actor.full_name if actor else "TSCO Platform",
            "ts": datetime.utcnow().isoformat(),
        })
    save_operations_state(db, state, payload, actor)
    return generated_id


def sync_sample_to_operations(db: Session, sample: SampleRequest, actor: User | None = None, phase: str = "REGISTERED") -> None:
    """Compatibility wrapper. New intake releases should call sync_samples_to_operations."""
    sync_samples_to_operations(db, [sample], actor=actor, phase=phase)

def reconcile_operations_to_platform(db: Session, payload: dict[str, Any], site_id: int, actor: User | None = None) -> int:
    """Propagate analytical/testing progress back to the platform timeline.

    Official report release is not inferred from the browser-side Result Worksheet. It is
    created only by the server-side Final Controlled Report approval path.
    """
    from ..models import CustodyEvent, SampleStatus

    samples = db.scalars(select(SampleRequest).where(SampleRequest.site_id == site_id)).all()
    results_keys = {str(row.get("sample", "")).upper() for row in payload.get("results", [])}
    reports = {str(row.get("sample", "")).upper(): row for row in payload.get("reports", [])}
    batch_status: dict[str, str] = {}
    for batch in payload.get("batches", []):
        for key in batch.get("samples", []):
            batch_status[str(key).upper()] = str(batch.get("status", ""))

    rank = {
        SampleStatus.SUBMITTED.value: 1,
        SampleStatus.ACCEPTED.value: 2,
        SampleStatus.AWAITING_RECEIPT.value: 3,
        SampleStatus.RECEIVED.value: 4,
        SampleStatus.READY_FOR_LAB.value: 5,
        SampleStatus.REGISTERED.value: 5,
        SampleStatus.TESTING.value: 6,
        SampleStatus.TECHNICAL_REVIEW.value: 7,
        SampleStatus.REPORT_APPROVED.value: 8,
        SampleStatus.READY_FOR_LMS.value: 8,  # legacy compatibility only
        SampleStatus.REPORT_RELEASED.value: 9,
    }
    changed = 0
    for sample in samples:
        keys = {sample.request_number.upper()}
        if sample.lms_number:
            keys.add(sample.lms_number.upper())
        target = sample.status
        report = next((reports[key] for key in keys if key in reports), None)
        statuses = [batch_status.get(key, "").lower() for key in keys]
        has_technical = any("technical" in value or "review" in value for value in statuses)
        has_testing = bool(keys & results_keys) or any("testing" in value for value in statuses)
        ready_for_technical_review, _ = _platform_sample_lab_readiness_from_payload(payload, sample)

        # Result Worksheets never change report approval/release status in standalone mode.
        if has_technical or ready_for_technical_review:
            target = SampleStatus.TECHNICAL_REVIEW.value
        elif has_testing:
            target = SampleStatus.TESTING.value

        if rank.get(target, 0) > rank.get(sample.status, 0):
            sample.status = target
            from .commercial import sync_case_from_sample
            sync_case_from_sample(db, sample, actor, note="Laboratory operations synchronized business journey")
            event_type = {
                SampleStatus.TESTING.value: "LAB_RESULTS_IN_PROGRESS",
                SampleStatus.TECHNICAL_REVIEW.value: "TECHNICAL_REVIEW_STARTED",
            }.get(target, "LAB_STATUS_SYNC")
            exists = db.scalar(
                select(CustodyEvent.id).where(
                    CustodyEvent.sample_request_id == sample.id,
                    CustodyEvent.event_type == event_type,
                )
            )
            if not exists:
                db.add(
                    CustodyEvent(
                        sample_request_id=sample.id,
                        event_type=event_type,
                        status=target,
                        actor_id=actor.id if actor else None,
                        note="Synchronized from Full Laboratory Operations; official report release remains controlled by Final Controlled Reports",
                        event_at=datetime.utcnow(),
                    )
                )
            changed += 1
    return changed
