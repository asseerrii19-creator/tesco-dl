from pathlib import Path

from app.services.lab_operations import _result_qc_context, _server_qc_status

ROOT = Path(__file__).resolve().parents[1]


def test_seed_maps_pf_and_tan_assets_to_exact_workstations_and_methods():
    source = (ROOT / "app" / "seed.py").read_text(encoding="utf-8")
    assert '("EQ-26","Megger OTD LG2-P3 Power/Dissipation Factor Instrument","Electrical","ASTM D924 / IEC 60247 / ASTM D1169")' in source
    assert '("EQ-79","Metrohm 907 Titrando","TAN / Peroxide / RSH / H2S","ASTM D664 / ASTM D3703 / UOP 163")' in source
    assert '("EQ-80","Metrohm 907 Titrando","TAN / Peroxide / RSH / H2S","ASTM D664 / ASTM D3703 / UOP 163")' in source


def test_appearance_never_inherits_color_qc():
    batch = {"tests": [
        {"test": "Color ASTM", "method": "ASTM D1500", "station": "Physical / Chemistry"},
        {"test": "Appearance", "method": "ASTM D1524", "station": "Physical / Chemistry"},
    ]}
    ctx = _result_qc_context(batch, {"test": "Appearance", "display_test": "Appearance"})
    assert ctx["group"] == "Appearance"
    assert ctx["method"] == "ASTM D1524"
    assert ctx["observational"] == "1"


def test_dga_component_qc_is_server_authoritative_per_analyte():
    payload = {}
    row = {"test": "DGA", "qc_components": [
        {"key": "H2", "name": "H2", "target": 25, "result": 25.0},
        {"key": "CH4", "name": "CH4", "target": 25, "result": 26.0},
    ]}
    status, detail, profile = _server_qc_status(payload, row)
    assert status == "PASS"
    assert profile is None
    assert len(row["qc_components"]) == 2
    assert all(x["status"] == "PASS" for x in row["qc_components"])

    bad = {"test": "DGA", "qc_components": [
        {"key": "H2", "name": "H2", "target": 25, "result": 27.0},
    ]}
    status, _, _ = _server_qc_status(payload, bad)
    assert status == "FAIL"
    assert bad["qc_components"][0]["status"] == "FAIL"


def test_frontend_closes_current_workstation_without_cross_station_oqi_and_has_409_reconcile():
    source = (ROOT / "app" / "lab_ops" / "index_template.html").read_text(encoding="utf-8")
    assert "function workstationResultsComplete(b,workstation)" in source
    assert "oil quality index|oqin" in source
    assert "function mergeConflictState(remote,local)" in source
    assert "async function reconcile409AndRetry(localPayload)" in source
    assert "409" in source


def test_bdv_is_file_driven_method_defined_run_workflow_and_rsd_not_manual_entry():
    source = (ROOT / "app" / "lab_ops" / "index_template.html").read_text(encoding="utf-8")
    assert 'class="electrical-csv"' in source
    assert "IEC 60156 uses 6 breakdowns; ASTM D1816/D877 use 5." in source
    assert "Imported from the BDV instrument run set." in source
    assert "Awaiting BDV File" in source
    assert "RSD% = SD ÷ Average × 100" in source
    assert "secondary_result" in source
