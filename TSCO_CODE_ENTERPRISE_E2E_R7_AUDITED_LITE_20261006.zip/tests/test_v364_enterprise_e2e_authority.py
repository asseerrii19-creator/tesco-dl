from __future__ import annotations

import html as html_lib
import json
import re
from datetime import datetime
from pathlib import Path
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import (
    Asset, Client, CommercialCase, CommercialRequestLine, ControlledReport,
    PurchaseOrder, Quotation, Role, SampleRequest, SamplingAssignment,
    SamplingOrder, Site, User,
)
from app.review_personas import REVIEW_PERSONAS
from app.services.lab_operations import get_operations_state, save_operations_state
from app.services.scope import can_access_client


def login(browser: TestClient, email: str) -> None:
    r = browser.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303, (email, r.status_code, r.text[:300])


def logout(browser: TestClient) -> None:
    browser.post('/logout', follow_redirects=False)


EXPECTED_LANDINGS = {
    Role.MANAGEMENT.value: '/management',
    Role.EXCELLENCE.value: '/improvement',
    Role.CORPORATE_SUPPORT.value: '/gm-office',
    Role.SALES_MARKETING.value: '/commercial',
    Role.OPERATIONS_MANAGER.value: '/operations',
    Role.SAMPLING_SUPERVISOR.value: '/sampling-supervision',
    Role.DATA_ENTRY.value: '/intake',
    Role.FIELD_SAMPLER.value: '/field',
    Role.CLIENT_COORDINATOR.value: '/commercial',
    Role.TECHNICAL_MANAGER.value: '/management',
    Role.SENIOR_CHEMIST.value: '/lab',
    Role.LAB_TECHNICIAN.value: '/lab/operations?section=workstations',
    Role.LAB_SUPPORT.value: '/lab-support',
}


def test_all_current_internal_personas_and_clients_have_authorized_home_and_critical_surfaces():
    accounts = [(p.email, EXPECTED_LANDINGS[p.role]) for p in REVIEW_PERSONAS]
    accounts += [('client@sec.local', '/client'), ('client@aramco.local', '/client'), ('admin@tsco.local', '/admin')]
    critical = {
        'general.manager@tsco.local': ['/management', '/operations', '/commercial'],
        'excellence.specialist@tsco.local': ['/improvement', '/quality', '/documents'],
        'secretary@tsco.local': ['/gm-office', '/organization/employees'],
        'sales.marketing.specialist@tsco.local': ['/commercial'],
        'salesman@tsco.local': ['/commercial'],
        'field.manager@tsco.local': ['/operations', '/operations/orders', '/sampling-supervision', '/operations/field-progress', '/commercial'],
        'sampling.supervisor@tsco.local': ['/sampling-supervision', '/operations/field-progress'],
        'data.entry@tsco.local': ['/intake'],
        'sampleman@tsco.local': ['/field'],
        'client.coordinator@tsco.local': ['/commercial'],
        'external.coordination@tsco.local': ['/commercial'],
        'lab.manager@tsco.local': ['/management', '/lab', '/assessment', '/control/reports', '/operations'],
        'senior.technical@tsco.local': ['/lab', '/assessment', '/control/reports', '/improvement/responsibilities'],
        'senior.equipment@tsco.local': ['/lab', '/assessment', '/control/reports', '/improvement/responsibilities'],
        'senior.improvement@tsco.local': ['/lab', '/assessment', '/control/reports', '/improvement/responsibilities'],
        'chemist@tsco.local': ['/lab', '/lab/operations?section=workstations', '/control/my-quality-tasks', '/documents'],
        'technician@tsco.local': ['/lab', '/lab/operations?section=workstations', '/control/my-quality-tasks', '/documents'],
        'lab.support@tsco.local': ['/lab-support', '/housekeeping'],
        'client@sec.local': ['/client'],
        'client@aramco.local': ['/client'],
        'admin@tsco.local': ['/admin', '/admin/users', '/admin/workflows'],
    }
    with TestClient(app) as browser:
        for email, expected in accounts:
            logout(browser); login(browser, email)
            home = browser.get('/', follow_redirects=False)
            assert home.status_code == 303, (email, home.status_code)
            assert home.headers.get('location') == expected, (email, expected, home.headers.get('location'))
            for href in critical[email]:
                response = browser.get(href, follow_redirects=False)
                assert response.status_code == 200, (email, href, response.status_code, response.text[:250])
                assert 'section=supervisor' not in response.headers.get('location', '')

    # The persistent navigation itself must not expose the retired browser-state supervisor/dashboard surfaces.
    base = (Path(__file__).resolve().parents[1] / 'app' / 'templates' / 'base.html').read_text(encoding='utf-8')
    assert "item('/lab/operations?section=supervisor'" not in base
    assert "item('/lab/operations?section=dashboard'" not in base


def test_three_seniors_share_server_review_queue_but_keep_distinct_responsibility_domains():
    senior_emails = {
        'senior.technical@tsco.local': 'TECHNICAL',
        'senior.equipment@tsco.local': 'EQUIPMENT',
        'senior.improvement@tsco.local': 'IMPROVEMENT',
    }
    with TestClient(app) as browser:
        with SessionLocal() as db:
            users = {row.email: row for row in db.scalars(select(User).where(User.email.in_(senior_emails))).all()}
            assert set(users) == set(senior_emails)
            assert all(users[email].role == Role.SENIOR_CHEMIST.value for email in senior_emails)
        for email, domain in senior_emails.items():
            logout(browser); login(browser, email)
            page = browser.get('/lab')
            assert page.status_code == 200
            assert 'Canonical Laboratory Workflow' in page.text
            resp = browser.get('/improvement/responsibilities')
            assert resp.status_code == 200
            assert domain.lower() in resp.text.lower() or 'Senior Chemist' in resp.text


def test_client_to_official_report_enterprise_e2e_with_three_seniors_manager_gm_and_client_visibility():
    token = uuid4().hex[:8].upper()
    with TestClient(app) as browser:
        # 1) Client creates one controlled custom-test service request.
        login(browser, 'client@sec.local')
        created = browser.post('/client/requests', data={
            'lead_title': f'Enterprise E2E {token}', 'client_message': 'End-to-end authority verification',
            'sample_delivery_mode': 'TSCO_COLLECTION', 'sample_delivery_notes': 'TSCO field sampling required',
        }, follow_redirects=False)
        assert created.status_code == 303, created.text[:300]
        case_id = int(created.headers['location'].rstrip('/').split('/')[-1])
        line = browser.post(f'/client/requests/{case_id}/lines', data={
            'quantity': 1, 'requested_package': 'CUSTOM', 'method_family': 'IEC',
            'priority': 'NORMAL', 'required_tat': '', 'due_at': '', 'expected_serials': '',
            'requested_tests': 'Water Content KF @RT',
        }, follow_redirects=False)
        assert line.status_code == 303, line.text[:500]
        submit = browser.post(f'/client/requests/{case_id}/submit', data={'client_message': ''}, follow_redirects=False)
        assert submit.status_code == 303, submit.text[:500]
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case
            assert case.assigned_coordinator_id
            coordinator = db.get(User, case.assigned_coordinator_id); assert coordinator
            assert coordinator.role == Role.CLIENT_COORDINATOR.value
            coordinator_email = coordinator.email
            request_line = db.scalar(select(CommercialRequestLine).where(CommercialRequestLine.commercial_case_id == case_id)); assert request_line
            line_id = request_line.id
            sec = db.scalar(select(Client).where(Client.code == 'SEC')); assert sec
            asset = db.scalar(select(Asset).where(Asset.client_id == sec.id, Asset.active.is_(True))); assert asset
            client_id, asset_id = sec.id, asset.id

        # 2) Assigned Coordinator issues quote; client accepts and uploads PO.
        logout(browser); login(browser, coordinator_email)
        quote_no = f'QT-E2E-{token}'
        q = browser.post(f'/commercial/cases/{case_id}/advance', data={
            'target_stage': 'QUOTATION', 'quotation_number': quote_no, 'note': '', 'reference': '',
        }, follow_redirects=False)
        assert q.status_code == 303, q.text[:500]
        logout(browser); login(browser, 'client@sec.local')
        accepted = browser.post(f'/client/requests/{case_id}/quotation-decision', data={'decision': 'ACCEPT', 'note': 'Accepted for E2E'}, follow_redirects=False)
        assert accepted.status_code == 303, accepted.text[:500]
        po_no = f'PO-E2E-{token}'
        po = browser.post(
            f'/client/requests/{case_id}/purchase-order',
            data={'purchase_order_number': po_no},
            files={'upload': ('po.pdf', b'%PDF-1.4\n% enterprise e2e\n', 'application/pdf')},
            follow_redirects=False,
        )
        assert po.status_code == 303, po.text[:500]

        # 3) Coordinator completes controlled handover.
        logout(browser); login(browser, coordinator_email)
        handover = browser.post(f'/commercial/cases/{case_id}/advance', data={
            'target_stage': 'COMPLETE_HANDOVER',
            'handover_commercial': 'Quotation and PO verified',
            'handover_technical': 'One Water Content KF @RT sample / IEC',
            'handover_client_info': 'TSCO sampling; client data confirmed',
            'note': 'Controlled handover complete', 'reference': '',
            'expected_samples': '', 'requested_test_package': '', 'default_priority': 'NORMAL', 'required_tat': '',
        }, follow_redirects=False)
        assert handover.status_code == 303, handover.text[:500]
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case
            assert case.request_status == 'HANDOVER_COMPLETE'
            quote_id, po_id = case.quotation_id, case.purchase_order_id
            assert db.get(Quotation, quote_id).status == 'CLIENT_ACCEPTED'
            assert db.get(PurchaseOrder, po_id).status == 'ACTIVE'
            supervisor = db.scalar(select(User).where(User.email == 'sampling.supervisor@tsco.local')); assert supervisor
            supervisor_id = supervisor.id
            sampler = db.scalar(select(User).where(User.email == 'sampleman@tsco.local')); assert sampler
            sampler_id = sampler.id

        # 4) Field Manager must accept CLIENT_ACCEPTED quote and create order/assignment.
        logout(browser); login(browser, 'field.manager@tsco.local')
        order = browser.post('/operations/orders', data={
            'client_id': client_id, 'quotation_id': quote_id, 'purchase_order_id': po_id,
            'supervisor_id': supervisor_id, 'title': f'E2E Sampling {token}', 'priority': 'Normal',
            'due_at': '', 'notes': 'Enterprise E2E order', 'sampling_request_id': '', 'operational_project_id': '',
        }, follow_redirects=False)
        assert order.status_code == 303, order.text[:800]
        with SessionLocal() as db:
            so = db.scalar(select(SamplingOrder).where(SamplingOrder.commercial_case_id == case_id).order_by(SamplingOrder.id.desc())); assert so
            order_id = so.id
        assignment = browser.post(f'/operations/orders/{order_id}/assignments', data={
            'asset_id': asset_id, 'commercial_request_line_id': line_id, 'sample_count': 1,
            'sample_label': f'E2E Main Tank {token}', 'source_party': 'TSCO', 'task_type': 'ON_SITE_SAMPLING',
            'requested_package': 'CUSTOM', 'sampling_point': 'Main Tank Bottom', 'container_count': 1,
            'instructions': 'Collect one transformer oil sample',
        }, follow_redirects=False)
        assert assignment.status_code == 303, assignment.text[:800]
        with SessionLocal() as db:
            sa = db.scalar(select(SamplingAssignment).where(SamplingAssignment.order_id == order_id).order_by(SamplingAssignment.id.desc())); assert sa
            assignment_id = sa.id

        # 5) Sampling Supervisor names the Sampleman; named assignment alone grants temporary client scope.
        logout(browser); login(browser, 'sampling.supervisor@tsco.local')
        assigned = browser.post(f'/sampling-supervision/assignment/{assignment_id}/assign', data={
            'sampler_id': sampler_id, 'note': 'Assigned for enterprise E2E',
        }, follow_redirects=False)
        assert assigned.status_code == 303, assigned.text[:500]
        with SessionLocal() as db:
            sampler_row = db.get(User, sampler_id); assert sampler_row
            assert can_access_client(db, sampler_row, client_id) is True
        logout(browser); login(browser, 'sampleman@tsco.local')
        field = browser.post('/field/new', data={
            'assignment_id': assignment_id, 'client_id': client_id, 'quotation_id': quote_id, 'purchase_order_id': po_id,
            'existing_asset_id': asset_id, 'sample_date_time': '2026-10-06T08:00',
            'sampling_point': 'Main Tank Bottom', 'requested_package': 'CUSTOM', 'container_count': 1,
            'oil_temperature_c': '40', 'field_notes': 'Enterprise E2E sample',
        }, follow_redirects=False)
        assert field.status_code == 303, field.text[:800]
        with SessionLocal() as db:
            sample = db.scalar(select(SampleRequest).where(SampleRequest.sampling_assignment_id == assignment_id)); assert sample
            sample_id, request_number = sample.id, sample.request_number
            assert sample.commercial_case_id == case_id
            assert sample.status == 'SUBMITTED'

        # 6) Data Entry accepts, receives, and releases to the lab.
        logout(browser); login(browser, 'data.entry@tsco.local')
        assert browser.post('/intake/bulk-decision', data={'sample_ids': [sample_id], 'note': 'Data verified'}, follow_redirects=False).status_code == 303
        assert browser.post('/intake/bulk-receive', data={'sample_ids': [sample_id], 'seal_status': 'Intact', 'condition_note': 'Received intact'}, follow_redirects=False).status_code == 303
        assert browser.post('/intake/batch-release', data={'sample_ids': [sample_id], 'note': 'Released to laboratory'}, follow_redirects=False).status_code == 303

        # 7) Controlled laboratory state: one required Water result + assigned workstation completion.
        with SessionLocal() as db:
            sample = db.get(SampleRequest, sample_id); assert sample and sample.status == 'READY_FOR_LAB'
            site = db.get(Site, sample.site_id); assert site
            chem = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert chem
            senior = db.scalar(select(User).where(User.email == 'senior.technical@tsco.local')); assert senior
            state, payload = get_operations_state(db, site)
            batch = next(b for b in payload.get('batches', []) if sample_id in (b.get('platform_sample_ids') or []))
            batch_id = batch['id']
            # Preserve the production-generated batch; add only controlled analytical evidence.
            payload.setdefault('results', []).append({
                'id': f'R-E2E-{token}', 'batch': batch_id, 'sample': request_number,
                'test': 'WATER:KF_RT', 'display_test': 'Water Content KF @RT', 'result': '12.4',
                'unit': 'mg/kg', 'method': 'IEC 60814', 'qc_status': 'PASS',
                'analyst': chem.full_name, 'ts': datetime.utcnow().isoformat(),
            })
            water_assignments = [a for a in payload.get('testAssignments', []) if a.get('workstation') == 'Water' and a.get('batch_id') in {batch_id, '*'}]
            assert water_assignments, payload.get('testAssignments', [])
            water_assignments.sort(key=lambda a: (0 if a.get('batch_id') == batch_id else -1, int(a.get('revision') or 0), str(a.get('assigned_at') or '')))
            active_assignment = water_assignments[-1]
            payload.setdefault('assignmentCompletions', []).append({
                'id': f'C-E2E-{token}', 'batch_id': batch_id, 'workstation': 'Water',
                'assignment_id': active_assignment['id'], 'completed_by_user_id': chem.id,
                'completed_by': chem.full_name, 'completed_at': datetime.utcnow().isoformat(),
            })
            save_operations_state(db, state, payload, actor=senior)
            db.commit()

        # 8) Any of the three Senior Chemists must see the same server-derived review-ready sample.
        for senior_email in ('senior.technical@tsco.local', 'senior.equipment@tsco.local', 'senior.improvement@tsco.local'):
            logout(browser); login(browser, senior_email)
            queue = browser.get('/lab')
            assert queue.status_code == 200
            assert request_number in queue.text, (senior_email, request_number)
            assert 'Ready for Senior technical review' in queue.text
        with SessionLocal() as db:
            sample = db.get(SampleRequest, sample_id); assert sample and sample.status == 'TECHNICAL_REVIEW'
            case = db.get(CommercialCase, case_id); assert case and case.request_status == 'TECHNICAL_REVIEW'

        # 9) Senior technical review -> Lab Manager final approval/release.
        logout(browser); login(browser, 'senior.technical@tsco.local')
        report_no = f'TSCO-E2E-{token}'
        created_report = browser.post('/control/report', data={
            'sample_request_id': sample_id, 'report_number': report_no, 'condition_status': 'NORMAL',
            'interpretation': 'Water content reviewed against the controlled result.',
            'recommendation': 'Continue routine monitoring.', 'dga_requested': '', 'corrosive_requested': '', 'paper_requested': '',
            'supersedes_report_id': '', 'amendment_reason': '',
        }, follow_redirects=False)
        assert created_report.status_code == 303, created_report.text[:800]
        with SessionLocal() as db:
            report = db.scalar(select(ControlledReport).where(ControlledReport.report_number == report_no)); assert report
            report_id = report.id
        completed_review = browser.post(f'/control/report/{report_id}/review', data={
            'action': 'COMPLETE', 'condition_status': 'NORMAL',
            'interpretation': 'Water content reviewed against the controlled result.',
            'recommendation': 'Continue routine monitoring.',
            'confirm_results': '1', 'confirm_identity': '1', 'confirm_interpretation': '1',
            'confirm_evidence': '1', 'confirm_recommendation': '1',
        }, follow_redirects=False)
        assert completed_review.status_code == 303, completed_review.text[:800]
        with SessionLocal() as db:
            assert db.get(SampleRequest, sample_id).status == 'REPORT_APPROVED'
            assert db.get(CommercialCase, case_id).request_status == 'PENDING_FINAL_APPROVAL'

        logout(browser); login(browser, 'lab.manager@tsco.local')
        approved = browser.post(f'/control/report/{report_id}/approve', follow_redirects=False)
        assert approved.status_code == 303, approved.text[:1000]
        with SessionLocal() as db:
            sample = db.get(SampleRequest, sample_id); report = db.get(ControlledReport, report_id); case = db.get(CommercialCase, case_id)
            assert sample.status == 'REPORT_RELEASED'
            assert report.status == 'REPORT_RELEASED'
            assert case.request_status == 'REPORT_RELEASED'
            assert report.official_pdf_path and Path(report.official_pdf_path).is_file()
            assert report.official_pdf_sha256 and len(report.official_pdf_sha256) == 64

        # 10) General Manager sees the same canonical released workflow; client sees the official report only after release.
        logout(browser); login(browser, 'general.manager@tsco.local')
        gm = browser.get('/management')
        assert gm.status_code == 200
        assert request_number in gm.text
        assert 'REPORT RELEASED' in gm.text.upper() or 'REPORT_RELEASED' in gm.text.upper()

        logout(browser); login(browser, 'client@sec.local')
        dashboard = browser.get('/client')
        assert dashboard.status_code == 200
        assert request_number in dashboard.text
        assert f'/control/report/{report_id}/preview' in dashboard.text
        assert f'/control/report/{report_id}/pdf' in dashboard.text
        preview = browser.get(f'/control/report/{report_id}/preview')
        assert preview.status_code == 200 and report_no in preview.text
        detail = browser.get(f'/client/requests/{case_id}')
        assert detail.status_code == 200
        assert 'official TSCO Analysis Report has been released' in detail.text
        pdf = browser.get(f'/control/report/{report_id}/pdf', follow_redirects=False)
        assert pdf.status_code == 200
        assert 'application/pdf' in pdf.headers.get('content-type', '')

        # 11) Assigned Coordinator records the controlled client submission; client sees final submission state.
        logout(browser); login(browser, coordinator_email)
        submitted = browser.post(f'/control/report/{report_id}/submission', data={
            'channel': 'PORTAL', 'recipient': 'SEC Client Portal',
            'submission_reference': f'SUB-E2E-{token}', 'note': 'Official report delivered through portal',
        }, follow_redirects=False)
        assert submitted.status_code == 303, submitted.text[:800]
        logout(browser); login(browser, 'client@sec.local')
        detail = browser.get(f'/client/requests/{case_id}')
        assert detail.status_code == 200
        assert 'client submission record is complete' in detail.text
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case and case.request_status == 'REPORT_SUBMITTED'
            # Named sampler access is temporary: once assignment is complete, no active assignment remains.
            sa = db.get(SamplingAssignment, assignment_id); assert sa and sa.completed_sample_id == sample_id and sa.status == 'COMPLETED'
            sampler_row = db.get(User, sampler_id); assert sampler_row
            assert can_access_client(db, sampler_row, client_id) is False


def test_client_accepted_quotation_is_valid_for_operations_and_online_offline_field_paths():
    operations = (Path(__file__).resolve().parents[1] / 'app' / 'routes' / 'operations.py').read_text(encoding='utf-8')
    field = (Path(__file__).resolve().parents[1] / 'app' / 'routes' / 'field.py').read_text(encoding='utf-8')
    assert 'quote.status not in {"ACTIVE", "CLIENT_ACCEPTED"}' in operations
    # create_sample + offline_sync must apply the same accepted-quotation rule.
    assert field.count('quote.status not in {"ACTIVE", "CLIENT_ACCEPTED"}') >= 2
