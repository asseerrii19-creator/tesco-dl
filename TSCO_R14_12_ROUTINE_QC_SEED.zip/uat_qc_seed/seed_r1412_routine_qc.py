"""One-time, fail-closed R14.12 isolated UAT fixture job; never a QC bypass.

Run from release_current: python uat_qc_seed/seed_r1412_routine_qc.py --apply
Uses existing registration/activation domain services, exact existing users, ORM
row locks and normal audit records. No schema changes, new users or sample runs.
"""
from __future__ import annotations
import argparse
import base64
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import sys
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent))
TAG = 'R14.12-UAT-DEMO'
BATCH = 'LB-20261012125724-C8CB28'
SAMPLE = 'FS-DMM-26-000001'
SERVICE = 'srv-db68h54s728c73fij1o0'
HOST = 'tsco-r14-12-isolated-check.onrender.com'
REGISTRAR = 'UAT Role — Chemical Technician'
REVIEWER = 'UAT Role — Senior Chemist (Technical)'


def guard_environment():
    if os.getenv('TSCO_UAT_QC_SEED_CONFIRM') != TAG + ':' + BATCH:
        raise ValueError('Explicit isolated UAT job confirmation is required')
    if os.getenv('RENDER_SERVICE_ID') != SERVICE:
        raise ValueError('Refusing any service other than the isolated R14.12 service')
    if os.getenv('APP_ENV', '').lower() not in {'uat', 'testing', 'staging'}:
        raise ValueError('Refusing non-UAT/staging runtime')
    if urlparse(os.getenv('PUBLIC_BASE_URL', '')).hostname != HOST:
        raise ValueError('Isolated PUBLIC_BASE_URL identity mismatch')
    url = urlparse(os.getenv('DATABASE_URL', ''))
    if not url.scheme.startswith('postgresql') or not (url.hostname or '').endswith('.neon.tech'):
        raise ValueError('Existing isolated Neon PostgreSQL connection is required')
    if len(os.getenv('APP_SECRET', '')) < 32:
        raise ValueError('Use the existing staging application signing secret')


def load_fixtures():
    fixtures = json.loads((ROOT / 'fixture_manifest.json').read_text(encoding='utf-8'))
    if len(fixtures) != 8 or len({f['code'] for f in fixtures}) != 8:
        raise ValueError('Exactly eight unique Routine QC contexts required')
    if {f['code'] for f in fixtures} != {'DGA','WATER','COLOR','TAN','BDV','IFT','PF25','PF100'}:
        raise ValueError('Unexpected test in fixture scope')
    if sum(len(f['equipment']) for f in fixtures) != 18:
        raise ValueError('Exact 18 equipment bindings required')
    for f in fixtures:
        if f['batch'] != BATCH or f['sample'] != SAMPLE or not f['lot'].startswith(TAG):
            raise ValueError('Fixture identity mismatch')
        raw = (ROOT / f['evidence_filename']).read_bytes()
        if TAG.encode() not in raw or b'SYNTHETIC' not in raw or not raw:
            raise ValueError('Explicit synthetic evidence marker required')
        f['evidence'] = {'name':f['evidence_filename'], 'data':'data:text/csv;base64,'+base64.b64encode(raw).decode()}
        f['evidence_sha256'] = hashlib.sha256(raw).hexdigest()
    return fixtures


def unique(rows, description):
    if len(rows) != 1:
        raise ValueError(f'Expected exactly one existing {description}; found {len(rows)}')
    return rows[0]


def seed_transaction(db, fixtures, apply=False):
    from sqlalchemy import select, or_
    from app.models import Site, User, EquipmentAsset, OperationsState, SampleRequest
    from app.services.qc_lifecycle import register_lot, decide_lot, active_lot
    from app.services.lab_operations import (_result_qc_context, _batch_test_rows,
        _qc_source_package_test, _validated_qc_equipment, save_operations_state,
        scope_operations_payload, _analytical_qc_schedule_state)
    from app.services.audit import add_audit

    site = unique(list(db.scalars(select(Site).where(Site.code=='DMM'))), 'DMM site')
    # Serialize this job with normal HTTP lot writes and concurrent reruns.
    state = unique(list(db.scalars(select(OperationsState).where(OperationsState.site_id==site.id).with_for_update())), 'existing OperationsState')
    payload = json.loads(state.json_data)
    original = deepcopy(payload)
    batch = unique([b for b in payload.get('batches',[]) if b.get('id')==BATCH], 'target batch')
    if list(map(str,batch.get('samples',[]))) != [SAMPLE]:
        raise ValueError('The target batch must contain only the unchanged target sample')
    sample = unique(list(db.scalars(select(SampleRequest).where(SampleRequest.site_id==site.id,
        or_(SampleRequest.request_number==SAMPLE, SampleRequest.lms_number==SAMPLE)).with_for_update())), 'existing target sample')
    sample_snapshot = {c.name:deepcopy(getattr(sample,c.name)) for c in SampleRequest.__table__.columns}
    if sample.requested_package != 'Routine Test':
        raise ValueError('The target sample is not Routine Test')
    registrar = unique(list(db.scalars(select(User).where(User.site_id==site.id, User.active.is_(True),
        User.full_name==REGISTRAR, User.role=='lab_technician'))), 'active UAT Chemical Technician')
    reviewer = unique(list(db.scalars(select(User).where(User.site_id==site.id, User.active.is_(True),
        User.full_name==REVIEWER, User.role=='senior_chemist', User.senior_responsibility_domain=='TECHNICAL'))), 'active UAT Technical Senior')
    if registrar.id == reviewer.id:
        raise ValueError('Independent preparer and approver are required')
    actual = {(t['test'],t['method']) for t in _batch_test_rows(batch) if _qc_source_package_test(t)}
    expected = {(f['test'],f['method']) for f in fixtures}
    if actual != expected:
        raise ValueError('Runtime measured Routine QC scope differs from the eight approved contexts')

    report = {'tag':TAG,'batch':BATCH,'sample':SAMPLE,'mode':'APPLIED' if apply else 'DRY_RUN',
        'preparer':{'id':registrar.id,'name':registrar.full_name},
        'approver':{'id':reviewer.id,'name':reviewer.full_name},'lots':[],
        'sample_results_entered':0,'daily_qc_runs_entered':0,
        'approval_origin':'User-authorized synthetic UAT bootstrap; no browser sign-in or claim of real qualification'}
    for f in fixtures:
        ctx = _result_qc_context(batch, {'test':f['test']})
        equipment=[]
        for code in f['equipment']:
            eq=unique(list(db.scalars(select(EquipmentAsset).where(EquipmentAsset.site_id==site.id,
                EquipmentAsset.equipment_id==code,EquipmentAsset.active.is_(True)))),code)
            _validated_qc_equipment(db,site.id,equipment_asset_id=eq.id,workstation=ctx['workstation'],method_name=ctx['method'])
            equipment.append(eq)
        ids=[eq.id for eq in equipment]
        candidates=[l for l in payload.get('qualifiedQcProfiles',[]) if l.get('lot_number')==f['lot']]
        if len(candidates)>1:
            raise ValueError('Duplicate existing demo lot; refuse to repair silently')
        if candidates:
            lot=candidates[0]
            checks={'lifecycle':'CONTROLLED_LOT','context_test':f['test'],'method_name':f['method'],
                'material':f['material'],'mean':f['target'],'lcl2':f['low'],'ucl2':f['high'],
                'valid_from':f['valid_from'],'valid_until':f['valid_until'],
                'prepared_by_user_id':registrar.id,'uat_seed_tag':TAG,'uat_batch_id':BATCH}
            if any(lot.get(k)!=v for k,v in checks.items()) or set(lot.get('equipment_ids',[]))!=set(ids):
                raise ValueError('Existing fixture differs; refuse mutation/duplicate')
            if lot.get('evidence',{}).get('sha256') != f['evidence_sha256']:
                raise ValueError('Existing fixture evidence differs')
            if lot.get('status') not in {'PENDING_SENIOR','ACTIVE'}:
                raise ValueError('Existing lot closed/rejected/superseded; no silent reactivation')
            if f['code']=='DGA' and (lot.get('component_targets')!=f['component_targets'] or lot.get('tolerance_pct')!=f['tolerance_pct']):
                raise ValueError('DGA fixture component targets differ')
            outcome='EXISTING'
        else:
            body={'batch_id':BATCH,'context_test':f['test'],'equipment_ids':ids,'source_type':'INTERNAL',
                'material':f['material'],'lot_number':f['lot'],'valid_from':f['valid_from'],
                'valid_until':f['valid_until'],'target':f['target'],'lower_limit':f['low'],
                'upper_limit':f['high'],'qualification':f['qualification'],'evidence':f['evidence']}
            if f['code']=='DGA':body.update(component_targets=f['component_targets'],tolerance_pct=f['tolerance_pct'])
            lot=register_lot(payload,body,registrar,db,site.id)
            lot.update(uat_seed_tag=TAG,uat_batch_id=BATCH,execution_origin='AUTHORIZED_SYNTHETIC_UAT_BOOTSTRAP')
            if apply:
                save_operations_state(db,state,payload,registrar)
                add_audit(db,actor=registrar,request=None,action='QC_LOT_REGISTERED',entity_type='QCLot',entity_id=lot['id'],
                    summary=lot['label']+' / PENDING_SENIOR',details={'origin':report['approval_origin'],'batch':BATCH,'equipment_ids':ids,'evidence_sha256':f['evidence_sha256']})
            outcome='CREATED'
        if lot['status']=='PENDING_SENIOR':
            # Never supersede another pre-existing active production/fixture lot.
            if any(l.get('id')!=lot['id'] and l.get('status')=='ACTIVE' and l.get('context_test')==f['test']
                and l.get('method_name')==f['method'] and set(l.get('equipment_ids',[]))&set(ids)
                for l in payload.get('qualifiedQcProfiles',[])):
                raise ValueError('Another active lot overlaps; independent review required; no automatic supersession')
            decide_lot(payload,lot['id'],{'action':'ACTIVATE','signed':True,
                'reason':TAG+' user-authorized synthetic UAT bootstrap qualification and activation; synthetic evidence only, not production QC or a human browser review.'},reviewer,db,site.id)
            if apply:
                save_operations_state(db,state,payload,reviewer)
                add_audit(db,actor=reviewer,request=None,action='QC_LOT_ACTIVATE',entity_type='QCLot',entity_id=lot['id'],
                    summary=lot['label']+' / ACTIVE',details={'origin':report['approval_origin'],'batch':BATCH,'equipment_ids':ids,'evidence_sha256':f['evidence_sha256'],'signature':lot['signature']})
        if lot.get('approved_by_user_id')!=reviewer.id or not lot.get('signature'):
            raise ValueError('Independent approval/signature identity mismatch')
        bindings=[]
        for eq in equipment:
            if active_lot(payload,ctx,eq.id) is not lot:
                raise ValueError('Exact equipment binding is not active/valid')
            readiness=_analytical_qc_schedule_state(payload,ctx,eq.id)
            bindings.append({'equipment_id':eq.equipment_id,'equipment_asset_id':eq.id,
                'lot_binding_active':True,'daily_qc_ready':bool(readiness.get('ready')),
                'daily_qc_reason':readiness.get('reason')})
        report['lots'].append({'id':lot['id'],'lot_number':lot['lot_number'],'test':f['test'],
            'method':f['method'],'status':lot['status'],'outcome':outcome,'equipment_bindings':bindings,
            'evidence_sha256':f['evidence_sha256']})
    for key in set(original)|set(payload):
        if key not in {'qualifiedQcProfiles','meta'} and original.get(key)!=payload.get(key):
            raise ValueError(f'Protected operational collection changed: {key}')
    if any(getattr(sample,k)!=v for k,v in sample_snapshot.items()):
        raise ValueError('Protected sample record changed')
    old_lots={l['id']:l for l in original.get('qualifiedQcProfiles',[])}
    for lot in payload['qualifiedQcProfiles']:
        if lot['id'] in old_lots and not lot.get('lot_number','').startswith(TAG) and old_lots[lot['id']]!=lot:
            raise ValueError('Unrelated QC lot changed')
    visible=scope_operations_payload(payload,registrar)
    scoped={l['id']:l for l in visible.get('qualifiedQcProfiles',[])}
    for lot in report['lots']:
        if lot['id'] not in scoped or any(k in scoped[lot['id']] for k in ('mean','lcl2','ucl2','lcl3','ucl3','component_targets','tolerance_pct')):
            raise ValueError('Technician scope or blind target-field redaction failed')
    report['checks']={'blind_target_fields_redacted':True,'sample_and_batch_unchanged':True,
        'unrelated_qc_unchanged':True,'qc_runs_unchanged':True,'analytical_results_unchanged':True}
    if not apply:db.rollback()
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply',action='store_true')
    args=parser.parse_args()
    guard_environment()
    fixtures=load_fixtures()
    from app.database import SessionLocal
    with SessionLocal() as db:
        try:
            report=seed_transaction(db,fixtures,apply=args.apply)
            if args.apply:db.commit()
        except Exception:
            db.rollback()
            raise
    # No passwords/connection strings or target values printed to runtime logs.
    print('R14.12-UAT-DEMO_QC_SEED='+json.dumps(report,ensure_ascii=False))


if __name__=='__main__':
    try:main()
    except Exception as exc:
        detail=str(exc) if isinstance(exc,(ValueError,PermissionError)) else type(exc).__name__
        print('R14.12-UAT-DEMO_QC_SEED_ABORTED: '+detail+'; no partial changes committed',file=sys.stderr)
        sys.exit(1)
