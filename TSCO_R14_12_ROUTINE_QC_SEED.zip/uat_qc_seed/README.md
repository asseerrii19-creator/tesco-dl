# R14.12-UAT-DEMO — Routine QC one-time job

STATUS: prepared and tested locally; NOT executed against the staging Neon database.
No live QCL IDs exist from this job until it is executed successfully.

Only service `tsco-r14-12-isolated-check` / `srv-db68h54s728c73fij1o0` is permitted.
Do not deploy or run on `tsco-v285-final-review`, production, or any existing UAT PostgreSQL database.
Uses the isolated service's existing Neon DATABASE_URL and APP_SECRET; no credentials are packaged or printed.

## Frozen scope

Sample: `FS-DMM-26-000001`. Batch: `LB-20261012125724-C8CB28`. Routine Test only.

| Context | Method | Equipment codes | Demo lot number |
|---|---|---|---|
| DGA | ASTM D3612 | EQ-23, EQ-64 | R14.12-UAT-DEMO-DGA-20261012 |
| Water KF @RT | ASTM D1533 | EQ-69, EQ-70 | R14.12-UAT-DEMO-WATER-20261012 |
| Color | ASTM D1500 | EQ-05 | R14.12-UAT-DEMO-COLOR-20261012 |
| TAN | ASTM D664 | EQ-79, EQ-80 | R14.12-UAT-DEMO-TAN-20261012 |
| BDV @1mm AVG | ASTM D1816 | EQ-24, EQ-25, EQ-30 | R14.12-UAT-DEMO-BDV-20261012 |
| IFT | ASTM D971 | EQ-03, EQ-04 | R14.12-UAT-DEMO-IFT-20261012 |
| PF @25°C/60Hz | ASTM D924 | EQ-130, EQ-26, EQ-49 | R14.12-UAT-DEMO-PF25-20261012 |
| PF @100°C/60Hz | ASTM D924 | EQ-130, EQ-26, EQ-49 | R14.12-UAT-DEMO-PF100-20261012 |

Eight lots, eighteen distinct Test/Method/Equipment bindings. Each Water device resolves separately to the same approved demo material/lot. No generic instrument or QC context.
All values/limits/component targets and qualification evidence are synthetic fixtures, NOT TSCO production targets, CRM certificates, actual measurement evidence or real laboratory qualification.
Validity is 12–31 October 2026 (Asia/Riyadh). Expired fixtures abort; no automatic renewal.

## Controlled execution

- Existing `UAT Role — Chemical Technician` is the registrar/preparer. Its active site assignment is checked by the existing registration service.
- Existing `UAT Role — Senior Chemist (Technical)` is the independent approver/activator. The existing domain enforces Technical domain, independent identity, valid equipment and expiry, and creates the application signature.
- Audit and rationale explicitly mark the action as **user-authorized synthetic UAT bootstrap**. This does not claim a real human browser signature or production technical qualification.
- Calls existing `register_lot`, `decide_lot`, `save_operations_state`, `add_audit`, `active_lot`, technician scoping and daily readiness services.
- Uses SQLAlchemy ORM and PostgreSQL row locks. No raw SQL, new users/roles, HTTP bypass endpoint, schema changes, changes to application QC rules, or application startup changes.
- One atomic transaction: any failure rolls back all new QC lots and associated audit records.
- Rerun reuses matching ACTIVE IDs without duplicate records, approvals, audit events or revision increments. Conflicting/rejected/closed/superseded fixtures fail closed. Other active lots are never automatically superseded.
- Existing sample and batch, analytical results, QC runs and unrelated operational collections remain unchanged.

## Run inside the isolated service runtime

The overlay archive must be extracted into `release_current` (alongside `app/`).
The existing `APP_ENV` must be `uat`, `testing` or `staging`, `RENDER_SERVICE_ID` must match the frozen service and `PUBLIC_BASE_URL` must be `https://tsco-r14-12-isolated-check.onrender.com`.
Do not replace DATABASE_URL or APP_SECRET: this job uses the already configured isolated Neon connection and signing key.

Dry run:

```bash
TSCO_UAT_QC_SEED_CONFIRM=R14.12-UAT-DEMO:LB-20261012125724-C8CB28 python uat_qc_seed/seed_r1412_routine_qc.py
```

Apply:

```bash
TSCO_UAT_QC_SEED_CONFIRM=R14.12-UAT-DEMO:LB-20261012125724-C8CB28 python uat_qc_seed/seed_r1412_routine_qc.py --apply
```

Only the apply command commits. The report prefix `R14.12-UAT-DEMO_QC_SEED=` contains the actual QCL IDs, registrar/approver IDs, exact equipment asset IDs/codes and daily QC readiness for manual verification.
Do not report dry-run IDs as created records: dry runs roll back all candidate changes.

## Safari verification after successful apply

1. Senior: Laboratory → QC Lots & Runs; verify exactly eight ACTIVE demo lots, qualification evidence and independent registrar/approver history.
2. Technician: view only assigned Routine contexts; routine entry keeps server target fields hidden and remains exact-equipment controlled.
3. Water: EQ-69 and EQ-70 each resolve to the demo Water lot; each still requires its own two startup QC runs. A lot being ACTIVE is not a daily PASS.
4. Other devices: daily QC still required separately per instrument, using retained run evidence where enforced. No startup QC runs were seeded.
5. Current sample analytical results remain unentered. Perform them manually in the normal workflow.

## Verification limits

The local suite tests domain/ORM creation, eighteen bindings, rerun idempotency, audit identities, blind target-field redaction, server PASS/FAIL, refusal of missing assignment, rollback after a late equipment failure, conflicting fixtures and environment isolation guards.
Local tests use disposable SQLite; this package has NOT yet been exercised against live Neon/PostgreSQL or verified in Safari.
Runtime transaction locks use PostgreSQL SELECT FOR UPDATE through the ORM.
