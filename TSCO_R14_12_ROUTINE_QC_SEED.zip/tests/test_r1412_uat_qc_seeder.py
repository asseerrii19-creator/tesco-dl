from copy import deepcopy
import base64
from datetime import datetime,timedelta
import json
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select,func
from app.main import app
from app.database import SessionLocal
from app.models import User,Site,Client,Asset,SampleRequest,EquipmentAsset,AuditLog
from app.services.lab_operations import get_operations_state,save_operations_state,_result_qc_context,_server_qc_status
from uat_qc_seed.seed_r1412_routine_qc import (load_fixtures,seed_transaction,guard_environment,
    TAG,BATCH,SAMPLE,REGISTRAR,REVIEWER,SERVICE,HOST)


def setup(db):
    tech=db.scalar(select(User).where(User.full_name==REGISTRAR))
    senior=db.scalar(select(User).where(User.full_name==REVIEWER))
    assert tech is not None and senior is not None
    site=db.get(Site,tech.site_id)
    client=db.scalar(select(Client).where(Client.code=='SEC'))
    asset=db.scalar(select(Asset).where(Asset.client_id==client.id))
    sample=db.scalar(select(SampleRequest).where(SampleRequest.request_number==SAMPLE))
    if not sample:
        sample=SampleRequest(request_number=SAMPLE,barcode_value=SAMPLE,public_token='qc-seed-test',site_id=site.id,
            client_id=client.id,asset_id=asset.id,status='TESTING',sampling_point='Bottom Tank',sample_date_time=datetime.utcnow(),requested_package='Routine Test')
        db.add(sample)
    state,payload=get_operations_state(db,site)
    fs=load_fixtures()
    stations={'DGA':'DGA','WATER':'Water / BDV / PF / Room Conditions','COLOR':'IFT / Color / Appearance',
        'TAN':'TAN / RSH / Peroxide','BDV':'Water / BDV / PF / Room Conditions','IFT':'IFT / Color / Appearance',
        'PF25':'Water / BDV / PF / Room Conditions','PF100':'Water / BDV / PF / Room Conditions'}
    batch={'id':BATCH,'samples':[SAMPLE],'tests':[{'test':f['test'],'method':f['method'],'station':stations[f['code']]} for f in fs]}
    payload['batches']=[batch]
    payload['qualifiedQcProfiles']=[];payload['qc']=[];payload['results']=[]
    payload['testAssignments']=[{'id':'A'+str(i),'batch_id':BATCH,'workstation':s,'primary_user_id':tech.id,'mode':'SINGLE','revision':1}
        for i,s in enumerate(set(stations.values()))]
    for f in fs:
        for code in f['equipment']:
            eq=db.scalar(select(EquipmentAsset).where(EquipmentAsset.site_id==site.id,EquipmentAsset.equipment_id==code))
            if eq is None:
                eq=EquipmentAsset(site_id=site.id,equipment_id=code,name='Synthetic unit-test equipment')
                db.add(eq)
            eq.status='IN_SERVICE';eq.active=True;eq.workstation=stations[f['code']]
            eq.test_method='ASTM D1533 / ASTM D1816 / ASTM D924' if stations[f['code']].startswith('Water') else f['method']
            eq.next_calibration_at=datetime.utcnow()+timedelta(days=100)
            eq.next_verification_at=datetime.utcnow()+timedelta(days=100)
    save_operations_state(db,state,payload,tech);db.flush()
    return fs,state,payload,tech,senior


def test_existing_domain_services_idempotency_blind_scoping_and_no_sample_results():
    with TestClient(app):
        with SessionLocal() as db:
            fs,state,p,tech,senior=setup(db)
            audit_before=db.scalar(select(func.count()).select_from(AuditLog))
            first=seed_transaction(db,fs,apply=True);db.flush()
            assert len(first['lots'])==8
            assert sum(len(l['equipment_bindings']) for l in first['lots'])==18
            assert all(l['outcome']=='CREATED' and l['status']=='ACTIVE' for l in first['lots'])
            first_ids=[l['id'] for l in first['lots']]
            rev=state.revision
            count=db.scalar(select(func.count()).select_from(AuditLog))
            assert count==audit_before+16
            second=seed_transaction(db,fs,apply=True);db.flush()
            assert [l['id'] for l in second['lots']]==first_ids
            assert all(l['outcome']=='EXISTING' for l in second['lots'])
            assert state.revision==rev and db.scalar(select(func.count()).select_from(AuditLog))==count
            payload=json.loads(state.json_data)
            assert payload['results']==[] and payload['qc']==[] and payload['batches']==p['batches']
            assert all(l['prepared_by_user_id']==tech.id and l['approved_by_user_id']==senior.id for l in payload['qualifiedQcProfiles'])
            assert all(not b['daily_qc_ready'] for l in first['lots'] for b in l['equipment_bindings'])
            water=next(l for l in payload['qualifiedQcProfiles'] if l['test']=='Water')
            ctx=_result_qc_context(p['batches'][0],{'test':water['context_test']})
            for eid in water['equipment_ids']:
                row={'test':'Water','context_test':ctx['test'],'method_name':ctx['method'],'workstation':ctx['workstation'],
                    'batch_id':BATCH,'equipment_asset_id':eid,'lot':water['id'],'result':20,
                    'source_file':'R14.12-UAT-DEMO-unit-test.csv','source_data':'data:text/csv;base64,'+base64.b64encode(b'Result\n20').decode()}
                assert _server_qc_status(payload,row)[0]=='PASS'
                row['result']=100
                row['source_data']='data:text/csv;base64,'+base64.b64encode(b'Result\n100').decode()
                assert _server_qc_status(payload,row)[0]=='FAIL'
            db.rollback()


def test_no_assignment_no_partial_commit_and_existing_conflicts_abort():
    with TestClient(app):
        with SessionLocal() as db:
            fs,state,p,tech,senior=setup(db)
            p['testAssignments']=[];save_operations_state(db,state,p,tech);db.flush()
            before=state.json_data
            with pytest.raises(PermissionError):seed_transaction(db,fs,apply=True)
            assert state.json_data==before
            db.rollback()


def test_environment_guard_refuses_wrong_service_database_and_missing_opt_in(monkeypatch):
    for k,v in {'TSCO_UAT_QC_SEED_CONFIRM':TAG+':'+BATCH,'RENDER_SERVICE_ID':SERVICE,'APP_ENV':'staging',
        'PUBLIC_BASE_URL':'https://'+HOST,'DATABASE_URL':'postgresql://fixture:fixture@ep-test.neon.tech/neondb',
        'APP_SECRET':'test-only-signing-secret-at-least-32-characters'}.items():monkeypatch.setenv(k,v)
    guard_environment()
    for key,value in [('RENDER_SERVICE_ID','srv-daknqsjl550s73et1t3g'),('DATABASE_URL','sqlite:///local.db'),
        ('DATABASE_URL','postgresql://fixture:fixture@uat.render.com/uat'),('APP_ENV','production'),
        ('PUBLIC_BASE_URL','https://tsco-v285-final-review.onrender.com'),('TSCO_UAT_QC_SEED_CONFIRM','')]:
        with monkeypatch.context() as m:
            m.setenv(key,value)
            with pytest.raises(ValueError):guard_environment()


def test_late_equipment_failure_rolls_back_all_created_lots_and_audits():
    with TestClient(app):
        with SessionLocal() as db:
            fs,state,p,tech,senior=setup(db)
            bad=db.scalar(select(EquipmentAsset).where(EquipmentAsset.site_id==tech.site_id,EquipmentAsset.equipment_id=='EQ-130'))
            bad.status='OUT_OF_SERVICE'
            db.commit()
            original_revision=state.revision
            original_audits=db.scalar(select(func.count()).select_from(AuditLog))
            with pytest.raises(PermissionError):seed_transaction(db,fs,apply=True)
            db.rollback()
            db.refresh(state)
            assert state.revision==original_revision
            assert json.loads(state.json_data)['qualifiedQcProfiles']==[]
            assert db.scalar(select(func.count()).select_from(AuditLog))==original_audits


def test_existing_lot_conflict_is_not_modified_or_duplicated():
    with TestClient(app):
        with SessionLocal() as db:
            fs,state,p,tech,senior=setup(db)
            seed_transaction(db,fs,apply=True);db.flush()
            controlled=json.loads(state.json_data)
            controlled['qualifiedQcProfiles'][0]['mean']=999
            save_operations_state(db,state,controlled,senior);db.flush()
            original=state.json_data
            with pytest.raises(ValueError,match='differs'):seed_transaction(db,fs,apply=True)
            assert state.json_data==original
            assert len(json.loads(state.json_data)['qualifiedQcProfiles'])==8
            db.rollback()
