from copy import deepcopy
from datetime import datetime, timezone
from types import SimpleNamespace

from app.services.lab_operations import (
    merge_scoped_operations_update,
    scope_operations_payload,
    validate_operations_update,
)


def _base_state(test_name, method, workstation, user_id=18):
    return {
        'batches': [{'id':'B1','samples':['S1'],'tests':[{'test':test_name,'method':method,'station':workstation}],'status':'Testing'}],
        'results': [], 'qc': [], 'qualifiedQcProfiles': [], 'retests': [], 'dgaAttachments': [], 'resultEvidence': [],
        'testAssignments': [{'id':'A1','batch_id':'B1','scope':'BATCH','workstation':workstation,'mode':'SINGLE','revision':1,'primary_user_id':user_id,'backup_user_id':None}],
        'assignmentCompletions': [], 'qualityDistributions': [], 'qualityTaskEvents': [], 'reports': [], 'retained': [],
        'storageAssignments': [], 'batchHistory': [], 'cancelledSamples': [], 'supervisorNotes': [], 'standards': [],
        'staff': [{'id':user_id,'name':'Technician','role':'lab_technician'}], 'clients': [], 'samplePoints': [],
        'customPackages': [], 'formulaDefinitions': [], 'testUnits': {}, 'settings': {}, 'meta': {'revision': 7},
        'drafts': {}, 'calculationDrafts': {},
    }


def _dga_components(value=25.0):
    keys = [('H2','Hydrogen (H2)'),('O2','Oxygen (O2)'),('N2','Nitrogen (N2)'),('CH4','Methane (CH4)'),('CO','Carbon Monoxide (CO)'),('CO2','Carbon Dioxide (CO2)'),('C2H4','Ethylene (C2H4)'),('C2H6','Ethane (C2H6)'),('C2H2','Acetylene (C2H2)')]
    return [{'key':k,'name':n,'target':25.0,'result':value} for k,n in keys]


def _dga_qc(qid, eq_asset, eq_id, *, stale=False):
    row = {
        'id': qid, 'mode':'routine','test':'DGA','context_test':'Dissolved Gas Analysis (DGA)',
        'method_name':'IEC 60567','workstation':'DGA','assignment_id':'A1','batch_id':'B1',
        'equipment_asset_id':eq_asset,'equipment_id':eq_id,'equipment_name':'DGA GC-TOGA',
        'status':'PASS','detail':'Component-level CRM verification','qc_components':_dga_components(),
        'target':'Certified component targets ±5%','result':'9/9 components PASS',
        'analyst':'Technician','recorded_by_user_id':18,'ts':datetime.now(timezone.utc).isoformat(),
    }
    if stale:
        row['detail'] = 'older browser representation'
        row.pop('recorded_by_user_id', None)
    return row


def test_dga_two_equipment_full_merge_and_validation_preserves_first_and_accepts_second():
    user = SimpleNamespace(id=18, role='lab_technician', full_name='Technician')
    current = _base_state('Dissolved Gas Analysis (DGA)','IEC 60567','DGA')
    current['qc'] = [_dga_qc('QC-EQ64',64,'EQ-64')]

    incoming = deepcopy(scope_operations_payload(current,user))
    incoming['qc'][0] = _dga_qc('QC-EQ64',64,'EQ-64',stale=True)
    incoming['qc'].insert(0,_dga_qc('QC-EQ23',23,'EQ-23'))

    merged = merge_scoped_operations_update(current,incoming,user)
    accepted = validate_operations_update(current,merged,user,db=None,site_id=None)

    assert [q['id'] for q in accepted['qc']] == ['QC-EQ64','QC-EQ23']
    assert accepted['qc'][0] == current['qc'][0]
    assert accepted['qc'][1]['equipment_id'] == 'EQ-23'
    assert accepted['qc'][1]['status'] == 'PASS'
    assert len(accepted['qc'][1]['qc_components']) == 9


def test_same_pattern_works_for_repeated_new_qc_ids_without_rewriting_history():
    user = SimpleNamespace(id=18, role='lab_technician', full_name='Technician')
    current = _base_state('Dissolved Gas Analysis (DGA)','IEC 60567','DGA')
    current['qc'] = [_dga_qc('QC-1',64,'EQ-64')]
    incoming = deepcopy(scope_operations_payload(current,user))
    incoming['qc'][0]['detail'] = 'browser formatting drift'
    incoming['qc'].insert(0,_dga_qc('QC-2',23,'EQ-23'))
    merged = merge_scoped_operations_update(current,incoming,user)
    assert merged['qc'][0] == current['qc'][0]
    assert {q['id'] for q in merged['qc']} == {'QC-1','QC-2'}


def test_duplicate_incoming_id_is_still_rejected():
    user = SimpleNamespace(id=18, role='lab_technician', full_name='Technician')
    current = _base_state('Dissolved Gas Analysis (DGA)','IEC 60567','DGA')
    incoming = deepcopy(scope_operations_payload(current,user))
    row = _dga_qc('QC-DUP',23,'EQ-23')
    incoming['qc'] = [row, deepcopy(row)]
    try:
        merge_scoped_operations_update(current,incoming,user)
    except PermissionError as exc:
        assert 'Duplicate' in str(exc)
    else:
        raise AssertionError('duplicate QC ids must be rejected')


def test_visible_existing_record_cannot_be_deleted_even_though_stale_fields_are_tolerated():
    user = SimpleNamespace(id=18, role='lab_technician', full_name='Technician')
    current = _base_state('Dissolved Gas Analysis (DGA)','IEC 60567','DGA')
    current['qc'] = [_dga_qc('QC-EQ64',64,'EQ-64')]
    incoming = deepcopy(scope_operations_payload(current,user))
    incoming['qc'] = []
    try:
        merge_scoped_operations_update(current,incoming,user)
    except PermissionError as exc:
        assert 'cannot be changed or deleted' in str(exc)
    else:
        raise AssertionError('visible historical QC deletion must be rejected')


def test_dga_server_rejects_partial_or_duplicate_component_sets():
    from app.services.lab_operations import _server_qc_status
    payload = {'qualifiedQcProfiles': []}
    partial = _dga_qc('QC-PART',23,'EQ-23')
    partial['qc_components'] = partial['qc_components'][:-1]
    try:
        _server_qc_status(payload, partial)
    except PermissionError as exc:
        assert 'exactly the nine' in str(exc)
    else:
        raise AssertionError('partial DGA QC component set must be rejected')

    dup = _dga_qc('QC-DUP-COMP',23,'EQ-23')
    dup['qc_components'][-1]['key'] = 'H2'
    try:
        _server_qc_status(payload, dup)
    except PermissionError as exc:
        assert 'exactly the nine' in str(exc)
    else:
        raise AssertionError('duplicate DGA QC component key must be rejected')
