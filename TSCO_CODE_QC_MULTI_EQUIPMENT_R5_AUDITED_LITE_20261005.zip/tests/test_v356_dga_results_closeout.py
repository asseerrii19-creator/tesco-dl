from pathlib import Path

from app.services.lab_operations import _test_complete, _workstation_complete


def _payload(component_keys):
    sample = 'DGA-UAT-1'
    batch = {
        'id': 'B-DGA-R3',
        'samples': [sample],
        'tests': [{'test': 'Dissolved Gas Analysis (DGA)', 'method': 'IEC 60567', 'station': 'DGA'}],
        'status': 'Testing',
    }
    return {
        'batches': [batch],
        'results': [
            {'id': f'R-{key}', 'batch': batch['id'], 'sample': sample, 'test': f'DGA:{key}', 'result': '1', 'unit': 'ppm'}
            for key in component_keys
        ],
    }, batch, sample


def test_dga_workstation_requires_full_controlled_nine_gas_set():
    keys = ['H2', 'O2', 'N2', 'CH4', 'CO', 'CO2', 'C2H4', 'C2H6', 'C2H2']
    partial, batch, sample = _payload(keys[:-1])
    assert not _test_complete(partial, sample, batch['tests'][0])
    assert not _workstation_complete(partial, batch, 'DGA')

    complete, batch, sample = _payload(keys)
    assert _test_complete(complete, sample, batch['tests'][0])
    assert _workstation_complete(complete, batch, 'DGA')


def test_dga_ui_is_file_first_for_qc_and_routine_results():
    html = (Path(__file__).resolve().parents[1] / 'app' / 'lab_ops' / 'index_template.html').read_text(encoding='utf-8')
    for marker in (
        'DGA CRM / Gas Standard</b> · Import the GC/CRM CSV or enter certificate values manually.',
        'DGA QC / CRM Instrument CSV',
        'CRM nominal level',
        '25 ppm',
        '50 ppm',
        '100 ppm',
        'function parseDgaQcCsv(text)',
        "source_kind:WS_QC_SOURCE?.kind||''",
        'DGA results</b> · Import the GC/TOGA CSV when available.',
        'Import Original GC/TOGA Results CSV',
        'DGA RESULTS COMPLETE',
        'Required gases:',
    ):
        assert marker in html


def test_dga_uat_csv_fixtures_cover_qc_and_all_nine_results():
    root = Path(__file__).resolve().parents[1] / 'app' / 'uat_fixtures'
    qc = (root / 'DGA_QC_CRM_25PPM_UAT.csv').read_text(encoding='utf-8')
    results = (root / 'DGA_RESULTS_UAT.csv').read_text(encoding='utf-8')
    for label in ('H2', 'O2', 'N2', 'CH4', 'CO', 'CO2', 'C2H4', 'C2H6', 'C2H2'):
        assert label in qc
        assert label in results
    assert 'TCG ppm STP' in results
    assert 'Equilibrium Pressure' in results
