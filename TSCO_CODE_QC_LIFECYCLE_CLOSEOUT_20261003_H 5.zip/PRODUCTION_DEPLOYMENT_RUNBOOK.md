# TSCO Digital Laboratory Platform — Deployment Runbook v3.4.6

1. Keep the existing Render PostgreSQL database and environment variables.
2. Deploy the v3.4.6 package.
3. Start with `alembic upgrade head` then Uvicorn.
4. Do not reset/recreate UAT case, samples, chain of custody, or Lab Batch.
5. Verify `/welcome` and Chemical Technician → Water using the existing urgent batch.
