# Final Package Manifest — v3.4.2 Standalone UAT

- Version: `3.4.2`
- Alembic head: `b17f4c8d9e20`
- Architecture: standalone TSCO Digital Laboratory Platform
- Official client document: Final Analysis Report (`QDF-[7]-08-A`-aligned)
- Official report authority: mandatory Senior Final Report Review → Technical Manager final approval/release
- Database target: PostgreSQL for UAT/production

## Current release documents
- `START_HERE.md`
- `V3.4.2_STANDALONE_UAT_FLOW.md`
- `V3.4.2_FINAL_ANALYSIS_REPORT_ALIGNMENT.md`
- `V3.4.2_SENIOR_FINAL_REPORT_REVIEW.md`
- `DEFECT_CLOSURE_REGISTER_v3.4.2.md`
- `FINAL_VERIFICATION_v3.4.2.md`
- `UAT_ACCEPTANCE_CHECKLIST.md`
- `DEPLOYMENT_QUICKSTART.md`
- `PRODUCTION_DEPLOYMENT_RUNBOOK.md`
- `RELEASE_VERIFICATION_EVIDENCE_v3.4.2.txt`
- `PACKAGE_CONTENTS_v3.4.2.txt`
- `PACKAGE_SHA256SUMS_v3.4.2.txt`

## Package hygiene
The distributable ZIP excludes runtime databases, cache folders, Python bytecode, pytest cache, temporary report artifacts and superseded release-closeout documents. Database migrations and legacy schema compatibility remain in source because they are required to upgrade existing environments safely.
