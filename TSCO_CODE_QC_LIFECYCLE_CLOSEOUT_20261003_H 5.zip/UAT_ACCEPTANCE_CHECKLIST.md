# UAT Acceptance Checklist — v3.4.4 Intake Continuity UAT

Use real representative UAT data and verify the complete chain:

- [ ] Client Request captures scope/quantity/method/package/priority/TAT.
- [ ] Coordinator ownership is present and controlled reassignment works.
- [ ] Quotation is visible to the client; accept/reject/revision path works.
- [ ] Client PO upload links to the accepted quotation and one canonical PO-received stage.
- [ ] Operations receives the completed handover.
- [ ] Direct Delivery / Field Sampling creates individual sample identities and barcodes.
- [ ] TSCO Internal Registration and Physical Receiving persist after refresh/re-login.
- [ ] Smart Batch and Release to Lab create the correct assignments.
- [ ] QC gates block invalid result entry where required.
- [ ] Water/DGA/BDV/PF/OQI/Color/Appearance rules behave as controlled.
- [ ] Save failure cannot display a false success or advance assignment completion.
- [ ] Complete My Assignment updates counters/state correctly.
- [ ] Senior Technical Review receives the completed sample.
- [ ] Result Worksheet has no official release control.
- [ ] Senior Final Report Review shows the complete Final Analysis Report preview and small Quick Result Check cards for current controlled values.
- [ ] Senior can save draft Condition / Interpretation / Recommendation without advancing the workflow.
- [ ] Automatic requirements and all Senior confirmations block Technical Review Complete until satisfied.
- [ ] Technical Manager cannot approve before Senior Final Report Review is completed.
- [ ] Final Analysis Report follows QDF-[7]-08-A-aligned content, including applicable specialty Direct DP / Corrosive Sulfur sections.
- [ ] Technical Manager approval creates the official TSCO PDF artifact, integrity hash and release state.
- [ ] Client/Coordinator submission is available only after official release.
- [ ] Corporate Administration Handoff is visible without local invoicing/payment actions.
- [ ] Direct URLs and role navigation enforce RBAC.
- [ ] Mobile/tablet/desktop layouts keep controls usable and labels within bounds.
- [ ] Refresh and re-login preserve PostgreSQL-backed state and evidence.
