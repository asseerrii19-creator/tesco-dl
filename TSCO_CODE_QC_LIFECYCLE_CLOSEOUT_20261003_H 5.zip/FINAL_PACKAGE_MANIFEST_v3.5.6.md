# TSCO Project 00012 — v3.5.6 Package Manifest

**Release:** Change Set H — QC Material/Lot Lifecycle + File-First Analytical QC Closeout  
**Date:** 03 October 2026

## Start here

1. `START_HERE.md`
2. `V3.5.6_QC_LIFECYCLE_FILE_FIRST_CLOSEOUT.md`
3. `FINAL_VERIFICATION_v3.5.6.md`
4. `RELEASE_VERIFICATION_EVIDENCE_v3.5.6.txt`
5. `PACKAGE_SHA256SUMS_v3.5.6.txt`

## Runtime/deployment

- Application source: `app/`
- Alembic migrations: `alembic/`
- Render: `render.yaml`
- Docker: `Dockerfile`, `docker-compose.yml`, `docker-compose.production.yml`
- Local controlled review launchers: `START_LOCAL_REVIEW.bat`, `START_LOCAL_REVIEW.sh`

## Change-set scope

- QC Material/Lot lifecycle and Senior approval/signature.
- Internal/CRM evidence handling.
- File-first routine QC for instrument/run evidence.
- Exact Test + Method + Equipment lot binding.
- Server-derived PASS/WARNING/FAIL with PASS-only result gate.
- Compact collapsed QC UI and run history.
- Existing sample workflow retained; no database reset required.

`PACKAGE_CONTENTS_v3.5.6.txt` is the generated file inventory for this package.
