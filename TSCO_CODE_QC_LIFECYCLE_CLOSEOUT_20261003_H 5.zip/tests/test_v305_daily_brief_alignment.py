from datetime import datetime
from email.message import EmailMessage

from fastapi.testclient import TestClient

from app.main import app
from app.models import Role, User
from app.services.daily_brief import _current_quality_snapshot, deliver_daily_brief, render_daily_brief_html


def _user():
    return User(id=501, email='chemist@example.com', full_name='Test Chemist', password_hash='x', role=Role.LAB_TECHNICIAN.value, active=True)


def test_daily_brief_qc_reads_same_monthly_distribution_as_my_qc():
    user = _user()
    payload = {
        'qualityDistributions': [{
            'month': '2026-09', 'revision': 3,
            'analytical_ownership': [
                {'equipment_id': 'EQ-69', 'equipment_name': 'KF Water', 'workstation': 'Water Content (KF)', 'test_method': 'IEC 60814', 'primary_user_id': 501, 'backup_user_id': 502},
                {'equipment_id': 'EQ-70', 'equipment_name': 'BDV', 'workstation': 'BDV', 'test_method': 'IEC 60156', 'primary_user_id': 503, 'backup_user_id': 501},
            ],
            'assignments': [
                {'id': 'A1', 'task': 'Balances Check', 'domain': 'Routine Quality', 'period_label': 'Week 2 • 12–18', 'start_day': 12, 'end_day': 18, 'primary_user_id': 501, 'backup_user_id': 502},
                {'id': 'A2', 'task': 'Future Check', 'domain': 'Routine Quality', 'period_label': 'Week 4 • 26–30', 'start_day': 26, 'end_day': 30, 'primary_user_id': 501, 'backup_user_id': 502},
                {'id': 'A3', 'task': 'Completed Check', 'domain': 'Routine Quality', 'period_label': 'Week 1 • 1–11', 'start_day': 1, 'end_day': 11, 'primary_user_id': 501, 'backup_user_id': 502},
            ],
        }],
        'qualityTaskEvents': [{'assignment_id': 'A3', 'completed_at': '2026-09-10T09:00:00'}],
    }
    equipment, routine = _current_quality_snapshot(payload, user, datetime(2026, 9, 16, 8, 0))
    assert [(row['assigned_as'], row['equipment_id']) for row in equipment] == [('Primary', 'EQ-69'), ('Backup', 'EQ-70')]
    assert len(routine) == 1
    assert routine[0]['task'] == 'Balances Check'
    assert routine[0]['status'] == 'Due now'


def test_daily_brief_html_contains_coordinated_equipment_and_qc_tables():
    brief = {
        'date': 'Wednesday, 16 September 2026', 'recipient_name': 'Test Chemist', 'recipient_email': 'chemist@example.com',
        'yesterday': ['Water result completed'], 'today': ['Water Content (KF) — Batch 01'],
        'qc_equipment': [{'assigned_as': 'Primary', 'equipment_id': 'EQ-69', 'equipment_name': 'KF Water', 'workstation': 'Water Content (KF)', 'method': 'IEC 60814'}],
        'qc_routine': [{'task': 'Balances Check', 'domain': 'Routine Quality', 'window': 'Week 2 • 12–18', 'assigned_as': 'Primary', 'status': 'Due now', 'due': '18 Sep'}],
        'carry_over': ['No open item'], 'overnight': ['No handover'], 'qc_due': [], 'role': Role.LAB_TECHNICIAN.value,
    }
    html = render_daily_brief_html(brief)
    assert 'Monthly equipment responsibility' in html
    assert 'EQ-69' in html and 'Water Content (KF)' in html
    assert 'QC action now' in html and 'Balances Check' in html


def test_email_delivery_is_multipart_with_html_qc_table(monkeypatch):
    captured = {}
    class FakeSMTP:
        def __init__(self, *args, **kwargs): pass
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def starttls(self): pass
        def login(self, *args): pass
        def send_message(self, message: EmailMessage): captured['message'] = message
    monkeypatch.setenv('SMTP_HOST', 'smtp.test')
    monkeypatch.setenv('SMTP_FROM', 'lab@test.local')
    monkeypatch.setattr('app.services.daily_brief.smtplib.SMTP', FakeSMTP)
    brief = {
        'date': 'Wednesday, 16 September 2026', 'recipient_name': 'Test Chemist', 'recipient_email': 'chemist@example.com',
        'yesterday': ['Done'], 'today': ['Assigned'], 'qc_due': ['Equipment: Primary · EQ-69 · KF Water · Water Content (KF)'],
        'qc_equipment': [{'assigned_as': 'Primary', 'equipment_id': 'EQ-69', 'equipment_name': 'KF Water', 'workstation': 'Water Content (KF)', 'method': 'IEC 60814'}],
        'qc_routine': [], 'carry_over': ['None'], 'overnight': ['None'], 'role': Role.LAB_TECHNICIAN.value,
    }
    result = deliver_daily_brief(brief)
    assert result.status == 'SENT'
    msg = captured['message']
    assert msg.is_multipart()
    html_parts = [p for p in msg.walk() if p.get_content_type() == 'text/html']
    assert html_parts and 'EQ-69' in html_parts[0].get_content()


def test_brief_archive_explicitly_states_same_qc_source():
    with TestClient(app) as client:
        r = client.post('/login', data={'email': 'chemist@tsco.local', 'password': 'Demo123!'}, follow_redirects=False)
        assert r.status_code == 303
        page = client.get('/control/daily-brief')
        assert page.status_code == 200
        assert 'SAME SOURCE AS MY QC' in page.text
        assert 'QC / routine duties due' in page.text and 'Equipment responsibility' in page.text
