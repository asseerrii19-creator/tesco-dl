from pathlib import Path
from types import SimpleNamespace

from app.services.lab_operations import scope_operations_payload

ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / 'app/lab_ops/index_template.html').read_text(encoding='utf-8')
WRAPPER = (ROOT / 'app/templates/lab_operations.html').read_text(encoding='utf-8')
ROUTE = (ROOT / 'app/routes/lab_operations.py').read_text(encoding='utf-8')


def test_additives_is_a_compact_workstation_card_not_a_home_page_accordion():
    assert "{name:'Additives / Special Tests',desc:" in HTML
    assert 'id="additiveHead"' not in HTML
    assert 'id="additiveBody"' not in HTML
    assert "CORE.filter(w=>visible.has(w.name))" in HTML


def test_open_workstation_context_is_persisted_to_parent_url_and_browser():
    assert "TSCO_LAB_WORKSTATION_CHANGE" in HTML
    assert "localStorage.setItem(KEY+'-last-workstation'" in HTML
    assert "TSCO_LAB_WORKSTATION_CHANGE" in WRAPPER
    assert "url.searchParams.set('workstation',workstation)" in WRAPPER
    assert "url.searchParams.delete('workstation')" in WRAPPER
    assert "localStorage.getItem(KEY+'-last-workstation')" in ROUTE


def test_electrical_assignment_remains_visible_under_the_existing_14_day_contract():
    user = SimpleNamespace(id=17, role='lab_technician')
    current = {
        'batches': [{
            'id': 'LB-UAT-CURRENT', 'samples': ['FS-DMM-26-000003', 'FS-DMM-26-000004'],
            'tests': [
                {'test': 'Power Factor @25°C/60Hz', 'method': 'ASTM D924', 'station': 'Electrical'},
                {'test': 'Power Factor @100°C/60Hz', 'method': 'ASTM D924', 'station': 'Electrical'},
                {'test': 'Breakdown Voltage @2.5mm- AVG', 'method': 'IEC 60156', 'station': 'Electrical'},
                {'test': 'RSD% of BDV @2.5mm', 'method': 'IEC 60156', 'station': 'Electrical'},
            ],
        }],
        'results': [], 'qc': [], 'qualifiedQcProfiles': [], 'qcLots': [], 'qcLotEvents': [], 'qcEvidence': [],
        'retests': [], 'dgaAttachments': [], 'resultEvidence': [],
        'testAssignments': [{
            'id': 'WSA-AUTO-20260927-20261010-ELECTRICAL', 'batch_id': '*', 'scope': 'WORKSTATION',
            'workstation': 'Electrical', 'mode': 'SINGLE', 'revision': 1,
            'primary_user_id': 17, 'primary_name': 'UAT Role — Chemist', 'backup_user_id': None,
            'source': 'AUTO_14_DAY_ROTATION', 'cycle_key': '20260927-20261010',
            'cycle_start': '2026-09-27T00:00:00', 'cycle_end': '2026-10-10T23:59:59',
        }],
        'assignmentCompletions': [], 'qualityDistributions': [], 'qualityTaskEvents': [],
        'reports': [], 'retained': [], 'storageAssignments': [], 'batchHistory': [],
        'cancelledSamples': [], 'supervisorNotes': [], 'standards': [],
        'staff': [{'id': 17, 'name': 'UAT Role — Chemist', 'role': 'lab_technician', 'active': True}],
        'clients': [], 'settings': {}, 'meta': {'revision': 1}, 'drafts': {}, 'calculationDrafts': {},
    }
    scoped = scope_operations_payload(current, user)
    assert len(scoped['batches']) == 1
    assert {row['station'] for row in scoped['batches'][0]['tests']} == {'Electrical'}
    assert scoped['testAssignments'][0]['id'] == 'WSA-AUTO-20260927-20261010-ELECTRICAL'
    assert scoped['testAssignments'][0]['primary_user_id'] == 17


def test_operations_load_contains_best_effort_current_cycle_assignment_reconciliation():
    assert 'ensure_analytical_rotation_assignments(db, site.id, payload, required_workstations)' in ROUTE
    assert 'reconcile_analytical_rotation_continuity(db, site.id, payload, required_workstations)' in ROUTE
    assert 'if materialized_ids - durable_ids or continuity_repairs or restored_assignments:' in ROUTE
    assert 'Senior batch-specific exception override' in ROUTE
