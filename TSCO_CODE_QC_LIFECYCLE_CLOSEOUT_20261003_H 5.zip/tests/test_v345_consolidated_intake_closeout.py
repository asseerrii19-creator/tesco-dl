from pathlib import Path

from fastapi.testclient import TestClient

from app.main import app


ROOT = Path(__file__).resolve().parents[1]


def test_browser_405_is_branded_html_not_raw_json():
    with TestClient(app) as browser:
        response = browser.post('/welcome', headers={'accept': 'text/html'}, follow_redirects=False)
        assert response.status_code == 405
        assert 'text/html' in response.headers.get('content-type', '')
        assert 'TSCO · DIGITAL LABORATORY PLATFORM' in response.text
        assert 'Method Not Allowed' in response.text
        assert not response.text.lstrip().startswith('{')


def test_intake_copy_distinguishes_open_intake_from_physical_receipt():
    text = (ROOT / 'app' / 'templates' / 'intake_queue.html').read_text()
    assert '>Open Intake</a>' in text
    assert 'Register Samples from Approved Request' in text
    assert "'Create Sample Records' if linked_intake" in text
    assert 'Physical receipt date/time is captured automatically' in text
    assert 'Receipt timestamp:' in text
    assert 'Sampling Date / Time' in text
    assert 'Newer / Replacement Client Data Form' in text
    assert '{{ s.sampling_point }}<br><small>' in text


def test_direct_delivery_stepper_uses_data_entry_intake_and_skips_sampling_card():
    text = (ROOT / 'app' / 'templates' / 'commercial_flow.html').read_text()
    assert "key=='SAMPLING'" in text
    assert "'Data Entry Intake'" in text
    assert 'Record External Client Response / Follow-up' in text


def test_technician_compact_queue_displays_lab_batch_id():
    text = (ROOT / 'app' / 'lab_ops' / 'index_template.html').read_text()
    assert 'Lab Batch ${esc(b.id)}' in text


def test_intake_record_distinguishes_sampling_and_received_timestamps():
    text = (ROOT / 'app' / 'templates' / 'intake_review.html').read_text()
    assert '<dt>Sampling Date / Time</dt>' in text
    assert '<dt>Physical Received At</dt>' in text


def test_stale_client_portal_status_is_reconciled_after_handover_and_sample_creation():
    from datetime import datetime
    from uuid import uuid4
    from sqlalchemy import select
    from app.database import SessionLocal
    from app.models import Asset, Client, CommercialCase, SampleRequest, Site
    from app.services.commercial import reconcile_client_portal_request_statuses

    token = uuid4().hex[:8].upper()
    with SessionLocal() as db:
        site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
        client = db.scalar(select(Client).where(Client.code == 'SEC')); assert client
        case = CommercialCase(
            case_code=f'BC-DMM-V345-{token}', site_id=site.id, client_id=client.id,
            current_stage='COMPLETE_HANDOVER', status='ACTIVE', lead_title='v3.4.5 status reconciliation',
            request_source='CLIENT_PORTAL', request_status='PO_RECEIVED', sample_delivery_mode='CLIENT_DELIVERY',
            handover_commercial='ok', handover_technical='ok', handover_client_info='ok',
        )
        db.add(case); db.flush()
        assert reconcile_client_portal_request_statuses(db) >= 1
        db.refresh(case)
        assert case.request_status == 'HANDOVER_COMPLETE'

        asset = Asset(client_id=client.id, asset_code=f'SEC-V345-{token}', serial_number=f'V345-{token}', equipment_type='Transformer', active=True)
        db.add(asset); db.flush()
        sample = SampleRequest(
            request_number=f'FS-V345-{token}', public_token=f'pub-{token}', barcode_value=f'bc-{token}', status='TESTING',
            site_id=site.id, client_id=client.id, commercial_case_id=case.id, asset_id=asset.id,
            submission_channel='CLIENT_DELIVERED', sample_date_time=datetime(2026,10,1,18,0), sampling_point='Bottom',
            requested_package='Routine Test', requested_method_family='DEFAULT', requested_tests_json='[]',
            sample_origin='Client-Originated / Direct Delivery', priority='URGENT', required_tat='24H',
        )
        db.add(sample); case.current_stage='TESTING'; db.commit()
        assert reconcile_client_portal_request_statuses(db) >= 1
        db.refresh(case)
        assert case.request_status == 'IN_PROGRESS'
