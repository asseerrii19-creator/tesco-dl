from __future__ import annotations

import base64
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace

import pytest

from app.services import lab_operations as ops


def data_url(text: str) -> str:
    return "data:text/csv;base64," + base64.b64encode(text.encode()).decode()


def user(role: str, uid: int = 17, name: str = "UAT User"):
    return SimpleNamespace(role=role, id=uid, full_name=name)


def approved_lot_payload(group="BDV", method="IEC 60156", context_test="Breakdown Voltage @2.5mm- AVG"):
    lot = {
        "id": "LOT-1",
        "status": "PENDING_SENIOR",
        "source_type": "INTERNAL",
        "lot_code": "QC-LOT-001",
        "test": group,
        "context_test": context_test,
        "method_name": method,
        "equipment_asset_ids": [25],
        "expiry_date": "2099-12-31",
        "target": 60.0,
        "acceptance_low": 55.0,
        "acceptance_high": 65.0,
        "warning_low": 57.0,
        "warning_high": 63.0,
        "created_at": "2026-10-03T10:00:00",
    }
    event = {
        "id": "EV-1",
        "lot_id": "LOT-1",
        "action": "APPROVE",
        "target": 60.0,
        "acceptance_low": 55.0,
        "acceptance_high": 65.0,
        "warning_low": 57.0,
        "warning_high": 63.0,
        "approved_by": "Senior Chemist",
        "approved_by_user_id": 5,
        "approved_at": "2026-10-03T10:15:00",
        "approval_signature": "Authenticated electronic approval · Senior Chemist",
        "ts": "2026-10-03T10:15:00",
    }
    return {"qcLots": [lot], "qcLotEvents": [event], "qcEvidence": [], "qc": []}


def test_bdv_qc_file_parser_uses_six_run_set_and_derives_average_rsd():
    evidence = {
        "data": data_url("Run1,58\nRun2,59\nRun3,60\nRun4,61\nRun5,62\nRun6,60\n")
    }
    value, detail = ops._parse_qc_csv_measurement(
        evidence, "Breakdown Voltage @2.5mm- AVG", "BDV", "IEC 60156"
    )
    assert value == pytest.approx(60.0)
    assert detail["runs"] == [58.0, 59.0, 60.0, 61.0, 62.0, 60.0]
    assert detail["rsd_pct"] > 0


def test_pf_qc_file_parser_uses_temperature_specific_value():
    evidence = {"data": data_url("PF25,0.101\nPF100,1.234\n")}
    v25, _ = ops._parse_qc_csv_measurement(evidence, "Power Factor @25°C/60Hz", "PF", "ASTM D924")
    v100, _ = ops._parse_qc_csv_measurement(evidence, "Power Factor @100°C/60Hz", "PF", "ASTM D924")
    assert v25 == pytest.approx(0.101)
    assert v100 == pytest.approx(1.234)


def test_dga_qc_file_parser_reads_components():
    evidence = {"data": data_url("Gas,Value_ppm\nH2,50\nCH4,10\nC2H2,1\nCO,100\n")}
    value, detail = ops._parse_qc_csv_measurement(evidence, "Dissolved Gas Analysis (DGA)", "DGA", "IEC 60567")
    assert value is None
    assert {row["key"]: row["result"] for row in detail["qc_components"]} == {"H2": 50.0, "CH4": 10.0, "C2H2": 1.0, "CO": 100.0}


def test_only_pass_is_acceptable_for_result_gate():
    assert ops._QC_ACCEPTABLE == {"PASS"}


def test_qc_lot_stays_pending_until_senior_approval_and_is_e_signed():
    current = {"qcLots": [], "qcLotEvents": [], "qcEvidence": []}
    proposed = deepcopy(current)
    proposed["qcEvidence"].append({"id": "E1", "kind": "qc-lot-qualification", "data": data_url("qualification")})
    proposed["qcLots"].append({
        "id": "L1", "source_type": "INTERNAL", "lot_code": "BDV-QC-NEW", "test": "BDV", "context_test": "Breakdown Voltage @2.5mm- AVG",
        "method_name": "IEC 60156", "expiry_date": "2099-12-31", "target": 60,
        "acceptance_low": 55, "acceptance_high": 65, "warning_low": 57, "warning_high": 63,
        "equipment_asset_ids": [25], "qualification_evidence_id": "E1",
    })
    ops._sanitize_qc_lots(current, proposed, user("lab_technician"))
    assert proposed["qcLots"][0]["status"] == "PENDING_SENIOR"
    assert ops._qc_lot_state(proposed, "L1")["status"] == "PENDING_SENIOR"

    after = deepcopy(proposed)
    after["qcLotEvents"].append({"id": "A1", "lot_id": "L1", "action": "APPROVE"})
    ops._sanitize_qc_lot_events(proposed, after, user("senior_chemist", 9, "Senior Chemist"))
    state = ops._qc_lot_state(after, "L1")
    assert state["status"] == "ACTIVE"
    assert state["approved_by"] == "Senior Chemist"
    assert "Authenticated electronic approval" in state["approval_signature"]


def test_non_senior_cannot_activate_qc_lot():
    current = {"qcLots": [{"id": "L1", "status": "PENDING_SENIOR"}], "qcLotEvents": []}
    proposed = deepcopy(current)
    proposed["qcLotEvents"].append({"id": "A1", "lot_id": "L1", "action": "APPROVE"})
    with pytest.raises(PermissionError, match="Senior Chemist"):
        ops._sanitize_qc_lot_events(current, proposed, user("lab_technician"))


def test_active_lot_limits_drive_server_pass_warning_fail():
    payload = approved_lot_payload()
    status, _, _ = ops._server_qc_status(payload, {"qc_lot_id": "LOT-1", "test": "BDV", "result": 60})
    assert status == "PASS"
    status, _, _ = ops._server_qc_status(payload, {"qc_lot_id": "LOT-1", "test": "BDV", "result": 64})
    assert status == "WARNING"
    status, _, _ = ops._server_qc_status(payload, {"qc_lot_id": "LOT-1", "test": "BDV", "result": 70})
    assert status == "FAIL"


def test_dga_lot_component_acceptance_is_controlled_by_approved_lot():
    lot = {
        "id": "DGA-L1", "status": "PENDING_SENIOR", "source_type": "CRM", "lot_code": "CRM-GAS-01",
        "test": "DGA", "context_test": "Dissolved Gas Analysis (DGA)", "method_name": "IEC 60567", "equipment_asset_ids": [23], "expiry_date": "2099-12-31",
        "component_targets": [{"key": "H2", "target": 50.0}, {"key": "CH4", "target": 10.0}],
        "component_tolerance_pct": 5.0,
    }
    event = {
        "id": "DGA-A1", "lot_id": "DGA-L1", "action": "APPROVE",
        "component_targets": deepcopy(lot["component_targets"]), "component_tolerance_pct": 5.0,
        "approved_by": "Senior", "approved_at": "2026-10-03T10:00:00", "approval_signature": "signed", "ts": "2026-10-03T10:00:00",
    }
    payload = {"qcLots": [lot], "qcLotEvents": [event]}
    row = {"qc_lot_id": "DGA-L1", "test": "DGA", "qc_components": [{"key": "H2", "result": 51}, {"key": "CH4", "result": 9.8}]}
    status, _, _ = ops._server_qc_status(payload, row)
    assert status == "PASS"
    row = {"qc_lot_id": "DGA-L1", "test": "DGA", "qc_components": [{"key": "H2", "result": 60}, {"key": "CH4", "result": 9.8}]}
    status, _, _ = ops._server_qc_status(payload, row)
    assert status == "FAIL"



def test_result_gate_rejects_forged_pass_without_lot_and_source_evidence():
    payload = approved_lot_payload()
    # Normalized operational payload is lifecycle-aware; PASS text alone is not enough.
    payload["qc"] = [{
        "id": "FORGED", "test": "BDV", "context_test": "Breakdown Voltage @2.5mm- AVG",
        "method_name": "IEC 60156", "equipment_asset_id": 25, "status": "PASS",
        "ts": "2099-01-01T10:00:00",
    }]
    ctx = {"group": "BDV", "test": "Breakdown Voltage @2.5mm- AVG", "method": "IEC 60156", "workstation": "Electrical"}
    assert ops._qc_record_has_lifecycle_evidence(payload, payload["qc"][0], ctx) is False


def test_senior_cannot_activate_overlapping_lot_on_same_test_method_equipment():
    current = approved_lot_payload()
    current["qcLots"].append({
        "id": "LOT-2", "status": "PENDING_SENIOR", "source_type": "INTERNAL",
        "lot_code": "QC-LOT-002", "test": "BDV", "context_test": "Breakdown Voltage @2.5mm- AVG", "method_name": "IEC 60156",
        "equipment_asset_ids": [25], "expiry_date": "2099-12-31",
        "target": 60.0, "acceptance_low": 55.0, "acceptance_high": 65.0,
    })
    proposed = deepcopy(current)
    proposed["qcLotEvents"].append({"id": "EV-2", "lot_id": "LOT-2", "action": "APPROVE"})
    with pytest.raises(PermissionError, match="Close/supersede"):
        ops._sanitize_qc_lot_events(current, proposed, user("senior_chemist", 9, "Senior Chemist"))

def test_qc_lot_is_bound_to_exact_requested_test_not_only_broad_bdv_group():
    payload = approved_lot_payload()
    lot = ops._qc_lot_state(payload, "LOT-1")
    assert lot is not None
    eq = 25
    iec_ctx = {"group": "BDV", "test": "Breakdown Voltage @2.5mm- AVG", "method": "IEC 60156", "workstation": "Electrical"}
    other_ctx = {"group": "BDV", "test": "Breakdown Voltage @1mm- AVG", "method": "IEC 60156", "workstation": "Electrical"}
    assert ops._qc_lot_matches_context(lot, iec_ctx, eq) is True
    assert ops._qc_lot_matches_context(lot, other_ctx, eq) is False


def test_qc_ui_is_compact_file_first_lifecycle_not_legacy_manual_panel():
    html = Path("app/lab_ops/index_template.html").read_text(encoding="utf-8")
    assert '<details class="qc-fold" id="qcLotFold"' in html
    assert '<details class="workstation-qc-panel" id="analytical-qc"' in html
    assert '<details class="qc-fold" id="qcLotFold" open' not in html
    assert "QC Material / Lot Control" in html
    assert "QC Instrument / Run Source File" in html
    assert "SUBMIT LOT FOR SENIOR APPROVAL" in html
    assert "APPROVED LOT REQUIRED" in html
    assert "SAVE QC FILE & RESULT" in html
    assert "$('saveStandard').onclick" not in html
    assert "_QC_ACCEPTABLE = {\"PASS\"}" in Path("app/services/lab_operations.py").read_text(encoding="utf-8")


def test_end_to_end_server_accepts_file_first_bdv_qc_only_after_senior_lot_approval():
    from copy import deepcopy
    from datetime import datetime
    from fastapi.testclient import TestClient
    from sqlalchemy import select
    from app.main import app
    from app.database import SessionLocal
    from app.models import EquipmentAsset, Site, User
    from app.services.lab_operations import get_operations_state, validate_operations_update

    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "DMM")); assert site
            chemist = db.scalar(select(User).where(User.email == "chemist@tsco.local")); assert chemist
            senior = db.scalar(select(User).where(User.email == "senior@tsco.local")); assert senior
            equipment = db.scalar(select(EquipmentAsset).where(EquipmentAsset.site_id == site.id, EquipmentAsset.equipment_id == "EQ-25")); assert equipment
            _, base = get_operations_state(db, site)
            base = deepcopy(base)
            base["batches"] = [{
                "id": "B-V356-QC", "template": "Routine", "package_id": "TEST", "client_id": "1",
                "client_name": "UAT", "client_code": "UAT", "priority": "Normal", "site": site.code,
                "samples": ["S-V356-1"], "sample_meta": {"S-V356-1": {}},
                "tests": [{"test": "Breakdown Voltage @2.5mm- AVG", "method": "IEC 60156", "station": "Electrical", "unit": "kV"}],
                "status": "Testing",
            }]
            base["testAssignments"] = [{
                "id": "WSA-V356", "batch_id": "B-V356-QC", "scope": "BATCH", "workstation": "Electrical", "mode": "SINGLE",
                "primary_user_id": chemist.id, "primary_name": chemist.full_name, "backup_user_id": None, "backup_name": "",
                "assigned_by_user_id": senior.id, "assigned_by": senior.full_name, "assigned_at": datetime.utcnow().isoformat(),
                "revision": 1, "access_scope": "NAMED_USERS",
            }]
            base["qc"] = []; base["results"] = []; base["qcLots"] = []; base["qcLotEvents"] = []; base["qcEvidence"] = []

            proposed = deepcopy(base)
            proposed["qcEvidence"].append({
                "id": "LOT-EV-V356", "kind": "qc-lot-qualification", "lot_id": "LOT-V356",
                "name": "BDV_QC_qualification.csv", "type": "text/csv", "data": data_url("qualification,evidence\n"),
            })
            proposed["qcLots"].append({
                "id": "LOT-V356", "source_type": "INTERNAL", "lot_code": "BDV-QC-V356", "test": "BDV", "context_test": "Breakdown Voltage @2.5mm- AVG",
                "method_name": "IEC 60156", "expiry_date": "2099-12-31", "target": 60.0,
                "acceptance_low": 55.0, "acceptance_high": 65.0, "warning_low": 57.0, "warning_high": 63.0,
                "equipment_asset_ids": [equipment.id], "qualification_evidence_id": "LOT-EV-V356",
            })
            pending = validate_operations_update(base, proposed, chemist, db=db, site_id=site.id)
            assert ops._qc_lot_state(pending, "LOT-V356")["status"] == "PENDING_SENIOR"

            approval = deepcopy(pending)
            approval["qcLotEvents"].append({"id": "LOT-APP-V356", "lot_id": "LOT-V356", "action": "APPROVE"})
            active = validate_operations_update(pending, approval, senior, db=db, site_id=site.id)
            assert ops._qc_lot_state(active, "LOT-V356")["status"] == "ACTIVE"

            run = deepcopy(active)
            run["qcEvidence"].append({
                "id": "RUN-EV-V356", "kind": "qc-run-source", "lot_id": "LOT-V356", "test": "BDV",
                "context_test": "Breakdown Voltage @2.5mm- AVG", "method_name": "IEC 60156",
                "equipment_asset_id": equipment.id, "name": "BDV_QC_run.csv", "type": "text/csv",
                "data": data_url("Run1,58\nRun2,59\nRun3,60\nRun4,61\nRun5,62\nRun6,60\n"),
            })
            run["qc"].append({
                "id": "QC-RUN-V356", "mode": "routine", "test": "BDV", "context_test": "Breakdown Voltage @2.5mm- AVG",
                "method_name": "IEC 60156", "assignment_id": "WSA-V356", "batch_id": "B-V356-QC",
                "equipment_asset_id": equipment.id, "qc_lot_id": "LOT-V356", "evidence_id": "RUN-EV-V356",
                "result": "999", "status": "PASS",
            })
            accepted = validate_operations_update(active, run, chemist, db=db, site_id=site.id)
            qc = accepted["qc"][-1]
            assert qc["status"] == "PASS"
            assert float(qc["result"]) == pytest.approx(60.0)
            assert qc["parsed_from_file"] is True
            assert qc["source_file"] == "BDV_QC_run.csv"
            assert qc["lot"] == "BDV-QC-V356"
            assert "Authenticated electronic approval" in qc["lot_approval_signature"]
