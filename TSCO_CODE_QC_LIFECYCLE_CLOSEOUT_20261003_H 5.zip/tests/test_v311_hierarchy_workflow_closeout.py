from datetime import datetime
from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import (
    Asset, Client, EquipmentAsset, ImprovementItem, PurchaseOrder, Quotation,
    Role, SampleRequest, SamplingAssignment, SamplingOrder, User,
)


def login(client, email, password="Demo123!"):
    response = client.post("/login", data={"email": email, "password": password}, follow_redirects=False)
    assert response.status_code == 303


def test_excellence_has_real_my_work_navigation_and_open_workspace():
    with TestClient(app) as client:
        login(client, "excellence@tsco.local")
        page = client.get("/")
        assert page.status_code == 200
        assert "My Workspace" in page.text
        assert "My Improvement Work" in page.text
        work = client.get("/improvement?tab=register&scope=my-work")
        assert work.status_code == 200
        assert "My Improvement Work" in work.text
        assert "QHSE and Equipment remain source owners" in work.text


def test_quality_or_equipment_issue_can_link_to_improvement_without_moving_authority():
    with TestClient(app) as client:
        with SessionLocal() as db:
            equipment = db.scalar(select(EquipmentAsset).where(EquipmentAsset.active.is_(True)).order_by(EquipmentAsset.id))
            assert equipment
            equipment_id = equipment.id
            eq_code = equipment.equipment_id
        login(client, "quality@tsco.local")
        response = client.post(
            "/improvement/from-source",
            data={
                "source_entity_type": "EquipmentAsset",
                "source_entity_id": equipment_id,
                "title": f"Equipment improvement — {eq_code}",
                "problem_statement": "Controlled cross-functional improvement; equipment authority remains with Quality/Technical.",
                "category": "EQUIPMENT",
                "priority": "HIGH",
                "source_url": "/quality?tab=equipment",
            },
            follow_redirects=False,
        )
        assert response.status_code == 303
        with SessionLocal() as db:
            item = db.scalar(select(ImprovementItem).where(
                ImprovementItem.source_entity_type == "EquipmentAsset",
                ImprovementItem.source_entity_id == equipment_id,
            ).order_by(ImprovementItem.id.desc()))
            assert item is not None
            assert item.source == "CONTROLLED_SOURCE"
            assert item.source_url == "/quality?tab=equipment"
        client.post("/logout")
        login(client, "excellence@tsco.local")
        page = client.get("/improvement?tab=register&scope=my-work")
        assert eq_code in page.text
        assert "Linked controlled source" in page.text
        assert "/quality?tab=equipment" in page.text
        # v3.1.7: Excellence has governance/oversight access to QC, equipment history, validation and audit.
        quality = client.get("/quality", follow_redirects=False)
        assert quality.status_code == 200
        assert "Excellence Oversight" in quality.text


def test_internal_sampling_hierarchy_is_operations_to_supervisor_to_sampleman_to_data_entry():
    with TestClient(app) as client:
        with SessionLocal() as db:
            sec = db.scalar(select(Client).where(Client.code == "SEC"))
            quote = db.scalar(select(Quotation).where(Quotation.client_id == sec.id, Quotation.status == "ACTIVE"))
            po = db.scalar(select(PurchaseOrder).where(PurchaseOrder.client_id == sec.id, PurchaseOrder.status == "ACTIVE"))
            asset = db.scalar(select(Asset).where(Asset.client_id == sec.id, Asset.active.is_(True)))
            supervisor = db.scalar(select(User).where(User.email == "supervisor@tsco.local"))
            sampler = db.scalar(select(User).where(User.email == "fieldman@tsco.local"))
            assert all([sec, quote, po, asset, supervisor, sampler])
            ids = dict(client=sec.id, quote=quote.id, po=po.id, asset=asset.id, supervisor=supervisor.id, sampler=sampler.id)
            supervisor_name, sampler_name = supervisor.full_name, sampler.full_name

        login(client, "operations@tsco.local")
        created = client.post(
            "/operations/orders",
            data={
                "client_id": ids["client"], "quotation_id": ids["quote"], "purchase_order_id": ids["po"],
                "supervisor_id": ids["supervisor"], "title": "Hierarchy-controlled sampling",
                "priority": "High", "due_at": "", "notes": "Supervisor allocates named Sampleman",
            },
            follow_redirects=False,
        )
        assert created.status_code == 303
        with SessionLocal() as db:
            order = db.scalar(select(SamplingOrder).where(SamplingOrder.title == "Hierarchy-controlled sampling").order_by(SamplingOrder.id.desc()))
            assert order and order.supervisor_id == ids["supervisor"]
            order_id, order_number = order.id, order.order_number

        requirement = client.post(
            f"/operations/orders/{order_id}/assignments",
            data={
                "asset_id": ids["asset"], "sample_label": "TR-01 Main Tank / Sample H1", "source_party": "TSCO",
                "requested_package": "SEC Routine", "sampling_point": "Main Tank Bottom",
                "container_count": 1, "instructions": "Collect under approved assignment",
            },
            follow_redirects=False,
        )
        assert requirement.status_code == 303
        with SessionLocal() as db:
            assignment = db.scalar(select(SamplingAssignment).where(SamplingAssignment.order_id == order_id).order_by(SamplingAssignment.id.desc()))
            assert assignment
            assert assignment.sample_label == "TR-01 Main Tank / Sample H1"
            assert assignment.assigned_sampler_id is None
            assert assignment.status == "UNASSIGNED"
            assignment_id = assignment.id

        # Operations may oversee assignment but cannot allocate a named TSCO Sampleman.
        denied = client.post(
            f"/sampling-supervision/assignment/{assignment_id}/assign",
            data={"sampler_id": ids["sampler"], "note": "Operations should not bypass supervisor"},
            follow_redirects=False,
        )
        assert denied.status_code == 403

        client.post("/logout")
        login(client, "supervisor@tsco.local")
        supervisor_page = client.get("/sampling-supervision")
        assert "TR-01 Main Tank / Sample H1" in supervisor_page.text
        assigned = client.post(
            f"/sampling-supervision/assignment/{assignment_id}/assign",
            data={"sampler_id": ids["sampler"], "note": "Assigned by Sampling Supervisor"},
            follow_redirects=False,
        )
        assert assigned.status_code == 303

        client.post("/logout")
        login(client, "fieldman@tsco.local")
        field = client.get("/field")
        assert "TR-01 Main Tank / Sample H1" in field.text
        assert supervisor_name in field.text
        assert order_number in field.text
        assert "+ Unplanned / direct sample" not in field.text

        collected = client.post(
            "/field/new",
            data={
                "assignment_id": assignment_id,
                "client_id": ids["client"], "quotation_id": "", "purchase_order_id": "",
                "existing_asset_id": ids["asset"], "asset_code": "", "serial_number": "",
                "equipment_type": "Transformer", "manufacturer": "", "station_name": "", "asset_location_label": "",
                "voltage_kv": "", "rated_mva": "", "sample_date_time": datetime.now().strftime("%Y-%m-%dT%H:%M"),
                "sampling_point": "Main Tank Bottom", "requested_package": "SEC Routine",
                "client_sample_reference": "HIERARCHY-H1", "oil_temperature_c": "35", "ambient_temperature_c": "31",
                "ambient_humidity_pct": "40", "gps_latitude": "26.42", "gps_longitude": "50.08", "gps_accuracy_m": "3",
                "field_notes": "Collected by assigned TSCO Sampleman", "container_count": 1,
            },
            follow_redirects=False,
        )
        assert collected.status_code == 303
        with SessionLocal() as db:
            sample = db.scalar(select(SampleRequest).where(SampleRequest.client_sample_reference == "HIERARCHY-H1"))
            assert sample
            assert sample.submission_channel == "TSCO_FIELD"
            assert sample.sample_origin == "TSCO Field-Sampled"
            assert sample.sampler_id == ids["sampler"]
            assert sample.sampling_assignment_id == assignment_id
            sample_id = sample.id
            event_notes = [e.note for e in sample.events]
            assert any(sampler_name in note and order_number in note and supervisor_name in note for note in event_notes)

        client.post("/logout")
        login(client, "intake@tsco.local")
        take_in = client.get(f"/intake/{sample_id}")
        assert take_in.status_code == 200
        assert "TSCO Sampling Service / Employee-Collected" in take_in.text
        assert sampler_name in take_in.text
        assert supervisor_name in take_in.text
        assert order_number in take_in.text
        assert "TR-01 Main Tank / Sample H1" in take_in.text


def test_org_page_makes_real_chart_and_system_sampling_chain_explicit():
    with TestClient(app) as client:
        login(client, "operations@tsco.local")
        page = client.get("/organization")
        assert page.status_code == 200
        for phrase in (
            "FIELD OPERATIONAL & TECHNICAL MANAGER",
            "SAMPLEMEN",
            "CLIENT ACCOUNT & COORDINATION OFFICER",
            "EXTERNAL COORDINATION OFFICER",
            "DATA ENTRY",
            "LAB OPERATIONAL & TECHNICAL MANAGER",
            "Dammam & Bahrain Labs",
        ):
            assert phrase in page.text
        assert "OPERATIONS DEPARTMENT" not in page.text
        assert "Quality Department" not in page.text


def test_source_files_do_not_reintroduce_direct_operations_staff_assignment_or_empty_excellence_workspace():
    root = Path(__file__).resolve().parents[1]
    operations_html = (root / "app/templates/operations_dashboard.html").read_text()
    base_html = (root / "app/templates/base.html").read_text()
    supervision_py = (root / "app/routes/sampling_supervision.py").read_text()
    assert 'name="assigned_sampler_id"' not in operations_html
    assert "My Improvement Work" in base_html
    assert "WRITE_ALLOWED = {Role.SAMPLING_SUPERVISOR.value, Role.SYSTEM_ADMIN.value}" in supervision_py
