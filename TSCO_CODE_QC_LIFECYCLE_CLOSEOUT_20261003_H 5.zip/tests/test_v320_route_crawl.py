from __future__ import annotations

from fastapi.testclient import TestClient

from app.main import app


def login(c: TestClient, email: str):
    r = c.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303, (email, r.status_code, r.text[:200])


def logout(c: TestClient):
    c.post('/logout', follow_redirects=False)


ROLE_LANDINGS = {
    'general.manager@tsco.local': '/management',
    'excellence.specialist@tsco.local': '/improvement',
    'secretary@tsco.local': '/gm-office',
    'sales.marketing.specialist@tsco.local': '/commercial',
    'salesman@tsco.local': '/commercial',
    'field.manager@tsco.local': '/operations',
    'sampling.supervisor@tsco.local': '/sampling-supervision',
    'data.entry@tsco.local': '/intake',
    'sampleman@tsco.local': '/field',
    'client.coordinator@tsco.local': '/commercial',
    'external.coordination@tsco.local': '/commercial',
    'lab.manager@tsco.local': '/management',
    'senior.technical@tsco.local': '/lab/operations?section=supervisor',
    'senior.equipment@tsco.local': '/lab/operations?section=supervisor',
    'senior.improvement@tsco.local': '/lab/operations?section=supervisor',
    'chemist@tsco.local': '/lab/operations?section=workstations',
    'technician@tsco.local': '/lab/operations?section=workstations',
    'lab.support@tsco.local': '/lab-support',
    'client@sec.local': '/client',
    'clientsampler@sec.local': '/field',
    'clientops@sec.local': '/field',
    'admin@tsco.local': '/admin',
}


def test_all_review_personas_reach_only_a_valid_primary_workspace():
    with TestClient(app) as c:
        for email, expected in ROLE_LANDINGS.items():
            login(c, email)
            root = c.get('/', follow_redirects=False)
            assert root.status_code == 303, (email, root.status_code)
            assert root.headers.get('location') == expected, (email, root.headers.get('location'), expected)
            landing = c.get(expected, follow_redirects=True)
            assert landing.status_code == 200, (email, expected, landing.status_code, landing.text[:300])
            assert 'Internal Server Error' not in landing.text
            logout(c)


def test_sampleman_direct_url_is_server_denied_without_named_assignment():
    with TestClient(app) as c:
        login(c, 'sampleman@tsco.local')
        r = c.get('/field/new', follow_redirects=False)
        assert r.status_code == 403


def test_admin_and_shared_base_personas_cannot_cross_business_write_boundaries():
    with TestClient(app) as c:
        login(c, 'admin@tsco.local')
        assert c.post('/commercial/cases', data={'client_id': 1, 'lead_title': 'forbidden'}, follow_redirects=False).status_code == 403
        logout(c)
        login(c, 'external.coordination@tsco.local')
        assert c.post('/commercial/projects', data={'project_reference':'DENY-X','project_name':'Denied','client_id':1}, follow_redirects=False).status_code == 403
        logout(c)
        login(c, 'salesman@tsco.local')
        assert c.post('/commercial/cases', data={'client_id': 1, 'lead_title': 'forbidden'}, follow_redirects=False).status_code == 403


def test_all_review_personas_static_get_route_crawl_has_no_server_errors():
    """Crawl every non-parameterized application GET route under every review persona.

    Authorization outcomes (200/3xx/401/403/404/405) are valid for a role-scoped route;
    any 5xx is a release-blocking routing/runtime defect.
    """
    public_or_framework = {"/openapi.json", "/docs", "/docs/oauth2-redirect", "/static"}
    crawl_paths = sorted({
        route.path
        for route in app.routes
        if "GET" in (getattr(route, "methods", set()) or set())
        and "{" not in route.path
        and route.path not in public_or_framework
        and not route.path.startswith("/static")
        and route.path not in {"/login", "/welcome"}
    })
    assert len(crawl_paths) >= 50

    with TestClient(app) as c:
        for email in ROLE_LANDINGS:
            login(c, email)
            failures = []
            for path in crawl_paths:
                r = c.get(path, follow_redirects=False)
                if r.status_code >= 500:
                    failures.append((path, r.status_code, r.text[:180]))
            assert not failures, (email, failures[:10])
            logout(c)
