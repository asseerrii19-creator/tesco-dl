from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import LeaveCoverageAssignment, Role, StaffAvailability, User
from app.org_structure import EMPLOYEES
from app.review_personas import REVIEW_PERSONAS

ROOT = Path(__file__).resolve().parents[1]


def login(c: TestClient, email: str):
    r = c.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303, (email, r.status_code, r.text[:250])


def logout(c: TestClient):
    c.post('/logout', follow_redirects=False)


def get_user(db, email: str) -> User:
    row = db.scalar(select(User).where(User.email == email))
    assert row is not None, email
    return row


def test_v323_identity_hierarchy_and_current_matrices_are_consistent():
    assert tuple(map(int, (ROOT / 'VERSION').read_text(encoding='utf-8').strip().split('.'))) >= (3, 2, 3)
    assert len(REVIEW_PERSONAS) == 18
    personas = {p.title: p for p in REVIEW_PERSONAS}
    assert personas['Sampling Supervisor'].email == 'sampling.supervisor@tsco.local'
    assert personas['Sampleman'].reports_to == 'Sampling Supervisor'
    assert personas['Sampleman'].leave_approver == 'Sampling Supervisor'
    assert personas['Data Entry'].reports_to == 'Field Operational & Technical Manager'

    for filename in ('ROLE_DEPARTMENT_ACCESS_MATRIX_v3.2.3.csv', 'UAT_ROLE_ACCESS_v3.2.3.csv'):
        raw = (ROOT / filename).read_text(encoding='utf-8')
        assert 'supervisor@tsco.local' not in raw.replace('sampling.supervisor@tsco.local', '')
        rows = list(csv.DictReader(raw.splitlines()))
        title_key = 'Job Title / Review Persona' if 'Job Title / Review Persona' in rows[0] else 'Review Persona'
        by_title = {r[title_key]: r for r in rows}
        assert by_title['Sampling Supervisor']['UAT Login' if 'UAT Login' in by_title['Sampling Supervisor'] else 'Login'] == 'sampling.supervisor@tsco.local'
        leave_key = 'Leave Approver' if 'Leave Approver' in by_title['Sampleman'] else 'Leave Approver Role'
        assert by_title['Sampleman'][leave_key] == 'Sampling Supervisor'

    named_samplemen = [e for e in EMPLOYEES if e.job_title == 'Sampleman']
    assert named_samplemen
    assert all(e.manager_email == 'sampling.supervisor@tsco.local' for e in named_samplemen)
    assert all(e.leave_approver_email == 'sampling.supervisor@tsco.local' for e in named_samplemen)

    org_html = (ROOT / 'app/templates/organization.html').read_text(encoding='utf-8')
    assert 'FIELD SUPERVISION' in org_html
    assert '↳ {{review_org.sampleman}}' in org_html
    assert 'DATA ENTRY · DIRECT REPORT' in org_html


def test_seeded_uat_reporting_lines_match_approved_field_hierarchy():
    with TestClient(app):
        with SessionLocal() as db:
            manager = get_user(db, 'field.manager@tsco.local')
            supervisor = get_user(db, 'sampling.supervisor@tsco.local')
            sampleman = get_user(db, 'sampleman@tsco.local')
            data_entry = get_user(db, 'data.entry@tsco.local')
            assert supervisor.manager_id == manager.id
            assert supervisor.leave_approver_id == manager.id
            assert sampleman.manager_id == supervisor.id
            assert sampleman.leave_approver_id == supervisor.id
            assert data_entry.manager_id == manager.id
            assert data_entry.leave_approver_id == manager.id


def test_sampleman_leave_routes_to_supervisor_and_uses_field_manager_fallback_when_supervisor_unavailable():
    with TestClient(app) as c:
        login(c, 'sampleman@tsco.local')
        r = c.post('/control/availability/request', data={
            'start_at': '2031-01-10T08:00', 'end_at': '2031-01-12T17:00', 'notes': 'Primary route test'
        }, follow_redirects=False)
        assert r.status_code == 303
        logout(c)
        with SessionLocal() as db:
            sampleman = get_user(db, 'sampleman@tsco.local')
            supervisor = get_user(db, 'sampling.supervisor@tsco.local')
            first = db.scalar(select(StaffAvailability).where(
                StaffAvailability.user_id == sampleman.id,
                StaffAvailability.entry_type == 'LEAVE',
                StaffAvailability.start_at == datetime(2031, 1, 10, 8, 0),
            ))
            assert first and first.approver_id == supervisor.id and first.status == 'PENDING_MANAGER'
            first_id = first.id
        login(c, 'sampling.supervisor@tsco.local')
        r = c.post(f'/control/availability/{first_id}/transition', data={'decision': 'APPROVE'}, follow_redirects=False)
        assert r.status_code == 303
        logout(c)
        with SessionLocal() as db:
            assert db.get(StaffAvailability, first_id).status == 'MANAGER_APPROVED'
            supervisor = get_user(db, 'sampling.supervisor@tsco.local')
            manager = get_user(db, 'field.manager@tsco.local')
            db.add(StaffAvailability(
                site_id=supervisor.site_id, user_id=supervisor.id, entry_type='LEAVE',
                start_at=datetime(2031, 2, 10, 8), end_at=datetime(2031, 2, 15, 17),
                status='MANAGER_APPROVED', approver_id=manager.id, approved_by_id=manager.id,
                created_by_id=supervisor.id, notes='Supervisor unavailable for fallback test',
            ))
            db.commit()
        login(c, 'sampleman@tsco.local')
        r = c.post('/control/availability/request', data={
            'start_at': '2031-02-11T08:00', 'end_at': '2031-02-12T17:00', 'notes': 'Fallback route test'
        }, follow_redirects=False)
        assert r.status_code == 303
        logout(c)
        with SessionLocal() as db:
            sampleman = get_user(db, 'sampleman@tsco.local')
            manager = get_user(db, 'field.manager@tsco.local')
            second = db.scalar(select(StaffAvailability).where(
                StaffAvailability.user_id == sampleman.id,
                StaffAvailability.entry_type == 'LEAVE',
                StaffAvailability.start_at == datetime(2031, 2, 11, 8, 0),
            ))
            assert second and second.approver_id == manager.id and second.status == 'PENDING_MANAGER'



def test_field_manager_can_act_if_supervisor_becomes_unavailable_after_sampleman_request():
    with TestClient(app) as c:
        login(c, 'sampleman@tsco.local')
        r = c.post('/control/availability/request', data={
            'start_at': '2033-04-10T08:00', 'end_at': '2033-04-12T17:00', 'notes': 'Late fallback visibility test'
        }, follow_redirects=False)
        assert r.status_code == 303
        logout(c)

        with SessionLocal() as db:
            sampleman = get_user(db, 'sampleman@tsco.local')
            supervisor = get_user(db, 'sampling.supervisor@tsco.local')
            manager = get_user(db, 'field.manager@tsco.local')
            leave = db.scalar(select(StaffAvailability).where(
                StaffAvailability.user_id == sampleman.id,
                StaffAvailability.start_at == datetime(2033, 4, 10, 8, 0),
            ))
            assert leave and leave.approver_id == supervisor.id
            leave_id = leave.id
            db.add(StaffAvailability(
                site_id=supervisor.site_id, user_id=supervisor.id, entry_type='TRAINING',
                start_at=datetime(2033, 4, 10, 7), end_at=datetime(2033, 4, 12, 18),
                status='APPROVED', approver_id=manager.id, approved_by_id=manager.id,
                created_by_id=manager.id, notes='Supervisor became unavailable after request',
            ))
            db.commit()

        login(c, 'field.manager@tsco.local')
        page = c.get('/control/my-availability')
        assert page.status_code == 200
        assert f'/control/availability/{leave_id}/transition' in page.text
        r = c.post(f'/control/availability/{leave_id}/transition', data={'decision': 'APPROVE'}, follow_redirects=False)
        assert r.status_code == 303
        logout(c)
        with SessionLocal() as db:
            assert db.get(StaffAvailability, leave_id).status == 'MANAGER_APPROVED'

def test_senior_leave_requires_valid_acting_backup_and_coverage_before_manager_approval():
    with TestClient(app) as c:
        with SessionLocal() as db:
            acting = get_user(db, 'senior.equipment@tsco.local')
            acting_id = acting.id

        login(c, 'senior.technical@tsco.local')
        r = c.post('/control/availability/request', data={
            'start_at': '2032-03-10T08:00', 'end_at': '2032-03-12T17:00',
            'notes': 'Coverage gate test', 'acting_senior_id': ''
        }, follow_redirects=False)
        assert r.status_code == 303
        logout(c)

        with SessionLocal() as db:
            senior = get_user(db, 'senior.technical@tsco.local')
            leave = db.scalar(select(StaffAvailability).where(
                StaffAvailability.user_id == senior.id,
                StaffAvailability.entry_type == 'LEAVE',
                StaffAvailability.start_at == datetime(2032, 3, 10, 8, 0),
            ))
            assert leave and leave.status == 'COVERAGE_ACTION_REQUIRED'
            coverage = db.scalar(select(LeaveCoverageAssignment).where(LeaveCoverageAssignment.leave_availability_id == leave.id))
            assert coverage and coverage.status == 'ACTION_REQUIRED' and coverage.acting_user_id is None
            leave_id = leave.id

        login(c, 'senior.technical@tsco.local')
        r = c.post(f'/control/availability/{leave_id}/coverage', data={'acting_senior_id': str(acting_id)}, follow_redirects=False)
        assert r.status_code == 303
        logout(c)

        with SessionLocal() as db:
            leave = db.get(StaffAvailability, leave_id)
            coverage = db.scalar(select(LeaveCoverageAssignment).where(LeaveCoverageAssignment.leave_availability_id == leave_id))
            assert leave.status == 'PENDING_MANAGER'
            assert coverage.status == 'COVERAGE_OK'
            assert coverage.acting_user_id == acting_id
            assert coverage.available_senior_count >= coverage.required_minimum

        login(c, 'lab.manager@tsco.local')
        r = c.post(f'/control/availability/{leave_id}/transition', data={'decision': 'APPROVE'}, follow_redirects=False)
        assert r.status_code == 303
        logout(c)
        with SessionLocal() as db:
            assert db.get(StaffAvailability, leave_id).status == 'MANAGER_APPROVED'
