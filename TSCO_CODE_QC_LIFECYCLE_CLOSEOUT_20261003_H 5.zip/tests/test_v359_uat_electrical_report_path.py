from __future__ import annotations

import base64
import json
import math
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import Asset, Client, ControlledReport, EquipmentAsset, SampleRequest, Site, User
from app.services.lab_operations import (
    get_operations_state,
    platform_sample_lab_readiness,
    save_operations_state,
    validate_operations_update,
)


def _data_url(text: str) -> str:
    return "data:text/csv;base64," + base64.b64encode(text.encode()).decode()


def _login(c: TestClient, email: str) -> None:
    r = c.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303


def _logout(c: TestClient) -> None:
    c.post('/logout', follow_redirects=False)


def test_uat_electrical_qc_results_senior_review_and_official_report_release():
    token = uuid4().hex[:8].upper()
    batch_id = f'LB-V359-{token}'
    assignment_id = f'WSA-V359-{token}-ELECTRICAL'
    sample_key = f'FS-DMM-V359-{token}'

    with TestClient(app) as c:
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            client = db.scalar(select(Client).where(Client.code == 'SEC')); assert client
            asset = db.scalar(select(Asset).where(Asset.client_id == client.id)); assert asset
            chemist = db.scalar(select(User).where(User.email == 'chemist@tsco.local')); assert chemist
            senior = db.scalar(select(User).where(User.email == 'senior@tsco.local')); assert senior
            bdv_eq = db.scalar(select(EquipmentAsset).where(EquipmentAsset.site_id == site.id, EquipmentAsset.equipment_id == 'EQ-25')); assert bdv_eq
            pf_eq = db.scalar(select(EquipmentAsset).where(EquipmentAsset.site_id == site.id, EquipmentAsset.equipment_id == 'EQ-26')); assert pf_eq

            state, original_payload = get_operations_state(db, site)
            original_json, original_revision, original_updated_by = state.json_data, state.revision, state.updated_by_id

            sample = SampleRequest(
                request_number=f'V359-{token}', public_token=f'PUB-V359-{token}', barcode_value=f'BAR-V359-{token}',
                lms_number=sample_key, status='TESTING', site_id=site.id, client_id=client.id, asset_id=asset.id,
                sample_date_time=datetime.utcnow(), sampling_point='Main Tank', sample_origin='Client-Originated / Direct Delivery',
                requested_package='Electrical UAT',
            )
            db.add(sample); db.flush()

            base = deepcopy(original_payload)
            base.setdefault('batches', []).append({
                'id': batch_id, 'platform_sample_id': sample.id, 'platform_sample_ids': [sample.id],
                'samples': [sample_key], 'sample_meta': {sample_key: {}}, 'status': 'Testing', 'priority': 'Normal',
                'tests': [
                    {'test': 'Breakdown Voltage @2.5mm- AVG', 'method': 'IEC 60156', 'station': 'Electrical', 'unit': 'kV'},
                    {'test': 'RSD% of BDV @2.5mm', 'method': 'IEC 60156', 'station': 'Electrical', 'unit': '%'},
                    {'test': 'Power Factor @25°C/60Hz', 'method': 'ASTM D924', 'station': 'Electrical', 'unit': '%'},
                    {'test': 'Power Factor @100°C/60Hz', 'method': 'ASTM D924', 'station': 'Electrical', 'unit': '%'},
                ],
            })
            base.setdefault('testAssignments', []).append({
                'id': assignment_id, 'batch_id': batch_id, 'scope': 'BATCH', 'workstation': 'Electrical', 'mode': 'SINGLE',
                'primary_user_id': chemist.id, 'primary_name': chemist.full_name, 'backup_user_id': None, 'backup_name': '',
                'assigned_by_user_id': senior.id, 'assigned_by': senior.full_name, 'assigned_at': datetime.utcnow().isoformat(),
                'revision': 1, 'access_scope': 'NAMED_USERS',
            })

            # Technician proposes three exact-context QC lots (BDV, PF25, PF100) with retained qualification evidence.
            proposed = deepcopy(base)
            lots = [
                ('LOT-BDV-'+token, 'BDV', 'Breakdown Voltage @2.5mm- AVG', 'IEC 60156', bdv_eq.id, 60.0, 50.0, 70.0),
                ('LOT-PF25-'+token, 'PF', 'Power Factor @25°C/60Hz', 'ASTM D924', pf_eq.id, 0.10, 0.05, 0.15),
                ('LOT-PF100-'+token, 'PF', 'Power Factor @100°C/60Hz', 'ASTM D924', pf_eq.id, 1.20, 1.00, 1.50),
            ]
            for lot_id, group, context_test, method, eq_id, target, low, high in lots:
                evid = 'QUAL-'+lot_id
                proposed.setdefault('qcEvidence', []).append({
                    'id': evid, 'kind': 'qc-lot-qualification', 'lot_id': lot_id,
                    'name': f'{lot_id}_qualification.csv', 'type': 'text/csv', 'data': _data_url('qualification,evidence\n'),
                })
                proposed.setdefault('qcLots', []).append({
                    'id': lot_id, 'source_type': 'INTERNAL', 'lot_code': lot_id,
                    'test': group, 'context_test': context_test, 'method_name': method,
                    'expiry_date': '2099-12-31', 'target': target,
                    'acceptance_low': low, 'acceptance_high': high,
                    'warning_low': low + (target-low)*0.4, 'warning_high': high - (high-target)*0.4,
                    'equipment_asset_ids': [eq_id], 'qualification_evidence_id': evid,
                })
            pending = validate_operations_update(base, proposed, chemist, db=db, site_id=site.id)

            # Senior activates each exact Test + Method + Equipment lot.
            approval = deepcopy(pending)
            for lot_id, *_ in lots:
                approval.setdefault('qcLotEvents', []).append({'id': 'APP-'+lot_id, 'lot_id': lot_id, 'action': 'APPROVE'})
            active = validate_operations_update(pending, approval, senior, db=db, site_id=site.id)

            # File-first routine QC: BDV exact six-run source + one PF source covering both temperatures.
            run = deepcopy(active)
            run.setdefault('qcEvidence', []).extend([
                {
                    'id': 'RUN-BDV-'+token, 'kind': 'qc-run-source', 'lot_id': 'LOT-BDV-'+token,
                    'test': 'BDV', 'context_test': 'Breakdown Voltage @2.5mm- AVG', 'method_name': 'IEC 60156',
                    'equipment_asset_id': bdv_eq.id, 'name': 'BDV_QC_run.csv', 'type': 'text/csv',
                    'data': _data_url('Run1,58\nRun2,59\nRun3,60\nRun4,61\nRun5,62\nRun6,60\n'),
                },
                {
                    'id': 'RUN-PF-'+token, 'kind': 'qc-run-source', 'lot_id': 'LOT-PF25-'+token,
                    'test': 'PF', 'context_test': 'Power Factor @25°C/60Hz', 'method_name': 'ASTM D924',
                    'equipment_asset_id': pf_eq.id, 'name': 'PF_QC_run.csv', 'type': 'text/csv',
                    'data': _data_url('PF25,0.101\nPF100,1.234\n'),
                },
            ])
            run.setdefault('qc', []).extend([
                {
                    'id': 'QC-BDV-'+token, 'mode': 'routine', 'test': 'BDV', 'context_test': 'Breakdown Voltage @2.5mm- AVG',
                    'method_name': 'IEC 60156', 'assignment_id': assignment_id, 'batch_id': batch_id,
                    'equipment_asset_id': bdv_eq.id, 'qc_lot_id': 'LOT-BDV-'+token, 'evidence_id': 'RUN-BDV-'+token,
                    'result': '0', 'status': 'PASS',
                },
                {
                    'id': 'QC-PF25-'+token, 'mode': 'routine', 'test': 'PF', 'context_test': 'Power Factor @25°C/60Hz',
                    'method_name': 'ASTM D924', 'assignment_id': assignment_id, 'batch_id': batch_id,
                    'equipment_asset_id': pf_eq.id, 'qc_lot_id': 'LOT-PF25-'+token, 'evidence_id': 'RUN-PF-'+token,
                    'result': '0', 'status': 'PASS',
                },
                {
                    'id': 'QC-PF100-'+token, 'mode': 'routine', 'test': 'PF', 'context_test': 'Power Factor @100°C/60Hz',
                    'method_name': 'ASTM D924', 'assignment_id': assignment_id, 'batch_id': batch_id,
                    'equipment_asset_id': pf_eq.id, 'qc_lot_id': 'LOT-PF100-'+token, 'evidence_id': 'RUN-PF-'+token,
                    'result': '0', 'status': 'PASS',
                },
            ])
            qc_ready = validate_operations_update(active, run, chemist, db=db, site_id=site.id)
            assert {q['status'] for q in qc_ready['qc'] if str(q.get('id','')).endswith(token)} == {'PASS'}

            # Same sample result files: BDV average + derived RSD, PF25 + PF100; then close Electrical assignment.
            values = [70.2, 71.5, 72.0, 72.8, 73.5, 74.4]
            mean = sum(values)/len(values)
            sd = math.sqrt(sum((x-mean)**2 for x in values)/(len(values)-1))
            rsd = sd/mean*100
            calc = {'method': 'IEC 60156', 'inputs': {f'R{i+1}': v for i, v in enumerate(values)}}
            results = deepcopy(qc_ready)
            results.setdefault('results', []).extend([
                {'id':'R-BDV-'+token, 'batch':batch_id, 'sample':sample_key, 'test':'Breakdown Voltage @2.5mm- AVG', 'display_test':'Breakdown Voltage @2.5mm- AVG', 'result':f'{mean:.2f}', 'calculation':calc, 'source':'BDV instrument CSV'},
                {'id':'R-RSD-'+token, 'batch':batch_id, 'sample':sample_key, 'test':'RSD% of BDV @2.5mm', 'display_test':'RSD% of BDV @2.5mm', 'result':f'{rsd:.2f}', 'calculated':True, 'calculation':calc, 'source':'Derived from BDV run set'},
                {'id':'R-PF25-'+token, 'batch':batch_id, 'sample':sample_key, 'test':'Power Factor @25°C/60Hz', 'display_test':'Power Factor @25°C/60Hz', 'result':'0.0342'},
                {'id':'R-PF100-'+token, 'batch':batch_id, 'sample':sample_key, 'test':'Power Factor @100°C/60Hz', 'display_test':'Power Factor @100°C/60Hz', 'result':'0.4893'},
            ])
            results.setdefault('assignmentCompletions', []).append({
                'id':'COMP-'+token, 'batch_id':batch_id, 'workstation':'Electrical', 'assignment_id':assignment_id,
            })
            completed = validate_operations_update(qc_ready, results, chemist, db=db, site_id=site.id)
            electrical_rows = [r for r in completed['results'] if str(r.get('id','')).endswith(token)]
            measured = [r for r in electrical_rows if not r.get('calculated')]
            assert len(electrical_rows) == 4
            assert all(r.get('qc_status') == 'PASS' for r in measured)
            assert all(r.get('qc_lot_id') and r.get('qc_evidence_id') for r in measured)
            assert completed['assignmentCompletions'][-1]['completed_by_user_id'] == chemist.id

            save_operations_state(db, state, completed, actor=chemist)
            sample.status = 'TECHNICAL_REVIEW'
            db.commit(); sid = sample.id
            ready, reason = platform_sample_lab_readiness(db, sample)
            assert ready, reason

        # Senior sees exact Electrical results in Final Analysis Report preview and completes sign-off.
        _login(c, 'senior@tsco.local')
        report_number = f'TSCO-V359-{token}'
        created = c.post('/control/report', data={
            'sample_request_id': sid, 'report_number': report_number, 'condition_status': 'NORMAL',
            'interpretation': '', 'recommendation': '', 'dga_requested': '', 'corrosive_requested': '', 'paper_requested': '',
            'supersedes_report_id': '', 'amendment_reason': '',
        }, follow_redirects=False)
        assert created.status_code == 303
        with SessionLocal() as db:
            report = db.scalar(select(ControlledReport).where(ControlledReport.report_number == report_number)); assert report
            rid = report.id

        page = c.get(f'/control/report/{rid}/review')
        assert page.status_code == 200
        assert 'Breakdown Voltage' in page.text
        assert 'Power Factor' in page.text
        assert 'READY FOR SENIOR SIGN-OFF' in page.text

        signed = c.post(f'/control/report/{rid}/review', data={
            'action':'COMPLETE', 'condition_status':'NORMAL',
            'interpretation':'Electrical results reviewed against controlled laboratory evidence.',
            'recommendation':'Continue routine monitoring at the normal interval.',
            'confirm_results':'1', 'confirm_identity':'1', 'confirm_interpretation':'1', 'confirm_evidence':'1', 'confirm_recommendation':'1',
        }, follow_redirects=False)
        assert signed.status_code == 303, signed.text[:500]

        _logout(c); _login(c, 'technical@tsco.local')
        released = c.post(f'/control/report/{rid}/approve', follow_redirects=False)
        assert released.status_code == 303, released.text[:500]
        with SessionLocal() as db:
            report = db.get(ControlledReport, rid); sample = db.get(SampleRequest, sid)
            assert report.status == 'REPORT_RELEASED'
            assert sample.status == 'REPORT_RELEASED'
            assert report.official_pdf_path and Path(report.official_pdf_path).is_file()
            assert report.official_pdf_sha256 and len(report.official_pdf_sha256) == 64
            # Restore OperationsState so this integration test does not pollute other tests.
            state, _ = get_operations_state(db, db.scalar(select(Site).where(Site.code == 'DMM')))
            state.json_data = original_json
            state.revision = original_revision
            state.updated_by_id = original_updated_by
            db.commit()
