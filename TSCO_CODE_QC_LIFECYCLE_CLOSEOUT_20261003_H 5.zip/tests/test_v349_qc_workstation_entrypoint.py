from fastapi.testclient import TestClient

from app.main import app


def login(browser: TestClient, email: str = "technician@tsco.local"):
    r = browser.post("/login", data={"email": email, "password": "Demo123!"}, follow_redirects=False)
    assert r.status_code == 303


def test_technician_workstation_has_visible_analytical_qc_entrypoint():
    with TestClient(app) as browser:
        login(browser)
        shell = browser.get("/lab/operations?section=workstations&workstation=Water")
        assert shell.status_code == 200
        assert 'id="platformAnalyticalQcLink"' in shell.text
        assert 'section=quality' in shell.text
        page = browser.get("/lab/operations/app?embed=1&section=workstations&workstation=Water")
        assert page.status_code == 200
        assert 'id="wsQc"' in page.text
        assert '>ANALYTICAL QC</button>' in page.text
        assert "qcEntry.style.display='inline-flex'" in page.text


def test_quality_deeplink_preserves_water_workstation_context():
    with TestClient(app) as browser:
        login(browser)
        page = browser.get("/lab/operations/app?embed=1&section=quality&workstation=Water")
        assert page.status_code == 200
        assert 'window.TSCO_PLATFORM_WORKSTATION="Water"' in page.text
        assert "section==='quality'&&workstation" in page.text
        assert "availableQcTests().filter(q=>qcWorkstation(q)===workstation)" in page.text
