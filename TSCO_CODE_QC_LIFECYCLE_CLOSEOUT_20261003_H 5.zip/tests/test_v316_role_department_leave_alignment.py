from datetime import datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import StaffAvailability, User
from app.org_structure import employee_spec


def login(client: TestClient, email: str, password: str = "Demo123!"):
    response = client.post("/login", data={"email": email, "password": password}, follow_redirects=False)
    assert response.status_code == 303, (email, response.status_code, response.text[:300])


def logout(client: TestClient):
    client.get("/logout", follow_redirects=False)


def leave_window(days_from_now: int = 30):
    start = datetime.now() + timedelta(days=days_from_now)
    end = start + timedelta(days=3)
    return start.strftime("%Y-%m-%dT%H:%M"), end.strftime("%Y-%m-%dT%H:%M")


def test_named_employee_reporting_and_leave_approver_source_of_truth():
    with TestClient(app):
        with SessionLocal() as db:
            expected = {
                "renad.alqahtani@tsco.local": ("salah.alshajira@tsco.local", "salah.alshajira@tsco.local"),
                "ohood.alhareeqi@tsco.local": ("salah.alshajira@tsco.local", "salah.alshajira@tsco.local"),
                "ahmed.alqahtani@tsco.local": ("abdulmajeed@tsco.local", "abdulmajeed@tsco.local"),
                "mohammed.amir@tsco.local": ("abdulmajeed@tsco.local", "abdulmajeed@tsco.local"),
                "malindu.eranda@tsco.local": ("abdulmajeed@tsco.local", "abdulmajeed@tsco.local"),
                "rwad@tsco.local": ("salah.alshajira@tsco.local", "salah.alshajira@tsco.local"),
                "mohammed.alyahya@tsco.local": ("rwad@tsco.local", "rwad@tsco.local"),
                "anas.asiri@tsco.local": ("rwad@tsco.local", "rwad@tsco.local"),
                "sahid.husain@tsco.local": ("rwad@tsco.local", "rwad@tsco.local"),
            }
            for email, (manager_email, approver_email) in expected.items():
                user = db.scalar(select(User).where(User.email == email))
                assert user is not None, email
                assert user.manager is not None and user.manager.email == manager_email
                assert user.leave_approver is not None and user.leave_approver.email == approver_email

            gm = db.scalar(select(User).where(User.email == "salah.alshajira@tsco.local"))
            assert gm is not None and gm.manager_id is None and gm.leave_approver_id is None


def test_secretary_is_gm_office_only_and_cannot_enter_lab_or_controlled_lab_documents():
    with TestClient(app) as client:
        login(client, "renad.alqahtani@tsco.local")
        home = client.get("/", follow_redirects=False)
        assert home.status_code == 303 and home.headers["location"] == "/workspace"

        workspace = client.get("/workspace")
        assert workspace.status_code == 200
        assert "Secretary" in workspace.text
        assert "Salah Al-Shajira" in workspace.text
        assert "GM office coordination" in workspace.text
        assert 'href="/lab/operations' not in workspace.text
        assert 'href="/documents"' not in workspace.text
        assert 'href="/control/my-availability"' in workspace.text

        assert client.get("/lab/operations?section=workstations").status_code == 403
        assert client.get("/control/daily-brief").status_code == 403
        assert client.get("/documents").status_code == 403


def test_secretary_leave_routes_directly_to_gm_and_only_gm_can_decide():
    with TestClient(app) as client:
        login(client, "renad.alqahtani@tsco.local")
        start_at, end_at = leave_window(40)
        response = client.post(
            "/control/availability/request",
            data={"start_at": start_at, "end_at": end_at, "notes": "Annual planning test"},
            follow_redirects=False,
        )
        assert response.status_code == 303
        with SessionLocal() as db:
            renad = db.scalar(select(User).where(User.email == "renad.alqahtani@tsco.local"))
            salah = db.scalar(select(User).where(User.email == "salah.alshajira@tsco.local"))
            row = db.scalar(select(StaffAvailability).where(
                StaffAvailability.user_id == renad.id,
                StaffAvailability.entry_type == "LEAVE",
                StaffAvailability.notes == "Annual planning test",
            ).order_by(StaffAvailability.id.desc()))
            assert row is not None
            request_id = row.id
            assert row.status == "PENDING_MANAGER"
            assert row.approver_id == salah.id

        logout(client)
        login(client, "rwad@tsco.local")
        denied = client.post(
            f"/control/availability/{request_id}/transition",
            data={"decision": "APPROVE"},
            follow_redirects=False,
        )
        assert denied.status_code == 400
        assert "direct leave approver" in denied.text

        logout(client)
        login(client, "salah.alshajira@tsco.local")
        approved = client.post(
            f"/control/availability/{request_id}/transition",
            data={"decision": "APPROVE"},
            follow_redirects=False,
        )
        assert approved.status_code == 303
        with SessionLocal() as db:
            row = db.get(StaffAvailability, request_id)
            salah = db.scalar(select(User).where(User.email == "salah.alshajira@tsco.local"))
            assert row.status == "MANAGER_APPROVED"
            assert row.approved_by_id == salah.id


def test_lab_employee_leave_routes_to_lab_manager_not_to_senior_chemist():
    with TestClient(app) as client:
        login(client, "anas.asiri@tsco.local")
        start_at, end_at = leave_window(70)
        response = client.post(
            "/control/availability/request",
            data={"start_at": start_at, "end_at": end_at, "notes": "Lab leave routing test"},
            follow_redirects=False,
        )
        assert response.status_code == 303
        with SessionLocal() as db:
            anas = db.scalar(select(User).where(User.email == "anas.asiri@tsco.local"))
            rwad = db.scalar(select(User).where(User.email == "rwad@tsco.local"))
            row = db.scalar(select(StaffAvailability).where(
                StaffAvailability.user_id == anas.id,
                StaffAvailability.notes == "Lab leave routing test",
            ).order_by(StaffAvailability.id.desc()))
            assert row is not None
            assert row.status == "PENDING_MANAGER"
            assert row.approver_id == rwad.id
            request_id = row.id

        logout(client)
        login(client, "mohammed.alyahya@tsco.local")
        denied = client.post(
            f"/control/availability/{request_id}/transition",
            data={"decision": "APPROVE"},
            follow_redirects=False,
        )
        assert denied.status_code == 400

        logout(client)
        login(client, "rwad@tsco.local")
        approved = client.post(
            f"/control/availability/{request_id}/transition",
            data={"decision": "APPROVE"},
            follow_redirects=False,
        )
        assert approved.status_code == 303


def test_shared_service_uat_function_account_has_no_invented_employee_leave_chain():
    with TestClient(app) as client:
        login(client, "hr@tsco.local")
        workspace = client.get("/workspace")
        assert workspace.status_code == 200
        assert "SHARED SERVICES FUNCTION ACCOUNT" in workspace.text
        assert "no invented reporting manager or leave chain" in workspace.text
        denied = client.post(
            "/control/availability/request",
            data={"start_at": "2026-12-01T08:00", "end_at": "2026-12-04T08:00", "notes": "Should not route"},
            follow_redirects=False,
        )
        assert denied.status_code == 403


def test_employee_spec_defines_exact_job_need_and_boundary_for_secretary_and_lab_roles():
    secretary = employee_spec("renad.alqahtani@tsco.local")
    chemist = employee_spec("ali.alorain@tsco.local")
    field = employee_spec("mohammed.amir@tsco.local")
    assert secretary and "GM office coordination" in secretary.workspace_summary
    assert "No samples/results/QC" in secretary.boundaries
    assert chemist and "Assigned analytical work" in chemist.workspace_summary
    assert field and "Assigned field work" in field.workspace_summary
