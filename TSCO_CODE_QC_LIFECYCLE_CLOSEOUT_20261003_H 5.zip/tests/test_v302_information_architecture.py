from fastapi.testclient import TestClient

from app.main import app


def login(client, email, password="Demo123!"):
    r = client.post("/login", data={"email": email, "password": password}, follow_redirects=False)
    assert r.status_code == 303


def test_lab_technician_navigation_is_compact_and_has_single_integrated_knowledge_entry():
    with TestClient(app) as client:
        login(client, "chemist@tsco.local")
        page = client.get("/lab/operations?section=workstations")
        assert page.status_code == 200
        assert "Methods / SOPs / EOPs" in page.text
        assert 'href="/documents"' not in page.text
        assert "Laboratory Operations Display" not in page.text
        assert "nav-group" in page.text


def test_quality_and_senior_do_not_receive_tv_display_as_department_workspace():
    with TestClient(app) as client:
        login(client, "quality@tsco.local")
        assert client.get("/lab/operations?section=labprogress").status_code == 403
    with TestClient(app) as client:
        login(client, "senior@tsco.local")
        assert client.get("/lab/operations?section=labprogress").status_code == 403


def test_technical_manager_has_one_dedicated_operations_display_entry():
    with TestClient(app) as client:
        login(client, "technical@tsco.local")
        page = client.get("/management")
        assert page.status_code == 200
        assert page.text.count("Laboratory Operations Display") == 1


def test_public_page_keeps_about_vision_and_laboratories_compact_inside_drawers():
    with TestClient(app) as client:
        page = client.get("/welcome")
        assert page.status_code == 200
        assert page.text.count('class="public-rail-item"') == 3
        assert "Our Vision" in page.text
        assert "Our Laboratories" in page.text
        assert "compressed thumbnails" in page.text
