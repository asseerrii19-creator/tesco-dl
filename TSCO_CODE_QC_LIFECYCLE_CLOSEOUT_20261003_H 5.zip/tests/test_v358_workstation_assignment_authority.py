from datetime import datetime
from types import SimpleNamespace

from app.services import lab_operations as ops


def _base_payload():
    return {
        'batches': [], 'results': [], 'qc': [], 'qualifiedQcProfiles': [], 'qcLots': [], 'qcLotEvents': [],
        'qcEvidence': [], 'retests': [], 'dgaAttachments': [], 'resultEvidence': [], 'assignmentCompletions': [],
        'qualityDistributions': [], 'qualityTaskEvents': [], 'reports': [], 'retained': [], 'storageAssignments': [],
        'batchHistory': [], 'cancelledSamples': [], 'supervisorNotes': [], 'standards': [], 'staff': [], 'clients': [],
        'settings': {}, 'meta': {'revision': 1}, 'drafts': {}, 'calculationDrafts': {}, 'testAssignments': [],
    }


def test_active_global_workstation_assignment_survives_empty_batch_queue():
    user = SimpleNamespace(id=17, role='lab_technician')
    payload = _base_payload()
    payload['testAssignments'] = [{
        'id': 'WSA-AUTO-20260927-20261010-ELECTRICAL', 'batch_id': '*', 'scope': 'WORKSTATION',
        'workstation': 'Electrical', 'mode': 'SINGLE', 'revision': 1,
        'primary_user_id': 17, 'primary_name': 'UAT Role — Chemist', 'backup_user_id': None,
        'source': 'AUTO_14_DAY_ROTATION', 'cycle_key': '20260927-20261010',
        'cycle_start': '2026-09-27T00:00:00', 'cycle_end': '2026-10-10T23:59:59',
        'assigned_at': '2026-09-29T15:51:50',
    }]
    scoped = ops.scope_operations_payload(payload, user)
    assert scoped['batches'] == []
    assert len(scoped['testAssignments']) == 1
    assert scoped['testAssignments'][0]['workstation'] == 'Electrical'
    assert scoped['testAssignments'][0]['primary_user_id'] == 17


def test_same_cycle_history_restores_original_electrical_owner_even_if_current_availability_changed(monkeypatch):
    chemist = SimpleNamespace(id=17, full_name='UAT Role — Chemist', role='lab_technician', active=True, site_id=1)
    technician = SimpleNamespace(id=18, full_name='UAT Role — Chemical Technician', role='lab_technician', active=True, site_id=1)

    class ScalarRows:
        def all(self):
            return [chemist, technician]

    class FakeDb:
        def scalars(self, _stmt):
            return ScalarRows()

    monkeypatch.setattr(ops, '_analytical_candidate_available', lambda *args, **kwargs: False)
    payload = _base_payload()
    payload['batchHistory'] = [{
        'id': 'BH-AUTO-ASSIGN-LB-ORIGINAL',
        'action': 'Automatic 14-Day Analytical Assignment',
        'details': 'DGA → UAT Role — Chemical Technician · Electrical → UAT Role — Chemist · Additives / Special Tests → UAT Role — Chemical Technician',
        'ts': '2026-09-29T15:51:50',
    }]
    # Simulate the bad same-cycle re-materialization that silently moved Electrical.
    payload['testAssignments'] = [{
        'id': 'WSA-AUTO-20260927-20261010-ELECTRICAL', 'batch_id': '*', 'scope': 'WORKSTATION',
        'workstation': 'Electrical', 'mode': 'SINGLE', 'revision': 1,
        'primary_user_id': 18, 'primary_name': 'UAT Role — Chemical Technician', 'backup_user_id': None,
        'source': 'AUTO_14_DAY_ROTATION', 'cycle_key': '20260927-20261010',
        'cycle_start': '2026-09-27T00:00:00', 'cycle_end': '2026-10-10T23:59:59',
        'assigned_at': '2026-10-03T18:00:00',
    }]

    repaired = ops.reconcile_analytical_rotation_continuity(
        FakeDb(), 1, payload, {'Electrical'}, when=datetime(2026, 10, 3, 19, 0, 0)
    )
    assert len(repaired) == 1
    assert repaired[0]['primary_user_id'] == 17
    assert repaired[0]['primary_name'] == 'UAT Role — Chemist'
    assert repaired[0]['revision'] == 2
    assert repaired[0]['source'] == 'AUTO_14_DAY_ROTATION_CONTINUITY_REPAIR'
    current = ops._current_test_assignment(payload, 'ANY-BATCH', 'Electrical')
    assert current['primary_user_id'] == 17


def test_same_cycle_repair_restores_electrical_and_removes_wrong_additives_owner(monkeypatch):
    chemist = SimpleNamespace(id=17, full_name='UAT Role — Chemist', role='lab_technician', active=True, site_id=1)
    technician = SimpleNamespace(id=18, full_name='UAT Role — Chemical Technician', role='lab_technician', active=True, site_id=1)

    class ScalarRows:
        def all(self):
            return [chemist, technician]

    class FakeDb:
        def scalars(self, _stmt):
            return ScalarRows()

    # Simulate a mid-cycle availability change. Continuity must still preserve the already
    # published cycle owner; coverage changes require an explicit Senior exception.
    monkeypatch.setattr(ops, '_analytical_candidate_available', lambda *args, **kwargs: False)
    payload = _base_payload()
    payload['batchHistory'] = [{
        'id': 'BH-AUTO-ASSIGN-LB-ORIGINAL',
        'action': 'Automatic 14-Day Analytical Assignment',
        'details': 'Electrical → UAT Role — Chemist · Additives / Special Tests → UAT Role — Chemical Technician',
        'ts': '2026-09-29T15:51:50',
    }]
    payload['testAssignments'] = [
        {
            'id': 'WSA-BAD-ELECTRICAL', 'batch_id': '*', 'scope': 'WORKSTATION',
            'workstation': 'Electrical', 'mode': 'SINGLE', 'revision': 2,
            'primary_user_id': 18, 'primary_name': 'UAT Role — Chemical Technician', 'backup_user_id': None,
            'source': 'AUTO_14_DAY_ROTATION', 'cycle_key': '20260927-20261010',
            'cycle_start': '2026-09-27T00:00:00', 'cycle_end': '2026-10-10T23:59:59',
            'assigned_at': '2026-10-03T18:00:00',
        },
        {
            'id': 'WSA-BAD-ADDITIVES', 'batch_id': '*', 'scope': 'WORKSTATION',
            'workstation': 'Additives / Special Tests', 'mode': 'SINGLE', 'revision': 2,
            'primary_user_id': 17, 'primary_name': 'UAT Role — Chemist', 'backup_user_id': None,
            'source': 'AUTO_14_DAY_ROTATION', 'cycle_key': '20260927-20261010',
            'cycle_start': '2026-09-27T00:00:00', 'cycle_end': '2026-10-10T23:59:59',
            'assigned_at': '2026-10-03T18:00:00',
        },
    ]

    repaired = ops.reconcile_analytical_rotation_continuity(
        FakeDb(), 1, payload, {'Electrical', 'Additives / Special Tests'}, when=datetime(2026, 10, 4, 3, 0, 0)
    )
    assert len(repaired) == 2
    assert ops._current_test_assignment(payload, 'ANY', 'Electrical')['primary_user_id'] == 17
    assert ops._current_test_assignment(payload, 'ANY', 'Additives / Special Tests')['primary_user_id'] == 18



def test_frontend_workstation_visibility_uses_rotation_assignments_not_only_batches():
    from pathlib import Path
    html = (Path(__file__).resolve().parents[1] / 'app' / 'lab_ops' / 'index_template.html').read_text(encoding='utf-8')
    assert "(DB.testAssignments||[]).forEach" in html
    assert "String(a.batch_id||'')==='*'&&assignmentAllowsUser(a)" in html
