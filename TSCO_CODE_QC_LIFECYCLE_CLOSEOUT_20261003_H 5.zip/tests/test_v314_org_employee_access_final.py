from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import Department, User
from app.routes.organization import ORG_EMPLOYEES


def login(client, email, password='Demo123!'):
    r = client.post('/login', data={'email': email, 'password': password}, follow_redirects=False)
    assert r.status_code == 303, (email, r.status_code, r.text)


def test_v314_exact_source_chart_departments_only():
    with TestClient(app):
        with SessionLocal() as db:
            depts = {d.code: d.name for d in db.scalars(select(Department).where(Department.active.is_(True))).all()}
    assert depts == {
        'CORP': 'General Management',
        'SAM': 'Sales & Marketing Department',
        'SHARED': 'Shared Services',
        'LABS': 'Dammam & Bahrain Labs',
        'FIELD': 'Field Operations',
        'LAB': 'Laboratory Operations',
    }


def test_v314_all_named_people_have_one_active_canonical_login():
    expected = {email.lower(): (name, title, area, role) for name, email, title, area, role in ORG_EMPLOYEES}
    assert len(expected) == len(ORG_EMPLOYEES) == 32
    with TestClient(app):
        with SessionLocal() as db:
            rows = list(db.scalars(select(User).where(User.email.in_(expected.keys()))).all())
            assert len(rows) == 32
            for user in rows:
                name, _title, _area, role = expected[user.email.lower()]
                assert user.active is True
                assert user.full_name == name
                assert user.role == role


def test_v314_every_named_employee_can_authenticate():
    with TestClient(app) as client:
        for _name, email, _title, _area, _role in ORG_EMPLOYEES:
            login(client, email)
            client.post('/logout')


def test_v314_employee_directory_and_org_chart_are_visible_to_internal_staff():
    with TestClient(app) as client:
        login(client, 'anas.asiri@tsco.local')
        org = client.get('/organization')
        employees = client.get('/organization/employees')
        assert org.status_code == 200
        assert employees.status_code == 200
        for text in ['Salah Al-Shajira','Ohood Al Hareeqi','Ahmed Al Qahtani','Malindu Eranda','Rwad','Anas Asiri']:
            assert text in org.text or text in employees.text
        assert 'Employee Directory & Responsibilities' in employees.text
        assert 'Shared Intake Bridge' not in employees.text
        assert 'Quality Department' not in org.text
        assert 'Continuous Improvement Department' not in org.text
        assert 'Receiving Department' not in org.text


def test_v314_data_entry_is_one_login_with_stages_inside_same_workspace():
    with TestClient(app) as client:
        login(client, 'ahmed.alqahtani@tsco.local')
        page = client.get('/intake?view=incoming')
        assert page.status_code == 200
        for text in ['Incoming &amp; Verification','Physical Receiving','Batch &amp; Distribution','Released to Laboratory']:
            assert text in page.text
        assert 'Data Entry Workspace' in page.text


def test_v314_qhse_is_shared_service_not_company_quality_department():
    with TestClient(app) as client:
        login(client, 'qhse@tsco.local')
        org = client.get('/organization')
        assert org.status_code == 200
        assert 'SHARED SERVICES' in org.text
        assert 'QHSE' in org.text
        assert 'Quality Department' not in org.text
        quality = client.get('/quality')
        assert quality.status_code == 200


def test_v314_client_coordination_remains_under_field_operations():
    with TestClient(app) as client:
        login(client, 'malindu.eranda@tsco.local')
        page = client.get('/organization')
        assert page.status_code == 200
        assert 'FIELD OPERATIONAL &amp; TECHNICAL MANAGER' in page.text or 'FIELD OPERATIONAL & TECHNICAL MANAGER' in page.text
        assert 'CLIENT ACCOUNT &amp; COORDINATION OFFICER' in page.text or 'CLIENT ACCOUNT & COORDINATION OFFICER' in page.text
        assert 'Malindu Eranda' in page.text
