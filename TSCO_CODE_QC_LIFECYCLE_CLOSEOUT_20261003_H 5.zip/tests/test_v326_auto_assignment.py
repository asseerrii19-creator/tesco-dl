from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import Asset, Client, SampleRequest, Site, TestPackageConfig, User
from app.services.lab_operations import (
    _batch_workstations,
    get_operations_state,
    scope_operations_payload,
    sync_samples_to_operations,
)


def _make_received_sample(db, *, suffix: str) -> tuple[SampleRequest, User]:
    site = db.scalar(select(Site).where(Site.code == "DMM")); assert site
    client = db.scalar(select(Client).where(Client.code == "SEC")); assert client
    asset = db.scalar(select(Asset).where(Asset.client_id == client.id)); assert asset
    actor = db.scalar(select(User).where(User.email == "data.entry@tsco.local")); assert actor
    package = db.scalar(select(TestPackageConfig).where(TestPackageConfig.active.is_(True)).order_by(TestPackageConfig.id)); assert package
    sample = SampleRequest(
        request_number=f"V326-{suffix}", public_token=f"PUB-{suffix}", barcode_value=f"BAR-{suffix}",
        lms_number=f"LMS-{suffix}", status="RECEIVED", site_id=site.id, client_id=client.id, asset_id=asset.id,
        sample_date_time=datetime.utcnow(), sampling_point="Main Tank - Bottom",
        sample_origin="Client-Originated / Direct Delivery", submission_channel="CLIENT_DELIVERED",
        requested_package=package.name, priority="NORMAL", required_tat="Standard", received_at=datetime.utcnow(),
    )
    db.add(sample); db.flush()
    return sample, actor


def test_release_auto_publishes_14_day_named_assignments_and_technician_work():
    with TestClient(app) as client:
        with SessionLocal() as db:
            token = uuid4().hex[:8]
            sample, actor = _make_received_sample(db, suffix=token)
            site_id = sample.site_id
            batch_id = sync_samples_to_operations(db, [sample], actor, phase="READY_FOR_LAB")
            db.commit()
            site = db.get(Site, site_id); assert site
            _, payload = get_operations_state(db, site)
            batch = next(b for b in payload["batches"] if b["id"] == batch_id)
            stations = _batch_workstations(batch)
            current_defaults = [
                a for a in payload["testAssignments"]
                if a.get("batch_id") == "*" and a.get("workstation") in stations
            ]
            assert len(current_defaults) == len(stations)
            assert all(a.get("source") == "AUTO_14_DAY_ROTATION" for a in current_defaults)
            assert all(a.get("primary_user_id") for a in current_defaults)
            assert len({a.get("cycle_key") for a in current_defaults}) == 1

            assigned_users = [db.get(User, int(a["primary_user_id"])) for a in current_defaults]
            visible_pairs = set()
            for person in {u.id: u for u in assigned_users if u is not None}.values():
                scoped = scope_operations_payload(payload, person)
                assert any(b.get("id") == batch_id for b in scoped.get("batches", []))
                for row in scoped.get("testAssignments", []):
                    ws = str(row.get("workstation") or "")
                    if ws:
                        visible_pairs.add(ws)
            assert stations <= visible_pairs

            assigned_emails = [u.email for u in {u.id: u for u in assigned_users if u is not None}.values()]

        for email in assigned_emails:
            client.post("/logout")
            r = client.post("/login", data={"email": email, "password": "Demo123!"}, follow_redirects=False)
            assert r.status_code == 303
            page = client.get("/lab")
            assert page.status_code == 200
            assert batch_id in page.text


def test_second_release_same_cycle_reuses_rotation_without_senior_action():
    with TestClient(app):
        with SessionLocal() as db:
            s1, actor = _make_received_sample(db, suffix=uuid4().hex[:8])
            sync_samples_to_operations(db, [s1], actor, phase="READY_FOR_LAB")
            db.flush()
            site = db.get(Site, s1.site_id); assert site
            _, payload1 = get_operations_state(db, site)
            auto1 = [a for a in payload1["testAssignments"] if a.get("source") == "AUTO_14_DAY_ROTATION"]
            count1 = len(auto1)
            ids1 = {a["id"] for a in auto1}

            s2, actor2 = _make_received_sample(db, suffix=uuid4().hex[:8])
            sync_samples_to_operations(db, [s2], actor2, phase="READY_FOR_LAB")
            db.commit()
            _, payload2 = get_operations_state(db, site)
            auto2 = [a for a in payload2["testAssignments"] if a.get("source") == "AUTO_14_DAY_ROTATION"]
            assert len(auto2) == count1
            assert {a["id"] for a in auto2} == ids1


def test_senior_surface_describes_auto_rotation_as_monitor_override():
    with TestClient(app) as client:
        r = client.post("/login", data={"email": "senior.technical@tsco.local", "password": "Demo123!"}, follow_redirects=False)
        assert r.status_code == 303
        page = client.get("/lab/operations/app?embed=1&section=supervisor")
        assert page.status_code == 200
        assert "AUTO 14-DAY ROTATION" in page.text
        assert "SAVE EXCEPTION OVERRIDE" in page.text
        assert "Workstation default — all current & future batches" not in page.text
