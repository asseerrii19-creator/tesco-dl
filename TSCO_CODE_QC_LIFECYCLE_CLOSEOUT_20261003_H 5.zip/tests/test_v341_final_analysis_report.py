from __future__ import annotations

from pathlib import Path

from pypdf import PdfReader

from app.services.final_report_pdf import build_final_report_pdf


def _payload() -> dict:
    cols = [
        {'sample_id':'s0','number':'DM-26003388','date':'08/06/2026'},
        {'sample_id':'s1','number':'DM-25007520','date':'19/10/2025'},
        {'sample_id':'s2','number':'DM-25004025','date':'27/05/2025'},
        {'sample_id':'s3','number':'DM-23001574','date':'23/10/2023'},
    ]
    return {
        'report': {'number':'DM-26003388#A','status':'Officially Released','revision':1,'condition':'NORMAL','verification_url':'https://example.invalid/report','recommendation':'A new sample is recommended annually.'},
        'client': {'name':'Saudi Arabian Oil Company','address':'Eastern Province','contact_name':'Client Contact','email':'client@example.com','phone':'0500000000'},
        'asset': {'reference':'J10-010-XFR(T)-302','serial_number':'2015W02667','tag_number':'J10-010-XFR(T)-302','substation':'Substation - 10','equipment_type':'Transformer','voltage':'13.8 / 41.6','rated_mva':'15/20','cooling_type':'ONAN/ONAF','sealing_system':'Conservator with Bladder','manufacturer_country':'KSA','manufacturer':'WESCOSA','manufacture_year':'2015','location':'Western POD (Jazan)','owner':'Saudi Arabian Oil Company','oil_type':'Mineral','oil_weight':'-','tap_changer_type':'On-Load','tap_changer_chamber':'-','load_pct':'-','operating_period':'-'},
        'sample': {'sampling_from':'Bottom','sampler':'Client','sampling_date':'26/04/2026','arrival_date':'05/05/2026','oil_temp':'55','ambient_temp':'31','humidity':'54','equipment_status':'In-service','sampling_reason':'Minor PM','po_number':'6511229936','work_order':'-','sap_number':'5492713'},
        'history': {'last_report_date':'13/04/2020','last_report_number':'20-03265','fluid_treatment':'-','tap_changer_maintenance':'In-service','fluid_supplement':'-','events_observed':'-','repairs_modifications':'-'},
        'approval': {'reviewed_by':'Senior Chemist','approved_by':'Technical Manager','approved_at':'08/06/2026'},
        'dga': {'columns':cols,'standard':'STANDARD IEC 60567 / IEC 60599','interpretation':'DGA results require trend review.','rows':[
            {'test':'Hydrogen (H2)','unit':'ppm','values':{'s0':'42','s1':'16','s2':'LTD','s3':'LTD'},'method':'IEC 60567','uncertainty':'+/- 5.5 %','normal':'50','caution':'150','dl':'1'},
            {'test':'Methane (CH4)','unit':'ppm','values':{'s0':'59','s1':'30','s2':'28','s3':'20'},'method':'IEC 60567','uncertainty':'+/- 4.7 %','normal':'30','caution':'130','dl':'1'},
        ]},
        'dga_diagnostics': {'ratios':{'CH4/H2':'1.4','C2H6/CH4':'1.2'},'methods':[{'name':'IEC Ratio','result':'T1'}]},
        'furan': {'columns':cols,'standard':'STANDARD IEC 61198','interpretation':'Paper condition is good.','rows':[
            {'test':'2-Furfural (2FAL)','unit':'mg/kg','values':{'s0':'LTD','s1':'LTD','s2':'LTD','s3':'LTD'},'method':'IEC 61198','uncertainty':'0.2','normal':'<0.05','caution':'>2.0','dl':'0.01'},
            {'test':'Paper Lifetime Remaining Years','unit':'Years','values':{'s0':'>30','s1':'>30','s2':'>30','s3':'>30'},'method':'Calculated','uncertainty':'-','normal':'-','caution':'-','dl':'-'},
        ]},
        'furan_dp': {'chendong':'>1000','de_pablo':'>1000','stebbin':'>1000'},
        'oil': {'columns':cols,'standard':'','interpretation':'Oil quality results are within the reviewed condition profile.','rows':[
            {'test':'Total Acid Number','unit':'mg KOH/g','values':{'s0':'LTD','s1':'LTD','s2':'0.013','s3':'<0.01'},'method':'IEC 62021/1-03','uncertainty':'+/- 1.8 %','normal':'<0.15','caution':'>0.30','dl':'0.010'},
            {'test':'Water Content KF @RT','unit':'ppm','values':{'s0':'10.1','s1':'32','s2':'12','s3':'14'},'method':'ASTM D1533-20','uncertainty':'+/- 3.1 %','normal':'<30','caution':'>40','dl':'-'},
        ]},
        'corrosion': {'requested':True,'rows':[{'test':'Corrosive Sulfur','result':'OIL NOT CORROSIVE','method':'IEC 62535'}], 'image_path':str(Path('app/static/tsco-analytical-brand.png').resolve()), 'conclusion':'OIL NOT CORROSIVE', 'principle':'The controlled method evaluates corrosive sulfur by approved exposure and visual classification.'},
        'charts': [
            {'title':'Hydrogen (H2)','labels':['10/2023','05/2025','10/2025','06/2026'],'values':[0,0,16,42]},
            {'title':'Water Content KF','labels':['10/2023','05/2025','10/2025','06/2026'],'values':[14,12,32,10.1]},
        ],
    }


def test_official_analysis_report_matches_supplied_six_part_client_structure(tmp_path):
    out = tmp_path / 'analysis-report.pdf'
    build_final_report_pdf(_payload(), out)
    reader = PdfReader(str(out))
    assert len(reader.pages) == 6
    texts = [(p.extract_text() or '') for p in reader.pages]
    assert all('ANALYSIS REPORT' in t and 'QDF-[7]-08-A' in t for t in texts)
    assert all(mark in texts[0] for mark in ('EQUIPMENT DATA','SAMPLING DATA','TRANSFORMER EVENTS AND HISTORY'))
    assert 'DGA - MINERAL OIL OF TRANSFORMER' in texts[1]
    assert 'CONCENTRATION RATIOS & DIAGNOSTICS' in texts[1]
    assert 'FURANIC DERIVATIVES' in texts[2]
    assert 'CALCULATED AVERAGE DP' in texts[2]
    assert 'TRANSFORMER OIL QUALITY TESTS' in texts[3]
    assert 'DETECTION OF CORROSIVE SULFUR RESULT' in texts[4]
    assert 'OIL NOT CORROSIVE' in texts[4]
    assert 'GRAPHS' in texts[5] and 'RECOMMENDATION' in texts[5]
    merged = '\n'.join(texts)
    assert '<br' not in merged.lower() and '<b>' not in merged.lower()


def test_active_ui_and_intake_contract_do_not_expose_lms_actions():
    ui = '\n'.join(Path(p).read_text(encoding='utf-8') for p in [
        'app/templates/admin_workflows.html',
        'app/templates/controlled_reports.html',
        'app/templates/controlled_report_preview.html',
        'app/templates/client_dashboard.html',
        'app/lab_ops/index_template.html',
    ])
    assert 'external_lms' not in ui.lower()
    assert 'approve for lms' not in ui.lower()
    assert 'approve all for lms' not in ui.lower()
    intake = Path('app/routes/intake.py').read_text(encoding='utf-8')
    assert 'REGISTER_LMS' not in intake
