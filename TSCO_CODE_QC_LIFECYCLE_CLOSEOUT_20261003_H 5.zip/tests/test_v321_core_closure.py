from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import Asset, Client, SampleRequest, Site, User
from app.services.lab_operations import get_operations_state


def login(c: TestClient, email: str):
    r = c.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303, (email, r.status_code, r.text[:200])


def test_data_entry_is_one_intake_workspace_and_has_no_lab_document_library():
    with TestClient(app) as c:
        login(c, 'data.entry@tsco.local')
        page = c.get('/intake')
        assert page.status_code == 200
        assert 'Sample Intake & Receiving' in page.text
        assert 'Data Review' in page.text and 'Physical Receiving' in page.text and 'Batch & Distribution' in page.text
        # The laboratory method library is not a Data Entry navigation/workspace responsibility.
        assert '>Controlled Documents<' not in page.text
        denied = c.get('/documents', follow_redirects=False)
        assert denied.status_code == 403


def test_chemist_method_workspace_contains_search_test_method_index_and_all_controlled_types():
    with TestClient(app) as c:
        login(c, 'chemist@tsco.local')
        shell = c.get('/lab/operations?section=knowledge')
        assert shell.status_code == 200
        app_page = c.get('/lab/operations/app?section=knowledge')
        assert app_page.status_code == 200
        text = app_page.text
        assert 'Search test, method, ASTM/IEC code, SOP, EOP' in text
        assert 'Test → Method Index' in text
        assert 'OPEN FULL LIBRARY' in text
        # Bundled controlled references must actually be injected into the Chemist workspace.
        assert 'ASTM-D445' in text
        assert 'IEC-60814' in text
        assert 'EOP-6-04-D' in text
        assert 'SOP-PCB-GC-ECD' in text
        assert '"type":"METHOD"' in text
        assert '"type":"EOP"' in text
        assert '"type":"SOP"' in text


def test_chemist_central_document_library_is_searchable_by_method_and_type():
    with TestClient(app) as c:
        login(c, 'chemist@tsco.local')
        r = c.get('/documents?q=IEC+60814')
        assert r.status_code == 200
        assert 'Search Library' in r.text
        catalog = Path(__file__).resolve().parents[1] / 'app/reference_documents/catalog.json'
        if catalog.exists():
            assert 'IEC-60814' in r.text
            r = c.get('/documents?document_type=SOP')
            assert r.status_code == 200
            assert 'SOP-PCB-GC-ECD' in r.text
            r = c.get('/documents?document_type=EOP&q=TitroLine')
            assert r.status_code == 200
            assert 'EOP-6-04-D' in r.text
        else:
            # Some deployment archives intentionally omit reference bytes; the SQL controlled
            # document register remains authoritative and startup/search must still be available.
            assert 'Controlled' in r.text or 'Document' in r.text


def test_core_transformer_oil_test_methods_are_not_blank_or_misassigned():
    data = json.loads((Path(__file__).resolve().parents[1] / 'app/data/lab_packages.json').read_text())
    master = {row['test']: row for row in data['tests'] if isinstance(row, dict) and row.get('test')}
    expected = {
        'Dissolved Gas Analysis (DGA)': ('IEC 60567', 'DGA'),
        'Water Content KF @RT': ('IEC 60814', 'Water'),
        'Total Acid Number': ('ASTM D664', 'TAN / Peroxide / RSH / H2S'),
        'Interfacial Tension (IFT)': ('ASTM D971', 'Physical / Chemistry'),
        'Power Factor @25°C/60Hz': ('ASTM D924', 'Electrical'),
        'Breakdown Voltage @2.5mm- AVG': ('IEC 60156', 'Electrical'),
        'Breakdown Voltage @1mm- AVG': ('ASTM D1816', 'Electrical'),
        'Resistivity @       °C/60Hz': ('ASTM D1169', 'Electrical'),
        'Color ASTM': ('ASTM D1500', 'Physical / Chemistry'),
        'Viscosity @ 40 °C': ('ASTM D445', 'Physical / Chemistry'),
        'Density of Oil @RT': ('ASTM D4052', 'Physical / Chemistry'),
        '2-Furfural (2FAL)': ('IEC 61198', 'Furan / Passivator'),
        'Antioxidant (BHT)': ('IEC 60666', 'DBDS / BHT / Toluene / PCB'),
        'Dibenzyl Disulfide (DBDS)': ('IEC 62697-1', 'DBDS / BHT / Toluene / PCB'),
        'Potentially Corrosive Sulfur (CCD)': ('IEC 62535', 'Corrosion / CCD'),
        'Corrosive Sulfur': ('ASTM D1275b', 'Corrosion / CCD'),
        'Peroxide Number': ('ASTM D3703', 'TAN / Peroxide / RSH / H2S'),
    }
    for test, (method, station) in expected.items():
        assert test in master, test
        assert master[test]['method'] == method, (test, master[test]['method'], method)
        assert master[test]['station'] == station, (test, master[test]['station'], station)


def test_data_entry_cannot_bypass_smart_batch_release_with_single_sample_decision_action():
    with TestClient(app) as c:
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            client = db.scalar(select(Client).where(Client.active.is_(True))); assert client
            asset = db.scalar(select(Asset).where(Asset.client_id == client.id, Asset.active.is_(True))); assert asset
            token = uuid4().hex[:8]
            row = SampleRequest(
                request_number=f'V321-BATCH-{token}', public_token=f'PUB-{token}', barcode_value=f'BAR-{token}',
                lms_number=f'LMS-{token}', status='RECEIVED', site_id=site.id, client_id=client.id, asset_id=asset.id,
                sample_date_time=datetime.utcnow(), sampling_point='Main Tank', sample_origin='Client-Originated / Direct Delivery',
                submission_channel='CLIENT_DELIVERED', requested_package='Routine Test', priority='NORMAL', received_at=datetime.utcnow(),
            )
            db.add(row); db.commit(); sid = row.id
        login(c, 'data.entry@tsco.local')
        r = c.post(f'/intake/{sid}/decision', data={'action':'DISTRIBUTE_TO_LAB'}, follow_redirects=False)
        assert r.status_code == 400
        with SessionLocal() as db:
            sample = db.get(SampleRequest, sid)
            assert sample.status == 'RECEIVED'
            site = db.get(Site, sample.site_id)
            _, payload = get_operations_state(db, site)
            assert not any(sample.lms_number in batch.get('samples', []) for batch in payload.get('batches', []))


def test_unconfigured_analytical_method_is_never_silently_released_to_lab():
    from app.models import TestPackageConfig
    from app.services.lab_operations import package_method_configuration_issues, package_catalog, sync_samples_to_operations
    import pytest
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            packages = package_catalog(db, site.id)
            full = next(p for p in packages if p['name'] == 'Full Test')
            issues = package_method_configuration_issues(full)
            assert 'Refractive Index' in issues
            # Core Routine package is executable because its only method-less row is an operational oil-temperature input.
            routine = next(p for p in packages if p['name'] == 'Routine Test')
            assert package_method_configuration_issues(routine) == []
            custom = next(p for p in packages if p['name'] == 'Custom — Select Tests')
            assert package_method_configuration_issues(custom) == ['No tests configured in package']

            client = db.scalar(select(Client).where(Client.active.is_(True))); assert client
            asset = db.scalar(select(Asset).where(Asset.client_id == client.id, Asset.active.is_(True))); assert asset
            actor = db.scalar(select(User).where(User.email == 'data.entry@tsco.local')); assert actor
            token = uuid4().hex[:8]
            row = SampleRequest(
                request_number=f'V321-METHOD-{token}', public_token=f'PUB-{token}', barcode_value=f'BAR-{token}',
                lms_number=f'LMS-{token}', status='RECEIVED', site_id=site.id, client_id=client.id, asset_id=asset.id,
                sample_date_time=datetime.utcnow(), sampling_point='Main Tank', sample_origin='Client-Originated / Direct Delivery',
                submission_channel='CLIENT_DELIVERED', requested_package='Full Test', priority='NORMAL', received_at=datetime.utcnow(),
            )
            db.add(row); db.flush()
            with pytest.raises(ValueError, match='controlled package/method configuration is required'):
                sync_samples_to_operations(db, [row], actor, phase='READY_FOR_LAB')
