from __future__ import annotations

from datetime import datetime
from pathlib import Path
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import (
    Asset, Client, CommercialCase, ControlledReport, OperationalProject, ReportSubmission,
    Role, SampleRequest, SamplingAssignment, SamplingOrder, Site, User,
)


def login(c: TestClient, email: str):
    r = c.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303, (email, r.status_code, r.text[:300])


def logout(c: TestClient):
    c.post('/logout', follow_redirects=False)


def test_admin_is_read_only_for_business_write_routes():
    with TestClient(app) as c:
        login(c, 'admin@tsco.local')
        assert c.post('/operations/orders', data={'client_id':'1'}, follow_redirects=False).status_code == 403
        assert c.post('/intake/direct', data={'client_id':'1','asset_id':'1'}, follow_redirects=False).status_code == 403
        assert c.post('/receiving/1/receive', data={}, follow_redirects=False).status_code == 403
        assert c.post('/sampling-supervision/assignment/1/assign', data={'sampler_id': 1}, follow_redirects=False).status_code == 403
        assert c.post('/assessment/1', data={'decision':'APPROVED'}, follow_redirects=False).status_code == 403
        assert c.post('/admin/commercial/quotation', data={'client_id':1,'number':'NO-ADMIN-Q'}, follow_redirects=False).status_code == 403
        assert c.post('/admin/commercial/po', data={'client_id':1,'number':'NO-ADMIN-PO'}, follow_redirects=False).status_code == 403
        assert c.post('/admin/documents/1/status', data={'status':'ACTIVE'}, follow_redirects=False).status_code == 403


def test_shared_base_roles_do_not_collapse_business_capabilities():
    with TestClient(app) as c:
        login(c, 'salesman@tsco.local')
        r = c.post('/commercial/cases', data={'client_id':1,'lead_title':'Denied salesman case'}, follow_redirects=False)
        assert r.status_code == 403
        logout(c)
        login(c, 'external.coordination@tsco.local')
        r = c.post('/commercial/cases', data={'client_id':1,'lead_title':'Denied external coordinator case'}, follow_redirects=False)
        assert r.status_code == 403


def test_field_manager_has_controlled_fallback_assignment_authority():
    with TestClient(app) as c:
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM'))
            client = db.scalar(select(Client).where(Client.active.is_(True)))
            supervisor = db.scalar(select(User).where(User.email == 'sampling.supervisor@tsco.local'))
            sampleman = db.scalar(select(User).where(User.email == 'sampleman@tsco.local'))
            token = uuid4().hex[:8]
            order = SamplingOrder(order_number=f'FALLBACK-{token}', site_id=site.id, client_id=client.id,
                                  created_by_id=supervisor.id, supervisor_id=supervisor.id, title='Fallback test')
            db.add(order); db.flush()
            a = SamplingAssignment(order_id=order.id, assignment_code=f'FA-{token}', sample_label='Bottle A',
                                   source_party='TSCO', task_type='ON_SITE_SAMPLING', requested_package='Routine Test',
                                   sampling_point='Main Tank Bottom', container_count=1, status='UNASSIGNED')
            db.add(a); db.commit(); aid=a.id; sid=sampleman.id
        login(c, 'field.manager@tsco.local')
        r = c.post(f'/sampling-supervision/assignment/{aid}/assign', data={'sampler_id':sid,'note':'Supervisor fallback'}, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            row=db.get(SamplingAssignment,aid)
            assert row.assigned_sampler_id==sid and row.status=='ASSIGNED'


def test_operational_project_requires_gm_approval_before_activation():
    token = uuid4().hex[:8].upper()
    with TestClient(app) as c:
        with SessionLocal() as db:
            client=db.scalar(select(Client).where(Client.active.is_(True))); cid=client.id
        login(c,'field.manager@tsco.local')
        r=c.post('/commercial/projects',data={
            'project_reference':f'PRJ-{token}','project_name':'v3.2 project closeout','client_id':cid,
            'project_type':'LAB_FIELD','scope':'Field + laboratory scope','field_scope':'1','laboratory_scope':'1',
            'expected_samples':'12','test_package':'Routine Test','special_tat':'24H'
        },follow_redirects=False)
        assert r.status_code==303
        with SessionLocal() as db:
            p=db.scalar(select(OperationalProject).where(OperationalProject.project_reference==f'PRJ-{token}'))
            assert p.status=='PENDING_GM_APPROVAL'; pid=p.id
        # Field Manager cannot activate before GM approval.
        assert c.post(f'/commercial/projects/{pid}/activate',follow_redirects=False).status_code in {400,500}
        logout(c); login(c,'general.manager@tsco.local')
        assert c.post(f'/commercial/projects/{pid}/approve',follow_redirects=False).status_code==303
        with SessionLocal() as db: assert db.get(OperationalProject,pid).status=='APPROVED'
        logout(c); login(c,'field.manager@tsco.local')
        assert c.post(f'/commercial/projects/{pid}/activate',follow_redirects=False).status_code==303
        with SessionLocal() as db: assert db.get(OperationalProject,pid).status=='ACTIVE'


def test_structured_client_report_submission_updates_same_business_case():
    token=uuid4().hex[:8]
    with TestClient(app) as c:
        with SessionLocal() as db:
            site=db.scalar(select(Site).where(Site.code=='DMM'))
            client=db.scalar(select(Client).where(Client.active.is_(True)))
            asset=db.scalar(select(Asset).where(Asset.client_id==client.id,Asset.active.is_(True)))
            coord=db.scalar(select(User).where(User.email=='client.coordinator@tsco.local'))
            case=CommercialCase(case_code=f'BC-RPT-{token}',site_id=site.id,client_id=client.id,owner_id=coord.id,
                                assigned_coordinator_id=coord.id,current_stage='REPORT_RELEASE',lead_title='Report closeout')
            db.add(case); db.flush()
            sample=SampleRequest(request_number=f'RPT-{token}',public_token=f'P-{token}',barcode_value=f'B-{token}',
                                 status='REPORT_RELEASED',site_id=site.id,client_id=client.id,asset_id=asset.id,
                                 commercial_case_id=case.id,sample_date_time=datetime.utcnow(),sampling_point='Main Tank',sample_origin='Client-Originated / Direct Delivery')
            db.add(sample); db.flush(); case.sample_request_id=sample.id
            report=ControlledReport(site_id=site.id,sample_request_id=sample.id,report_number=f'TSCO-{token}',revision=0,
                                    condition_status='NORMAL',report_payload_json='{}',qr_token=f'Q-{token}',status='REPORT_RELEASED',lms_status='LMS_RELEASED')
            db.add(report); db.commit(); rid=report.id; cid_case=case.id
        login(c,'client.coordinator@tsco.local')
        r=c.post(f'/control/report/{rid}/submission',data={'channel':'EMAIL','recipient':'client@example.test','submission_reference':f'TR-{token}','note':'Released report sent'},follow_redirects=False)
        assert r.status_code==303
        with SessionLocal() as db:
            case=db.get(CommercialCase,cid_case)
            subs=list(db.scalars(select(ReportSubmission).where(ReportSubmission.controlled_report_id==rid)).all())
            assert case.current_stage=='REPORT_SUBMISSION'
            assert case.corporate_admin_status=='SENT_TO_PARENT_ADMINISTRATION'
            assert len(subs)==1 and subs[0].submission_reference==f'TR-{token}'


def test_backup_restore_migration_and_offline_release_controls_are_present():
    root=Path(__file__).resolve().parents[1]
    backup=(root/'scripts/production_backup.sh').read_text()
    restore=(root/'scripts/production_restore.sh').read_text()
    preflight=(root/'scripts/migration_preflight.sh').read_text()
    sw=(root/'app/static/service-worker.js').read_text()
    assert 'database.sql.gz' in backup and 'data.tar.gz' in backup and 'SHA256SUMS' in backup and 'sha256sum -c' in backup
    assert 'database.sql.gz' in restore and 'data.tar.gz' in restore and 'sha256sum -c' in restore and 'production_smoke_test.py' in restore
    assert 'alembic heads' in preflight and 'Expected one Alembic head' in preflight
    assert "url.pathname.startsWith('/static/')" in sw and 'Authenticated HTML/API responses are never written' in sw


def test_local_commercial_flow_has_no_finance_write_authority():
    from app.services.commercial import role_can_transition
    with SessionLocal() as db:
        admin=db.scalar(select(User).where(User.email=='admin@tsco.local'))
        gm=db.scalar(select(User).where(User.email=='general.manager@tsco.local'))
        coord=db.scalar(select(User).where(User.email=='client.coordinator@tsco.local'))
        for user in (admin,gm,coord):
            assert not role_can_transition(user,'INVOICING')
            assert not role_can_transition(user,'PAYMENT_COLLECTION')
            assert not role_can_transition(user,'CLOSED')
            assert not role_can_transition(user,'REPORT_SUBMISSION')
