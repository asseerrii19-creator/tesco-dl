from __future__ import annotations

from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import CommercialCase, CommercialRequestLine, Quotation, User


def _login(client: TestClient, email: str) -> None:
    r = client.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303


def test_client_submits_unified_request_and_staff_open_status_is_visible():
    token = uuid4().hex[:8].upper()
    with TestClient(app) as browser:
        _login(browser, 'client@sec.local')
        r = browser.post('/client/requests', data={
            'lead_title': f'Transformer oil testing {token}',
            'client_message': 'Please use the requested scope below; two samples are urgent.',
        }, follow_redirects=False)
        assert r.status_code == 303 and '/client/requests/' in r.headers['location']
        case_id = int(r.headers['location'].rstrip('/').split('/')[-1])

        r = browser.post(f'/client/requests/{case_id}/lines', data={
            'quantity': 18, 'requested_package': 'Routine Test', 'method_family': 'IEC',
            'priority': 'NORMAL', 'required_tat': '', 'due_at': '',
        }, follow_redirects=False)
        assert r.status_code == 303
        r = browser.post(f'/client/requests/{case_id}/lines', data={
            'quantity': 2, 'requested_package': 'Full Test', 'method_family': 'ASTM',
            'priority': 'URGENT', 'required_tat': '12H', 'due_at': '',
        }, follow_redirects=False)
        assert r.status_code == 303
        r = browser.post(f'/client/requests/{case_id}/submit', data={
            'client_message': 'Please use the requested scope below; two samples are urgent.'
        }, follow_redirects=False)
        assert r.status_code == 303

        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case
            assert case.request_source == 'CLIENT_PORTAL'
            assert case.request_status == 'RECEIVED'
            assert case.expected_samples == 20
            assert case.requested_test_package == 'Mixed Request Scope'
            assert case.default_priority == 'MIXED'
            lines = list(db.scalars(select(CommercialRequestLine).where(CommercialRequestLine.commercial_case_id == case_id).order_by(CommercialRequestLine.line_number)).all())
            assert [(x.quantity, x.requested_package, x.method_family, x.priority, x.required_tat) for x in lines] == [
                (18, 'Routine Test', 'IEC', 'NORMAL', ''),
                (2, 'Full Test', 'ASTM', 'URGENT', '12H'),
            ]

        portal = browser.get('/client')
        assert portal.status_code == 200
        assert 'Received' in portal.text and f'Transformer oil testing {token}' in portal.text

        browser.post('/logout')
        _login(browser, 'sales.marketing.specialist@tsco.local')
        opened = browser.get(f'/commercial?case_id={case_id}')
        assert opened.status_code == 200
        assert 'Submitted directly by client' in opened.text
        assert 'Under Review' in opened.text

        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case
            assert case.request_status == 'UNDER_REVIEW'
            assert case.request_opened_at is not None
            assert case.request_opened_by_id is not None

        browser.post('/logout')
        _login(browser, 'client@sec.local')
        detail = browser.get(f'/client/requests/{case_id}')
        assert detail.status_code == 200
        assert 'Under Review' in detail.text


def test_existing_quotation_uses_client_submitted_scope_without_rekeying():
    token = uuid4().hex[:8].upper()
    with TestClient(app) as browser:
        _login(browser, 'client@sec.local')
        r = browser.post('/client/requests', data={'lead_title': f'Quote scope {token}', 'client_message': ''}, follow_redirects=False)
        case_id = int(r.headers['location'].rstrip('/').split('/')[-1])
        browser.post(f'/client/requests/{case_id}/lines', data={
            'quantity': 4, 'requested_package': 'Full Test', 'method_family': 'ASTM',
            'priority': 'URGENT', 'required_tat': '24H', 'due_at': '',
        }, follow_redirects=False)
        browser.post(f'/client/requests/{case_id}/submit', data={'client_message': ''}, follow_redirects=False)

        with SessionLocal() as db:
            coordinator = db.scalar(select(User).where(User.email == 'client.coordinator@tsco.local')); assert coordinator
            case = db.get(CommercialCase, case_id); assert case
            case.assigned_coordinator_id = coordinator.id
            db.commit()

        browser.post('/logout')
        _login(browser, 'client.coordinator@tsco.local')
        browser.get(f'/commercial?case_id={case_id}')
        quote_no = f'QT-V329-{token}'
        r = browser.post(f'/commercial/cases/{case_id}/advance', data={
            'target_stage': 'QUOTATION', 'quotation_number': quote_no, 'note': '', 'reference': '',
        }, follow_redirects=False)
        assert r.status_code == 303

        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case and case.quotation_id
            quote = db.get(Quotation, case.quotation_id); assert quote
            assert '4 x Full Test / ASTM / URGENT / 24H' in quote.description
            assert case.request_status == 'QUOTATION_CREATED'
