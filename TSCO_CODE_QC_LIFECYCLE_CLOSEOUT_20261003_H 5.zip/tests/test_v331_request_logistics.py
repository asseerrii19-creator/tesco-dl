from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import CommercialAttachment, CommercialCase, CommercialRequestLine, PurchaseOrder, Quotation


def _login(browser: TestClient, email: str) -> None:
    r = browser.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303


def test_client_request_captures_expected_arrival_route_serials_and_data_form_once():
    with TestClient(app) as browser:
        _login(browser, 'client@sec.local')
        r = browser.post('/client/requests', data={
            'lead_title': 'Twelve transformer samples',
            'expected_arrival_at': '2026-10-02T09:30',
            'sample_delivery_mode': 'CLIENT_DELIVERY',
            'sample_delivery_notes': 'Plant A — samples will be delivered to TSCO reception',
            'client_message': 'Four urgent, remaining normal',
        }, follow_redirects=False)
        assert r.status_code == 303
        case_id = int(r.headers['location'].rstrip('/').split('/')[-1])

        r = browser.post(f'/client/requests/{case_id}/lines', data={
            'quantity': 2, 'requested_package': 'Routine Test', 'method_family': 'IEC',
            'priority': 'URGENT', 'required_tat': '24H', 'due_at': '',
            'expected_serials': 'SN-REQ-331-A\nSN-REQ-331-B',
        }, follow_redirects=False)
        assert r.status_code == 303

        r = browser.post(
            f'/client/requests/{case_id}/attachments',
            files={'upload': ('client-data-form.pdf', b'%PDF-1.4\n% v331 controlled data form\n%%EOF', 'application/pdf')},
            follow_redirects=False,
        )
        assert r.status_code == 303

        page = browser.get(f'/client/requests/{case_id}')
        assert page.status_code == 200
        assert '2026-10-02 09:30' in page.text
        assert 'Client delivery to TSCO' in page.text
        assert 'SN-REQ-331-A' in page.text
        assert 'client-data-form.pdf' in page.text

        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case
            assert case.expected_arrival_at == datetime(2026, 10, 2, 9, 30)
            assert case.sample_delivery_mode == 'CLIENT_DELIVERY'
            assert 'Plant A' in case.sample_delivery_notes
            line = db.scalar(select(CommercialRequestLine).where(CommercialRequestLine.commercial_case_id == case_id)); assert line
            doc = db.scalar(select(CommercialAttachment).where(CommercialAttachment.commercial_case_id == case_id, CommercialAttachment.document_type == 'CLIENT_DATA_FORM'))
            assert doc and doc.original_name == 'client-data-form.pdf'


def test_request_logistics_and_data_form_are_visible_to_coordination_and_expected_arrivals():
    with TestClient(app) as browser:
        _login(browser, 'client@sec.local')
        token = uuid4().hex[:8].upper()
        r = browser.post('/client/requests', data={
            'lead_title': f'Collection request {token}',
            'expected_arrival_at': '2026-10-03T08:00',
            'sample_delivery_mode': 'TSCO_COLLECTION',
            'sample_delivery_notes': 'Collect from Main Plant sample room',
            'client_message': 'Data Form attached',
        }, follow_redirects=False)
        case_id = int(r.headers['location'].rstrip('/').split('/')[-1])
        r = browser.post(f'/client/requests/{case_id}/lines', data={
            'quantity': 1, 'requested_package': 'Routine Test', 'method_family': 'ASTM',
            'priority': 'NORMAL', 'required_tat': '', 'due_at': '', 'expected_serials': f'SN-{token}',
        }, follow_redirects=False)
        assert r.status_code == 303
        r = browser.post(
            f'/client/requests/{case_id}/attachments',
            files={'upload': ('data-form.pdf', b'%PDF-1.4\n% request evidence\n%%EOF', 'application/pdf')},
            follow_redirects=False,
        )
        assert r.status_code == 303

        # Put the commercial case at the approved handover boundary so Data Entry receives it as an expected arrival.
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case
            q = Quotation(client_id=case.client_id, number=f'QT-331-{token}', status='ACTIVE', description='v331')
            db.add(q); db.flush()
            po = PurchaseOrder(client_id=case.client_id, quotation_id=q.id, number=f'PO-331-{token}', status='ACTIVE')
            db.add(po); db.flush()
            case.quotation_id = q.id
            case.purchase_order_id = po.id
            case.current_stage = 'COMPLETE_HANDOVER'
            case.status = 'ACTIVE'
            db.commit()

        browser.post('/logout', follow_redirects=False)
        _login(browser, 'client.coordinator@tsco.local')
        commercial = browser.get(f'/commercial?case_id={case_id}')
        assert commercial.status_code == 200
        assert '2026-10-03 08:00' in commercial.text
        assert 'TSCO collection / sampling coordination' in commercial.text
        assert 'data-form.pdf' in commercial.text

        browser.post('/logout', follow_redirects=False)
        _login(browser, 'data.entry@tsco.local')
        intake = browser.get('/intake?view=incoming')
        assert intake.status_code == 200
        assert '2026-10-03 08:00' in intake.text
        assert 'TSCO collection / sampling' in intake.text
        assert f'SN-{token}' in intake.text
