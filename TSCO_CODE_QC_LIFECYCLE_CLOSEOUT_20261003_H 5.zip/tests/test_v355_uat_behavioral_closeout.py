from pathlib import Path
import math
import pytest

from app.services.lab_operations import _validate_bdv_series_result, _validate_calculated_result

ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / 'app/lab_ops/index_template.html').read_text(encoding='utf-8')


def _stats(values):
    mean = sum(values) / len(values)
    sd = math.sqrt(sum((x - mean) ** 2 for x in values) / (len(values) - 1))
    return round(mean, 2), round(sd / mean * 100.0, 2)


def test_iec60156_six_run_average_and_rsd_are_server_verified_as_one_run_set():
    values = [72.1, 74.2, 73.5, 75.0, 74.8, 73.9]
    avg, rsd = _stats(values)
    calc = {
        'method': 'IEC 60156',
        'inputs': {f'R{i+1}': v for i, v in enumerate(values)},
    }
    avg_row = {
        'test': 'Breakdown Voltage @2.5mm- AVG',
        'result': str(avg),
        'calculated': False,
        'calculation': calc,
        'source': 'BDV instrument CSV',
    }
    rsd_row = {
        'test': 'RSD% of BDV @2.5mm',
        'result': str(rsd),
        'calculated': True,
        'calculation': calc,
        'source': 'Derived from BDV run set',
    }
    _validate_bdv_series_result(avg_row)
    _validate_bdv_series_result(rsd_row)
    # Regression: the derived RSD must not be rejected as an unsupported generic calculation.
    _validate_calculated_result({}, {}, rsd_row)


def test_iec60156_rejects_missing_sixth_breakdown():
    calc = {'method': 'IEC 60156', 'inputs': {f'R{i}': 70 + i for i in range(1, 6)}}
    with pytest.raises(PermissionError, match='exactly 6 numeric breakdown readings'):
        _validate_bdv_series_result({
            'test': 'Breakdown Voltage @2.5mm- AVG', 'result': '73',
            'calculation': calc, 'source': 'BDV instrument CSV',
        })


def test_astm_bdv_keeps_method_defined_five_run_protocol():
    values = [48.0, 49.0, 50.0, 51.0, 52.0]
    avg, rsd = _stats(values)
    calc = {'method': 'ASTM D1816', 'inputs': {f'R{i+1}': v for i, v in enumerate(values)}}
    _validate_bdv_series_result({'test': 'Breakdown Voltage @1mm- AVG', 'result': str(avg), 'calculation': calc, 'source': 'BDV instrument CSV'})
    _validate_bdv_series_result({'test': 'RSD% of BDV @1mm', 'result': str(rsd), 'calculated': True, 'calculation': calc, 'source': 'Derived from BDV run set'})


def test_electrical_ui_is_file_first_and_does_not_render_bdv_rsd_as_manual_entry():
    assert 'BDV Instrument Result File (CSV)' in HTML
    assert 'PF Instrument Result File (CSV)' in HTML
    assert "standardElectrical=tests.filter(t=>!/breakdown voltage|rsd% of bdv|power factor" in HTML
    assert "data-kind=\"BDV\"" in HTML and "data-kind=\"PF\"" in HTML
    assert "covers_tests:kind==='BDV'?[target,bdvFormula?.secondaryTest].filter(Boolean)" in HTML
    assert "evidence_id:evid" in HTML


def test_live_equipment_resolver_has_exact_controlled_assets_for_current_blockers():
    for equipment_id in ('EQ-24', 'EQ-25', 'EQ-30', 'EQ-26', 'EQ-49', 'EQ-130', 'EQ-79', 'EQ-80'):
        assert equipment_id in HTML
    assert 'function equipmentForQcContext(ctx){return equipmentMappedForQcContext(ctx).filter(equipmentReady)}' in HTML
    assert 'function equipmentClassSupportsContext' in HTML
