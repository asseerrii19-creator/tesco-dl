from datetime import datetime, timedelta

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import StaffAvailability, User
from app.review_personas import REVIEW_PERSONAS


def login(client: TestClient, email: str, password: str = "Demo123!"):
    r = client.post("/login", data={"email": email, "password": password}, follow_redirects=False)
    assert r.status_code == 303, (email, r.status_code, r.text[:300])


def logout(client: TestClient):
    client.post("/logout", follow_redirects=False)


def test_all_review_personas_are_position_based_and_no_current_employee_names():
    emails = {p.email for p in REVIEW_PERSONAS}
    assert "secretary@tsco.local" in emails
    assert "senior.technical@tsco.local" in emails
    assert "senior.equipment@tsco.local" in emails
    assert "senior.improvement@tsco.local" in emails
    assert all("anas.asiri" not in e and "rwad@" not in e and "renad." not in e for e in emails)


def test_review_persona_home_landings_are_job_specific():
    expected = {
        "general.manager@tsco.local": "/management",
        "excellence.specialist@tsco.local": "/improvement",
        "secretary@tsco.local": "/gm-office",
        "sales.marketing.specialist@tsco.local": "/commercial",
        "salesman@tsco.local": "/commercial",
        "field.manager@tsco.local": "/operations",
        "data.entry@tsco.local": "/intake",
        "sampleman@tsco.local": "/field",
        "client.coordinator@tsco.local": "/commercial",
        "external.coordination@tsco.local": "/commercial",
        "lab.manager@tsco.local": "/management",
        "senior.technical@tsco.local": "/lab/operations?section=supervisor",
        "senior.equipment@tsco.local": "/lab/operations?section=supervisor",
        "senior.improvement@tsco.local": "/lab/operations?section=supervisor",
        "chemist@tsco.local": "/lab/operations?section=workstations",
        "technician@tsco.local": "/lab/operations?section=workstations",
        "lab.support@tsco.local": "/workspace",
        "hr@tsco.local": "/workspace",
        "qhse@tsco.local": "/quality",
        "legal@tsco.local": "/workspace",
        "procurement@tsco.local": "/workspace",
        "finance@tsco.local": "/commercial",
        "it@tsco.local": "/workspace",
        "erb@tsco.local": "/workspace",
    }
    with TestClient(app) as client:
        for email, target in expected.items():
            login(client, email)
            r = client.get("/", follow_redirects=False)
            assert r.status_code == 303 and r.headers["location"] == target, (email, r.status_code, r.headers.get("location"))
            logout(client)


def test_secretary_uat_workspace_is_gm_office_only_and_direct_urls_are_blocked():
    with TestClient(app) as client:
        login(client, "secretary@tsco.local")
        page = client.get("/gm-office")
        assert page.status_code == 200
        for text in ["GM Office Workspace", "Correspondence & Follow-up", "Meetings & Calendar", "Employee Directory", "My Leave & Availability"]:
            assert text in page.text
        for path in [
            "/lab/operations?section=workstations", "/quality", "/intake", "/operations", "/commercial", "/documents", "/assets/structure", "/improvement",
        ]:
            assert client.get(path, follow_redirects=False).status_code == 403, path


def test_generic_uat_leave_personas_exercise_configured_manager_route():
    with TestClient(app) as client:
        login(client, "secretary@tsco.local")
        page = client.get("/control/my-availability")
        assert page.status_code == 200
        assert "General Manager" in page.text
        start = datetime.now() + timedelta(days=120)
        end = start + timedelta(days=2)
        note = "V318 role-persona leave routing"
        r = client.post("/control/availability/request", data={
            "start_at": start.strftime("%Y-%m-%dT%H:%M"),
            "end_at": end.strftime("%Y-%m-%dT%H:%M"),
            "notes": note,
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            secretary = db.scalar(select(User).where(User.email == "secretary@tsco.local"))
            gm = db.scalar(select(User).where(User.email == "general.manager@tsco.local"))
            row = db.scalar(select(StaffAvailability).where(
                StaffAvailability.user_id == secretary.id,
                StaffAvailability.notes == note,
            ).order_by(StaffAvailability.id.desc()))
            assert row and row.status == "PENDING_MANAGER" and row.approver_id == gm.id
            request_id = row.id
        logout(client)
        login(client, "general.manager@tsco.local")
        approval = client.post(f"/control/availability/{request_id}/transition", data={"decision": "APPROVE"}, follow_redirects=False)
        assert approval.status_code == 303


def test_three_senior_personas_have_same_role_but_separate_responsibility_domains():
    with TestClient(app) as client:
        expected = {
            "senior.technical@tsco.local": ("TECHNICAL", "Technical Affairs"),
            "senior.equipment@tsco.local": ("EQUIPMENT", "Equipment &amp; Maintenance"),
            "senior.improvement@tsco.local": ("IMPROVEMENT", "Improvement Coordination"),
        }
        for email, (domain, label) in expected.items():
            login(client, email)
            with SessionLocal() as db:
                user = db.scalar(select(User).where(User.email == email))
                assert user.role == "senior_chemist" and user.senior_responsibility_domain == domain
            resp = client.get("/improvement/responsibilities")
            assert resp.status_code == 200 and label in resp.text
            logout(client)


def test_uat_review_org_and_directory_hide_current_staff_names(monkeypatch):
    monkeypatch.setenv("APP_ENV", "development")
    with TestClient(app) as client:
        login(client, "secretary@tsco.local")
        org = client.get("/organization")
        directory = client.get("/organization/employees")
        assert org.status_code == 200 and directory.status_code == 200
        for forbidden_name in ["Salah Al-Shajira", "Renad Al Qahtani", "Anas Asiri", "Rwad", "Ohood Al Hareeqi"]:
            assert forbidden_name not in org.text
            assert forbidden_name not in directory.text
        for role_title in ["General Manager", "Secretary", "Field Operational &amp; Technical Manager", "Senior Chemist — Technical", "Technician"]:
            assert role_title in org.text or role_title in directory.text
        assert "NO EMPLOYEE NAMES" in directory.text


def test_employee_directory_direct_url_is_role_scoped_in_uat(monkeypatch):
    monkeypatch.setenv("APP_ENV", "development")
    with TestClient(app) as client:
        login(client, "technician@tsco.local")
        assert client.get("/organization/employees").status_code == 403
        logout(client)
        login(client, "secretary@tsco.local")
        assert client.get("/organization/employees").status_code == 200
