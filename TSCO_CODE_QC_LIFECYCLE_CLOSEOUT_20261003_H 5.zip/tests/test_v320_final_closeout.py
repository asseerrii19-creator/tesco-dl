from __future__ import annotations

from datetime import datetime
from pathlib import Path
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
import app.routes.control_center as cc
from app.database import SessionLocal
from app.models import (
    Asset, Client, ControlledDocument, ControlledReport, QualityCase, QualityExecutionRevision,
    SampleRequest, Site, TroubleshootingRecord, TroubleshootingNote,
    TroubleshootingResolutionRevision, User,
)


def login(c: TestClient, email: str):
    r = c.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303, (email, r.status_code, r.text[:300])


def logout(c: TestClient):
    c.post('/logout', follow_redirects=False)


def sample_for_report() -> int:
    with SessionLocal() as db:
        site = db.scalar(select(Site).where(Site.code == 'DMM'))
        client = db.scalar(select(Client).where(Client.code == 'SEC'))
        asset = db.scalar(select(Asset).where(Asset.client_id == client.id))
        token = uuid4().hex[:10]
        row = SampleRequest(
            request_number=f'V320-{token}', public_token=f'PUB-{token}', barcode_value=f'BAR-{token}',
            status='TECHNICAL_REVIEW', site_id=site.id, client_id=client.id, asset_id=asset.id,
            sample_date_time=datetime.utcnow(), sampling_point='Main Tank', sample_origin='Client-Originated / Direct Delivery',
        )
        db.add(row); db.commit(); db.refresh(row); return row.id


def test_final_uat_personas_and_titles_are_aligned():
    with TestClient(app):
        with SessionLocal() as db:
            supervisor = db.scalar(select(User).where(User.email == 'sampling.supervisor@tsco.local'))
            tech = db.scalar(select(User).where(User.email == 'technician@tsco.local'))
            support = db.scalar(select(User).where(User.email == 'lab.support@tsco.local'))
            sampleman = db.scalar(select(User).where(User.email == 'sampleman@tsco.local'))
            assert supervisor and supervisor.active and supervisor.job_title == 'Sampling Supervisor'
            assert tech and tech.job_title == 'Chemical Technician'
            assert support and support.job_title == 'Glassware Cleaning'
            assert sampleman.manager and sampleman.manager.email == 'sampling.supervisor@tsco.local'


def test_sampleman_direct_url_is_denied_without_assignment():
    with TestClient(app) as c:
        login(c, 'sampleman@tsco.local')
        r = c.get('/field/new', follow_redirects=False)
        assert r.status_code == 403


def test_admin_document_upload_is_draft_then_senior_and_manager_approve():
    with TestClient(app) as c:
        login(c, 'admin@tsco.local')
        code = f'V320-SOP-{uuid4().hex[:6]}'.upper()
        r = c.post('/admin/documents', data={
            'document_type':'SOP','code':code,'title':'Controlled v3.2 test SOP','revision':'01','effective_date':'',
            'site_id':'','workstation':'Water','test_name':'Water Content','method_name':'IEC 60814','notes':'closeout test',
        }, files={'document_file':('test.txt', b'controlled document content')}, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            doc = db.scalar(select(ControlledDocument).where(ControlledDocument.code == code))
            assert doc.status == 'DRAFT'
            doc_id = doc.id
        logout(c); login(c, 'senior@tsco.local')
        assert c.post(f'/documents/{doc_id}/technical-review', follow_redirects=False).status_code == 303
        with SessionLocal() as db: assert db.get(ControlledDocument, doc_id).status == 'PENDING_MANAGER_APPROVAL'
        logout(c); login(c, 'technical@tsco.local')
        assert c.post(f'/documents/{doc_id}/manager-approve', follow_redirects=False).status_code == 303
        with SessionLocal() as db:
            doc = db.get(ControlledDocument, doc_id)
            assert doc.status == 'ACTIVE' and doc.technical_reviewed_by_id and doc.manager_approved_by_id


def test_system_admin_cannot_approve_report_and_manager_snapshot_is_immutable_record(monkeypatch):
    sid = sample_for_report()
    with TestClient(app) as c:
        login(c, 'senior@tsco.local')
        number = f'DM-V320-{uuid4().hex[:8]}'
        r = c.post('/control/report', data={
            'sample_request_id':sid,'report_number':number,'condition_status':'NORMAL','interpretation':'Senior interpretation',
            'recommendation':'Monitor trend','dga_requested':'','corrosive_requested':'','paper_requested':''
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            report = db.scalar(select(ControlledReport).where(ControlledReport.report_number == number)); rid=report.id
            assert report.status == 'TECHNICAL_REVIEW' and report.reviewed_by_id is None
        logout(c); login(c, 'admin@tsco.local')
        assert c.post(f'/control/report/{rid}/approve', follow_redirects=False).status_code == 403
        logout(c); login(c, 'senior@tsco.local')
        monkeypatch.setattr(cc, '_report_review_requirements', lambda db,row,payload,cards: [{'ok':True,'detail':'ok'}])
        monkeypatch.setattr(cc, '_report_result_review_cards', lambda payload,sample_id: [{'test':'Water Content','result':'12','unit':'ppm','method':'IEC','normal':'<30','caution':'>40','group':'Oil Quality'}])
        reviewed=c.post(f'/control/report/{rid}/review',data={'action':'COMPLETE','condition_status':'NORMAL','interpretation':'Senior interpretation','recommendation':'Monitor trend','confirm_results':'1','confirm_identity':'1','confirm_interpretation':'1','confirm_evidence':'1','confirm_recommendation':'1'},follow_redirects=False)
        assert reviewed.status_code==303
        with SessionLocal() as db: assert db.get(ControlledReport,rid).status=='PENDING_MANAGER_APPROVAL'
        logout(c); login(c, 'technical@tsco.local')
        assert c.post(f'/control/report/{rid}/approve', follow_redirects=False).status_code == 303
        with SessionLocal() as db:
            report=db.get(ControlledReport,rid)
            assert report.status == 'REPORT_RELEASED' and report.approved_snapshot_json not in ('','{}') and report.lms_status == 'NOT_APPLICABLE'


def test_validation_protocol_supports_more_than_five_runs_and_preserves_revision():
    with TestClient(app) as c:
        with SessionLocal() as db:
            chem=db.scalar(select(User).where(User.email=='chemist@tsco.local')); uid=chem.id
        login(c,'excellence@tsco.local')
        r=c.post('/control/case',data={
            'case_type':'VALIDATION','title':'Seven run validation','test_name':'Water Content','method_name':'IEC 60814',
            'assigned_to_id':uid,'priority':'NORMAL','required_runs':7,'objective':'Repeatability','acceptance_criteria':'Protocol criterion',
            'required_evidence':'Worksheet','equipment_asset_id':'','due_at':'','scheme_name':'','evaluation_criteria':'Protocol criterion',
        },follow_redirects=False)
        assert r.status_code==303
        with SessionLocal() as db:
            case=db.scalar(select(QualityCase).where(QualityCase.title=='Seven run validation').order_by(QualityCase.id.desc())); cid=case.id
        logout(c); login(c,'chemist@tsco.local')
        page=c.get('/control/my-quality-tasks'); assert page.status_code==200 and 'Required runs</b>7' in page.text
        data={'run_values':[str(v) for v in [1,2,3,4,5,6,7]], 'evidence_reference':'V320-VAL'}
        r=c.post(f'/control/my-quality-tasks/{cid}/submit',data=data,follow_redirects=False); assert r.status_code==303, r.text[:500]
        with SessionLocal() as db:
            rev=db.scalar(select(QualityExecutionRevision).where(QualityExecutionRevision.quality_case_id==cid))
            assert rev and rev.revision==1 and '7.0' in rev.raw_runs_json


def test_troubleshooting_notes_and_resolution_revision_are_preserved_and_admin_cannot_publish():
    with TestClient(app) as c:
        login(c,'chemist@tsco.local')
        r=c.post('/control/troubleshooting',data={'test_name':'DGA','method_name':'IEC 60567','equipment_asset_id':'','workstation':'DGA','problem':'V320 issue','symptoms':'unstable run','actions_taken':'stopped','safety_impact':'','result_integrity_impact':'review','lessons':''},follow_redirects=False)
        assert r.status_code==303
        with SessionLocal() as db: rec=db.scalar(select(TroubleshootingRecord).where(TroubleshootingRecord.problem=='V320 issue').order_by(TroubleshootingRecord.id.desc())); rid=rec.id
        assert c.post(f'/control/troubleshooting/{rid}/note',data={'note':'Repeated on second attempt','evidence_reference':'LOG-1'},follow_redirects=False).status_code==303
        logout(c); login(c,'senior@tsco.local')
        assert c.post(f'/control/troubleshooting/{rid}/resolution',data={'resolution_text':'Controlled resolution','root_cause':'Method-side cause','evidence_reference':'EV-1'},follow_redirects=False).status_code==303
        assert c.post(f'/control/troubleshooting/{rid}/transition',data={'status':'PENDING_MANAGER_APPROVAL'},follow_redirects=False).status_code==303
        logout(c); login(c,'admin@tsco.local')
        assert c.post(f'/control/troubleshooting/{rid}/transition',data={'status':'PUBLISHED'},follow_redirects=False).status_code==403
        logout(c); login(c,'technical@tsco.local')
        assert c.post(f'/control/troubleshooting/{rid}/transition',data={'status':'PUBLISHED'},follow_redirects=False).status_code==303
        with SessionLocal() as db:
            rec=db.get(TroubleshootingRecord,rid)
            notes=list(db.scalars(select(TroubleshootingNote).where(TroubleshootingNote.troubleshooting_record_id==rid)).all())
            revisions=list(db.scalars(select(TroubleshootingResolutionRevision).where(TroubleshootingResolutionRevision.troubleshooting_record_id==rid)).all())
            assert rec.status=='PUBLISHED' and rec.published_revision==1 and len(notes)==1 and len(revisions)==1 and revisions[0].status=='EFFECTIVE'


def test_offline_storage_and_service_worker_are_user_site_scoped_and_no_authenticated_cache():
    root=Path(__file__).resolve().parents[1]
    sw=(root/'app/static/service-worker.js').read_text()
    field=(root/'app/static/field-form.js').read_text()
    lab=(root/'app/lab_ops/index_template.html').read_text()
    assert "url.pathname.startsWith('/static/')" in sw and "Authenticated HTML/API responses are never written" in sw
    assert 'data-user-id' in (root/'app/templates/base.html').read_text()
    assert 'document.body.dataset.userId' in field and 'document.body.dataset.siteCode' in field
    assert 'USER_SCOPE' in lab and "CURRENT_SITE.toLowerCase()" in lab
