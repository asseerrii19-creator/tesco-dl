from __future__ import annotations

import json
from datetime import datetime
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import func, select

from app.main import app
from app.database import SessionLocal
from app.models import (
    Asset, Client, CommercialCase, CommercialRequestLine, CompetencyRecord, PurchaseOrder, Quotation,
    Role, SampleRequest, SamplingAssignment, SamplingOrder, Site, StaffAvailability, User, UserClientAssignment,
)
from app.services.lab_operations import (
    _analytical_rotation_cycle, ensure_analytical_rotation_assignments, resolved_sample_package,
)


def _login(client: TestClient, email: str) -> None:
    r = client.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303


def _base(db):
    site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
    client = db.scalar(select(Client).where(Client.code == 'SEC')); assert client
    asset = db.scalar(select(Asset).where(Asset.client_id == client.id)); assert asset
    return site, client, asset


def _complete_scope(db, *, quantity=3, package='Full Test', family='ASTM', priority='URGENT', tat='12H'):
    site, customer, asset = _base(db)
    token = uuid4().hex[:8].upper()
    quote = Quotation(client_id=customer.id, number=f'QT-V328-{token}', status='ACTIVE', description='Client request scope')
    db.add(quote); db.flush()
    po = PurchaseOrder(client_id=customer.id, quotation_id=quote.id, number=f'PO-V328-{token}', status='ACTIVE')
    db.add(po); db.flush()
    case = CommercialCase(
        case_code=f'BC-DMM-2026-{token}', site_id=site.id, client_id=customer.id,
        quotation_id=quote.id, purchase_order_id=po.id, current_stage='COMPLETE_HANDOVER', status='ACTIVE',
        lead_title='Structured client request', handover_commercial='Approved quote / PO',
        handover_technical='Inherit Client Request Scope', handover_client_info='Controlled UAT',
        expected_samples=quantity, requested_test_package=package, default_priority=priority, required_tat=tat,
    )
    db.add(case); db.flush()
    line = CommercialRequestLine(
        commercial_case_id=case.id, line_number=1, quantity=quantity, requested_package=package,
        requested_tests_json='[]', method_family=family, priority=priority, required_tat=tat,
        status='ACTIVE', created_by_id=None,
    )
    db.add(line); db.commit()
    return site.id, customer.id, asset.id, quote.id, po.id, case.id, line.id


def test_client_request_scope_is_recorded_before_quotation_and_supports_split_tat():
    with TestClient(app) as browser:
        with SessionLocal() as db:
            site, customer, _ = _base(db)
            coordinator = db.scalar(select(User).where(User.email == 'client.coordinator@tsco.local')); assert coordinator
            token = uuid4().hex[:8].upper()
            case = CommercialCase(
                case_code=f'BC-DMM-2026-{token}', site_id=site.id, client_id=customer.id,
                owner_id=coordinator.id, assigned_coordinator_id=coordinator.id,
                current_stage='LEAD_GENERATION', status='ACTIVE', lead_title='20 sample client request',
            )
            db.add(case); db.commit(); case_id = case.id
        _login(browser, 'client.coordinator@tsco.local')
        r = browser.post(f'/commercial/cases/{case_id}/request-lines', data={
            'quantity': 18, 'requested_package': 'Routine Test', 'method_family': 'IEC',
            'priority': 'NORMAL', 'required_tat': '', 'due_at': '',
        }, follow_redirects=False)
        assert r.status_code == 303
        r = browser.post(f'/commercial/cases/{case_id}/request-lines', data={
            'quantity': 2, 'requested_package': 'Full Test', 'method_family': 'ASTM',
            'priority': 'URGENT', 'required_tat': '12H', 'due_at': '',
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case
            lines = list(db.scalars(select(CommercialRequestLine).where(CommercialRequestLine.commercial_case_id == case_id).order_by(CommercialRequestLine.line_number)).all())
            assert len(lines) == 2
            assert case.expected_samples == 20
            assert case.requested_test_package == 'Mixed Request Scope'
            assert case.default_priority == 'MIXED'
            assert case.required_tat == 'MIXED'
        r = browser.post(f'/commercial/cases/{case_id}/advance', data={
            'target_stage': 'QUOTATION', 'quotation_number': f'QT-REQ-{uuid4().hex[:6].upper()}', 'note': '', 'reference': '',
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case and case.quotation_id
            quote = db.get(Quotation, case.quotation_id); assert quote
            assert '18 x Routine Test' in quote.description
            assert '2 x Full Test' in quote.description


def test_direct_intake_inherits_scope_and_astm_applies_to_dga_and_bdv():
    with TestClient(app) as browser:
        with SessionLocal() as db:
            site_id, client_id, asset_id, quote_id, po_id, case_id, line_id = _complete_scope(db, quantity=3)
        _login(browser, 'data.entry@tsco.local')
        r = browser.post('/intake/direct', data={
            'client_id': client_id, 'asset_id': asset_id, 'quotation_id': quote_id, 'purchase_order_id': po_id,
            'commercial_request_line_id': line_id, 'requested_package': 'Routine Test',
            'sampling_point': 'Main Tank - Bottom', 'sample_count': 3, 'container_count': 1,
            'client_sample_reference': 'REQ328', 'priority': 'NORMAL', 'required_tat': '',
        }, follow_redirects=False)
        assert r.status_code == 303 and 'created=3' in r.headers['location']
        with SessionLocal() as db:
            rows = list(db.scalars(select(SampleRequest).where(SampleRequest.commercial_request_line_id == line_id).order_by(SampleRequest.id)).all())
            assert len(rows) == 3
            assert all(x.requested_package == 'Full Test' for x in rows)
            assert all(x.requested_method_family == 'ASTM' for x in rows)
            assert all(x.priority == 'URGENT' and x.required_tat == '12H' for x in rows)
            package = resolved_sample_package(db, rows[0])
            methods = [(t.get('test'), t.get('method')) for t in package['tests']]
            assert ('Dissolved Gas Analysis (DGA)', 'ASTM D3612') in methods
            bdv_methods = {m for n, m in methods if 'Breakdown Voltage' in str(n) or 'RSD% of BDV' in str(n)}
            assert bdv_methods == {'ASTM D1816'}


def test_field_assignment_and_field_sample_inherit_same_client_request_scope():
    with TestClient(app) as browser:
        with SessionLocal() as db:
            site_id, client_id, asset_id, quote_id, po_id, case_id, line_id = _complete_scope(db, quantity=2, package='Routine Test', family='IEC', priority='NORMAL', tat='24H')
            ops = db.scalar(select(User).where(User.email == 'field.manager@tsco.local')); assert ops
            sampler = db.scalar(select(User).where(User.email == 'sampleman@tsco.local')); assert sampler
            site = db.get(Site, site_id); assert site
            order = SamplingOrder(
                order_number=f'SO-V328-{uuid4().hex[:8]}', site_id=site_id, client_id=client_id,
                quotation_id=quote_id, purchase_order_id=po_id, commercial_case_id=case_id,
                created_by_id=ops.id, title='Structured field collection', priority='Normal', status='OPEN',
            )
            db.add(order); db.commit(); order_id = order.id; sampler_id = sampler.id
        _login(browser, 'field.manager@tsco.local')
        r = browser.post(f'/operations/orders/{order_id}/assignments', data={
            'asset_id': asset_id, 'commercial_request_line_id': line_id, 'sample_count': 2,
            'sample_label': 'Transformer Main Tank', 'source_party': 'TSCO', 'task_type': 'ON_SITE_SAMPLING',
            'requested_package': 'Full Test', 'sampling_point': 'Main Tank Bottom', 'container_count': 1,
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            rows = list(db.scalars(select(SamplingAssignment).where(SamplingAssignment.order_id == order_id).order_by(SamplingAssignment.id)).all())
            assert len(rows) == 2
            assert all(a.commercial_request_line_id == line_id for a in rows)
            assert all(a.requested_package == 'Routine Test' and a.requested_method_family == 'IEC' for a in rows)
            assert all(a.priority == 'NORMAL' and a.required_tat == '24H' for a in rows)
            first = rows[0]
            first.assigned_sampler_id = sampler_id; first.status = 'ASSIGNED'; first.assigned_at = datetime.utcnow()
            existing = db.scalar(select(UserClientAssignment).where(UserClientAssignment.user_id == sampler_id, UserClientAssignment.client_id == client_id))
            if not existing:
                db.add(UserClientAssignment(user_id=sampler_id, client_id=client_id, active=True))
            db.commit(); assignment_id = first.id
        browser.post('/logout')
        _login(browser, 'sampleman@tsco.local')
        r = browser.post('/field/new', data={
            'assignment_id': assignment_id, 'client_id': client_id, 'quotation_id': quote_id, 'purchase_order_id': po_id,
            'existing_asset_id': asset_id, 'sample_date_time': '2026-09-28T08:00',
            'sampling_point': 'Main Tank Bottom', 'requested_package': 'Full Test', 'container_count': 1,
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            sample = db.scalar(select(SampleRequest).where(SampleRequest.sampling_assignment_id == assignment_id)); assert sample
            assert sample.commercial_request_line_id == line_id
            assert sample.requested_package == 'Routine Test'
            assert sample.requested_method_family == 'IEC'
            assert sample.priority == 'NORMAL' and sample.required_tat == '24H'


def test_auto_analytical_rotation_uses_detailed_night_shift_sequence_in_ranking():
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            # Find a workstation with at least two independently competent active technicians.
            rows = list(db.execute(
                select(CompetencyRecord.workstation, func.count(func.distinct(CompetencyRecord.user_id)))
                .join(User, User.id == CompetencyRecord.user_id)
                .where(CompetencyRecord.site_id == site.id, CompetencyRecord.active.is_(True),
                       CompetencyRecord.authorization == 'INDEPENDENT', User.active.is_(True), User.role == Role.LAB_TECHNICIAN.value)
                .group_by(CompetencyRecord.workstation)
                .having(func.count(func.distinct(CompetencyRecord.user_id)) >= 2)
            ).all())
            assert rows
            workstation = rows[0][0]
            people = list(db.scalars(
                select(User).join(CompetencyRecord, CompetencyRecord.user_id == User.id)
                .where(User.site_id == site.id, User.active.is_(True), User.role == Role.LAB_TECHNICIAN.value,
                       CompetencyRecord.site_id == site.id, CompetencyRecord.workstation == workstation,
                       CompetencyRecord.active.is_(True), CompetencyRecord.authorization == 'INDEPENDENT')
                .distinct().order_by(User.id)
            ).all())
            assert len(people) >= 2
            when = datetime(2026, 9, 28, 8, 0, 0)
            _, start, end, cycle_index = _analytical_rotation_cycle(when)
            offset = cycle_index % len(people)
            ranked = people[offset:] + people[:offset]
            first = ranked[0]
            db.add(StaffAvailability(
                site_id=site.id, user_id=first.id, entry_type='SHIFT', start_at=start, end_at=min(end, start.replace(hour=22)),
                status='APPROVED', shift_code='NIGHT / AUTO-ROSTER', notes='v3.2.8 test', created_by_id=first.id,
            ))
            db.flush()
            payload = {'testAssignments': []}
            created = ensure_analytical_rotation_assignments(db, site.id, payload, {workstation}, when=when)
            assert len(created) == 1
            assert created[0]['primary_user_id'] != first.id
            assert 'Detailed Night Shift sequence' in created[0]['shift_context']


def test_structured_request_one_sample_reaches_lab_with_auto_assignment_without_senior_distribution():
    from app.services.lab_operations import get_operations_state
    with TestClient(app) as browser:
        with SessionLocal() as db:
            site_id, client_id, asset_id, quote_id, po_id, case_id, line_id = _complete_scope(
                db, quantity=1, package='Routine Test', family='IEC', priority='NORMAL', tat=''
            )
        _login(browser, 'data.entry@tsco.local')
        r = browser.post('/intake/direct', data={
            'client_id': client_id, 'asset_id': asset_id, 'quotation_id': quote_id, 'purchase_order_id': po_id,
            'commercial_request_line_id': line_id, 'requested_package': 'Routine Test',
            'sampling_point': 'Main Tank - Bottom', 'sample_count': 1, 'container_count': 1,
            'client_sample_reference': 'ONE-E2E', 'priority': 'NORMAL', 'required_tat': '',
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            sample = db.scalar(select(SampleRequest).where(SampleRequest.commercial_request_line_id == line_id)); assert sample
            sid = sample.id
        r = browser.post('/intake/bulk-decision', data={'sample_ids': [sid], 'note': 'Verified'}, follow_redirects=False)
        assert r.status_code == 303
        r = browser.post('/intake/bulk-receive', data={'sample_ids': [sid], 'seal_status': 'Intact', 'condition_note': 'Received intact'}, follow_redirects=False)
        assert r.status_code == 303
        r = browser.post('/intake/batch-release', data={'sample_ids': [sid], 'note': 'Release to lab'}, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            sample = db.get(SampleRequest, sid); assert sample and sample.status == 'READY_FOR_LAB'
            site = db.get(Site, site_id); assert site
            _, payload = get_operations_state(db, site)
            batch = next(b for b in payload['batches'] if sid in (b.get('platform_sample_ids') or []))
            auto = [a for a in payload['testAssignments'] if a.get('batch_id') == '*' and a.get('source') == 'AUTO_14_DAY_ROTATION']
            assert auto
            assert any(a.get('primary_user_id') for a in auto)
            assert batch.get('method_family') == 'IEC'
