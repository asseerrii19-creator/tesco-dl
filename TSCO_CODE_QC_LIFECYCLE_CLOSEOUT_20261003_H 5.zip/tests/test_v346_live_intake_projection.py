from __future__ import annotations

import json
from datetime import datetime
from uuid import uuid4

from sqlalchemy import select

from app.database import SessionLocal
from app.models import Asset, Client, OperationsState, SampleRequest, Site
from app.services.lab_operations import get_operations_state


def test_existing_lab_batch_refreshes_controlled_intake_metadata_after_backfill():
    token = uuid4().hex[:8].upper()
    with SessionLocal() as db:
        site = db.scalar(select(Site).where(Site.code == "DMM")); assert site
        client = db.scalar(select(Client).where(Client.code == "SEC")); assert client
        asset = Asset(
            client_id=client.id, asset_code=f"SEC-V346-{token}", serial_number=f"V346-{token}",
            equipment_type="Power Transformer", station_name="Dammam West Substation",
            asset_location_label="Dammam West Substation", active=True,
        )
        db.add(asset); db.flush()
        sample = SampleRequest(
            request_number=f"FS-V346-{token}", public_token=f"pub-{token}", barcode_value=f"bc-{token}",
            status="TESTING", site_id=site.id, client_id=client.id, asset_id=asset.id,
            submission_channel="CLIENT_DELIVERED", sample_date_time=datetime(2026, 10, 1, 20, 50),
            sampling_point="Bottom", requested_package="Routine Test", requested_method_family="DEFAULT",
            requested_tests_json="[]", sample_origin="Client-Originated / Direct Delivery",
            priority="URGENT", required_tat="24H", oil_temperature_c=49.0,
            ambient_temperature_c=36.0, ambient_humidity_pct=46.0,
        )
        db.add(sample); db.flush()
        key = sample.request_number.upper()
        stale = {
            "batches": [{
                "id": f"LB-V346-{token}", "samples": [key], "platform_sample_ids": [sample.id],
                "sample_meta": {key: {"point": "Bottom", "temp": "", "roomTemp": "", "roomHumidity": ""}},
                "tests": [], "roomTemp": "", "roomHumidity": "",
            }],
            "results": [], "qc": [], "qualifiedQcProfiles": [], "reports": [], "retained": [],
            "retests": [], "storageAssignments": [], "batchHistory": [], "cancelledSamples": [],
            "supervisorNotes": [], "standards": [], "dgaAttachments": [], "resultEvidence": [],
            "qualityDistributions": [], "qualityTaskEvents": [], "testAssignments": [],
            "assignmentCompletions": [], "clients": [], "customPackages": [], "formulaDefinitions": [],
            "calculationDrafts": {}, "staff": [], "samplePoints": [], "testUnits": {}, "drafts": {},
            "settings": {}, "meta": {},
        }
        state = db.scalar(select(OperationsState).where(OperationsState.site_id == site.id))
        if state is None:
            state = OperationsState(site_id=site.id, json_data=json.dumps(stale), revision=0)
            db.add(state)
        else:
            state.json_data = json.dumps(stale)
        db.commit()

        _state, payload = get_operations_state(db, site)
        meta = payload["batches"][0]["sample_meta"][key]
        assert meta["temp"] == "49.0"
        assert meta["roomTemp"] == "36.0"
        assert meta["roomHumidity"] == "46.0"
        assert payload["batches"][0]["roomTemp"] == "36.0"
        assert payload["batches"][0]["roomHumidity"] == "46.0"
        assert payload["batches"][0]["id"] == f"LB-V346-{token}"
