from __future__ import annotations

from datetime import datetime
from io import BytesIO
from uuid import uuid4

from PIL import Image
from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import (
    Client, GlasswareBatch, HousekeepingTask, NightShiftMonthPlan, Notification,
    OfficeCorrespondence, OfficeMeeting, OfficeMeetingAction, OperationalProject,
    OvertimeClaim, Role, SampleKit, SampleKitTask, Site, StaffAvailability,
    StaffWorkPattern, User,
)


def login(c: TestClient, email: str):
    r = c.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303, (email, r.status_code, r.text[:200])


def logout(c: TestClient):
    c.post('/logout', follow_redirects=False)


def user(db, email: str) -> User:
    row = db.scalar(select(User).where(User.email == email))
    assert row is not None, email
    return row


def tiny_png() -> bytes:
    out = BytesIO()
    Image.new('RGB', (2, 2), 'white').save(out, format='PNG')
    return out.getvalue()


def test_employee_knowledge_and_troubleshooting_are_visible_without_assignment_and_data_entry_is_denied():
    with TestClient(app) as c:
        login(c, 'chemist@tsco.local')
        workstation = c.get('/lab/operations?section=workstations')
        assert workstation.status_code == 200
        assert 'Troubleshooting' in workstation.text
        assert 'Methods / SOPs / EOPs / Quick Guides' in workstation.text

        trouble = c.get('/troubleshooting')
        assert trouble.status_code == 200
        assert 'Troubleshooting' in trouble.text

        docs = c.get('/documents?q=IEC+60814')
        assert docs.status_code == 200
        assert 'Search' in docs.text and ('IEC 60814' in docs.text or 'Water' in docs.text)
        logout(c)

        login(c, 'data.entry@tsco.local')
        assert c.get('/troubleshooting', follow_redirects=False).status_code == 403
        assert c.get('/documents', follow_redirects=False).status_code == 403


def test_housekeeping_assignment_is_employee_scoped_and_requires_photo_evidence():
    with TestClient(app) as c:
        with SessionLocal() as db:
            chem = user(db, 'chemist@tsco.local')
            tech = user(db, 'technician@tsco.local')

        login(c, 'senior.equipment@tsco.local')
        r = c.post('/housekeeping/tasks', data={
            'area_zone': 'V322 Electrical Bench', 'assigned_to_id': str(chem.id),
            'due_at': '', 'shift_code': 'DAY'
        }, follow_redirects=False)
        assert r.status_code == 303
        logout(c)

        with SessionLocal() as db:
            task = db.scalar(select(HousekeepingTask).where(HousekeepingTask.area_zone == 'V322 Electrical Bench').order_by(HousekeepingTask.id.desc()))
            assert task and task.assigned_to_id == chem.id and task.status == 'DUE'
            task_id = task.id

        login(c, 'technician@tsco.local')
        assert c.post(f'/housekeeping/tasks/{task_id}/start', follow_redirects=False).status_code == 403
        logout(c)

        login(c, 'chemist@tsco.local')
        page = c.get('/housekeeping')
        assert page.status_code == 200 and 'V322 Electrical Bench' in page.text
        r = c.post(
            f'/housekeeping/tasks/{task_id}/complete',
            data={'completion_note': 'Bench cleaned and area restored'},
            files={'photo': ('evidence.png', tiny_png(), 'image/png')},
            follow_redirects=False,
        )
        assert r.status_code == 303
        logout(c)

        with SessionLocal() as db:
            task = db.get(HousekeepingTask, task_id)
            assert task.status == 'COMPLETED'
            assert task.completion_photo_path and task.completed_at is not None


def test_glassware_basket_tray_workflow_runs_waiting_to_completed():
    with TestClient(app) as c:
        login(c, 'lab.support@tsco.local')
        r = c.post('/lab-support/glassware', data={
            'source_workstation': 'Water / KF', 'glassware_type': 'Bottle / Flask',
            'approximate_quantity': '8', 'priority': 'HIGH', 'assigned_to_id': '',
            'note': 'V322 closeout basket'
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            row = db.scalar(select(GlasswareBatch).where(GlasswareBatch.note.contains('V322 closeout basket')).order_by(GlasswareBatch.id.desc()))
            assert row and row.batch_code.startswith('GW-') and row.status == 'WAITING'
            batch_id = row.id
        for status in ['WASHING', 'DRYING', 'READY', 'COMPLETED']:
            r = c.post(f'/lab-support/glassware/{batch_id}/status', data={'status': status, 'note': status}, follow_redirects=False)
            assert r.status_code == 303, (status, r.status_code, r.text[:200])
        page = c.get('/lab-support')
        assert page.status_code == 200 and f'GW-{batch_id:04d}' in page.text
        logout(c)
        with SessionLocal() as db:
            row = db.get(GlasswareBatch, batch_id)
            assert row.status == 'COMPLETED' and row.completed_at is not None


def test_secretary_correspondence_meeting_and_action_are_real_records():
    token = uuid4().hex[:8]
    subject = f'V322 Management Correspondence {token}'
    meeting_title = f'V322 Closeout Meeting {token}'
    with TestClient(app) as c:
        login(c, 'secretary@tsco.local')
        with SessionLocal() as db:
            responsible = user(db, 'field.manager@tsco.local')
        r = c.post('/gm-office/correspondence', data={
            'direction': 'INCOMING', 'subject': subject, 'reference': f'REF-{token}',
            'sender': 'Client', 'recipient': 'General Manager',
            'correspondence_at': '2026-09-20T09:00', 'responsible_user_id': str(responsible.id),
            'due_at': '2026-09-22T12:00', 'follow_up_note': 'Follow up'
        }, follow_redirects=False)
        assert r.status_code == 303
        r = c.post('/gm-office/meetings', data={
            'title': meeting_title, 'meeting_at': '2026-09-21T10:00',
            'attendees': 'GM, Field Manager', 'agenda': 'Closeout', 'minutes': ''
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            meeting = db.scalar(select(OfficeMeeting).where(OfficeMeeting.title == meeting_title))
            assert meeting
            meeting_id = meeting.id
        r = c.post(f'/gm-office/meetings/{meeting_id}/actions', data={
            'action_text': 'Submit final deployment evidence', 'owner_user_id': str(responsible.id), 'due_at': '2026-09-22T15:00'
        }, follow_redirects=False)
        assert r.status_code == 303
        page = c.get('/gm-office')
        assert page.status_code == 200 and subject in page.text and meeting_title in page.text
        logout(c)
        with SessionLocal() as db:
            assert db.scalar(select(OfficeCorrespondence).where(OfficeCorrespondence.subject == subject))
            assert db.scalar(select(OfficeMeetingAction).where(OfficeMeetingAction.meeting_id == meeting_id))


def test_employee_overtime_word_and_schedule_visibility():
    with TestClient(app) as c:
        with SessionLocal() as db:
            chem = user(db, 'chemist@tsco.local')
            senior = user(db, 'senior.technical@tsco.local')
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            db.add(NightShiftMonthPlan(site_id=site.id, year=2027, month=2, user_id=chem.id, status='PUBLISHED', created_by_id=senior.id))
            db.add(StaffAvailability(site_id=site.id, user_id=chem.id, entry_type='ON_CALL', start_at=datetime(2027,2,4,16), end_at=datetime(2027,2,5,8), status='CONFIRMED', shift_code='ONCALL', created_by_id=senior.id))
            db.commit(); chem_id = chem.id

        login(c, 'chemist@tsco.local')
        page = c.get('/workforce')
        assert page.status_code == 200 and 'My Night Shift Months' in page.text and 'My Overtime' in page.text
        assert '2027' in page.text and ('ON CALL' in page.text.upper() or 'ON_CALL' in page.text.upper())
        r = c.post('/workforce/overtime/claims', data={
            'work_date': '2026-09-20', 'start_time': '17:00', 'end_time': '19:30',
            'total_hours': '0', 'reason': 'Urgent laboratory workload',
            'project_reference': 'P-00012', 'related_reference': 'BATCH-V322', 'overtime_request_id': ''
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            claim = db.scalar(select(OvertimeClaim).where(OvertimeClaim.employee_id == chem_id).order_by(OvertimeClaim.id.desc()))
            assert claim and abs(claim.total_hours - 2.5) < 0.001 and claim.status == 'DRAFT'
            claim_id = claim.id
        word = c.get(f'/workforce/overtime/claims/{claim_id}/word')
        assert word.status_code == 200
        assert word.headers['content-type'].startswith('application/vnd.openxmlformats-officedocument')
        assert word.content[:2] == b'PK'
        logout(c)
        with SessionLocal() as db:
            assert db.get(OvertimeClaim, claim_id).status == 'WORD_PREPARED'


def test_annual_night_plan_generator_uses_work_pattern_and_competency_without_runtime_error():
    target_year = datetime.utcnow().year + 2
    with TestClient(app) as c:
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            senior = user(db, 'senior.technical@tsco.local')
            chem = user(db, 'chemist@tsco.local')
            pattern = db.scalar(select(StaffWorkPattern).where(StaffWorkPattern.site_id == site.id, StaffWorkPattern.user_id == chem.id))
            if not pattern:
                db.add(StaffWorkPattern(site_id=site.id, user_id=chem.id, name='V322 Standard', weekdays_json='[6,0,1,2,3]', shift_start='08:00', shift_end='16:00', active=True, created_by_id=senior.id))
            else:
                pattern.active = True; pattern.weekdays_json = '[6,0,1,2,3]'; pattern.effective_from = None; pattern.effective_to = None
            db.query(NightShiftMonthPlan).filter(NightShiftMonthPlan.site_id == site.id, NightShiftMonthPlan.year == target_year).delete(synchronize_session=False)
            db.commit()
        login(c, 'senior.technical@tsco.local')
        r = c.post('/workforce/annual-night/generate', data={'year': str(target_year), 'people_per_month': '1'}, follow_redirects=False)
        assert r.status_code == 303, (r.status_code, r.text[:300])
        logout(c)
        with SessionLocal() as db:
            plans = list(db.scalars(select(NightShiftMonthPlan).where(NightShiftMonthPlan.year == target_year)).all())
            assert len(plans) == 12


def test_sample_kit_build_issue_return_and_recondition_cycle_is_operational():
    token = uuid4().hex[:8]
    with TestClient(app) as c:
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            supervisor = user(db, 'sampling.supervisor@tsco.local')
            sampler = user(db, 'sampleman@tsco.local')
            task = SampleKitTask(site_id=site.id, retained_sample_key=f'RETAINED-{token}', container_type='BOTTLE', assigned_to_id=sampler.id, assigned_by_id=supervisor.id, status='READY', note='Authorized reusable retained container')
            db.add(task); db.commit(); db.refresh(task); task_id = task.id; sampler_id = sampler.id
        login(c, 'sampling.supervisor@tsco.local')
        r = c.post('/sampling-supervision/sample-kits', data={'task_ids': str(task_id), 'kit_type': 'Transformer Oil Sampling Kit', 'contents_summary': '', 'note': f'V322 {token}'}, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            kit = db.scalar(select(SampleKit).where(SampleKit.note.contains(token)).order_by(SampleKit.id.desc()))
            assert kit and kit.status == 'PREPARING'; kit_id = kit.id; kit_code = kit.kit_code
        assert c.post(f'/sampling-supervision/sample-kits/{kit_id}/ready', follow_redirects=False).status_code == 303
        assert c.post(f'/sampling-supervision/sample-kits/{kit_id}/issue', data={'sampler_id': str(sampler_id), 'sampling_order_id': '', 'note': 'Issued'}, follow_redirects=False).status_code == 303
        logout(c)

        login(c, 'sampleman@tsco.local')
        page = c.get('/field')
        assert page.status_code == 200 and kit_code in page.text
        assert c.post(f'/field/sample-kits/{kit_id}/return', data={'note': 'Returned'}, follow_redirects=False).status_code == 303
        logout(c)

        login(c, 'sampling.supervisor@tsco.local')
        assert c.post(f'/sampling-supervision/sample-kits/{kit_id}/reconditioning', data={'note': 'Clean again'}, follow_redirects=False).status_code == 303
        logout(c)
        login(c, 'sampleman@tsco.local')
        assert c.post(f'/field/sample-kits/{kit_id}/reconditioned', data={'note': 'Ready'}, follow_redirects=False).status_code == 303
        logout(c)
        with SessionLocal() as db:
            kit = db.get(SampleKit, kit_id)
            assert kit.status == 'READY' and kit.assigned_sampler_id is None


def test_gm_project_approval_notifies_field_and_lab_managers_and_enters_both_planning_views():
    token = uuid4().hex[:8].upper()
    ref = f'V322-P-{token}'
    with TestClient(app) as c:
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            client = db.scalar(select(Client).where(Client.code == 'SEC')); assert client
            ops = user(db, 'field.manager@tsco.local')
            row = OperationalProject(project_reference=ref, project_name='V322 Final Project', site_id=site.id, client_id=client.id, created_by_id=ops.id, project_type='GENERAL', scope='Field and laboratory closeout', location_scope='Eastern Region', planned_start_at=datetime(2026,10,1,8), field_scope=True, laboratory_scope=True, expected_samples=30, test_package='Routine Test', special_tat='24H', status='PENDING_GM_APPROVAL', submitted_at=datetime.utcnow())
            db.add(row); db.commit(); db.refresh(row); project_id = row.id
        login(c, 'general.manager@tsco.local')
        r = c.post(f'/commercial/projects/{project_id}/approve', follow_redirects=False)
        assert r.status_code == 303
        logout(c)
        with SessionLocal() as db:
            row = db.get(OperationalProject, project_id); assert row.status == 'APPROVED'
            field_manager = user(db, 'field.manager@tsco.local')
            lab_manager = user(db, 'lab.manager@tsco.local')
            field_note = db.scalar(select(Notification).where(Notification.user_id == field_manager.id, Notification.title.contains(ref)))
            lab_note = db.scalar(select(Notification).where(Notification.user_id == lab_manager.id, Notification.title.contains(ref)))
            assert field_note and field_note.target_url.startswith('/operations')
            assert lab_note and lab_note.target_url.startswith('/management')
        login(c, 'field.manager@tsco.local')
        ops_page = c.get('/operations')
        assert ops_page.status_code == 200 and ref in ops_page.text and 'Upcoming Projects' in ops_page.text
        logout(c)
        login(c, 'lab.manager@tsco.local')
        lab_page = c.get('/management')
        assert lab_page.status_code == 200 and ref in lab_page.text and 'Laboratory Planning' in lab_page.text


def test_quality_center_template_and_new_role_workspaces_render_without_legacy_document_code_error():
    checks = {
        'excellence.specialist@tsco.local': ['/quality', '/improvement'],
        'secretary@tsco.local': ['/gm-office'],
        'chemist@tsco.local': ['/housekeeping', '/workforce', '/troubleshooting', '/documents'],
        'technician@tsco.local': ['/housekeeping', '/workforce', '/troubleshooting', '/documents'],
        'lab.support@tsco.local': ['/lab-support', '/housekeeping', '/workforce'],
        'sampling.supervisor@tsco.local': ['/sampling-supervision', '/workforce'],
        'lab.manager@tsco.local': ['/management', '/workforce/history'],
        'field.manager@tsco.local': ['/operations', '/workforce/history'],
    }
    with TestClient(app) as c:
        for email, paths in checks.items():
            login(c, email)
            for path in paths:
                r = c.get(path, follow_redirects=False)
                assert r.status_code == 200, (email, path, r.status_code, r.text[:250])
                assert 'Internal Server Error' not in r.text
            logout(c)
