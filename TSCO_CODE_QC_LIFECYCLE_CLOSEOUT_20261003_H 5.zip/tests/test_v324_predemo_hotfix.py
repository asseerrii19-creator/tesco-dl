from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import Asset, Client, SampleRequest, Site, User
from app.services.lab_operations import (
    _qc_workstation,
    _platform_sample_lab_readiness_from_payload,
    reconcile_operations_to_platform,
)


def _user(db, email: str) -> User:
    row = db.scalar(select(User).where(User.email == email))
    assert row is not None, email
    return row


def test_appearance_analytical_qc_routes_to_physical_chemistry():
    assert _qc_workstation("Appearance") == "Physical / Chemistry"
    assert _qc_workstation("Oil Quality Index") == "Physical / Chemistry"


def test_completed_sample_auto_advances_from_testing_to_technical_review():
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "DMM")); assert site
            client = db.scalar(select(Client).where(Client.code == "SEC")); assert client
            asset = db.scalar(select(Asset).where(Asset.client_id == client.id)); assert asset
            chemist = _user(db, "chemist@tsco.local")

            token = uuid4().hex[:8]
            sample = SampleRequest(
                request_number=f"V324-{token}",
                public_token=f"PUB-{token}",
                barcode_value=f"BAR-{token}",
                lms_number=f"LMS-{token}",
                status="TESTING",
                site_id=site.id,
                client_id=client.id,
                asset_id=asset.id,
                sample_date_time=datetime.utcnow(),
                sampling_point="Main Tank",
                sample_origin="Client-Originated / Direct Delivery",
                submission_channel="CLIENT_DELIVERED",
                requested_package="Routine Test",
                priority="NORMAL",
                received_at=datetime.utcnow(),
            )
            db.add(sample)
            db.flush()

            assignment_id = f"WSA-{token}"
            batch_id = f"B-{token}"
            sample_key = sample.request_number
            payload = {
                "batches": [{
                    "id": batch_id,
                    "template": "Pre-Demo Hotfix",
                    "package_id": "V324",
                    "client_id": str(client.id),
                    "client_name": client.name,
                    "client_code": client.code,
                    "priority": "Normal",
                    "site": site.code,
                    "platform_sample_id": sample.id,
                    "platform_sample_ids": [sample.id],
                    "samples": [sample_key],
                    "sample_meta": {sample_key: {}},
                    "tests": [{
                        "test": "Appearance",
                        "method": "Visual",
                        "station": "Physical / Chemistry",
                        "unit": "",
                    }],
                    "status": "Testing",
                    "created_at": datetime.utcnow().isoformat(),
                }],
                "testAssignments": [{
                    "id": assignment_id,
                    "batch_id": batch_id,
                    "scope": "BATCH",
                    "workstation": "Physical / Chemistry",
                    "mode": "SINGLE",
                    "primary_user_id": chemist.id,
                    "primary_name": chemist.full_name,
                    "backup_user_id": None,
                    "backup_name": "",
                    "assigned_by_user_id": chemist.id,
                    "assigned_by": "Test Senior",
                    "assigned_at": datetime.utcnow().isoformat(),
                    "revision": 1,
                    "access_scope": "NAMED_USERS",
                }],
                "results": [{
                    "id": f"R-{token}",
                    "batch": batch_id,
                    "sample": sample_key,
                    "test": "Appearance",
                    "display_test": "Appearance",
                    "result": "Clear & Bright",
                    "unit": "",
                    "calculated": False,
                    "qc_status": "RECORDED",
                }],
                "qc": [{
                    "id": f"QC-{token}",
                    "mode": "routine",
                    "test": "Appearance",
                    "workstation": "Physical / Chemistry",
                    "assignment_id": assignment_id,
                    "batch_id": batch_id,
                    "status": "RECORDED",
                    "result": "1",
                    "target": "1",
                    "ts": datetime.utcnow().isoformat(),
                }],
                "assignmentCompletions": [{
                    "id": f"AC-{token}",
                    "batch_id": batch_id,
                    "workstation": "Physical / Chemistry",
                    "assignment_id": assignment_id,
                    "completed_by_user_id": chemist.id,
                    "completed_by": chemist.full_name,
                    "completed_at": datetime.utcnow().isoformat(),
                }],
                "retests": [],
                "reports": [],
            }

            ready, reason = _platform_sample_lab_readiness_from_payload(payload, sample)
            assert ready is True, reason
            changed = reconcile_operations_to_platform(db, payload, site.id, chemist)
            assert changed == 1
            assert sample.status == "TECHNICAL_REVIEW"
