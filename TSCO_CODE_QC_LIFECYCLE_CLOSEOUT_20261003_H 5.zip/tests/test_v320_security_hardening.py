from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import Site, User
from app.services.lab_operations import get_operations_state, validate_operations_update


def _user(db, email: str) -> User:
    row = db.scalar(select(User).where(User.email == email))
    assert row is not None, email
    return row


def test_retained_sample_disposition_is_limited_to_senior_technical_or_lab_manager():
    # Keep this security test independently runnable: application startup creates/migrates
    # the disposable pytest database and seeds the UAT review identities used below.
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "DMM"))
            assert site is not None
            _, current = get_operations_state(db, site)

            proposed = deepcopy(current)
            proposed["retained"] = list(proposed.get("retained", [])) + [{
                "sample": "SECURITY-CLOSEOUT-RET-1",
                "status": "Disposed",
                "disposed_at": "2026-09-20T00:00:00",
            }]

            equipment_senior = _user(db, "senior.equipment@tsco.local")
            with pytest.raises(PermissionError, match="Senior Chemist — Technical"):
                validate_operations_update(current, deepcopy(proposed), equipment_senior, db=db, site_id=site.id)

            technical_senior = _user(db, "senior.technical@tsco.local")
            accepted = validate_operations_update(current, deepcopy(proposed), technical_senior, db=db, site_id=site.id)
            assert accepted["retained"][-1]["sample"] == "SECURITY-CLOSEOUT-RET-1"

            lab_manager = _user(db, "lab.manager@tsco.local")
            accepted = validate_operations_update(current, deepcopy(proposed), lab_manager, db=db, site_id=site.id)
            assert accepted["retained"][-1]["status"] == "Disposed"


def test_lab_console_has_no_broad_all_staff_assignment_or_admin_business_release_shortcut():
    root = Path(__file__).resolve().parents[1]
    html = (root / "app/lab_ops/index_template.html").read_text(encoding="utf-8")
    service = (root / "app/services/lab_operations.py").read_text(encoding="utf-8")
    sections = (root / "app/lab_sections.py").read_text(encoding="utf-8")

    assert 'All Laboratory Chemists' not in html
    assignment_select = html.split('id="assignMode"', 1)[1].split('</select>', 1)[0]
    assert 'value="ALL"' not in assignment_select
    assert "broad ALL-staff assignments are not permitted" in service
    assert "function canFinalRelease(){return CURRENT_ROLE==='technical_manager'}" in html
    assert "TSCO_PLATFORM_SENIOR_DOMAIN" in (root / "app/routes/lab_operations.py").read_text(encoding="utf-8")
    assert 'Role.SYSTEM_ADMIN.value: {"general"}' in sections
