"""Regression: the bench must not receive 403 when unchanged assignments arrive in a different order."""
from copy import deepcopy
import pytest
from types import SimpleNamespace
from app.services.lab_operations import merge_scoped_operations_update, scope_operations_payload


def test_technician_unchanged_assignments_reordered_are_not_a_write():
    user = SimpleNamespace(id=18, role='lab_technician')
    assignments = [
        {'id': f'A-{station}', 'batch_id': '*', 'scope': 'WORKSTATION', 'workstation': station,
         'mode': 'SINGLE', 'revision': 1, 'primary_user_id': 18, 'backup_user_id': None}
        for station in ('DGA', 'Water', 'Physical / Chemistry')
    ]
    current = {
        'batches': [{'id': 'B1', 'samples': ['S1'], 'tests': [
            {'test': 'Dissolved Gas Analysis (DGA)', 'station': 'DGA'},
            {'test': 'Water Content KF @RT', 'station': 'Water'},
            {'test': 'Color ASTM', 'station': 'Physical / Chemistry'}]}],
        'results': [], 'qc': [], 'qualifiedQcProfiles': [], 'retests': [],
        'dgaAttachments': [], 'testAssignments': assignments,
        'assignmentCompletions': [], 'qualityDistributions': [], 'qualityTaskEvents': [],
        'reports': [], 'retained': [], 'storageAssignments': [], 'batchHistory': [],
        'cancelledSamples': [], 'supervisorNotes': [],
        'staff': [{'id': 18, 'name': 'Technician', 'role': 'lab_technician'}],
        'clients': [], 'settings': {}, 'meta': {'revision': 1},
        'drafts': {}, 'calculationDrafts': {},
    }
    incoming = deepcopy(scope_operations_payload(current, user))
    assert len(incoming['testAssignments']) == 3
    incoming['testAssignments'] = list(reversed(incoming['testAssignments']))
    incoming['drafts']['S1|DGA:H2'] = '7.4'
    merged = merge_scoped_operations_update(current, incoming, user)
    assert merged['testAssignments'] == current['testAssignments']
    assert merged['drafts']['S1|DGA:H2'] == '7.4'
    # Ordering is irrelevant; changes to actual assignment identity/ownership remain forbidden.
    forged = deepcopy(incoming)
    forged['testAssignments'][0]['primary_user_id'] = 999
    with pytest.raises(PermissionError, match='testAssignments'):
        merge_scoped_operations_update(current, forged, user)

    duplicated = deepcopy(incoming)
    duplicated['testAssignments'].append(deepcopy(duplicated['testAssignments'][0]))
    with pytest.raises(PermissionError, match='testAssignments'):
        merge_scoped_operations_update(current, duplicated, user)
