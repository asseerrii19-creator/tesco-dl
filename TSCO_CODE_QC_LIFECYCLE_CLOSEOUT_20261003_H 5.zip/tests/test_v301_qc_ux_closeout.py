from collections import Counter
from datetime import datetime

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import EquipmentAsset, Role, Site, User
from app.services.lab_operations import blank_operations_db, ensure_monthly_quality_distribution


def login(client, email, password='Demo123!'):
    r=client.post('/login',data={'email':email,'password':password},follow_redirects=False)
    assert r.status_code==303


def test_analytical_monthly_ownership_never_stacks_multiple_primary_or_backup_assets():
    site=Site(id=9001,code='TEST',name='Test Site',laboratory_name='Test Lab',active=True)
    staff=[User(id=9100+i,email=f't{i}@example.com',full_name=f'Tech {i}',password_hash='x',role=Role.LAB_TECHNICIAN.value,site_id=site.id,active=True) for i in range(4)]
    equipment=[EquipmentAsset(id=9200+i,site_id=site.id,equipment_id=f'EQ-{i+1}',name=f'Instrument {i+1}',workstation='Water',test_method='IEC',status='IN_SERVICE',active=True) for i in range(7)]
    payload=blank_operations_db(site)
    dist=ensure_monthly_quality_distribution(payload,staff,when=datetime(2026,9,16),equipment=equipment)
    rows=dist['analytical_ownership']
    primary=Counter(r['primary_user_id'] for r in rows if r.get('primary_user_id'))
    backup=Counter(r['backup_user_id'] for r in rows if r.get('backup_user_id'))
    assert max(primary.values(),default=0)<=1
    assert max(backup.values(),default=0)<=1
    assert any(r['status']=='COVERAGE_REQUIRED' for r in rows)
    assert len({r['equipment_id'] for r in rows})==len(rows)==7


def test_routine_owner_pair_is_fixed_across_all_windows_in_same_month():
    site=Site(id=9301,code='TEST2',name='Test Site 2',laboratory_name='Test Lab 2',active=True)
    staff=[User(id=9400+i,email=f'q{i}@example.com',full_name=f'Chemist {i}',password_hash='x',role=Role.LAB_TECHNICIAN.value,site_id=site.id,active=True) for i in range(3)]
    payload=blank_operations_db(site)
    dist=ensure_monthly_quality_distribution(payload,staff,when=datetime(2026,9,16))
    for task_key in ('balances','electrode','chemical_inventory','sample_storage'):
        rows=[r for r in dist['assignments'] if r['task_key']==task_key]
        assert rows
        assert len({r['primary_user_id'] for r in rows})==1
        assert len({r.get('backup_user_id') for r in rows})==1
    assert dist['ownership_model']=='MONTHLY_FIXED_PRIMARY_BACKUP_V2'


def test_live_distribution_uses_exact_equipment_ids_and_enforces_anti_overload():
    with TestClient(app) as client:
        login(client,'quality@tsco.local')
        data=client.get('/api/lab-operations/data').json()['db']
        month=datetime.utcnow().strftime('%Y-%m')
        dist=max((d for d in data['qualityDistributions'] if d['month']==month),key=lambda d:int(d.get('revision') or 1))
        rows=dist['analytical_ownership']
        assert rows
        assert all(r.get('equipment_id','').startswith('EQ-') for r in rows)
        primary=Counter(r['primary_user_id'] for r in rows if r.get('primary_user_id'))
        backup=Counter(r['backup_user_id'] for r in rows if r.get('backup_user_id'))
        assert max(primary.values(),default=0)<=1
        assert max(backup.values(),default=0)<=1


def test_brief_archive_has_single_navigation_entry_and_no_duplicate_topbar_shortcut():
    with TestClient(app) as client:
        login(client,'chemist@tsco.local')
        page=client.get('/control/my-quality-tasks')
        assert page.status_code==200
        assert page.text.count('href="/control/daily-brief"')==1
        assert 'Brief Archive' in page.text
        archive=client.get('/control/daily-brief')
        assert 'Daily Brief Archive' in archive.text
        assert 'archive/reference copy only' in archive.text


def test_public_landing_is_concise_not_editorial_stack():
    with TestClient(app) as client:
        page=client.get('/welcome')
        assert page.status_code==200
        assert 'Six controlled steps' in page.text
        assert 'Secure Sign In' in page.text
        assert 'Our Vision' in page.text
        assert 'Who We Are' in page.text
        assert 'Our Laboratories' in page.text
        assert 'class="lab-photo-slot"' not in page.text
        assert 'Open Analytical Lab Profile' in page.text
        assert page.text.count('<article>') <= 14
        assert page.text.count('class="public-rail-item"') == 3
