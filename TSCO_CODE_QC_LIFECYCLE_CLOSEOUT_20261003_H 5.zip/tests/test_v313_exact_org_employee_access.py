from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import User
from app.routes.organization import ORG_EMPLOYEES


def login(client, email, password='Demo123!'):
    r = client.post('/login', data={'email': email, 'password': password}, follow_redirects=False)
    assert r.status_code == 303, r.text


def test_source_org_chart_is_reproduced_without_invented_departments():
    with TestClient(app) as client:
        login(client, 'admin@tsco.local')
        page = client.get('/organization')
        assert page.status_code == 200
        for text in [
            'Salah Al-Shajira', 'Ohood Al Hareeqi', 'Renad Al Qahtani',
            'SALES & MARKETING DEPARTMENT', 'Dammam & Bahrain Labs',
            'Abdulmajeed', 'Ahmed Al Qahtani', 'Rwad',
            'CLIENT ACCOUNT & COORDINATION OFFICER', 'Sara Al Otaibi',
            'QHSE', 'SHARED SERVICES',
        ]:
            assert text in page.text
        assert 'Continuous Improvement Department' not in page.text
        assert 'Quality Department' not in page.text
        assert 'Sample Intake Department' not in page.text
        assert 'Receiving Department' not in page.text


def test_data_entry_is_one_person_one_login_with_all_intake_stages_inside_workspace():
    with TestClient(app) as client:
        login(client, 'ahmed.alqahtani@tsco.local')
        page = client.get('/intake?view=incoming')
        assert page.status_code == 200
        for text in ['Incoming &amp; Verification', 'Physical Receiving', 'Batch &amp; Distribution', 'Released to Laboratory']:
            assert text in page.text
    with SessionLocal() as db:
        ahmed = db.scalar(select(User).where(User.email == 'ahmed.alqahtani@tsco.local'))
        assert ahmed and ahmed.active and ahmed.role == 'data_entry'
        # Historical alias exists only in APP_ENV=testing for regression compatibility.
        duplicate = db.scalar(select(User).where(User.email == 'receiving@tsco.local'))
        assert duplicate is not None and duplicate.full_name == 'Legacy Receiving Test Alias'


def test_every_named_org_chart_employee_has_one_canonical_active_uat_login():
    expected = {email.lower(): (name, role) for name, email, _job, _area, role in ORG_EMPLOYEES}
    assert len(expected) == len(ORG_EMPLOYEES) == 32
    with TestClient(app):
        with SessionLocal() as db:
            rows = list(db.scalars(select(User).where(User.email.in_(expected.keys()))).all())
            assert len(rows) == len(expected)
            for user in rows:
                name, role = expected[user.email.lower()]
                assert user.active is True
                assert user.full_name == name
                assert user.role == role


def test_employee_directory_exposes_named_people_jobs_and_hides_access_details_from_regular_staff():
    with TestClient(app) as client:
        login(client, 'anas.asiri@tsco.local')
        page = client.get('/organization/employees')
        assert page.status_code == 200
        for text in [
            'Employee Directory & Responsibilities', 'Anas Asiri', 'Technician',
            'Malindu Eranda', 'Client Account &amp; Coordination Officer',
            'Mohammed Al Yahya', 'Senior Chemist', 'Ahmed Al Qahtani', 'Data Entry',
        ]:
            assert text in page.text
        assert 'Named people in source chart' in page.text
        assert '>32<' in page.text
        assert 'anas.asiri@tsco.local' not in page.text
        client.post('/logout')
        login(client, 'salah.alshajira@tsco.local')
        manager_page = client.get('/organization/employees')
        assert 'anas.asiri@tsco.local' in manager_page.text
        assert 'System access' in manager_page.text


def test_client_coordination_stays_under_field_operations_and_excellence_is_not_department():
    with TestClient(app) as client:
        login(client, 'malindu.eranda@tsco.local')
        org = client.get('/organization')
        assert org.status_code == 200
        assert 'CLIENT ACCOUNT & COORDINATION OFFICER' in org.text
        assert 'Field Operations' in org.text
        client.post('/logout')
        login(client, 'ohood.alhareeqi@tsco.local')
        improvement = client.get('/improvement')
        assert improvement.status_code == 200
        assert 'EXCELLENCE-COORDINATED' in improvement.text
        assert 'not a separate department' in improvement.text
        assert 'QHSE remains a separate Shared Services responsibility and workspace' in improvement.text


def test_active_departments_match_source_chart_structure_only():
    with TestClient(app):
        with SessionLocal() as db:
            from app.models import Department
            depts = {d.code: d.name for d in db.scalars(select(Department).where(Department.active.is_(True))).all()}
            assert depts == {
                'CORP': 'General Management',
                'SAM': 'Sales & Marketing Department',
                'SHARED': 'Shared Services',
                'LABS': 'Dammam & Bahrain Labs',
                'FIELD': 'Field Operations',
                'LAB': 'Laboratory Operations',
            }
