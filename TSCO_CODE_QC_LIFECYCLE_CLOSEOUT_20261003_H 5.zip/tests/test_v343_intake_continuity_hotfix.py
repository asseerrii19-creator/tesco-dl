from __future__ import annotations

import hashlib
from pathlib import Path
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import Asset, Client, CommercialAttachment, CommercialCase, CommercialRequestLine, PurchaseOrder, Quotation, SampleRequest, Site
from app.services.client_data_form import parse_client_data_form


def _login(browser: TestClient, email: str) -> None:
    r = browser.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303


def _uat_form_bytes() -> bytes:
    return (Path(__file__).resolve().parents[1] / 'app' / 'uat_fixtures' / 'TSCO_UAT_Client_Data_Form_BC-DMM-2026-0003.pdf').read_bytes()


def test_explicit_client_data_form_parser_extracts_two_samples():
    payload = parse_client_data_form(_uat_form_bytes())
    assert payload['text_found'] is True
    assert set(payload['samples']) == {'UAT-SEC-TR-001', 'UAT-SEC-TR-002'}
    first = payload['samples']['UAT-SEC-TR-001']
    second = payload['samples']['UAT-SEC-TR-002']
    assert first['sampling_point'] == 'Bottom drain valve'
    assert first['sample_date_time'] == '2026-10-01T14:30'
    assert first['manufacturer'] == 'WESCOSA'
    assert first['tag_number'] == 'UAT-TAG-001'
    assert first['hv_voltage_kv'] == 115.0 and first['lv_voltage_kv'] == 13.8
    assert first['oil_temperature_c'] == 48.0
    assert second['oil_temperature_c'] == 49.0


def test_same_case_can_continue_when_expected_serials_are_not_in_asset_master():
    token = uuid4().hex[:8].upper()
    raw = _uat_form_bytes()
    with TestClient(app) as browser:
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            client = db.scalar(select(Client).where(Client.code == 'SEC')); assert client
            quote = Quotation(client_id=client.id, number=f'QT-V343-{token}', status='CLIENT_ACCEPTED', description='v3.4.3 continuity')
            db.add(quote); db.flush()
            po = PurchaseOrder(client_id=client.id, quotation_id=quote.id, number=f'PO-V343-{token}', status='ACTIVE')
            db.add(po); db.flush()
            case = CommercialCase(
                case_code=f'BC-DMM-V343-{token}', site_id=site.id, client_id=client.id,
                quotation_id=quote.id, purchase_order_id=po.id, current_stage='COMPLETE_HANDOVER', status='ACTIVE',
                lead_title='Transformer Oil Testing', handover_commercial='Approved', handover_technical='Routine Test',
                handover_client_info='Direct delivery', expected_samples=2, requested_test_package='Routine Test',
                default_priority='URGENT', required_tat='24H', sample_delivery_mode='CLIENT_DELIVERY',
                sample_delivery_notes='Dammam West Substation',
            )
            db.add(case); db.flush()
            line = CommercialRequestLine(
                commercial_case_id=case.id, line_number=1, quantity=2, requested_package='Routine Test',
                requested_tests_json='[]', expected_serials_json='["UAT-SEC-TR-001", "UAT-SEC-TR-002"]',
                method_family='DEFAULT', priority='URGENT', required_tat='24H', status='ACTIVE',
            )
            db.add(line); db.flush()
            attachment = CommercialAttachment(
                commercial_case_id=case.id, document_type='CLIENT_DATA_FORM',
                original_name='TSCO_UAT_Client_Data_Form_BC-DMM-2026-0003.pdf', stored_path='/missing/on-purpose.pdf',
                content_type='application/pdf', sha256=hashlib.sha256(raw).hexdigest(), content_blob=raw,
            )
            db.add(attachment); db.commit()
            ids = (client.id, quote.id, po.id, line.id, case.id, attachment.id)

        _login(browser, 'data.entry@tsco.local')
        page = browser.get(f'/intake?view=incoming&scope_line_id={ids[3]}')
        assert page.status_code == 200
        assert 'UAT-SEC-TR-001' in page.text and 'UAT-SEC-TR-002' in page.text
        assert 'TSCO_UAT_Client_Data_Form_BC-DMM-2026-0003.pdf' in page.text
        assert 'controlled identity will be created on submit' in page.text

        doc = browser.get(f'/commercial/attachments/{ids[5]}')
        assert doc.status_code == 200
        assert doc.content.startswith(b'%PDF-')

        r = browser.post('/intake/direct', data={
            'client_id': ids[0], 'quotation_id': ids[1], 'purchase_order_id': ids[2],
            'commercial_request_line_id': ids[3], 'serial_numbers': 'UAT-SEC-TR-001\nUAT-SEC-TR-002',
            'requested_package': 'Routine Test', 'sampling_point': '', 'sample_date_time': '',
            'sample_count': 2, 'container_count': 1, 'client_sample_reference': 'UAT-V343',
            'priority': 'URGENT', 'required_tat': '24H',
        }, follow_redirects=False)
        assert r.status_code == 303, r.text[:600]
        assert 'created=2' in r.headers['location']

        with SessionLocal() as db:
            rows = list(db.scalars(select(SampleRequest).where(SampleRequest.commercial_case_id == ids[4]).order_by(SampleRequest.id)).all())
            assert len(rows) == 2
            assert [row.asset.serial_number for row in rows] == ['UAT-SEC-TR-001', 'UAT-SEC-TR-002']
            assert all(row.sampling_point == 'Bottom drain valve' for row in rows)
            assert rows[0].oil_temperature_c == 48.0 and rows[1].oil_temperature_c == 49.0
            assert all(row.priority == 'URGENT' and row.required_tat == '24H' for row in rows)
            assets = list(db.scalars(select(Asset).where(Asset.client_id == ids[0], Asset.serial_number.in_(['UAT-SEC-TR-001','UAT-SEC-TR-002']))).all())
            assert len(assets) == 2
            assert all(a.station_name == 'Dammam West Substation' for a in assets)
            assert {a.tag_number for a in assets} == {'UAT-TAG-001', 'UAT-TAG-002'}
