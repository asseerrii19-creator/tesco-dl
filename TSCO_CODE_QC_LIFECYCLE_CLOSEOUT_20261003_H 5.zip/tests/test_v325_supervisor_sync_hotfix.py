from __future__ import annotations

from datetime import datetime
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import Asset, Client, SampleRequest, Site, TestPackageConfig, User
from app.services.lab_operations import sync_samples_to_operations


def _login(client: TestClient, email: str):
    r = client.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303, (email, r.status_code, r.text)


def test_unauthorized_embedded_pages_are_hidden_not_removed_so_async_sync_can_render():
    with TestClient(app) as client:
        _login(client, 'senior.technical@tsco.local')
        r = client.get('/lab/operations/app?embed=1&section=supervisor')
        assert r.status_code == 200
        html = r.text
        assert "page.hidden=true" in html
        assert "page.inert=true" in html
        assert "page.remove()" not in html.split('function pruneUnauthorizedPages()', 1)[1].split('function boot()', 1)[0]
        assert "CLOUD_ENDPOINT='/api/lab-operations/data'" in html


def test_access_changed_role_switch_uses_post_logout():
    with TestClient(app) as client:
        _login(client, 'data.entry@tsco.local')
        r = client.get('/commercial/cases/1/advance')
        # GET on a POST-only business action returns a branded error page or 405 depending route resolution.
        # Exercise a known unauthorized lab section to guarantee branded HTTP error handling.
        r = client.get('/lab/operations?section=supervisor')
        assert r.status_code == 403
        assert "form method='post' action='/logout'" in r.text
        assert "href='/logout'" not in r.text


def test_released_batch_is_visible_to_senior_operations_api():
    with TestClient(app) as client:
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            client_row = db.scalar(select(Client).where(Client.code == 'SEC')); assert client_row
            asset = db.scalar(select(Asset).where(Asset.client_id == client_row.id)); assert asset
            actor = db.scalar(select(User).where(User.email == 'data.entry@tsco.local')); assert actor
            package = db.scalar(select(TestPackageConfig).where(TestPackageConfig.active.is_(True)).order_by(TestPackageConfig.id)); assert package
            token = uuid4().hex[:8]
            sample = SampleRequest(
                request_number=f'V325-{token}', public_token=f'PUB-{token}', barcode_value=f'BAR-{token}',
                lms_number=f'LMS-{token}', status='RECEIVED', site_id=site.id, client_id=client_row.id, asset_id=asset.id,
                sample_date_time=datetime.utcnow(), sampling_point='Main Tank - Bottom',
                sample_origin='Client-Originated / Direct Delivery', submission_channel='CLIENT_DELIVERED',
                requested_package=package.name, priority='NORMAL', required_tat='Standard', received_at=datetime.utcnow(),
            )
            db.add(sample); db.flush()
            sample_key = sample.lms_number
            batch_id = sync_samples_to_operations(db, [sample], actor, phase='READY_FOR_LAB')
            db.commit()

        _login(client, 'senior.technical@tsco.local')
        payload = client.get('/api/lab-operations/data')
        assert payload.status_code == 200, payload.text
        data = payload.json()['db']
        batch = next((b for b in data.get('batches', []) if b.get('id') == batch_id), None)
        assert batch is not None
        assert sample_key.upper() in batch['samples']
        assert batch['status'] == 'Ready for Testing'
