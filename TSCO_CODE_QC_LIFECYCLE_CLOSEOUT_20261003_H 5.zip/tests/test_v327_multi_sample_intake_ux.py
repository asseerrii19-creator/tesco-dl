from __future__ import annotations

import json
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import Asset, Client, CommercialCase, PurchaseOrder, Quotation, SampleRequest, Site, TestPackageConfig
from app.services.lab_operations import get_operations_state


def _login(client: TestClient, email: str = "data.entry@tsco.local") -> None:
    r = client.post("/login", data={"email": email, "password": "Demo123!"}, follow_redirects=False)
    assert r.status_code == 303


def _scope(db, count: int = 3):
    token = uuid4().hex[:8].upper()
    site = db.scalar(select(Site).where(Site.code == "DMM")); assert site
    client = db.scalar(select(Client).where(Client.code == "SEC")); assert client
    asset = db.scalar(select(Asset).where(Asset.client_id == client.id)); assert asset
    pkg = db.scalar(select(TestPackageConfig).where(TestPackageConfig.active.is_(True)).order_by(TestPackageConfig.id)); assert pkg
    quote = Quotation(client_id=client.id, number=f"QT-V327-{token}", status="ACTIVE", description="Bulk UAT")
    db.add(quote); db.flush()
    po = PurchaseOrder(client_id=client.id, quotation_id=quote.id, number=f"PO-V327-{token}", status="ACTIVE")
    db.add(po); db.flush()
    case = CommercialCase(
        case_code=f"BC-DMM-2026-{token}", site_id=site.id, client_id=client.id,
        quotation_id=quote.id, purchase_order_id=po.id, current_stage="COMPLETE_HANDOVER", status="ACTIVE",
        lead_title="Bulk direct intake UAT", handover_commercial="Approved quote and PO",
        handover_technical="Transformer oil testing", handover_client_info="Direct delivery",
        expected_samples=count, requested_test_package=pkg.name, default_priority="NORMAL", required_tat="",
    )
    db.add(case); db.commit()
    return site.id, client.id, asset.id, quote.id, po.id, case.id, pkg.name


def test_direct_intake_creates_unique_records_and_remembers_new_sampling_point():
    with TestClient(app) as client:
        with SessionLocal() as db:
            site_id, client_id, asset_id, quote_id, po_id, case_id, pkg = _scope(db, 3)
        _login(client)
        r = client.post("/intake/direct", data={
            "client_id": client_id, "asset_id": asset_id, "quotation_id": quote_id, "purchase_order_id": po_id,
            "requested_package": pkg, "sampling_point": "Demo Valve V327", "sample_count": 3,
            "container_count": 1, "client_sample_reference": "CLIENT-BULK", "notes": "Controlled bulk intake",
            "priority": "NORMAL", "required_tat": "",
        }, follow_redirects=False)
        assert r.status_code == 303
        assert "created=3" in r.headers["location"]
        with SessionLocal() as db:
            rows = list(db.scalars(select(SampleRequest).where(SampleRequest.commercial_case_id == case_id).order_by(SampleRequest.id)).all())
            assert len(rows) == 3
            assert len({r.request_number for r in rows}) == 3
            assert len({r.barcode_value for r in rows}) == 3
            assert [r.client_sample_reference for r in rows] == ["CLIENT-BULK-01", "CLIENT-BULK-02", "CLIENT-BULK-03"]
            asset = db.get(Asset, asset_id); assert asset
            assert "Demo Valve V327" in json.loads(asset.sampling_points_json)


def test_bulk_data_review_receipt_and_release_runs_three_samples_without_per_sample_clicks():
    with TestClient(app) as client:
        with SessionLocal() as db:
            site_id, client_id, asset_id, quote_id, po_id, case_id, pkg = _scope(db, 3)
        _login(client)
        r = client.post("/intake/direct", data={
            "client_id": client_id, "asset_id": asset_id, "quotation_id": quote_id, "purchase_order_id": po_id,
            "requested_package": pkg, "sampling_point": "Main Tank - Bottom", "sample_count": 3,
            "container_count": 1, "client_sample_reference": "BULK", "priority": "NORMAL", "required_tat": "",
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            rows = list(db.scalars(select(SampleRequest).where(SampleRequest.commercial_case_id == case_id).order_by(SampleRequest.id)).all())
            ids = [r.id for r in rows]
        r = client.post("/intake/bulk-decision", data={"sample_ids": ids, "note": "Bulk verified"}, follow_redirects=False)
        assert r.status_code == 303 and "view=receiving" in r.headers["location"]
        with SessionLocal() as db:
            rows = [db.get(SampleRequest, i) for i in ids]
            assert all(r and r.status == "AWAITING_RECEIPT" and not r.lms_number for r in rows)
        r = client.post("/intake/bulk-receive", data={"sample_ids": ids, "seal_status": "Intact", "condition_note": "Container received intact and label verified."}, follow_redirects=False)
        assert r.status_code == 303 and "view=distribution" in r.headers["location"]
        r = client.post("/intake/batch-release", data={"sample_ids": ids, "note": "Controlled lab handoff"}, follow_redirects=False)
        assert r.status_code == 303 and "view=released" in r.headers["location"]
        with SessionLocal() as db:
            rows = [db.get(SampleRequest, i) for i in ids]
            assert all(r and r.status == "READY_FOR_LAB" for r in rows)
            site = db.get(Site, site_id); assert site
            _, payload = get_operations_state(db, site)
            batches = [b for b in payload["batches"] if sorted(b.get("platform_sample_ids") or []) == sorted(ids)]
            assert len(batches) == 1
            assert len(batches[0]["samples"]) == 3


def test_intake_ui_exposes_scope_prefill_bulk_actions_and_reusable_choices():
    with TestClient(app) as client:
        with SessionLocal() as db:
            _scope(db, 10)
        _login(client)
        page = client.get("/intake?view=incoming")
        assert page.status_code == 200
        text = page.text
        assert "Number of Samples Received" in text
        assert "Creates a unique Sample ID + barcode" in text
        assert "Commercial scope: expected" in text
        assert "samplingPointOptions" in text
        assert "New values are saved to this asset" in text


def test_commercial_case_stage_uses_furthest_linked_sample_not_only_legacy_single_pointer():
    from app.services.commercial import effective_stage
    with TestClient(app):
        with SessionLocal() as db:
            site_id, client_id, asset_id, quote_id, po_id, case_id, pkg = _scope(db, 2)
            case = db.get(CommercialCase, case_id); assert case
            first = SampleRequest(request_number=f"V327-A-{uuid4().hex[:6]}", public_token=uuid4().hex, barcode_value=uuid4().hex,
                                  status="RECEIVED", site_id=site_id, client_id=client_id, asset_id=asset_id,
                                  quotation_id=quote_id, purchase_order_id=po_id, commercial_case_id=case_id,
                                  sample_date_time=__import__('datetime').datetime.utcnow(), sampling_point="Main Tank - Bottom",
                                  requested_package=pkg, sample_origin="Client-Originated / Direct Delivery", submission_channel="CLIENT_DELIVERED")
            second = SampleRequest(request_number=f"V327-B-{uuid4().hex[:6]}", public_token=uuid4().hex, barcode_value=uuid4().hex,
                                   status="TECHNICAL_REVIEW", site_id=site_id, client_id=client_id, asset_id=asset_id,
                                   quotation_id=quote_id, purchase_order_id=po_id, commercial_case_id=case_id,
                                   sample_date_time=__import__('datetime').datetime.utcnow(), sampling_point="Main Tank - Bottom",
                                   requested_package=pkg, sample_origin="Client-Originated / Direct Delivery", submission_channel="CLIENT_DELIVERED")
            db.add_all([first, second]); db.flush()
            case.sample_request_id = first.id
            case.current_stage = "SAMPLE_DELIVERY"
            db.commit(); db.refresh(case)
            assert effective_stage(db, case) == "REVIEW"
