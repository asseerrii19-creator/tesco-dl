from pathlib import Path
from urllib.parse import urlsplit

from bs4 import BeautifulSoup
from fastapi.testclient import TestClient

from app.main import app


INTERNAL_USERS = [
    "fieldman@tsco.local",
    "supervisor@tsco.local",
    "operations@tsco.local",
    "intake@tsco.local",
    "receiving@tsco.local",
    "chemist@tsco.local",
    "senior@tsco.local",
    "quality@tsco.local",
    "technical@tsco.local",
    "manager@tsco.local",
    "sales@tsco.local",
    "finance@tsco.local",
    "excellence@tsco.local",
    "admin@tsco.local",
]


def login(client: TestClient, email: str, password: str = "Demo123!"):
    r = client.post("/login", data={"email": email, "password": password}, follow_redirects=False)
    assert r.status_code == 303, (email, r.status_code, r.text)


def test_public_profile_is_official_compact_and_not_a_newspaper():
    with TestClient(app) as client:
        page = client.get("/welcome")
        assert page.status_code == 200
        assert "Our Vision" in page.text
        assert "Who We Are" in page.text
        assert "Our Laboratories" in page.text
        assert "Open Analytical Lab Profile" in page.text
        assert "TSCO_Analytical_Lab_Profile_August_2026.pdf" in page.text
        assert "PHOTO" not in page.text
        assert "Bahrain Laboratory" not in page.text
        assert page.text.count('class="public-rail-item"') == 3


def test_clean_profile_is_served_and_source_copy_has_23_pages():
    profile = Path(__file__).resolve().parents[1] / "app" / "static" / "documents" / "TSCO_Analytical_Lab_Profile_August_2026.pdf"
    assert profile.exists()
    assert profile.stat().st_size > 1_000_000
    with TestClient(app) as client:
        r = client.get("/static/documents/TSCO_Analytical_Lab_Profile_August_2026.pdf")
        assert r.status_code == 200
        assert r.headers.get("content-type", "").startswith("application/pdf")


def test_every_visible_internal_navigation_link_is_reachable_for_the_role():
    # This catches the exact class of IA/RBAC defect where a department menu exposes
    # dead, forbidden or duplicated workspace links to a role that should not see them.
    with TestClient(app) as client:
        for email in INTERNAL_USERS:
            login(client, email)
            shell = client.get("/organization")
            assert shell.status_code == 200, email
            soup = BeautifulSoup(shell.text, "html.parser")
            hrefs = []
            for a in soup.select("aside.sidebar a.side-link[href]"):
                href = a.get("href")
                if not href or href.startswith("http"):
                    continue
                if href not in hrefs:
                    hrefs.append(href)
            assert hrefs, email
            for href in hrefs:
                parts = urlsplit(href)
                target = parts.path + (("?" + parts.query) if parts.query else "")
                response = client.get(target, follow_redirects=False)
                assert response.status_code not in {403, 404, 405, 500}, (email, target, response.status_code)
            client.post("/logout", follow_redirects=False)
