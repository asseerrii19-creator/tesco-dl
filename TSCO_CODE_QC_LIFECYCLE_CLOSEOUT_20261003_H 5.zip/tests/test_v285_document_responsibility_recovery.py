import hashlib
import json
from pathlib import Path
from fastapi.testclient import TestClient
from sqlalchemy import select, func
from app.main import app
from app.database import SessionLocal
from app.models import ControlledDocument, ImprovementItem, Notification, User
from app.services.document_catalog import SOURCE_DIR, install_reference_documents


def login(client, email):
    r=client.post('/login',data={'email':email,'password':'Demo123!'},follow_redirects=False)
    assert r.status_code==303,r.text


def test_original_documents_download_byte_for_byte_and_survive_restart():
    catalog=json.loads((SOURCE_DIR/'catalog.json').read_text())
    with TestClient(app) as client:
        login(client,'chemist@tsco.local')
        for row in catalog:
            r=client.get('/documents/by-code/'+row['code'])
            assert r.status_code==200, row['code']
            assert hashlib.sha256(r.content).hexdigest()==row['sha256']
        page=client.get('/documents',params={'workstation':'Water','method':'IEC 60814'})
        assert 'IEC-60814' in page.text and 'EOP-6-04-D' in page.text
        assert 'ASTM-D1816' not in page.text
        assert 'REFERENCE' in page.text
        with SessionLocal() as db:
            before=db.scalar(select(func.count()).select_from(ControlledDocument))
            assert install_reference_documents(db)==0
            assert db.scalar(select(func.count()).select_from(ControlledDocument))==before


def test_withdrawn_reference_is_not_reactivated_and_client_cannot_read_documents():
    with TestClient(app) as client:
        login(client,'chemist@tsco.local')
        with SessionLocal() as db:
            doc=db.scalar(select(ControlledDocument).where(ControlledDocument.code=='IEC-60836'))
            doc.status='WITHDRAWN';db.commit()
            assert install_reference_documents(db)==0
        assert client.get('/documents/by-code/IEC-60836').status_code==404
        with SessionLocal() as db:
            doc=db.scalar(select(ControlledDocument).where(ControlledDocument.code=='IEC-60836'));doc.status='REFERENCE';db.commit()
    with TestClient(app) as external:
        login(external, 'client@sec.local')
        assert external.get('/documents').status_code == 403
        assert external.get('/documents/by-code/IEC-60814').status_code == 403
    with TestClient(app) as anon:
        assert anon.get('/documents',follow_redirects=False).status_code==303


def test_senior_only_sees_assigned_register_and_assignment_notification():
    with TestClient(app) as client:
        with SessionLocal() as db:
            senior=db.scalar(select(User).where(User.email=='senior.improvement@tsco.local')); sid=senior.id
        login(client,'excellence@tsco.local')
        assert client.post('/improvement',data={'title':'Assigned recovery task 285','owner_id':str(sid)},follow_redirects=False).status_code==303
        assert client.post('/improvement',data={'title':'Department confidential task 285'},follow_redirects=False).status_code==303
        with SessionLocal() as db:
            own=db.scalar(select(ImprovementItem).where(ImprovementItem.title=='Assigned recovery task 285'));oid=own.id
            other=db.scalar(select(ImprovementItem).where(ImprovementItem.title=='Department confidential task 285'));otherid=other.id
            n=db.scalar(select(Notification).where(Notification.user_id==sid, Notification.target_url==f'/improvement?tab=register#item-{oid}'))
            assert n
        client.get('/logout');login(client,'senior.improvement@tsco.local')
        page=client.get('/improvement/responsibilities')
        assert page.status_code==200
        assert 'My Responsibilities' in page.text and 'Assigned recovery task 285' in page.text
        assert 'Department confidential task 285' not in page.text
        assert 'Continuous Improvement Workspace' not in page.text
        assert client.post(f'/improvement/{otherid}/update',data={'status':'CLOSED'},follow_redirects=False).status_code==403
        assert client.post(f'/improvement/{oid}/update',data={'status':'IN_PROGRESS','owner_id':str(sid)},follow_redirects=False).status_code==303
