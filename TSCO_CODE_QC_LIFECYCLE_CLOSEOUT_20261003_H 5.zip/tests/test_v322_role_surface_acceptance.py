from fastapi.testclient import TestClient
from html import unescape
from app.main import app


def login(c, email):
    r=c.post('/login',data={'email':email,'password':'Demo123!'},follow_redirects=False)
    assert r.status_code==303,(email,r.status_code,r.text[:200])


def logout(c):
    c.post('/logout',follow_redirects=False)


# 18 local business personas + the technical System Administrator surface.
SURFACES = {
    'general.manager@tsco.local': ('/management', ['Management Overview','Organization','My Leave & Availability','My Schedule & Overtime']),
    'excellence.specialist@tsco.local': ('/improvement', ['My Improvement Work','QC History','Validation / Verification','Audit & Findings','Troubleshooting']),
    'secretary@tsco.local': ('/gm-office', ['GM Office','Employee Directory','My Leave & Availability','My Schedule & Overtime']),
    'sales.marketing.specialist@tsco.local': ('/commercial', ['Communication Flow','Improvement Proposal','My Leave & Availability']),
    'salesman@tsco.local': ('/commercial', ['Communication Flow','Improvement Proposal','My Leave & Availability']),
    'field.manager@tsco.local': ('/operations', ['Operations Overview','Sampling Orders','Sampling Assignments','Field Progress','Employee Work History']),
    'sampling.supervisor@tsco.local': ('/sampling-supervision', ['Sampling Supervision','Field Progress','Controlled Documents','My Schedule & Overtime']),
    'data.entry@tsco.local': ('/intake', ['Data Entry Workspace','Sample Intake & Receiving','Transformer / Asset Structure','My Schedule & Overtime']),
    'sampleman@tsco.local': ('/field', ['My Field Work','Controlled Documents','My Leave & Availability','My Schedule & Overtime']),
    'client.coordinator@tsco.local': ('/commercial', ['Communication Flow','Improvement Proposal','My Leave & Availability']),
    'external.coordination@tsco.local': ('/commercial', ['Communication Flow','Improvement Proposal','My Leave & Availability']),
    'lab.manager@tsco.local': ('/management', ['Management Overview','Laboratory Operations Display','Quality / Governance','Employee Work History']),
    'senior.technical@tsco.local': ('/lab/operations?section=supervisor', ['My Technical Review','Technical Affairs','Troubleshooting','Housekeeping / Observations','Document Governance']),
    'senior.equipment@tsco.local': ('/lab/operations?section=supervisor', ['My Technical Review','Equipment & Maintenance','Troubleshooting','Housekeeping / Observations']),
    'senior.improvement@tsco.local': ('/lab/operations?section=supervisor', ['My Technical Review','Improvement Coordination','Troubleshooting','Housekeeping / Observations']),
    'chemist@tsco.local': ('/lab/operations?section=workstations', ['My Work','My Workstation','Methods / SOPs / EOPs / Quick Guides','Troubleshooting','Housekeeping / Observations','My QC / Validation Tasks']),
    'technician@tsco.local': ('/lab/operations?section=workstations', ['My Work','My Workstation','Methods / SOPs / EOPs / Quick Guides','Troubleshooting','Housekeeping / Observations','My QC / Validation Tasks']),
    'lab.support@tsco.local': ('/lab-support', ['Glassware & Housekeeping','My Housekeeping','My Leave & Availability','My Schedule & Overtime']),
    'admin@tsco.local': ('/admin', ['Platform Overview','Master Data Center','Users & Access','Controlled Documents','Audit Log']),
}


def test_all_19_final_role_surfaces_have_expected_navigation_and_valid_landings():
    assert len(SURFACES)==19
    with TestClient(app) as c:
        for email,(landing,labels) in SURFACES.items():
            login(c,email)
            root=c.get('/',follow_redirects=False)
            assert root.status_code==303 and root.headers.get('location')==landing,(email,root.status_code,root.headers.get('location'),landing)
            page=c.get(landing,follow_redirects=True)
            assert page.status_code==200,(email,landing,page.status_code,page.text[:300])
            rendered=unescape(page.text)
            for label in labels:
                assert label in rendered,(email,label)
            logout(c)


def test_critical_cross_role_boundaries_remain_closed():
    with TestClient(app) as c:
        # Data Entry cannot cross into controlled analytical knowledge/troubleshooting/result work.
        login(c,'data.entry@tsco.local')
        assert c.get('/documents',follow_redirects=False).status_code==403
        assert c.get('/troubleshooting',follow_redirects=False).status_code==403
        logout(c)

        # Secretary is an administrative GM-office role, not lab/commercial operations.
        login(c,'secretary@tsco.local')
        for path in ['/intake','/lab/operations?section=workstations','/quality','/commercial','/troubleshooting']:
            assert c.get(path,follow_redirects=False).status_code==403,(path,c.get(path,follow_redirects=False).status_code)
        logout(c)

        # Analyst roles cannot enter management/admin surfaces.
        login(c,'chemist@tsco.local')
        assert c.get('/management',follow_redirects=False).status_code==403
        assert c.get('/admin',follow_redirects=False).status_code==403
        logout(c)

        # Glassware support cannot enter analytical or management workspaces.
        login(c,'lab.support@tsco.local')
        assert c.get('/lab/operations?section=workstations',follow_redirects=False).status_code==403
        assert c.get('/management',follow_redirects=False).status_code==403
