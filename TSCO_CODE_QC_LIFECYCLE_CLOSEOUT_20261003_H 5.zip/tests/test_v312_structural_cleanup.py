from pathlib import Path

from fastapi.testclient import TestClient

from app.main import app
from app.role_matrix import ROLE_REVIEW_MATRIX
from app.models import Role


def login(client, email, password="Demo123!"):
    response = client.post("/login", data={"email": email, "password": password}, follow_redirects=False)
    assert response.status_code == 303, response.text


def _side_nav(html: str) -> str:
    start = html.index('<nav class="side-nav">')
    end = html.index('</nav>', start)
    return html[start:end]


def test_chemist_gets_my_work_and_my_workstation_without_display_or_duplicate_documents():
    with TestClient(app) as client:
        login(client, "chemist@tsco.local")
        page = client.get("/lab")
        assert page.status_code == 200
        assert "My Work" in page.text
        nav = _side_nav(page.text)
        assert nav.count(">My Work<") == 1
        assert nav.count("My Workstation") == 1
        assert "Laboratory Operations Display" not in nav
        assert "Methods / SOPs / EOPs / Quick Guides" in nav
        assert 'href="/documents"' not in nav


def test_intake_is_one_operations_owned_workspace_with_nested_stages():
    with TestClient(app) as client:
        login(client, "intake@tsco.local")
        page = client.get("/intake?view=incoming")
        assert page.status_code == 200
        nav = _side_nav(page.text)
        for label in ("Incoming &amp; Verification", "Physical Receiving", "Batch &amp; Distribution", "Released to Laboratory"):
            assert label in nav
        assert "Sample Intake & Receiving" in nav


def test_tv_display_is_independent_and_restricted_to_technical_management_or_admin():
    with TestClient(app) as client:
        login(client, "technical@tsco.local")
        allowed = client.get("/lab/display")
        assert allowed.status_code == 200
        assert "READ-ONLY · MANAGEMENT / TV VIEW" in allowed.text
        assert "/lab/operations/app?embed=1&amp;section=labprogress" in allowed.text or "/lab/operations/app?embed=1&section=labprogress" in allowed.text
    with TestClient(app) as client:
        login(client, "senior@tsco.local")
        assert client.get("/lab/display").status_code == 403
    with TestClient(app) as client:
        login(client, "chemist@tsco.local")
        assert client.get("/lab/display").status_code == 403


def test_organization_uses_source_chart_and_separates_org_from_system_access():
    with TestClient(app) as client:
        login(client, "operations@tsco.local")
        page = client.get("/organization")
        assert page.status_code == 200
        for phrase in ("Organization", "System access model", "Workspace", "Permissions", "Dammam & Bahrain Labs", "DATA ENTRY", "Ahmed Al Qahtani"):
            assert phrase in page.text
        assert "OPERATIONS DEPARTMENT" not in page.text
        assert "Quality Department" not in page.text
        assert "Continuous Improvement Department" not in page.text


def test_role_matrix_no_longer_treats_tv_as_senior_workspace_and_makes_chemist_work_split_explicit():
    senior = ROLE_REVIEW_MATRIX[Role.SENIOR_CHEMIST.value]
    chemist = ROLE_REVIEW_MATRIX[Role.LAB_TECHNICIAN.value]
    data_entry = ROLE_REVIEW_MATRIX[Role.DATA_ENTRY.value]
    assert senior["department"] == "Dammam & Bahrain Labs · Laboratory Operations"
    assert "Laboratory Progress" not in senior["primary"]
    assert "My Work" in chemist["primary"] and "My Workstation" in chemist["primary"]
    assert data_entry["department"] == "Dammam & Bahrain Labs"


def test_workstation_grouping_keeps_established_relationships_and_passivator_out_of_dbds_reporting_group():
    root = Path(__file__).resolve().parents[1]
    source = (root / "app/lab_ops/index_template.html").read_text()
    assert "'Furan / Passivator':['furan','passivator']" in source
    assert "'DBDS / BHT / Toluene / PCB':['dbds','bht-toluene','pcb']" in source
    assert "'Electrical':['bdv','pf']" in source
    assert "'TAN / Peroxide / RSH / H2S':['tan']" in source
    assert "if(/2-furfural|furan|passivator|irgamet|tta|bta|indirect dp|paper lifetime/.test(n))return'Furan / Passivator / Paper Ageing'" in source
    assert "if(/dbds|bht|toluene|pcb/.test(n))return'DBDS / BHT / Toluene / PCB'" in source
    assert "dbds|bht|toluene|passivator|pcb" not in source


def test_general_lab_settings_no_longer_duplicate_user_or_document_crud():
    root = Path(__file__).resolve().parents[1]
    source = (root / "app/lab_ops/index_template.html").read_text()
    assert "Add Staff" not in source
    assert "SAVE NEW REVISION" not in source
    assert "Laboratory Roles" in source
    assert "Read-only laboratory reference" in source
    assert "Laboratory Staff" not in source


def test_public_gallery_is_optional_compressed_folder_not_a_dead_placeholder_grid():
    root = Path(__file__).resolve().parents[1]
    auth = (root / "app/routes/auth.py").read_text()
    readme = (root / "app/static/lab-gallery/README.txt").read_text()
    assert 'static" / "lab-gallery"' in auth
    assert "lazy-loaded thumbnails" in readme
    with TestClient(app) as client:
        page = client.get("/welcome")
        assert page.status_code == 200
        assert "compressed thumbnails" in page.text
        assert "lab-photo-slot" not in page.text
