from datetime import datetime

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import CompetencyRecord, StaffAvailability, StaffWorkPattern, User
from app.services.daily_brief import build_daily_brief, deliver_daily_brief


def login(client: TestClient, email: str, password: str = 'Demo123!'):
    response = client.post('/login', data={'email': email, 'password': password}, follow_redirects=False)
    assert response.status_code == 303, response.text


def logout(client: TestClient):
    client.post('/logout', follow_redirects=False)


def test_every_internal_employee_can_see_read_only_organization_and_client_cannot():
    internal = [
        'fieldman@tsco.local', 'supervisor@tsco.local', 'operations@tsco.local',
        'intake@tsco.local', 'receiving@tsco.local', 'chemist@tsco.local',
        'senior@tsco.local', 'quality@tsco.local', 'technical@tsco.local',
        'manager@tsco.local', 'sales@tsco.local', 'finance@tsco.local',
        'excellence@tsco.local', 'admin@tsco.local',
    ]
    with TestClient(app) as client:
        for email in internal:
            login(client, email)
            page = client.get('/organization')
            assert page.status_code == 200, email
            assert 'Organization &amp; System Roles' in page.text or 'Organization & System Roles' in page.text
            logout(client)
        login(client, 'client@sec.local')
        blocked = client.get('/organization')
        assert blocked.status_code == 403


def test_daily_operational_brief_is_bound_to_login_email_and_has_required_sections(monkeypatch):
    monkeypatch.delenv('SMTP_HOST', raising=False)
    monkeypatch.delenv('SMTP_FROM', raising=False)
    with TestClient(app) as client:
        login(client, 'chemist@tsco.local')
        page = client.get('/control/daily-brief')
        assert page.status_code == 200
        assert 'chemist@tsco.local' in page.text
        for text in ['Yesterday', 'Today', 'QC / routine duties due', 'Carry-over', 'Night-to-morning handover']:
            assert text in page.text
    with SessionLocal() as db:
        user = db.scalar(select(User).where(User.email == 'chemist@tsco.local'))
        brief = build_daily_brief(db, user, now=datetime(2026, 9, 15, 8, 0))
        assert brief['recipient_email'] == user.email
        assert deliver_daily_brief(brief).status == 'PENDING_CONFIGURATION'


def test_daily_operational_brief_is_internal_only():
    with TestClient(app) as client:
        login(client, 'client@sec.local')
        response = client.get('/control/daily-brief')
        assert response.status_code == 403


def test_commercial_role_is_presented_as_coordinator_without_laboratory_authority():
    with TestClient(app) as client:
        login(client, 'sales@tsco.local')
        page = client.get('/organization')
        assert page.status_code == 200
        assert 'CLIENT ACCOUNT &amp; COORDINATION OFFICER' in page.text or 'CLIENT ACCOUNT & COORDINATION OFFICER' in page.text
        lab = client.get('/lab/operations?section=workstations', follow_redirects=False)
        assert lab.status_code == 403


def test_night_roster_generation_is_planned_then_separately_approved_by_senior():
    month = '2027-02'
    with SessionLocal() as db:
        chemists = db.scalars(select(User).where(User.email.in_(['chemist@tsco.local', 'chemist2@tsco.local']))).all()
        assert len(chemists) == 2
        site_id = chemists[0].site_id
        db.query(StaffAvailability).filter(
            StaffAvailability.site_id == site_id,
            StaffAvailability.shift_code.like('NIGHT / AUTO-ROSTER%'),
            StaffAvailability.start_at >= datetime(2027, 2, 1),
            StaffAvailability.start_at < datetime(2027, 3, 1),
        ).delete(synchronize_session=False)
        for chemist in chemists:
            existing = db.scalar(select(StaffWorkPattern).where(StaffWorkPattern.site_id == site_id, StaffWorkPattern.user_id == chemist.id))
            if existing:
                existing.weekdays_json = '[0,1,2,3,4,5,6]'; existing.active = True
            else:
                db.add(StaffWorkPattern(site_id=site_id, user_id=chemist.id, name='All days test pattern', weekdays_json='[0,1,2,3,4,5,6]', shift_start='08:00', shift_end='16:00', active=True, created_by_id=chemist.id))
            db.add(CompetencyRecord(site_id=site_id, user_id=chemist.id, test_name='Night roster eligibility test', workstation='General Night Coverage', category=1, authorization='INDEPENDENT', active=True))
        db.commit()

    with TestClient(app) as client:
        login(client, 'senior@tsco.local')
        generated = client.post('/control/schedule/generate-night', data={'month': month, 'people_per_day': '2'}, follow_redirects=False)
        assert generated.status_code == 303, generated.text
        with SessionLocal() as db:
            rows = db.scalars(select(StaffAvailability).where(StaffAvailability.shift_code == 'NIGHT / AUTO-ROSTER', StaffAvailability.start_at >= datetime(2027, 2, 1), StaffAvailability.start_at < datetime(2027, 3, 1))).all()
            assert rows and all(row.status == 'PLANNED' and row.approved_by_id is None for row in rows)
        approved = client.post('/control/schedule/approve-night', data={'month': month}, follow_redirects=False)
        assert approved.status_code == 303, approved.text
        with SessionLocal() as db:
            rows = db.scalars(select(StaffAvailability).where(StaffAvailability.shift_code == 'NIGHT / AUTO-ROSTER', StaffAvailability.start_at >= datetime(2027, 2, 1), StaffAvailability.start_at < datetime(2027, 3, 1))).all()
            assert rows and all(row.status == 'APPROVED' and row.approved_by_id is not None for row in rows)
            for row in rows:
                db.delete(row)
            db.query(CompetencyRecord).filter(CompetencyRecord.site_id == rows[0].site_id, CompetencyRecord.test_name == 'Night roster eligibility test').delete(synchronize_session=False)
            db.commit()
