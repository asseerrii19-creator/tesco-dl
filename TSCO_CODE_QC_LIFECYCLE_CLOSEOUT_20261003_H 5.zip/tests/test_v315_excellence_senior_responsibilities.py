from fastapi.testclient import TestClient
from html import unescape
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import EquipmentAsset, QualityCase, User
from app.responsibilities import senior_responsibility


def login(client, email, password="Demo123!"):
    r = client.post("/login", data={"email": email, "password": password}, follow_redirects=False)
    assert r.status_code == 303, r.text


def test_named_senior_responsibility_mapping_is_fixed_on_real_accounts():
    expected = {
        "mohammed.alyahya@tsco.local": "TECHNICAL",
        "tara.alghamdi@tsco.local": "EQUIPMENT",
        "reem.alotaibi@tsco.local": "IMPROVEMENT",
    }
    with TestClient(app):
        with SessionLocal() as db:
            for email, domain in expected.items():
                user = db.scalar(select(User).where(User.email == email))
                assert user is not None
                assert user.senior_responsibility_domain == domain
                assert senior_responsibility(user) == domain


def test_excellence_has_governance_sections_without_becoming_quality_department():
    with TestClient(app) as client:
        login(client, "ohood.alhareeqi@tsco.local")
        for tab, label in [
            ("qc", "QC History"),
            ("equipment", "Equipment / Calibration History"),
            ("validation", "Validation / Verification"),
            ("audit", "Audit & Findings"),
            ("evidence", "Controlled Quality Evidence"),
        ]:
            r = client.get(f"/quality?tab={tab}")
            assert r.status_code == 200, (tab, r.text)
            assert "Excellence Oversight" in r.text
            assert label in r.text
        nav = client.get("/improvement").text
        assert "Excellence Oversight" in nav
        assert "Quality Department" not in nav


def test_excellence_can_create_validation_and_audit_but_not_equipment_maintenance_event():
    with TestClient(app) as client:
        login(client, "ohood.alhareeqi@tsco.local")
        r = client.post("/control/case", data={
            "case_type": "VALIDATION", "title": "KF method validation review",
            "test_name": "Water Content", "method_name": "IEC 60814",
            "equipment_asset_id": "", "assigned_to_id": "", "priority": "NORMAL",
            "due_at": "", "scheme_name": "", "evaluation_criteria": "Repeatability and evidence review",
        }, follow_redirects=False)
        assert r.status_code == 303
        assert r.headers["location"] == "/quality?tab=validation"
        r = client.post("/control/case", data={
            "case_type": "AUDIT", "title": "Internal workflow audit",
            "test_name": "Laboratory workflow", "method_name": "",
            "equipment_asset_id": "", "assigned_to_id": "", "priority": "NORMAL",
            "due_at": "", "scheme_name": "", "evaluation_criteria": "Traceability and action closure",
        }, follow_redirects=False)
        assert r.status_code == 303
        assert r.headers["location"] == "/quality?tab=audit"
        with SessionLocal() as db:
            assert db.scalar(select(QualityCase).where(QualityCase.case_type == "VALIDATION", QualityCase.title == "KF method validation review"))
            assert db.scalar(select(QualityCase).where(QualityCase.case_type == "AUDIT", QualityCase.title == "Internal workflow audit"))
            eq = db.scalar(select(EquipmentAsset).order_by(EquipmentAsset.id))
            assert eq
            eid = eq.id
        denied = client.post(f"/control/equipment/{eid}/event", data={
            "event_type": "MAINTENANCE", "result": "PASS", "details": "Must remain Equipment Senior execution", "next_due_at": ""
        }, follow_redirects=False)
        assert denied.status_code == 403


def test_each_real_senior_gets_own_responsibility_section_and_scope():
    cases = [
        ("mohammed.alyahya@tsco.local", "Technical Affairs", "TECHNICAL", "Technical Affairs"),
        ("tara.alghamdi@tsco.local", "Equipment · Maintenance · Calibration Follow-up", "EQUIPMENT", "Equipment & Maintenance"),
        ("reem.alotaibi@tsco.local", "Improvement Coordination", "IMPROVEMENT", "Improvement Coordination"),
    ]
    with TestClient(app) as client:
        for email, label, domain, nav_label in cases:
            login(client, email)
            r = client.get("/improvement/responsibilities")
            assert r.status_code == 200, (email, r.text)
            assert label in r.text
            assert domain in r.text
            home = client.get("/lab/operations?section=supervisor")
            assert home.status_code == 200
            assert nav_label in unescape(home.text)
            client.post("/logout")


def test_equipment_senior_has_equipment_control_and_improvement_senior_has_read_only_coordination_views():
    with TestClient(app) as client:
        login(client, "tara.alghamdi@tsco.local")
        eq_page = client.get("/quality?tab=equipment")
        assert eq_page.status_code == 200
        assert "Record event" in eq_page.text
        client.post("/logout")

        login(client, "reem.alotaibi@tsco.local")
        validation = client.get("/quality?tab=validation")
        assert validation.status_code == 200
        assert "Improvement Coordination" in validation.text
        assert "Create controlled case" not in validation.text
        audit = client.get("/quality?tab=audit")
        assert audit.status_code == 200
        assert "Create Audit Record" not in audit.text
