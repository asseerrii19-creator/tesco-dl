from __future__ import annotations

import json
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import Asset, Client, CommercialCase, CommercialRequestLine, PurchaseOrder, Quotation, SamplePhoto, SampleRequest, Site


def _login(browser: TestClient, email: str) -> None:
    r = browser.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303


def _scope_with_two_assets(db):
    site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
    client = db.scalar(select(Client).where(Client.code == 'SEC')); assert client
    first = db.scalar(select(Asset).where(Asset.client_id == client.id).order_by(Asset.id)); assert first
    token = uuid4().hex[:8].upper()
    second = Asset(
        client_id=client.id, asset_code=f'V330-{token}', serial_number=f'SN-V330-{token}',
        equipment_type='Transformer', station_name=first.station_name or 'Demo Plant',
        asset_location_label=first.asset_location_label or 'Demo Plant / Bay B', active=True,
    )
    db.add(second); db.flush()
    quote = Quotation(client_id=client.id, number=f'QT-V330-{token}', status='ACTIVE', description='Serial matching UAT')
    db.add(quote); db.flush()
    po = PurchaseOrder(client_id=client.id, quotation_id=quote.id, number=f'PO-V330-{token}', status='ACTIVE')
    db.add(po); db.flush()
    case = CommercialCase(
        case_code=f'BC-DMM-2026-{token}', site_id=site.id, client_id=client.id,
        quotation_id=quote.id, purchase_order_id=po.id, current_stage='COMPLETE_HANDOVER', status='ACTIVE',
        lead_title='Serial matching UAT', handover_commercial='Approved quote / PO',
        handover_technical='Routine transformer oil testing', handover_client_info='Direct delivery',
        expected_samples=2, requested_test_package='Routine Test', default_priority='NORMAL', required_tat='',
    )
    db.add(case); db.flush()
    line = CommercialRequestLine(
        commercial_case_id=case.id, line_number=1, quantity=2, requested_package='Routine Test',
        requested_tests_json='[]', expected_serials_json=json.dumps([first.serial_number, second.serial_number]),
        method_family='IEC', priority='NORMAL', required_tat='', status='ACTIVE',
    )
    db.add(line); db.commit()
    return site, client, first, second, quote, po, case, line


def test_client_request_can_store_optional_transformer_serials_before_arrival():
    with TestClient(app) as browser:
        _login(browser, 'client@sec.local')
        r = browser.post('/client/requests', data={'lead_title': 'Known transformer serials', 'client_message': ''}, follow_redirects=False)
        assert r.status_code == 303
        case_id = int(r.headers['location'].rstrip('/').split('/')[-1])
        r = browser.post(f'/client/requests/{case_id}/lines', data={
            'quantity': 2, 'requested_package': 'Routine Test', 'method_family': 'IEC',
            'priority': 'NORMAL', 'required_tat': '', 'due_at': '',
            'expected_serials': 'TX-SERIAL-A\nTX-SERIAL-B',
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            line = db.scalar(select(CommercialRequestLine).where(CommercialRequestLine.commercial_case_id == case_id)); assert line
            assert json.loads(line.expected_serials_json) == ['TX-SERIAL-A', 'TX-SERIAL-B']


def test_data_entry_expected_arrival_serial_matching_and_data_form_scan():
    with TestClient(app) as browser:
        with SessionLocal() as db:
            _, client, first, second, quote, po, case, line = _scope_with_two_assets(db)
            client_id, quote_id, po_id, case_id, line_id = client.id, quote.id, po.id, case.id, line.id
            serials = [first.serial_number, second.serial_number]
        _login(browser, 'data.entry@tsco.local')

        page = browser.get('/intake?view=incoming')
        assert page.status_code == 200
        assert 'EXPECTED ARRIVALS' in page.text
        assert serials[0] in page.text and serials[1] in page.text
        assert 'Open Intake' in page.text

        lookup = browser.get(f'/intake/asset-match/lookup?serial_number={serials[0]}&client_id={client_id}')
        assert lookup.status_code == 200
        assert lookup.json()['matched'] is True
        assert lookup.json()['serial_number'] == serials[0]

        r = browser.post('/intake/direct', data={
            'client_id': client_id, 'asset_id': '', 'quotation_id': quote_id, 'purchase_order_id': po_id,
            'commercial_request_line_id': line_id, 'serial_numbers': '\n'.join(serials),
            'requested_package': 'Routine Test', 'sampling_point': 'Main Tank - Bottom', 'sample_count': 1,
            'container_count': 1, 'client_sample_reference': 'DATAFORM-V330', 'priority': 'NORMAL', 'required_tat': '',
        }, files={'submission_document': ('data-form.pdf', b'%PDF-1.4\n% controlled demo', 'application/pdf')}, follow_redirects=False)
        assert r.status_code == 303 and 'created=2' in r.headers['location']

        with SessionLocal() as db:
            rows = list(db.scalars(select(SampleRequest).where(SampleRequest.commercial_case_id == case_id).order_by(SampleRequest.id)).all())
            assert len(rows) == 2
            assert [row.asset.serial_number for row in rows] == serials
            assert all(row.commercial_request_line_id == line_id for row in rows)
            assert all(row.requested_method_family == 'IEC' for row in rows)
            assert all(db.scalar(select(SamplePhoto.id).where(SamplePhoto.sample_request_id == row.id, SamplePhoto.kind == 'CLIENT_SUBMISSION_DOCUMENT')) for row in rows)
            first_sample_id = rows[0].id
            first_asset_id = rows[0].asset_id

        search = browser.get(f'/intake?view=all&q={serials[0]}')
        assert search.status_code == 200 and serials[0] in search.text
        assets = browser.get(f'/intake?view=assets&q={serials[0]}')
        assert assets.status_code == 200 and 'Asset / Serial Register' in assets.text and serials[0] in assets.text
        detail = browser.get(f'/intake/assets/{first_asset_id}')
        assert detail.status_code == 200 and 'Transformer / Asset Data' in detail.text and serials[0] in detail.text
        sample = browser.get(f'/intake/{first_sample_id}')
        assert sample.status_code == 200 and 'Open full transformer record' in sample.text


def test_serial_not_in_explicit_request_scope_is_rejected():
    with TestClient(app) as browser:
        with SessionLocal() as db:
            _, client, first, second, quote, po, _, line = _scope_with_two_assets(db)
            bad = Asset(client_id=client.id, asset_code=f'BAD-{uuid4().hex[:6]}', serial_number=f'BAD-SN-{uuid4().hex[:8]}', equipment_type='Transformer', active=True)
            db.add(bad); db.commit(); bad_serial = bad.serial_number
            ids = (client.id, quote.id, po.id, line.id)
        _login(browser, 'data.entry@tsco.local')
        r = browser.post('/intake/direct', data={
            'client_id': ids[0], 'asset_id': '', 'quotation_id': ids[1], 'purchase_order_id': ids[2],
            'commercial_request_line_id': ids[3], 'serial_numbers': bad_serial,
            'requested_package': 'Routine Test', 'sampling_point': 'Main Tank - Bottom', 'sample_count': 1,
            'container_count': 1, 'priority': 'NORMAL', 'required_tat': '',
        }, follow_redirects=False)
        assert r.status_code == 400
        assert 'not listed in the selected Client Request Scope' in r.text
