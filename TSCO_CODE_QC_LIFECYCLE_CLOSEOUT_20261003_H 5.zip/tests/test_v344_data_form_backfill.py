from __future__ import annotations

import hashlib
from datetime import datetime
from pathlib import Path
from uuid import uuid4

from sqlalchemy import select

from app.database import SessionLocal
from app.models import Asset, Client, CommercialAttachment, CommercialCase, SampleRequest, Site
from app.services.client_data_form import sync_missing_sample_metadata_from_case_data_form


def _uat_form_bytes() -> bytes:
    return (Path(__file__).resolve().parents[1] / 'app' / 'uat_fixtures' / 'TSCO_UAT_Client_Data_Form_BC-DMM-2026-0003.pdf').read_bytes()


def test_backfill_repairs_existing_testing_sample_without_overwriting_existing_intake_values():
    token = uuid4().hex[:8].upper()
    raw = _uat_form_bytes()
    with SessionLocal() as db:
        site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
        client = db.scalar(select(Client).where(Client.code == 'SEC')); assert client
        case = CommercialCase(
            case_code=f'BC-DMM-V344-{token}', site_id=site.id, client_id=client.id,
            current_stage='COMPLETE_HANDOVER', status='ACTIVE', lead_title='v3.4.4 metadata backfill',
            handover_commercial='Approved', handover_technical='Routine Test', handover_client_info='Direct delivery',
            expected_samples=1, requested_test_package='Routine Test', default_priority='URGENT', required_tat='24H',
            sample_delivery_mode='CLIENT_DELIVERY', sample_delivery_notes='Dammam West Substation',
        )
        db.add(case); db.flush()
        attachment = CommercialAttachment(
            commercial_case_id=case.id, document_type='CLIENT_DATA_FORM',
            original_name='TSCO_UAT_Client_Data_Form_BC-DMM-2026-0003.pdf', stored_path='/missing/on-purpose.pdf',
            content_type='application/pdf', sha256=hashlib.sha256(raw).hexdigest(), content_blob=raw,
        )
        db.add(attachment); db.flush()
        asset = Asset(
            client_id=client.id, asset_code=f'SEC-V344-{token}', serial_number='UAT-SEC-TR-001',
            equipment_type='Power Transformer', station_name='Dammam West Substation', asset_location_label='Dammam West Substation', active=True,
        )
        db.add(asset); db.flush()
        sample = SampleRequest(
            request_number=f'FS-V344-{token}', public_token=f'pub-{token}', barcode_value=f'bc-{token}', status='TESTING',
            site_id=site.id, client_id=client.id, commercial_case_id=case.id, asset_id=asset.id,
            submission_channel='CLIENT_DELIVERED', sample_date_time=datetime(2026,10,1,17,50), sampling_point='Bottom',
            requested_package='Routine Test', requested_method_family='DEFAULT', requested_tests_json='[]',
            sample_origin='Client-Originated / Direct Delivery', priority='URGENT', required_tat='24H',
            oil_temperature_c=None, ambient_temperature_c=None, ambient_humidity_pct=None,
        )
        db.add(sample); db.commit()
        sample_id = sample.id
        case_id = case.id

        changed = sync_missing_sample_metadata_from_case_data_form(db, case_id)
        assert changed == 1
        repaired = db.get(SampleRequest, sample_id)
        assert repaired.oil_temperature_c == 48.0
        assert repaired.ambient_temperature_c == 36.0
        assert repaired.ambient_humidity_pct == 45.0
        # Non-destructive: preserve the already-recorded intake point rather than overwriting it.
        assert repaired.sampling_point == 'Bottom'
        assert repaired.asset.tag_number == 'UAT-TAG-001'
        assert repaired.asset.manufacturer == 'WESCOSA'
