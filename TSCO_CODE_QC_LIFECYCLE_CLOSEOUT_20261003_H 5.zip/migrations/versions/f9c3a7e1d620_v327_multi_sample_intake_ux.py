"""v3.2.7 multi-sample intake and structured handover scope

Revision ID: f9c3a7e1d620
Revises: e7a4c2d9138f
"""
from alembic import op
import sqlalchemy as sa

revision = "f9c3a7e1d620"
down_revision = "e7a4c2d9138f"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("commercial_cases") as batch:
        batch.add_column(sa.Column("expected_samples", sa.Integer(), nullable=True))
        batch.add_column(sa.Column("requested_test_package", sa.String(length=160), nullable=False, server_default=""))
        batch.add_column(sa.Column("default_priority", sa.String(length=20), nullable=False, server_default="NORMAL"))
        batch.add_column(sa.Column("required_tat", sa.String(length=40), nullable=False, server_default=""))


def downgrade() -> None:
    with op.batch_alter_table("commercial_cases") as batch:
        batch.drop_column("required_tat")
        batch.drop_column("default_priority")
        batch.drop_column("requested_test_package")
        batch.drop_column("expected_samples")
