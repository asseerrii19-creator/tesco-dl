"""v3.4.3 attachment durability hotfix

Revision ID: c43a7d9e2f10
Revises: b17f4c8d9e20
Create Date: 2026-10-01
"""
from alembic import op
import sqlalchemy as sa

revision = "c43a7d9e2f10"
down_revision = "b17f4c8d9e20"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("commercial_attachments", sa.Column("content_blob", sa.LargeBinary(), nullable=True))


def downgrade() -> None:
    op.drop_column("commercial_attachments", "content_blob")
