"""v3.3.1 client request sample logistics and expected arrival

Revision ID: a62f1d9e4c71
Revises: d31e7a9c4b20
"""
from alembic import op
import sqlalchemy as sa

revision = "a62f1d9e4c71"
down_revision = "d31e7a9c4b20"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("commercial_cases") as batch:
        batch.add_column(sa.Column("expected_arrival_at", sa.DateTime(), nullable=True))
        batch.add_column(sa.Column("sample_delivery_mode", sa.String(length=30), nullable=False, server_default="TBD"))
        batch.add_column(sa.Column("sample_delivery_notes", sa.Text(), nullable=False, server_default=""))


def downgrade() -> None:
    with op.batch_alter_table("commercial_cases") as batch:
        batch.drop_column("sample_delivery_notes")
        batch.drop_column("sample_delivery_mode")
        batch.drop_column("expected_arrival_at")
