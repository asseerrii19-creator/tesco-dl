"""final consolidated closeout controls

Revision ID: a7c3e9f4b210
Revises: f52d7c9a6b11
"""
from alembic import op
import sqlalchemy as sa

revision = "a7c3e9f4b210"
down_revision = "f52d7c9a6b11"
branch_labels = None
depends_on = None


def upgrade():
    # v3.2.0 organization closeout: parent-company/shared-service review identities are
    # not local TSCO employee personas. Preserve rows for historical FK integrity but
    # deactivate the old seeded logins during an in-place upgrade.
    bind = op.get_bind()
    bind.execute(sa.text(
        "UPDATE users SET active = :inactive WHERE lower(email) IN "
        "('hr@tsco.local','qhse@tsco.local','quality@tsco.local','legal@tsco.local',"
        "'procurement@tsco.local','finance@tsco.local','it@tsco.local','erb@tsco.local')"
    ), {"inactive": False})
    op.create_table(
        "operational_projects",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("project_reference", sa.String(80), nullable=False),
        sa.Column("project_name", sa.String(220), nullable=False),
        sa.Column("site_id", sa.Integer(), sa.ForeignKey("sites.id"), nullable=False),
        sa.Column("client_id", sa.Integer(), sa.ForeignKey("clients.id"), nullable=False),
        sa.Column("commercial_case_id", sa.Integer(), nullable=True),
        sa.Column("created_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("approved_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("project_type", sa.String(80), nullable=False, server_default="GENERAL"),
        sa.Column("scope", sa.Text(), nullable=False, server_default=""),
        sa.Column("location_scope", sa.String(220), nullable=False, server_default=""),
        sa.Column("planned_start_at", sa.DateTime(), nullable=True),
        sa.Column("planned_end_at", sa.DateTime(), nullable=True),
        sa.Column("field_scope", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("laboratory_scope", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("expected_samples", sa.Integer(), nullable=True),
        sa.Column("test_package", sa.String(160), nullable=False, server_default=""),
        sa.Column("special_tat", sa.String(80), nullable=False, server_default=""),
        sa.Column("status", sa.String(40), nullable=False, server_default="DRAFT"),
        sa.Column("supporting_notes", sa.Text(), nullable=False, server_default=""),
        sa.Column("submitted_at", sa.DateTime(), nullable=True),
        sa.Column("approved_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("project_reference", name="uq_operational_project_reference"),
    )
    op.create_index("ix_operational_projects_project_reference", "operational_projects", ["project_reference"])
    op.create_index("ix_operational_projects_project_name", "operational_projects", ["project_name"])
    op.create_index("ix_operational_projects_site_id", "operational_projects", ["site_id"])
    op.create_index("ix_operational_projects_client_id", "operational_projects", ["client_id"])
    op.create_index("ix_operational_projects_commercial_case_id", "operational_projects", ["commercial_case_id"])
    op.create_index("ix_operational_projects_status", "operational_projects", ["status"])

    with op.batch_alter_table("commercial_cases") as batch:
        batch.add_column(sa.Column("assigned_coordinator_id", sa.Integer(), nullable=True))
        batch.add_column(sa.Column("operational_project_id", sa.Integer(), nullable=True))
        batch.add_column(sa.Column("corporate_admin_status", sa.String(60), nullable=False, server_default=""))
        batch.create_index("ix_commercial_cases_assigned_coordinator_id", ["assigned_coordinator_id"], unique=False)
        batch.create_index("ix_commercial_cases_operational_project_id", ["operational_project_id"], unique=False)
        batch.create_foreign_key("fk_commercial_cases_assigned_coordinator_users", "users", ["assigned_coordinator_id"], ["id"])
        batch.create_foreign_key("fk_commercial_cases_operational_project", "operational_projects", ["operational_project_id"], ["id"])
    with op.batch_alter_table("operational_projects") as batch:
        batch.create_foreign_key("fk_operational_project_commercial_case", "commercial_cases", ["commercial_case_id"], ["id"])

    with op.batch_alter_table("sampling_orders") as batch:
        batch.add_column(sa.Column("operational_project_id", sa.Integer(), nullable=True))
        batch.create_index("ix_sampling_orders_operational_project_id", ["operational_project_id"], unique=False)
        batch.create_foreign_key("fk_sampling_orders_operational_project", "operational_projects", ["operational_project_id"], ["id"])
    with op.batch_alter_table("sampling_assignments") as batch:
        batch.add_column(sa.Column("task_type", sa.String(40), nullable=False, server_default="ON_SITE_SAMPLING"))
        batch.create_index("ix_sampling_assignments_task_type", ["task_type"], unique=False)

    with op.batch_alter_table("controlled_documents") as batch:
        batch.add_column(sa.Column("technical_reviewed_by_id", sa.Integer(), nullable=True))
        batch.add_column(sa.Column("manager_approved_by_id", sa.Integer(), nullable=True))
        batch.add_column(sa.Column("technical_reviewed_at", sa.DateTime(), nullable=True))
        batch.add_column(sa.Column("manager_approved_at", sa.DateTime(), nullable=True))
        batch.create_foreign_key("fk_controlled_documents_technical_reviewer", "users", ["technical_reviewed_by_id"], ["id"])
        batch.create_foreign_key("fk_controlled_documents_manager_approver", "users", ["manager_approved_by_id"], ["id"])

    with op.batch_alter_table("quality_cases") as batch:
        batch.add_column(sa.Column("method_document_id", sa.Integer(), nullable=True))
        batch.add_column(sa.Column("sop_document_id", sa.Integer(), nullable=True))
        batch.add_column(sa.Column("review_conclusion", sa.String(40), nullable=False, server_default=""))
        batch.add_column(sa.Column("review_note", sa.Text(), nullable=False, server_default=""))
        batch.create_index("ix_quality_cases_method_document_id", ["method_document_id"], unique=False)
        batch.create_index("ix_quality_cases_sop_document_id", ["sop_document_id"], unique=False)
        batch.create_foreign_key("fk_quality_cases_method_document", "controlled_documents", ["method_document_id"], ["id"])
        batch.create_foreign_key("fk_quality_cases_sop_document", "controlled_documents", ["sop_document_id"], ["id"])

    op.create_table(
        "quality_execution_revisions",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("quality_case_id", sa.Integer(), sa.ForeignKey("quality_cases.id"), nullable=False),
        sa.Column("revision", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("raw_runs_json", sa.Text(), nullable=False, server_default="[]"),
        sa.Column("calculation_json", sa.Text(), nullable=False, server_default="{}"),
        sa.Column("evidence_reference", sa.String(240), nullable=False, server_default=""),
        sa.Column("submitted_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("submitted_at", sa.DateTime(), nullable=False),
        sa.Column("return_reason", sa.Text(), nullable=False, server_default=""),
        sa.UniqueConstraint("quality_case_id", "revision", name="uq_quality_execution_case_revision"),
    )
    op.create_index("ix_quality_execution_revisions_quality_case_id", "quality_execution_revisions", ["quality_case_id"])
    op.create_index("ix_quality_execution_revisions_submitted_by_id", "quality_execution_revisions", ["submitted_by_id"])
    op.create_index("ix_quality_execution_revisions_submitted_at", "quality_execution_revisions", ["submitted_at"])

    with op.batch_alter_table("troubleshooting_records") as batch:
        batch.add_column(sa.Column("responsible_domain", sa.String(30), nullable=False, server_default="TECHNICAL"))
        batch.add_column(sa.Column("resolution_summary", sa.Text(), nullable=False, server_default=""))
        batch.add_column(sa.Column("published_revision", sa.Integer(), nullable=False, server_default="0"))
        batch.create_index("ix_troubleshooting_records_responsible_domain", ["responsible_domain"], unique=False)

    op.create_table(
        "troubleshooting_notes",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("troubleshooting_record_id", sa.Integer(), sa.ForeignKey("troubleshooting_records.id"), nullable=False),
        sa.Column("author_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("note_type", sa.String(40), nullable=False, server_default="OBSERVATION"),
        sa.Column("note", sa.Text(), nullable=False),
        sa.Column("evidence_reference", sa.String(240), nullable=False, server_default=""),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_troubleshooting_notes_record", "troubleshooting_notes", ["troubleshooting_record_id"])
    op.create_index("ix_troubleshooting_notes_author", "troubleshooting_notes", ["author_id"])
    op.create_index("ix_troubleshooting_notes_created", "troubleshooting_notes", ["created_at"])

    op.create_table(
        "troubleshooting_resolution_revisions",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("troubleshooting_record_id", sa.Integer(), sa.ForeignKey("troubleshooting_records.id"), nullable=False),
        sa.Column("revision", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("resolution_text", sa.Text(), nullable=False),
        sa.Column("root_cause", sa.Text(), nullable=False, server_default=""),
        sa.Column("evidence_reference", sa.String(240), nullable=False, server_default=""),
        sa.Column("status", sa.String(30), nullable=False, server_default="PROPOSED"),
        sa.Column("created_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("reviewed_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("approved_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("effective_at", sa.DateTime(), nullable=True),
        sa.UniqueConstraint("troubleshooting_record_id", "revision", name="uq_troubleshooting_resolution_revision"),
    )
    op.create_index("ix_troubleshooting_resolution_record", "troubleshooting_resolution_revisions", ["troubleshooting_record_id"])
    op.create_index("ix_troubleshooting_resolution_status", "troubleshooting_resolution_revisions", ["status"])

    op.create_table(
        "external_technical_evidence",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("troubleshooting_record_id", sa.Integer(), sa.ForeignKey("troubleshooting_records.id"), nullable=False),
        sa.Column("verifier_name", sa.String(180), nullable=False),
        sa.Column("company", sa.String(180), nullable=False, server_default=""),
        sa.Column("contact", sa.String(180), nullable=False, server_default=""),
        sa.Column("verification_at", sa.DateTime(), nullable=True),
        sa.Column("reference", sa.String(180), nullable=False, server_default=""),
        sa.Column("conclusion", sa.Text(), nullable=False, server_default=""),
        sa.Column("evidence_reference", sa.String(240), nullable=False, server_default=""),
        sa.Column("recorded_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("reviewed_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_external_technical_evidence_record", "external_technical_evidence", ["troubleshooting_record_id"])

    with op.batch_alter_table("controlled_reports") as batch:
        batch.add_column(sa.Column("lms_status", sa.String(40), nullable=False, server_default="PENDING_LMS"))
        batch.add_column(sa.Column("approved_snapshot_json", sa.Text(), nullable=False, server_default="{}"))
        batch.add_column(sa.Column("supersedes_report_id", sa.Integer(), nullable=True))
        batch.add_column(sa.Column("amendment_reason", sa.Text(), nullable=False, server_default=""))
        batch.create_index("ix_controlled_reports_lms_status", ["lms_status"], unique=False)
        batch.create_index("ix_controlled_reports_supersedes_report_id", ["supersedes_report_id"], unique=False)
        batch.create_foreign_key("fk_controlled_reports_supersedes", "controlled_reports", ["supersedes_report_id"], ["id"])

    op.create_table(
        "report_submissions",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("controlled_report_id", sa.Integer(), sa.ForeignKey("controlled_reports.id"), nullable=False),
        sa.Column("client_id", sa.Integer(), sa.ForeignKey("clients.id"), nullable=False),
        sa.Column("channel", sa.String(40), nullable=False),
        sa.Column("recipient", sa.String(220), nullable=False, server_default=""),
        sa.Column("submission_reference", sa.String(180), nullable=False, server_default=""),
        sa.Column("note", sa.Text(), nullable=False, server_default=""),
        sa.Column("submitted_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("submitted_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_report_submissions_controlled_report_id", "report_submissions", ["controlled_report_id"])
    op.create_index("ix_report_submissions_client_id", "report_submissions", ["client_id"])
    op.create_index("ix_report_submissions_submitted_by_id", "report_submissions", ["submitted_by_id"])
    op.create_index("ix_report_submissions_submitted_at", "report_submissions", ["submitted_at"])


def downgrade():
    op.drop_table("report_submissions")
    with op.batch_alter_table("controlled_reports") as batch:
        batch.drop_constraint("fk_controlled_reports_supersedes", type_="foreignkey")
        batch.drop_index("ix_controlled_reports_supersedes_report_id")
        batch.drop_index("ix_controlled_reports_lms_status")
        batch.drop_column("amendment_reason")
        batch.drop_column("supersedes_report_id")
        batch.drop_column("approved_snapshot_json")
        batch.drop_column("lms_status")
    op.drop_table("external_technical_evidence")
    op.drop_table("troubleshooting_resolution_revisions")
    op.drop_table("troubleshooting_notes")
    with op.batch_alter_table("troubleshooting_records") as batch:
        batch.drop_index("ix_troubleshooting_records_responsible_domain")
        batch.drop_column("published_revision")
        batch.drop_column("resolution_summary")
        batch.drop_column("responsible_domain")
    op.drop_table("quality_execution_revisions")
    with op.batch_alter_table("quality_cases") as batch:
        batch.drop_constraint("fk_quality_cases_sop_document", type_="foreignkey")
        batch.drop_constraint("fk_quality_cases_method_document", type_="foreignkey")
        batch.drop_index("ix_quality_cases_sop_document_id")
        batch.drop_index("ix_quality_cases_method_document_id")
        batch.drop_column("review_note")
        batch.drop_column("review_conclusion")
        batch.drop_column("sop_document_id")
        batch.drop_column("method_document_id")
    with op.batch_alter_table("controlled_documents") as batch:
        batch.drop_constraint("fk_controlled_documents_manager_approver", type_="foreignkey")
        batch.drop_constraint("fk_controlled_documents_technical_reviewer", type_="foreignkey")
        batch.drop_column("manager_approved_at")
        batch.drop_column("technical_reviewed_at")
        batch.drop_column("manager_approved_by_id")
        batch.drop_column("technical_reviewed_by_id")
    with op.batch_alter_table("sampling_assignments") as batch:
        batch.drop_index("ix_sampling_assignments_task_type")
        batch.drop_column("task_type")
    with op.batch_alter_table("sampling_orders") as batch:
        batch.drop_constraint("fk_sampling_orders_operational_project", type_="foreignkey")
        batch.drop_index("ix_sampling_orders_operational_project_id")
        batch.drop_column("operational_project_id")
    with op.batch_alter_table("operational_projects") as batch:
        batch.drop_constraint("fk_operational_project_commercial_case", type_="foreignkey")
    with op.batch_alter_table("commercial_cases") as batch:
        batch.drop_constraint("fk_commercial_cases_operational_project", type_="foreignkey")
        batch.drop_constraint("fk_commercial_cases_assigned_coordinator_users", type_="foreignkey")
        batch.drop_index("ix_commercial_cases_operational_project_id")
        batch.drop_index("ix_commercial_cases_assigned_coordinator_id")
        batch.drop_column("corporate_admin_status")
        batch.drop_column("operational_project_id")
        batch.drop_column("assigned_coordinator_id")
    op.drop_table("operational_projects")
