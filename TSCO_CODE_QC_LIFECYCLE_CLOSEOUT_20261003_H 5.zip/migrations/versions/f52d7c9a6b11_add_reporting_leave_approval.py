"""add reporting line and direct-manager leave approval

Revision ID: f52d7c9a6b11
Revises: f41c8e2a91d0
"""
from alembic import op
import sqlalchemy as sa

revision = "f52d7c9a6b11"
down_revision = "f41c8e2a91d0"
branch_labels = None
depends_on = None


def upgrade():
    # batch_alter_table keeps the migration portable to the SQLite UAT review build
    # while preserving the same foreign keys in PostgreSQL production deployments.
    with op.batch_alter_table("users") as batch:
        batch.add_column(sa.Column("manager_id", sa.Integer(), nullable=True))
        batch.add_column(sa.Column("leave_approver_id", sa.Integer(), nullable=True))
        batch.create_index("ix_users_manager_id", ["manager_id"], unique=False)
        batch.create_index("ix_users_leave_approver_id", ["leave_approver_id"], unique=False)
        batch.create_foreign_key("fk_users_manager_id_users", "users", ["manager_id"], ["id"])
        batch.create_foreign_key("fk_users_leave_approver_id_users", "users", ["leave_approver_id"], ["id"])

    with op.batch_alter_table("staff_availability") as batch:
        batch.add_column(sa.Column("approver_id", sa.Integer(), nullable=True))
        batch.create_index("ix_staff_availability_approver_id", ["approver_id"], unique=False)
        batch.create_foreign_key("fk_staff_availability_approver_id_users", "users", ["approver_id"], ["id"])


def downgrade():
    with op.batch_alter_table("staff_availability") as batch:
        batch.drop_constraint("fk_staff_availability_approver_id_users", type_="foreignkey")
        batch.drop_index("ix_staff_availability_approver_id")
        batch.drop_column("approver_id")
    with op.batch_alter_table("users") as batch:
        batch.drop_constraint("fk_users_leave_approver_id_users", type_="foreignkey")
        batch.drop_constraint("fk_users_manager_id_users", type_="foreignkey")
        batch.drop_index("ix_users_leave_approver_id")
        batch.drop_index("ix_users_manager_id")
        batch.drop_column("leave_approver_id")
        batch.drop_column("manager_id")
