"""v3.2.3 hierarchy and leave coverage closeout

Revision ID: e7a4c2d9138f
Revises: c9e5a7b2d410
"""
from alembic import op
import sqlalchemy as sa

revision = "e7a4c2d9138f"
down_revision = "c9e5a7b2d410"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "leave_coverage_assignments",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("leave_availability_id", sa.Integer(), sa.ForeignKey("staff_availability.id"), nullable=False),
        sa.Column("site_id", sa.Integer(), sa.ForeignKey("sites.id"), nullable=False),
        sa.Column("absent_user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("acting_user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("responsibility_domain", sa.String(30), nullable=False, server_default=""),
        sa.Column("required_minimum", sa.Integer(), nullable=False, server_default="2"),
        sa.Column("available_senior_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("status", sa.String(40), nullable=False, server_default="ACTION_REQUIRED"),
        sa.Column("note", sa.Text(), nullable=False, server_default=""),
        sa.Column("checked_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("checked_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("leave_availability_id", name="uq_leave_coverage_leave"),
    )
    for col in ("leave_availability_id", "site_id", "absent_user_id", "acting_user_id", "responsibility_domain", "status", "checked_at"):
        op.create_index(f"ix_leave_coverage_assignments_{col}", "leave_coverage_assignments", [col])


def downgrade():
    op.drop_table("leave_coverage_assignments")
