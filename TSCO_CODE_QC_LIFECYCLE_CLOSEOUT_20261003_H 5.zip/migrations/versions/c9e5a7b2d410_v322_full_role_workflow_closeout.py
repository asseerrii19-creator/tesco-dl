"""v3.2.2 full role/workflow closeout

Revision ID: c9e5a7b2d410
Revises: b8d4f6a1c321
"""
from alembic import op
import sqlalchemy as sa

revision = "c9e5a7b2d410"
down_revision = "b8d4f6a1c321"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table("office_correspondence",
        sa.Column("id",sa.Integer(),primary_key=True),sa.Column("direction",sa.String(20),nullable=False),
        sa.Column("subject",sa.String(240),nullable=False),sa.Column("reference",sa.String(120),nullable=False,server_default=""),
        sa.Column("sender",sa.String(220),nullable=False,server_default=""),sa.Column("recipient",sa.String(220),nullable=False,server_default=""),
        sa.Column("correspondence_at",sa.DateTime(),nullable=False),sa.Column("responsible_user_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=True),
        sa.Column("due_at",sa.DateTime(),nullable=True),sa.Column("status",sa.String(30),nullable=False,server_default="OPEN"),
        sa.Column("follow_up_note",sa.Text(),nullable=False,server_default=""),sa.Column("closure_note",sa.Text(),nullable=False,server_default=""),
        sa.Column("attachment_path",sa.String(500),nullable=False,server_default=""),sa.Column("created_by_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=False),
        sa.Column("closed_at",sa.DateTime(),nullable=True),sa.Column("created_at",sa.DateTime(),nullable=False),sa.Column("updated_at",sa.DateTime(),nullable=False))
    op.create_index("ix_office_correspondence_direction","office_correspondence",["direction"]); op.create_index("ix_office_correspondence_status","office_correspondence",["status"])
    op.create_index("ix_office_correspondence_responsible_user_id","office_correspondence",["responsible_user_id"]); op.create_index("ix_office_correspondence_due_at","office_correspondence",["due_at"])

    op.create_table("office_meetings",
        sa.Column("id",sa.Integer(),primary_key=True),sa.Column("title",sa.String(240),nullable=False),sa.Column("meeting_at",sa.DateTime(),nullable=False),
        sa.Column("attendees",sa.Text(),nullable=False,server_default=""),sa.Column("agenda",sa.Text(),nullable=False,server_default=""),sa.Column("minutes",sa.Text(),nullable=False,server_default=""),
        sa.Column("status",sa.String(30),nullable=False,server_default="PLANNED"),sa.Column("created_by_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=False),
        sa.Column("created_at",sa.DateTime(),nullable=False),sa.Column("updated_at",sa.DateTime(),nullable=False))
    op.create_index("ix_office_meetings_meeting_at","office_meetings",["meeting_at"]); op.create_index("ix_office_meetings_status","office_meetings",["status"])
    op.create_table("office_meeting_actions",
        sa.Column("id",sa.Integer(),primary_key=True),sa.Column("meeting_id",sa.Integer(),sa.ForeignKey("office_meetings.id"),nullable=False),
        sa.Column("action_text",sa.Text(),nullable=False),sa.Column("owner_user_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=True),
        sa.Column("due_at",sa.DateTime(),nullable=True),sa.Column("status",sa.String(30),nullable=False,server_default="OPEN"),sa.Column("closure_note",sa.Text(),nullable=False,server_default=""),sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_index("ix_office_meeting_actions_meeting_id","office_meeting_actions",["meeting_id"]); op.create_index("ix_office_meeting_actions_owner_user_id","office_meeting_actions",["owner_user_id"])

    op.create_table("overtime_requests",
        sa.Column("id",sa.Integer(),primary_key=True),sa.Column("site_id",sa.Integer(),sa.ForeignKey("sites.id"),nullable=False),sa.Column("employee_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=False),
        sa.Column("requested_by_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=False),sa.Column("approver_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=False),
        sa.Column("work_date",sa.DateTime(),nullable=False),sa.Column("requested_hours",sa.Float(),nullable=False,server_default="0"),sa.Column("reason",sa.Text(),nullable=False,server_default=""),
        sa.Column("project_reference",sa.String(120),nullable=False,server_default=""),sa.Column("related_reference",sa.String(180),nullable=False,server_default=""),
        sa.Column("status",sa.String(30),nullable=False,server_default="SUBMITTED"),sa.Column("decision_note",sa.Text(),nullable=False,server_default=""),sa.Column("decided_at",sa.DateTime(),nullable=True),sa.Column("created_at",sa.DateTime(),nullable=False))
    for c in ("site_id","employee_id","requested_by_id","approver_id","work_date","status"): op.create_index(f"ix_overtime_requests_{c}","overtime_requests",[c])
    op.create_table("overtime_claims",
        sa.Column("id",sa.Integer(),primary_key=True),sa.Column("site_id",sa.Integer(),sa.ForeignKey("sites.id"),nullable=False),sa.Column("employee_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=False),
        sa.Column("overtime_request_id",sa.Integer(),sa.ForeignKey("overtime_requests.id"),nullable=True),sa.Column("work_date",sa.DateTime(),nullable=False),
        sa.Column("start_time",sa.String(5),nullable=False,server_default=""),sa.Column("end_time",sa.String(5),nullable=False,server_default=""),sa.Column("total_hours",sa.Float(),nullable=False,server_default="0"),
        sa.Column("reason",sa.Text(),nullable=False,server_default=""),sa.Column("project_reference",sa.String(120),nullable=False,server_default=""),sa.Column("related_reference",sa.String(180),nullable=False,server_default=""),
        sa.Column("status",sa.String(40),nullable=False,server_default="DRAFT"),sa.Column("external_submission_reference",sa.String(180),nullable=False,server_default=""),sa.Column("note",sa.Text(),nullable=False,server_default=""),
        sa.Column("created_at",sa.DateTime(),nullable=False),sa.Column("updated_at",sa.DateTime(),nullable=False))
    for c in ("site_id","employee_id","overtime_request_id","work_date","status"): op.create_index(f"ix_overtime_claims_{c}","overtime_claims",[c])

    op.create_table("night_shift_month_plans",
        sa.Column("id",sa.Integer(),primary_key=True),sa.Column("site_id",sa.Integer(),sa.ForeignKey("sites.id"),nullable=False),sa.Column("year",sa.Integer(),nullable=False),sa.Column("month",sa.Integer(),nullable=False),
        sa.Column("user_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=False),sa.Column("status",sa.String(30),nullable=False,server_default="PUBLISHED"),sa.Column("created_by_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=False),sa.Column("created_at",sa.DateTime(),nullable=False),
        sa.UniqueConstraint("site_id","year","month","user_id",name="uq_night_shift_month_plan"))
    for c in ("site_id","year","month","user_id","status"): op.create_index(f"ix_night_shift_month_plans_{c}","night_shift_month_plans",[c])

    op.create_table("housekeeping_tasks",
        sa.Column("id",sa.Integer(),primary_key=True),sa.Column("site_id",sa.Integer(),sa.ForeignKey("sites.id"),nullable=False),sa.Column("area_zone",sa.String(180),nullable=False),
        sa.Column("assigned_to_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=False),sa.Column("due_at",sa.DateTime(),nullable=True),sa.Column("shift_code",sa.String(40),nullable=False,server_default=""),
        sa.Column("status",sa.String(30),nullable=False,server_default="DUE"),sa.Column("completion_note",sa.Text(),nullable=False,server_default=""),sa.Column("completion_photo_path",sa.String(500),nullable=False,server_default=""),
        sa.Column("created_by_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=False),sa.Column("completed_at",sa.DateTime(),nullable=True),sa.Column("created_at",sa.DateTime(),nullable=False))
    for c in ("site_id","assigned_to_id","due_at","status"): op.create_index(f"ix_housekeeping_tasks_{c}","housekeeping_tasks",[c])
    op.create_table("housekeeping_observations",
        sa.Column("id",sa.Integer(),primary_key=True),sa.Column("task_id",sa.Integer(),sa.ForeignKey("housekeeping_tasks.id"),nullable=True),sa.Column("site_id",sa.Integer(),sa.ForeignKey("sites.id"),nullable=False),
        sa.Column("raised_by_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=False),sa.Column("category",sa.String(60),nullable=False),sa.Column("note",sa.Text(),nullable=False),
        sa.Column("photo_path",sa.String(500),nullable=False,server_default=""),sa.Column("routed_domain",sa.String(30),nullable=False,server_default="EQUIPMENT"),sa.Column("status",sa.String(30),nullable=False,server_default="OPEN"),sa.Column("created_at",sa.DateTime(),nullable=False))
    for c in ("task_id","site_id","raised_by_id","category","routed_domain","status"): op.create_index(f"ix_housekeeping_observations_{c}","housekeeping_observations",[c])

    op.create_table("glassware_batches",
        sa.Column("id",sa.Integer(),primary_key=True),sa.Column("site_id",sa.Integer(),sa.ForeignKey("sites.id"),nullable=False),sa.Column("batch_code",sa.String(40),nullable=False,unique=True),
        sa.Column("source_workstation",sa.String(180),nullable=False,server_default=""),sa.Column("glassware_type",sa.String(180),nullable=False,server_default="General"),sa.Column("approximate_quantity",sa.Integer(),nullable=True),
        sa.Column("priority",sa.String(20),nullable=False,server_default="NORMAL"),sa.Column("received_at",sa.DateTime(),nullable=False),sa.Column("status",sa.String(30),nullable=False,server_default="WAITING"),
        sa.Column("assigned_to_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=True),sa.Column("note",sa.Text(),nullable=False,server_default=""),sa.Column("completed_at",sa.DateTime(),nullable=True),
        sa.Column("created_by_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=False))
    for c in ("site_id","batch_code","priority","received_at","status","assigned_to_id"): op.create_index(f"ix_glassware_batches_{c}","glassware_batches",[c])

    op.create_table("sample_kits",
        sa.Column("id",sa.Integer(),primary_key=True),sa.Column("site_id",sa.Integer(),sa.ForeignKey("sites.id"),nullable=False),sa.Column("kit_code",sa.String(40),nullable=False,unique=True),
        sa.Column("status",sa.String(30),nullable=False,server_default="PREPARING"),sa.Column("kit_type",sa.String(120),nullable=False,server_default="Transformer Oil Sampling Kit"),
        sa.Column("contents_summary",sa.Text(),nullable=False,server_default=""),sa.Column("container_count",sa.Integer(),nullable=False,server_default="0"),
        sa.Column("assigned_sampler_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=True),
        sa.Column("operational_project_id",sa.Integer(),sa.ForeignKey("operational_projects.id"),nullable=True),sa.Column("sampling_order_id",sa.Integer(),sa.ForeignKey("sampling_orders.id"),nullable=True),
        sa.Column("note",sa.Text(),nullable=False,server_default=""),sa.Column("prepared_at",sa.DateTime(),nullable=True),sa.Column("issued_at",sa.DateTime(),nullable=True),sa.Column("returned_at",sa.DateTime(),nullable=True),sa.Column("created_by_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=False),sa.Column("created_at",sa.DateTime(),nullable=False))
    for c in ("site_id","kit_code","status","assigned_sampler_id","operational_project_id","sampling_order_id"): op.create_index(f"ix_sample_kits_{c}","sample_kits",[c])
    op.create_table("sample_kit_tasks",
        sa.Column("id",sa.Integer(),primary_key=True),sa.Column("site_id",sa.Integer(),sa.ForeignKey("sites.id"),nullable=False),sa.Column("retained_sample_key",sa.String(120),nullable=False),
        sa.Column("container_type",sa.String(30),nullable=False,server_default="BOTTLE"),sa.Column("assigned_to_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=False),sa.Column("assigned_by_id",sa.Integer(),sa.ForeignKey("users.id"),nullable=False),
        sa.Column("sample_kit_id",sa.Integer(),sa.ForeignKey("sample_kits.id"),nullable=True),sa.Column("status",sa.String(30),nullable=False,server_default="ASSIGNED"),sa.Column("note",sa.Text(),nullable=False,server_default=""),
        sa.Column("completed_at",sa.DateTime(),nullable=True),sa.Column("created_at",sa.DateTime(),nullable=False))
    for c in ("site_id","retained_sample_key","assigned_to_id","sample_kit_id","status"): op.create_index(f"ix_sample_kit_tasks_{c}","sample_kit_tasks",[c])


def downgrade():
    for table in ["sample_kit_tasks","sample_kits","glassware_batches","housekeeping_observations","housekeeping_tasks","night_shift_month_plans","overtime_claims","overtime_requests","office_meeting_actions","office_meetings","office_correspondence"]:
        op.drop_table(table)
