"""v3.2.8 client request scope before quotation

Revision ID: ba7d2f9c4e31
Revises: f9c3a7e1d620
"""
from alembic import op
import sqlalchemy as sa

revision = "ba7d2f9c4e31"
down_revision = "f9c3a7e1d620"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "commercial_request_lines",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("commercial_case_id", sa.Integer(), sa.ForeignKey("commercial_cases.id"), nullable=False),
        sa.Column("line_number", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("quantity", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("requested_package", sa.String(length=160), nullable=False, server_default="Routine Test"),
        sa.Column("requested_tests_json", sa.Text(), nullable=False, server_default="[]"),
        sa.Column("method_family", sa.String(length=20), nullable=False, server_default="DEFAULT"),
        sa.Column("priority", sa.String(length=20), nullable=False, server_default="NORMAL"),
        sa.Column("required_tat", sa.String(length=40), nullable=False, server_default=""),
        sa.Column("due_at", sa.DateTime(), nullable=True),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="ACTIVE"),
        sa.Column("created_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("commercial_case_id", "line_number", name="uq_commercial_request_line_number"),
    )
    op.create_index("ix_commercial_request_lines_commercial_case_id", "commercial_request_lines", ["commercial_case_id"])
    op.create_index("ix_commercial_request_lines_status", "commercial_request_lines", ["status"])
    with op.batch_alter_table("sampling_assignments") as batch:
        batch.add_column(sa.Column("commercial_request_line_id", sa.Integer(), nullable=True))
        batch.add_column(sa.Column("requested_method_family", sa.String(length=20), nullable=False, server_default="DEFAULT"))
        batch.add_column(sa.Column("requested_tests_json", sa.Text(), nullable=False, server_default="[]"))
        batch.add_column(sa.Column("priority", sa.String(length=20), nullable=False, server_default="NORMAL"))
        batch.add_column(sa.Column("required_tat", sa.String(length=30), nullable=False, server_default=""))
        batch.add_column(sa.Column("due_at", sa.DateTime(), nullable=True))
        batch.create_foreign_key("fk_sampling_assignment_request_line", "commercial_request_lines", ["commercial_request_line_id"], ["id"])
        batch.create_index("ix_sampling_assignments_commercial_request_line_id", ["commercial_request_line_id"])
        batch.create_index("ix_sampling_assignments_due_at", ["due_at"])

    with op.batch_alter_table("sample_requests") as batch:
        batch.add_column(sa.Column("commercial_request_line_id", sa.Integer(), nullable=True))
        batch.add_column(sa.Column("requested_method_family", sa.String(length=20), nullable=False, server_default="DEFAULT"))
        batch.add_column(sa.Column("requested_tests_json", sa.Text(), nullable=False, server_default="[]"))
        batch.create_foreign_key("fk_sample_commercial_request_line", "commercial_request_lines", ["commercial_request_line_id"], ["id"])
        batch.create_index("ix_sample_requests_commercial_request_line_id", ["commercial_request_line_id"])


def downgrade() -> None:
    with op.batch_alter_table("sample_requests") as batch:
        batch.drop_index("ix_sample_requests_commercial_request_line_id")
        batch.drop_constraint("fk_sample_commercial_request_line", type_="foreignkey")
        batch.drop_column("requested_tests_json")
        batch.drop_column("requested_method_family")
        batch.drop_column("commercial_request_line_id")
    with op.batch_alter_table("sampling_assignments") as batch:
        batch.drop_index("ix_sampling_assignments_due_at")
        batch.drop_index("ix_sampling_assignments_commercial_request_line_id")
        batch.drop_constraint("fk_sampling_assignment_request_line", type_="foreignkey")
        batch.drop_column("due_at")
        batch.drop_column("required_tat")
        batch.drop_column("priority")
        batch.drop_column("requested_tests_json")
        batch.drop_column("requested_method_family")
        batch.drop_column("commercial_request_line_id")
    op.drop_index("ix_commercial_request_lines_status", table_name="commercial_request_lines")
    op.drop_index("ix_commercial_request_lines_commercial_case_id", table_name="commercial_request_lines")
    op.drop_table("commercial_request_lines")
