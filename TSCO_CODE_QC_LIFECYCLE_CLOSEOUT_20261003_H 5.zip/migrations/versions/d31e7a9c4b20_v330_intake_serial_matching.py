"""v3.3.0 intake request-to-physical-sample serial matching

Revision ID: d31e7a9c4b20
Revises: c14e8a2b7d39
"""
from alembic import op
import sqlalchemy as sa

revision = "d31e7a9c4b20"
down_revision = "c14e8a2b7d39"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("commercial_request_lines") as batch:
        batch.add_column(sa.Column("expected_serials_json", sa.Text(), nullable=False, server_default="[]"))


def downgrade() -> None:
    with op.batch_alter_table("commercial_request_lines") as batch:
        batch.drop_column("expected_serials_json")
