"""v3.4.2 official controlled report PDF artifact

Revision ID: b17f4c8d9e20
Revises: a62f1d9e4c71
"""
from alembic import op
import sqlalchemy as sa

revision = "b17f4c8d9e20"
down_revision = "a62f1d9e4c71"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("controlled_reports") as batch:
        batch.add_column(sa.Column("official_pdf_path", sa.String(length=500), nullable=False, server_default=""))
        batch.add_column(sa.Column("official_pdf_sha256", sa.String(length=64), nullable=False, server_default=""))
        batch.add_column(sa.Column("official_pdf_generated_at", sa.DateTime(), nullable=True))
        batch.add_column(sa.Column("report_template_code", sa.String(length=40), nullable=False, server_default="QDF-[7]-08-A"))
        batch.create_index("ix_controlled_reports_official_pdf_sha256", ["official_pdf_sha256"], unique=False)


def downgrade() -> None:
    with op.batch_alter_table("controlled_reports") as batch:
        batch.drop_index("ix_controlled_reports_official_pdf_sha256")
        batch.drop_column("report_template_code")
        batch.drop_column("official_pdf_generated_at")
        batch.drop_column("official_pdf_sha256")
        batch.drop_column("official_pdf_path")
