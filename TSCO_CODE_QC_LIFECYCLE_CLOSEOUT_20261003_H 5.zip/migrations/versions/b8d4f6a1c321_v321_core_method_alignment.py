"""v3.2.1 core method alignment

Revision ID: b8d4f6a1c321
Revises: a7c3e9f4b210
"""
from alembic import op
import sqlalchemy as sa
import json
from datetime import datetime

revision = "b8d4f6a1c321"
down_revision = "a7c3e9f4b210"
branch_labels = None
depends_on = None

METHOD_MAP = {
    "Dissolved Gas Analysis (DGA)": "IEC 60567",
    "Viscosity @ 40 °C": "ASTM D445",
    "Viscosity @ -30 °C": "ASTM D445",
    "Viscosity @ 100 °C": "ASTM D445",
    "Density of Oil @RT": "ASTM D4052",
    "Density of Oil @20°C": "ASTM D4052",
    "Relative Density of Oil": "ASTM D4052",
    "Dibenzyl Disulfide (DBDS)": "IEC 62697-1",
}
RENAMES = {
    "Ruller Test": "RULER Test",
    "Demusibility Test": "Demulsibility Test",
    "Rams-Bottom Carbon Residue": "Ramsbottom Carbon Residue",
    "Gassing Tendancy": "Gassing Tendency",
    "Oxidation Satbility": "Oxidation Stability",
    "Polycyclo aromatics PCA": "Polycyclic Aromatics (PCA)",
}


def _patch_tests(raw: str) -> tuple[str, bool]:
    try:
        rows = json.loads(raw or "[]")
    except Exception:
        return raw, False
    if not isinstance(rows, list):
        return raw, False
    changed = False
    for row in rows:
        if not isinstance(row, dict):
            continue
        name = str(row.get("test") or "")
        if name in RENAMES:
            row["test"] = RENAMES[name]
            name = row["test"]
            changed = True
        if name in METHOD_MAP and str(row.get("method") or "").strip() != METHOD_MAP[name]:
            row["method"] = METHOD_MAP[name]
            changed = True
    return json.dumps(rows, ensure_ascii=False), changed


def upgrade():
    bind = op.get_bind()
    rows = bind.execute(sa.text("SELECT id, tests_json FROM test_package_configs")).mappings().all()
    for row in rows:
        patched, changed = _patch_tests(row["tests_json"])
        if changed:
            bind.execute(
                sa.text("UPDATE test_package_configs SET tests_json=:tests_json, updated_at=:updated_at WHERE id=:id"),
                {"tests_json": patched, "updated_at": datetime.utcnow(), "id": row["id"]},
            )


def downgrade():
    # This migration corrects master-data labels/method references only. It intentionally does not
    # guess previous values during downgrade because package masters may have been legitimately
    # edited after upgrade. Historical package JSON/revisions remain the audit source.
    pass
