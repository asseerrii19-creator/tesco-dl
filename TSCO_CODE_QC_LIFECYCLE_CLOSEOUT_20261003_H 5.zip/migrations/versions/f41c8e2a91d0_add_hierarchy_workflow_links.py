"""add hierarchy workflow links

Revision ID: f41c8e2a91d0
Revises: e31a7f4b9c20
"""
from alembic import op
import sqlalchemy as sa

revision = "f41c8e2a91d0"
down_revision = "e31a7f4b9c20"
branch_labels = None
depends_on = None

def upgrade():
    op.add_column("sampling_assignments", sa.Column("sample_label", sa.String(length=180), nullable=False, server_default=""))
    op.create_index("ix_sampling_assignments_sample_label", "sampling_assignments", ["sample_label"], unique=False)
    op.add_column("improvement_items", sa.Column("source_entity_type", sa.String(length=60), nullable=False, server_default=""))
    op.add_column("improvement_items", sa.Column("source_entity_id", sa.Integer(), nullable=True))
    op.add_column("improvement_items", sa.Column("source_url", sa.String(length=300), nullable=False, server_default=""))
    op.create_index("ix_improvement_items_source_entity_type", "improvement_items", ["source_entity_type"], unique=False)
    op.create_index("ix_improvement_items_source_entity_id", "improvement_items", ["source_entity_id"], unique=False)

def downgrade():
    op.drop_index("ix_improvement_items_source_entity_id", table_name="improvement_items")
    op.drop_index("ix_improvement_items_source_entity_type", table_name="improvement_items")
    op.drop_column("improvement_items", "source_url")
    op.drop_column("improvement_items", "source_entity_id")
    op.drop_column("improvement_items", "source_entity_type")
    op.drop_index("ix_sampling_assignments_sample_label", table_name="sampling_assignments")
    op.drop_column("sampling_assignments", "sample_label")
