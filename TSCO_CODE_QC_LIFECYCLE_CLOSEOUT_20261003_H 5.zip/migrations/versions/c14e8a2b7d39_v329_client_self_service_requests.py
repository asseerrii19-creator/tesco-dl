"""v3.2.9 client self-service request intake

Revision ID: c14e8a2b7d39
Revises: ba7d2f9c4e31
"""
from alembic import op
import sqlalchemy as sa

revision = "c14e8a2b7d39"
down_revision = "ba7d2f9c4e31"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("commercial_cases") as batch:
        batch.add_column(sa.Column("request_source", sa.String(length=30), nullable=False, server_default="INTERNAL"))
        batch.add_column(sa.Column("request_status", sa.String(length=30), nullable=False, server_default="INTERNAL"))
        batch.add_column(sa.Column("client_message", sa.Text(), nullable=False, server_default=""))
        batch.add_column(sa.Column("client_submitted_at", sa.DateTime(), nullable=True))
        batch.add_column(sa.Column("request_opened_at", sa.DateTime(), nullable=True))
        batch.add_column(sa.Column("request_opened_by_id", sa.Integer(), nullable=True))
        batch.create_foreign_key("fk_commercial_case_request_opened_by", "users", ["request_opened_by_id"], ["id"])
        batch.create_index("ix_commercial_cases_request_source", ["request_source"])
        batch.create_index("ix_commercial_cases_request_status", ["request_status"])
        batch.create_index("ix_commercial_cases_request_opened_by_id", ["request_opened_by_id"])


def downgrade() -> None:
    with op.batch_alter_table("commercial_cases") as batch:
        batch.drop_index("ix_commercial_cases_request_opened_by_id")
        batch.drop_index("ix_commercial_cases_request_status")
        batch.drop_index("ix_commercial_cases_request_source")
        batch.drop_constraint("fk_commercial_case_request_opened_by", type_="foreignkey")
        batch.drop_column("request_opened_by_id")
        batch.drop_column("request_opened_at")
        batch.drop_column("client_submitted_at")
        batch.drop_column("client_message")
        batch.drop_column("request_status")
        batch.drop_column("request_source")
