# Final Package Manifest — v3.4.3 Intake Continuity UAT

- Version: `3.4.3`
- Alembic head: `c43a7d9e2f10`
- Deployment model: existing Render PostgreSQL UAT service; no database reset
- Continuation case: `BC-DMM-2026-0003`
- Required continuation point: Data Entry → Expected Arrivals → Receive Samples

## v3.4.3 release-specific files
- `V3.4.3_INTAKE_CONTINUITY_HOTFIX.md`
- `FINAL_VERIFICATION_v3.4.3.md`
- `RELEASE_VERIFICATION_EVIDENCE_v3.4.3.txt`
- `PACKAGE_CONTENTS_v3.4.3.txt`
- `PACKAGE_SHA256SUMS_v3.4.3.txt`
- `scripts/run_v343_release_verification.sh`
- `tests/test_v343_intake_continuity_hotfix.py`
- `migrations/versions/c43a7d9e2f10_v343_attachment_blob_hotfix.py`
- `app/services/client_data_form.py`
- `app/uat_fixtures/` recovery copies for the already-created UAT case documents

Historical v3.4.2 release documents remain in the package as baseline evidence. Where v3.4.3 explicitly supersedes intake behavior, the v3.4.3 hotfix document is authoritative.
