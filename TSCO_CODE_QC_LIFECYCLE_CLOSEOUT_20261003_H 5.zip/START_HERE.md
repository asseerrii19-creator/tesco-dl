# START HERE — Project 00012 v3.5.8 Workstation Assignment Authority + QC Lifecycle UAT

1. Deploy **Change Set H** without database reset; Alembic head remains `c43a7d9e2f10`.
2. Keep the current UAT samples/batches. Do not recreate the workflow just to test this release.
3. In **Analytical QC Control**, create/register the applicable QC Material/Lot:
   - Internal: qualification/preparation evidence is mandatory.
   - CRM: supplier, certificate/lot evidence and certified information are mandatory.
4. Bind the lot to the exact requested Test/Method and Equipment Master ID(s).
5. Senior Chemist reviews and electronically approves the lot. A pending/unapproved lot cannot release sample results.
6. At the workstation, expand **Analytical QC** only when action is required, select the approved lot and upload the QC instrument/run source file.
7. The server parses/evaluates the QC. Only **PASS** opens the affected sample-result path. WARNING/FAIL/missing/expired QC stays blocked.
8. Continue the same sample UAT using the existing BDV/PF file-first sample-result flow.

Read `V3.5.8_WORKSTATION_ASSIGNMENT_AUTHORITY_CLOSEOUT.md` for the current workstation fix, `V3.5.6_QC_LIFECYCLE_FILE_FIRST_CLOSEOUT.md` for the controlled QC operating model, and `FINAL_VERIFICATION_v3.5.8.md` for verification evidence.
