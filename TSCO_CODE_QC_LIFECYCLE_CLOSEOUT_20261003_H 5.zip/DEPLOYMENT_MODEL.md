# TSCO UAT fixed deployment model

This package is the mutable application code layer. The bundled reference document seed is stored separately in `TSCO_REFERENCE_ASSETS.zip` because those documents are large and change infrequently.

## Normal update
1. Replace `TSCO_CODE_CURRENT.zip` in the GitHub repository.
2. Commit once.
3. Render deploys using fixed Build/Start commands. No version-specific paths or command edits are required.

## Reference documents
Do not replace `TSCO_REFERENCE_ASSETS.zip` for ordinary bug fixes or UI/workflow changes. Replace it only when the bundled seed reference documents themselves change.

## Release gate
The fixed Render build validates the archive and runs the current v3.4.x regression suite before the application can deploy.

## Operational data vs code
- Intake/sample corrections are performed through controlled Data Entry amendment and audit trail.
- Master/configuration changes belong in authorized system screens.
- A code deploy is reserved for actual defects or new software behavior.
