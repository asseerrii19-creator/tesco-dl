# TSCO Digital Laboratory Platform — Project 00012 v3.5.8

Current UAT package: **v3.5.8 — Workstation Assignment Authority Closeout**, retaining the v3.5.6 QC Material/Lot Lifecycle + File-First Analytical QC controls and the v3.5.7 navigation continuity behavior.

This release keeps the existing UAT sample journey and closes the analytical-QC design gap identified during live Chemical Technician UAT:

- QC is controlled as a Material/Lot lifecycle rather than a free manual value.
- New Internal/CRM lots require evidence, exact Test/Method/Equipment scope and Senior Chemist technical approval/e-signature before use.
- Routine analytical QC is file-first where instrument output exists; source files are retained as controlled evidence.
- Only a valid **PASS** from the active approved lot opens the affected sample-result gate. WARNING/FAIL/missing/expired/unapproved QC remains blocked.
- BDV/PF/DGA QC use controlled instrument parsing; failed QC cannot be overridden to PASS.
- Workstation QC UI is compact/collapsible instead of an always-open equipment list.

Start with `START_HERE.md`, `V3.5.8_WORKSTATION_ASSIGNMENT_AUTHORITY_CLOSEOUT.md`, and `V3.5.6_QC_LIFECYCLE_FILE_FIRST_CLOSEOUT.md`.

Database migration head: `c43a7d9e2f10` (unchanged; no database reset required).
