# Package Manifest — v3.5.9

Package name: `TSCO_CODE_QC_LIFECYCLE_CLOSEOUT_20261003_H.zip`

Primary changed/added release files versus v3.5.8:
- `app/services/lab_operations.py`
- `app/lab_ops/index_template.html`
- `tests/test_v359_uat_electrical_report_path.py`
- `BUILD_RELEASE_CHECK.sh`
- `VERSION`
- `V3.5.9_ELECTRICAL_TO_REPORT_ONE_SHOT_CLOSEOUT.md`
- `FINAL_VERIFICATION_v3.5.9.md`
- `FINAL_PACKAGE_MANIFEST_v3.5.9.md`

Release version: 3.5.9
