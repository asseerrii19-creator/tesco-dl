# Final Verification — v3.4.2 Standalone UAT

## Automated gates completed
- Release identity is `3.4.2` on active runtime/version surfaces.
- Alembic head is `b17f4c8d9e20`; a clean database upgrades from base to head.
- Full automated regression suite passes: **86 tests**.
- Active user-facing release workflow exposes no LMS approval/release action.
- Result Worksheet has no official client-release control.
- Senior Final Report Review is a mandatory state gate before Technical Manager approval.
- Senior review workspace includes full report preview, Quick Result Check cards, automatic requirements, draft saving, editable Condition / Interpretation / Recommendation and explicit confirmations.
- Technical Manager approval rejects a report that has not completed Senior review.
- Final Analysis Report approval creates an immutable official PDF with SHA-256 integrity metadata.
- Direct paper DP is retained separately from indirect furan DP and can be shown in the specialty report section with corrosion results when requested.
- Representative QDF-[7]-08-A report generation renders six pages without visible clipping/overlap in PDF render verification.

## Manual UAT still required before production
Use representative company data on the company-controlled UAT PostgreSQL environment and verify the complete workflow by role on desktop, iPad and phone. Quality must confirm controlled report wording, accreditation assets, uncertainty/limits and final master values before production release.

This build is **UAT-ready**; it is not a claim of company production/security acceptance.
