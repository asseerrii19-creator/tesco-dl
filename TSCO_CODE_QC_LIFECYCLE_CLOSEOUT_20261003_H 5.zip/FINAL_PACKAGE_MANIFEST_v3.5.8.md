# TSCO Project 00012 — v3.5.8 Package Manifest

Deployment filename remains `TSCO_CODE_QC_LIFECYCLE_CLOSEOUT_20261003_H.zip` so the existing Render build/start commands remain unchanged.

Current closeout documents:
1. `V3.5.8_WORKSTATION_ASSIGNMENT_AUTHORITY_CLOSEOUT.md`
2. `FINAL_VERIFICATION_v3.5.8.md`
3. `V3.5.6_QC_LIFECYCLE_FILE_FIRST_CLOSEOUT.md`

No database reset, service change, or new Render service is required.
