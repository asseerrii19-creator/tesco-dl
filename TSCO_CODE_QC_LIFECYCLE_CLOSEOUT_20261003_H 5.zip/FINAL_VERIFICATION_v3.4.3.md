# Final Verification — v3.4.3 Intake Continuity UAT

## Release identity
- Application version: `3.4.3`
- Alembic head: `c43a7d9e2f10`
- Baseline: v3.4.2 standalone UAT
- Hotfix scope: direct-client intake continuity + controlled commercial-document durability

## Verified controls
- Existing approved commercial case is reused; no restart/re-key requirement.
- Client Data Form parser maps explicit request/sample fields conservatively.
- Approved request serials prefill Data Entry intake.
- Missing approved serials can create controlled Asset Master identities during intake.
- Duplicate/ambiguous serial identity remains blocked.
- `CLIENT_ACCEPTED` quotation state is accepted after client acceptance and before/with PO handoff.
- Data Entry can read linked controlled commercial documents.
- Attachment downloads fall back to database binary content if the local file is absent.
- Existing v3.4.2 UAT attachments can be restored into blob storage without recreating the case.
- Fresh database migration reaches `c43a7d9e2f10`.

## Regression evidence
The release verification script runs compile checks, a clean migration, the v3.4.3 continuity tests, and the current intake/client/commercial regression set. See `RELEASE_VERIFICATION_EVIDENCE_v3.4.3.txt`.
