# Final Package Manifest — v3.4.4 Data Form Backfill UAT

- Version: `3.4.4`
- Database migration head remains: `c43a7d9e2f10` (no schema change required)
- Scope: linked Client Data Form durability/backfill and Data Entry correction path for already-created samples

## Release-specific files
- `V3.4.4_DATA_FORM_BACKFILL_HOTFIX.md`
- `FINAL_VERIFICATION_v3.4.4.md`
- `RELEASE_VERIFICATION_EVIDENCE_v3.4.4.txt`
- `PACKAGE_CONTENTS_v3.4.4.txt`
- `PACKAGE_SHA256SUMS_v3.4.4.txt`
- `tests/test_v344_data_form_backfill.py`

Historical release evidence remains packaged for traceability. v3.4.4 supersedes v3.4.3 only for missing linked Client Data Form metadata/backfill behavior.
