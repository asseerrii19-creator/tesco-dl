from __future__ import annotations

from app.database import SessionLocal
from app.models import User
from app.services.daily_brief import INTERNAL_ROLES, build_daily_brief, deliver_daily_brief


def main() -> int:
    sent = pending = failed = 0
    with SessionLocal() as db:
        users = db.query(User).filter(User.active.is_(True), User.role.in_(INTERNAL_ROLES)).order_by(User.email).all()
        for user in users:
            try:
                delivery = deliver_daily_brief(build_daily_brief(db, user))
                if delivery.status == 'SENT':
                    sent += 1
                else:
                    pending += 1
                print(f"{user.email}: {delivery.status} — {delivery.detail}")
            except Exception as exc:
                failed += 1
                print(f"{user.email}: FAILED — {exc}")
    print(f"Summary: sent={sent} pending_configuration={pending} failed={failed}")
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
