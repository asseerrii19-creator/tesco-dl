#!/bin/sh
set -eu

ENV_FILE=${1:-.env.production}
COMPOSE_FILE=${COMPOSE_FILE:-docker-compose.production.yml}
BACKUP_DIR=${BACKUP_DIR:-backups}
[ -f "$ENV_FILE" ] || { echo "Missing environment file: $ENV_FILE" >&2; exit 1; }
mkdir -p "$BACKUP_DIR"
set -a; . "$ENV_FILE"; set +a
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
WORK="$BACKUP_DIR/.tsco_backup_${STAMP}_$$"
BUNDLE="$BACKUP_DIR/tsco_platform_${STAMP}.tar.gz"
mkdir -p "$WORK"
trap 'rm -rf "$WORK"' EXIT INT TERM

VERSION=$(cat VERSION 2>/dev/null || echo unknown)
ALEMBIC_HEAD=$(docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" run --rm -T web alembic heads 2>/dev/null | awk '/\(head\)/{print $1; exit}')
[ -n "$ALEMBIC_HEAD" ] || { echo "Unable to resolve Alembic head" >&2; exit 1; }

echo "1/4 Dump PostgreSQL"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" --no-owner --no-privileges | gzip -9 > "$WORK/database.sql.gz"
[ -s "$WORK/database.sql.gz" ] || { echo "Database backup is empty" >&2; exit 1; }

echo "2/4 Archive controlled files (/var/data)"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T web \
  sh -c 'cd /var/data && tar -czf - .' > "$WORK/data.tar.gz"
[ -s "$WORK/data.tar.gz" ] || { echo "/var/data archive is empty" >&2; exit 1; }

cat > "$WORK/manifest.txt" <<MANIFEST
TSCO Digital Laboratory Platform backup
created_utc=$STAMP
application_version=$VERSION
alembic_head=$ALEMBIC_HEAD
postgres_database=$POSTGRES_DB
contains=database.sql.gz,data.tar.gz
MANIFEST
(
  cd "$WORK"
  sha256sum database.sql.gz data.tar.gz manifest.txt > SHA256SUMS
)

echo "3/4 Build atomic backup bundle"
tar -C "$WORK" -czf "$BUNDLE" database.sql.gz data.tar.gz manifest.txt SHA256SUMS
[ -s "$BUNDLE" ] || { echo "Backup bundle was not created" >&2; exit 1; }
sha256sum "$BUNDLE" > "$BUNDLE.sha256"

echo "4/4 Verify bundle"
tar -tzf "$BUNDLE" >/dev/null
TMP_VERIFY="$WORK/verify"; mkdir -p "$TMP_VERIFY"; tar -C "$TMP_VERIFY" -xzf "$BUNDLE"
(cd "$TMP_VERIFY" && sha256sum -c SHA256SUMS >/dev/null)

echo "PASS: complete database + /var/data backup created"
echo "$BUNDLE"
echo "$BUNDLE.sha256"
