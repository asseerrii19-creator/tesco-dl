#!/bin/sh
set -eu

[ $# -ge 1 ] || { echo "Usage: $0 <tsco_platform_*.tar.gz> [env-file]" >&2; exit 2; }
BUNDLE=$1
ENV_FILE=${2:-.env.production}
COMPOSE_FILE=${COMPOSE_FILE:-docker-compose.production.yml}
[ -f "$BUNDLE" ] || { echo "Backup bundle not found: $BUNDLE" >&2; exit 1; }
[ -f "$ENV_FILE" ] || { echo "Environment file not found: $ENV_FILE" >&2; exit 1; }
if [ -f "$BUNDLE.sha256" ]; then
  echo "Verify external backup bundle checksum"
  sha256sum -c "$BUNDLE.sha256" >/dev/null
fi
set -a; . "$ENV_FILE"; set +a

WORK=$(mktemp -d "${TMPDIR:-/tmp}/tsco_restore.XXXXXX")
trap 'rm -rf "$WORK"' EXIT INT TERM

CONTENTS=$(tar -tzf "$BUNDLE" | sed 's#^\./##' | sed '/^$/d' | sort)
EXPECTED=$(printf '%s\n' SHA256SUMS data.tar.gz database.sql.gz manifest.txt | sort)
[ "$CONTENTS" = "$EXPECTED" ] || { echo "Backup bundle contains unexpected or missing members" >&2; exit 1; }
tar -C "$WORK" -xzf "$BUNDLE"
for f in database.sql.gz data.tar.gz manifest.txt SHA256SUMS; do [ -s "$WORK/$f" ] || { echo "Bundle missing $f" >&2; exit 1; }; done
(cd "$WORK" && sha256sum -c SHA256SUMS)
cat "$WORK/manifest.txt"
printf 'DESTRUCTIVE RESTORE: type RESTORE to replace database %s and /var/data: ' "$POSTGRES_DB"
read answer
[ "$answer" = "RESTORE" ] || { echo "Cancelled."; exit 1; }

echo "1/5 Stop application service"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" stop web >/dev/null || true

echo "2/5 Recreate database"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  psql -U "$POSTGRES_USER" -d postgres -v ON_ERROR_STOP=1 \
  -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='${POSTGRES_DB}' AND pid <> pg_backend_pid();" \
  -c "DROP DATABASE IF EXISTS \"${POSTGRES_DB}\";" \
  -c "CREATE DATABASE \"${POSTGRES_DB}\" OWNER \"${POSTGRES_USER}\";"
gunzip -c "$WORK/database.sql.gz" | docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T db \
  psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -v ON_ERROR_STOP=1

echo "3/5 Restore matching controlled-file volume"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" run --rm -T web \
  sh -c 'find /var/data -mindepth 1 -maxdepth 1 -exec rm -rf -- {} +; tar -C /var/data -xzf -' < "$WORK/data.tar.gz"

echo "4/5 Apply/verify database migrations"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" run --rm -T web alembic upgrade head

echo "5/5 Start application and run smoke test"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" up -d web >/dev/null
sleep 3
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" exec -T web python scripts/production_smoke_test.py http://127.0.0.1:8000

echo "PASS: database + /var/data restored from the same verified bundle"
