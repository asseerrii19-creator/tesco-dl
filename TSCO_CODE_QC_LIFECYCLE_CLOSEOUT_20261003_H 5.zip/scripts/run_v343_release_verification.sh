#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }

[ "$(tr -d '\r\n ' < VERSION)" = "3.4.3" ] || fail "VERSION is not 3.4.3"
grep -q 'version = "3.4.3"' pyproject.toml || fail "pyproject version mismatch"
grep -q 'version="3.4.3"' app/main.py || fail "FastAPI version mismatch"
grep -q '"version": "3.4.3"' app/routes/api.py || fail "API health/version mismatch"
pass "release identity is consistently v3.4.3"

[ "$(alembic heads | awk '{print $1}')" = "c43a7d9e2f10" ] || fail "Alembic head mismatch"
python -m py_compile app/services/client_data_form.py app/routes/intake.py app/routes/client.py app/routes/commercial.py app/models.py app/main.py
pass "v3.4.3 intake/document modules compile"

grep -q 'content_blob' app/models.py || fail "commercial attachment DB blob missing"
grep -q '_create_intake_asset' app/routes/intake.py || fail "controlled intake asset creation missing"
grep -q 'CLIENT_ACCEPTED' app/routes/intake.py || fail "accepted quotation handoff support missing"
grep -q 'case_data_form_payload' app/routes/intake.py || fail "linked Client Data Form intake prefill missing"
pass "intake continuity controls are present"

TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
TSCO_DATA_DIR="$TMP/data" DATABASE_URL="sqlite:///$TMP/clean.db" alembic upgrade head >/dev/null
[ -f "$TMP/clean.db" ] || fail "clean database migration did not create DB"
CURRENT_HEAD="$(TSCO_DATA_DIR="$TMP/data" DATABASE_URL="sqlite:///$TMP/clean.db" alembic current | awk '{print $1}')"
[ "$CURRENT_HEAD" = "c43a7d9e2f10" ] || fail "clean DB did not reach v3.4.3 head"
pass "clean database upgrades to c43a7d9e2f10"

pytest -q --disable-warnings \
  tests/test_v327_multi_sample_intake_ux.py \
  tests/test_v328_client_request_scope.py \
  tests/test_v329_client_self_service.py \
  tests/test_v330_intake_request_matching.py \
  tests/test_v331_request_logistics.py \
  tests/test_v340_standalone_closeout.py \
  tests/test_v341_final_analysis_report.py \
  tests/test_v342_senior_final_report_review.py \
  tests/test_v343_intake_continuity_hotfix.py
pass "current intake/client/commercial/report regression set passed"

echo "V3.4.3_RELEASE_VERIFICATION=PASS"
