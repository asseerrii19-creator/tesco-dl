#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }
[ "$(tr -d '\r\n ' < VERSION)" = "3.4.4" ] || fail "VERSION is not 3.4.4"
grep -q 'version = "3.4.4"' pyproject.toml || fail "pyproject version mismatch"
grep -q 'version="3.4.4"' app/main.py || fail "FastAPI version mismatch"
grep -q '"version": "3.4.4"' app/routes/api.py || fail "API health/version mismatch"
pass "release identity is consistently v3.4.4"
[ "$(alembic heads | awk '{print $1}')" = "c43a7d9e2f10" ] || fail "Alembic head mismatch"
python -m py_compile app/services/client_data_form.py app/routes/intake.py app/main.py
pass "v3.4.4 modules compile"
grep -q 'sync_all_missing_sample_metadata_from_data_forms' app/main.py || fail "startup backfill missing"
grep -q 'sync-client-data-form' app/routes/intake.py || fail "Data Entry manual sync route missing"
grep -q 'Sampling Data / Client Data Form' app/templates/intake_review.html || fail "Data Entry sampling metadata view missing"
pass "backfill controls are present"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
TSCO_DATA_DIR="$TMP/data" DATABASE_URL="sqlite:///$TMP/clean.db" alembic upgrade head >/dev/null
CURRENT_HEAD="$(TSCO_DATA_DIR="$TMP/data" DATABASE_URL="sqlite:///$TMP/clean.db" alembic current | awk '{print $1}')"
[ "$CURRENT_HEAD" = "c43a7d9e2f10" ] || fail "clean DB head mismatch"
pass "clean database upgrades to c43a7d9e2f10"
pytest -q --disable-warnings \
  tests/test_v327_multi_sample_intake_ux.py \
  tests/test_v328_client_request_scope.py \
  tests/test_v329_client_self_service.py \
  tests/test_v330_intake_request_matching.py \
  tests/test_v331_request_logistics.py \
  tests/test_v340_standalone_closeout.py \
  tests/test_v341_final_analysis_report.py \
  tests/test_v342_senior_final_report_review.py \
  tests/test_v343_intake_continuity_hotfix.py \
  tests/test_v344_data_form_backfill.py
pass "current intake/client/commercial/report regression set passed"
echo "V3.4.4_RELEASE_VERIFICATION=PASS"
