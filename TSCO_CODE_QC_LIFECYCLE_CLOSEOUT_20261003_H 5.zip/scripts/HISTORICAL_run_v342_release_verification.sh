#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }

[ "$(tr -d '\r\n ' < VERSION)" = "3.4.2" ] || fail "VERSION is not 3.4.2"
grep -q 'version = "3.4.2"' pyproject.toml || fail "pyproject version mismatch"
grep -q 'version="3.4.2"' app/main.py || fail "FastAPI version mismatch"
grep -q '"version": "3.4.2"' app/routes/api.py || fail "API health/version mismatch"
pass "release identity is consistently v3.4.2"

[ "$(alembic heads | awk '{print $1}')" = "b17f4c8d9e20" ] || fail "Alembic head mismatch"
python -m py_compile app/services/final_report_pdf.py app/services/final_report_data.py app/routes/control_center.py app/routes/intake.py
pass "core report/intake modules compile"

[ ! -d app/integrations/lms ] || fail "active LMS connector directory exists"
if grep -RInE 'APPROVE ALL FOR LMS|APPROVE FOR LMS|external_lms|REGISTER_LMS' app/templates app/lab_ops app/routes/intake.py >/tmp/tsco_v342_lms_ui_hits.txt 2>/dev/null; then
  cat /tmp/tsco_v342_lms_ui_hits.txt >&2
  fail "active UI/intake contract still exposes an LMS action"
fi
pass "active user workflow is LMS-independent"

grep -q 'Senior Final Report Review' app/templates/senior_final_report_review.html || fail "Senior report review workspace missing"
grep -q 'Quick Result Check' app/templates/senior_final_report_review.html || fail "Senior quick-result cards missing"
grep -q 'Technical Review Complete' app/templates/senior_final_report_review.html || fail "Senior completion control missing"
grep -q "row.status != 'PENDING_MANAGER_APPROVAL'" app/routes/control_center.py || fail "manager approval gate missing"
pass "Senior Final Report Review is enforced before manager approval"

grep -q 'QDF-\[7\]-08-A' app/services/final_report_pdf.py || fail "official report template code missing"
grep -q 'Direct DP-value on Paper Sample' app/services/final_report_data.py || fail "direct-paper report model missing"
grep -q 'official_pdf_sha256' app/models.py || fail "official PDF integrity metadata missing"
pass "official Final Analysis Report controls are present"

TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
TSCO_DATA_DIR="$TMP/data" DATABASE_URL="sqlite:///$TMP/clean.db" alembic upgrade head >/dev/null
[ -f "$TMP/clean.db" ] || fail "clean database migration did not create DB"
pass "clean database upgrades to current head"

timeout -k 2s 55s pytest -q --disable-warnings
pass "configured release regression suite passed"

pytest -q --disable-warnings tests/test_v282_polished_review.py::test_report_preview_groups_direct_paper_separately_and_special_panel_combines_with_corrosion
pass "direct-paper / corrosion specialty preview regression passed in isolation"

echo "V3.4.2_RELEASE_VERIFICATION=PASS"
