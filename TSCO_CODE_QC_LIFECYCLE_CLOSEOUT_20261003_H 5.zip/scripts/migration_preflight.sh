#!/bin/sh
set -eu
ENV_FILE=${1:-.env.production}
COMPOSE_FILE=${COMPOSE_FILE:-docker-compose.production.yml}
[ -f "$ENV_FILE" ] || { echo "Missing $ENV_FILE" >&2; exit 1; }
echo "1/4 Validate compose configuration"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" config >/dev/null
echo "2/4 Build application image"
docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" build web >/dev/null
echo "3/4 Verify exactly one Alembic head"
HEADS=$(docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" run --rm web alembic heads | grep -c '(head)' || true)
[ "$HEADS" -eq 1 ] || { echo "Expected one Alembic head, found $HEADS" >&2; exit 1; }
echo "4/4 Reminder: create ./scripts/production_backup.sh bundle immediately before migration"
echo "PASS: migration preflight complete"
