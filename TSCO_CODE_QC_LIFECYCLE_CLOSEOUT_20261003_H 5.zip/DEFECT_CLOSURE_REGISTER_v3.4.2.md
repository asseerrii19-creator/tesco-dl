# Defect Closure Register — v3.4.2

This register consolidates the high-impact defects identified during the late-September UAT cycle and the subsequent standalone closeout.

| Area | Defect / inconsistency | v3.4.2 treatment |
|---|---|---|
| Persistence | UI could report Save success even when central API persistence failed | Server-authoritative mutation; failed save restores prior state and cannot advance completion |
| Identity | Analyst could be inferred from assignment instead of authenticated actor | Result save uses authenticated user identity |
| Workstation UX | Save collapsed/left the active workstation and disrupted sequential entry | Open sample/workstation context preserved after successful save |
| Assignment | Completion/status/counters could remain stale | Completion is gated by required results/evidence and persisted state |
| Water | Technician was forced to enter oil temperature as a second result | Intake/Data Form temperature is read-only; technician enters KF result only |
| DGA | CSV import omitted TCG, total volume and equilibrium pressure | Import coverage extended and source evidence retained |
| BDV | Incorrect run-count behavior and manual summary risk | Six controlled readings; Average/RSD calculated; evidence retained |
| PF | 25 °C / 100 °C pair not treated as controlled instrument result set | Pair handled as one controlled result workflow |
| OQI | Manual entry allowed for a calculated value | Calculation-only |
| Appearance/Color | Free-text entry allowed uncontrolled values | Controlled selections; abnormal evidence support |
| Reports | Lab Result Worksheet also contained official approval actions | Worksheet is internal/read-only for release authority |
| Final report template | Official client report structure was not represented by the internal Result Worksheet | Added QDF-[7]-08-A-aligned Final Analysis Report with condition, client/equipment/sampling data, historical analytical tables, interpretation, evidence, trends and recommendation |
| Report artifact integrity | Official release could exist only as mutable screen data | Technical Manager approval now generates an immutable PDF artifact and stores SHA-256 integrity metadata |
| Report terminology | Internal worksheet and official report could be confused as two competing final reports | UI now explicitly separates Result Worksheet (internal) from Final Analysis Report (official client document) |
| Report history | Client report needed current + previous results like the laboratory reference | Final Analysis Report builds current plus up to three prior released report columns for the same asset |
| Corrosive evidence | Official report needed the controlled sulfur evidence image | Corrosive Sulfur report section includes retained image evidence when requested/available |
| Final report | Duplicate/competing approval path existed | Final Analysis Report is the single official TSCO client-release path |
| Senior final report review | Official report could advance without a dedicated Senior whole-report verification workspace | Mandatory Senior Final Report Review now embeds full report preview, Quick Result Check cards, automatic gates, editable Condition/Interpretation/Recommendation, draft save and five confirmations before manager handoff |
| LMS | Active workflow/config depended on external LMS boundary | Removed from active workflow and deployment configuration; legacy data only |
| Commercial stages | Proposal and Purchase Order/PO Received duplicated mandatory flow | Canonical Request → Quotation → Client Decision → PO Received → Complete Handover |
| Client portal | Client could not fully act on quotation/PO flow | Quote visibility/decision and controlled PO upload added |
| Coordinator | Submitted client request could exist without useful owner | Automatic eligible coordinator assignment with controlled reassignment |
| Operations | Pending request metric could ignore completed commercial handovers | Operations overview includes handovers awaiting operational action |
| Sample identity | Multi-sample handling risked conflating serials/records | Individual sample records with unique IDs/barcodes and asset serials preserved |
| Report grouping | Group-order labels could mismatch and silently hide sections | Canonical group names plus fallback rendering prevent silent omission |
| Invoice | Invoicing could be interpreted as a local lab action | Local workflow stops at Corporate Administration Handoff |
| Versioning | Package/UI/API exposed mixed release identities | Current release identity unified to v3.4.2 |
| Deployment | LMS env/config remained even after standalone decision | LMS deployment variables removed from Compose, Render and env examples |
| Local review / bundled DB | Bundled SQLite schema could lag the current models and fail before login | Runtime DB is not shipped as release state; local launch scripts run `alembic upgrade head` before Uvicorn and verification migrates a fresh SQLite database to head |

The final release gate is the automated verification script plus manual UAT of real business data and company-controlled infrastructure/security acceptance.
