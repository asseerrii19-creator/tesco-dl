from __future__ import annotations

import os
from sqlalchemy import create_engine, event
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from .storage import DATA_DIR

DEFAULT_DB = f"sqlite:///{(DATA_DIR / 'tsco_platform.db').as_posix()}"
DATABASE_URL = os.getenv("DATABASE_URL", "").strip()
if DATABASE_URL.startswith("postgresql://"):
    DATABASE_URL = "postgresql+psycopg://" + DATABASE_URL[len("postgresql://"):]
_RUNTIME_ENV = os.getenv("APP_ENV", "development").strip().lower()
_ON_RENDER = os.getenv("RENDER", "").strip().lower() in {"1", "true", "yes"}
if not DATABASE_URL:
    if _ON_RENDER or _RUNTIME_ENV in {"uat", "staging", "production", "prod"}:
        raise RuntimeError("DATABASE_URL is required for Render/UAT/production; refusing ephemeral SQLite fallback")
    DATABASE_URL = DEFAULT_DB

connect_args = {"check_same_thread": False, "timeout": 30} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args, future=True)

if DATABASE_URL.startswith("sqlite"):
    @event.listens_for(engine, "connect")
    def _sqlite_foreign_keys_on(dbapi_connection, _connection_record):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


class Base(DeclarativeBase):
    pass


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
