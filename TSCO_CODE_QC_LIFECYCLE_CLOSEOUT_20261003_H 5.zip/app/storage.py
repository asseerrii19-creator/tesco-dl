from __future__ import annotations

import os
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
_configured_data_dir = os.getenv("TSCO_DATA_DIR", "").strip()
_RUNTIME_ENV = os.getenv("APP_ENV", "development").strip().lower()
_ON_RENDER = os.getenv("RENDER", "").strip().lower() in {"1", "true", "yes"}
if (_ON_RENDER or _RUNTIME_ENV in {"uat", "staging", "production", "prod"}) and not _configured_data_dir:
    raise RuntimeError("TSCO_DATA_DIR is required for Render/UAT/production; controlled files must use persistent storage")
DATA_DIR = Path(_configured_data_dir or str(APP_DIR / "data")).expanduser().resolve()
UPLOAD_DIR = DATA_DIR / "uploads"
BARCODE_DIR = DATA_DIR / "barcodes"
CONTROLLED_DOCUMENT_DIR = DATA_DIR / "controlled_documents"

for directory in (DATA_DIR, UPLOAD_DIR, BARCODE_DIR, CONTROLLED_DOCUMENT_DIR):
    directory.mkdir(parents=True, exist_ok=True)
