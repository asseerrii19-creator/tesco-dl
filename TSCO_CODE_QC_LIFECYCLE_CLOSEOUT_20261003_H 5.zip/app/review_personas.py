from __future__ import annotations

from dataclasses import dataclass
from .models import Role


@dataclass(frozen=True)
class ReviewPersona:
    email: str
    title: str
    organization_area: str
    role: str
    reports_to: str
    leave_approver: str
    needs: tuple[str, ...]
    boundaries: tuple[str, ...]
    senior_domain: str = ""


# UAT identities are position-based and contain only current local TSCO
# personas required by the approved workflow. Parent-company functions remain external
# handoff boundaries and are not represented as local employee accounts.
REVIEW_PERSONAS: tuple[ReviewPersona, ...] = (
    ReviewPersona("general.manager@tsco.local", "General Manager", "General Management", Role.MANAGEMENT.value, "External / Board", "External / Board",
        ("Executive overview", "Organization / staffing", "Operational Project approval", "Continuous Improvement governance", "Direct-report approvals"),
        ("No routine sample/result entry", "No routine QC execution", "No self-approval of leave")),
    ReviewPersona("excellence.specialist@tsco.local", "Excellence Specialist", "General Management", Role.EXCELLENCE.value, "General Manager", "General Manager",
        ("Continuous Improvement governance", "Validation / Verification governance", "Audit & findings", "QC/equipment trend visibility", "Controlled evidence / archive"),
        ("No routine analytical result entry", "No Senior technical approval", "No equipment maintenance execution")),
    ReviewPersona("secretary@tsco.local", "Secretary", "General Management", Role.CORPORATE_SUPPORT.value, "General Manager", "General Manager",
        ("GM office coordination", "Correspondence & follow-up", "Meetings & calendar", "Notifications", "Employee directory", "Own leave plan"),
        ("No laboratory operations", "No samples/results/QC", "No technical approvals", "No commercial workflow ownership")),
    ReviewPersona("sales.marketing.specialist@tsco.local", "Sales & Marketing Specialist", "Sales & Marketing Department", Role.SALES_MARKETING.value, "General Manager", "General Manager",
        ("Lead generation", "Commercial relationship", "Proposal preparation", "Quotation/PO visibility", "Sales collaboration"),
        ("No controlled Quotation/PO ownership", "No operational handover authority", "No laboratory result entry")),
    ReviewPersona("salesman@tsco.local", "Salesman", "Sales & Marketing Department", Role.SALES_MARKETING.value, "General Manager", "General Manager",
        ("Prospect / lead follow-up", "Client visits / communication", "Opportunity updates", "Proposal support"),
        ("No controlled Quotation/PO ownership", "No operational handover authority", "No laboratory result entry")),
    ReviewPersona("field.manager@tsco.local", "Field Operational & Technical Manager", "Dammam & Bahrain Labs · Field Operations", Role.OPERATIONS_MANAGER.value, "General Manager", "General Manager",
        ("Field operations", "Official Sampling Orders", "Project / field planning", "Supervisor oversight", "Fallback assignment", "Field leave oversight / fallback escalation"),
        ("No routine analytical result entry", "No laboratory QC execution", "No Senior technical approval")),
    ReviewPersona("sampling.supervisor@tsco.local", "Sampling Supervisor", "Dammam & Bahrain Labs · Field Operations", Role.SAMPLING_SUPERVISOR.value, "Field Operational & Technical Manager", "Field Operational & Technical Manager",
        ("Named Sampleman assignment/reassignment", "Field readiness", "Sample Kit readiness", "Overtime request preparation", "Sampleman leave approval / coverage"),
        ("No official Operations Order ownership", "No overtime approval", "No laboratory result entry")),
    ReviewPersona("data.entry@tsco.local", "Data Entry", "Dammam & Bahrain Labs · Intake / Receiving", Role.DATA_ENTRY.value, "Field Operational & Technical Manager", "Field Operational & Technical Manager",
        ("Receiving / intake", "Registration", "Labels", "Priority/TAT", "Batch & laboratory release", "Chain of Custody"),
        ("No separate Receiving persona", "No analytical result entry", "No Senior review", "No final TSCO report release")),
    ReviewPersona("sampleman@tsco.local", "Sampleman", "Dammam & Bahrain Labs · Field Operations", Role.FIELD_SAMPLER.value, "Sampling Supervisor", "Sampling Supervisor",
        ("Assigned field work", "Sampling / pickup / delivery evidence", "Sample Kit preparation task", "Own availability"),
        ("No unassigned TSCO field work", "No laboratory result entry", "No retained-sample disposition authority")),
    ReviewPersona("client.coordinator@tsco.local", "Client Account & Coordination Officer", "Dammam & Bahrain Labs · Field Operations", Role.CLIENT_COORDINATOR.value, "Field Operational & Technical Manager", "Field Operational & Technical Manager",
        ("Assigned Business Cases", "Controlled Quotation / PO", "Operational handover", "Client follow-up", "Released-report submission record"),
        ("No analytical result entry", "No technical approval", "No finance/payment closure")),
    ReviewPersona("external.coordination@tsco.local", "External Coordination Officer", "Dammam & Bahrain Labs · Field Operations", Role.CLIENT_COORDINATOR.value, "Field Operational & Technical Manager", "Field Operational & Technical Manager",
        ("External/client communication", "Follow-up history", "Permitted attachments", "Quotation/PO/handover visibility"),
        ("No controlled Quotation/PO ownership", "No Complete Handover authority", "No technical approval")),
    ReviewPersona("lab.manager@tsco.local", "Lab Operational & Technical Manager", "Dammam & Bahrain Labs · Laboratory Operations", Role.TECHNICAL_MANAGER.value, "General Manager", "General Manager",
        ("Laboratory management", "Workload / technical oversight", "Senior responsibilities", "Final report approval/stamp", "Controlled technical adoption", "Laboratory leave approvals"),
        ("No routine analyst result entry", "No field execution", "No IT/admin substitution for business approval")),
    ReviewPersona("senior.technical@tsco.local", "Senior Chemist — Technical", "Dammam & Bahrain Labs · Laboratory Operations", Role.SENIOR_CHEMIST.value, "Lab Operational & Technical Manager", "Lab Operational & Technical Manager",
        ("Technical review", "Methods/SOPs/EOPs technical review", "Method troubleshooting", "Retest/resample authority", "Report review", "Gas supply requests"),
        ("No final manager approval/stamp", "No direct client/final report release"), "TECHNICAL"),
    ReviewPersona("senior.equipment@tsco.local", "Senior Chemist — Equipment & Maintenance", "Dammam & Bahrain Labs · Laboratory Operations", Role.SENIOR_CHEMIST.value, "Lab Operational & Technical Manager", "Lab Operational & Technical Manager",
        ("Equipment Master", "Calibration / verification / maintenance", "Equipment troubleshooting", "QC drift disposition", "Report review", "Equipment purchase requests"),
        ("No final manager approval/stamp", "No routine blanket QC execution"), "EQUIPMENT"),
    ReviewPersona("senior.improvement@tsco.local", "Senior Chemist — Continuous Improvement", "Dammam & Bahrain Labs · Laboratory Operations", Role.SENIOR_CHEMIST.value, "Lab Operational & Technical Manager", "Lab Operational & Technical Manager",
        ("Assigned technical improvement", "Validation / verification follow-up", "Audit evidence follow-up", "Report review", "Excellence coordination"),
        ("No Excellence governance substitution", "No final manager approval/stamp"), "IMPROVEMENT"),
    ReviewPersona("chemist@tsco.local", "Chemist", "Dammam & Bahrain Labs · Laboratory Operations", Role.LAB_TECHNICIAN.value, "Lab Operational & Technical Manager", "Lab Operational & Technical Manager",
        ("Assigned analytical work", "Required Test QC", "Result entry", "Authorized retest", "Assigned validation runs", "Controlled references / troubleshooting"),
        ("No Senior technical approval", "No final report approval", "No self-assignment")),
    ReviewPersona("technician@tsco.local", "Chemical Technician", "Dammam & Bahrain Labs · Laboratory Operations", Role.LAB_TECHNICIAN.value, "Lab Operational & Technical Manager", "Lab Operational & Technical Manager",
        ("Assigned analytical work", "Required Test QC", "Result entry", "Authorized retest", "Assigned validation runs", "Controlled references / troubleshooting"),
        ("No Senior technical approval", "No final report approval", "No self-assignment")),
    ReviewPersona("lab.support@tsco.local", "Glassware Cleaning", "Dammam & Bahrain Labs · Laboratory Operations", Role.LAB_SUPPORT.value, "Lab Operational & Technical Manager", "Lab Operational & Technical Manager",
        ("Glassware / cleaning support", "Assigned housekeeping support", "Notifications", "Own availability"),
        ("No analytical result entry", "No QC approval", "No technical review", "No report release")),
)

REVIEW_PERSONA_BY_EMAIL = {p.email.lower(): p for p in REVIEW_PERSONAS}
