from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import EquipmentAsset, Role, Site, TroubleshootingRecord, TroubleshootingNote, TroubleshootingResolutionRevision, ExternalTechnicalEvidence
from ..security import require_user
from ..services.capabilities import is_senior_technical, is_senior_equipment, is_lab_manager

router = APIRouter(tags=["troubleshooting knowledge"])
ALLOWED = {
    Role.LAB_TECHNICIAN.value, Role.SENIOR_CHEMIST.value, Role.QUALITY.value,
    Role.TECHNICAL_MANAGER.value, Role.EXCELLENCE.value,
}


def _site(db: Session, user) -> Site:
    site = db.get(Site, user.site_id) if user.site_id else None
    return site or db.scalar(select(Site).where(Site.code == "DMM"))


@router.get("/troubleshooting")
def knowledge(request: Request, q: str = "", db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    site = _site(db, user)
    published = db.scalars(
        select(TroubleshootingRecord)
        .where(TroubleshootingRecord.site_id == site.id, TroubleshootingRecord.status == "PUBLISHED")
        .order_by(TroubleshootingRecord.updated_at.desc())
    ).all()
    if q.strip():
        needle = q.strip().lower()
        published = [r for r in published if needle in " ".join([
            r.test_name or "", r.method_name or "", r.workstation or "", r.problem or "",
            r.symptoms or "", r.root_cause or "", r.actions_taken or "", r.lessons or "",
        ]).lower()]
    mine = db.scalars(
        select(TroubleshootingRecord)
        .where(TroubleshootingRecord.site_id == site.id, TroubleshootingRecord.created_by_id == user.id,
               TroubleshootingRecord.status != "PUBLISHED")
        .order_by(TroubleshootingRecord.updated_at.desc())
        .limit(50)
    ).all()
    equipment = db.scalars(
        select(EquipmentAsset).where(EquipmentAsset.site_id == site.id, EquipmentAsset.active.is_(True)).order_by(EquipmentAsset.equipment_id)
    ).all()
    visible_records = {r.id for r in published + mine}
    # Seniors and the Technical Manager need active routed cases as well as published knowledge.
    if user.role in {Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value}:
        active = list(db.scalars(select(TroubleshootingRecord).where(TroubleshootingRecord.site_id==site.id, TroubleshootingRecord.status!="PUBLISHED").order_by(TroubleshootingRecord.updated_at.desc()).limit(100)).all())
        for r in active:
            if r.id not in visible_records: mine.append(r); visible_records.add(r.id)
    notes = list(db.scalars(select(TroubleshootingNote).where(TroubleshootingNote.troubleshooting_record_id.in_(visible_records))).all()) if visible_records else []
    resolutions = list(db.scalars(select(TroubleshootingResolutionRevision).where(TroubleshootingResolutionRevision.troubleshooting_record_id.in_(visible_records)).order_by(TroubleshootingResolutionRevision.revision.desc())).all()) if visible_records else []
    external = list(db.scalars(select(ExternalTechnicalEvidence).where(ExternalTechnicalEvidence.troubleshooting_record_id.in_(visible_records)).order_by(ExternalTechnicalEvidence.created_at.desc())).all()) if visible_records else []
    notes_by={}; resolutions_by={}; external_by={}
    for x in notes: notes_by.setdefault(x.troubleshooting_record_id,[]).append(x)
    for x in resolutions: resolutions_by.setdefault(x.troubleshooting_record_id,[]).append(x)
    for x in external: external_by.setdefault(x.troubleshooting_record_id,[]).append(x)
    return templates.TemplateResponse("troubleshooting_knowledge.html", {
        "request": request, "user": user, "site": site, "published": published, "mine": mine,
        "equipment": equipment, "q": q, "notes_by":notes_by, "resolutions_by":resolutions_by, "external_by":external_by,
        "is_senior_technical":is_senior_technical(user), "is_senior_equipment":is_senior_equipment(user), "is_lab_manager":is_lab_manager(user),
    })
