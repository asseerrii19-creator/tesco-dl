from __future__ import annotations

import hashlib
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, RedirectResponse
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import Role, Site, User, HousekeepingTask, HousekeepingObservation, GlasswareBatch, Notification
from ..security import require_user
from ..services.audit import add_audit
from ..storage import UPLOAD_DIR

router = APIRouter(tags=["laboratory support"])
HOUSEKEEPING_VIEW = {Role.LAB_TECHNICIAN.value, Role.LAB_SUPPORT.value, Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value}
HOUSEKEEPING_CONTRIBUTE = {Role.LAB_TECHNICIAN.value, Role.LAB_SUPPORT.value, Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value}
HOUSEKEEPING_CREATE = {Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value}
HOUSEKEEPING_DISPOSITION = {Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value}
GLASSWARE_VIEW = {Role.LAB_SUPPORT.value, Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value}
GLASSWARE_WRITE = {Role.LAB_SUPPORT.value, Role.TECHNICAL_MANAGER.value}
EVIDENCE_DIR = UPLOAD_DIR / "housekeeping"
EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
MAX_IMAGE = 10 * 1024 * 1024
IMAGE_TYPES = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}


def _site(db: Session, user: User) -> Site:
    site = db.get(Site, user.site_id) if user.site_id else None
    site = site or db.scalar(select(Site).where(Site.code == "DMM"))
    if not site: raise ValueError("Active laboratory site is required")
    return site


def _dt(value: str | None) -> datetime | None:
    if not value: return None
    return datetime.fromisoformat(value.replace("Z", "+00:00")).replace(tzinfo=None)


def _is_equipment_senior(user: User) -> bool:
    return user.role == Role.SENIOR_CHEMIST.value and str(user.senior_responsibility_domain or "").upper() == "EQUIPMENT"


async def _save_image(upload: UploadFile | None, *, required: bool = False) -> str:
    if not upload or not upload.filename:
        if required: raise ValueError("A completion/evidence photo is required")
        return ""
    content_type = (upload.content_type or "").lower()
    if content_type not in IMAGE_TYPES:
        raise ValueError("Housekeeping evidence must be JPG, PNG or WEBP")
    raw = await upload.read()
    if not raw:
        if required: raise ValueError("Evidence photo is empty")
        return ""
    if len(raw) > MAX_IMAGE: raise ValueError("Evidence photo must be 10 MB or smaller")
    # Verify image bytes, not only browser MIME metadata.
    from PIL import Image
    from io import BytesIO
    try:
        image = Image.open(BytesIO(raw)); image.verify()
    except Exception:
        raise ValueError("Evidence file is not a valid image")
    digest = hashlib.sha256(raw).hexdigest(); path = EVIDENCE_DIR / f"{digest}{IMAGE_TYPES[content_type]}"
    if not path.exists(): path.write_bytes(raw)
    return str(path)


@router.get("/housekeeping")
def housekeeping(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, HOUSEKEEPING_VIEW); site = _site(db, user)
    task_stmt = select(HousekeepingTask).where(HousekeepingTask.site_id == site.id)
    if user.role in {Role.LAB_TECHNICIAN.value, Role.LAB_SUPPORT.value}:
        task_stmt = task_stmt.where(HousekeepingTask.assigned_to_id == user.id)
    elif user.role == Role.SENIOR_CHEMIST.value and not _is_equipment_senior(user):
        # Other Seniors may see their own assigned area only; equipment/facility ownership stays with Equipment Senior.
        task_stmt = task_stmt.where(HousekeepingTask.assigned_to_id == user.id)
    tasks = list(db.scalars(task_stmt.order_by(HousekeepingTask.created_at.desc()).limit(200)).all())
    obs_stmt = select(HousekeepingObservation).where(HousekeepingObservation.site_id == site.id)
    if user.role in {Role.LAB_TECHNICIAN.value, Role.LAB_SUPPORT.value}:
        obs_stmt = obs_stmt.where(HousekeepingObservation.raised_by_id == user.id)
    elif user.role == Role.SENIOR_CHEMIST.value:
        domain = str(user.senior_responsibility_domain or "TECHNICAL").upper()
        obs_stmt = obs_stmt.where(HousekeepingObservation.routed_domain == domain)
    observations = list(db.scalars(obs_stmt.order_by(HousekeepingObservation.created_at.desc()).limit(150)).all())
    assignable = []
    can_create = user.role == Role.TECHNICAL_MANAGER.value or _is_equipment_senior(user)
    if can_create:
        assignable = list(db.scalars(select(User).where(User.site_id == site.id, User.active.is_(True), User.role.in_([Role.LAB_TECHNICIAN.value, Role.LAB_SUPPORT.value])).order_by(User.full_name)).all())
    return templates.TemplateResponse("housekeeping.html", {"request": request, "user": user, "site": site, "tasks": tasks, "observations": observations, "assignable": assignable, "can_create": can_create, "can_disposition": user.role in HOUSEKEEPING_DISPOSITION})


@router.post("/housekeeping/tasks")
def create_housekeeping_task(request: Request, area_zone: str = Form(...), assigned_to_id: int = Form(...), due_at: str = Form(""), shift_code: str = Form(""), db: Session = Depends(get_db)):
    actor = require_user(request, db, HOUSEKEEPING_CREATE); site = _site(db, actor)
    if actor.role == Role.SENIOR_CHEMIST.value and not _is_equipment_senior(actor):
        raise HTTPException(403, "Housekeeping/facility task ownership belongs to Senior Chemist — Equipment & Maintenance")
    employee = db.get(User, assigned_to_id)
    if not employee or not employee.active or employee.site_id != site.id or employee.role not in {Role.LAB_TECHNICIAN.value, Role.LAB_SUPPORT.value}:
        raise ValueError("Housekeeping task must be assigned to an active laboratory employee at this site")
    if not area_zone.strip(): raise ValueError("Area / zone is required")
    row = HousekeepingTask(site_id=site.id, area_zone=area_zone.strip(), assigned_to_id=employee.id, due_at=_dt(due_at), shift_code=shift_code.strip(), status="DUE", created_by_id=actor.id)
    db.add(row); db.flush(); add_audit(db, actor=actor, request=request, action="HOUSEKEEPING_TASK_ASSIGN", entity_type="HousekeepingTask", entity_id=row.id, summary=f"{row.area_zone} → {employee.full_name}")
    db.commit(); return RedirectResponse("/housekeeping", 303)


@router.post("/housekeeping/tasks/{task_id}/start")
def start_housekeeping(task_id: int, request: Request, db: Session = Depends(get_db)):
    actor = require_user(request, db, {Role.LAB_TECHNICIAN.value, Role.LAB_SUPPORT.value}); row = db.get(HousekeepingTask, task_id)
    if not row: raise HTTPException(404, "Housekeeping task not found")
    if row.assigned_to_id != actor.id: raise HTTPException(403, "Only the assigned employee can start this task")
    if row.status not in {"DUE", "IN_PROGRESS"}: raise ValueError("Only Due tasks can be started")
    row.status = "IN_PROGRESS"; add_audit(db, actor=actor, request=request, action="HOUSEKEEPING_TASK_START", entity_type="HousekeepingTask", entity_id=row.id, summary=row.area_zone)
    db.commit(); return RedirectResponse("/housekeeping", 303)


@router.post("/housekeeping/tasks/{task_id}/complete")
async def complete_housekeeping(task_id: int, request: Request, completion_note: str = Form(...), photo: UploadFile | None = File(None), db: Session = Depends(get_db)):
    actor = require_user(request, db, {Role.LAB_TECHNICIAN.value, Role.LAB_SUPPORT.value}); row = db.get(HousekeepingTask, task_id)
    if not row: raise HTTPException(404, "Housekeeping task not found")
    if row.assigned_to_id != actor.id: raise HTTPException(403, "Only the assigned employee can complete this task")
    if row.status not in {"DUE", "IN_PROGRESS"}: raise ValueError("Task is not open")
    if not completion_note.strip(): raise ValueError("A short completion note is required")
    evidence = await _save_image(photo, required=True)
    row.status = "COMPLETED"; row.completion_note = completion_note.strip(); row.completion_photo_path = evidence; row.completed_at = datetime.utcnow()
    add_audit(db, actor=actor, request=request, action="HOUSEKEEPING_TASK_COMPLETE", entity_type="HousekeepingTask", entity_id=row.id, summary=f"{row.area_zone} · photo evidence captured")
    db.commit(); return RedirectResponse("/housekeeping", 303)


@router.post("/housekeeping/observations")
async def create_observation(request: Request, task_id: str = Form(""), category: str = Form(...), note: str = Form(...), photo: UploadFile | None = File(None), db: Session = Depends(get_db)):
    actor = require_user(request, db, HOUSEKEEPING_CONTRIBUTE); site = _site(db, actor)
    task = db.get(HousekeepingTask, int(task_id)) if task_id.strip() else None
    if task and task.site_id != site.id: raise HTTPException(403, "Task is outside your site")
    if task and actor.role in {Role.LAB_TECHNICIAN.value, Role.LAB_SUPPORT.value} and task.assigned_to_id != actor.id:
        raise HTTPException(403, "Observation is outside your assigned area")
    clean = category.strip().upper()
    if not note.strip(): raise ValueError("Observation / issue note is required")
    equipment_categories = {"BROKEN_GLASSWARE", "DAMAGED_EQUIPMENT", "SINK_DRAIN", "FACILITY", "STORAGE", "MISSING_LABEL"}
    routed = "EQUIPMENT" if clean in equipment_categories else "IMPROVEMENT" if clean in {"PROCESS", "RECURRING", "IMPROVEMENT"} else "TECHNICAL"
    row = HousekeepingObservation(task_id=task.id if task else None, site_id=site.id, raised_by_id=actor.id, category=clean, note=note.strip(), photo_path=await _save_image(photo), routed_domain=routed, status="OPEN")
    db.add(row); db.flush(); add_audit(db, actor=actor, request=request, action="HOUSEKEEPING_OBSERVATION_RAISED", entity_type="HousekeepingObservation", entity_id=row.id, summary=f"{clean} → {routed}")
    recipients = list(db.scalars(select(User).where(User.site_id == site.id, User.active.is_(True), or_(User.role == Role.TECHNICAL_MANAGER.value, (User.role == Role.SENIOR_CHEMIST.value) & (User.senior_responsibility_domain == routed)))).all())
    for recipient in recipients:
        db.add(Notification(site_id=site.id, user_id=recipient.id, category="HOUSEKEEPING", title=f"Housekeeping observation — {clean.replace('_',' ')}", message=note.strip()[:500], target_url="/housekeeping", priority="HIGH" if clean in {"UNSAFE","DAMAGED_EQUIPMENT"} else "NORMAL", email_status="PENDING_CONFIGURATION"))
    db.commit(); return RedirectResponse("/housekeeping", 303)


@router.post("/housekeeping/observations/{observation_id}/status")
def disposition_observation(observation_id: int, request: Request, status: str = Form(...), db: Session = Depends(get_db)):
    actor = require_user(request, db, HOUSEKEEPING_DISPOSITION)
    row = db.get(HousekeepingObservation, observation_id)
    if not row: raise HTTPException(404, "Observation not found")
    if actor.site_id and row.site_id != actor.site_id: raise HTTPException(403, "Observation is outside your site")
    if actor.role == Role.SENIOR_CHEMIST.value and str(actor.senior_responsibility_domain or "TECHNICAL").upper() != row.routed_domain:
        raise HTTPException(403, "Observation is routed to another Senior responsibility domain")
    clean = status.strip().upper()
    if clean not in {"OPEN", "IN_REVIEW", "CLOSED"}: raise ValueError("Unsupported observation status")
    row.status = clean
    add_audit(db, actor=actor, request=request, action="HOUSEKEEPING_OBSERVATION_STATUS", entity_type="HousekeepingObservation", entity_id=row.id, summary=f"{row.routed_domain} · {clean}")
    db.commit(); return RedirectResponse("/housekeeping", 303)


@router.get("/housekeeping/evidence/{kind}/{row_id}")
def housekeeping_evidence(kind: str, row_id: int, request: Request, db: Session = Depends(get_db)):
    actor = require_user(request, db, HOUSEKEEPING_VIEW); site = _site(db, actor)
    if kind == "task":
        row = db.get(HousekeepingTask, row_id); path = row.completion_photo_path if row else ""
        owner_id = row.assigned_to_id if row else None
    elif kind == "observation":
        row = db.get(HousekeepingObservation, row_id); path = row.photo_path if row else ""
        owner_id = row.raised_by_id if row else None
    else: raise HTTPException(404, "Evidence not found")
    if not row or row.site_id != site.id or not path: raise HTTPException(404, "Evidence not found")
    if actor.role in {Role.LAB_TECHNICIAN.value, Role.LAB_SUPPORT.value} and actor.id != owner_id: raise HTTPException(403, "Evidence is outside your scope")
    p = Path(path)
    if not p.exists(): raise HTTPException(404, "Evidence file not found")
    return FileResponse(p)


@router.get("/lab-support")
def glassware_workspace(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, GLASSWARE_VIEW); site = _site(db, user)
    rows = list(db.scalars(select(GlasswareBatch).where(GlasswareBatch.site_id == site.id).order_by(GlasswareBatch.received_at.desc(), GlasswareBatch.id.desc()).limit(300)).all())
    support_people = list(db.scalars(select(User).where(User.site_id == site.id, User.active.is_(True), User.role == Role.LAB_SUPPORT.value).order_by(User.full_name)).all())
    counts = {s: sum(1 for r in rows if r.status == s) for s in ["WAITING", "WASHING", "DRYING", "READY"]}
    return templates.TemplateResponse("lab_support.html", {"request": request, "user": user, "site": site, "rows": rows, "support_people": support_people, "counts": counts, "now": datetime.utcnow()})


@router.post("/lab-support/glassware")
def create_glassware_batch(request: Request, source_workstation: str = Form(...), glassware_type: str = Form("General"), approximate_quantity: str = Form(""), priority: str = Form("NORMAL"), assigned_to_id: str = Form(""), note: str = Form(""), db: Session = Depends(get_db)):
    actor = require_user(request, db, GLASSWARE_WRITE); site = _site(db, actor)
    priority = priority.strip().upper()
    if priority not in {"NORMAL", "HIGH", "URGENT"}: raise ValueError("Priority must be Normal, High or Urgent")
    assigned = db.get(User, int(assigned_to_id)) if assigned_to_id.strip() else (actor if actor.role == Role.LAB_SUPPORT.value else None)
    if assigned and (not assigned.active or assigned.site_id != site.id or assigned.role != Role.LAB_SUPPORT.value): raise ValueError("Glassware batch can be assigned only to Glassware Cleaning")
    qty = int(approximate_quantity) if approximate_quantity.strip() else None
    if qty is not None and qty < 0: raise ValueError("Approximate quantity cannot be negative")
    row = GlasswareBatch(site_id=site.id, batch_code="PENDING", source_workstation=source_workstation.strip(), glassware_type=glassware_type.strip() or "General", approximate_quantity=qty, priority=priority, received_at=datetime.utcnow(), status="WAITING", assigned_to_id=assigned.id if assigned else None, note=note.strip(), created_by_id=actor.id)
    if not row.source_workstation: raise ValueError("Source workstation / area is required")
    db.add(row); db.flush(); row.batch_code = f"GW-{row.id:04d}"
    add_audit(db, actor=actor, request=request, action="GLASSWARE_BATCH_CREATE", entity_type="GlasswareBatch", entity_id=row.id, summary=f"{row.batch_code} · {row.source_workstation}")
    db.commit(); return RedirectResponse("/lab-support", 303)


@router.post("/lab-support/glassware/{batch_id}/status")
def transition_glassware(batch_id: int, request: Request, status: str = Form(...), note: str = Form(""), db: Session = Depends(get_db)):
    actor = require_user(request, db, GLASSWARE_WRITE); row = db.get(GlasswareBatch, batch_id)
    if not row: raise HTTPException(404, "Glassware batch not found")
    if actor.role == Role.LAB_SUPPORT.value and row.assigned_to_id not in {None, actor.id}: raise HTTPException(403, "Glassware batch is assigned to another employee")
    target = status.strip().upper()
    transitions = {"WAITING": {"WASHING"}, "DIRTY": {"WASHING"}, "WASHING": {"DRYING"}, "DRYING": {"READY"}, "READY": {"RETURNED", "COMPLETED"}, "RETURNED": {"COMPLETED"}, "COMPLETED": set()}
    if target not in transitions.get(row.status, set()): raise ValueError(f"Invalid glassware transition: {row.status} → {target}")
    if actor.role == Role.LAB_SUPPORT.value and row.assigned_to_id is None: row.assigned_to_id = actor.id
    row.status = target
    if note.strip(): row.note = (row.note + "\n" + note.strip()).strip()
    if target == "COMPLETED": row.completed_at = datetime.utcnow()
    add_audit(db, actor=actor, request=request, action="GLASSWARE_BATCH_STATUS", entity_type="GlasswareBatch", entity_id=row.id, summary=f"{row.batch_code}: {target}")
    db.commit(); return RedirectResponse("/lab-support", 303)
