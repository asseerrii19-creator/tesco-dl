from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime
from io import BytesIO
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from fastapi.responses import FileResponse, RedirectResponse, Response
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from PIL import Image, UnidentifiedImageError

from ..database import get_db
from ..dependencies import templates
from ..models import (Asset, Client, ClientUnit, CommercialAttachment, CommercialCase, CommercialEvent, CommercialRequestLine, ControlledReport,
                      Notification, PurchaseOrder, Quotation, Role, SampleRequest, SampleStatus, Site, User)
from ..security import current_user, require_user
from ..services.audit import add_audit
from ..services.commercial import canonical_stage, parse_expected_serials, refresh_case_request_summary, request_line_expected_serials, request_scope_lines
from ..services.lab_operations import package_catalog
from ..services.capabilities import can_manage_controlled_commercial_documents
from ..services.scope import allowed_client_unit_ids, can_access_asset, can_access_sample, client_scope_labels
from ..services.workflow import STATUS_LABELS, STATUS_ORDER
from ..storage import UPLOAD_DIR

router = APIRouter(tags=["client"])

CLIENT_DELIVERY_MODES = {"CLIENT_DELIVERY", "TSCO_COLLECTION", "TBD"}
MAX_CLIENT_ATTACHMENT_BYTES = 10_000_000


def _parse_expected_arrival(value: str) -> datetime | None:
    clean = (value or "").strip()
    if not clean:
        return None
    try:
        return datetime.fromisoformat(clean)
    except ValueError as exc:
        raise ValueError("Expected sample arrival date/time is invalid") from exc


def _clean_delivery_mode(value: str) -> str:
    clean = (value or "TBD").strip().upper()
    if clean not in CLIENT_DELIVERY_MODES:
        raise ValueError("Sample route must be Client Delivery, TSCO Collection, or To Be Confirmed")
    return clean


def _validated_client_attachment(upload: UploadFile) -> tuple[bytes, str, str]:
    if not upload.filename:
        raise ValueError("Select a Data Form / client document to upload")
    raw = upload.file.read(MAX_CLIENT_ATTACHMENT_BYTES + 1)
    if not raw:
        raise ValueError("The selected client document is empty")
    if len(raw) > MAX_CLIENT_ATTACHMENT_BYTES:
        raise ValueError("Client documents must be 10 MB or smaller")
    suffix = Path(upload.filename).suffix.lower()
    content_type = (upload.content_type or "").lower()
    if content_type == "application/pdf" or suffix == ".pdf":
        if not raw.startswith(b"%PDF-"):
            raise ValueError("The uploaded PDF is invalid")
        return raw, ".pdf", "application/pdf"
    if content_type.startswith("image/") or suffix in {".jpg", ".jpeg", ".png", ".webp"}:
        try:
            with Image.open(BytesIO(raw)) as image:
                image.verify()
                fmt = (image.format or "").upper()
        except (UnidentifiedImageError, OSError, SyntaxError, ValueError):
            raise ValueError("The uploaded client image is invalid or corrupt")
        mapping = {"JPEG": (".jpg", "image/jpeg"), "PNG": (".png", "image/png"), "WEBP": (".webp", "image/webp")}
        if fmt not in mapping:
            raise ValueError("Client document images must be JPEG, PNG or WebP")
        return raw, *mapping[fmt]
    raise ValueError("Client documents must be PDF, JPEG, PNG or WebP")


def _client_site(db: Session, user: User) -> Site:
    row = db.get(Site, user.site_id) if user.site_id else db.scalar(select(Site).where(Site.code == "DMM"))
    if not row:
        raise ValueError("Active site is required")
    return row


def _client_case_code(db: Session, site: Site) -> str:
    year = datetime.utcnow().year
    prefix = f"BC-{site.code}-{year}-"
    rows = db.scalars(select(CommercialCase.case_code).where(CommercialCase.case_code.like(f"{prefix}%"))).all()
    last = 0
    for value in rows:
        try:
            last = max(last, int(value.rsplit("-", 1)[-1]))
        except Exception:
            pass
    return f"{prefix}{last + 1:04d}"


def _client_visible_packages(packages: list[dict], client: Client | None) -> list[dict]:
    """Expose only GENERAL packages plus packages explicitly scoped to this client."""
    code = (client.code if client else "").strip().upper()
    visible = []
    for package in packages:
        scope = str(package.get("scope") or "GENERAL").strip().upper()
        if scope in {"", "GENERAL", code}:
            visible.append(package)
    return visible


def _client_request_test_catalog(packages: list[dict]) -> list[dict]:
    """Client-orderable services only; hide methods, QC outputs and derived calculations."""
    excluded_fragments = (
        "rsd%", "temperature", "humidity in cellulose", "oil quality index",
        "indirect dp", "lifetime remaining", "calculation",
    )
    rows: dict[str, dict] = {}
    for package in packages:
        for item in package.get("tests", []):
            if not isinstance(item, dict):
                continue
            name = str(item.get("test") or "").strip()
            method = str(item.get("method") or "").strip().lower()
            lowered = name.lower()
            if not name or lowered.startswith("room test") or method == "calculation":
                continue
            if any(fragment in lowered for fragment in excluded_fragments):
                continue
            rows.setdefault(lowered, {"test": name})
    return sorted(rows.values(), key=lambda row: row["test"].lower())


def _client_scope_due(value: str, tat: str) -> datetime | None:
    clean = (value or "").strip()
    if tat == "EXACT_DUE":
        if not clean:
            raise ValueError("Exact Due request requires a due date/time")
        try:
            return datetime.fromisoformat(clean)
        except ValueError as exc:
            raise ValueError("Exact due date/time is invalid") from exc
    return None


def _owned_client_case(db: Session, user: User, case_id: int) -> CommercialCase:
    row = db.get(CommercialCase, case_id)
    if not row or not user.client_id or row.client_id != user.client_id or row.request_source != "CLIENT_PORTAL":
        raise ValueError("Client request was not found in this account")
    return row


def _auto_assign_client_coordinator(db: Session, case: CommercialCase) -> User | None:
    """Assign a submitted client request to the least-loaded eligible site coordinator.

    The assignment is deterministic and auditable. Operations can still reassign later.
    """
    if case.assigned_coordinator_id:
        return db.get(User, case.assigned_coordinator_id)
    rows = list(db.scalars(select(User).where(
        User.active.is_(True), User.site_id == case.site_id, User.role == Role.CLIENT_COORDINATOR.value,
    ).order_by(User.full_name, User.id)).all())
    rows = [u for u in rows if can_manage_controlled_commercial_documents(u)]
    if not rows:
        return None
    counts = dict(db.execute(
        select(CommercialCase.assigned_coordinator_id, func.count(CommercialCase.id))
        .where(CommercialCase.status == "ACTIVE", CommercialCase.assigned_coordinator_id.is_not(None))
        .group_by(CommercialCase.assigned_coordinator_id)
    ).all())
    chosen = min(rows, key=lambda u: (int(counts.get(u.id, 0)), u.full_name.lower(), u.id))
    case.assigned_coordinator_id = chosen.id
    return chosen


def _notify_case_coordinator(db: Session, case: CommercialCase, *, title: str, message: str, priority: str = "NORMAL") -> None:
    recipients: list[User] = []
    if case.assigned_coordinator_id:
        row = db.get(User, case.assigned_coordinator_id)
        if row and row.active:
            recipients.append(row)
    if not recipients:
        recipients = list(db.scalars(select(User).where(
            User.active.is_(True), User.site_id == case.site_id, User.role == Role.CLIENT_COORDINATOR.value,
        )).all())
    for recipient in recipients:
        db.add(Notification(site_id=case.site_id, user_id=recipient.id, category="CLIENT_REQUEST", title=title[:220], message=message[:500], target_url=f"/commercial?case_id={case.id}", priority=priority, email_status="PENDING_CONFIGURATION"))


@router.get("/client")
def client_dashboard(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.CLIENT.value, Role.SYSTEM_ADMIN.value})
    stmt = select(SampleRequest).order_by(SampleRequest.created_at.desc())
    scope_labels: list[str] = []
    if user.role == Role.CLIENT.value:
        stmt = stmt.where(SampleRequest.client_id == user.client_id)
        allowed_units = allowed_client_unit_ids(db, user, user.client_id)
        if allowed_units is not None:
            if allowed_units:
                stmt = stmt.join(Asset, SampleRequest.asset_id == Asset.id).where(Asset.client_unit_id.in_(allowed_units))
            else:
                stmt = stmt.where(SampleRequest.id == -1)
        scope_labels = client_scope_labels(db, user)
    samples = db.scalars(stmt.limit(100)).all()
    service_requests = []
    if user.client_id:
        service_requests = list(db.scalars(
            select(CommercialCase).where(
                CommercialCase.client_id == user.client_id, CommercialCase.request_source == "CLIENT_PORTAL"
            ).order_by(CommercialCase.updated_at.desc()).limit(100)
        ).all())
    visible_sample_ids = {row.id for row in samples if row.status == SampleStatus.REPORT_RELEASED.value}
    reports_by_sample = {}
    if visible_sample_ids:
        reports = db.scalars(
            select(ControlledReport)
            .where(ControlledReport.sample_request_id.in_(visible_sample_ids), ControlledReport.status == SampleStatus.REPORT_RELEASED.value)
            .order_by(ControlledReport.sample_request_id, ControlledReport.revision.desc(), ControlledReport.created_at.desc())
        ).all()
        for report in reports:
            reports_by_sample.setdefault(report.sample_request_id, report)
    return templates.TemplateResponse(
        "client_dashboard.html",
        {"request": request, "user": user, "samples": samples, "service_requests": service_requests, "status_labels": STATUS_LABELS, "scope_labels": scope_labels, "reports_by_sample": reports_by_sample},
    )


@router.post("/client/requests")
def start_client_request(
    request: Request, lead_title: str = Form(...), client_message: str = Form(""),
    expected_arrival_at: str = Form(""), sample_delivery_mode: str = Form("TBD"), sample_delivery_notes: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.CLIENT.value})
    if not user.client_id:
        raise ValueError("Client account is not linked to an organization")
    title = (lead_title or "").strip()
    if not title:
        raise ValueError("Request title is required")
    site = _client_site(db, user)
    row = CommercialCase(
        case_code=_client_case_code(db, site), site_id=site.id, client_id=user.client_id, owner_id=user.id,
        current_stage="LEAD_GENERATION", status="ACTIVE", lead_title=title[:220], lead_source="Client Portal",
        request_source="CLIENT_PORTAL", request_status="DRAFT", client_message=(client_message or "").strip()[:4000],
        expected_arrival_at=_parse_expected_arrival(expected_arrival_at), sample_delivery_mode=_clean_delivery_mode(sample_delivery_mode),
        sample_delivery_notes=(sample_delivery_notes or "").strip()[:4000],
    )
    db.add(row); db.flush()
    db.add(CommercialEvent(commercial_case_id=row.id, actor_id=user.id, from_stage="", to_stage="LEAD_GENERATION", note="Client service request draft opened"))
    add_audit(db, actor=user, request=request, action="CLIENT_SERVICE_REQUEST_DRAFT_CREATED", entity_type="CommercialCase", entity_id=row.id, summary=row.case_code)
    db.commit()
    return RedirectResponse(f"/client/requests/{row.id}", status_code=303)


@router.get("/client/requests/{case_id}")
def client_request_detail(case_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.CLIENT.value})
    row = _owned_client_case(db, user, case_id)
    site = _client_site(db, user)
    packages = _client_visible_packages(package_catalog(db, site.id), user.client)
    lines = request_scope_lines(db, row)
    for line in lines:
        try:
            line.requested_tests_display = ", ".join(json.loads(line.requested_tests_json or "[]"))
        except Exception:
            line.requested_tests_display = ""
        line.expected_serials_display = ", ".join(request_line_expected_serials(line))
    return templates.TemplateResponse("client_request.html", {
        "request": request, "user": user, "case": row, "lines": lines, "packages": packages,
        "request_test_catalog": _client_request_test_catalog(packages),
    })


@router.post("/client/requests/{case_id}/logistics")
def update_client_request_logistics(
    case_id: int, request: Request, expected_arrival_at: str = Form(""), sample_delivery_mode: str = Form("TBD"),
    sample_delivery_notes: str = Form(""), db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    if case.request_status != "DRAFT":
        raise ValueError("Submitted client requests are locked; contact Client Coordination for a change")
    case.expected_arrival_at = _parse_expected_arrival(expected_arrival_at)
    case.sample_delivery_mode = _clean_delivery_mode(sample_delivery_mode)
    case.sample_delivery_notes = (sample_delivery_notes or "").strip()[:4000]
    add_audit(db, actor=user, request=request, action="CLIENT_REQUEST_LOGISTICS_UPDATED", entity_type="CommercialCase", entity_id=case.id, summary=case.case_code)
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}", status_code=303)


@router.post("/client/requests/{case_id}/attachments")
def upload_client_request_attachment(
    case_id: int, request: Request, upload: UploadFile = File(...), db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    if case.request_status != "DRAFT":
        raise ValueError("Submitted client requests are locked; contact Client Coordination for a change")
    raw, ext, mime = _validated_client_attachment(upload)
    digest = hashlib.sha256(raw).hexdigest()
    folder = UPLOAD_DIR / "commercial"
    folder.mkdir(parents=True, exist_ok=True)
    stored = folder / f"case_{case.id}_{digest[:20]}{ext}"
    if not stored.exists():
        stored.write_bytes(raw)
    row = CommercialAttachment(
        commercial_case_id=case.id, document_type="CLIENT_DATA_FORM",
        original_name=Path(upload.filename or f"data-form{ext}").name[:220], stored_path=str(stored),
        content_type=mime, sha256=digest, content_blob=raw, uploaded_by_id=user.id,
    )
    db.add(row); db.flush()
    add_audit(db, actor=user, request=request, action="CLIENT_DATA_FORM_UPLOADED", entity_type="CommercialAttachment", entity_id=row.id, summary=f"{case.case_code}: {row.original_name}")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}", status_code=303)


@router.get("/client/requests/{case_id}/attachments/{attachment_id}")
def open_client_request_attachment(case_id: int, attachment_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    row = db.get(CommercialAttachment, attachment_id)
    if not row or row.commercial_case_id != case.id:
        raise ValueError("Client request attachment was not found")
    path = Path(row.stored_path or "")
    if path.is_file():
        return FileResponse(path, media_type=row.content_type or "application/octet-stream", filename=Path(row.original_name).name, content_disposition_type="inline")
    if row.content_blob:
        safe_name = Path(row.original_name).name.replace('"', '')
        return Response(content=bytes(row.content_blob), media_type=row.content_type or "application/octet-stream", headers={"Content-Disposition": f'inline; filename="{safe_name}"'})
    raise ValueError("Client request attachment file is unavailable")


@router.post("/client/requests/{case_id}/quotation-decision")
def client_quotation_decision(
    case_id: int, request: Request, decision: str = Form(...), note: str = Form(""), db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    quote = case.quotation
    if not quote:
        raise ValueError("Quotation is not available yet")
    action = (decision or "").strip().upper()
    if action not in {"ACCEPT", "REJECT"}:
        raise ValueError("Quotation decision must be Accept or Reject")
    current = canonical_stage(case.current_stage)
    if current not in {"QUOTATION", "CLIENT_FOLLOW_UP"}:
        raise ValueError("Quotation decision is no longer available at this stage")
    if action == "ACCEPT":
        quote.status = "CLIENT_ACCEPTED"
        case.request_status = "QUOTATION_ACCEPTED"
        case.client_follow_up = (note or "Client accepted quotation in portal").strip()[:4000]
        if current == "QUOTATION":
            db.add(CommercialEvent(commercial_case_id=case.id, actor_id=user.id, from_stage="QUOTATION", to_stage="CLIENT_FOLLOW_UP", note=case.client_follow_up, reference=quote.number))
            case.current_stage = "CLIENT_FOLLOW_UP"
        _notify_case_coordinator(db, case, title=f"Quotation accepted — {case.case_code}", message=f"{case.client.name} accepted quotation {quote.number}.", priority="HIGH")
    else:
        quote.status = "CLIENT_REJECTED"
        case.request_status = "QUOTATION_REJECTED"
        rejection_note = (note or "Client requested quotation revision").strip()[:4000]
        case.client_follow_up = rejection_note
        db.add(CommercialEvent(commercial_case_id=case.id, actor_id=user.id, from_stage=current, to_stage=current, note=rejection_note, reference=quote.number))
        _notify_case_coordinator(db, case, title=f"Quotation revision requested — {case.case_code}", message=f"{case.client.name} rejected / requested revision to quotation {quote.number}. {rejection_note}", priority="HIGH")
    add_audit(db, actor=user, request=request, action=f"CLIENT_QUOTATION_{action}", entity_type="CommercialCase", entity_id=case.id, summary=f"{case.case_code}: quotation {quote.number} {action.lower()}")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}", status_code=303)


@router.post("/client/requests/{case_id}/purchase-order")
def client_purchase_order_upload(
    case_id: int, request: Request, purchase_order_number: str = Form(...), upload: UploadFile = File(...), db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    quote = case.quotation
    if not quote or quote.status != "CLIENT_ACCEPTED":
        raise ValueError("Accept the current quotation before uploading the purchase order")
    current = canonical_stage(case.current_stage)
    if current not in {"CLIENT_FOLLOW_UP", "PURCHASE_ORDER_RECEIVED"}:
        raise ValueError("Purchase order upload is not available at this stage")
    number = (purchase_order_number or "").strip()[:80]
    if not number:
        raise ValueError("Purchase order number is required")
    raw, ext, mime = _validated_client_attachment(upload)
    po = db.scalar(select(PurchaseOrder).where(PurchaseOrder.client_id == case.client_id, PurchaseOrder.number == number))
    if po and po.quotation_id and po.quotation_id != quote.id:
        raise ValueError("Purchase order number is already linked to a different quotation")
    if not po:
        po = PurchaseOrder(client_id=case.client_id, quotation_id=quote.id, number=number, status="ACTIVE")
        db.add(po); db.flush()
    else:
        po.quotation_id = quote.id; po.status = "ACTIVE"
    case.purchase_order_id = po.id
    case.po_received_reference = number
    case.request_status = "PO_RECEIVED"
    digest = hashlib.sha256(raw).hexdigest()
    folder = UPLOAD_DIR / "commercial"; folder.mkdir(parents=True, exist_ok=True)
    stored = folder / f"case_{case.id}_po_{digest[:20]}{ext}"
    if not stored.exists(): stored.write_bytes(raw)
    existing = db.scalar(select(CommercialAttachment).where(
        CommercialAttachment.commercial_case_id == case.id,
        CommercialAttachment.document_type == "PURCHASE_ORDER",
        CommercialAttachment.sha256 == digest,
    ))
    if not existing:
        doc = CommercialAttachment(commercial_case_id=case.id, document_type="PURCHASE_ORDER", original_name=Path(upload.filename or f"purchase-order{ext}").name[:220], stored_path=str(stored), content_type=mime, sha256=digest, content_blob=raw, uploaded_by_id=user.id)
        db.add(doc)
    if current != "PURCHASE_ORDER_RECEIVED":
        db.add(CommercialEvent(commercial_case_id=case.id, actor_id=user.id, from_stage=current, to_stage="PURCHASE_ORDER_RECEIVED", note="Client uploaded approved purchase order in portal", reference=number))
        case.current_stage = "PURCHASE_ORDER_RECEIVED"
    _notify_case_coordinator(db, case, title=f"Purchase order received — {case.case_code}", message=f"{case.client.name} uploaded PO {number}; complete the controlled handover.", priority="HIGH")
    add_audit(db, actor=user, request=request, action="CLIENT_PURCHASE_ORDER_UPLOADED", entity_type="CommercialCase", entity_id=case.id, summary=f"{case.case_code}: PO {number} received from client")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}", status_code=303)


@router.post("/client/requests/{case_id}/lines")
def add_client_request_line(
    case_id: int, request: Request, quantity: int = Form(...), requested_package: str = Form(...),
    method_family: str = Form("DEFAULT"), priority: str = Form("NORMAL"), required_tat: str = Form(""),
    due_at: str = Form(""), expected_serials: str = Form(""), requested_tests: list[str] = Form([]), db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    if case.request_status != "DRAFT":
        raise ValueError("Submitted client requests are locked; contact Client Coordination for a change")
    if quantity < 1 or quantity > 10000:
        raise ValueError("Requested quantity must be between 1 and 10000 samples")
    site = _client_site(db, user)
    packages = package_catalog(db, site.id)
    active_names = {str(row.get("name") or "") for row in packages}
    package = (requested_package or "").strip()
    if package != "CUSTOM" and package not in active_names:
        raise ValueError("Select an available test package or Custom Tests")
    family = (method_family or "DEFAULT").strip().upper()
    if family not in {"DEFAULT", "ASTM", "IEC"}:
        raise ValueError("Method family must be Default, ASTM or IEC")
    clean_priority = (priority or "NORMAL").strip().upper()
    if clean_priority not in {"NORMAL", "HIGH", "URGENT"}:
        raise ValueError("Priority must be Normal, High or Urgent")
    tat = (required_tat or "").strip().upper()
    if tat not in {"", "12H", "24H", "EXACT_DUE"}:
        raise ValueError("Required TAT must be Standard, 12H, 24H or Exact Due")
    exact_due = _client_scope_due(due_at, tat)
    valid_test_names = {row["test"] for row in _client_request_test_catalog(packages)}
    tests = list(dict.fromkeys(str(value).strip() for value in requested_tests if str(value).strip()))
    if package == "CUSTOM":
        if not tests:
            raise ValueError("Custom Tests requires at least one requested test")
        unknown = [name for name in tests if name not in valid_test_names]
        if unknown:
            raise ValueError(f"Unknown requested test: {unknown[0]}")
    else:
        tests = []
    serials = parse_expected_serials(expected_serials)
    if len(serials) > quantity:
        raise ValueError("Expected transformer serials cannot exceed the requested sample quantity")
    next_line = (db.scalar(select(func.max(CommercialRequestLine.line_number)).where(CommercialRequestLine.commercial_case_id == case.id)) or 0) + 1
    row = CommercialRequestLine(
        commercial_case_id=case.id, line_number=next_line, quantity=quantity, requested_package=package,
        requested_tests_json=json.dumps(tests, ensure_ascii=False), expected_serials_json=json.dumps(serials, ensure_ascii=False), method_family=family, priority=clean_priority,
        required_tat=tat, due_at=exact_due, status="ACTIVE", created_by_id=user.id,
    )
    db.add(row); db.flush(); refresh_case_request_summary(db, case)
    add_audit(db, actor=user, request=request, action="CLIENT_REQUEST_SCOPE_ADDED_BY_CLIENT", entity_type="CommercialRequestLine", entity_id=row.id, summary=f"{case.case_code} line {row.line_number}: {quantity} x {package}")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}", status_code=303)


@router.post("/client/requests/{case_id}/lines/{line_id}/edit")
def edit_client_request_line(
    case_id: int, line_id: int, request: Request, quantity: int = Form(...),
    expected_serials: str = Form(""), priority: str = Form("NORMAL"),
    required_tat: str = Form(""), due_at: str = Form(""), db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    if case.request_status != "DRAFT":
        raise ValueError("Submitted client requests are locked")
    row = db.get(CommercialRequestLine, line_id)
    if not row or row.commercial_case_id != case.id or row.status != "ACTIVE":
        raise ValueError("Request scope line was not found")
    if quantity < 1 or quantity > 10000:
        raise ValueError("Sample quantity must be between 1 and 10000")
    serials = parse_expected_serials(expected_serials)
    if len(serials) > quantity:
        raise ValueError("Expected transformer serials cannot exceed the requested sample quantity")
    clean_priority = (priority or "NORMAL").strip().upper()
    if clean_priority not in {"NORMAL", "HIGH", "URGENT"}:
        raise ValueError("Priority is invalid")
    tat = (required_tat or "").strip().upper()
    if tat not in {"", "12H", "24H", "EXACT_DUE"}:
        raise ValueError("Required TAT is invalid")
    row.quantity = quantity
    row.expected_serials_json = json.dumps(serials, ensure_ascii=False)
    row.priority = clean_priority
    row.required_tat = tat
    row.due_at = _client_scope_due(due_at, tat)
    refresh_case_request_summary(db, case)
    add_audit(db, actor=user, request=request, action="CLIENT_REQUEST_SCOPE_EDITED_BY_CLIENT", entity_type="CommercialRequestLine", entity_id=row.id, summary=f"{case.case_code} line {row.line_number} edited")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}", status_code=303)


@router.post("/client/requests/{case_id}/lines/{line_id}/remove")
def remove_client_request_line(case_id: int, line_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    if case.request_status != "DRAFT":
        raise ValueError("Submitted client requests are locked")
    row = db.get(CommercialRequestLine, line_id)
    if not row or row.commercial_case_id != case.id:
        raise ValueError("Request scope line was not found")
    row.status = "REMOVED"; refresh_case_request_summary(db, case)
    add_audit(db, actor=user, request=request, action="CLIENT_REQUEST_SCOPE_REMOVED_BY_CLIENT", entity_type="CommercialRequestLine", entity_id=row.id, summary=f"{case.case_code} line {row.line_number} removed")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}", status_code=303)


@router.post("/client/requests/{case_id}/submit")
def submit_client_request(case_id: int, request: Request, client_message: str = Form(""), db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    if case.request_status != "DRAFT":
        raise ValueError("Client request is already submitted")
    lines = request_scope_lines(db, case)
    if not lines:
        raise ValueError("Add at least one requested service / test line before submitting")
    case.client_message = (client_message or case.client_message or "").strip()[:4000]
    case.request_status = "RECEIVED"
    case.client_submitted_at = datetime.utcnow()
    refresh_case_request_summary(db, case)
    assigned = _auto_assign_client_coordinator(db, case)
    assignment_note = f" Assigned coordinator: {assigned.full_name}." if assigned else " Awaiting coordinator assignment."
    db.add(CommercialEvent(commercial_case_id=case.id, actor_id=user.id, from_stage="LEAD_GENERATION", to_stage="LEAD_GENERATION", note="Client service request submitted and received by TSCO." + assignment_note))
    _notify_case_coordinator(db, case, title=f"New client request — {case.case_code}", message=f"{case.client.name}: {case.lead_title}", priority="HIGH" if case.default_priority in {"HIGH", "URGENT", "MIXED"} else "NORMAL")
    sales = list(db.scalars(select(User).where(User.active.is_(True), User.site_id == case.site_id, User.role == Role.SALES_MARKETING.value)).all())
    for recipient in sales:
        db.add(Notification(site_id=case.site_id, user_id=recipient.id, category="CLIENT_REQUEST", title=f"New client request — {case.case_code}", message=f"{case.client.name}: {case.lead_title}"[:500], target_url=f"/commercial?case_id={case.id}", priority="HIGH" if case.default_priority in {"HIGH", "URGENT", "MIXED"} else "NORMAL", email_status="PENDING_CONFIGURATION"))
    add_audit(db, actor=user, request=request, action="CLIENT_SERVICE_REQUEST_SUBMITTED", entity_type="CommercialCase", entity_id=case.id, summary=f"{case.case_code} received from client")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}", status_code=303)


@router.get("/track/{token}")
def public_tracking(token: str, request: Request, db: Session = Depends(get_db)):
    sample = db.scalar(select(SampleRequest).where(SampleRequest.public_token == token))
    if not sample:
        return templates.TemplateResponse("not_found.html", {"request": request}, status_code=404)
    public_enabled = os.getenv("ENABLE_PUBLIC_TRACKING", "false").strip().lower() in {"1", "true", "yes", "on"}
    user = current_user(request, db)
    if not public_enabled:
        if not user:
            return RedirectResponse("/login", status_code=303)
        if not can_access_sample(db, user, sample):
            return templates.TemplateResponse("not_found.html", {"request": request, "user": user}, status_code=404)
    completed = {event.status for event in sample.events}
    completed.add(sample.status)
    return templates.TemplateResponse(
        "public_track.html",
        {
            "request": request,
            "user": user,
            "sample": sample,
            "status_labels": STATUS_LABELS,
            "status_order": STATUS_ORDER,
            "completed": completed,
        },
    )
