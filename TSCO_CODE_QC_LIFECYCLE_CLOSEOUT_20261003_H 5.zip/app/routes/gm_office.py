from __future__ import annotations

import hashlib
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import RedirectResponse, FileResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import OfficeCorrespondence, OfficeMeeting, OfficeMeetingAction, Role, User, Notification
from ..security import require_user
from ..services.audit import add_audit
from ..storage import UPLOAD_DIR

router = APIRouter(prefix="/gm-office", tags=["gm office"])
SECRETARY = {Role.CORPORATE_SUPPORT.value}
EVIDENCE_DIR = UPLOAD_DIR / "gm-office"
EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
MAX_ATTACHMENT = 12 * 1024 * 1024


def _dt(value: str | None) -> datetime | None:
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00")).replace(tzinfo=None)


async def _save(upload: UploadFile | None) -> str:
    if not upload or not upload.filename:
        return ""
    raw = await upload.read()
    if not raw:
        return ""
    if len(raw) > MAX_ATTACHMENT:
        raise ValueError("GM Office attachment must be 12 MB or smaller")
    suffix = Path(upload.filename).suffix.lower()[:12]
    digest = hashlib.sha256(raw).hexdigest()
    path = EVIDENCE_DIR / f"{digest[:20]}{suffix}"
    if not path.exists():
        path.write_bytes(raw)
    return str(path)


@router.get("")
def workspace(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, SECRETARY)
    correspondence = list(db.scalars(select(OfficeCorrespondence).order_by(OfficeCorrespondence.correspondence_at.desc(), OfficeCorrespondence.id.desc()).limit(200)).all())
    meetings = list(db.scalars(select(OfficeMeeting).order_by(OfficeMeeting.meeting_at.desc(), OfficeMeeting.id.desc()).limit(120)).all())
    staff = list(db.scalars(select(User).where(User.active.is_(True)).order_by(User.full_name)).all())
    return templates.TemplateResponse("gm_office_workspace.html", {"request": request, "user": user, "correspondence": correspondence, "meetings": meetings, "staff": staff})


@router.post("/correspondence")
async def create_correspondence(
    request: Request, direction: str = Form(...), subject: str = Form(...), reference: str = Form(""),
    sender: str = Form(""), recipient: str = Form(""), correspondence_at: str = Form(...),
    responsible_user_id: str = Form(""), due_at: str = Form(""), follow_up_note: str = Form(""),
    attachment: UploadFile | None = File(None), db: Session = Depends(get_db),
):
    user = require_user(request, db, SECRETARY)
    direction = direction.strip().upper()
    if direction not in {"INCOMING", "OUTGOING"}:
        raise ValueError("Correspondence direction must be Incoming or Outgoing")
    responsible = None
    if responsible_user_id.strip():
        responsible = db.get(User, int(responsible_user_id))
        if not responsible or not responsible.active:
            raise ValueError("Responsible person is not an active employee")
    row = OfficeCorrespondence(
        direction=direction, subject=subject.strip(), reference=reference.strip(), sender=sender.strip(), recipient=recipient.strip(),
        correspondence_at=_dt(correspondence_at) or datetime.utcnow(), responsible_user_id=responsible.id if responsible else None,
        due_at=_dt(due_at), status="OPEN", follow_up_note=follow_up_note.strip(), attachment_path=await _save(attachment), created_by_id=user.id,
    )
    if not row.subject:
        raise ValueError("Correspondence subject is required")
    db.add(row); db.flush()
    add_audit(db, actor=user, request=request, action="GM_CORRESPONDENCE_CREATE", entity_type="OfficeCorrespondence", entity_id=row.id, summary=f"{direction} · {row.subject[:140]}")
    if responsible:
        db.add(Notification(site_id=responsible.site_id,user_id=responsible.id,category="GM_OFFICE",title="GM Office correspondence follow-up",message=row.subject[:500],target_url="/control/notifications",priority="NORMAL",email_status="PENDING_CONFIGURATION"))
    db.commit()
    return RedirectResponse("/gm-office#correspondence", status_code=303)


@router.post("/correspondence/{row_id}/update")
def update_correspondence(row_id: int, request: Request, status: str = Form(...), follow_up_note: str = Form(""), closure_note: str = Form(""), db: Session = Depends(get_db)):
    user = require_user(request, db, SECRETARY)
    row = db.get(OfficeCorrespondence, row_id)
    if not row:
        raise HTTPException(404, "Correspondence record not found")
    status = status.strip().upper()
    if status not in {"OPEN", "FOLLOW_UP", "CLOSED"}:
        raise ValueError("Unsupported correspondence status")
    row.status = status; row.follow_up_note = follow_up_note.strip() or row.follow_up_note
    if status == "CLOSED":
        if not closure_note.strip():
            raise ValueError("Closure note is required when closing correspondence")
        row.closure_note = closure_note.strip(); row.closed_at = datetime.utcnow()
    add_audit(db, actor=user, request=request, action="GM_CORRESPONDENCE_UPDATE", entity_type="OfficeCorrespondence", entity_id=row.id, summary=status)
    db.commit(); return RedirectResponse("/gm-office#correspondence", 303)


@router.post("/meetings")
def create_meeting(request: Request, title: str = Form(...), meeting_at: str = Form(...), attendees: str = Form(""), agenda: str = Form(""), minutes: str = Form(""), db: Session = Depends(get_db)):
    user = require_user(request, db, SECRETARY)
    when = _dt(meeting_at)
    if not title.strip() or not when:
        raise ValueError("Meeting title and date/time are required")
    row = OfficeMeeting(title=title.strip(), meeting_at=when, attendees=attendees.strip(), agenda=agenda.strip(), minutes=minutes.strip(), status="PLANNED", created_by_id=user.id)
    db.add(row); db.flush()
    add_audit(db, actor=user, request=request, action="GM_MEETING_CREATE", entity_type="OfficeMeeting", entity_id=row.id, summary=row.title[:160])
    db.commit(); return RedirectResponse("/gm-office#meetings", 303)


@router.post("/meetings/{meeting_id}/minutes")
def update_meeting(meeting_id: int, request: Request, status: str = Form(...), minutes: str = Form(""), db: Session = Depends(get_db)):
    user = require_user(request, db, SECRETARY); row = db.get(OfficeMeeting, meeting_id)
    if not row: raise HTTPException(404, "Meeting not found")
    clean = status.strip().upper()
    if clean not in {"PLANNED", "HELD", "CLOSED", "CANCELLED"}: raise ValueError("Unsupported meeting status")
    row.status = clean; row.minutes = minutes.strip() or row.minutes
    add_audit(db, actor=user, request=request, action="GM_MEETING_UPDATE", entity_type="OfficeMeeting", entity_id=row.id, summary=clean)
    db.commit(); return RedirectResponse("/gm-office#meetings", 303)


@router.post("/meetings/{meeting_id}/actions")
def add_meeting_action(meeting_id: int, request: Request, action_text: str = Form(...), owner_user_id: str = Form(""), due_at: str = Form(""), db: Session = Depends(get_db)):
    user = require_user(request, db, SECRETARY); meeting = db.get(OfficeMeeting, meeting_id)
    if not meeting: raise HTTPException(404, "Meeting not found")
    owner = db.get(User, int(owner_user_id)) if owner_user_id.strip() else None
    if owner_user_id.strip() and (not owner or not owner.active): raise ValueError("Action owner is not active")
    if not action_text.strip(): raise ValueError("Action item is required")
    row = OfficeMeetingAction(meeting_id=meeting.id, action_text=action_text.strip(), owner_user_id=owner.id if owner else None, due_at=_dt(due_at), status="OPEN")
    db.add(row); db.flush()
    add_audit(db, actor=user, request=request, action="GM_MEETING_ACTION_CREATE", entity_type="OfficeMeetingAction", entity_id=row.id, summary=action_text.strip()[:160])
    if owner:
        db.add(Notification(site_id=owner.site_id,user_id=owner.id,category="GM_OFFICE",title=f"Meeting action — {meeting.title[:120]}",message=action_text.strip()[:500],target_url="/control/notifications",priority="NORMAL",email_status="PENDING_CONFIGURATION"))
    db.commit(); return RedirectResponse("/gm-office#meetings", 303)


@router.post("/meeting-actions/{action_id}/close")
def close_meeting_action(action_id: int, request: Request, closure_note: str = Form(""), db: Session = Depends(get_db)):
    user = require_user(request, db, SECRETARY); row = db.get(OfficeMeetingAction, action_id)
    if not row: raise HTTPException(404, "Meeting action not found")
    row.status = "CLOSED"; row.closure_note = closure_note.strip()
    add_audit(db, actor=user, request=request, action="GM_MEETING_ACTION_CLOSE", entity_type="OfficeMeetingAction", entity_id=row.id, summary=row.action_text[:160])
    db.commit(); return RedirectResponse("/gm-office#meetings", 303)


@router.get("/correspondence/{row_id}/attachment")
def correspondence_attachment(row_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, SECRETARY)
    row = db.get(OfficeCorrespondence, row_id)
    if not row or not row.attachment_path:
        raise HTTPException(404, "Correspondence attachment not found")
    path = Path(row.attachment_path)
    if not path.exists():
        raise HTTPException(404, "Correspondence attachment file not found")
    add_audit(db, actor=user, request=request, action="GM_CORRESPONDENCE_ATTACHMENT_VIEW", entity_type="OfficeCorrespondence", entity_id=row.id, summary=row.subject[:160]); db.commit()
    return FileResponse(path)
