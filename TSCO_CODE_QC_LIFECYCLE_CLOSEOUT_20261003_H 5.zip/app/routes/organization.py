from __future__ import annotations

import os

from fastapi import APIRouter, Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import Role, User
from ..security import require_user
from ..role_matrix import ROLE_REVIEW_MATRIX, role_display
from ..org_structure import EMPLOYEES as ORG_EMPLOYEE_SPECS, SHARED_SERVICE_FUNCTIONS
from ..review_personas import REVIEW_PERSONAS

router = APIRouter(prefix="/organization", tags=["organization and employees"])

EMPLOYEE_DIRECTORY_ALLOWED = {
    Role.CORPORATE_SUPPORT.value, Role.OPERATIONS_MANAGER.value, Role.TECHNICAL_MANAGER.value,
    Role.MANAGEMENT.value, Role.EXCELLENCE.value, Role.SYSTEM_ADMIN.value,
}

INTERNAL = {
    Role.FIELD_SAMPLER.value,
    Role.SAMPLING_SUPERVISOR.value,
    Role.OPERATIONS_MANAGER.value,
    Role.DATA_ENTRY.value,
    Role.CLIENT_COORDINATOR.value,
    Role.LAB_TECHNICIAN.value,
    Role.SENIOR_CHEMIST.value,
    Role.QUALITY.value,
    Role.TECHNICAL_MANAGER.value,
    Role.MANAGEMENT.value,
    Role.SALES_MARKETING.value,
    Role.FINANCE.value,
    Role.EXCELLENCE.value,
    Role.CORPORATE_SUPPORT.value,
    Role.SHARED_SERVICES.value,
    Role.LAB_SUPPORT.value,
    Role.SYSTEM_ADMIN.value,
}

# Exact named people from the supplied TSCO Analytical Lab organizational chart.
# Workflow stages such as Receiving, QC, validation and improvement are NOT people/departments.
ORG = {
    "general_manager": "Salah Al-Shajira",
    "excellence": "Ohood Al Hareeqi",
    "secretary": "Renad Al Qahtani",
    "sales_specialist": "Humayoon",
    "salesman": "Khalid Alali",
    "field_manager": "Abdulmajeed",
    "sampling_supervisor": "Sampling Supervisor",
    "data_entry": "Ahmed Al Qahtani",
    "samplemen": [
        "Mohammed Amir",
        "Matiullah Khan",
        "Rahmatullah Abdul Momin",
        "Mohammed Majid",
        "Mubarak Abdullah",
    ],
    "client_coordination": ["Malindu Eranda", "Mohammed Athaf", "Muhammed Arsalan"],
    "external_coordination": ["Sara Al Otaibi"],
    "lab_manager": "Rwad",
    "seniors": ["Mohammed Al Yahya", "Tara Al Ghamdi", "Reem Al Otaibi"],
    "chemists": [
        "Ali Al Orain",
        "Syed Azhar",
        "Hadeel Al Rashidi",
        "Anandhu Krishna",
        "Subindev Valuparampil",
        "Abdullah Al Hindi",
        "Ziyad Al-Harbi",
    ],
    "technicians": ["Faisal Al Shihri", "Sultan Al Subaie", "Anas Asiri", "Muhanand Al Azhri"],
    "glassware": ["Sahid Husain"],
    "shared_services": [],
}

REVIEW_ORG = {
    "shared_services": [],
    "general_manager": "General Manager",
    "sales_roles": ["Sales & Marketing Specialist", "Salesman"],
    "support_roles": ["Excellence Specialist", "Secretary"],
    "data_entry": "Data Entry",
    "field_manager": "Field Operational & Technical Manager",
    "sampling_supervisor": "Sampling Supervisor",
    "sampleman": "Sampleman",
    "field_direct_roles": ["Client Account & Coordination Officer", "External Coordination Officer"],
    "lab_manager": "Lab Operational & Technical Manager",
    "senior_roles": ["Senior Chemist — Technical", "Senior Chemist — Equipment & Maintenance", "Senior Chemist — Continuous Improvement"],
    "lab_roles": ["Chemist", "Chemical Technician", "Glassware Cleaning"],
}

# Named employee directory and reporting lines are centralized in app.org_structure.
# This prevents the organization page, seed data and leave approvals from drifting apart.
ORG_EMPLOYEES = [
    (e.name, e.email, e.job_title, e.organization_area, e.role) for e in ORG_EMPLOYEE_SPECS
]

SHARED_SERVICE_ACCESS = [
    (function_name, email, access_role) for function_name, email, access_role, _ in SHARED_SERVICE_FUNCTIONS
]



def _role_matrix(users: list[User]) -> list[dict]:
    rows = []
    for role, spec in ROLE_REVIEW_MATRIX.items():
        if role in {Role.CLIENT.value, Role.CLIENT_OPERATIONS.value, Role.CLIENT_SAMPLER.value}:
            continue
        rows.append({"role": role, **spec, "accounts": [u for u in users if u.role == role]})
    return rows


@router.get("")
def organization(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, INTERNAL)
    users = list(db.scalars(select(User).where(User.active.is_(True)).order_by(User.full_name)).all())
    review_mode = os.getenv("APP_ENV", "development").strip().lower() != "testing"
    return templates.TemplateResponse(
        "organization.html",
        {
            "request": request,
            "user": user,
            "org": ORG,
            "review_org": REVIEW_ORG,
            "review_mode": review_mode,
            "role_matrix": _role_matrix(users),
            "named_employee_count": len(ORG_EMPLOYEES),
        },
    )


@router.get("/employees")
def employees(request: Request, db: Session = Depends(get_db)):
    review_mode = os.getenv("APP_ENV", "development").strip().lower() != "testing"
    user = require_user(request, db, EMPLOYEE_DIRECTORY_ALLOWED if review_mode else INTERNAL)
    active_users = list(db.scalars(select(User).where(User.active.is_(True))).all())
    if review_mode:
        by_email = {u.email.lower(): u for u in active_users}
        review_rows = []
        for p in REVIEW_PERSONAS:
            account = by_email.get(p.email.lower())
            review_rows.append({
                "title": p.title, "email": p.email, "organization_area": p.organization_area,
                "access_role": p.role, "access_label": role_display(p.role),
                "manager": p.reports_to, "leave_approver": p.leave_approver,
                "workspace_summary": p.needs, "boundaries": p.boundaries,
                "status": "ACTIVE" if account else "NOT CONFIGURED",
            })
        return templates.TemplateResponse(
            "employees.html",
            {
                "request": request, "user": user, "review_mode": True, "review_roles": review_rows,
                "employees": [], "shared_services": [], "active_named": 0, "named_employee_count": 0,
                "show_access_details": True,
            },
        )
    by_email = {u.email.lower(): u for u in active_users}

    staff_rows = []
    spec_by_email = {e.email.lower(): e for e in ORG_EMPLOYEE_SPECS}
    for name, email, job_title, organization_area, access_role in ORG_EMPLOYEES:
        account = by_email.get(email.lower())
        spec = spec_by_email[email.lower()]
        staff_rows.append(
            {
                "name": name,
                "email": email,
                "job_title": job_title,
                "organization_area": organization_area,
                "access_role": access_role,
                "access_label": role_display(access_role),
                "account": account,
                "manager": account.manager.full_name if account and account.manager else (spec.manager_email or "—"),
                "leave_approver": account.leave_approver.full_name if account and account.leave_approver else (spec.leave_approver_email or "External / not defined in source chart"),
                "workspace_summary": spec.workspace_summary,
                "boundaries": spec.boundaries,
                "status": "ACTIVE" if account else "NOT CONFIGURED",
            }
        )

    shared_rows = []
    shared_needs = {email.lower(): needs for _, email, _, needs in SHARED_SERVICE_FUNCTIONS}
    for function_name, email, access_role in SHARED_SERVICE_ACCESS:
        account = by_email.get(email.lower())
        shared_rows.append(
            {
                "function": function_name,
                "email": email,
                "access_role": access_role,
                "access_label": role_display(access_role),
                "account": account,
                "needs": shared_needs.get(email.lower(), ()),
                "status": "ACTIVE" if account else "NOT CONFIGURED",
            }
        )

    active_named = sum(1 for r in staff_rows if r["account"] is not None)
    return templates.TemplateResponse(
        "employees.html",
        {
            "request": request,
            "user": user,
            "review_mode": False,
            "employees": staff_rows,
            "shared_services": shared_rows,
            "active_named": active_named,
            "named_employee_count": len(staff_rows),
            "show_access_details": user.role in {
                Role.SYSTEM_ADMIN.value, Role.MANAGEMENT.value, Role.TECHNICAL_MANAGER.value,
                Role.OPERATIONS_MANAGER.value, Role.EXCELLENCE.value,
            },
        },
    )
