from __future__ import annotations

from datetime import datetime, timedelta
from io import BytesIO
import os
import json

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import RedirectResponse, StreamingResponse
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import (
    Role, User, Site, StaffAvailability, StaffWorkPattern, NightShiftMonthPlan,
    OvertimeRequest, OvertimeClaim, HousekeepingTask, SampleKitTask,
    SamplingAssignment, AuditLog, CompetencyRecord,
)
from ..security import require_user
from ..services.audit import add_audit

router = APIRouter(prefix="/workforce", tags=["workforce"])
INTERNAL = {
    Role.FIELD_SAMPLER.value, Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value,
    Role.DATA_ENTRY.value, Role.CLIENT_COORDINATOR.value, Role.LAB_TECHNICIAN.value,
    Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value, Role.MANAGEMENT.value,
    Role.SALES_MARKETING.value, Role.EXCELLENCE.value, Role.CORPORATE_SUPPORT.value,
    Role.LAB_SUPPORT.value, Role.SYSTEM_ADMIN.value,
}
MANAGERS = {
    Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value, Role.SENIOR_CHEMIST.value,
    Role.TECHNICAL_MANAGER.value, Role.MANAGEMENT.value,
}
CLAIM_STATUSES = [
    "DRAFT", "WORD_PREPARED", "SUBMITTED_SHAREPOINT", "MANAGER_APPROVED",
    "GM_APPROVED", "READY_FOR_MENAME", "SUBMITTED_MENAME",
]


def _site(db: Session, user: User) -> Site:
    site = db.get(Site, user.site_id) if user.site_id else None
    site = site or db.scalar(select(Site).where(Site.code == "DMM"))
    if not site:
        raise ValueError("Active site is required")
    return site


def _dt(value: str | None) -> datetime | None:
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00")).replace(tzinfo=None)


def _scope_employee(db: Session, actor: User, employee_id: int) -> User:
    employee = db.get(User, employee_id)
    if not employee or not employee.active:
        raise ValueError("Active employee is required")
    if actor.role == Role.SYSTEM_ADMIN.value:
        return employee
    if actor.site_id and employee.site_id != actor.site_id:
        raise HTTPException(403, "Employee is outside your site scope")
    # Direct-report control is authoritative. Sampling Supervisor also owns Sampleman allocation.
    if employee.manager_id != actor.id:
        if not (actor.role == Role.SAMPLING_SUPERVISOR.value and employee.role == Role.FIELD_SAMPLER.value):
            raise HTTPException(403, "Operational overtime can be requested only for employees in your reporting scope")
    return employee


@router.get("")
def workspace(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, INTERNAL)
    site = _site(db, user)
    plans = db.scalars(
        select(NightShiftMonthPlan).where(NightShiftMonthPlan.user_id == user.id)
        .order_by(NightShiftMonthPlan.year.desc(), NightShiftMonthPlan.month.desc()).limit(24)
    ).all()
    roster = db.scalars(
        select(StaffAvailability).where(
            StaffAvailability.user_id == user.id,
            StaffAvailability.entry_type.in_(["SHIFT", "ON_CALL"]),
            StaffAvailability.status.in_(["PLANNED", "APPROVED", "CONFIRMED"]),
        ).order_by(StaffAvailability.start_at.desc()).limit(120)
    ).all()
    claims = db.scalars(
        select(OvertimeClaim).where(OvertimeClaim.employee_id == user.id)
        .order_by(OvertimeClaim.work_date.desc(), OvertimeClaim.id.desc()).limit(120)
    ).all()
    requests = db.scalars(
        select(OvertimeRequest).where(or_(OvertimeRequest.employee_id == user.id, OvertimeRequest.approver_id == user.id, OvertimeRequest.requested_by_id == user.id))
        .order_by(OvertimeRequest.work_date.desc(), OvertimeRequest.id.desc()).limit(120)
    ).all()
    direct_reports = []
    if user.role in MANAGERS or user.role == Role.SYSTEM_ADMIN.value:
        stmt = select(User).where(User.active.is_(True))
        if user.role != Role.SYSTEM_ADMIN.value:
            stmt = stmt.where(User.site_id == site.id).where(or_(User.manager_id == user.id, (User.role == Role.FIELD_SAMPLER.value) if user.role == Role.SAMPLING_SUPERVISOR.value else False))
        direct_reports = list(db.scalars(stmt.order_by(User.full_name)).all())

    lab_people = []
    work_patterns = {}
    managed_roster = []
    if user.role in {Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value}:
        lab_people = list(db.scalars(select(User).where(
            User.site_id == site.id, User.active.is_(True), User.role == Role.LAB_TECHNICIAN.value
        ).order_by(User.full_name)).all())
        pattern_rows = list(db.scalars(select(StaffWorkPattern).where(
            StaffWorkPattern.site_id == site.id, StaffWorkPattern.active.is_(True)
        )).all())
        for row in pattern_rows:
            try:
                days = [int(x) for x in json.loads(row.weekdays_json or "[]")]
            except Exception:
                days = []
            work_patterns[row.user_id] = {
                "name": row.name, "days": days, "shift_start": row.shift_start, "shift_end": row.shift_end,
                "effective_from": row.effective_from, "effective_to": row.effective_to,
            }
        window_start = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=7)
        window_end = window_start + timedelta(days=100)
        lab_ids = [p.id for p in lab_people]
        if lab_ids:
            managed_roster = list(db.scalars(select(StaffAvailability).where(
                StaffAvailability.site_id == site.id, StaffAvailability.user_id.in_(lab_ids),
                StaffAvailability.entry_type.in_(["SHIFT", "ON_CALL"]),
                StaffAvailability.start_at >= window_start, StaffAvailability.start_at < window_end,
            ).order_by(StaffAvailability.start_at, StaffAvailability.user_id)).all())
    annual_site_plans = []
    if user.role in {Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value}:
        annual_site_plans = list(db.scalars(select(NightShiftMonthPlan).where(
            NightShiftMonthPlan.site_id == site.id, NightShiftMonthPlan.year >= datetime.utcnow().year,
        ).order_by(NightShiftMonthPlan.year, NightShiftMonthPlan.month, NightShiftMonthPlan.created_at)).all())

    return templates.TemplateResponse("workforce.html", {
        "request": request, "user": user, "site": site, "plans": plans, "roster": roster,
        "claims": claims, "requests": requests, "direct_reports": direct_reports,
        "claim_statuses": CLAIM_STATUSES,
        "lab_people": lab_people, "work_patterns": work_patterns, "managed_roster": managed_roster, "annual_site_plans": annual_site_plans,
        "current_month": datetime.utcnow().strftime("%Y-%m"),
        "sharepoint_url": os.getenv("OVERTIME_SHAREPOINT_URL", "").strip(),
        "mename_url": os.getenv("MENAME_URL", "").strip(),
    })


@router.post("/overtime/requests")
def create_overtime_request(
    request: Request, employee_id: int = Form(...), work_date: str = Form(...),
    requested_hours: float = Form(...), reason: str = Form(...), project_reference: str = Form(""),
    related_reference: str = Form(""), db: Session = Depends(get_db),
):
    actor = require_user(request, db, MANAGERS)
    employee = _scope_employee(db, actor, employee_id)
    site = _site(db, actor)
    when = _dt(work_date)
    if not when or requested_hours <= 0 or requested_hours > 24:
        raise ValueError("Work date and overtime hours (0–24) are required")
    if not reason.strip():
        raise ValueError("Operational overtime reason is required")
    if actor.role == Role.SAMPLING_SUPERVISOR.value and employee.role == Role.FIELD_SAMPLER.value:
        approver = actor.manager  # approved Field workflow: Supervisor raises → Field Manager decides
    else:
        approver = employee.manager
    if not approver:
        raise ValueError("A direct operational approver must be configured")
    if approver.id == actor.id and actor.role == Role.SAMPLING_SUPERVISOR.value:
        raise ValueError("Sampling Supervisor overtime requests must route to the Field Operational & Technical Manager")
    row = OvertimeRequest(
        site_id=site.id, employee_id=employee.id, requested_by_id=actor.id, approver_id=approver.id,
        work_date=when, requested_hours=requested_hours, reason=reason.strip(),
        project_reference=project_reference.strip(), related_reference=related_reference.strip(), status="SUBMITTED",
    )
    db.add(row); db.flush()
    add_audit(db, actor=actor, request=request, action="OVERTIME_PREAUTH_REQUEST", entity_type="OvertimeRequest", entity_id=row.id,
              summary=f"{employee.full_name} · {requested_hours:g} h · {when.date().isoformat()}")
    db.commit()
    return RedirectResponse("/workforce#overtime-requests", 303)


@router.post("/overtime/requests/{request_id}/decision")
def decide_overtime_request(request_id: int, request: Request, decision: str = Form(...), note: str = Form(""), db: Session = Depends(get_db)):
    actor = require_user(request, db, MANAGERS | {Role.MANAGEMENT.value})
    row = db.get(OvertimeRequest, request_id)
    if not row:
        raise HTTPException(404, "Overtime request not found")
    if row.approver_id != actor.id and actor.role not in {Role.MANAGEMENT.value, Role.SYSTEM_ADMIN.value}:
        raise HTTPException(403, "Only the configured operational approver can decide this request")
    if row.status != "SUBMITTED":
        raise ValueError("This overtime request has already been decided")
    clean = decision.strip().upper()
    if clean not in {"APPROVED", "REJECTED"}:
        raise ValueError("Decision must be Approved or Rejected")
    row.status = clean; row.decision_note = note.strip(); row.decided_at = datetime.utcnow()
    add_audit(db, actor=actor, request=request, action="OVERTIME_PREAUTH_DECISION", entity_type="OvertimeRequest", entity_id=row.id, summary=clean)
    db.commit()
    return RedirectResponse("/workforce#overtime-requests", 303)


@router.post("/overtime/claims")
def create_overtime_claim(
    request: Request, work_date: str = Form(...), start_time: str = Form(""), end_time: str = Form(""),
    total_hours: float = Form(0), reason: str = Form(...), project_reference: str = Form(""),
    related_reference: str = Form(""), overtime_request_id: str = Form(""), db: Session = Depends(get_db),
):
    actor = require_user(request, db, INTERNAL - {Role.SYSTEM_ADMIN.value})
    site = _site(db, actor); when = _dt(work_date)
    if not when or not reason.strip():
        raise ValueError("Work date and overtime reason are required")
    if total_hours <= 0 and start_time and end_time:
        try:
            a = datetime.strptime(start_time, "%H:%M"); b = datetime.strptime(end_time, "%H:%M")
            minutes = (b - a).total_seconds() / 60
            if minutes <= 0: minutes += 24 * 60
            total_hours = round(minutes / 60, 2)
        except Exception:
            raise ValueError("Start/end time is invalid")
    if total_hours <= 0 or total_hours > 24:
        raise ValueError("Total overtime hours must be greater than zero and not more than 24")
    req = None
    if overtime_request_id.strip():
        req = db.get(OvertimeRequest, int(overtime_request_id))
        if not req or req.employee_id != actor.id or req.status != "APPROVED":
            raise ValueError("Linked operational overtime request must be approved and belong to you")
    row = OvertimeClaim(
        site_id=site.id, employee_id=actor.id, overtime_request_id=req.id if req else None,
        work_date=when, start_time=start_time.strip(), end_time=end_time.strip(), total_hours=total_hours,
        reason=reason.strip(), project_reference=project_reference.strip(), related_reference=related_reference.strip(), status="DRAFT",
    )
    db.add(row); db.flush()
    add_audit(db, actor=actor, request=request, action="OVERTIME_CLAIM_CREATE", entity_type="OvertimeClaim", entity_id=row.id,
              summary=f"{when.date().isoformat()} · {total_hours:g} h")
    db.commit()
    return RedirectResponse("/workforce#my-overtime", 303)


@router.post("/overtime/claims/{claim_id}/status")
def update_claim_status(
    claim_id: int, request: Request, status: str = Form(...), external_submission_reference: str = Form(""), note: str = Form(""), db: Session = Depends(get_db),
):
    actor = require_user(request, db, INTERNAL)
    row = db.get(OvertimeClaim, claim_id)
    if not row:
        raise HTTPException(404, "Overtime claim not found")
    if row.employee_id != actor.id and actor.role != Role.SYSTEM_ADMIN.value:
        raise HTTPException(403, "Employees can update only their own overtime submission tracking")
    clean = status.strip().upper()
    if clean not in CLAIM_STATUSES:
        raise ValueError("Unsupported overtime submission status")
    current_i = CLAIM_STATUSES.index(row.status) if row.status in CLAIM_STATUSES else 0
    new_i = CLAIM_STATUSES.index(clean)
    if new_i < current_i:
        raise ValueError("Overtime submission status cannot be moved backwards")
    row.status = clean
    row.external_submission_reference = external_submission_reference.strip() or row.external_submission_reference
    row.note = note.strip() or row.note
    add_audit(db, actor=actor, request=request, action="OVERTIME_CLAIM_STATUS", entity_type="OvertimeClaim", entity_id=row.id, summary=clean)
    db.commit()
    return RedirectResponse("/workforce#my-overtime", 303)


@router.get("/overtime/claims/{claim_id}/word")
def overtime_word(claim_id: int, request: Request, db: Session = Depends(get_db)):
    actor = require_user(request, db, INTERNAL)
    row = db.get(OvertimeClaim, claim_id)
    if not row:
        raise HTTPException(404, "Overtime claim not found")
    if row.employee_id != actor.id and actor.role not in {Role.SYSTEM_ADMIN.value, Role.TECHNICAL_MANAGER.value, Role.OPERATIONS_MANAGER.value, Role.MANAGEMENT.value}:
        raise HTTPException(403, "Overtime sheet is outside your scope")
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    doc = Document()
    title = doc.add_paragraph(); title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.add_run("TSCO — Overtime Sheet").bold = True
    t = doc.add_table(rows=0, cols=2); t.style = "Table Grid"
    data = [
        ("Employee", row.employee.full_name), ("Job Title", row.employee.job_title or row.employee.role),
        ("Date", row.work_date.strftime("%Y-%m-%d")), ("Start", row.start_time or "—"), ("End", row.end_time or "—"),
        ("Total Hours", f"{row.total_hours:g}"), ("Reason", row.reason),
        ("Project / Order", row.project_reference or "—"), ("Related Reference", row.related_reference or "—"),
        ("Operational Pre-Authorization", f"OTR-{row.overtime_request_id}" if row.overtime_request_id else "Not linked"),
        ("Official Submission Status", row.status.replace("_", " ").title()),
        ("Official Submission Reference", row.external_submission_reference or "—"),
    ]
    for label, value in data:
        cells = t.add_row().cells; cells[0].text = label; cells[1].text = str(value)
    doc.add_paragraph("Official approvals/signatures remain in the company SharePoint workflow. This sheet is the TSCO preparation record and does not replace the official approval process.")
    out = BytesIO(); doc.save(out); out.seek(0)
    if row.employee_id == actor.id and row.status == "DRAFT":
        row.status = "WORD_PREPARED"
        add_audit(db, actor=actor, request=request, action="OVERTIME_WORD_PREPARED", entity_type="OvertimeClaim", entity_id=row.id, summary="Word overtime sheet generated")
        db.commit()
    filename = f"TSCO_Overtime_{row.work_date:%Y%m%d}_{row.employee.id}.docx"
    return StreamingResponse(out, media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document", headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@router.get("/history")
def work_history(request: Request, employee_id: str = "", from_date: str = "", to_date: str = "", db: Session = Depends(get_db)):
    actor = require_user(request, db, {Role.OPERATIONS_MANAGER.value, Role.TECHNICAL_MANAGER.value, Role.MANAGEMENT.value, Role.SYSTEM_ADMIN.value})
    site = _site(db, actor)
    stmt = select(User).where(User.active.is_(True))
    if actor.role != Role.SYSTEM_ADMIN.value:
        stmt = stmt.where(User.site_id == site.id)
        if actor.role == Role.OPERATIONS_MANAGER.value:
            stmt = stmt.where(User.role.in_([Role.SAMPLING_SUPERVISOR.value, Role.FIELD_SAMPLER.value, Role.DATA_ENTRY.value, Role.CLIENT_COORDINATOR.value]))
        elif actor.role == Role.TECHNICAL_MANAGER.value:
            stmt = stmt.where(User.role.in_([Role.SENIOR_CHEMIST.value, Role.LAB_TECHNICIAN.value, Role.LAB_SUPPORT.value]))
        elif actor.role != Role.MANAGEMENT.value:
            stmt = stmt.where(User.manager_id == actor.id)
    employees = list(db.scalars(stmt.order_by(User.full_name)).all())
    selected = None; events = []
    if employee_id:
        selected = next((p for p in employees if p.id == int(employee_id)), None)
        if not selected:
            raise HTTPException(403, "Employee is outside your work-history scope")
        for a in db.scalars(select(AuditLog).where(AuditLog.actor_id == selected.id).order_by(AuditLog.created_at.desc()).limit(100)).all():
            events.append({"when": a.created_at, "type": "Activity", "summary": f"{a.action}: {a.summary or ''}"})
        for row in db.scalars(select(OvertimeClaim).where(OvertimeClaim.employee_id == selected.id).order_by(OvertimeClaim.work_date.desc()).limit(50)).all():
            events.append({"when": row.work_date, "type": "Overtime", "summary": f"{row.total_hours:g} h · {row.reason} · {row.status}"})
        for row in db.scalars(select(HousekeepingTask).where(HousekeepingTask.assigned_to_id == selected.id).order_by(HousekeepingTask.created_at.desc()).limit(50)).all():
            events.append({"when": row.completed_at or row.created_at, "type": "Housekeeping", "summary": f"{row.area_zone} · {row.status}"})
        for row in db.scalars(select(SampleKitTask).where(SampleKitTask.assigned_to_id == selected.id).order_by(SampleKitTask.created_at.desc()).limit(50)).all():
            events.append({"when": row.completed_at or row.created_at, "type": "Sample Kit", "summary": f"{row.container_type} · {row.status}"})
        for row in db.scalars(select(SamplingAssignment).where(SamplingAssignment.assigned_sampler_id == selected.id).order_by(SamplingAssignment.created_at.desc()).limit(100)).all():
            events.append({"when": row.completed_at or row.assigned_at or row.created_at, "type": "Field Assignment", "summary": f"{row.assignment_code} · {row.task_type.replace('_',' ')} · {row.status}"})
        # Laboratory result/QC/completion evidence is stored in the authoritative Operations state.
        if selected.role == Role.LAB_TECHNICIAN.value:
            from ..services.lab_operations import get_operations_state
            _, payload = get_operations_state(db, site)
            for row in payload.get("results", []):
                if int(row.get("recorded_by_user_id") or 0) == selected.id:
                    try: when = datetime.fromisoformat(str(row.get("ts") or "").replace("Z", "+00:00")).replace(tzinfo=None)
                    except Exception: when = datetime.min
                    events.append({"when": when, "type": "Analytical Result", "summary": f"{row.get('sample','')} · {row.get('test','')} · {row.get('result','')} {row.get('unit','')}"})
            for row in payload.get("qc", []):
                if int(row.get("recorded_by_user_id") or 0) == selected.id:
                    try: when = datetime.fromisoformat(str(row.get("ts") or "").replace("Z", "+00:00")).replace(tzinfo=None)
                    except Exception: when = datetime.min
                    events.append({"when": when, "type": "Analytical QC", "summary": f"{row.get('test','')} · {row.get('status','')}"})
            for row in payload.get("assignmentCompletions", []):
                if int(row.get("completed_by_user_id") or 0) == selected.id:
                    try: when = datetime.fromisoformat(str(row.get("completed_at") or "").replace("Z", "+00:00")).replace(tzinfo=None)
                    except Exception: when = datetime.min
                    events.append({"when": when, "type": "Assignment Completion", "summary": f"{row.get('batch_id','')} · {row.get('workstation','')}"})
        start = datetime.fromisoformat(from_date) if from_date.strip() else None
        end = datetime.fromisoformat(to_date) if to_date.strip() else None
        if end is not None:
            end = end.replace(hour=23, minute=59, second=59, microsecond=999999)
        if start or end:
            events = [e for e in events if e.get("when") and (start is None or e["when"] >= start) and (end is None or e["when"] <= end)]
        events.sort(key=lambda e: e["when"] or datetime.min, reverse=True)
        events = events[:200]
    return templates.TemplateResponse("work_history.html", {"request": request, "user": actor, "employees": employees, "selected": selected, "events": events, "from_date": from_date, "to_date": to_date})

@router.post("/annual-night/generate")
def generate_annual_night_plan(request: Request, year: int = Form(...), people_per_month: int = Form(2), db: Session = Depends(get_db)):
    actor = require_user(request, db, {Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value})
    site = _site(db, actor)
    if year < datetime.utcnow().year or year > datetime.utcnow().year + 2:
        raise ValueError("Annual Night Shift plan year must be current or within the next two years")
    if people_per_month not in {1, 2, 3}:
        raise ValueError("Annual Night Shift plan supports 1–3 employees per month")
    existing = db.scalar(select(NightShiftMonthPlan).where(
        NightShiftMonthPlan.site_id == site.id, NightShiftMonthPlan.year == year,
        NightShiftMonthPlan.status.in_(["PUBLISHED", "REASSIGNED"]),
    ))
    if existing:
        raise ValueError("An annual Night Shift month plan already exists for this site/year")

    people = list(db.scalars(select(User).where(
        User.site_id == site.id, User.active.is_(True), User.role == Role.LAB_TECHNICIAN.value,
    ).order_by(User.full_name)).all())
    pattern_rows = list(db.scalars(select(StaffWorkPattern).where(
        StaffWorkPattern.site_id == site.id, StaffWorkPattern.active.is_(True),
        StaffWorkPattern.user_id.in_([p.id for p in people] or [-1]),
    )).all())
    patterns = {row.user_id: row for row in pattern_rows}
    people = [p for p in people if p.id in patterns]
    if len(people) < people_per_month:
        raise ValueError("Configure active Work Patterns for enough laboratory employees before publishing the annual Night Shift plan")

    competency_rows = list(db.scalars(select(CompetencyRecord).where(
        CompetencyRecord.site_id == site.id, CompetencyRecord.active.is_(True),
        CompetencyRecord.user_id.in_([p.id for p in people] or [-1]),
    )).all())
    competency_configured = bool(competency_rows)
    if competency_configured:
        now = datetime.utcnow()
        competent = {r.user_id for r in competency_rows if r.authorization in {"INDEPENDENT", "SUPERVISED"} and (r.expires_at is None or r.expires_at >= now)}
        people = [p for p in people if p.id in competent]
    if len(people) < people_per_month:
        raise ValueError("Not enough competency-authorized laboratory employees for the annual Night Shift plan")

    prior_counts = {p.id: db.query(NightShiftMonthPlan).filter(
        NightShiftMonthPlan.site_id == site.id, NightShiftMonthPlan.user_id == p.id,
        NightShiftMonthPlan.status == "PUBLISHED", NightShiftMonthPlan.year < year,
    ).count() for p in people}
    year_counts = {p.id: 0 for p in people}
    created = 0
    for month in range(1, 13):
        m_start = datetime(year, month, 1)
        m_end = datetime(year, month, 28, 23, 59, 59) + timedelta(days=4)
        m_end = (m_end.replace(day=1) - timedelta(seconds=1))
        candidates = []
        for person in people:
            pattern = patterns.get(person.id)
            if not pattern or (pattern.effective_from and pattern.effective_from > m_end) or (pattern.effective_to and pattern.effective_to < m_start):
                continue
            try:
                workdays = {int(x) for x in json.loads(pattern.weekdays_json or "[]")}
            except Exception:
                workdays = set()
            if not workdays:
                continue
            blocked = db.scalar(select(StaffAvailability.id).where(
                StaffAvailability.site_id == site.id, StaffAvailability.user_id == person.id,
                StaffAvailability.entry_type.in_(["LEAVE", "HOLIDAY", "TRAINING", "UNAVAILABLE"]),
                StaffAvailability.status.in_(["APPROVED", "CONFIRMED", "APPROVED_FOR_ANNUAL_PLAN", "MANAGER_APPROVED"]),
                StaffAvailability.start_at <= m_start, StaffAvailability.end_at >= m_end,
            ))
            if not blocked:
                candidates.append(person)
        candidates.sort(key=lambda p: (prior_counts[p.id] + year_counts[p.id], year_counts[p.id], p.full_name.lower()))
        if len(candidates) < people_per_month:
            raise ValueError(f"Not enough eligible laboratory staff for {year}-{month:02d}; check Work Patterns / leave / training / competency")
        for person in candidates[:people_per_month]:
            db.add(NightShiftMonthPlan(site_id=site.id, year=year, month=month, user_id=person.id, status="PUBLISHED", created_by_id=actor.id))
            year_counts[person.id] += 1
            created += 1
    add_audit(db, actor=actor, request=request, action="ANNUAL_NIGHT_MONTH_PLAN_GENERATED", entity_type="NightShiftMonthPlan", entity_id=None,
              summary=f"{year} · {people_per_month}/month · {created} assignments · Work Pattern/competency/availability/fair-history aware")
    db.commit()
    return RedirectResponse("/workforce#annual-night", 303)


@router.post("/annual-night/{plan_id}/reassign")
def reassign_annual_night_plan(plan_id: int, request: Request, replacement_user_id: int = Form(...), note: str = Form(...), db: Session = Depends(get_db)):
    actor = require_user(request, db, {Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value})
    site = _site(db, actor)
    row = db.get(NightShiftMonthPlan, plan_id)
    if not row or row.site_id != site.id or row.status != "PUBLISHED":
        raise ValueError("Published annual Night Shift assignment not found")
    replacement = db.get(User, replacement_user_id)
    if not replacement or not replacement.active or replacement.site_id != site.id or replacement.role != Role.LAB_TECHNICIAN.value:
        raise ValueError("Replacement must be an active laboratory employee in this site")
    if replacement.id == row.user_id:
        raise ValueError("Select a different replacement employee")
    pattern = db.scalar(select(StaffWorkPattern).where(
        StaffWorkPattern.site_id == site.id, StaffWorkPattern.user_id == replacement.id, StaffWorkPattern.active.is_(True),
    ))
    if not pattern:
        raise ValueError("Replacement must have an active Work Pattern")
    duplicate = db.scalar(select(NightShiftMonthPlan.id).where(
        NightShiftMonthPlan.site_id == site.id, NightShiftMonthPlan.year == row.year, NightShiftMonthPlan.month == row.month,
        NightShiftMonthPlan.user_id == replacement.id, NightShiftMonthPlan.status == "PUBLISHED",
    ))
    if duplicate:
        raise ValueError("Replacement is already assigned to this Night Shift month")
    old_user = row.user
    row.status = "REASSIGNED"
    new_row = NightShiftMonthPlan(site_id=site.id, year=row.year, month=row.month, user_id=replacement.id, status="PUBLISHED", created_by_id=actor.id)
    db.add(new_row); db.flush()
    add_audit(db, actor=actor, request=request, action="ANNUAL_NIGHT_MONTH_REASSIGNED", entity_type="NightShiftMonthPlan", entity_id=new_row.id,
              summary=f"{row.year}-{row.month:02d}: {old_user.full_name if old_user else row.user_id} → {replacement.full_name} · {note.strip() or 'Operational reassignment'}")
    db.commit()
    return RedirectResponse("/workforce#annual-night", 303)
