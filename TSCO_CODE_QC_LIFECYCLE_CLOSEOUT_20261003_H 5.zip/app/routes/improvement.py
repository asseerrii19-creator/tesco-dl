from __future__ import annotations

from datetime import datetime
from fastapi import APIRouter, Depends, Form, Request, HTTPException
from fastapi.responses import RedirectResponse
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import (
    Department, EquipmentAsset, EquipmentEvent, ImprovementActivity, ImprovementItem, QualityCase, Role, Site, User, Notification,
    TroubleshootingRecord, EvidenceRecord,
)
from ..responsibilities import responsibility_label, senior_responsibility
from ..security import require_user
from ..services.audit import add_audit

router = APIRouter(prefix="/improvement", tags=["continuous improvement"])
INTERNAL = {
    Role.FIELD_SAMPLER.value, Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value,
    Role.DATA_ENTRY.value, Role.CLIENT_COORDINATOR.value, Role.LAB_TECHNICIAN.value,
    Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value,
    Role.MANAGEMENT.value, Role.SALES_MARKETING.value, Role.EXCELLENCE.value,
    Role.SYSTEM_ADMIN.value,
}
GOVERN = {Role.TECHNICAL_MANAGER.value, Role.EXCELLENCE.value}
ACTION = GOVERN | {Role.SENIOR_CHEMIST.value}
STATUSES = ["SUBMITTED", "UNDER_REVIEW", "APPROVED", "IN_PROGRESS", "VALIDATION", "IMPLEMENTED", "CLOSED", "DEFERRED"]
CATEGORIES = ["OPERATIONS", "QUALITY", "SAFETY", "DIGITALIZATION", "WORKFLOW", "DOCUMENTATION", "EQUIPMENT", "CLIENT_SERVICE", "COST", "OTHER"]

TAB_LABELS = [
    ("overview", "Overview"), ("register", "Improvement Register"),
    ("roadmap", "Project 00012 Roadmap"), ("review-model", "Department Review Model"),
]

ROADMAP = [
    ("MAR 2026", "Problem identification", "Operational observation, workflow gaps, paper dependency and sample visibility."),
    ("APR 2026", "Practical improvement concepts", "Orientation, troubleshooting support, quick references and easier technical knowledge access."),
    ("05–06 MAY", "Operational Improvement Roadmap", "Digital operational support, future dashboards, workflow tracking, standalone platform monitoring."),
    ("24–25 MAY", "Retained sample tracking", "Receiving → storage → laboratory workflow, retention/disposal, retrieval and barcode/QR direction."),
    ("16 JUN", "Workflow prototype", "Sample tracking, priority, assignment, routing, result consolidation and supervisor visibility."),
    ("27–28 JUL", "Working web platform", "Operational web system with supervisory monitoring, laboratory workflow, quality and retained samples."),
    ("03–05 AUG", "Integrated multi-role platform", "Full Laboratory Operations expanded into the TSCO Digital Laboratory Platform and UAT architecture."),
    ("CURRENT", "Department review & controlled UAT", "Validate each department workflow, close gaps, preserve one architecture and prepare production IT handover."),
]


def _site(db: Session, user) -> Site:
    site = db.get(Site, user.site_id) if user.site_id else None
    return site or db.scalar(select(Site).where(Site.code == "DMM"))


def _can_govern_improvement(user) -> bool:
    return user.role in GOVERN


def _allowed_tabs(user) -> set[str]:
    if user.role in {Role.FIELD_SAMPLER.value, Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value, Role.DATA_ENTRY.value, Role.CLIENT_COORDINATOR.value, Role.LAB_TECHNICIAN.value, Role.SALES_MARKETING.value, Role.FINANCE.value, Role.QUALITY.value}:
        return {"register"}
    if user.role == Role.SENIOR_CHEMIST.value:
        return {"register"}
    return {"overview", "register", "roadmap", "review-model"}


def _next_code(db: Session) -> str:
    year = datetime.utcnow().year
    count = db.scalar(select(func.count()).select_from(ImprovementItem).where(ImprovementItem.code.like(f"CI-{year}-%"))) or 0
    return f"CI-{year}-{count + 1:04d}"


@router.get("/responsibilities")
def responsibilities(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.SENIOR_CHEMIST.value})
    site = _site(db, user)
    domain = senior_responsibility(user)
    items = list(db.scalars(select(ImprovementItem).where(
        ((ImprovementItem.site_id == site.id) | (ImprovementItem.site_id.is_(None))),
        ((ImprovementItem.owner_id == user.id) | (ImprovementItem.created_by_id == user.id)),
    ).order_by(ImprovementItem.created_at.desc()).limit(100)).all())
    equipment = []
    equipment_events = []
    troubleshooting = []
    validation_cases = []
    if domain == "EQUIPMENT":
        equipment = list(db.scalars(select(EquipmentAsset).where(EquipmentAsset.site_id == site.id, EquipmentAsset.active.is_(True)).order_by(EquipmentAsset.equipment_id)).all())
        equipment_events = list(db.scalars(select(EquipmentEvent).join(EquipmentAsset).where(EquipmentAsset.site_id == site.id).order_by(EquipmentEvent.event_at.desc()).limit(100)).all())
        troubleshooting = list(db.scalars(select(TroubleshootingRecord).where(TroubleshootingRecord.site_id == site.id, TroubleshootingRecord.equipment_asset_id.is_not(None)).order_by(TroubleshootingRecord.updated_at.desc()).limit(100)).all())
    elif domain == "TECHNICAL":
        troubleshooting = list(db.scalars(select(TroubleshootingRecord).where(TroubleshootingRecord.site_id == site.id, TroubleshootingRecord.equipment_asset_id.is_(None)).order_by(TroubleshootingRecord.updated_at.desc()).limit(100)).all())
        validation_cases = list(db.scalars(select(QualityCase).where(QualityCase.site_id == site.id, QualityCase.case_type.in_(["VALIDATION", "VERIFICATION"])).order_by(QualityCase.updated_at.desc()).limit(100)).all())
    elif domain == "IMPROVEMENT":
        validation_cases = list(db.scalars(select(QualityCase).where(QualityCase.site_id == site.id, QualityCase.case_type.in_(["VALIDATION", "VERIFICATION", "AUDIT"])).order_by(QualityCase.updated_at.desc()).limit(100)).all())
    return templates.TemplateResponse("senior_responsibilities.html", {
        "request": request, "user": user, "site": site, "domain": domain,
        "domain_label": responsibility_label(domain), "items": items,
        "equipment": equipment, "equipment_events": equipment_events,
        "troubleshooting": troubleshooting, "validation_cases": validation_cases,
    })


def _notify_owner(db, row, previous_owner=None):
    if row.owner_id and row.owner_id != previous_owner:
        db.add(Notification(user_id=row.owner_id, site_id=row.site_id, category="IMPROVEMENT",
            title=f"Assigned responsibility: {row.code}", message=row.title,
            target_url=f"/improvement?tab=register#item-{row.id}", priority=row.priority))


def _validate_owner(db, owner_id, site_id):
    if owner_id is None:
        return
    owner = db.get(User, owner_id)
    if not owner or not owner.active or owner.role not in ACTION or (site_id and owner.site_id not in {None, site_id}):
        raise ValueError("Select an active responsibility owner at this site")


@router.get("")
def dashboard(request: Request, tab: str = "overview", status: str = "", scope: str = "", db: Session = Depends(get_db)):
    user = require_user(request, db, INTERNAL)
    site = _site(db, user)
    allowed_tabs = _allowed_tabs(user)
    tab = tab if tab in allowed_tabs else ("overview" if "overview" in allowed_tabs else "register")

    stmt = select(ImprovementItem).order_by(ImprovementItem.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        stmt = stmt.where((ImprovementItem.site_id == user.site_id) | (ImprovementItem.site_id.is_(None)))
    if user.role == Role.SENIOR_CHEMIST.value:
        stmt = stmt.where((ImprovementItem.owner_id == user.id) | (ImprovementItem.created_by_id == user.id))
    my_work = scope == "my-work" and user.role == Role.EXCELLENCE.value
    if my_work:
        tab = "register"
        stmt = stmt.where(~ImprovementItem.status.in_(["CLOSED", "DEFERRED"]))
    if status in STATUSES:
        stmt = stmt.where(ImprovementItem.status == status)
    submit_only = user.role in {Role.FIELD_SAMPLER.value, Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value, Role.DATA_ENTRY.value, Role.CLIENT_COORDINATOR.value, Role.LAB_TECHNICIAN.value, Role.SALES_MARKETING.value, Role.FINANCE.value, Role.QUALITY.value}
    if submit_only:
        stmt = stmt.where(ImprovementItem.created_by_id == user.id)
    items = db.scalars(stmt.limit(300)).all()
    metrics = {state: sum(1 for row in items if row.status == state) for state in STATUSES}

    staff_stmt = select(User).where(User.active.is_(True)).order_by(User.full_name)
    if user.site_id:
        staff_stmt = staff_stmt.where((User.site_id == user.site_id) | (User.site_id.is_(None)))
    staff = db.scalars(staff_stmt).all()
    departments = db.scalars(select(Department).where(Department.active.is_(True)).order_by(Department.name)).all()
    return templates.TemplateResponse(
        "improvement.html",
        {
            "request": request, "user": user, "site": site, "tab": tab, "status_filter": status, "items": items,
            "staff": staff, "departments": departments, "metrics": metrics,
            "statuses": STATUSES, "categories": CATEGORIES, "manage": user.role in ACTION,
            "govern": _can_govern_improvement(user), "senior_view": user.role == Role.SENIOR_CHEMIST.value, "roadmap": ROADMAP,
            "visible_tabs": [(k, label) for k, label in TAB_LABELS if k in allowed_tabs],
            "senior_label": responsibility_label(senior_responsibility(user)), "senior_scope": senior_responsibility(user),
            "submit_only": submit_only, "my_work": my_work, "scope": scope, "now": datetime.utcnow(),
        },
    )


@router.post("")
def create_item(
    request: Request,
    title: str = Form(...), problem_statement: str = Form(""), category: str = Form("OPERATIONS"),
    priority: str = Form("NORMAL"), impact_area: str = Form(""), expected_benefit: str = Form(""),
    department_id: str = Form(""), owner_id: str = Form(""), due_at: str = Form(""),
    baseline_metric: str = Form(""), baseline_value: str = Form(""), target_value: str = Form(""), metric_unit: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, INTERNAL)
    clean_title = title.strip()[:220]
    if not clean_title:
        raise ValueError("Improvement title is required")
    category = category.strip().upper()
    if category not in CATEGORIES:
        category = "OTHER"
    priority = priority.strip().upper()
    if priority not in {"LOW", "NORMAL", "HIGH", "URGENT"}:
        priority = "NORMAL"
    dep_id = int(department_id) if department_id.isdigit() else user.department_id
    own_id = int(owner_id) if owner_id.isdigit() and _can_govern_improvement(user) else None
    _validate_owner(db, own_id, user.site_id)
    row = ImprovementItem(
        code=_next_code(db), site_id=user.site_id, department_id=dep_id, created_by_id=user.id, owner_id=own_id,
        title=clean_title, problem_statement=problem_statement.strip()[:6000], category=category, source="EMPLOYEE",
        priority=priority, impact_area=impact_area.strip()[:120], expected_benefit=expected_benefit.strip()[:4000],
        baseline_metric=baseline_metric.strip()[:120], baseline_value=baseline_value.strip()[:80],
        target_value=target_value.strip()[:80], metric_unit=metric_unit.strip()[:40],
        due_at=datetime.fromisoformat(due_at) if due_at else None,
    )
    db.add(row); db.flush()
    _notify_owner(db, row)
    db.add(ImprovementActivity(improvement_item_id=row.id, actor_id=user.id, action="SUBMITTED", note="Improvement opportunity submitted", status_snapshot=row.status))
    add_audit(db, actor=user, request=request, action="IMPROVEMENT_SUBMITTED", entity_type="ImprovementItem", entity_id=row.id, summary=f"{row.code}: {row.title}")
    db.commit()
    return RedirectResponse("/improvement?tab=register", status_code=303)


@router.post("/from-source")
def create_from_source(
    request: Request, source_entity_type: str = Form(...), source_entity_id: int = Form(...),
    title: str = Form(...), problem_statement: str = Form(""), category: str = Form("QUALITY"),
    priority: str = Form("HIGH"), source_url: str = Form(""), db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.TECHNICAL_MANAGER.value, Role.EXCELLENCE.value, Role.SENIOR_CHEMIST.value})
    if user.role == Role.SENIOR_CHEMIST.value and senior_responsibility(user) != "EQUIPMENT":
        raise HTTPException(status_code=403, detail="Only the Equipment & Maintenance Senior may escalate equipment issues to Continuous Improvement")
    entity_type = source_entity_type.strip()[:60]
    model_map = {"QualityCase": QualityCase, "EquipmentAsset": EquipmentAsset, "EquipmentEvent": EquipmentEvent}
    model = model_map.get(entity_type)
    if model is None:
        raise ValueError("Unsupported improvement source")
    source_row = db.get(model, source_entity_id)
    if not source_row:
        raise ValueError("Controlled source record was not found")
    source_site_id = getattr(source_row, "site_id", None)
    if entity_type == "EquipmentEvent":
        source_site_id = source_row.equipment.site_id if source_row.equipment else None
    if user.site_id and source_site_id not in {None, user.site_id}:
        raise HTTPException(status_code=403, detail="Controlled source is outside your site scope")
    existing = db.scalar(select(ImprovementItem).where(
        ImprovementItem.source_entity_type == entity_type,
        ImprovementItem.source_entity_id == source_entity_id,
        ~ImprovementItem.status.in_(["CLOSED", "DEFERRED"]),
    ))
    if existing:
        return RedirectResponse(f"/improvement?tab=register&scope=my-work#item-{existing.id}", status_code=303)
    clean_title = title.strip()[:220]
    if not clean_title:
        raise ValueError("Improvement title is required")
    category = category.strip().upper() if category.strip().upper() in CATEGORIES else "QUALITY"
    priority = priority.strip().upper() if priority.strip().upper() in {"LOW","NORMAL","HIGH","URGENT"} else "HIGH"
    row = ImprovementItem(
        code=_next_code(db), site_id=user.site_id, department_id=user.department_id, created_by_id=user.id,
        title=clean_title, problem_statement=problem_statement.strip()[:6000], category=category,
        source="CONTROLLED_SOURCE", source_entity_type=entity_type, source_entity_id=source_entity_id,
        source_url=source_url.strip()[:300], priority=priority, impact_area="Cross-functional controlled improvement",
    )
    db.add(row); db.flush()
    db.add(ImprovementActivity(improvement_item_id=row.id, actor_id=user.id, action="ESCALATED_FROM_SOURCE", note=f"Linked from {entity_type} #{source_entity_id}", status_snapshot=row.status))
    add_audit(db, actor=user, request=request, action="IMPROVEMENT_ESCALATED_FROM_SOURCE", entity_type="ImprovementItem", entity_id=row.id, summary=f"{row.code}: {row.title}", details={"source_entity_type": entity_type, "source_entity_id": source_entity_id})
    db.commit()
    return RedirectResponse(f"/improvement?tab=register&scope=my-work#item-{row.id}", status_code=303)


@router.post("/{item_id}/update")
def update_item(
    item_id: int, request: Request, status: str = Form(...), owner_id: str = Form(""), due_at: str = Form(""),
    action_plan: str = Form(""), result_summary: str = Form(""), evidence_reference: str = Form(""), note: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, ACTION)
    row = db.get(ImprovementItem, item_id)
    if not row:
        raise ValueError("Improvement item not found")
    if user.site_id and row.site_id not in {None, user.site_id}:
        raise ValueError("Improvement item is outside your site scope")
    if user.role == Role.SENIOR_CHEMIST.value and row.owner_id != user.id:
        raise HTTPException(status_code=403, detail="This responsibility is not assigned to you")
    previous_owner = row.owner_id
    new_status = status.strip().upper()
    if new_status not in STATUSES:
        raise ValueError("Unsupported improvement status")
    is_governor = _can_govern_improvement(user)
    if not is_governor:
        if row.owner_id != user.id:
            raise HTTPException(status_code=403, detail="Only the assigned improvement owner or an improvement governor can update this item")
        if new_status not in {"IN_PROGRESS", "VALIDATION"}:
            raise HTTPException(status_code=403, detail="Assigned improvement owners can progress work to IN_PROGRESS or VALIDATION; governance closes or defers the item")
        if owner_id and int(owner_id) != user.id:
            raise HTTPException(status_code=403, detail="Assigned improvement owners cannot reassign the item")
    row.status = new_status
    if is_governor:
        next_owner = int(owner_id) if owner_id.isdigit() else None
        _validate_owner(db, next_owner, row.site_id)
        row.owner_id = next_owner
    _notify_owner(db, row, previous_owner)
    row.due_at = datetime.fromisoformat(due_at) if due_at else None
    row.action_plan = action_plan.strip()[:6000]
    row.result_summary = result_summary.strip()[:6000]
    row.evidence_reference = evidence_reference.strip()[:300]
    if new_status in {"APPROVED", "IMPLEMENTED", "CLOSED", "DEFERRED"} and not is_governor:
        raise HTTPException(status_code=403, detail="Only improvement governance can approve, implement, close or defer an item")
    if new_status == "CLOSED":
        row.closed_at = datetime.utcnow(); row.approved_by_id = user.id
    db.add(ImprovementActivity(improvement_item_id=row.id, actor_id=user.id, action="UPDATED", note=note.strip()[:4000], status_snapshot=row.status))
    add_audit(db, actor=user, request=request, action="IMPROVEMENT_UPDATED", entity_type="ImprovementItem", entity_id=row.id, summary=f"{row.code}: {row.status}")
    db.commit()
    return RedirectResponse(f"/improvement?tab=register#item-{row.id}", status_code=303)
