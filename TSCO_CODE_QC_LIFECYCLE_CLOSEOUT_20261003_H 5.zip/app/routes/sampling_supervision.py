from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, Form, Request, HTTPException
from fastapi.responses import RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import Client, Role, SamplingAssignment, SamplingOrder, SamplingRequestNotice, User, SampleKit, SampleKitTask, Site
from ..security import require_user
from ..services.capabilities import can_assign_sampleman
from ..services.audit import add_audit
from ..services.identifiers import next_sampling_request_code
from ..services.lab_operations import get_operations_state

router = APIRouter(prefix="/sampling-supervision", tags=["sampling supervision"])
ALLOWED = {Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value, Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value}
WRITE_ALLOWED = {Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value}
REQUEST_WRITE_ALLOWED = {Role.SAMPLING_SUPERVISOR.value}


@router.get("")
def dashboard(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    stmt = select(SamplingAssignment).join(SamplingOrder).order_by(SamplingAssignment.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        stmt = stmt.where(SamplingOrder.site_id == user.site_id)
    if user.role == Role.SAMPLING_SUPERVISOR.value:
        stmt = stmt.where(SamplingOrder.supervisor_id == user.id)
    assignments = db.scalars(stmt.limit(200)).all()
    samplers_stmt = select(User).where(User.role == Role.FIELD_SAMPLER.value, User.active.is_(True))
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        samplers_stmt = samplers_stmt.where(User.site_id == user.site_id)
    samplers = db.scalars(samplers_stmt.order_by(User.full_name)).all()
    clients = db.scalars(select(Client).where(Client.active.is_(True)).order_by(Client.name)).all()
    notices_stmt = select(SamplingRequestNotice).order_by(SamplingRequestNotice.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        notices_stmt = notices_stmt.where(SamplingRequestNotice.site_id == user.site_id)
    if user.role == Role.SAMPLING_SUPERVISOR.value:
        notices_stmt = notices_stmt.where(SamplingRequestNotice.requested_by_id == user.id)
    notices = db.scalars(notices_stmt.limit(100)).all()
    site = db.get(Site, user.site_id) if user.site_id else None
    retained_candidates = []
    if site:
        _, lab_state = get_operations_state(db, site)
        retained_candidates = [
            r for r in lab_state.get("retained", [])
            if str(r.get("status") or "").upper() == "DISPOSED"
            and str(r.get("bottle_reused") or "").strip().lower() in {"yes", "y", "true", "1"}
        ]
    kit_tasks_stmt = select(SampleKitTask).order_by(SampleKitTask.created_at.desc())
    kits_stmt = select(SampleKit).order_by(SampleKit.created_at.desc())
    orders_stmt = select(SamplingOrder).where(SamplingOrder.status.in_(["OPEN", "APPROVED", "IN_PROGRESS"]))
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        kit_tasks_stmt = kit_tasks_stmt.where(SampleKitTask.site_id == user.site_id)
        kits_stmt = kits_stmt.where(SampleKit.site_id == user.site_id)
        orders_stmt = orders_stmt.where(SamplingOrder.site_id == user.site_id)
    kit_tasks = list(db.scalars(kit_tasks_stmt.limit(200)).all())
    kits = list(db.scalars(kits_stmt.limit(100)).all())
    orders = list(db.scalars(orders_stmt.order_by(SamplingOrder.created_at.desc()).limit(100)).all())
    return templates.TemplateResponse("sampling_supervision.html", {
        "request": request, "user": user, "assignments": assignments, "samplers": samplers,
        "clients": clients, "notices": notices, "retained_candidates": retained_candidates,
        "kit_tasks": kit_tasks, "kits": kits, "orders": orders,
    })


@router.post("/requests")
def create_sampling_request(
    request: Request, client_id: int = Form(...), title: str = Form("Sampling request"),
    priority: str = Form("Normal"), expected_samples: int = Form(1), target_sampling_at: str = Form(""),
    notes: str = Form(""), db: Session = Depends(get_db),
):
    user = require_user(request, db, REQUEST_WRITE_ALLOWED)
    client = db.get(Client, client_id)
    if not client or not client.active:
        raise ValueError("Active client is required")
    if not user.site_id:
        raise ValueError("Sampling Supervisor must be assigned to a site")
    priority = priority.strip().title()
    if priority not in {"Normal", "High", "Urgent"}:
        raise ValueError("Unsupported priority")
    if expected_samples < 1 or expected_samples > 500:
        raise ValueError("Expected sample count must be between 1 and 500")
    clean_title = (title or "Sampling request").strip()[:200] or "Sampling request"
    try:
        target = datetime.fromisoformat(target_sampling_at) if target_sampling_at else None
    except ValueError:
        raise ValueError("Target sampling date/time is invalid")
    notice = SamplingRequestNotice(
        request_code=next_sampling_request_code(db, user.site), site_id=user.site_id, client_id=client.id,
        requested_by_id=user.id, title=clean_title, priority=priority, expected_samples=expected_samples,
        target_sampling_at=target, notes=(notes or "").strip()[:4000], status="PENDING_OPERATIONS",
    )
    db.add(notice); db.flush()
    add_audit(db, actor=user, request=request, action="SAMPLING_REQUEST_SUBMITTED", entity_type="SamplingRequestNotice",
              entity_id=notice.id, summary=f"{notice.request_code} submitted to Operations",
              details={"client_id": client.id, "expected_samples": expected_samples, "priority": priority})
    db.commit()
    return RedirectResponse("/sampling-supervision", status_code=303)


@router.post("/assignment/{assignment_id}/assign")
def assign(assignment_id: int, request: Request, sampler_id: int = Form(...), note: str = Form(""), db: Session = Depends(get_db)):
    user = require_user(request, db, WRITE_ALLOWED)
    assignment = db.get(SamplingAssignment, assignment_id)
    sampler = db.get(User, sampler_id)
    if not assignment or not sampler:
        return RedirectResponse("/sampling-supervision", status_code=303)
    if assignment.status == "COMPLETED" or assignment.completed_sample_id:
        raise ValueError("Completed sampling assignments cannot be reassigned")
    if not can_assign_sampleman(user):
        raise HTTPException(status_code=403, detail="Named Sampleman assignment belongs to the Sampling Supervisor, with Field Manager fallback")
    if user.site_id and assignment.order.site_id != user.site_id:
        return RedirectResponse("/sampling-supervision", status_code=303)
    if user.role == Role.SAMPLING_SUPERVISOR.value and assignment.order.supervisor_id != user.id:
        return RedirectResponse("/sampling-supervision", status_code=303)
    if assignment.source_party != "TSCO":
        raise ValueError("Client-collected work is not allocated to TSCO Samplemen through Sampling Supervision")
    if not sampler.active or sampler.role != Role.FIELD_SAMPLER.value or sampler.client_id is not None:
        raise ValueError("Selected user must be an active TSCO Sampleman")
    if sampler.site_id != assignment.order.site_id:
        raise ValueError("Sampler and sampling order must belong to the same site")
    assignment.assigned_sampler_id = sampler.id
    assignment.assigned_at = datetime.utcnow()
    assignment.status = "ASSIGNED"
    if note.strip():
        assignment.instructions = (assignment.instructions + "\n" + note.strip()).strip()
    add_audit(db, actor=user, request=request, action="SAMPLING_ASSIGNMENT_ASSIGNED", entity_type="SamplingAssignment", entity_id=assignment.id, summary=f"Assigned {assignment.assignment_code} to {sampler.full_name}")
    db.commit()
    return RedirectResponse("/sampling-supervision", status_code=303)


@router.post("/sample-kit/tasks")
def create_sample_kit_task(
    request: Request, retained_sample_key: str = Form(...), assigned_to_id: int = Form(...),
    container_type: str = Form("BOTTLE"), note: str = Form(""), db: Session = Depends(get_db),
):
    actor = require_user(request, db, WRITE_ALLOWED)
    if not actor.site_id: raise ValueError("Sampling Supervisor must be assigned to a site")
    sampler = db.get(User, assigned_to_id)
    if not sampler or not sampler.active or sampler.role != Role.FIELD_SAMPLER.value or sampler.site_id != actor.site_id:
        raise ValueError("Preparation task must be assigned to an active TSCO Sampleman at this site")
    site = db.get(Site, actor.site_id); _, payload = get_operations_state(db, site)
    retained = next((r for r in payload.get("retained", []) if str(r.get("sample")) == retained_sample_key.strip()), None)
    if not retained or str(retained.get("status") or "").upper() != "DISPOSED" or str(retained.get("bottle_reused") or "").strip().lower() not in {"yes","y","true","1"}:
        raise ValueError("Container preparation requires a retained-sample disposition already authorized by Laboratory Technical ownership and marked reusable")
    exists = db.scalar(select(SampleKitTask).where(SampleKitTask.site_id == actor.site_id, SampleKitTask.retained_sample_key == retained_sample_key.strip(), SampleKitTask.status.in_(["ASSIGNED","IN_PROGRESS","READY"])))
    if exists: raise ValueError("An active preparation task already exists for this retained container")
    row = SampleKitTask(site_id=actor.site_id, retained_sample_key=retained_sample_key.strip(), container_type=container_type.strip().upper() or "BOTTLE", assigned_to_id=sampler.id, assigned_by_id=actor.id, status="ASSIGNED", note=note.strip())
    db.add(row); db.flush(); add_audit(db, actor=actor, request=request, action="SAMPLE_KIT_PREP_ASSIGNED", entity_type="SampleKitTask", entity_id=row.id, summary=f"{row.retained_sample_key} → {sampler.full_name}")
    db.commit(); return RedirectResponse("/sampling-supervision#sample-kits", 303)


@router.post("/sample-kits")
def create_sample_kit(request: Request, task_ids: list[int] = Form(default=[]), kit_type: str = Form("Transformer Oil Sampling Kit"), contents_summary: str = Form(""), note: str = Form(""), db: Session = Depends(get_db)):
    actor = require_user(request, db, WRITE_ALLOWED)
    if not actor.site_id: raise ValueError("Sampling Supervisor must be assigned to a site")
    if not task_ids: raise ValueError("Select at least one Ready preparation task")
    tasks = list(db.scalars(select(SampleKitTask).where(SampleKitTask.id.in_(task_ids), SampleKitTask.site_id == actor.site_id)).all())
    if len(tasks) != len(set(task_ids)) or any(t.status != "READY" or t.sample_kit_id is not None for t in tasks):
        raise ValueError("Only unallocated Ready preparation tasks can be added to a Sample Kit")
    auto_summary = ", ".join(f"{t.container_type} ({t.retained_sample_key})" for t in tasks)
    row = SampleKit(
        site_id=actor.site_id, kit_code="PENDING", status="PREPARING",
        kit_type=kit_type.strip() or "Transformer Oil Sampling Kit",
        contents_summary=contents_summary.strip() or auto_summary, container_count=len(tasks),
        note=note.strip(), prepared_at=datetime.utcnow(), created_by_id=actor.id,
    )
    db.add(row); db.flush(); row.kit_code = f"KIT-{row.id:04d}"
    for task in tasks: task.sample_kit_id = row.id
    add_audit(db, actor=actor, request=request, action="SAMPLE_KIT_BUILT", entity_type="SampleKit", entity_id=row.id, summary=f"{row.kit_code} · {len(tasks)} prepared container(s)")
    db.commit(); return RedirectResponse("/sampling-supervision#sample-kits", 303)


@router.post("/sample-kits/{kit_id}/ready")
def mark_sample_kit_ready(kit_id: int, request: Request, db: Session = Depends(get_db)):
    actor = require_user(request, db, WRITE_ALLOWED); kit = db.get(SampleKit, kit_id)
    if not kit or (actor.site_id and kit.site_id != actor.site_id): raise ValueError("Sample Kit not found in your site")
    if kit.status != "PREPARING": raise ValueError("Only a preparing Sample Kit can be marked Ready")
    task_count = db.query(SampleKitTask).filter(SampleKitTask.sample_kit_id == kit.id).count()
    if task_count < 1 or task_count != kit.container_count: raise ValueError("Sample Kit contents are incomplete")
    kit.status = "READY"
    add_audit(db, actor=actor, request=request, action="SAMPLE_KIT_READY", entity_type="SampleKit", entity_id=kit.id, summary=f"{kit.kit_code} · {kit.container_count} container(s)")
    db.commit(); return RedirectResponse("/sampling-supervision#sample-kits", 303)


@router.post("/sample-kits/{kit_id}/issue")
def issue_sample_kit(kit_id: int, request: Request, sampler_id: int = Form(...), sampling_order_id: str = Form(""), note: str = Form(""), db: Session = Depends(get_db)):
    actor = require_user(request, db, WRITE_ALLOWED); kit = db.get(SampleKit, kit_id)
    sampler = db.get(User, sampler_id)
    if not kit or (actor.site_id and kit.site_id != actor.site_id): raise ValueError("Sample Kit not found in your site")
    if kit.status not in {"READY", "BUILDING"}: raise ValueError("Only a Ready Sample Kit can be issued")
    if not sampler or not sampler.active or sampler.role != Role.FIELD_SAMPLER.value or sampler.site_id != kit.site_id: raise ValueError("Select an active TSCO Sampleman at the same site")
    order = db.get(SamplingOrder, int(sampling_order_id)) if sampling_order_id.strip() else None
    if order and order.site_id != kit.site_id: raise ValueError("Sampling Order belongs to a different site")
    kit.assigned_sampler_id = sampler.id; kit.sampling_order_id = order.id if order else None; kit.operational_project_id = order.operational_project_id if order else None
    kit.status = "ISSUED"; kit.issued_at = datetime.utcnow(); kit.note = (kit.note + "\n" + note.strip()).strip() if note.strip() else kit.note
    add_audit(db, actor=actor, request=request, action="SAMPLE_KIT_ISSUED", entity_type="SampleKit", entity_id=kit.id, summary=f"{kit.kit_code} → {sampler.full_name}")
    db.commit(); return RedirectResponse("/sampling-supervision#sample-kits", 303)


@router.post("/sample-kits/{kit_id}/reconditioning")
def start_sample_kit_reconditioning(kit_id: int, request: Request, note: str = Form(""), db: Session = Depends(get_db)):
    actor = require_user(request, db, WRITE_ALLOWED); kit = db.get(SampleKit, kit_id)
    if not kit or (actor.site_id and kit.site_id != actor.site_id): raise ValueError("Sample Kit not found in your site")
    if kit.status != "RETURNED": raise ValueError("Only a returned Sample Kit can enter reconditioning")
    kit.status = "RECONDITIONING"
    if note.strip(): kit.note = (kit.note + "\n" + note.strip()).strip()
    add_audit(db, actor=actor, request=request, action="SAMPLE_KIT_RECONDITIONING", entity_type="SampleKit", entity_id=kit.id, summary=kit.kit_code)
    db.commit(); return RedirectResponse("/sampling-supervision#sample-kits", 303)
