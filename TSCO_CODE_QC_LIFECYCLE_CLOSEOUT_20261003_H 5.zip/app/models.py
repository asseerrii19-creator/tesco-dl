from __future__ import annotations

from datetime import datetime
from enum import Enum

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, LargeBinary, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


class Role(str, Enum):
    FIELD_SAMPLER = "field_sampler"
    CLIENT_SAMPLER = "client_sampler"
    CLIENT_OPERATIONS = "client_operations"
    SAMPLING_SUPERVISOR = "sampling_supervisor"
    OPERATIONS_MANAGER = "operations_manager"
    DATA_ENTRY = "data_entry"
    SAMPLE_RECEIVING = "sample_receiving"
    LAB_TECHNICIAN = "lab_technician"
    SENIOR_CHEMIST = "senior_chemist"
    QUALITY = "quality"
    TECHNICAL_MANAGER = "technical_manager"
    MANAGEMENT = "management"
    SALES_MARKETING = "sales_marketing"
    CLIENT_COORDINATOR = "client_coordinator"
    FINANCE = "finance"
    EXCELLENCE = "excellence"
    CORPORATE_SUPPORT = "corporate_support"
    SHARED_SERVICES = "shared_services"
    LAB_SUPPORT = "lab_support"
    CLIENT = "client"
    SYSTEM_ADMIN = "system_admin"


class SampleStatus(str, Enum):
    DRAFT = "DRAFT"
    SUBMITTED = "SUBMITTED"
    RETURNED = "RETURNED"
    REJECTED = "REJECTED"
    ACCEPTED = "ACCEPTED"
    AWAITING_RECEIPT = "AWAITING_RECEIPT"
    IN_TRANSIT = "IN_TRANSIT"
    RECEIVED = "RECEIVED"
    READY_FOR_LAB = "READY_FOR_LAB"
    REGISTERED = "REGISTERED"
    TESTING = "TESTING"
    TECHNICAL_REVIEW = "TECHNICAL_REVIEW"
    REPORT_APPROVED = "REPORT_APPROVED"
    READY_FOR_LMS = "READY_FOR_LMS"  # legacy pre-standalone state; not used by new workflows
    REPORT_RELEASED = "REPORT_RELEASED"


class Site(Base):
    __tablename__ = "sites"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(12), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120))
    laboratory_name: Mapped[str] = mapped_column(String(160))
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class IdentifierSequence(Base):
    __tablename__ = "identifier_sequences"
    id: Mapped[int] = mapped_column(primary_key=True)
    namespace: Mapped[str] = mapped_column(String(40), index=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    year: Mapped[str] = mapped_column(String(4), index=True)
    current_value: Mapped[int] = mapped_column(Integer, default=0)
    site: Mapped[Site] = relationship()
    __table_args__ = (UniqueConstraint("namespace", "site_id", "year", name="uq_identifier_sequence_scope"),)


class Client(Base):
    __tablename__ = "clients"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(24), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    contact_email: Mapped[str] = mapped_column(String(180), default="")
    contact_phone: Mapped[str] = mapped_column(String(60), default="")
    notes: Mapped[str] = mapped_column(Text, default="")
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class Department(Base):
    __tablename__ = "departments"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    code: Mapped[str] = mapped_column(String(40), index=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    site: Mapped[Site | None] = relationship()
    __table_args__ = (UniqueConstraint("site_id", "code", name="uq_department_site_code"),)


class ClientUnit(Base):
    __tablename__ = "client_units"
    id: Mapped[int] = mapped_column(primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    parent_id: Mapped[int | None] = mapped_column(ForeignKey("client_units.id"), nullable=True, index=True)
    unit_type: Mapped[str] = mapped_column(String(40), default="SITE", index=True)
    code: Mapped[str] = mapped_column(String(80), index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    client: Mapped[Client] = relationship()
    parent: Mapped["ClientUnit | None"] = relationship(remote_side="ClientUnit.id")
    __table_args__ = (UniqueConstraint("client_id", "code", name="uq_client_unit_code"),)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(180), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(160))
    password_hash: Mapped[str] = mapped_column(String(300))
    role: Mapped[str] = mapped_column(String(40), index=True)
    job_title: Mapped[str] = mapped_column(String(120), default="")
    senior_responsibility_domain: Mapped[str] = mapped_column(String(30), default="", index=True)
    phone: Mapped[str] = mapped_column(String(60), default="")
    client_id: Mapped[int | None] = mapped_column(ForeignKey("clients.id"), nullable=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True)
    department_id: Mapped[int | None] = mapped_column(ForeignKey("departments.id"), nullable=True)
    manager_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    leave_approver_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    must_change_password: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    client: Mapped[Client | None] = relationship(foreign_keys=[client_id])
    site: Mapped[Site | None] = relationship()
    department: Mapped["Department | None"] = relationship()
    manager: Mapped["User | None"] = relationship("User", remote_side="User.id", foreign_keys=[manager_id], post_update=True)
    leave_approver: Mapped["User | None"] = relationship("User", remote_side="User.id", foreign_keys=[leave_approver_id], post_update=True)
    client_assignments: Mapped[list["UserClientAssignment"]] = relationship(
        back_populates="user", cascade="all, delete-orphan", foreign_keys="UserClientAssignment.user_id"
    )
    client_unit_assignments: Mapped[list["UserClientUnitAssignment"]] = relationship(
        back_populates="user", cascade="all, delete-orphan", foreign_keys="UserClientUnitAssignment.user_id"
    )


class UserClientAssignment(Base):
    __tablename__ = "user_client_assignments"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    user: Mapped[User] = relationship(back_populates="client_assignments", foreign_keys=[user_id])
    client: Mapped[Client] = relationship()
    __table_args__ = (UniqueConstraint("user_id", "client_id", name="uq_user_client_assignment"),)




class UserClientUnitAssignment(Base):
    __tablename__ = "user_client_unit_assignments"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    client_unit_id: Mapped[int] = mapped_column(ForeignKey("client_units.id"), index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    user: Mapped[User] = relationship(back_populates="client_unit_assignments", foreign_keys=[user_id])
    client_unit: Mapped[ClientUnit] = relationship()
    __table_args__ = (UniqueConstraint("user_id", "client_unit_id", name="uq_user_client_unit_assignment"),)


class Quotation(Base):
    __tablename__ = "quotations"
    id: Mapped[int] = mapped_column(primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    number: Mapped[str] = mapped_column(String(80), index=True)
    status: Mapped[str] = mapped_column(String(30), default="ACTIVE")
    description: Mapped[str] = mapped_column(String(240), default="")
    client: Mapped[Client] = relationship()
    __table_args__ = (UniqueConstraint("client_id", "number", name="uq_quote_client_number"),)


class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"
    id: Mapped[int] = mapped_column(primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    quotation_id: Mapped[int | None] = mapped_column(ForeignKey("quotations.id"), nullable=True)
    number: Mapped[str] = mapped_column(String(80), index=True)
    status: Mapped[str] = mapped_column(String(30), default="ACTIVE")
    client: Mapped[Client] = relationship()
    quotation: Mapped[Quotation | None] = relationship()
    __table_args__ = (UniqueConstraint("client_id", "number", name="uq_po_client_number"),)


class CommercialRequestLine(Base):
    __tablename__ = "commercial_request_lines"
    id: Mapped[int] = mapped_column(primary_key=True)
    commercial_case_id: Mapped[int] = mapped_column(ForeignKey("commercial_cases.id"), index=True)
    line_number: Mapped[int] = mapped_column(Integer, default=1)
    quantity: Mapped[int] = mapped_column(Integer, default=1)
    requested_package: Mapped[str] = mapped_column(String(160), default="Routine Test")
    requested_tests_json: Mapped[str] = mapped_column(Text, default="[]")
    expected_serials_json: Mapped[str] = mapped_column(Text, default="[]")
    method_family: Mapped[str] = mapped_column(String(20), default="DEFAULT")
    priority: Mapped[str] = mapped_column(String(20), default="NORMAL")
    required_tat: Mapped[str] = mapped_column(String(40), default="")
    due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="ACTIVE", index=True)
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    case: Mapped["CommercialCase"] = relationship(back_populates="request_lines")
    created_by: Mapped["User | None"] = relationship(foreign_keys=[created_by_id])
    samples: Mapped[list["SampleRequest"]] = relationship(back_populates="commercial_request_line")
    __table_args__ = (UniqueConstraint("commercial_case_id", "line_number", name="uq_commercial_request_line_number"),)



class OperationalProject(Base):
    __tablename__ = "operational_projects"
    id: Mapped[int] = mapped_column(primary_key=True)
    project_reference: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    project_name: Mapped[str] = mapped_column(String(220), index=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    commercial_case_id: Mapped[int | None] = mapped_column(ForeignKey("commercial_cases.id", use_alter=True, name="fk_operational_project_commercial_case"), nullable=True, index=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    approved_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    project_type: Mapped[str] = mapped_column(String(80), default="GENERAL")
    scope: Mapped[str] = mapped_column(Text, default="")
    location_scope: Mapped[str] = mapped_column(String(220), default="")
    planned_start_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    planned_end_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    field_scope: Mapped[bool] = mapped_column(Boolean, default=False)
    laboratory_scope: Mapped[bool] = mapped_column(Boolean, default=True)
    expected_samples: Mapped[int | None] = mapped_column(Integer, nullable=True)
    test_package: Mapped[str] = mapped_column(String(160), default="")
    special_tat: Mapped[str] = mapped_column(String(80), default="")
    status: Mapped[str] = mapped_column(String(40), default="DRAFT", index=True)
    supporting_notes: Mapped[str] = mapped_column(Text, default="")
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    approved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    site: Mapped[Site] = relationship()
    client: Mapped[Client] = relationship()
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])
    approved_by: Mapped[User | None] = relationship(foreign_keys=[approved_by_id])
    commercial_case: Mapped["CommercialCase | None"] = relationship(foreign_keys=[commercial_case_id], post_update=True)


class CommercialCase(Base):
    """End-to-end business communication case.

    This record spans the business journey before and after the laboratory sample
    lifecycle. Sampling/laboratory data remain in their dedicated tables and are
    linked here instead of duplicated.
    """
    __tablename__ = "commercial_cases"
    id: Mapped[int] = mapped_column(primary_key=True)
    case_code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    owner_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    assigned_coordinator_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    operational_project_id: Mapped[int | None] = mapped_column(ForeignKey("operational_projects.id", use_alter=True, name="fk_commercial_cases_operational_project"), nullable=True, index=True)
    quotation_id: Mapped[int | None] = mapped_column(ForeignKey("quotations.id"), nullable=True, index=True)
    purchase_order_id: Mapped[int | None] = mapped_column(ForeignKey("purchase_orders.id"), nullable=True, index=True)
    sampling_order_id: Mapped[int | None] = mapped_column(ForeignKey("sampling_orders.id", use_alter=True, name="fk_commercial_sampling_order"), nullable=True, index=True)
    sample_request_id: Mapped[int | None] = mapped_column(ForeignKey("sample_requests.id", use_alter=True, name="fk_commercial_sample_request"), nullable=True, index=True)
    current_stage: Mapped[str] = mapped_column(String(50), default="LEAD_GENERATION", index=True)
    status: Mapped[str] = mapped_column(String(30), default="ACTIVE", index=True)

    lead_title: Mapped[str] = mapped_column(String(220), default="")
    lead_source: Mapped[str] = mapped_column(String(120), default="")
    proposal_reference: Mapped[str] = mapped_column(String(160), default="")
    client_follow_up: Mapped[str] = mapped_column(Text, default="")
    po_received_reference: Mapped[str] = mapped_column(String(160), default="")
    handover_commercial: Mapped[str] = mapped_column(Text, default="")
    handover_technical: Mapped[str] = mapped_column(Text, default="")
    handover_client_info: Mapped[str] = mapped_column(Text, default="")
    expected_samples: Mapped[int | None] = mapped_column(Integer, nullable=True)
    requested_test_package: Mapped[str] = mapped_column(String(160), default="")
    default_priority: Mapped[str] = mapped_column(String(20), default="NORMAL")
    required_tat: Mapped[str] = mapped_column(String(40), default="")
    request_source: Mapped[str] = mapped_column(String(30), default="INTERNAL", index=True)
    request_status: Mapped[str] = mapped_column(String(30), default="INTERNAL", index=True)
    client_message: Mapped[str] = mapped_column(Text, default="")
    expected_arrival_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    sample_delivery_mode: Mapped[str] = mapped_column(String(30), default="TBD")
    sample_delivery_notes: Mapped[str] = mapped_column(Text, default="")
    client_submitted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    request_opened_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    request_opened_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    report_submission_reference: Mapped[str] = mapped_column(String(180), default="")
    invoice_number: Mapped[str] = mapped_column(String(120), default="")
    payment_reference: Mapped[str] = mapped_column(String(120), default="")
    corporate_admin_status: Mapped[str] = mapped_column(String(60), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    site: Mapped[Site] = relationship(foreign_keys=[site_id])
    client: Mapped[Client] = relationship(foreign_keys=[client_id])
    owner: Mapped[User | None] = relationship(foreign_keys=[owner_id])
    assigned_coordinator: Mapped[User | None] = relationship(foreign_keys=[assigned_coordinator_id])
    request_opened_by: Mapped[User | None] = relationship(foreign_keys=[request_opened_by_id])
    operational_project: Mapped[OperationalProject | None] = relationship(foreign_keys=[operational_project_id], post_update=True)
    quotation: Mapped[Quotation | None] = relationship(foreign_keys=[quotation_id])
    purchase_order: Mapped[PurchaseOrder | None] = relationship(foreign_keys=[purchase_order_id])
    sampling_order: Mapped["SamplingOrder | None"] = relationship(foreign_keys=[sampling_order_id], post_update=True)
    sample_request: Mapped["SampleRequest | None"] = relationship(foreign_keys=[sample_request_id], post_update=True)
    request_lines: Mapped[list["CommercialRequestLine"]] = relationship(back_populates="case", cascade="all, delete-orphan", order_by="CommercialRequestLine.line_number")
    events: Mapped[list["CommercialEvent"]] = relationship(back_populates="case", cascade="all, delete-orphan")
    attachments: Mapped[list["CommercialAttachment"]] = relationship(back_populates="case", cascade="all, delete-orphan")


class CommercialEvent(Base):
    __tablename__ = "commercial_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    commercial_case_id: Mapped[int] = mapped_column(ForeignKey("commercial_cases.id"), index=True)
    actor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    from_stage: Mapped[str] = mapped_column(String(50), default="")
    to_stage: Mapped[str] = mapped_column(String(50), index=True)
    note: Mapped[str] = mapped_column(Text, default="")
    reference: Mapped[str] = mapped_column(String(180), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    case: Mapped[CommercialCase] = relationship(back_populates="events")
    actor: Mapped[User | None] = relationship(foreign_keys=[actor_id])


class CommercialAttachment(Base):
    """Controlled quotation / PO / handover evidence linked to one business case.

    Samples and sampling orders link to the CommercialCase, so these documents stay
    attached to the same controlled chain without duplicating files on every sample.
    """
    __tablename__ = "commercial_attachments"
    id: Mapped[int] = mapped_column(primary_key=True)
    commercial_case_id: Mapped[int] = mapped_column(ForeignKey("commercial_cases.id"), index=True)
    document_type: Mapped[str] = mapped_column(String(40), index=True)
    original_name: Mapped[str] = mapped_column(String(220))
    stored_path: Mapped[str] = mapped_column(String(500))
    content_type: Mapped[str] = mapped_column(String(120), default="application/octet-stream")
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    content_blob: Mapped[bytes | None] = mapped_column(LargeBinary, nullable=True)
    uploaded_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    case: Mapped[CommercialCase] = relationship(back_populates="attachments")
    uploaded_by: Mapped[User | None] = relationship(foreign_keys=[uploaded_by_id])


class Asset(Base):
    __tablename__ = "assets"
    id: Mapped[int] = mapped_column(primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    client_unit_id: Mapped[int | None] = mapped_column(ForeignKey("client_units.id"), nullable=True, index=True)
    asset_code: Mapped[str] = mapped_column(String(80), index=True)
    serial_number: Mapped[str] = mapped_column(String(120), index=True)
    equipment_type: Mapped[str] = mapped_column(String(80), default="Transformer")
    manufacturer: Mapped[str] = mapped_column(String(120), default="")
    voltage_kv: Mapped[float | None] = mapped_column(Float, nullable=True)
    rated_mva: Mapped[float | None] = mapped_column(Float, nullable=True)
    hv_voltage_kv: Mapped[float | None] = mapped_column(Float, nullable=True)
    lv_voltage_kv: Mapped[float | None] = mapped_column(Float, nullable=True)
    sealing_system: Mapped[str] = mapped_column(String(100), default="")
    cooling_type: Mapped[str] = mapped_column(String(100), default="")
    manufacturer_country: Mapped[str] = mapped_column(String(100), default="")
    manufacture_year: Mapped[int | None] = mapped_column(Integer, nullable=True)
    oil_type: Mapped[str] = mapped_column(String(120), default="")
    oil_weight_kg: Mapped[float | None] = mapped_column(Float, nullable=True)
    owner_name: Mapped[str] = mapped_column(String(180), default="")
    tap_changer_type: Mapped[str] = mapped_column(String(100), default="")
    tap_changer_chamber: Mapped[str] = mapped_column(String(100), default="")
    tag_number: Mapped[str] = mapped_column(String(100), default="")
    phase: Mapped[str] = mapped_column(String(40), default="")
    operating_period: Mapped[str] = mapped_column(String(100), default="")
    sampling_points_json: Mapped[str] = mapped_column(Text, default="[]")
    station_name: Mapped[str] = mapped_column(String(160), default="")
    asset_location_label: Mapped[str] = mapped_column(String(200), default="")
    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    client: Mapped[Client] = relationship()
    client_unit: Mapped["ClientUnit | None"] = relationship()
    __table_args__ = (
        UniqueConstraint("client_id", "asset_code", name="uq_asset_client_code"),
    )


class SamplingRequestNotice(Base):
    __tablename__ = "sampling_request_notices"
    id: Mapped[int] = mapped_column(primary_key=True)
    request_code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    requested_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    title: Mapped[str] = mapped_column(String(200), default="Sampling request")
    priority: Mapped[str] = mapped_column(String(30), default="Normal")
    expected_samples: Mapped[int] = mapped_column(Integer, default=1)
    target_sampling_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(30), default="PENDING_OPERATIONS", index=True)
    converted_order_id: Mapped[int | None] = mapped_column(ForeignKey("sampling_orders.id"), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    converted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    site: Mapped[Site] = relationship()
    client: Mapped[Client] = relationship()
    requested_by: Mapped[User] = relationship(foreign_keys=[requested_by_id])
    converted_order: Mapped["SamplingOrder | None"] = relationship(foreign_keys=[converted_order_id])


class SamplingOrder(Base):
    __tablename__ = "sampling_orders"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_number: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    quotation_id: Mapped[int | None] = mapped_column(ForeignKey("quotations.id"), nullable=True)
    purchase_order_id: Mapped[int | None] = mapped_column(ForeignKey("purchase_orders.id"), nullable=True)
    commercial_case_id: Mapped[int | None] = mapped_column(ForeignKey("commercial_cases.id"), nullable=True, index=True)
    operational_project_id: Mapped[int | None] = mapped_column(ForeignKey("operational_projects.id"), nullable=True, index=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    supervisor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    title: Mapped[str] = mapped_column(String(200), default="Sampling request")
    priority: Mapped[str] = mapped_column(String(30), default="Normal")
    status: Mapped[str] = mapped_column(String(30), default="OPEN", index=True)
    due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    site: Mapped[Site] = relationship()
    client: Mapped[Client] = relationship()
    quotation: Mapped[Quotation | None] = relationship()
    purchase_order: Mapped[PurchaseOrder | None] = relationship()
    operational_project: Mapped[OperationalProject | None] = relationship()
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])
    supervisor: Mapped[User | None] = relationship(foreign_keys=[supervisor_id])
    assignments: Mapped[list["SamplingAssignment"]] = relationship(back_populates="order", cascade="all, delete-orphan")


class SamplingAssignment(Base):
    __tablename__ = "sampling_assignments"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("sampling_orders.id"), index=True)
    asset_id: Mapped[int | None] = mapped_column(ForeignKey("assets.id"), nullable=True, index=True)
    assigned_sampler_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    assignment_code: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    sample_label: Mapped[str] = mapped_column(String(180), default="", index=True)
    source_party: Mapped[str] = mapped_column(String(30), default="TSCO")
    task_type: Mapped[str] = mapped_column(String(40), default="ON_SITE_SAMPLING", index=True)
    commercial_request_line_id: Mapped[int | None] = mapped_column(ForeignKey("commercial_request_lines.id"), nullable=True, index=True)
    requested_package: Mapped[str] = mapped_column(String(120), default="Routine Test")
    requested_method_family: Mapped[str] = mapped_column(String(20), default="DEFAULT")
    requested_tests_json: Mapped[str] = mapped_column(Text, default="[]")
    priority: Mapped[str] = mapped_column(String(20), default="NORMAL")
    required_tat: Mapped[str] = mapped_column(String(30), default="")
    due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    sampling_point: Mapped[str] = mapped_column(String(100), default="Main Tank Bottom")
    container_count: Mapped[int] = mapped_column(Integer, default=1)
    status: Mapped[str] = mapped_column(String(30), default="UNASSIGNED", index=True)
    instructions: Mapped[str] = mapped_column(Text, default="")
    assigned_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_sample_id: Mapped[int | None] = mapped_column(ForeignKey("sample_requests.id", use_alter=True, name="fk_assignment_completed_sample"), nullable=True)
    resample_of_sample_id: Mapped[int | None] = mapped_column(
        ForeignKey("sample_requests.id", use_alter=True, name="fk_assignment_resample_source"),
        nullable=True, unique=True, index=True,
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    order: Mapped[SamplingOrder] = relationship(back_populates="assignments")
    asset: Mapped[Asset | None] = relationship()
    assigned_sampler: Mapped[User | None] = relationship(foreign_keys=[assigned_sampler_id])
    commercial_request_line: Mapped[CommercialRequestLine | None] = relationship()


class OperationsState(Base):
    __tablename__ = "operations_states"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), unique=True, index=True)
    json_data: Mapped[str] = mapped_column(Text, default="{}")
    revision: Mapped[int] = mapped_column(Integer, default=0)
    updated_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    site: Mapped[Site] = relationship()
    updated_by: Mapped[User | None] = relationship()


class SampleRequest(Base):
    __tablename__ = "sample_requests"
    id: Mapped[int] = mapped_column(primary_key=True)
    request_number: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    public_token: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    barcode_value: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    status: Mapped[str] = mapped_column(String(40), default=SampleStatus.DRAFT.value, index=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    quotation_id: Mapped[int | None] = mapped_column(ForeignKey("quotations.id"), nullable=True)
    purchase_order_id: Mapped[int | None] = mapped_column(ForeignKey("purchase_orders.id"), nullable=True)
    commercial_case_id: Mapped[int | None] = mapped_column(ForeignKey("commercial_cases.id"), nullable=True, index=True)
    commercial_request_line_id: Mapped[int | None] = mapped_column(ForeignKey("commercial_request_lines.id"), nullable=True, index=True)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), index=True)
    sampler_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    sampling_assignment_id: Mapped[int | None] = mapped_column(ForeignKey("sampling_assignments.id"), nullable=True, index=True)
    submission_channel: Mapped[str] = mapped_column(String(30), default="TSCO_FIELD")

    sample_date_time: Mapped[datetime] = mapped_column(DateTime, index=True)
    sampling_point: Mapped[str] = mapped_column(String(100))
    requested_package: Mapped[str] = mapped_column(String(120), default="Routine Test")
    requested_method_family: Mapped[str] = mapped_column(String(20), default="DEFAULT")
    requested_tests_json: Mapped[str] = mapped_column(Text, default="[]")
    sample_origin: Mapped[str] = mapped_column(String(50), default="TSCO Field-Sampled", index=True)
    priority: Mapped[str] = mapped_column(String(20), default="NORMAL", index=True)
    required_tat: Mapped[str] = mapped_column(String(30), default="")
    due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    equipment_status: Mapped[str] = mapped_column(String(80), default="")
    sampling_reason: Mapped[str] = mapped_column(String(180), default="")
    work_order_number: Mapped[str] = mapped_column(String(100), default="")
    sap_number: Mapped[str] = mapped_column(String(100), default="")
    oil_temperature_c: Mapped[float | None] = mapped_column(Float, nullable=True)
    ambient_temperature_c: Mapped[float | None] = mapped_column(Float, nullable=True)
    ambient_humidity_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    gps_latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    gps_longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    gps_accuracy_m: Mapped[float | None] = mapped_column(Float, nullable=True)
    field_notes: Mapped[str] = mapped_column(Text, default="")
    container_count: Mapped[int] = mapped_column(Integer, default=1)

    lms_number: Mapped[str | None] = mapped_column(String(80), nullable=True, index=True)
    client_sample_reference: Mapped[str] = mapped_column(String(100), default="")
    data_entry_note: Mapped[str] = mapped_column(Text, default="")
    return_reason: Mapped[str] = mapped_column(Text, default="")
    rejection_reason: Mapped[str] = mapped_column(Text, default="")

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    accepted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    received_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    registered_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    released_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    site: Mapped[Site] = relationship()
    client: Mapped[Client] = relationship()
    quotation: Mapped[Quotation | None] = relationship()
    purchase_order: Mapped[PurchaseOrder | None] = relationship()
    commercial_request_line: Mapped[CommercialRequestLine | None] = relationship(back_populates="samples")
    asset: Mapped[Asset] = relationship()
    sampler: Mapped[User | None] = relationship(foreign_keys=[sampler_id])
    sampling_assignment: Mapped[SamplingAssignment | None] = relationship(foreign_keys=[sampling_assignment_id])
    photos: Mapped[list["SamplePhoto"]] = relationship(back_populates="sample", cascade="all, delete-orphan")
    events: Mapped[list["CustodyEvent"]] = relationship(back_populates="sample", cascade="all, delete-orphan")
    issues: Mapped[list["DataQualityIssue"]] = relationship(back_populates="sample", cascade="all, delete-orphan")


class SamplePhoto(Base):
    __tablename__ = "sample_photos"
    id: Mapped[int] = mapped_column(primary_key=True)
    sample_request_id: Mapped[int] = mapped_column(ForeignKey("sample_requests.id"), index=True)
    kind: Mapped[str] = mapped_column(String(60), default="General")
    original_name: Mapped[str] = mapped_column(String(220))
    stored_path: Mapped[str] = mapped_column(String(500))
    uploaded_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    sample: Mapped[SampleRequest] = relationship(back_populates="photos")


class CustodyEvent(Base):
    __tablename__ = "custody_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    sample_request_id: Mapped[int] = mapped_column(ForeignKey("sample_requests.id"), index=True)
    event_type: Mapped[str] = mapped_column(String(60), index=True)
    status: Mapped[str] = mapped_column(String(40), index=True)
    actor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    note: Mapped[str] = mapped_column(Text, default="")
    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    event_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    sample: Mapped[SampleRequest] = relationship(back_populates="events")
    actor: Mapped[User | None] = relationship()


class DataQualityIssue(Base):
    __tablename__ = "data_quality_issues"
    id: Mapped[int] = mapped_column(primary_key=True)
    sample_request_id: Mapped[int] = mapped_column(ForeignKey("sample_requests.id"), index=True)
    issue_type: Mapped[str] = mapped_column(String(80), index=True)
    severity: Mapped[str] = mapped_column(String(20), default="MEDIUM")
    description: Mapped[str] = mapped_column(Text)
    reported_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    sample: Mapped[SampleRequest] = relationship(back_populates="issues")
    reported_by: Mapped[User | None] = relationship()


class LmsSyncLog(Base):
    __tablename__ = "lms_sync_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    sample_request_id: Mapped[int] = mapped_column(ForeignKey("sample_requests.id"), index=True)
    direction: Mapped[str] = mapped_column(String(20))
    operation: Mapped[str] = mapped_column(String(80))
    status: Mapped[str] = mapped_column(String(30))
    external_reference: Mapped[str] = mapped_column(String(120), default="")
    request_payload: Mapped[str] = mapped_column(Text, default="")
    response_payload: Mapped[str] = mapped_column(Text, default="")
    error_message: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class TechnicalAssessmentRecord(Base):
    __tablename__ = "technical_assessment_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    sample_request_id: Mapped[int] = mapped_column(ForeignKey("sample_requests.id"), unique=True, index=True)
    profile: Mapped[str] = mapped_column(String(80), default="IEC 60422 / IEC 60599")
    system_findings_json: Mapped[str] = mapped_column(Text, default="{}")
    recommendation: Mapped[str] = mapped_column(Text, default="")
    decision: Mapped[str] = mapped_column(String(40), default="DRAFT", index=True)
    reviewed_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    sample: Mapped[SampleRequest] = relationship()
    reviewed_by: Mapped[User | None] = relationship()


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    actor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    action: Mapped[str] = mapped_column(String(80), index=True)
    entity_type: Mapped[str] = mapped_column(String(80), index=True)
    entity_id: Mapped[str] = mapped_column(String(80), default="", index=True)
    summary: Mapped[str] = mapped_column(String(260), default="")
    details: Mapped[str] = mapped_column(Text, default="")
    ip_address: Mapped[str] = mapped_column(String(80), default="")
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    actor: Mapped[User | None] = relationship(foreign_keys=[actor_id])
    site: Mapped[Site | None] = relationship()


class ControlledDocument(Base):
    __tablename__ = "controlled_documents"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    document_type: Mapped[str] = mapped_column(String(40), index=True)
    code: Mapped[str] = mapped_column(String(80), index=True)
    title: Mapped[str] = mapped_column(String(220), index=True)
    revision: Mapped[str] = mapped_column(String(40), default="00")
    status: Mapped[str] = mapped_column(String(30), default="ACTIVE", index=True)
    effective_date: Mapped[str] = mapped_column(String(20), default="")
    workstation: Mapped[str] = mapped_column(String(120), default="", index=True)
    test_name: Mapped[str] = mapped_column(String(220), default="", index=True)
    method_name: Mapped[str] = mapped_column(String(160), default="", index=True)
    original_filename: Mapped[str] = mapped_column(String(240))
    stored_filename: Mapped[str] = mapped_column(String(300), unique=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    uploaded_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    technical_reviewed_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    manager_approved_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    technical_reviewed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    manager_approved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    site: Mapped[Site | None] = relationship()
    uploaded_by: Mapped[User | None] = relationship(foreign_keys=[uploaded_by_id])
    technical_reviewed_by: Mapped[User | None] = relationship(foreign_keys=[technical_reviewed_by_id])
    manager_approved_by: Mapped[User | None] = relationship(foreign_keys=[manager_approved_by_id])


class TestPackageConfig(Base):
    __tablename__ = "test_package_configs"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    code: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    scope: Mapped[str] = mapped_column(String(80), default="GENERAL")
    tests_json: Mapped[str] = mapped_column(Text, default="[]")
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    site: Mapped[Site | None] = relationship()


class WorkflowDefinition(Base):
    __tablename__ = "workflow_definitions"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    code: Mapped[str] = mapped_column(String(80), index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    sample_type: Mapped[str] = mapped_column(String(80), default="GENERAL")
    version: Mapped[int] = mapped_column(Integer, default=1)
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    site: Mapped[Site | None] = relationship()
    steps: Mapped[list["WorkflowStep"]] = relationship(back_populates="workflow", cascade="all, delete-orphan", order_by="WorkflowStep.step_order")
    __table_args__ = (UniqueConstraint("site_id", "code", "version", name="uq_workflow_site_code_version"),)


class WorkflowStep(Base):
    __tablename__ = "workflow_steps"
    id: Mapped[int] = mapped_column(primary_key=True)
    workflow_id: Mapped[int] = mapped_column(ForeignKey("workflow_definitions.id"), index=True)
    step_order: Mapped[int] = mapped_column(Integer)
    step_key: Mapped[str] = mapped_column(String(80))
    label: Mapped[str] = mapped_column(String(160))
    responsible_role: Mapped[str] = mapped_column(String(40), default="")
    approval_required: Mapped[bool] = mapped_column(Boolean, default=False)
    terminal: Mapped[bool] = mapped_column(Boolean, default=False)
    workflow: Mapped[WorkflowDefinition] = relationship(back_populates="steps")
    __table_args__ = (UniqueConstraint("workflow_id", "step_order", name="uq_workflow_step_order"),)


class ApprovalPolicy(Base):
    __tablename__ = "approval_policies"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    code: Mapped[str] = mapped_column(String(80), index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    entity_type: Mapped[str] = mapped_column(String(80), default="SAMPLE_REPORT")
    stages_json: Mapped[str] = mapped_column(Text, default="[]")
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    site: Mapped[Site | None] = relationship()
    __table_args__ = (UniqueConstraint("site_id", "code", name="uq_approval_site_code"),)


class IntegrationQueueItem(Base):
    __tablename__ = "integration_queue"
    id: Mapped[int] = mapped_column(primary_key=True)
    sample_request_id: Mapped[int | None] = mapped_column(ForeignKey("sample_requests.id"), nullable=True, index=True)
    integration: Mapped[str] = mapped_column(String(40), default="EXTERNAL", index=True)
    direction: Mapped[str] = mapped_column(String(20), default="OUTBOUND")
    operation: Mapped[str] = mapped_column(String(80), index=True)
    status: Mapped[str] = mapped_column(String(30), default="PENDING", index=True)
    payload_json: Mapped[str] = mapped_column(Text, default="{}")
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    external_reference: Mapped[str] = mapped_column(String(120), default="")
    last_error: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    sample: Mapped[SampleRequest | None] = relationship()

# --- Project 00012 enterprise closeout modules (v2.7) ---
class EquipmentAsset(Base):
    __tablename__ = "equipment_assets"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    equipment_id: Mapped[str] = mapped_column(String(40), index=True)
    name: Mapped[str] = mapped_column(String(180))
    manufacturer: Mapped[str] = mapped_column(String(120), default="")
    model: Mapped[str] = mapped_column(String(120), default="")
    serial_number: Mapped[str] = mapped_column(String(120), default="")
    workstation: Mapped[str] = mapped_column(String(120), default="", index=True)
    test_method: Mapped[str] = mapped_column(String(180), default="")
    status: Mapped[str] = mapped_column(String(30), default="IN_SERVICE", index=True)
    calibration_provider: Mapped[str] = mapped_column(String(180), default="")
    calibration_certificate: Mapped[str] = mapped_column(String(180), default="")
    last_calibration_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    next_calibration_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    last_verification_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    next_verification_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    site: Mapped[Site] = relationship()
    __table_args__ = (UniqueConstraint("site_id", "equipment_id", name="uq_equipment_site_id"),)


class EquipmentEvent(Base):
    __tablename__ = "equipment_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    equipment_asset_id: Mapped[int] = mapped_column(ForeignKey("equipment_assets.id"), index=True)
    event_type: Mapped[str] = mapped_column(String(40), index=True)  # QC/CALIBRATION/MAINTENANCE/FAILURE/VERIFICATION
    status: Mapped[str] = mapped_column(String(30), default="OPEN", index=True)
    result: Mapped[str] = mapped_column(String(80), default="")
    details: Mapped[str] = mapped_column(Text, default="")
    certificate_reference: Mapped[str] = mapped_column(String(180), default="")
    performed_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    event_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    next_due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    equipment: Mapped[EquipmentAsset] = relationship()
    performed_by: Mapped[User | None] = relationship()


class CompetencyRecord(Base):
    __tablename__ = "competency_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    test_name: Mapped[str] = mapped_column(String(180), index=True)
    method_name: Mapped[str] = mapped_column(String(180), default="", index=True)
    workstation: Mapped[str] = mapped_column(String(120), default="", index=True)
    category: Mapped[int] = mapped_column(Integer, default=1)  # Skill Matrix Cat1-Cat5
    technical_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    data_processing_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    overall_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    authorization: Mapped[str] = mapped_column(String(30), default="TRAINING", index=True)  # INDEPENDENT/SUPERVISED/FAILED/TRAINING
    effective_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    evaluated_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    evidence_reference: Mapped[str] = mapped_column(String(240), default="")
    notes: Mapped[str] = mapped_column(Text, default="")
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    site: Mapped[Site] = relationship()
    user: Mapped[User] = relationship(foreign_keys=[user_id])
    evaluated_by: Mapped[User | None] = relationship(foreign_keys=[evaluated_by_id])


class QualityCase(Base):
    __tablename__ = "quality_cases"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    case_number: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    case_type: Mapped[str] = mapped_column(String(40), index=True)  # VALIDATION/VERIFICATION/ILC_PT/CAPA/NCR
    title: Mapped[str] = mapped_column(String(220))
    test_name: Mapped[str] = mapped_column(String(180), default="", index=True)
    method_name: Mapped[str] = mapped_column(String(180), default="")
    equipment_asset_id: Mapped[int | None] = mapped_column(ForeignKey("equipment_assets.id"), nullable=True, index=True)
    method_document_id: Mapped[int | None] = mapped_column(ForeignKey("controlled_documents.id"), nullable=True, index=True)
    sop_document_id: Mapped[int | None] = mapped_column(ForeignKey("controlled_documents.id"), nullable=True, index=True)
    assigned_to_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(40), default="OPEN", index=True)
    priority: Mapped[str] = mapped_column(String(20), default="NORMAL")
    due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    protocol_json: Mapped[str] = mapped_column(Text, default="{}")
    raw_runs_json: Mapped[str] = mapped_column(Text, default="[]")
    calculation_json: Mapped[str] = mapped_column(Text, default="{}")
    root_cause: Mapped[str] = mapped_column(Text, default="")
    corrective_action: Mapped[str] = mapped_column(Text, default="")
    effectiveness_review: Mapped[str] = mapped_column(Text, default="")
    scheme_name: Mapped[str] = mapped_column(String(180), default="")
    evaluation_criteria: Mapped[str] = mapped_column(Text, default="")
    evidence_reference: Mapped[str] = mapped_column(String(240), default="")
    review_conclusion: Mapped[str] = mapped_column(String(40), default="")
    review_note: Mapped[str] = mapped_column(Text, default="")
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    reviewed_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    site: Mapped[Site] = relationship()
    equipment: Mapped[EquipmentAsset | None] = relationship()
    method_document: Mapped[ControlledDocument | None] = relationship(foreign_keys=[method_document_id])
    sop_document: Mapped[ControlledDocument | None] = relationship(foreign_keys=[sop_document_id])
    assigned_to: Mapped[User | None] = relationship(foreign_keys=[assigned_to_id])
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])
    reviewed_by: Mapped[User | None] = relationship(foreign_keys=[reviewed_by_id])


class QualityExecutionRevision(Base):
    __tablename__ = "quality_execution_revisions"
    id: Mapped[int] = mapped_column(primary_key=True)
    quality_case_id: Mapped[int] = mapped_column(ForeignKey("quality_cases.id"), index=True)
    revision: Mapped[int] = mapped_column(Integer, default=1)
    raw_runs_json: Mapped[str] = mapped_column(Text, default="[]")
    calculation_json: Mapped[str] = mapped_column(Text, default="{}")
    evidence_reference: Mapped[str] = mapped_column(String(240), default="")
    submitted_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    submitted_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    return_reason: Mapped[str] = mapped_column(Text, default="")
    quality_case: Mapped[QualityCase] = relationship()
    submitted_by: Mapped[User] = relationship()
    __table_args__ = (UniqueConstraint("quality_case_id", "revision", name="uq_quality_execution_case_revision"),)


class StaffAvailability(Base):
    __tablename__ = "staff_availability"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    entry_type: Mapped[str] = mapped_column(String(30), index=True)  # LEAVE/SHIFT/ON_CALL/HOLIDAY/HANDOVER
    start_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    end_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    status: Mapped[str] = mapped_column(String(40), default="PLANNED", index=True)
    shift_code: Mapped[str] = mapped_column(String(40), default="")
    notes: Mapped[str] = mapped_column(Text, default="")
    approver_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    approved_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    site: Mapped[Site] = relationship()
    user: Mapped[User] = relationship(foreign_keys=[user_id])
    approver: Mapped[User | None] = relationship(foreign_keys=[approver_id])
    approved_by: Mapped[User | None] = relationship(foreign_keys=[approved_by_id])
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])


class LeaveCoverageAssignment(Base):
    __tablename__ = "leave_coverage_assignments"
    id: Mapped[int] = mapped_column(primary_key=True)
    leave_availability_id: Mapped[int] = mapped_column(ForeignKey("staff_availability.id"), unique=True, index=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    absent_user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    acting_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    responsibility_domain: Mapped[str] = mapped_column(String(30), default="", index=True)
    required_minimum: Mapped[int] = mapped_column(Integer, default=2)
    available_senior_count: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(40), default="ACTION_REQUIRED", index=True)
    note: Mapped[str] = mapped_column(Text, default="")
    checked_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    checked_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    leave: Mapped[StaffAvailability] = relationship(foreign_keys=[leave_availability_id])
    site: Mapped[Site] = relationship()
    absent_user: Mapped[User] = relationship(foreign_keys=[absent_user_id])
    acting_user: Mapped[User | None] = relationship(foreign_keys=[acting_user_id])
    checked_by: Mapped[User | None] = relationship(foreign_keys=[checked_by_id])


class EvidenceRecord(Base):
    __tablename__ = "evidence_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    sample_request_id: Mapped[int | None] = mapped_column(ForeignKey("sample_requests.id"), nullable=True, index=True)
    quality_case_id: Mapped[int | None] = mapped_column(ForeignKey("quality_cases.id"), nullable=True, index=True)
    equipment_asset_id: Mapped[int | None] = mapped_column(ForeignKey("equipment_assets.id"), nullable=True, index=True)
    evidence_type: Mapped[str] = mapped_column(String(50), index=True)  # DGA_SOURCE/DGA_CHROMATOGRAM/CORROSIVE_FRONT/CORROSIVE_BACK/CORROSIVE_COPPER/CORROSIVE_PAPER_INNER/CORROSIVE_PAPER_OUTER/PAPER_DP_EVIDENCE/VALIDATION/QC
    title: Mapped[str] = mapped_column(String(220))
    original_filename: Mapped[str] = mapped_column(String(240), default="")
    stored_path: Mapped[str] = mapped_column(String(500), default="")
    sha256: Mapped[str] = mapped_column(String(64), default="")
    method_name: Mapped[str] = mapped_column(String(180), default="")
    equipment_id_snapshot: Mapped[str] = mapped_column(String(40), default="")
    run_reference: Mapped[str] = mapped_column(String(100), default="")
    parsed_json: Mapped[str] = mapped_column(Text, default="{}")
    revision: Mapped[int] = mapped_column(Integer, default=1)
    status: Mapped[str] = mapped_column(String(30), default="CONTROLLED")
    uploaded_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    site: Mapped[Site] = relationship()
    sample: Mapped[SampleRequest | None] = relationship()
    quality_case: Mapped[QualityCase | None] = relationship()
    equipment: Mapped[EquipmentAsset | None] = relationship()
    uploaded_by: Mapped[User] = relationship()


class AssetHistoryEvent(Base):
    __tablename__ = "asset_history_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), index=True)
    event_type: Mapped[str] = mapped_column(String(60), index=True)
    event_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    report_number: Mapped[str] = mapped_column(String(80), default="")
    details: Mapped[str] = mapped_column(Text, default="")
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    asset: Mapped[Asset] = relationship()
    created_by: Mapped[User | None] = relationship()


class TechnicalResultRule(Base):
    __tablename__ = "technical_result_rules"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    test_name: Mapped[str] = mapped_column(String(180), index=True)
    method_name: Mapped[str] = mapped_column(String(180), default="", index=True)
    result_field: Mapped[str] = mapped_column(String(180), index=True)
    unit: Mapped[str] = mapped_column(String(60), default="")
    equipment_id: Mapped[str] = mapped_column(String(40), default="")
    allowed_states: Mapped[str] = mapped_column(String(120), default="NUMERIC,LTD")
    detection_limit: Mapped[float | None] = mapped_column(Float, nullable=True)
    working_range_min: Mapped[float | None] = mapped_column(Float, nullable=True)
    working_range_max: Mapped[float | None] = mapped_column(Float, nullable=True)
    decimals: Mapped[int | None] = mapped_column(Integer, nullable=True)
    rounding_rule: Mapped[str] = mapped_column(String(40), default="SOURCE_CONTROLLED")
    report_display_rule: Mapped[str] = mapped_column(String(240), default="")
    downstream_rule: Mapped[str] = mapped_column(Text, default="")
    source_reference: Mapped[str] = mapped_column(String(240), default="")
    effective_revision: Mapped[str] = mapped_column(String(40), default="")
    status: Mapped[str] = mapped_column(String(30), default="ACTIVE", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    __table_args__ = (UniqueConstraint("site_id", "test_name", "method_name", "result_field", "equipment_id", name="uq_result_rule_scope"),)


class TroubleshootingRecord(Base):
    __tablename__ = "troubleshooting_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    test_name: Mapped[str] = mapped_column(String(180), default="", index=True)
    method_name: Mapped[str] = mapped_column(String(180), default="")
    equipment_asset_id: Mapped[int | None] = mapped_column(ForeignKey("equipment_assets.id"), nullable=True)
    workstation: Mapped[str] = mapped_column(String(120), default="")
    problem: Mapped[str] = mapped_column(Text)
    symptoms: Mapped[str] = mapped_column(Text, default="")
    root_cause: Mapped[str] = mapped_column(Text, default="")
    actions_taken: Mapped[str] = mapped_column(Text, default="")
    safety_impact: Mapped[str] = mapped_column(Text, default="")
    result_integrity_impact: Mapped[str] = mapped_column(Text, default="")
    lessons: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(40), default="DRAFT", index=True)
    responsible_domain: Mapped[str] = mapped_column(String(30), default="TECHNICAL", index=True)
    resolution_summary: Mapped[str] = mapped_column(Text, default="")
    published_revision: Mapped[int] = mapped_column(Integer, default=0)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    senior_verified_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    technical_approved_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    site: Mapped[Site] = relationship()
    equipment: Mapped[EquipmentAsset | None] = relationship()
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])
    senior_verified_by: Mapped[User | None] = relationship(foreign_keys=[senior_verified_by_id])
    technical_approved_by: Mapped[User | None] = relationship(foreign_keys=[technical_approved_by_id])


class TroubleshootingNote(Base):
    __tablename__ = "troubleshooting_notes"
    id: Mapped[int] = mapped_column(primary_key=True)
    troubleshooting_record_id: Mapped[int] = mapped_column(ForeignKey("troubleshooting_records.id"), index=True)
    author_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    note_type: Mapped[str] = mapped_column(String(40), default="OBSERVATION")
    note: Mapped[str] = mapped_column(Text)
    evidence_reference: Mapped[str] = mapped_column(String(240), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    troubleshooting_record: Mapped[TroubleshootingRecord] = relationship()
    author: Mapped[User] = relationship()


class TroubleshootingResolutionRevision(Base):
    __tablename__ = "troubleshooting_resolution_revisions"
    id: Mapped[int] = mapped_column(primary_key=True)
    troubleshooting_record_id: Mapped[int] = mapped_column(ForeignKey("troubleshooting_records.id"), index=True)
    revision: Mapped[int] = mapped_column(Integer, default=1)
    resolution_text: Mapped[str] = mapped_column(Text)
    root_cause: Mapped[str] = mapped_column(Text, default="")
    evidence_reference: Mapped[str] = mapped_column(String(240), default="")
    status: Mapped[str] = mapped_column(String(30), default="PROPOSED", index=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    reviewed_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    approved_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    effective_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    troubleshooting_record: Mapped[TroubleshootingRecord] = relationship()
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])
    reviewed_by: Mapped[User | None] = relationship(foreign_keys=[reviewed_by_id])
    approved_by: Mapped[User | None] = relationship(foreign_keys=[approved_by_id])
    __table_args__ = (UniqueConstraint("troubleshooting_record_id", "revision", name="uq_troubleshooting_resolution_revision"),)


class ExternalTechnicalEvidence(Base):
    __tablename__ = "external_technical_evidence"
    id: Mapped[int] = mapped_column(primary_key=True)
    troubleshooting_record_id: Mapped[int] = mapped_column(ForeignKey("troubleshooting_records.id"), index=True)
    verifier_name: Mapped[str] = mapped_column(String(180))
    company: Mapped[str] = mapped_column(String(180), default="")
    contact: Mapped[str] = mapped_column(String(180), default="")
    verification_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    reference: Mapped[str] = mapped_column(String(180), default="")
    conclusion: Mapped[str] = mapped_column(Text, default="")
    evidence_reference: Mapped[str] = mapped_column(String(240), default="")
    recorded_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    reviewed_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    troubleshooting_record: Mapped[TroubleshootingRecord] = relationship()
    recorded_by: Mapped[User] = relationship(foreign_keys=[recorded_by_id])
    reviewed_by: Mapped[User | None] = relationship(foreign_keys=[reviewed_by_id])


class ControlledReport(Base):
    __tablename__ = "controlled_reports"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    sample_request_id: Mapped[int] = mapped_column(ForeignKey("sample_requests.id"), index=True)
    report_number: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    revision: Mapped[int] = mapped_column(Integer, default=1)
    status: Mapped[str] = mapped_column(String(40), default="DRAFT", index=True)
    condition_status: Mapped[str] = mapped_column(String(30), default="")
    interpretation: Mapped[str] = mapped_column(Text, default="")
    recommendation: Mapped[str] = mapped_column(Text, default="")
    report_payload_json: Mapped[str] = mapped_column(Text, default="{}")
    qr_token: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    reviewed_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    approved_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    lms_reference: Mapped[str] = mapped_column(String(120), default="")
    lms_status: Mapped[str] = mapped_column(String(40), default="NOT_APPLICABLE", index=True)
    approved_snapshot_json: Mapped[str] = mapped_column(Text, default="{}")
    official_pdf_path: Mapped[str] = mapped_column(String(500), default="")
    official_pdf_sha256: Mapped[str] = mapped_column(String(64), default="", index=True)
    official_pdf_generated_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    report_template_code: Mapped[str] = mapped_column(String(40), default="QDF-[7]-08-A")
    supersedes_report_id: Mapped[int | None] = mapped_column(ForeignKey("controlled_reports.id"), nullable=True, index=True)
    amendment_reason: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    approved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    site: Mapped[Site] = relationship()
    sample: Mapped[SampleRequest] = relationship()
    reviewed_by: Mapped[User | None] = relationship(foreign_keys=[reviewed_by_id])
    approved_by: Mapped[User | None] = relationship(foreign_keys=[approved_by_id])
    supersedes_report: Mapped["ControlledReport | None"] = relationship(remote_side="ControlledReport.id", foreign_keys=[supersedes_report_id])


class ReportSubmission(Base):
    __tablename__ = "report_submissions"
    id: Mapped[int] = mapped_column(primary_key=True)
    controlled_report_id: Mapped[int] = mapped_column(ForeignKey("controlled_reports.id"), index=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    channel: Mapped[str] = mapped_column(String(40))
    recipient: Mapped[str] = mapped_column(String(220), default="")
    submission_reference: Mapped[str] = mapped_column(String(180), default="")
    note: Mapped[str] = mapped_column(Text, default="")
    submitted_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    submitted_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    controlled_report: Mapped[ControlledReport] = relationship()
    client: Mapped[Client] = relationship()
    submitted_by: Mapped[User] = relationship()


class Notification(Base):
    __tablename__ = "notifications"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    category: Mapped[str] = mapped_column(String(40), default="WORK", index=True)
    title: Mapped[str] = mapped_column(String(220))
    message: Mapped[str] = mapped_column(Text, default="")
    target_url: Mapped[str] = mapped_column(String(300), default="")
    priority: Mapped[str] = mapped_column(String(20), default="NORMAL")
    read_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    email_status: Mapped[str] = mapped_column(String(30), default="PENDING_CONFIGURATION")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    site: Mapped[Site | None] = relationship()
    user: Mapped[User] = relationship()


class ImprovementItem(Base):
    __tablename__ = "improvement_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    department_id: Mapped[int | None] = mapped_column(ForeignKey("departments.id"), nullable=True, index=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    owner_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    title: Mapped[str] = mapped_column(String(220), index=True)
    problem_statement: Mapped[str] = mapped_column(Text, default="")
    category: Mapped[str] = mapped_column(String(60), default="OPERATIONS", index=True)
    source: Mapped[str] = mapped_column(String(60), default="EMPLOYEE", index=True)
    source_entity_type: Mapped[str] = mapped_column(String(60), default="", index=True)
    source_entity_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    source_url: Mapped[str] = mapped_column(String(300), default="")
    priority: Mapped[str] = mapped_column(String(20), default="NORMAL", index=True)
    impact_area: Mapped[str] = mapped_column(String(120), default="")
    expected_benefit: Mapped[str] = mapped_column(Text, default="")
    action_plan: Mapped[str] = mapped_column(Text, default="")
    baseline_metric: Mapped[str] = mapped_column(String(120), default="")
    baseline_value: Mapped[str] = mapped_column(String(80), default="")
    target_value: Mapped[str] = mapped_column(String(80), default="")
    metric_unit: Mapped[str] = mapped_column(String(40), default="")
    status: Mapped[str] = mapped_column(String(40), default="SUBMITTED", index=True)
    due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    result_summary: Mapped[str] = mapped_column(Text, default="")
    evidence_reference: Mapped[str] = mapped_column(String(300), default="")
    approved_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    site: Mapped[Site | None] = relationship(foreign_keys=[site_id])
    department: Mapped[Department | None] = relationship(foreign_keys=[department_id])
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])
    owner: Mapped[User | None] = relationship(foreign_keys=[owner_id])
    approved_by: Mapped[User | None] = relationship(foreign_keys=[approved_by_id])
    activities: Mapped[list["ImprovementActivity"]] = relationship(back_populates="item", cascade="all, delete-orphan")


class ImprovementActivity(Base):
    __tablename__ = "improvement_activities"
    id: Mapped[int] = mapped_column(primary_key=True)
    improvement_item_id: Mapped[int] = mapped_column(ForeignKey("improvement_items.id"), index=True)
    actor_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    action: Mapped[str] = mapped_column(String(60), index=True)
    note: Mapped[str] = mapped_column(Text, default="")
    status_snapshot: Mapped[str] = mapped_column(String(40), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    item: Mapped[ImprovementItem] = relationship(back_populates="activities")
    actor: Mapped[User] = relationship()



class MonthlyClosePeriod(Base):
    __tablename__ = "monthly_close_periods"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    year: Mapped[int] = mapped_column(Integer, index=True)
    month: Mapped[int] = mapped_column(Integer, index=True)
    status: Mapped[str] = mapped_column(String(20), default="OPEN", index=True)
    archive_reference: Mapped[str] = mapped_column(String(180), default="")
    close_note: Mapped[str] = mapped_column(Text, default="")
    closed_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    site: Mapped[Site] = relationship()
    closed_by: Mapped[User | None] = relationship(foreign_keys=[closed_by_id])
    __table_args__ = (UniqueConstraint("site_id", "year", "month", name="uq_monthly_close_site_period"),)


class StaffWorkPattern(Base):
    __tablename__ = "staff_work_patterns"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    name: Mapped[str] = mapped_column(String(100), default="Standard")
    weekdays_json: Mapped[str] = mapped_column(Text, default="[6,0,1,2,3]")
    shift_start: Mapped[str] = mapped_column(String(5), default="08:00")
    shift_end: Mapped[str] = mapped_column(String(5), default="16:00")
    effective_from: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    effective_to: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    site: Mapped[Site] = relationship(foreign_keys=[site_id])
    user: Mapped[User] = relationship(foreign_keys=[user_id])
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])
    __table_args__ = (UniqueConstraint("site_id", "user_id", name="uq_staff_work_pattern_user_site"),)


class OfficeCorrespondence(Base):
    __tablename__ = "office_correspondence"
    id: Mapped[int] = mapped_column(primary_key=True)
    direction: Mapped[str] = mapped_column(String(20), index=True)  # INCOMING/OUTGOING
    subject: Mapped[str] = mapped_column(String(240), index=True)
    reference: Mapped[str] = mapped_column(String(120), default="", index=True)
    sender: Mapped[str] = mapped_column(String(220), default="")
    recipient: Mapped[str] = mapped_column(String(220), default="")
    correspondence_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    responsible_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(30), default="OPEN", index=True)
    follow_up_note: Mapped[str] = mapped_column(Text, default="")
    closure_note: Mapped[str] = mapped_column(Text, default="")
    attachment_path: Mapped[str] = mapped_column(String(500), default="")
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    responsible_user: Mapped[User | None] = relationship(foreign_keys=[responsible_user_id])
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])


class OfficeMeeting(Base):
    __tablename__ = "office_meetings"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(240), index=True)
    meeting_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    attendees: Mapped[str] = mapped_column(Text, default="")
    agenda: Mapped[str] = mapped_column(Text, default="")
    minutes: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(30), default="PLANNED", index=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])
    actions: Mapped[list["OfficeMeetingAction"]] = relationship(back_populates="meeting", cascade="all, delete-orphan")


class OfficeMeetingAction(Base):
    __tablename__ = "office_meeting_actions"
    id: Mapped[int] = mapped_column(primary_key=True)
    meeting_id: Mapped[int] = mapped_column(ForeignKey("office_meetings.id"), index=True)
    action_text: Mapped[str] = mapped_column(Text)
    owner_user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(30), default="OPEN", index=True)
    closure_note: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    meeting: Mapped[OfficeMeeting] = relationship(back_populates="actions")
    owner_user: Mapped[User | None] = relationship(foreign_keys=[owner_user_id])


class OvertimeRequest(Base):
    __tablename__ = "overtime_requests"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    employee_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    requested_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    approver_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    work_date: Mapped[datetime] = mapped_column(DateTime, index=True)
    requested_hours: Mapped[float] = mapped_column(Float, default=0)
    reason: Mapped[str] = mapped_column(Text, default="")
    project_reference: Mapped[str] = mapped_column(String(120), default="")
    related_reference: Mapped[str] = mapped_column(String(180), default="")
    status: Mapped[str] = mapped_column(String(30), default="SUBMITTED", index=True)
    decision_note: Mapped[str] = mapped_column(Text, default="")
    decided_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    site: Mapped[Site] = relationship()
    employee: Mapped[User] = relationship(foreign_keys=[employee_id])
    requested_by: Mapped[User] = relationship(foreign_keys=[requested_by_id])
    approver: Mapped[User] = relationship(foreign_keys=[approver_id])


class OvertimeClaim(Base):
    __tablename__ = "overtime_claims"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    employee_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    overtime_request_id: Mapped[int | None] = mapped_column(ForeignKey("overtime_requests.id"), nullable=True, index=True)
    work_date: Mapped[datetime] = mapped_column(DateTime, index=True)
    start_time: Mapped[str] = mapped_column(String(5), default="")
    end_time: Mapped[str] = mapped_column(String(5), default="")
    total_hours: Mapped[float] = mapped_column(Float, default=0)
    reason: Mapped[str] = mapped_column(Text, default="")
    project_reference: Mapped[str] = mapped_column(String(120), default="")
    related_reference: Mapped[str] = mapped_column(String(180), default="")
    status: Mapped[str] = mapped_column(String(40), default="DRAFT", index=True)
    external_submission_reference: Mapped[str] = mapped_column(String(180), default="")
    note: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    site: Mapped[Site] = relationship()
    employee: Mapped[User] = relationship(foreign_keys=[employee_id])
    overtime_request: Mapped[OvertimeRequest | None] = relationship()


class NightShiftMonthPlan(Base):
    __tablename__ = "night_shift_month_plans"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    year: Mapped[int] = mapped_column(Integer, index=True)
    month: Mapped[int] = mapped_column(Integer, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    status: Mapped[str] = mapped_column(String(30), default="PUBLISHED", index=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    site: Mapped[Site] = relationship()
    user: Mapped[User] = relationship(foreign_keys=[user_id])
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])
    __table_args__ = (UniqueConstraint("site_id", "year", "month", "user_id", name="uq_night_shift_month_plan"),)


class HousekeepingTask(Base):
    __tablename__ = "housekeeping_tasks"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    area_zone: Mapped[str] = mapped_column(String(180), index=True)
    assigned_to_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    shift_code: Mapped[str] = mapped_column(String(40), default="")
    status: Mapped[str] = mapped_column(String(30), default="DUE", index=True)
    completion_note: Mapped[str] = mapped_column(Text, default="")
    completion_photo_path: Mapped[str] = mapped_column(String(500), default="")
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    site: Mapped[Site] = relationship()
    assigned_to: Mapped[User] = relationship(foreign_keys=[assigned_to_id])
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])


class HousekeepingObservation(Base):
    __tablename__ = "housekeeping_observations"
    id: Mapped[int] = mapped_column(primary_key=True)
    task_id: Mapped[int | None] = mapped_column(ForeignKey("housekeeping_tasks.id"), nullable=True, index=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    raised_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    category: Mapped[str] = mapped_column(String(60), index=True)
    note: Mapped[str] = mapped_column(Text)
    photo_path: Mapped[str] = mapped_column(String(500), default="")
    routed_domain: Mapped[str] = mapped_column(String(30), default="EQUIPMENT", index=True)
    status: Mapped[str] = mapped_column(String(30), default="OPEN", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    task: Mapped[HousekeepingTask | None] = relationship()
    site: Mapped[Site] = relationship()
    raised_by: Mapped[User] = relationship(foreign_keys=[raised_by_id])


class GlasswareBatch(Base):
    __tablename__ = "glassware_batches"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    batch_code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    source_workstation: Mapped[str] = mapped_column(String(180), default="")
    glassware_type: Mapped[str] = mapped_column(String(180), default="General")
    approximate_quantity: Mapped[int | None] = mapped_column(Integer, nullable=True)
    priority: Mapped[str] = mapped_column(String(20), default="NORMAL", index=True)
    received_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    status: Mapped[str] = mapped_column(String(30), default="WAITING", index=True)
    assigned_to_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    note: Mapped[str] = mapped_column(Text, default="")
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    site: Mapped[Site] = relationship()
    assigned_to: Mapped[User | None] = relationship(foreign_keys=[assigned_to_id])
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])


class SampleKit(Base):
    __tablename__ = "sample_kits"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    kit_code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    status: Mapped[str] = mapped_column(String(30), default="PREPARING", index=True)
    kit_type: Mapped[str] = mapped_column(String(120), default="Transformer Oil Sampling Kit")
    contents_summary: Mapped[str] = mapped_column(Text, default="")
    container_count: Mapped[int] = mapped_column(Integer, default=0)
    assigned_sampler_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    operational_project_id: Mapped[int | None] = mapped_column(ForeignKey("operational_projects.id"), nullable=True, index=True)
    sampling_order_id: Mapped[int | None] = mapped_column(ForeignKey("sampling_orders.id"), nullable=True, index=True)
    note: Mapped[str] = mapped_column(Text, default="")
    prepared_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    issued_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    returned_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    site: Mapped[Site] = relationship()
    assigned_sampler: Mapped[User | None] = relationship(foreign_keys=[assigned_sampler_id])
    operational_project: Mapped[OperationalProject | None] = relationship()
    sampling_order: Mapped[SamplingOrder | None] = relationship()
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])


class SampleKitTask(Base):
    __tablename__ = "sample_kit_tasks"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    retained_sample_key: Mapped[str] = mapped_column(String(120), index=True)
    container_type: Mapped[str] = mapped_column(String(30), default="BOTTLE")
    assigned_to_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    assigned_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    sample_kit_id: Mapped[int | None] = mapped_column(ForeignKey("sample_kits.id"), nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(30), default="ASSIGNED", index=True)
    note: Mapped[str] = mapped_column(Text, default="")
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    site: Mapped[Site] = relationship()
    assigned_to: Mapped[User] = relationship(foreign_keys=[assigned_to_id])
    assigned_by: Mapped[User] = relationship(foreign_keys=[assigned_by_id])
    sample_kit: Mapped[SampleKit | None] = relationship()
