from __future__ import annotations
from .models import Role

# Current local TSCO capability catalogue. Parent-company HR/Legal/Procurement/
# Finance/IT/ERB are integration/handoff boundaries, not local personas.
ROLE_REVIEW_MATRIX = {
    Role.MANAGEMENT.value: {
        "name":"General Manager","department":"General Management","purpose":"Executive governance, approved project activation and management oversight.",
        "primary":["Executive Overview","Operational Project Approval","Organization & Staff","Continuous Improvement Governance"],
        "must_not":["Routine sample/result entry","Routine laboratory QC","Self-approval of leave"],
    },
    Role.EXCELLENCE.value: {
        "name":"Excellence Specialist","department":"General Management","purpose":"Continuous Improvement, validation/verification governance, audit follow-up and controlled archive/traceability.",
        "primary":["Continuous Improvement","Validation / Verification Governance","Audit & Findings","Evidence / Trends"],
        "must_not":["Routine analytical result entry","Senior technical approval","Equipment maintenance execution"],
    },
    Role.CORPORATE_SUPPORT.value: {
        "name":"Secretary","department":"General Management","purpose":"GM Office administrative coordination.",
        "primary":["GM Office","Correspondence & Follow-up","Meetings & Calendar","Employee Directory"],
        "must_not":["Laboratory operations","Technical approval","Field execution","Commercial ownership"],
    },
    Role.SALES_MARKETING.value: {
        "name":"Sales & Marketing / Salesman","department":"Sales & Marketing Department","purpose":"Lead/opportunity and client-facing commercial collaboration, with job-title-specific capabilities.",
        "primary":["Business Communication Flow","Lead / Opportunity","Proposal","Commercial Status"],
        "must_not":["Controlled Quotation/PO ownership unless Client Account Coordinator","Laboratory result entry","Technical approval"],
    },
    Role.OPERATIONS_MANAGER.value: {
        "name":"Field Operational & Technical Manager","department":"Dammam & Bahrain Labs · Field Operations","purpose":"Official field-operation direction, Sampling Orders, planning and field-team oversight.",
        "primary":["Operations","Sampling Orders","Field Progress","Projects / Planning","Field-team Approval"],
        "must_not":["Routine analytical result entry","Senior technical approval"],
    },
    Role.SAMPLING_SUPERVISOR.value: {
        "name":"Sampling Supervisor","department":"Dammam & Bahrain Labs · Field Operations","purpose":"Named Sampleman distribution/reassignment and field readiness under approved Sampling Orders.",
        "primary":["Sampling Supervision","Assignments","Sample Kit Readiness","Overtime Requests","Sampleman Leave Approval"],
        "must_not":["Create independent client/project work outside approved order","Overtime approval","Laboratory result entry"],
    },
    Role.DATA_ENTRY.value: {
        "name":"Data Entry","department":"Dammam & Bahrain Labs · Intake / Receiving","purpose":"One continuous intake/receiving/registration/batching/laboratory-release responsibility.",
        "primary":["Intake / Receiving","Registration","Labels","Priority / TAT","Batch & Release","Custody"],
        "must_not":["Analytical result entry","Senior review","Final TSCO report release"],
    },
    Role.FIELD_SAMPLER.value: {
        "name":"Sampleman","department":"Dammam & Bahrain Labs · Field Operations","purpose":"Execute only explicitly assigned TSCO field tasks and controlled evidence capture.",
        "primary":["My Field Assignments","Sampling / Pickup / Delivery","Evidence","Sample Kit Tasks"],
        "must_not":["Unassigned TSCO field work","Laboratory result entry","Management approval"],
    },
    Role.CLIENT_COORDINATOR.value: {
        "name":"Client / External Coordination","department":"Dammam & Bahrain Labs · Field Operations","purpose":"Client-facing coordination; controlled document ownership depends on job title/capability.",
        "primary":["Commercial / Coordination","Client Follow-up","Report Submission"],
        "must_not":["Laboratory result entry","Technical approval","Finance/payment closure"],
    },
    Role.TECHNICAL_MANAGER.value: {
        "name":"Lab Operational & Technical Manager","department":"Dammam & Bahrain Labs · Laboratory Operations","purpose":"Laboratory management, technical oversight, final controlled technical adoption and report approval/stamp.",
        "primary":["Laboratory Management","Final Controlled Reports / TSCO Release","Senior Responsibilities","Released Reports","Leave Approvals"],
        "must_not":["Routine analyst result entry","Field execution","System-admin substitution"],
    },
    Role.SENIOR_CHEMIST.value: {
        "name":"Senior Chemist","department":"Dammam & Bahrain Labs · Laboratory Operations","purpose":"Shared Senior report review plus domain-specific Technical, Equipment/Maintenance or Continuous Improvement responsibility.",
        "primary":["Senior Review","Workload Distribution","Reports","Domain Responsibilities","Retest / Resample as authorized"],
        "must_not":["Routine analyst result entry","Final manager approval/stamp","Direct client/final report release"],
    },
    Role.LAB_TECHNICIAN.value: {
        "name":"Chemist / Chemical Technician","department":"Dammam & Bahrain Labs · Laboratory Operations","purpose":"Assignment-scoped laboratory execution controlled by competency, availability and explicit assignment.",
        "primary":["My Workstations","Result Entry","Analytical/Test QC","Authorized Retest","Assigned Validation / Verification"],
        "must_not":["Senior technical approval","Final report approval","Self-assignment"],
    },
    Role.LAB_SUPPORT.value: {
        "name":"Glassware Cleaning","department":"Dammam & Bahrain Labs · Laboratory Operations","purpose":"Glassware / cleaning and assigned laboratory housekeeping support.",
        "primary":["Support Tasks","Housekeeping","Notifications","Availability"],
        "must_not":["Analytical result entry","QC approval","Technical review","Report release"],
    },
    Role.SYSTEM_ADMIN.value: {
        "name":"System Administrator","department":"Technical Platform Identity","purpose":"Technical administration, configuration, account/access maintenance and platform support; outside the business reporting hierarchy.",
        "primary":["Administration","Users & Access","Technical Configuration","Audit","Import / Export"],
        "must_not":["Business approval","Analyst result entry","Senior technical approval","Technical Manager approval","GM approval"],
    },
    Role.CLIENT.value: {"name":"Client Portal User","department":"External Client","purpose":"Client-scoped status and officially released reports only.","primary":["Client Portal","Released Reports"],"must_not":["Internal laboratory data","Draft reports","QC / technical review"]},
    Role.CLIENT_SAMPLER.value: {"name":"Client Sampler","department":"External Client","purpose":"Authorized client-originated sample capture.","primary":["Client Sample Capture"],"must_not":["TSCO internal approvals"]},
    Role.CLIENT_OPERATIONS.value: {"name":"Client Operations","department":"External Client","purpose":"Authorized client operational capture/visibility.","primary":["Client Operations"],"must_not":["TSCO internal approvals"]},
}


def role_display(role: str) -> str:
    return ROLE_REVIEW_MATRIX.get(role, {}).get("name", role.replace("_", " ").title())
