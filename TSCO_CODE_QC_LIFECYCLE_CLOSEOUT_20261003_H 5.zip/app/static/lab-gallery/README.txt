TSCO Analytical Lab public gallery

Drop only approved public laboratory photographs in this folder.
Recommended delivery format:
- WebP preferred (JPG/PNG accepted)
- maximum long edge: 1600 px
- target file size: <= 250 KB per image
- descriptive filename, e.g. transformer-oil-lab.webp
- no client-identifying labels, sample IDs, documents, screens, or confidential information visible

The /welcome page discovers supported image files automatically and renders lazy-loaded thumbnails.
No empty placeholder grid is shown when the folder contains no approved photographs.
