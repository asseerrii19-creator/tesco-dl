(() => {
  const body = document.body;
  const menu = document.getElementById('menuButton');
  const overlay = document.getElementById('sidebarOverlay');
  const close = () => body.classList.remove('sidebar-open');
  if (menu) menu.addEventListener('click', () => body.classList.toggle('sidebar-open'));
  if (overlay) overlay.addEventListener('click', close);
  document.querySelectorAll('.side-link').forEach(link => link.addEventListener('click', close));

  // Keep the navigation compact: only the active department is expanded by default.
  // Every group can be opened/closed without navigating away.
  document.querySelectorAll('.nav-group').forEach((group, index) => {
    const label = group.querySelector(':scope > .nav-label');
    if (!label) return;
    const hasActive = !!group.querySelector('.side-link.active');
    group.classList.toggle('open', hasActive);
    label.setAttribute('role', 'button');
    label.setAttribute('tabindex', '0');
    label.setAttribute('aria-expanded', hasActive ? 'true' : 'false');
    label.setAttribute('aria-controls', `nav-group-${index}`);
    group.querySelectorAll(':scope > .side-link').forEach(link => link.dataset.navGroup = String(index));
    const toggle = () => {
      const next = !group.classList.contains('open');
      group.classList.toggle('open', next);
      label.setAttribute('aria-expanded', next ? 'true' : 'false');
    };
    label.addEventListener('click', toggle);
    label.addEventListener('keydown', event => {
      if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); toggle(); }
    });
  });

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => navigator.serviceWorker.register('/static/service-worker.js').catch(() => {}));
  }

  const updateNetwork = () => {
    document.querySelectorAll('[data-network-state]').forEach(el => {
      el.textContent = navigator.onLine ? 'Online' : 'Offline';
      el.classList.toggle('offline', !navigator.onLine);
    });
  };
  window.addEventListener('online', updateNetwork);
  window.addEventListener('offline', updateNetwork);
  updateNetwork();
})();
