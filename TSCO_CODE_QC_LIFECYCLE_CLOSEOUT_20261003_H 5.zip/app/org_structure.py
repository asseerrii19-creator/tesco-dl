from __future__ import annotations

from dataclasses import dataclass
import os

from .models import Role


@dataclass(frozen=True)
class EmployeeSpec:
    name: str
    email: str
    job_title: str
    department_code: str
    organization_area: str
    role: str
    manager_email: str | None
    leave_approver_email: str | None
    workspace_summary: tuple[str, ...]
    boundaries: tuple[str, ...]


# Source-of-truth organization baseline for the named staff supplied in the TSCO org chart.
# A job title is not a permission by itself: the system role controls routes, while this
# profile fixes the employee's real organizational placement, reporting line, leave approver
# and the work that should be visible in UAT.
EMPLOYEES: tuple[EmployeeSpec, ...] = (
    EmployeeSpec(
        "Salah Al-Shajira", "salah.alshajira@tsco.local", "General Manager", "CORP", "General Management",
        Role.MANAGEMENT.value, None, None,
        ("Executive overview", "Organization and staffing", "Department performance", "Continuous-improvement governance", "Direct-report approvals"),
        ("No routine sample/result entry", "No routine QC execution", "No self-approval of leave"),
    ),
    EmployeeSpec(
        "Ohood Al Hareeqi", "ohood.alhareeqi@tsco.local", "Excellence Specialist", "CORP", "General Management",
        Role.EXCELLENCE.value, "salah.alshajira@tsco.local", "salah.alshajira@tsco.local",
        ("Continuous Improvement", "QC history/trends", "Equipment & calibration history", "Validation / Verification", "Audit & findings", "Evidence and follow-up"),
        ("No routine laboratory result entry", "No Senior technical approval", "No equipment maintenance execution"),
    ),
    EmployeeSpec(
        "Renad Al Qahtani", "renad.alqahtani@tsco.local", "Secretary", "CORP", "General Management",
        Role.CORPORATE_SUPPORT.value, "salah.alshajira@tsco.local", "salah.alshajira@tsco.local",
        ("GM office coordination", "Assigned correspondence and follow-up", "Meetings / notifications", "Employee directory", "Own leave plan"),
        ("No laboratory operations", "No samples/results/QC", "No technical approvals", "No field execution"),
    ),
    EmployeeSpec(
        "Humayoon", "humayoon@tsco.local", "Sales & Marketing Specialist", "SAM", "Sales & Marketing Department",
        Role.SALES_MARKETING.value, "salah.alshajira@tsco.local", "salah.alshajira@tsco.local",
        ("Lead generation", "Commercial communication", "Quotation / proposal preparation", "Client follow-up", "Commercial handover"),
        ("No laboratory result entry", "No technical assessment", "No sample receiving"),
    ),
    EmployeeSpec(
        "Khalid Alali", "khalid.alali@tsco.local", "Salesman", "SAM", "Sales & Marketing Department",
        Role.SALES_MARKETING.value, "salah.alshajira@tsco.local", "salah.alshajira@tsco.local",
        ("Lead/customer follow-up", "Commercial communication", "Sales opportunity updates", "Quotation/proposal collaboration"),
        ("No laboratory result entry", "No technical approval", "No sample receiving"),
    ),
    EmployeeSpec(
        "Abdulmajeed", "abdulmajeed@tsco.local", "Field Operational & Technical Manager", "FIELD", "Dammam & Bahrain Labs · Field Operations",
        Role.OPERATIONS_MANAGER.value, "salah.alshajira@tsco.local", "salah.alshajira@tsco.local",
        ("Field operations overview", "Sampling orders and assignments", "Field progress", "Client-originated sample handoff", "Field-team leave approvals"),
        ("No routine analytical result entry", "No laboratory QC execution", "No Senior technical approval"),
    ),
    EmployeeSpec(
        "Ahmed Al Qahtani", "ahmed.alqahtani@tsco.local", "Data Entry", "LABS", "Dammam & Bahrain Labs",
        Role.DATA_ENTRY.value, "abdulmajeed@tsco.local", "abdulmajeed@tsco.local",
        ("Incoming sample verification", "Physical receiving", "TSCO internal registration", "Labels", "Urgent TAT capture", "Batch & laboratory distribution"),
        ("No analytical result entry", "No Senior technical review", "No final TSCO report release"),
    ),
    *tuple(
        EmployeeSpec(name, email, "Sampleman", "FIELD", "Dammam & Bahrain Labs · Field Operations", Role.FIELD_SAMPLER.value,
                     "sampling.supervisor@tsco.local", "sampling.supervisor@tsco.local",
                     ("Assigned field work", "Sampling / delivery evidence", "Authorized asset structure", "Controlled field instructions", "Own leave plan"),
                     ("No laboratory result entry", "No unassigned client work", "No management approvals"))
        for name, email in (
            ("Mohammed Amir", "mohammed.amir@tsco.local"),
            ("Matiullah Khan", "matiullah.khan@tsco.local"),
            ("Rahmatullah Abdul Momin", "rahmatullah.abdulmomin@tsco.local"),
            ("Mohammed Majid", "mohammed.majid@tsco.local"),
            ("Mubarak Abdullah", "mubarak.abdullah@tsco.local"),
        )
    ),
    *tuple(
        EmployeeSpec(name, email, "Client Account & Coordination Officer", "FIELD", "Dammam & Bahrain Labs · Field Operations", Role.CLIENT_COORDINATOR.value,
                     "abdulmajeed@tsco.local", "abdulmajeed@tsco.local",
                     ("Client requests", "Quotation / PO follow-up", "Controlled attachments", "Operational handover", "Report-submission communication", "Own leave plan"),
                     ("No laboratory result entry", "No technical assessment", "No invoice/payment closure"))
        for name, email in (
            ("Malindu Eranda", "malindu.eranda@tsco.local"),
            ("Mohammed Athaf", "mohammed.athaf@tsco.local"),
            ("Muhammed Arsalan", "muhammed.arsalan@tsco.local"),
        )
    ),
    EmployeeSpec(
        "Sara Al Otaibi", "sara.alotaibi@tsco.local", "External Coordination Officer", "FIELD", "Dammam & Bahrain Labs · Field Operations",
        Role.CLIENT_COORDINATOR.value, "abdulmajeed@tsco.local", "abdulmajeed@tsco.local",
        ("External/client coordination", "Request and attachment follow-up", "Handover communication", "Report-submission communication", "Own leave plan"),
        ("No laboratory result entry", "No technical assessment", "Job title remains External Coordination Officer"),
    ),
    EmployeeSpec(
        "Rwad", "rwad@tsco.local", "Lab Operational & Technical Manager", "LAB", "Dammam & Bahrain Labs · Laboratory Operations",
        Role.TECHNICAL_MANAGER.value, "salah.alshajira@tsco.local", "salah.alshajira@tsco.local",
        ("Laboratory management overview", "Workload and technical oversight", "Senior/chemist/technician supervision", "Final controlled reports / TSCO release", "Laboratory leave approvals"),
        ("No routine analyst result entry", "No field execution", "No IT/system-administrator override as business approval"),
    ),
    EmployeeSpec(
        "Mohammed Al Yahya", "mohammed.alyahya@tsco.local", "Senior Chemist", "LAB", "Dammam & Bahrain Labs · Laboratory Operations",
        Role.SENIOR_CHEMIST.value, "rwad@tsco.local", "rwad@tsco.local",
        ("Technical review", "Methods / SOPs / EOPs", "Technical troubleshooting", "Retest / resample oversight", "Retained samples", "Reports review"),
        ("No routine analyst result entry", "No final report release authority", "Technical responsibility does not replace manager authority"),
    ),
    EmployeeSpec(
        "Tara Al Ghamdi", "tara.alghamdi@tsco.local", "Senior Chemist", "LAB", "Dammam & Bahrain Labs · Laboratory Operations",
        Role.SENIOR_CHEMIST.value, "rwad@tsco.local", "rwad@tsco.local",
        ("Technical review", "Equipment follow-up", "Calibration / maintenance coordination", "Equipment troubleshooting", "Retained samples", "Reports review"),
        ("No routine analyst result entry", "No final report release authority", "Equipment responsibility remains with the Equipment Senior"),
    ),
    EmployeeSpec(
        "Reem Al Otaibi", "reem.alotaibi@tsco.local", "Senior Chemist", "LAB", "Dammam & Bahrain Labs · Laboratory Operations",
        Role.SENIOR_CHEMIST.value, "rwad@tsco.local", "rwad@tsco.local",
        ("Technical review", "Improvement coordination", "Validation/audit follow-up with Excellence", "Retained samples", "Reports review"),
        ("No routine analyst result entry", "No final report release authority", "Improvement coordination does not create a Quality department"),
    ),
    *tuple(
        EmployeeSpec(name, email, "Chemist", "LAB", "Dammam & Bahrain Labs · Laboratory Operations", Role.LAB_TECHNICIAN.value,
                     "rwad@tsco.local", "rwad@tsco.local",
                     ("Assigned analytical work", "Result entry", "Assigned QC", "Assigned validation/verification runs", "Methods / SOPs / Quick Guides", "Own leave plan"),
                     ("No Senior technical approval", "No final TSCO report release", "No management-only controls"))
        for name, email in (
            ("Ali Al Orain", "ali.alorain@tsco.local"), ("Syed Azhar", "syed.azhar@tsco.local"),
            ("Hadeel Al Rashidi", "hadeel.alrashidi@tsco.local"), ("Anandhu Krishna", "anandhu.krishna@tsco.local"),
            ("Subindev Valuparampil", "subindev.valuparampil@tsco.local"), ("Abdullah Al Hindi", "abdullah.alhindi@tsco.local"),
            ("Ziyad Al-Harbi", "ziyad.alharbi@tsco.local"),
        )
    ),
    *tuple(
        EmployeeSpec(name, email, "Chemical Technician", "LAB", "Dammam & Bahrain Labs · Laboratory Operations", Role.LAB_TECHNICIAN.value,
                     "rwad@tsco.local", "rwad@tsco.local",
                     ("Assigned analytical work", "Result entry", "Assigned QC", "Assigned validation/verification runs", "Methods / SOPs / Quick Guides", "Own leave plan"),
                     ("No Senior technical approval", "No final TSCO report release", "No management-only controls"))
        for name, email in (
            ("Faisal Al Shihri", "faisal.alshihri@tsco.local"), ("Sultan Al Subaie", "sultan.alsubaie@tsco.local"),
            ("Anas Asiri", "anas.asiri@tsco.local"), ("Muhanand Al Azhri", "muhanand.alazhri@tsco.local"),
        )
    ),
    EmployeeSpec(
        "Sahid Husain", "sahid.husain@tsco.local", "Glassware Cleaning", "LAB", "Dammam & Bahrain Labs · Laboratory Operations",
        Role.LAB_SUPPORT.value, "rwad@tsco.local", "rwad@tsco.local",
        ("Glassware/cleaning support instructions", "Assigned support follow-up", "Notifications", "Own leave plan"),
        ("No analytical result entry", "No QC approval", "No technical review", "No report release"),
    ),
)

EMPLOYEE_BY_EMAIL = {row.email: row for row in EMPLOYEES}

# The source chart gives Shared Services functions but no individual employee names/reporting managers.
# These UAT identities exercise function permissions only and must not be treated as real employee leave accounts.
SHARED_SERVICE_FUNCTIONS = (
    ("HR", "hr@tsco.local", Role.SHARED_SERVICES.value, ("Legacy test compatibility",)),
    ("QHSE", "qhse@tsco.local", Role.QUALITY.value, ("Legacy test compatibility",)),
    ("Legal Affairs", "legal@tsco.local", Role.SHARED_SERVICES.value, ("Legacy test compatibility",)),
    ("Procurement", "procurement@tsco.local", Role.SHARED_SERVICES.value, ("Legacy test compatibility",)),
    ("Finance", "finance@tsco.local", Role.FINANCE.value, ("Legacy test compatibility",)),
    ("IT", "it@tsco.local", Role.SHARED_SERVICES.value, ("Legacy test compatibility",)),
    ("ERB", "erb@tsco.local", Role.SHARED_SERVICES.value, ("Legacy test compatibility",)),
) if os.getenv("APP_ENV", "development").strip().lower() == "testing" else ()


def employee_spec(email: str | None) -> EmployeeSpec | None:
    return EMPLOYEE_BY_EMAIL.get((email or "").strip().lower())


def employee_is_named(email: str | None) -> bool:
    return (email or "").strip().lower() in EMPLOYEE_BY_EMAIL
