from __future__ import annotations

from sqlalchemy.orm import Session

from ..models import IntegrationQueueItem


def retry_item(db: Session, item: IntegrationQueueItem) -> bool:
    """Retry an optional external connector.

    Project 00012 core laboratory operations are standalone. Legacy LMS queue rows are
    preserved for audit/history only and are deliberately not executable.
    """
    item.attempts += 1
    item.status = "FAILED"
    if str(item.integration or "").upper() == "LMS":
        item.last_error = "Legacy LMS integration is disabled; TSCO Digital Laboratory Platform is operating standalone."
    else:
        item.last_error = f"No active runtime adapter is configured for {item.integration}:{item.operation}"
    return False
