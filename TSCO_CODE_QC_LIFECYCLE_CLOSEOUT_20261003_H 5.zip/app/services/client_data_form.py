from __future__ import annotations

import re
from io import BytesIO
from pathlib import Path
from typing import Any

from pypdf import PdfReader
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import Asset, CommercialAttachment, SampleRequest


def _clean(value: str | None) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def _field(block: str, label: str) -> str:
    m = re.search(rf"(?im)^\s*{re.escape(label)}\s+(.+?)\s*$", block)
    return _clean(m.group(1)) if m else ""


def _number(value: str) -> float | None:
    m = re.search(r"-?\d+(?:\.\d+)?", value or "")
    return float(m.group(0)) if m else None


def _year(value: str) -> int | None:
    m = re.search(r"\b(19|20)\d{2}\b", value or "")
    return int(m.group(0)) if m else None


def _date_time(value: str) -> str:
    clean = _clean(value)
    m = re.search(r"\b(\d{4}-\d{2}-\d{2})\s+(\d{1,2}:\d{2})\b", clean)
    return f"{m.group(1)}T{m.group(2)}" if m else ""


def _voltage_pair(value: str) -> tuple[float | None, float | None]:
    nums = re.findall(r"\d+(?:\.\d+)?", value or "")
    if len(nums) < 2:
        return None, None
    return float(nums[0]), float(nums[1])


def _rated_mva(value: str) -> float | None:
    nums = [float(v) for v in re.findall(r"\d+(?:\.\d+)?", value or "")]
    return max(nums) if nums else None


def extract_pdf_text(raw: bytes) -> str:
    if not raw or not raw.startswith(b"%PDF-"):
        return ""
    try:
        reader = PdfReader(BytesIO(raw))
        return "\n".join((page.extract_text() or "") for page in reader.pages)
    except Exception:
        return ""


def parse_client_data_form(raw: bytes) -> dict[str, Any]:
    """Parse explicit-label client data forms without making intake depend on OCR.

    The parser is intentionally conservative: values are used only when an explicit
    label is present. Unknown layouts simply return no extracted fields, leaving the
    approved commercial scope as the authoritative fallback.
    """
    text = extract_pdf_text(raw)
    if not text:
        return {"request": {}, "samples": {}, "text_found": False}

    request = {
        "client": _field(text, "Client"),
        "request_number": _field(text, "Request Number"),
        "request_title": _field(text, "Request Title"),
        "expected_sample_at": _date_time(_field(text, "Expected Sample Date / Time")),
        "sample_route": _field(text, "Sample Route"),
        "delivery_note": _field(text, "Pickup / Delivery Note"),
        "package": _field(text, "Package"),
        "priority_tat": _field(text, "Priority / TAT"),
    }

    samples: dict[str, dict[str, Any]] = {}
    parts = re.split(r"(?im)^\s*SAMPLE\s+(\d+)\s*$", text)
    for i in range(1, len(parts), 2):
        number = parts[i]
        block = parts[i + 1] if i + 1 < len(parts) else ""
        serial = _field(block, "Transformer Serial Number")
        if not serial:
            continue
        hv, lv = _voltage_pair(_field(block, "HV / LV"))
        sample = {
            "sample_number": number,
            "serial_number": serial,
            "tag_number": _field(block, "Tag Number"),
            "station_name": _field(block, "Substation / Location"),
            "equipment_type": _field(block, "Equipment Type") or "Power Transformer",
            "manufacturer": _field(block, "Manufacturer"),
            "manufacture_year": _year(_field(block, "Manufacture Year")),
            "rated_mva": _rated_mva(_field(block, "Rated Power")),
            "hv_voltage_kv": hv,
            "lv_voltage_kv": lv,
            "cooling_type": _field(block, "Cooling Type"),
            "oil_type": _field(block, "Oil Type"),
            "equipment_status": _field(block, "Equipment Status"),
            "sampling_point": _field(block, "Sampling Point"),
            "sample_date_time": _date_time(_field(block, "Sampling Date / Time")),
            "sample_man": _field(block, "Sample Man"),
            "oil_temperature_c": _number(_field(block, "Oil Temperature")),
            "ambient_temperature_c": _number(_field(block, "Ambient Temperature")),
            "ambient_humidity_pct": _number(_field(block, "Humidity")),
            "sampling_reason": _field(block, "Sampling Reason"),
            "requested_package": _field(block, "Requested Package"),
            "priority": _field(block, "Priority"),
            "required_tat": _field(block, "Required TAT"),
            "method_family": _field(block, "Method Family"),
        }
        samples[serial.upper()] = sample
    return {"request": request, "samples": samples, "text_found": True}


def attachment_bytes(row: CommercialAttachment | None) -> bytes:
    if not row:
        return b""
    blob = getattr(row, "content_blob", None)
    if blob:
        return bytes(blob)
    path = Path(row.stored_path or "")
    try:
        return path.read_bytes() if path.is_file() else b""
    except OSError:
        return b""


def latest_case_data_form(db: Session, case_id: int) -> CommercialAttachment | None:
    return db.scalar(
        select(CommercialAttachment)
        .where(
            CommercialAttachment.commercial_case_id == case_id,
            CommercialAttachment.document_type == "CLIENT_DATA_FORM",
        )
        .order_by(CommercialAttachment.created_at.desc(), CommercialAttachment.id.desc())
    )


def case_data_form_payload(db: Session, case_id: int) -> tuple[CommercialAttachment | None, dict[str, Any]]:
    row = latest_case_data_form(db, case_id)
    raw = attachment_bytes(row)
    return row, parse_client_data_form(raw) if raw else {"request": {}, "samples": {}, "text_found": False}


def repair_uat_attachment_blobs(db: Session, fixtures_dir: Path) -> int:
    """Recover the three controlled UAT documents across stateless Render deploys.

    New uploads are DB-backed. This only repairs the already-created v3.4.2 UAT case
    so its current journey can continue after the hotfix without recreating the case.
    """
    if not fixtures_dir.is_dir():
        return 0
    fixture_names = {
        "TSCO_UAT_Client_Data_Form_BC-DMM-2026-0003.pdf",
        "TSCO_UAT_Quotation_QT-UAT-0003.pdf",
        "SEC_UAT_Purchase_Order_SEC-PO-UAT-0003.pdf",
    }
    rows = list(db.scalars(select(CommercialAttachment).where(CommercialAttachment.original_name.in_(fixture_names))).all())
    changed = 0
    for row in rows:
        fixture = fixtures_dir / row.original_name
        if not fixture.is_file():
            continue
        raw = fixture.read_bytes()
        if not getattr(row, "content_blob", None):
            row.content_blob = raw
            changed += 1
        path = Path(row.stored_path or "")
        if row.stored_path and not path.is_file():
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(raw)
            except OSError:
                pass
    if changed:
        db.commit()
    return changed


def sync_missing_sample_metadata_from_case_data_form(db: Session, case_id: int) -> int:
    """Backfill missing intake/sample metadata from the linked controlled Client Data Form.

    This is intentionally non-destructive: populated fields are never overwritten.
    It supports already-created samples so a durable linked Data Form can repair
    missing metadata without recreating the commercial journey, sample IDs, or lab batch.
    """
    _row, payload = case_data_form_payload(db, case_id)
    parsed_samples = payload.get("samples", {})
    if not parsed_samples:
        return 0

    rows = list(db.scalars(select(SampleRequest).where(SampleRequest.commercial_case_id == case_id)).all())
    changed_rows = 0
    for sample in rows:
        serial = str(sample.asset.serial_number if sample.asset else "").strip().upper()
        metadata = parsed_samples.get(serial)
        if not metadata:
            continue
        changed = False

        for attr, key in (
            ("oil_temperature_c", "oil_temperature_c"),
            ("ambient_temperature_c", "ambient_temperature_c"),
            ("ambient_humidity_pct", "ambient_humidity_pct"),
        ):
            current = getattr(sample, attr, None)
            value = metadata.get(key)
            if current is None and value is not None:
                setattr(sample, attr, value)
                changed = True

        for attr, key, limit in (
            ("equipment_status", "equipment_status", 80),
            ("sampling_reason", "sampling_reason", 180),
        ):
            current = str(getattr(sample, attr, None) or "").strip()
            value = str(metadata.get(key) or "").strip()
            if not current and value:
                setattr(sample, attr, value[:limit])
                changed = True

        asset = sample.asset
        if asset:
            asset_fields = (
                ("manufacturer", "manufacturer", 120),
                ("cooling_type", "cooling_type", 100),
                ("oil_type", "oil_type", 120),
                ("tag_number", "tag_number", 100),
                ("station_name", "station_name", 160),
                ("asset_location_label", "station_name", 160),
            )
            for attr, key, limit in asset_fields:
                current = str(getattr(asset, attr, None) or "").strip()
                value = str(metadata.get(key) or "").strip()
                if not current and value:
                    setattr(asset, attr, value[:limit])
                    changed = True
            for attr, key in (
                ("rated_mva", "rated_mva"),
                ("hv_voltage_kv", "hv_voltage_kv"),
                ("lv_voltage_kv", "lv_voltage_kv"),
                ("manufacture_year", "manufacture_year"),
            ):
                current = getattr(asset, attr, None)
                value = metadata.get(key)
                if current is None and value is not None:
                    setattr(asset, attr, value)
                    changed = True

        if changed:
            changed_rows += 1

    if changed_rows:
        db.commit()
    return changed_rows


def sync_all_missing_sample_metadata_from_data_forms(db: Session) -> int:
    """Backfill missing metadata for all linked cases that already have samples."""
    case_ids = list(db.scalars(
        select(SampleRequest.commercial_case_id)
        .where(SampleRequest.commercial_case_id.is_not(None))
        .distinct()
    ).all())
    total = 0
    for case_id in case_ids:
        if case_id is not None:
            total += sync_missing_sample_metadata_from_case_data_form(db, int(case_id))
    return total
