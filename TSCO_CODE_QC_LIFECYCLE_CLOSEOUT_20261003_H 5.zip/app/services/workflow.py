from __future__ import annotations

from datetime import datetime

from sqlalchemy.orm import Session

from ..models import ControlledReport, CustodyEvent, SampleRequest, SampleStatus, User
from .commercial import sync_case_from_sample
from .lab_operations import activate_retention_after_report_release


STATUS_LABELS = {
    SampleStatus.DRAFT.value: "Draft",
    SampleStatus.SUBMITTED.value: "Submitted from field / client",
    SampleStatus.RETURNED.value: "Returned for correction",
    SampleStatus.REJECTED.value: "Rejected",
    SampleStatus.ACCEPTED.value: "Data accepted",
    SampleStatus.AWAITING_RECEIPT.value: "TSCO registered — awaiting physical receipt",
    SampleStatus.IN_TRANSIT.value: "In transit",
    SampleStatus.RECEIVED.value: "Physically received — awaiting batch/distribution",
    SampleStatus.READY_FOR_LAB.value: "Batched and released to laboratory",
    SampleStatus.REGISTERED.value: "TSCO internal registration complete",
    SampleStatus.TESTING.value: "Testing in progress",
    SampleStatus.TECHNICAL_REVIEW.value: "Technical review",
    SampleStatus.REPORT_APPROVED.value: "Senior technical review complete",
    SampleStatus.READY_FOR_LMS.value: "Legacy external-release state",
    SampleStatus.REPORT_RELEASED.value: "Official TSCO report released",
}

# Current standalone lifecycle. READY_FOR_LMS remains only to read/migrate historical rows.
STATUS_ORDER = [
    SampleStatus.SUBMITTED.value,
    SampleStatus.ACCEPTED.value,
    SampleStatus.AWAITING_RECEIPT.value,
    SampleStatus.IN_TRANSIT.value,
    SampleStatus.RECEIVED.value,
    SampleStatus.READY_FOR_LAB.value,
    SampleStatus.REGISTERED.value,
    SampleStatus.TESTING.value,
    SampleStatus.TECHNICAL_REVIEW.value,
    SampleStatus.REPORT_APPROVED.value,
    SampleStatus.REPORT_RELEASED.value,
]


def add_event(
    db: Session,
    sample: SampleRequest,
    actor: User | None,
    event_type: str,
    status_value: str,
    note: str = "",
    latitude: float | None = None,
    longitude: float | None = None,
) -> CustodyEvent:
    event = CustodyEvent(
        sample_request_id=sample.id,
        event_type=event_type,
        status=status_value,
        actor_id=actor.id if actor else None,
        note=note,
        latitude=latitude,
        longitude=longitude,
        event_at=datetime.utcnow(),
    )
    db.add(event)
    return event


def register_in_tsco(db: Session, sample: SampleRequest, actor: User) -> str:
    """Complete internal TSCO intake registration with no external-system dependency."""
    if sample.status not in {SampleStatus.ACCEPTED.value, SampleStatus.AWAITING_RECEIPT.value}:
        raise ValueError(f"TSCO registration is not permitted from status {sample.status}")
    sample.registered_at = sample.registered_at or datetime.utcnow()
    sample.status = SampleStatus.AWAITING_RECEIPT.value
    add_event(
        db,
        sample,
        actor,
        "TSCO_INTERNAL_REGISTRATION",
        sample.status,
        f"TSCO registration complete for {sample.request_number}; awaiting physical receipt",
    )
    return sample.request_number


def release_tsco_official_report(
    db: Session,
    sample: SampleRequest,
    actor: User | None = None,
    *,
    report_reference: str = "",
    note: str = "",
    controlled_report: ControlledReport | None = None,
) -> None:
    """Release the final controlled report inside the standalone TSCO platform.

    Senior Chemist technical review moves the sample to REPORT_APPROVED. Technical Manager
    approval/stamp is the final TSCO release boundary and moves both the sample and controlled
    report directly to REPORT_RELEASED. Historical READY_FOR_LMS rows are accepted only so old
    UAT/data can be migrated without re-enabling an external dependency.
    """
    if sample.status == SampleStatus.REPORT_RELEASED.value:
        return
    if sample.status not in {SampleStatus.REPORT_APPROVED.value, SampleStatus.READY_FOR_LMS.value}:
        raise ValueError(
            f"Official TSCO report cannot be released from status {sample.status}; "
            "Senior technical review must be complete first"
        )

    controlled = controlled_report or (
        db.query(ControlledReport)
        .filter(ControlledReport.sample_request_id == sample.id)
        .order_by(ControlledReport.revision.desc(), ControlledReport.created_at.desc())
        .first()
    )
    if controlled is None:
        raise ValueError("A controlled report record is required before official TSCO release")
    if controlled.status not in {
        "PENDING_MANAGER_APPROVAL",
        "TECHNICAL_REVIEW",
        SampleStatus.REPORT_APPROVED.value,
        SampleStatus.READY_FOR_LMS.value,
        SampleStatus.REPORT_RELEASED.value,
    }:
        raise ValueError(f"Controlled report cannot be released from status {controlled.status}")

    reference = str(report_reference or controlled.report_number or sample.request_number).strip()
    controlled.status = SampleStatus.REPORT_RELEASED.value
    # Keep legacy columns neutral for schema/backward compatibility only.
    controlled.lms_reference = ""
    controlled.lms_status = "NOT_APPLICABLE"
    sample.status = SampleStatus.REPORT_RELEASED.value
    sample.released_at = sample.released_at or datetime.utcnow()

    detail = note.strip() or "Technical Manager approved/stamped and released the official TSCO report"
    if reference:
        detail = f"{detail}; TSCO report reference {reference}"
    add_event(db, sample, actor, "TSCO_OFFICIAL_REPORT_RELEASED", sample.status, detail)
    sync_case_from_sample(db, sample, actor, note=detail)
    activate_retention_after_report_release(db, sample, actor, report_reference=reference)


# Compatibility aliases for old imports/data only. They never call an LMS connector.
def register_in_lms(db: Session, sample: SampleRequest, actor: User) -> str:  # pragma: no cover
    return register_in_tsco(db, sample, actor)


def confirm_lms_official_report_issued(
    db: Session,
    sample: SampleRequest,
    actor: User | None = None,
    *,
    report_reference: str = "",
    note: str = "",
    controlled_report: ControlledReport | None = None,
) -> None:  # pragma: no cover
    return release_tsco_official_report(
        db,
        sample,
        actor,
        report_reference=report_reference,
        note=note,
        controlled_report=controlled_report,
    )
