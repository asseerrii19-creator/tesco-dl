from __future__ import annotations

from ..models import Role, User


def title(user: User) -> str:
    return (getattr(user, "job_title", "") or getattr(user, "full_name", "") or "").strip().lower()


def is_system_admin(user: User) -> bool:
    return getattr(user, "role", "") == Role.SYSTEM_ADMIN.value


def is_sampling_supervisor(user: User) -> bool:
    return getattr(user, "role", "") == Role.SAMPLING_SUPERVISOR.value


def is_field_manager(user: User) -> bool:
    return getattr(user, "role", "") == Role.OPERATIONS_MANAGER.value and "field" in title(user)


def is_client_account_coordinator(user: User) -> bool:
    return getattr(user, "role", "") == Role.CLIENT_COORDINATOR.value and "client account" in title(user)


def is_external_coordinator(user: User) -> bool:
    return getattr(user, "role", "") == Role.CLIENT_COORDINATOR.value and "external coordination" in title(user)


def is_sales_specialist(user: User) -> bool:
    return getattr(user, "role", "") == Role.SALES_MARKETING.value and "specialist" in title(user)


def is_salesman(user: User) -> bool:
    return getattr(user, "role", "") == Role.SALES_MARKETING.value and "salesman" in title(user)


def senior_domain(user: User) -> str:
    return (getattr(user, "senior_responsibility_domain", "") or "").strip().upper()


def is_senior_technical(user: User) -> bool:
    return getattr(user, "role", "") == Role.SENIOR_CHEMIST.value and senior_domain(user) == "TECHNICAL"


def is_senior_equipment(user: User) -> bool:
    return getattr(user, "role", "") == Role.SENIOR_CHEMIST.value and senior_domain(user) == "EQUIPMENT"


def is_senior_improvement(user: User) -> bool:
    return getattr(user, "role", "") == Role.SENIOR_CHEMIST.value and senior_domain(user) == "IMPROVEMENT"


def is_lab_manager(user: User) -> bool:
    return getattr(user, "role", "") == Role.TECHNICAL_MANAGER.value


def is_excellence(user: User) -> bool:
    return getattr(user, "role", "") == Role.EXCELLENCE.value


def can_create_commercial_case(user: User) -> bool:
    return is_sales_specialist(user) or is_client_account_coordinator(user)


def can_manage_controlled_commercial_documents(user: User) -> bool:
    return is_client_account_coordinator(user)


def can_view_commercial(user: User) -> bool:
    return getattr(user, "role", "") in {
        Role.SALES_MARKETING.value,
        Role.OPERATIONS_MANAGER.value,
        Role.CLIENT_COORDINATOR.value,
        Role.TECHNICAL_MANAGER.value,
        Role.MANAGEMENT.value,
    } or is_system_admin(user)


def can_assign_sampleman(user: User) -> bool:
    return is_sampling_supervisor(user) or is_field_manager(user)


def can_request_retest_resample(user: User) -> bool:
    return is_senior_technical(user)


def can_manage_equipment_master(user: User) -> bool:
    return is_senior_equipment(user)


def can_review_method(user: User) -> bool:
    return is_senior_technical(user)


def can_govern_validation(user: User) -> bool:
    return is_excellence(user)


def can_final_technical_approve(user: User) -> bool:
    return is_lab_manager(user)


def can_review_report(user: User) -> bool:
    return getattr(user, "role", "") == Role.SENIOR_CHEMIST.value


def can_submit_client_report(user: User) -> bool:
    return is_client_account_coordinator(user)


def can_create_lab_assignment(user: User) -> bool:
    return getattr(user, "role", "") == Role.SENIOR_CHEMIST.value
