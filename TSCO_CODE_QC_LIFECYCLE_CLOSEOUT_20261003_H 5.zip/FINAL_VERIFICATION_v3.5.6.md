# FINAL VERIFICATION — v3.5.6 QC Lifecycle / File-First Closeout

**Project:** 00012 — TSCO Digital Laboratory Platform  
**Change set:** H  
**Verification date:** 03 October 2026  
**Build marker:** `TSCO-QC-LIFECYCLE-FILE-FIRST-CLOSEOUT-20261003-H`

## Release result

**PASS — current Change Set H canonical verification completed successfully.**

- Version identity: **3.5.6**
- Alembic head: **c43a7d9e2f10** — unchanged; no database reset is required for this change set.
- Python application compile: **PASS**
- Laboratory Operations inline JavaScript syntax: **PASS**
- QC UI release assertions: **PASS**
- QC server-control assertions: **PASS**
- Current QC/UAT canonical suite: **44 passed / 0 failed**
- Broader non-retired regression suite: **95 passed / 0 failed / 5 deliberately deselected**

## QC controls verified

- QC Material/Lot lifecycle for **Internal** and **External CRM** sources.
- New lot stays **PENDING_SENIOR** until Senior Chemist technical approval.
- Authenticated Senior approval records reviewer, timestamp and electronic approval signature.
- New lot cannot silently inherit or replace the current active lot for the same exact Test + Method + Equipment scope.
- QC lots are bound to the **exact independently measured requested test**, not merely a broad group. Example: one BDV context cannot silently release another gap/method context.
- Exact Equipment Master scope is mandatory and must be active / in service / method-compatible.
- CRM supplier, certificate and controlled evidence are required.
- Internal QC qualification/preparation evidence is required.
- Routine analytical QC is **file-first** and retains the original run source file as controlled evidence.
- IEC 60156 BDV QC parses the six-run set and derives Average/RSD server-side.
- Power Factor QC parses the temperature-specific 25 °C / 100 °C source value.
- DGA QC parses certified gas components and evaluates them against the approved lot component targets/tolerance.
- Only **PASS** satisfies the analytical result-validity gate.
- WARNING / FAIL / missing QC / expired lot / unapproved lot remains blocked.
- Browser-forged PASS or manually forged result values cannot bypass server parsing/evaluation.
- Senior review cannot convert a failed QC run to PASS by override.
- Sample-result provenance snapshots QC record, lot, Senior approval and source evidence.

## UX verified

- The previous large always-open Analytical QC list is removed from the normal workstation view.
- QC lifecycle, history and responsibility sections are compact and **collapsed by default**.
- Workstation QC exposes only the relevant Test + Method + exact Equipment context.
- Workstation actions are **RUN QC**, **QC LOT**, or **QC CURRENT** according to server state.
- QC Lot setup shows lifecycle/status/signature information without flooding the page.

## Historical-test disposition

Five legacy assertions are intentionally outside the v3.5.6 canonical release suite:

1. Four v3.2.1 business-acceptance tests manufacture a QC row directly in browser state without exact Equipment ID, approved QC Lot or run-source evidence. That workflow is intentionally retired by Change Set H and must not be restored merely to satisfy historical tests.
2. One v3.2.1 controlled-document test assumes reference-standard source bytes are bundled inside the code package. The supplied G baseline does not contain those optional reference bytes/catalog. v3.5.6 does **not** fabricate or redistribute missing controlled source documents; startup is hardened so their absence does not crash deployment, while central ControlledDocument records remain authoritative.

These exclusions do not relax any current QC control.

## Production boundary

This package is a controlled UAT/code closeout, not corporate production authorization. Production still depends on company-owned hosting/database/network/TLS, credentials/secrets, SSO/security acceptance, source-system/LMS interfaces, backup/restore/monitoring and formal operational acceptance.
