# TSCO Digital Laboratory Platform — Project 00012

Current rollback-safe UAT package: **v3.5.5-R1**.

Baseline: the original v3.5.5 / Change Set G behavior that last showed the Electrical workstation and current UAT samples correctly.

This package keeps that workstation/assignment behavior and adds only the confirmed QC/result controls needed for the current UAT path:

- QC Material/Lot lifecycle with Internal or CRM source evidence.
- Senior Chemist technical approval before a lot becomes ACTIVE.
- File-first routine QC for instrument-supported tests, including BDV and Power Factor.
- Exact Test + Method + Equipment + approved Lot traceability.
- Only QC PASS opens result entry; WARNING/FAIL/missing QC remains blocked.
- BDV RSD remains derived from the same controlled BDV run set.
- Room Test Temperature/Humidity are operational inputs and no longer create an Additives analytical workstation.
- One narrow DMM UAT data-repair shim restores the known-good 27-Sep–10-Oct assignment only when the exact FS-DMM-26-000003/000004 demo payload is present. It expires outside that cycle and does not alter future rotations or Senior batch exceptions.

Database migration head remains unchanged; no database reset is required.
