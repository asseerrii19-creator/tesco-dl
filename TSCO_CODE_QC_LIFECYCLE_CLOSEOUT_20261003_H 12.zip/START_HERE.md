# START HERE — Project 00012 v3.5.5-R1

1. Replace only `TSCO_CODE_QC_LIFECYCLE_CLOSEOUT_20261003_H.zip` in GitHub.
2. Do not change Render Build Command, Start Command, Environment, Database, or Health Check.
3. Deploy on the existing `tsco-v285-final-review` service and existing PostgreSQL database.
4. Refresh the existing UAT session. Do not recreate FS-DMM-26-000003/000004.
5. Confirm `Electrical` appears for `UAT Role — Chemist` and the existing Electrical batch remains accessible.
6. Use the compact Analytical QC flow: propose/select QC lot → Senior approval → upload instrument QC source file → PASS.
7. Upload the existing BDV/PF sample files, complete Electrical, then continue to Senior Review and Final Analysis Report.

This package intentionally does not contain the failed v3.5.7/v3.5.8 continuity logic that mutated workstation assignments during page load.
