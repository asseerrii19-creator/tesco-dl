from pathlib import Path
from types import SimpleNamespace

from app.services.lab_operations import (
    _authoritative_global_assignment,
    _current_test_assignment,
    scope_operations_payload,
)


def _payload():
    return {
        "staff": [
            {"id": 17, "name": "UAT Role — Chemist", "active": True},
            {"id": 18, "name": "UAT Role — Chemical Technician", "active": True},
        ],
        "testAssignments": [
            {
                "id": "BAD-ADD", "batch_id": "*", "workstation": "Additives / Special Tests",
                "mode": "SINGLE", "primary_user_id": 18, "primary_name": "UAT Role — Chemical Technician",
                "revision": 99, "source": "AUTO_14_DAY_ROTATION", "cycle_key": "20260927-20261010",
                "assigned_at": "2026-10-02T00:00:00", "cycle_start": "2026-09-27T00:00:00",
                "cycle_end": "2026-10-10T23:59:59",
            },
            {
                "id": "GOOD-E", "batch_id": "*", "workstation": "Electrical",
                "mode": "SINGLE", "primary_user_id": 17, "primary_name": "UAT Role — Chemist",
                "revision": 1, "source": "AUTO_14_DAY_ROTATION", "cycle_key": "20260927-20261010",
                "assigned_at": "2026-09-27T00:00:00", "cycle_start": "2026-09-27T00:00:00",
                "cycle_end": "2026-10-10T23:59:59",
            },
            {
                "id": "BAD-BATCH-E", "batch_id": "LB-20261001175803-A162C1", "workstation": "Electrical",
                "mode": "SINGLE", "primary_user_id": 18, "primary_name": "UAT Role — Chemical Technician",
                "revision": 50, "source": "AUTO_14_DAY_ROTATION_RECONCILIATION",
                "assigned_at": "2026-10-03T00:00:00",
            },
        ],
        "batches": [{
            "id": "LB-20261001175803-A162C1",
            "samples": ["FS-DMM-26-000003", "FS-DMM-26-000004"],
            "tests": [
                {"test": "Breakdown Voltage @2.5mm- AVG"},
                {"test": "Power Factor @25°C/60Hz"},
            ],
        }],
        "results": [], "qc": [], "qualifiedQcProfiles": [], "retests": [],
        "dgaAttachments": [], "resultEvidence": [], "assignmentCompletions": [],
        "qualityDistributions": [], "qualityTaskEvents": [], "reports": [], "retained": [],
        "storageAssignments": [], "batchHistory": [], "cancelledSamples": [], "supervisorNotes": [],
    }


def test_damaged_uat_batch_cannot_override_14_day_authority():
    payload = _payload()
    assert _authoritative_global_assignment(payload, "Electrical")["primary_user_id"] == 17
    assert _authoritative_global_assignment(payload, "Additives / Special Tests") is None
    resolved = _current_test_assignment(payload, "LB-20261001175803-A162C1", "Electrical")
    assert resolved["primary_user_id"] == 17


def test_scoped_payload_keeps_governed_global_cards_and_drops_ghost_additives():
    payload = _payload()
    chem = SimpleNamespace(id=17, role="lab_technician")
    tech = SimpleNamespace(id=18, role="lab_technician")

    chem_view = scope_operations_payload(payload, chem)
    assert any(a.get("workstation") == "Electrical" and a.get("primary_user_id") == 17 for a in chem_view["testAssignments"])
    assert all(a.get("workstation") != "Additives / Special Tests" for a in chem_view["testAssignments"])
    assert chem_view["batches"]

    tech_view = scope_operations_payload(payload, tech)
    assert all(a.get("workstation") != "Additives / Special Tests" for a in tech_view["testAssignments"])
    assert tech_view["batches"] == []


def test_frontend_is_assignment_driven_not_batch_driven():
    html = Path("app/lab_ops/index_template.html").read_text()
    assert "return authoritativeGlobalAssignment(workstation)}" in html
    assert "candidates.forEach(w=>{const a=authoritativeGlobalAssignment(w);if(assignmentAllowsUser(a))out.add(w)}" in html
    assert "function currentTestAssignment(batchId,workstation){return latestAssignmentForKey(batchId,workstation)" not in html
