from pathlib import Path

HTML = Path('app/lab_ops/index_template.html').read_text()


def test_removed_legacy_qc_controls_cannot_abort_bootstrap():
    # The v3.6.4 live regression was caused by refreshSelects dereferencing QC controls
    # (qa / qqAnalyst) that no longer exist after the QC lifecycle UI redesign.
    assert 'id="qa"' not in HTML
    assert 'id="qqAnalyst"' not in HTML
    assert "function fillSelect(el,values,selected=''){if(!el)return;" in HTML
    assert "const qa=$('qa'),qq=$('qqAnalyst'),trk=$('trkEmployee')" in HTML
    assert "if(qa)qa.disabled=true;if(qq)qq.disabled=true" in HTML


def test_workstation_shell_renders_before_noncritical_sections_and_server_bootstrap_starts_first():
    assert "function renderAll(){renderWorkstationCards();renderAdditives();refreshSelects();" in HTML
    assert "autoDerivedCalculations();bootstrapStorage();renderAll();" in HTML
    assert 'id="additiveHead" style="display:none"' in HTML
