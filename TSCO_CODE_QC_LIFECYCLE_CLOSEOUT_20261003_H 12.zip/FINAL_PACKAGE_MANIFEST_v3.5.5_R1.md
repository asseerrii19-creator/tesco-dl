# Package Manifest — v3.5.5-R1

Deployment archive name: `TSCO_CODE_QC_LIFECYCLE_CLOSEOUT_20261003_H.zip`

Baseline: Change Set G / v3.5.5.
Purpose: restore stable Electrical workstation behavior while retaining controlled file-first QC and report path corrections.

Primary changed files:
- `app/services/lab_operations.py`
- `app/routes/lab_operations.py`
- `app/lab_ops/index_template.html`
- `app/services/document_catalog.py`
- `tests/test_v356_qc_lifecycle_file_first.py`
- `tests/test_v357_workstation_continuity.py`
- `tests/test_v358_workstation_assignment_authority.py`
- `tests/test_v359_uat_electrical_report_path.py`
- `BUILD_RELEASE_CHECK.sh`
