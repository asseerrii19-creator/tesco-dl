from __future__ import annotations

from fastapi import APIRouter, Depends, Form, Request, HTTPException
from fastapi.responses import RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import Role, SampleRequest, SampleStatus, Site
from ..security import require_user
from ..services.audit import add_audit
from ..services.workflow import add_event
from ..services.lab_operations import sync_sample_to_operations, get_operations_state, scope_operations_payload, _workstation_for_test, platform_sample_lab_projection_from_payload, reconcile_operations_to_platform
from ..services.commercial import sync_case_from_sample
from ..services.month_close import assert_sample_period_open
from ..services.technical_review_assignments import active_review_assignment, ensure_site_review_assignments, assigned_to_user

router = APIRouter(prefix="/lab", tags=["laboratory"])
ALLOWED = {
    Role.LAB_TECHNICIAN.value,
    Role.SENIOR_CHEMIST.value,
    Role.QUALITY.value,
    Role.TECHNICAL_MANAGER.value,
    Role.SYSTEM_ADMIN.value,
}
STATUS_WRITE_ALLOWED = {Role.SENIOR_CHEMIST.value}


@router.get("")
def workspace(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    assigned_work = []
    samples = []
    sample_rows = []

    if user.role == Role.LAB_TECHNICIAN.value:
        site = db.get(Site, user.site_id) if user.site_id else db.scalar(select(Site).where(Site.code == "DMM"))
        if site:
            _, payload = get_operations_state(db, site)
            scoped = scope_operations_payload(payload, user)
            assignment_rows = [a for a in scoped.get("testAssignments", []) if isinstance(a, dict)]
            for batch in scoped.get("batches", []):
                if not isinstance(batch, dict):
                    continue
                batch_id = str(batch.get("id") or "")
                workstations = []
                stations = sorted({
                    _workstation_for_test(
                        batch,
                        str((row if isinstance(row, dict) else {"test": row}).get("test", ""))
                    )
                    for row in batch.get("tests", [])
                })
                for workstation in stations:
                    exact = [
                        a for a in assignment_rows
                        if str(a.get("batch_id") or "") == batch_id
                        and str(a.get("workstation") or "") == workstation
                    ]
                    defaults = [
                        a for a in assignment_rows
                        if str(a.get("batch_id") or "") == "*"
                        and str(a.get("workstation") or "") == workstation
                    ]
                    candidates = exact or defaults
                    if not candidates:
                        continue
                    candidates.sort(key=lambda a: (int(a.get("revision") or 0), str(a.get("assigned_at") or "")))
                    assignment = candidates[-1]
                    tests = [
                        row.get("test", "") if isinstance(row, dict) else str(row)
                        for row in batch.get("tests", [])
                        if _workstation_for_test(
                            batch,
                            str((row if isinstance(row, dict) else {"test": row}).get("test", ""))
                        ) == workstation
                    ]
                    workstations.append({
                        "name": workstation,
                        "mode": str(assignment.get("mode") or "SINGLE"),
                        "tests": [t for t in tests if t],
                    })
                if workstations:
                    assigned_work.append({
                        "id": batch_id,
                        "client": batch.get("client_name") or batch.get("client_code") or "—",
                        "priority": batch.get("priority") or "Normal",
                        "status": batch.get("status") or "Assigned",
                        "samples": list(batch.get("samples") or []),
                        "workstations": workstations,
                    })
    else:
        site = db.get(Site, user.site_id) if user.site_id else db.scalar(select(Site).where(Site.code == "DMM"))
        payload = None
        if site:
            _, payload = get_operations_state(db, site)
            # Deterministic server-side convergence: if a valid analytical save already made the
            # sample review-ready, refresh the canonical SampleRequest stage without trusting a
            # browser mirror. This is a system-derived transition, not a Senior user edit.
            if reconcile_operations_to_platform(db, payload, site.id, actor=None):
                db.commit()
        statuses = [
            SampleStatus.READY_FOR_LAB.value, SampleStatus.REGISTERED.value, SampleStatus.TESTING.value,
            SampleStatus.TECHNICAL_REVIEW.value, SampleStatus.REPORT_APPROVED.value,
        ]
        if user.role == Role.SENIOR_CHEMIST.value:
            # My Technical Review is an ownership queue, not a mirror of every testing sample.
            statuses = [SampleStatus.TECHNICAL_REVIEW.value, SampleStatus.REPORT_APPROVED.value]
        stmt = select(SampleRequest).where(SampleRequest.status.in_(statuses))
        if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
            stmt = stmt.where(SampleRequest.site_id == user.site_id)
        candidates = db.scalars(stmt.order_by(SampleRequest.created_at.desc()).limit(200)).all()
        assignments = ensure_site_review_assignments(db, candidates, actor=None) if candidates else {}
        # Senior users keep site-level visibility of every Technical Review item so samples never
        # disappear from UAT/operations. Ownership still controls every writable action below.
        samples = candidates
        if payload is not None:
            sample_rows = [
                {"sample": row, "projection": platform_sample_lab_projection_from_payload(payload, row),
                 "review_assignment": assignments.get(row.id) or active_review_assignment(db, row.id),
                 "is_assigned": assigned_to_user(assignments.get(row.id) or active_review_assignment(db, row.id), user) if user.role == Role.SENIOR_CHEMIST.value else True}
                for row in samples
            ]
        else:
            sample_rows = [{"sample": row, "projection": {"blocker": "Laboratory site is unavailable", "blockers": ["Laboratory site is unavailable"], "test_progress_pct": 0, "workstation_progress_pct": 0, "ready_for_technical_review": False}, "review_assignment": assignments.get(row.id) or active_review_assignment(db, row.id), "is_assigned": assigned_to_user(assignments.get(row.id) or active_review_assignment(db, row.id), user) if user.role == Role.SENIOR_CHEMIST.value else True} for row in samples]
        db.commit()

    return templates.TemplateResponse(
        "lab_workspace.html",
        {"request": request, "user": user, "samples": samples, "sample_rows": sample_rows, "assigned_work": assigned_work, "assigned_workstation_count": sum(len(x["workstations"]) for x in assigned_work), "urgent_high_count": sum(1 for x in assigned_work if str(x["priority"]).lower() in {"urgent", "high"})},
    )


@router.post("/{sample_id}/status")
def update_status(
    sample_id: int,
    request: Request,
    action: str = Form(...),
    note: str = Form(""),
    db: Session = Depends(get_db),
):
    # Sample-level START_TESTING / SUBMIT_REVIEW is retired.
    # Laboratory progress is derived from controlled workstation assignments, results, QC and
    # retest state. Chemists complete only their assigned work; the platform advances the
    # sample automatically when the controlled laboratory state is ready.
    user = require_user(request, db, STATUS_WRITE_ALLOWED)
    sample = db.get(SampleRequest, sample_id)
    if not sample or (user.site_id and sample.site_id != user.site_id):
        raise HTTPException(status_code=404, detail="Sample not found")
    raise HTTPException(
        status_code=409,
        detail="Legacy sample-level laboratory status actions are retired; use controlled workstation assignment completion",
    )
