from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, Request, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import (
    AuditLog, CompetencyRecord, EquipmentAsset, EquipmentEvent, EvidenceRecord,
    QualityCase, QualityExecutionRevision, ControlledDocument, Role, Site, User, SampleRequest,
)
from ..security import require_user
from ..services.lab_operations import get_operations_state
from ..responsibilities import senior_responsibility

router = APIRouter(prefix="/quality", tags=["quality"])
VIEW = {Role.QUALITY.value, Role.EXCELLENCE.value, Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value, Role.MANAGEMENT.value, Role.SYSTEM_ADMIN.value}
CASE_WRITE = {Role.EXCELLENCE.value, Role.TECHNICAL_MANAGER.value}
EQUIPMENT_WRITE = set()
TABS = [
    ("qc", "QC Ownership"),
    ("equipment", "Equipment & Calibration"),
    ("materials", "Materials / Gases / Storage"),
    ("validation", "Validation / Verification"),
    ("ilc_pt", "ILC / PT"),
    ("capa", "NCR / CAPA"),
    ("competency", "Competency"),
    ("evidence", "Evidence"),
    ("audit", "Audit"),
]


def _site(db: Session, user) -> Site:
    site = db.get(Site, user.site_id) if user.site_id else None
    return site or db.scalar(select(Site).where(Site.code == "DMM"))


@router.get("")
def quality_center(request: Request, tab: str = "qc", db: Session = Depends(get_db)):
    user = require_user(request, db, VIEW)
    site = _site(db, user)
    if user.role == Role.EXCELLENCE.value:
        visible_tabs = [("qc", "QC History"), ("equipment", "Equipment & Calibration History"),
                        ("validation", "Validation / Verification"), ("evidence", "Evidence"),
                        ("audit", "Audit & Findings")]
        workspace_mode = "excellence"
    elif user.role == Role.SENIOR_CHEMIST.value:
        domain = senior_responsibility(user)
        if domain == "EQUIPMENT":
            visible_tabs = [("qc", "QC Rotation"), ("equipment", "Equipment & Calibration"), ("materials", "Materials / Gases / Storage")]
            workspace_mode = "senior_equipment"
        elif domain == "IMPROVEMENT":
            visible_tabs = [("validation", "Validation / Verification"), ("evidence", "Evidence"), ("audit", "Audit & Findings")]
            workspace_mode = "senior_improvement"
        else:
            raise HTTPException(status_code=403, detail="This governance section belongs to your assigned Senior responsibility")
    else:
        visible_tabs = TABS
        workspace_mode = "governance"
    allowed = {k for k, _ in visible_tabs}
    tab = tab if tab in allowed else next(iter(allowed))

    staff_stmt = select(User).where(User.active.is_(True)).order_by(User.full_name)
    if user.site_id:
        staff_stmt = staff_stmt.where((User.site_id == user.site_id) | (User.site_id.is_(None)))
    staff = list(db.scalars(staff_stmt).all())
    equipment = list(db.scalars(select(EquipmentAsset).where(EquipmentAsset.site_id == site.id, EquipmentAsset.active.is_(True)).order_by(EquipmentAsset.equipment_id)).all())
    equipment_events = list(db.scalars(select(EquipmentEvent).join(EquipmentAsset).where(EquipmentAsset.site_id == site.id).order_by(EquipmentEvent.event_at.desc()).limit(150)).all())
    cases = list(db.scalars(select(QualityCase).where(QualityCase.site_id == site.id).order_by(QualityCase.created_at.desc()).limit(300)).all())
    competencies = list(db.scalars(select(CompetencyRecord).where(CompetencyRecord.site_id == site.id, CompetencyRecord.active.is_(True)).order_by(CompetencyRecord.created_at.desc()).limit(300)).all())
    evidence = list(db.scalars(select(EvidenceRecord).where(EvidenceRecord.site_id == site.id).order_by(EvidenceRecord.created_at.desc()).limit(200)).all())
    evidence_samples = list(db.scalars(select(SampleRequest).where(SampleRequest.site_id == site.id).order_by(SampleRequest.created_at.desc()).limit(300)).all())
    audits = list(db.scalars(select(AuditLog).where((AuditLog.site_id == site.id) | (AuditLog.site_id.is_(None))).order_by(AuditLog.created_at.desc()).limit(200)).all())
    controlled_documents = list(db.scalars(select(ControlledDocument).where(
        (ControlledDocument.site_id == site.id) | (ControlledDocument.site_id.is_(None)),
        ControlledDocument.status.in_(["ACTIVE", "EFFECTIVE", "REFERENCE"]),
        ControlledDocument.document_type.in_(["METHOD", "SOP", "EOP", "QUICK GUIDE"]),
    ).order_by(ControlledDocument.document_type, ControlledDocument.code, ControlledDocument.revision.desc())).all())
    revision_rows = list(db.scalars(select(QualityExecutionRevision).where(
        QualityExecutionRevision.quality_case_id.in_([c.id for c in cases] or [-1])
    ).order_by(QualityExecutionRevision.quality_case_id, QualityExecutionRevision.revision.desc())).all())
    execution_revisions = {}
    for rev in revision_rows:
        execution_revisions.setdefault(rev.quality_case_id, []).append(rev)

    _, payload = get_operations_state(db, site)
    distributions = sorted(payload.get("qualityDistributions", []), key=lambda x: str(x.get("month", "")), reverse=True)
    current_distribution = distributions[0] if distributions else None
    routine_owners = list(current_distribution.get("routine_owners", [])) if current_distribution else []
    analytical_ownership = list(current_distribution.get("analytical_ownership", [])) if current_distribution else []
    materials_assignments = [x for x in routine_owners if str(x.get("domain", "")) == "Materials, Gases & Storage"]
    controlled_materials = list(payload.get("standards", []))
    quality_events = list(payload.get("qualityTaskEvents", []))
    analytical_qc_events = [row for row in payload.get("qc", []) if isinstance(row, dict) and str(row.get("mode") or "routine").lower() != "qualify"]
    trend_groups = {}
    for row in analytical_qc_events:
        key = str(row.get("test") or row.get("group") or "Unclassified QC")
        group = trend_groups.setdefault(key, {"name": key, "total": 0, "pass": 0, "attention": 0, "fail": 0, "latest_at": "", "latest_result": "", "latest_target": ""})
        group["total"] += 1
        status = str(row.get("status") or "").upper()
        if status == "PASS": group["pass"] += 1
        elif status == "FAIL": group["fail"] += 1
        else: group["attention"] += 1
        stamp = str(row.get("ts") or "")
        if stamp >= group["latest_at"]:
            group["latest_at"] = stamp; group["latest_result"] = row.get("result", ""); group["latest_target"] = row.get("target", "")
    qc_trends = sorted(trend_groups.values(), key=lambda x: (x["fail"] > 0, x["attention"] > 0, x["total"]), reverse=True)
    quality_event_map = {}
    for event in quality_events:
        aid = str(event.get("assignment_id") or "")
        if aid and (aid not in quality_event_map or str(event.get("completed_at") or "") > str(quality_event_map[aid].get("completed_at") or "")):
            quality_event_map[aid] = event

    return templates.TemplateResponse("quality_center.html", {
        "request": request, "user": user, "site": site, "tab": tab,
        "visible_tabs": visible_tabs, "workspace_mode": workspace_mode,
        "can_case_write": user.role in CASE_WRITE,
        "can_equipment_write": user.role in EQUIPMENT_WRITE or (user.role == Role.SENIOR_CHEMIST.value and senior_responsibility(user) == "EQUIPMENT"),
        "can_qc_reassign": user.role == Role.TECHNICAL_MANAGER.value or (user.role == Role.SENIOR_CHEMIST.value and senior_responsibility(user) == "EQUIPMENT"),
        "can_improvement_source": user.role in {Role.EXCELLENCE.value, Role.TECHNICAL_MANAGER.value} or (user.role == Role.SENIOR_CHEMIST.value and senior_responsibility(user) == "EQUIPMENT"),
        "staff": staff, "equipment": equipment, "equipment_events": equipment_events,
        "cases": cases, "competencies": competencies, "evidence_rows": evidence, "evidence_samples": evidence_samples, "audits": audits,
        "can_evidence_upload": user.role in {Role.QUALITY.value, Role.EXCELLENCE.value, Role.TECHNICAL_MANAGER.value} or (user.role == Role.SENIOR_CHEMIST.value and senior_responsibility(user) == "IMPROVEMENT"),
        "controlled_documents": controlled_documents, "execution_revisions": execution_revisions,
        "quality_distribution": current_distribution, "routine_owners": routine_owners,
        "analytical_ownership": analytical_ownership, "materials_assignments": materials_assignments,
        "controlled_materials": controlled_materials, "quality_events": quality_events, "qc_trends": qc_trends, "analytical_qc_events": analytical_qc_events,
        "quality_event_map": quality_event_map, "now": datetime.utcnow(),
    })
