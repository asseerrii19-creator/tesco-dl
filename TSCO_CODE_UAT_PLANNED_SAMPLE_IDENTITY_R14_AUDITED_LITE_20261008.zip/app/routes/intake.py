from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timedelta
from io import BytesIO
from pathlib import Path

from PIL import Image, UnidentifiedImageError
from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from fastapi.responses import JSONResponse, RedirectResponse
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import (
    Asset, AssetHistoryEvent, Client, CommercialAttachment, CommercialCase, CommercialRequestLine, CustodyEvent, DataQualityIssue, PlannedSample, PurchaseOrder, Quotation, Role, SamplePhoto,
    SampleRequest, SampleStatus, Site,
)
from ..security import require_user
from ..services.workflow import add_event, register_in_tsco
from ..services.audit import add_audit
from ..services.scope import can_access_site
from ..services.identifiers import next_request_identifiers
from ..services.barcodes import generate_assets
from ..services.lab_operations import _batch_workstations, _current_test_assignment, get_operations_state, package_catalog, package_method_configuration_issues, resolved_sample_package, sync_sample_to_operations, sync_samples_to_operations
from ..services.commercial import request_line_expected_serials, resolve_handover_case, require_complete_handover, link_sample, stage_index, sync_case_from_sample
from ..services.client_data_form import case_data_form_payload, sync_missing_sample_metadata_from_case_data_form
from ..services.planned_samples import claim_planned_identity, planned_samples_for_case, ensure_planned_samples
from ..services.month_close import assert_site_period_open, assert_sample_period_open
from ..storage import BARCODE_DIR, UPLOAD_DIR

router = APIRouter(prefix="/intake", tags=["sample intake and distribution"])
READ_ALLOWED = {Role.DATA_ENTRY.value, Role.SYSTEM_ADMIN.value}
WRITE_ALLOWED = {Role.DATA_ENTRY.value}
AMEND_ALLOWED = {Role.DATA_ENTRY.value, Role.SYSTEM_ADMIN.value}
MAX_DIRECT_DOCUMENT_BYTES = 10_000_000


def _optional_int(value: str, label: str) -> int | None:
    clean = (value or "").strip()
    if not clean:
        return None
    if not clean.isdigit():
        raise ValueError(f"{label} is invalid")
    return int(clean)




def _optional_float(value: str, label: str, *, minimum: float | None = None, maximum: float | None = None) -> float | None:
    clean = (value or "").strip()
    if not clean:
        return None
    try:
        number = float(clean)
    except ValueError as exc:
        raise ValueError(f"{label} is invalid") from exc
    if minimum is not None and number < minimum:
        raise ValueError(f"{label} must be at least {minimum}")
    if maximum is not None and number > maximum:
        raise ValueError(f"{label} must be at most {maximum}")
    return number


def _optional_datetime(value: str, label: str) -> datetime | None:
    clean = (value or "").strip()
    if not clean:
        return None
    try:
        return datetime.fromisoformat(clean)
    except ValueError as exc:
        raise ValueError(f"{label} is invalid") from exc

def _display_method_family(package: dict) -> str:
    families: list[str] = []
    for row in package.get("tests", []):
        method = str((row or {}).get("method") or "").strip().upper() if isinstance(row, dict) else ""
        label = "IEC" if method.startswith("IEC") else "ASTM" if method.startswith("ASTM") else "OTHER" if method and method not in {"-", "CALCULATION"} else ""
        if label and label not in families:
            families.append(label)
    return "+".join(families) or "GENERAL"


def _apply_priority_tat(sample: SampleRequest, priority: str, required_tat: str, due_at: str) -> None:
    clean_priority = (priority or sample.priority or "NORMAL").strip().upper()
    if clean_priority not in {"NORMAL", "HIGH", "URGENT"}:
        raise ValueError("Priority must be NORMAL, HIGH or URGENT")
    clean_tat = (required_tat or "").strip().upper()
    if clean_tat not in {"", "12H", "24H", "EXACT_DUE"}:
        raise ValueError("Required TAT must be Standard, 12H, 24H or Exact Due")
    clean_due = (due_at or "").strip()
    try:
        parsed_due = datetime.fromisoformat(clean_due) if clean_due else None
    except ValueError as exc:
        raise ValueError("Exact due date/time is invalid") from exc
    if clean_tat == "EXACT_DUE" and parsed_due is None:
        raise ValueError("Exact Due TAT requires an exact due date/time")
    if clean_tat in {"12H", "24H"} and parsed_due is None:
        # Preserve an already-confirmed countdown instead of silently restarting it on re-save.
        if str(sample.required_tat or "").upper() == clean_tat and sample.due_at is not None:
            parsed_due = sample.due_at
        else:
            parsed_due = datetime.utcnow() + timedelta(hours=12 if clean_tat == "12H" else 24)
    if not clean_tat:
        parsed_due = None
    sample.priority = clean_priority
    sample.required_tat = clean_tat
    sample.due_at = parsed_due


def _safe_direct_document(upload: UploadFile | None) -> tuple[bytes, str, str] | None:
    if upload is None or not upload.filename:
        return None
    raw = upload.file.read(MAX_DIRECT_DOCUMENT_BYTES + 1)
    if len(raw) > MAX_DIRECT_DOCUMENT_BYTES:
        raise ValueError("Client submission document must be 10 MB or smaller")
    content_type = (upload.content_type or "").lower()
    suffix = Path(upload.filename).suffix.lower()
    if content_type == "application/pdf" or suffix == ".pdf":
        if not raw.startswith(b"%PDF-"):
            raise ValueError("Uploaded PDF is invalid")
        return raw, ".pdf", Path(upload.filename).name[:220]
    if content_type.startswith("image/") or suffix in {".jpg", ".jpeg", ".png", ".webp"}:
        try:
            with Image.open(BytesIO(raw)) as image:
                image.verify()
                fmt = (image.format or "").upper()
        except (UnidentifiedImageError, OSError, SyntaxError, ValueError):
            raise ValueError("Client submission image is invalid or corrupt")
        ext = {"JPEG": ".jpg", "PNG": ".png", "WEBP": ".webp"}.get(fmt)
        if not ext:
            raise ValueError("Client submission image must be JPEG, PNG or WebP")
        return raw, ext, Path(upload.filename).name[:220]
    raise ValueError("Client submission document must be PDF, JPEG, PNG or WebP")


def _site_for_user(db: Session, user) -> Site:
    site = db.get(Site, user.site_id) if user.site_id else db.scalar(select(Site).where(Site.code == "DMM"))
    if not site or not site.active:
        raise ValueError("An active laboratory site is required")
    return site


def _clean_saved_options(values, *, limit: int = 30) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for value in values:
        text = str(value or "").strip()
        if not text or text in seen:
            continue
        seen.add(text); out.append(text)
        if len(out) >= limit:
            break
    return out


def _asset_sampling_points(asset: Asset) -> list[str]:
    defaults = ["Main Tank - Bottom", "Main Tank - Top", "OLTC", "Bushing", "Cable Box H1", "Drum / Tote"]
    try:
        saved = json.loads(asset.sampling_points_json or "[]")
        if not isinstance(saved, list):
            saved = []
    except Exception:
        saved = []
    return _clean_saved_options([*saved, *defaults], limit=50)


def _remember_sampling_point(asset: Asset, point: str) -> None:
    clean = (point or "").strip()[:100]
    values = _asset_sampling_points(asset)
    if clean and clean not in values:
        values.insert(0, clean)
    asset.sampling_points_json = json.dumps(values[:50], ensure_ascii=False)


def _intake_asset_code(db: Session, client: Client, serial: str) -> str:
    token = re.sub(r"[^A-Z0-9]+", "-", (serial or "").upper()).strip("-") or "ASSET"
    prefix = re.sub(r"[^A-Z0-9]+", "-", (client.code or "CLIENT").upper()).strip("-") or "CLIENT"
    base = f"{prefix}-{token}"[:80]
    candidate = base
    suffix = 2
    while db.scalar(select(Asset.id).where(Asset.client_id == client.id, Asset.asset_code == candidate)):
        tail = f"-{suffix}"
        candidate = f"{base[:80-len(tail)]}{tail}"
        suffix += 1
    return candidate


def _create_intake_asset(db: Session, *, client: Client, serial: str, case: CommercialCase | None, metadata: dict, user, request: Request) -> Asset:
    station = str(metadata.get("station_name") or (case.sample_delivery_notes if case else "") or "").strip()[:160]
    point = str(metadata.get("sampling_point") or "").strip()[:100]
    asset = Asset(
        client_id=client.id,
        asset_code=_intake_asset_code(db, client, serial),
        serial_number=serial[:120],
        equipment_type=str(metadata.get("equipment_type") or "Power Transformer")[:80],
        manufacturer=str(metadata.get("manufacturer") or "")[:120],
        rated_mva=metadata.get("rated_mva"),
        hv_voltage_kv=metadata.get("hv_voltage_kv"),
        lv_voltage_kv=metadata.get("lv_voltage_kv"),
        cooling_type=str(metadata.get("cooling_type") or "")[:100],
        manufacture_year=metadata.get("manufacture_year"),
        oil_type=str(metadata.get("oil_type") or "")[:120],
        tag_number=str(metadata.get("tag_number") or "")[:100],
        sampling_points_json=json.dumps([point] if point else [], ensure_ascii=False),
        station_name=station,
        asset_location_label=station,
        active=True,
    )
    db.add(asset); db.flush()
    db.add(AssetHistoryEvent(
        asset_id=asset.id, event_type="INTAKE_IDENTITY_CREATED", event_at=datetime.utcnow(),
        details=f"Created by Data Entry from approved client request / data form for {case.case_code if case else 'direct intake'}",
        created_by_id=user.id,
    ))
    add_audit(
        db, actor=user, request=request, action="INTAKE_ASSET_IDENTITY_CREATED", entity_type="Asset", entity_id=asset.id,
        summary=f"Created controlled asset identity {asset.asset_code} for serial {serial}",
        details={"case_id": case.id if case else None, "serial": serial, "source": "APPROVED_REQUEST_AND_CLIENT_DATA_FORM"},
    )
    return asset


@router.get("")
def queue(request: Request, q: str = "", view: str = "incoming", db: Session = Depends(get_db)):
    user = require_user(request, db, READ_ALLOWED)
    site = _site_for_user(db, user)
    stmt = select(SampleRequest).order_by(SampleRequest.submitted_at.desc(), SampleRequest.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        stmt = stmt.where(SampleRequest.site_id == user.site_id)
    view = (view or "incoming").strip().lower()
    view_statuses = {
        "incoming": [SampleStatus.SUBMITTED.value, SampleStatus.RETURNED.value, SampleStatus.ACCEPTED.value],
        "receiving": [SampleStatus.AWAITING_RECEIPT.value],
        "distribution": [SampleStatus.RECEIVED.value],
        "released": [SampleStatus.READY_FOR_LAB.value],
    }
    if view in view_statuses:
        stmt = stmt.where(SampleRequest.status.in_(view_statuses[view]))
    elif view not in {"all", "assets"}:
        view = "incoming"
        stmt = stmt.where(SampleRequest.status.in_(view_statuses[view]))
    if q.strip() and view != "assets":
        term = f"%{q.strip()}%"
        stmt = stmt.where(
            or_(
                SampleRequest.request_number.ilike(term),
                SampleRequest.barcode_value.ilike(term),
                SampleRequest.lms_number.ilike(term),
                SampleRequest.client_sample_reference.ilike(term),
                SampleRequest.client.has(or_(Client.name.ilike(term), Client.code.ilike(term))),
                SampleRequest.asset.has(or_(Asset.serial_number.ilike(term), Asset.asset_code.ilike(term), Asset.station_name.ilike(term))),
            )
        )
    samples = [] if view == "assets" else db.scalars(stmt.limit(150)).all()
    clients = db.scalars(select(Client).where(Client.active.is_(True)).order_by(Client.name)).all()
    quotes = db.scalars(select(Quotation).where(Quotation.status.in_(["ACTIVE", "CLIENT_ACCEPTED"])).order_by(Quotation.number)).all()
    pos = db.scalars(select(PurchaseOrder).where(PurchaseOrder.status == "ACTIVE").order_by(PurchaseOrder.number)).all()
    asset_stmt = select(Asset).where(Asset.active.is_(True)).order_by(Asset.client_id, Asset.station_name, Asset.asset_code)
    if view == "assets" and q.strip():
        term = f"%{q.strip()}%"
        asset_stmt = asset_stmt.where(or_(
            Asset.serial_number.ilike(term), Asset.asset_code.ilike(term), Asset.station_name.ilike(term), Asset.asset_location_label.ilike(term),
            Asset.client.has(or_(Client.name.ilike(term), Client.code.ilike(term))),
        ))
    assets = db.scalars(asset_stmt.limit(300)).all()
    packages = package_catalog(db, site.id)
    for package in packages:
        package["method_configuration_issues"] = package_method_configuration_issues(package)
        package["release_ready"] = not package["method_configuration_issues"]
    package_by_name = {row["name"]: row for row in packages}
    batch_groups = []
    if view == "distribution":
        grouped: dict[tuple, dict] = {}
        for sample in samples:
            try:
                package = resolved_sample_package(db, sample)
            except Exception:
                package = package_by_name.get(sample.requested_package, {"name": sample.requested_package, "tests": []})
            requested_family = str(sample.requested_method_family or "DEFAULT").strip().upper()
            family = requested_family if requested_family in {"ASTM", "IEC"} else _display_method_family(package)
            priority = (sample.priority or "NORMAL").upper()
            required_tat = (sample.required_tat or "").upper()
            exact_due_key = sample.due_at.replace(second=0, microsecond=0).isoformat() if required_tat == "EXACT_DUE" and sample.due_at else ""
            key = (sample.client_id, family, sample.requested_package, priority, required_tat, exact_due_key)
            group = grouped.setdefault(key, {
                "client": sample.client, "method_family": family, "package": package.get("name", sample.requested_package),
                "priority": priority, "required_tat": required_tat, "samples": [], "earliest_due": None,
                "method_configuration_issues": package.get("method_configuration_issues", []),
                "release_ready": package.get("release_ready", True),
            })
            group["samples"].append(sample)
            if sample.due_at and (group["earliest_due"] is None or sample.due_at < group["earliest_due"]):
                group["earliest_due"] = sample.due_at
        batch_groups = sorted(grouped.values(), key=lambda g: ({"URGENT": 0, "HIGH": 1, "NORMAL": 2}.get(g["priority"], 3), g["earliest_due"] or datetime.max))
    cases = list(db.scalars(select(CommercialCase).where(CommercialCase.site_id == site.id, CommercialCase.purchase_order_id.is_not(None))).all())
    case_ids = [c.id for c in cases]
    counts: dict[int, int] = {}
    if case_ids:
        counts = {int(cid): int(cnt) for cid, cnt in db.execute(
            select(SampleRequest.commercial_case_id, func.count(SampleRequest.id))
            .where(SampleRequest.commercial_case_id.in_(case_ids))
            .group_by(SampleRequest.commercial_case_id)
        ).all() if cid is not None}
    po_scope = {}
    for case in cases:
        registered = counts.get(case.id, 0)
        expected = case.expected_samples
        po_scope[case.purchase_order_id] = {
            "case_code": case.case_code, "expected": expected or "", "registered": registered,
            "remaining": max(0, expected - registered) if expected is not None else "",
            "package": case.requested_test_package or "", "priority": case.default_priority or "NORMAL",
            "tat": case.required_tat or "",
        }
    # In-place upgrade support: cases already handed over before this release may not yet
    # have their pre-generated physical sample identities. Backfill them idempotently
    # when Intake opens so current UAT data can continue without a DB reset.
    planned_backfilled = False
    for case in cases:
        if stage_index(case.current_stage) < stage_index("COMPLETE_HANDOVER"):
            continue
        before = db.scalar(select(func.count()).select_from(PlannedSample).where(PlannedSample.commercial_case_id == case.id)) or 0
        rows = ensure_planned_samples(db, case)
        if len(rows) > int(before):
            planned_backfilled = True
    if planned_backfilled:
        db.commit()

    request_scope_lines = list(db.scalars(select(CommercialRequestLine).where(
        CommercialRequestLine.status == "ACTIVE"
    ).order_by(CommercialRequestLine.commercial_case_id, CommercialRequestLine.line_number)).all())
    line_ids = [row.id for row in request_scope_lines]
    line_counts = {}
    if line_ids:
        for line_id, count in db.execute(select(SampleRequest.commercial_request_line_id, func.count(SampleRequest.id)).where(
            SampleRequest.commercial_request_line_id.in_(line_ids)
        ).group_by(SampleRequest.commercial_request_line_id)).all():
            line_counts[int(line_id)] = int(count)
    request_scope_options = []
    for line in request_scope_lines:
        case = db.get(CommercialCase, line.commercial_case_id)
        if not case or not case.purchase_order_id or not case.quotation_id or case.site_id != site.id or stage_index(case.current_stage) < stage_index("COMPLETE_HANDOVER"):
            continue
        registered = line_counts.get(line.id, 0)
        remaining = max(0, int(line.quantity or 0) - registered)
        try:
            tests = json.loads(line.requested_tests_json or "[]")
        except Exception:
            tests = []
        request_scope_options.append({
            "id": line.id, "case_id": case.id, "case_code": case.case_code, "client_id": case.client_id,
            "client_code": case.client.code, "client_name": case.client.name,
            "quotation_id": case.quotation_id, "quotation_number": case.quotation.number if case.quotation else "",
            "purchase_order_id": case.purchase_order_id, "purchase_order_number": case.purchase_order.number if case.purchase_order else "",
            "line_number": line.line_number, "quantity": line.quantity, "registered": registered, "remaining": remaining,
            "package": line.requested_package, "package_label": "Custom Tests" if line.requested_package == "CUSTOM" else line.requested_package,
            "method_family": line.method_family, "priority": line.priority, "tat": line.required_tat,
            "due_at": line.due_at.isoformat(timespec="minutes") if line.due_at else "", "tests": tests,
            "expected_arrival_at": case.expected_arrival_at.isoformat(timespec="minutes") if case.expected_arrival_at else "",
            "sample_delivery_mode": case.sample_delivery_mode or "TBD", "sample_delivery_notes": case.sample_delivery_notes or "",
            "expected_serials": request_line_expected_serials(line),
        })
    asset_points = {str(a.id): _asset_sampling_points(a) for a in assets}
    intake_note_options = _clean_saved_options(db.scalars(
        select(SampleRequest.field_notes).where(SampleRequest.site_id == site.id, SampleRequest.field_notes != "").order_by(SampleRequest.created_at.desc())
    ).all())
    condition_rows = db.scalars(
        select(CustodyEvent.note).join(SampleRequest, CustodyEvent.sample_request_id == SampleRequest.id)
        .where(SampleRequest.site_id == site.id, CustodyEvent.event_type == "PHYSICAL_RECEIPT")
        .order_by(CustodyEvent.event_at.desc())
    ).all()
    condition_note_options = ["Container received intact, quantity verified, no visible leakage or damage.", "Container received intact and label verified.", "Received with minor external staining; no leakage observed."]
    for raw in condition_rows:
        text = str(raw or "").strip()
        if text.lower().startswith("seal:") and ". " in text:
            text = text.split(". ", 1)[1]
        condition_note_options.append(text)
    condition_note_options = _clean_saved_options(condition_note_options)
    batch_note_options = _clean_saved_options(db.scalars(
        select(CustodyEvent.note).join(SampleRequest, CustodyEvent.sample_request_id == SampleRequest.id)
        .where(SampleRequest.site_id == site.id, CustodyEvent.event_type == "BATCHED_AND_DISTRIBUTED")
        .order_by(CustodyEvent.event_at.desc())
    ).all())
    planned_samples = list(db.scalars(
        select(PlannedSample).where(
            PlannedSample.site_id == site.id,
            PlannedSample.status.in_(["EXPECTED", "ASSIGNED", "IN_TRANSIT"]),
            PlannedSample.sample_request_id.is_(None),
        ).order_by(PlannedSample.expected_arrival_at, PlannedSample.created_at, PlannedSample.id)
    ).all())
    selected_planned = None
    planned_param = (request.query_params.get("planned_id") or "").strip()
    if view == "incoming" and planned_param.isdigit():
        selected_planned = db.get(PlannedSample, int(planned_param))
        if not selected_planned or selected_planned.site_id != site.id or selected_planned.sample_request_id:
            selected_planned = None
    selected_intake_prefill = {}
    scope_line_param = (request.query_params.get("scope_line_id") or "").strip()
    if view == "incoming" and scope_line_param.isdigit():
        selected_option = next((row for row in request_scope_options if row["id"] == int(scope_line_param)), None)
        if selected_option:
            attachment, parsed = case_data_form_payload(db, selected_option["case_id"])
            serials = list(selected_option.get("expected_serials") or [])
            sample_rows = [parsed.get("samples", {}).get(str(serial).upper(), {}) for serial in serials]
            points = [str(row.get("sampling_point") or "").strip() for row in sample_rows if row]
            dates = [str(row.get("sample_date_time") or "").strip() for row in sample_rows if row]
            selected_intake_prefill = {
                "scope_line_id": selected_option["id"],
                "serials": serials,
                "sampling_point": points[0] if points and len(set(points)) == 1 else "",
                "sample_date_time": dates[0] if dates and len(set(dates)) == 1 else "",
                "data_form_name": attachment.original_name if attachment else "",
                "data_form_id": attachment.id if attachment else None,
                "parsed_samples": sample_rows,
            }
    if selected_planned:
        case = selected_planned.case
        attachment, parsed = case_data_form_payload(db, case.id)
        serial = selected_planned.expected_serial_number
        metadata = parsed.get("samples", {}).get(serial.upper(), {}) if serial else {}
        selected_intake_prefill = {
            "planned_sample_id": selected_planned.id,
            "scope_line_id": selected_planned.commercial_request_line_id,
            "serials": [serial] if serial else [],
            "sampling_point": str(metadata.get("sampling_point") or selected_planned.sampling_point or "").strip(),
            "sample_date_time": str(metadata.get("sample_date_time") or "").strip(),
            "data_form_name": attachment.original_name if attachment else "",
            "data_form_id": attachment.id if attachment else None,
            "parsed_samples": [metadata] if metadata else [],
            "barcode": selected_planned.barcode_value,
            "request_number": selected_planned.request_number,
            "case_id": case.id,
            "client_id": case.client_id,
            "quotation_id": case.quotation_id,
            "purchase_order_id": case.purchase_order_id,
        }

    released_assignments = []
    if view == "released":
        _, ops_payload = get_operations_state(db, site)
        released_ids = {sample.id for sample in samples}
        for batch in ops_payload.get("batches", []):
            if not released_ids.intersection(set(batch.get("platform_sample_ids") or [])):
                continue
            assignments = []
            for workstation in sorted(_batch_workstations(batch)):
                row = _current_test_assignment(ops_payload, str(batch.get("id") or ""), workstation)
                assignments.append({"workstation": workstation, "primary": row.get("primary_name", "") if row else "Unassigned", "source": row.get("source", "") if row else ""})
            released_assignments.append({"batch_id": batch.get("id"), "samples": batch.get("samples", []), "assignments": assignments})
    return templates.TemplateResponse(
        "intake_queue.html",
        {
            "request": request, "user": user, "samples": samples, "q": q, "view": view,
            "clients": clients, "quotes": quotes, "pos": pos, "assets": assets,
            "package_names": [row["name"] for row in packages], "packages": packages, "batch_groups": batch_groups,
            "po_scope": po_scope, "request_scope_options": request_scope_options, "asset_points": asset_points, "intake_note_options": intake_note_options,
            "condition_note_options": condition_note_options, "batch_note_options": batch_note_options, "released_assignments": released_assignments,
            "selected_intake_prefill": selected_intake_prefill, "planned_samples": planned_samples, "selected_planned": selected_planned,
        },
    )


@router.post("/match-barcode")
def match_expected_barcode(request: Request, barcode: str = Form(...), db: Session = Depends(get_db)):
    user = require_user(request, db, WRITE_ALLOWED)
    site = _site_for_user(db, user)
    value = (barcode or "").strip()
    if not value:
        return RedirectResponse("/intake?view=incoming&error=Scan+or+enter+an+expected+barcode", status_code=303)
    planned = db.scalar(select(PlannedSample).where(PlannedSample.site_id == site.id, PlannedSample.barcode_value == value))
    if not planned:
        return RedirectResponse("/intake?view=incoming&error=Barcode+does+not+match+an+expected+sample", status_code=303)
    if planned.sample_request_id:
        return RedirectResponse(f"/intake/{planned.sample_request_id}?barcode_matched=1", status_code=303)
    return RedirectResponse(f"/intake?view=incoming&planned_id={planned.id}", status_code=303)


@router.post("/direct")
def create_direct_client_intake(
    request: Request,
    client_id: int = Form(...),
    asset_id: str = Form(""),
    serial_numbers: str = Form(""),
    quotation_id: str = Form(""),
    purchase_order_id: str = Form(""),
    commercial_request_line_id: str = Form(""),
    planned_sample_id: str = Form(""),
    seal_status: str = Form("Intact"),
    condition_note: str = Form(""),
    requested_package: str = Form("Routine Test"),
    sampling_point: str = Form(""),
    sample_date_time: str = Form(""),
    sample_count: int = Form(1),
    container_count: int = Form(1),
    client_sample_reference: str = Form(""),
    notes: str = Form(""),
    priority: str = Form("NORMAL"),
    required_tat: str = Form(""),
    due_at: str = Form(""),
    submission_document: UploadFile | None = File(None),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, WRITE_ALLOWED)
    site = _site_for_user(db, user)
    assert_site_period_open(db, site.id)
    client = db.get(Client, client_id)
    if not client or not client.active:
        raise ValueError("Active client is required")
    planned_id = _optional_int(planned_sample_id, "Expected sample")
    planned = db.get(PlannedSample, planned_id) if planned_id else None
    if planned_id and not planned:
        raise ValueError("Expected sample identity was not found")
    if planned:
        if planned.site_id != site.id or planned.client_id != client.id:
            raise ValueError("Expected barcode belongs to a different site/client")
        if planned.sample_request_id or planned.status in {"MATERIALIZED", "CANCELLED", "VOID"}:
            raise ValueError("Expected sample identity has already been consumed or closed")

    serials = [row.strip()[:120] for row in serial_numbers.replace(",", "\n").replace(";", "\n").splitlines() if row.strip()]
    serials_provided = bool(serials)
    legacy_asset = db.get(Asset, _optional_int(asset_id, "Asset")) if asset_id.strip() else None
    if planned and not serials_provided and planned.expected_serial_number:
        serials = [planned.expected_serial_number]
        serials_provided = True
    if not serials_provided and legacy_asset and legacy_asset.active and legacy_asset.client_id == client.id:
        serials = [legacy_asset.serial_number for _ in range(sample_count)]
        serials_provided = True
    if not serials_provided:
        raise ValueError("Enter the transformer serial number shown on the matching Data Form / sample")

    if planned:
        commercial_case = planned.case
        quote_id = commercial_case.quotation_id
        po_id = commercial_case.purchase_order_id
        request_line_id = planned.commercial_request_line_id
        if not quote_id or not po_id:
            raise ValueError("Expected sample is missing the approved Quotation / PO handover")
    else:
        quote_id = _optional_int(quotation_id, "Quotation")
        po_id = _optional_int(purchase_order_id, "Purchase order")
        request_line_id = _optional_int(commercial_request_line_id, "Client Request Scope")
        if not quote_id or not po_id:
            raise ValueError("Client-originated intake requires the approved quotation and purchase order from the commercial handover")
        commercial_case = resolve_handover_case(db, site_id=site.id, client_id=client.id, quotation_id=quote_id, purchase_order_id=po_id)
    quote = db.get(Quotation, quote_id) if quote_id else None
    po = db.get(PurchaseOrder, po_id) if po_id else None
    if not quote or quote.client_id != client.id or quote.status not in {"ACTIVE", "CLIENT_ACCEPTED"}:
        raise ValueError("Quotation is not active/accepted for the selected client")
    if not po or po.client_id != client.id or po.status != "ACTIVE":
        raise ValueError("Purchase order is not active for the selected client")
    if po.quotation_id and po.quotation_id != quote.id:
        raise ValueError("Purchase order is linked to a different quotation")
    require_complete_handover(commercial_case)
    request_line = db.get(CommercialRequestLine, request_line_id) if request_line_id else None
    strict_scope = bool(request_line)
    if strict_scope and (not commercial_case or request_line.commercial_case_id != commercial_case.id or request_line.status != "ACTIVE"):
        raise ValueError("Selected Client Request Scope does not belong to this Quotation / PO")
    if planned and (not request_line or planned.commercial_request_line_id != request_line.id):
        raise ValueError("Expected barcode does not belong to the selected request scope")
    if not strict_scope and not (legacy_asset and legacy_asset.active and legacy_asset.client_id == client.id):
        raise ValueError("Select the approved Client Request Scope linked to this Quotation / PO")

    sample_count = 1 if planned else (len(serials) if strict_scope or serial_numbers.strip() else sample_count)
    if sample_count < 1 or sample_count > 100:
        raise ValueError("Number of samples received must be between 1 and 100")
    if planned and len(serials) != 1:
        raise ValueError("One scanned expected barcode can be matched to one physical sample at a time")

    if strict_scope:
        existing_count = db.scalar(select(func.count()).select_from(SampleRequest).where(SampleRequest.commercial_request_line_id == request_line.id)) or 0
        remaining = max(0, int(request_line.quantity or 0) - int(existing_count))
        if not planned and sample_count > remaining:
            raise ValueError(f"Requested scope has only {remaining} sample(s) remaining")
        expected_serials = {value.upper() for value in request_line_expected_serials(request_line)}
        if planned and planned.expected_serial_number and serials[0].upper() != planned.expected_serial_number.upper():
            raise ValueError("Scanned barcode and transformer serial do not match the pre-generated Data Form")
        if expected_serials:
            unexpected = [serial for serial in serials if serial.upper() not in expected_serials]
            if unexpected:
                raise ValueError(f"Serial {unexpected[0]} is not listed in the selected Client Request Scope")
        requested_package = request_line.requested_package
        priority = request_line.priority
        required_tat = request_line.required_tat
        due_at = request_line.due_at.isoformat(timespec="minutes") if request_line.due_at else ""
        requested_method_family = request_line.method_family or "DEFAULT"
        requested_tests_json = request_line.requested_tests_json or "[]"
    else:
        requested_method_family = "DEFAULT"
        requested_tests_json = "[]"
    active_packages = {row["name"] for row in package_catalog(db, site.id)}
    if requested_package != "CUSTOM" and requested_package not in active_packages:
        raise ValueError("Requested test package is not active for this site")
    if requested_package == "CUSTOM":
        try:
            if not json.loads(requested_tests_json or "[]"):
                raise ValueError("Custom Client Request Scope has no requested tests")
        except json.JSONDecodeError as exc:
            raise ValueError("Custom Client Request Scope tests are invalid") from exc
    if container_count < 1 or container_count > 100:
        raise ValueError("Container count must be between 1 and 100")

    _, parsed_data_form = case_data_form_payload(db, commercial_case.id)
    parsed_samples = parsed_data_form.get("samples", {})
    matched_assets: list[Asset] = []
    sample_metadata: list[dict] = []
    if strict_scope:
        for serial in serials:
            matches = list(db.scalars(select(Asset).where(Asset.active.is_(True), Asset.client_id == client.id, func.upper(Asset.serial_number) == serial.upper())).all())
            if len(matches) > 1:
                raise ValueError(f"Transformer serial {serial} is duplicated in the controlled Asset Master; resolve the duplicate before intake")
            metadata = parsed_samples.get(serial.upper(), {})
            if matches:
                asset = matches[0]
            else:
                # A serial explicitly approved in the Client Request may enter Asset Master
                # at intake with full audit linkage instead of stopping the case.
                asset = _create_intake_asset(db, client=client, serial=serial, case=commercial_case, metadata=metadata, user=user, request=request)
            matched_assets.append(asset)
            sample_metadata.append(metadata)
    else:
        matched_assets = [legacy_asset for _ in range(sample_count)]
        sample_metadata = [{} for _ in range(sample_count)]

    sampling_point = (sampling_point or "").strip()[:100]
    extracted_points = [str(meta.get("sampling_point") or "").strip()[:100] for meta in sample_metadata]
    nonempty_points = [point for point in extracted_points if point]
    if not sampling_point and nonempty_points and len(set(nonempty_points)) == 1:
        sampling_point = nonempty_points[0]
    # A linked Data Form may legitimately carry a different sampling point per physical sample.
    # Do not force Data Entry to invent one shared value just to pass intake.
    per_sample_points_complete = bool(sample_metadata) and len(sample_metadata) == sample_count and all(extracted_points)
    if not sampling_point and not per_sample_points_complete:
        raise ValueError("Sampling point is required for every sample and was not found in the linked Client Data Form")
    if sampling_point and sampling_point.lower() in {"client delivered", "client-originated", "client originated", "direct delivery"}:
        raise ValueError("Client Delivered is a sample origin, not a sampling point")

    client_sample_reference = (client_sample_reference or "").strip()[:100]
    notes = (notes or "").strip()[:4000]
    clean_seal = (seal_status or "Intact").strip().upper()
    if clean_seal not in {"INTACT", "BROKEN", "MISSING", "NOT APPLICABLE"}:
        raise ValueError("Unsupported seal status")
    condition_note = (condition_note or "").strip()[:1000]
    try:
        default_sample_dt = datetime.fromisoformat(sample_date_time) if sample_date_time else None
    except ValueError:
        raise ValueError("Sample date/time is invalid")
    document = _safe_direct_document(submission_document)
    samples_created: list[SampleRequest] = []
    artifact_paths: list[Path] = []
    written: Path | None = None
    try:
        if document:
            raw, ext, original_name = document
            written = UPLOAD_DIR / f"direct_intake_{site.code}_{datetime.utcnow().timestamp():.0f}{ext}"
            written.write_bytes(raw)
        for index in range(sample_count):
            asset = matched_assets[index]
            metadata = sample_metadata[index] if index < len(sample_metadata) else {}
            if planned:
                request_number, barcode_value, public_token = planned.request_number, planned.barcode_value, planned.public_token
            else:
                request_number, barcode_value, public_token = next_request_identifiers(db, site)
            ref = client_sample_reference
            if sample_count > 1 and ref:
                ref = f"{ref}-{index + 1:02d}"[:100]
            extracted_dt = None
            raw_dt = str(metadata.get("sample_date_time") or "").strip()
            if raw_dt:
                try:
                    extracted_dt = datetime.fromisoformat(raw_dt)
                except ValueError:
                    extracted_dt = None
            row_point = str(metadata.get("sampling_point") or sampling_point).strip()[:100] or sampling_point
            if not row_point:
                raise ValueError(f"Sampling point is missing for transformer serial {asset.serial_number}")
            if row_point.lower() in {"client delivered", "client-originated", "client originated", "direct delivery"}:
                raise ValueError("Client Delivered is a sample origin, not a sampling point")
            _remember_sampling_point(asset, row_point)
            row_notes = notes
            sample_man = str(metadata.get("sample_man") or "").strip()
            if sample_man and sample_man.lower() not in row_notes.lower():
                row_notes = (f"{row_notes} | " if row_notes else "") + f"Client sampler: {sample_man}"
            sample = SampleRequest(
                request_number=request_number, public_token=public_token, barcode_value=barcode_value,
                status=SampleStatus.SUBMITTED.value, site_id=site.id, client_id=client.id,
                quotation_id=quote.id if quote else None, purchase_order_id=po.id if po else None,
                commercial_case_id=commercial_case.id if commercial_case else None,
                commercial_request_line_id=request_line.id if request_line else None, asset_id=asset.id,
                sampler_id=None, sampling_assignment_id=None, submission_channel="CLIENT_DELIVERED",
                sample_date_time=default_sample_dt or extracted_dt or datetime.utcnow(), sampling_point=row_point, requested_package=requested_package,
                requested_method_family=requested_method_family, requested_tests_json=requested_tests_json,
                sample_origin="Client-Originated / Direct Delivery", priority="NORMAL", required_tat="", due_at=None,
                equipment_status=str(metadata.get("equipment_status") or "")[:80], sampling_reason=str(metadata.get("sampling_reason") or "")[:180],
                oil_temperature_c=metadata.get("oil_temperature_c"), ambient_temperature_c=metadata.get("ambient_temperature_c"),
                ambient_humidity_pct=metadata.get("ambient_humidity_pct"),
                client_sample_reference=ref, field_notes=row_notes[:4000], container_count=container_count, submitted_at=datetime.utcnow(),
            )
            _apply_priority_tat(sample, priority, required_tat, due_at)
            db.add(sample); db.flush()
            if planned:
                claim_planned_identity(planned, sample)
            if written:
                db.add(SamplePhoto(sample_request_id=sample.id, kind="CLIENT_SUBMISSION_DOCUMENT", original_name=original_name, stored_path=str(written)))
            if commercial_case:
                link_sample(db, commercial_case, sample, user)
            add_event(db, sample, user, "EXPECTED_SAMPLE_MATCHED" if planned else "DIRECT_CLIENT_INTAKE_CREATED", sample.status,
                      f"Expected barcode matched to physical client-delivered sample {barcode_value}" if planned else f"Client-delivered sample registered from direct submission ({index + 1}/{sample_count})")
            if planned:
                # Barcode matching happens at the physical receiving desk. Once Data Entry
                # confirms the expected identity/serial, keep the same pre-generated Sample ID
                # and complete acceptance + TSCO registration + physical receipt in one
                # controlled action so the sample appears immediately in Smart Batch Cards.
                sample.status = SampleStatus.ACCEPTED.value
                sample.accepted_at = datetime.utcnow()
                sample.data_entry_note = notes or "Expected barcode and Data Form matched at physical receipt"
                add_event(db, sample, user, "DATA_ACCEPTANCE", sample.status, sample.data_entry_note)
                register_in_tsco(db, sample, user)
                sample.status = SampleStatus.RECEIVED.value
                sample.received_at = datetime.utcnow()
                receipt_note = f"Seal: {clean_seal}. {condition_note or 'Barcode/Data Form identity matched; container accepted.'}"
                add_event(db, sample, user, "PHYSICAL_RECEIPT", sample.status, receipt_note)
                sync_case_from_sample(db, sample, user, note="Expected barcode matched and physical sample received by Sample Intake & Receiving")
            if not planned:
                artifacts = generate_assets(barcode_value, request_number, client.name, asset.asset_code, BARCODE_DIR)
                artifact_paths.extend(Path(path) for path in artifacts.values())
            add_audit(
                db, actor=user, request=request, action="DIRECT_CLIENT_SAMPLE_CREATED", entity_type="SampleRequest", entity_id=sample.id,
                summary=f"Created direct client intake {sample.request_number}",
                details={"client": client.code, "asset": asset.asset_code, "document": bool(document), "sample_count": sample_count, "sequence": index + 1, "request_line_id": request_line.id if request_line else None, "planned_sample_id": planned.id if planned else None, "pre_generated_barcode": bool(planned), "physical_receipt_completed": bool(planned), "seal_status": clean_seal if planned else None},
            )
            samples_created.append(sample)
        db.commit()
    except Exception:
        db.rollback()
        if written:
            written.unlink(missing_ok=True)
        for path in artifact_paths:
            path.unlink(missing_ok=True)
        raise
    if len(samples_created) == 1:
        if planned:
            return RedirectResponse("/intake?view=distribution&matched=1", status_code=303)
        return RedirectResponse(f"/intake/{samples_created[0].id}", status_code=303)
    return RedirectResponse(f"/intake?view=incoming&created={len(samples_created)}", status_code=303)



@router.post("/bulk-decision")
def bulk_decision(
    request: Request, sample_ids: list[int] = Form(...), note: str = Form(""), db: Session = Depends(get_db),
):
    user = require_user(request, db, WRITE_ALLOWED)
    ids = list(dict.fromkeys(int(x) for x in sample_ids))
    if not ids:
        raise ValueError("Select at least one sample")
    samples = list(db.scalars(select(SampleRequest).where(SampleRequest.id.in_(ids))).all())
    if len(samples) != len(ids):
        raise ValueError("One or more selected samples no longer exist")
    for sample in samples:
        if not can_access_site(user, sample.site_id):
            raise PermissionError("Selected sample is outside the authenticated site scope")
        assert_sample_period_open(db, sample)
        if sample.status not in {SampleStatus.SUBMITTED.value, SampleStatus.RETURNED.value}:
            raise ValueError(f"{sample.request_number} is not waiting for Data Review")
        sample.status = SampleStatus.ACCEPTED.value
        sample.accepted_at = datetime.utcnow()
        sample.data_entry_note = note.strip()
        add_event(db, sample, user, "DATA_ACCEPTANCE", sample.status, note.strip() or "Bulk Data Review accepted")
        register_in_tsco(db, sample, user)
        add_audit(db, actor=user, request=request, action="INTAKE_BULK_ACCEPT_REGISTER", entity_type="SampleRequest", entity_id=sample.id, summary=f"{sample.request_number}: accepted and registered in bulk", details={"sample_ids": ids, "note": note.strip()})
    db.commit()
    return RedirectResponse("/intake?view=receiving", status_code=303)


@router.post("/bulk-receive")
def bulk_receive(
    request: Request, sample_ids: list[int] = Form(...), seal_status: str = Form("Intact"), condition_note: str = Form(""), db: Session = Depends(get_db),
):
    user = require_user(request, db, WRITE_ALLOWED)
    ids = list(dict.fromkeys(int(x) for x in sample_ids))
    if not ids:
        raise ValueError("Select at least one sample")
    clean_seal = seal_status.strip().upper()
    if clean_seal not in {"INTACT", "BROKEN", "MISSING", "NOT APPLICABLE"}:
        raise ValueError("Unsupported seal status")
    samples = list(db.scalars(select(SampleRequest).where(SampleRequest.id.in_(ids))).all())
    if len(samples) != len(ids):
        raise ValueError("One or more selected samples no longer exist")
    for sample in samples:
        if not can_access_site(user, sample.site_id):
            raise PermissionError("Selected sample is outside the authenticated site scope")
        assert_sample_period_open(db, sample)
        if sample.status != SampleStatus.AWAITING_RECEIPT.value:
            raise ValueError(f"{sample.request_number} is not ready for physical receipt")
        sample.status = SampleStatus.RECEIVED.value
        sample.received_at = datetime.utcnow()
        add_event(db, sample, user, "PHYSICAL_RECEIPT", sample.status, f"Seal: {clean_seal}. {condition_note}".strip())
        sync_case_from_sample(db, sample, user, note="Physical sample received by Sample Intake & Receiving")
        add_audit(db, actor=user, request=request, action="PHYSICAL_SAMPLE_RECEIVED_BULK", entity_type="SampleRequest", entity_id=sample.id, summary=f"Received {sample.request_number} in bulk", details={"sample_ids": ids, "seal_status": clean_seal, "condition_note": condition_note})
    db.commit()
    return RedirectResponse("/intake?view=distribution", status_code=303)


@router.post("/{sample_id}/match-receive")
def match_and_receive_expected_sample(
    sample_id: int, request: Request, seal_status: str = Form("Intact"), condition_note: str = Form(""),
    db: Session = Depends(get_db),
):
    """Confirm a pre-generated barcode against a field/pickup sample that already exists.

    The Sampleman may materialize the planned identity in the field. When the same physical
    bottle/carton reaches Data Entry, scanning that barcode must not create another sample.
    This action completes Data Review/TSCO registration as needed and records physical receipt
    against the same stable Sample ID so it can enter Smart Batch Cards immediately.
    """
    user = require_user(request, db, WRITE_ALLOWED)
    sample = db.get(SampleRequest, sample_id)
    if not sample or not can_access_site(user, sample.site_id):
        return RedirectResponse("/intake?view=incoming", status_code=303)
    planned = db.scalar(select(PlannedSample).where(PlannedSample.sample_request_id == sample.id))
    if not planned or planned.barcode_value != sample.barcode_value:
        raise ValueError("This sample is not linked to a pre-generated expected barcode")
    assert_sample_period_open(db, sample)
    clean_seal = (seal_status or "Intact").strip().upper()
    if clean_seal not in {"INTACT", "BROKEN", "MISSING", "NOT APPLICABLE"}:
        raise ValueError("Unsupported seal status")
    clean_note = (condition_note or "").strip()[:1000]
    if sample.status in {SampleStatus.SUBMITTED.value, SampleStatus.RETURNED.value}:
        sample.status = SampleStatus.ACCEPTED.value
        sample.accepted_at = datetime.utcnow()
        sample.data_entry_note = "Pre-generated barcode / Data Form matched at physical receipt"
        add_event(db, sample, user, "DATA_ACCEPTANCE", sample.status, sample.data_entry_note)
        register_in_tsco(db, sample, user)
    elif sample.status == SampleStatus.ACCEPTED.value:
        register_in_tsco(db, sample, user)
    elif sample.status == SampleStatus.RECEIVED.value:
        return RedirectResponse("/intake?view=distribution&matched=1", status_code=303)
    elif sample.status != SampleStatus.AWAITING_RECEIPT.value:
        raise ValueError(f"Barcode receipt confirmation is not permitted from status {sample.status}")
    sample.status = SampleStatus.RECEIVED.value
    sample.received_at = datetime.utcnow()
    receipt_note = f"Seal: {clean_seal}. {clean_note or 'Pre-generated barcode/Data Form matched; physical custody accepted.'}"
    add_event(db, sample, user, "PHYSICAL_RECEIPT", sample.status, receipt_note)
    sync_case_from_sample(db, sample, user, note="Pre-generated barcode matched and physical sample received by Sample Intake & Receiving")
    add_audit(
        db, actor=user, request=request, action="EXPECTED_BARCODE_MATCH_AND_RECEIVE", entity_type="SampleRequest", entity_id=sample.id,
        summary=f"Matched and received {sample.request_number} using its pre-generated barcode",
        details={"planned_sample_id": planned.id, "barcode": sample.barcode_value, "seal_status": clean_seal, "condition_note": clean_note},
    )
    db.commit()
    return RedirectResponse("/intake?view=distribution&matched=1", status_code=303)


@router.post("/{sample_id}/receive")
def receive_sample(
    sample_id: int, request: Request, seal_status: str = Form("Intact"), condition_note: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, WRITE_ALLOWED)
    sample = db.get(SampleRequest, sample_id)
    if not sample or not can_access_site(user, sample.site_id):
        return RedirectResponse("/intake?view=receiving", status_code=303)
    assert_sample_period_open(db, sample)
    clean_seal = seal_status.strip().upper()
    if clean_seal not in {"INTACT", "BROKEN", "MISSING", "NOT APPLICABLE"}:
        raise ValueError("Unsupported seal status")
    if sample.status == SampleStatus.RECEIVED.value:
        return RedirectResponse("/intake?view=receiving&error=Sample+is+already+recorded+as+received", status_code=303)
    if sample.status != SampleStatus.AWAITING_RECEIPT.value:
        return RedirectResponse("/intake?view=receiving&error=Sample+status+does+not+permit+physical+receipt", status_code=303)
    sample.status = SampleStatus.RECEIVED.value
    sample.received_at = datetime.utcnow()
    add_event(db, sample, user, "PHYSICAL_RECEIPT", sample.status, f"Seal: {clean_seal}. {condition_note}".strip())
    sync_case_from_sample(db, sample, user, note="Physical sample received by Sample Intake & Receiving")
    add_audit(db, actor=user, request=request, action="PHYSICAL_SAMPLE_RECEIVED", entity_type="SampleRequest", entity_id=sample.id, summary=f"Received {sample.request_number}", details={"seal_status": clean_seal, "condition_note": condition_note})
    db.commit()
    return RedirectResponse("/intake?view=distribution", status_code=303)


@router.get("/asset-match/lookup")
def asset_match_lookup(request: Request, serial_number: str, client_id: int | None = None, db: Session = Depends(get_db)):
    user = require_user(request, db, READ_ALLOWED)
    clean = (serial_number or "").strip()[:120]
    if not clean:
        return JSONResponse({"matched": False, "reason": "Serial number is required"})
    stmt = select(Asset).where(Asset.active.is_(True), func.upper(Asset.serial_number) == clean.upper())
    if client_id:
        stmt = stmt.where(Asset.client_id == client_id)
    rows = list(db.scalars(stmt).all())
    if len(rows) != 1:
        return JSONResponse({"matched": False, "reason": "Not found" if not rows else "Ambiguous serial number"})
    asset = rows[0]
    return JSONResponse({"matched": True, "asset_id": asset.id, "serial_number": asset.serial_number, "asset_code": asset.asset_code, "client_id": asset.client_id, "client": asset.client.name, "station": asset.station_name, "location": asset.asset_location_label})


@router.get("/assets/{asset_id}")
def asset_detail(asset_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, READ_ALLOWED)
    asset = db.get(Asset, asset_id)
    if not asset or not asset.active:
        return RedirectResponse("/intake?view=assets", status_code=303)
    samples = list(db.scalars(select(SampleRequest).where(SampleRequest.asset_id == asset.id).order_by(SampleRequest.sample_date_time.desc()).limit(100)).all())
    return templates.TemplateResponse("intake_asset.html", {"request": request, "user": user, "asset": asset, "samples": samples})


@router.get("/{sample_id}")
def review(sample_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, READ_ALLOWED)
    sample = db.get(SampleRequest, sample_id)
    if not sample or not can_access_site(user, sample.site_id):
        return RedirectResponse("/intake", status_code=303)
    commercial_attachments = []
    if sample.commercial_case_id:
        commercial_attachments = list(db.scalars(
            select(CommercialAttachment)
            .where(CommercialAttachment.commercial_case_id == sample.commercial_case_id)
            .order_by(CommercialAttachment.created_at.desc())
        ).all())
    review_note_options = _clean_saved_options(db.scalars(
        select(SampleRequest.data_entry_note).where(SampleRequest.site_id == sample.site_id, SampleRequest.data_entry_note != "").order_by(SampleRequest.created_at.desc())
    ).all())
    condition_rows = db.scalars(
        select(CustodyEvent.note).join(SampleRequest, CustodyEvent.sample_request_id == SampleRequest.id)
        .where(SampleRequest.site_id == sample.site_id, CustodyEvent.event_type == "PHYSICAL_RECEIPT")
        .order_by(CustodyEvent.event_at.desc())
    ).all()
    condition_note_options = ["Container received intact, quantity verified, no visible leakage or damage.", "Container received intact and label verified."]
    for raw in condition_rows:
        text = str(raw or "").strip()
        if text.lower().startswith("seal:") and ". " in text:
            text = text.split(". ", 1)[1]
        condition_note_options.append(text)
    condition_note_options = _clean_saved_options(condition_note_options)
    return templates.TemplateResponse(
        "intake_review.html",
        {"request": request, "user": user, "sample": sample, "commercial_attachments": commercial_attachments,
         "review_note_options": review_note_options, "condition_note_options": condition_note_options},
    )


@router.post("/{sample_id}/amend-intake-data")
def amend_intake_data(
    sample_id: int,
    request: Request,
    sampling_point: str = Form(""),
    sample_date_time: str = Form(""),
    oil_temperature_c: str = Form(""),
    ambient_temperature_c: str = Form(""),
    ambient_humidity_pct: str = Form(""),
    sampling_reason: str = Form(""),
    equipment_status: str = Form(""),
    client_sample_reference: str = Form(""),
    container_count: int = Form(1),
    amendment_reason: str = Form(...),
    db: Session = Depends(get_db),
):
    """Controlled correction of intake / Client Data Form metadata.

    Data Entry owns routine intake corrections. System Admin may use the same control only as an
    emergency override. Identity/commercial links and physical-receipt timestamps are intentionally
    excluded from this endpoint. Every change is audited and becomes authoritative for existing Lab
    Batches through the live intake metadata projection.
    """
    user = require_user(request, db, AMEND_ALLOWED)
    sample = db.get(SampleRequest, sample_id)
    if not sample or not can_access_site(user, sample.site_id):
        return RedirectResponse("/intake", status_code=303)
    assert_sample_period_open(db, sample)

    reason = (amendment_reason or "").strip()
    if len(reason) < 3:
        raise ValueError("A correction reason is required")
    if container_count < 1 or container_count > 100:
        raise ValueError("Containers must be between 1 and 100")

    new_values = {
        "sampling_point": (sampling_point or "").strip()[:100],
        "sample_date_time": _optional_datetime(sample_date_time, "Sampling date / time") or sample.sample_date_time,
        "oil_temperature_c": _optional_float(oil_temperature_c, "Transformer oil temperature", minimum=-50, maximum=200),
        "ambient_temperature_c": _optional_float(ambient_temperature_c, "Ambient temperature", minimum=-50, maximum=100),
        "ambient_humidity_pct": _optional_float(ambient_humidity_pct, "Ambient humidity", minimum=0, maximum=100),
        "sampling_reason": (sampling_reason or "").strip()[:180],
        "equipment_status": (equipment_status or "").strip()[:80],
        "client_sample_reference": (client_sample_reference or "").strip()[:100],
        "container_count": int(container_count),
    }
    # Sampling point and sampling date/time are operationally required and should not be erased by
    # an amendment form accidentally left blank. Other optional Client Data Form values may be
    # cleared deliberately when the source document is corrected.
    if not new_values["sampling_point"]:
        new_values["sampling_point"] = sample.sampling_point

    before = {}
    after = {}
    labels = {
        "sampling_point": "Sampling Point",
        "sample_date_time": "Sampling Date / Time",
        "oil_temperature_c": "Transformer Oil Temperature",
        "ambient_temperature_c": "Ambient Temperature",
        "ambient_humidity_pct": "Ambient Humidity",
        "sampling_reason": "Sampling Reason",
        "equipment_status": "Equipment Status",
        "client_sample_reference": "Client Sample Reference",
        "container_count": "Containers",
    }
    for field, value in new_values.items():
        current = getattr(sample, field)
        if current != value:
            before[field] = current.isoformat() if isinstance(current, datetime) else current
            after[field] = value.isoformat() if isinstance(value, datetime) else value
            setattr(sample, field, value)

    if not after:
        return RedirectResponse(f"/intake/{sample.id}?ok=No+intake+data+changes+were+needed", status_code=303)

    _remember_sampling_point(sample.asset, sample.sampling_point)
    changed_labels = ", ".join(labels.get(key, key) for key in after)
    actor_mode = "System Admin override" if user.role == Role.SYSTEM_ADMIN.value else "Data Entry controlled amendment"
    add_event(
        db, sample, user, "INTAKE_DATA_AMENDED", sample.status,
        f"{actor_mode}: {changed_labels}. Reason: {reason}",
    )
    add_audit(
        db, actor=user, request=request, action="INTAKE_DATA_AMENDED",
        entity_type="SampleRequest", entity_id=sample.id,
        summary=f"{sample.request_number}: amended controlled intake data",
        details={"reason": reason, "before": before, "after": after, "status": sample.status},
    )
    db.commit()
    return RedirectResponse(f"/intake/{sample.id}?ok=Controlled+intake+data+updated", status_code=303)


@router.post("/{sample_id}/upload-client-data-form")
def upload_updated_client_data_form(
    sample_id: int,
    request: Request,
    upload: UploadFile = File(...),
    note: str = Form(""),
    db: Session = Depends(get_db),
):
    """Attach a newer Client Data Form revision without deleting the previous evidence.

    The new file becomes the latest controlled source document. Missing fields are backfilled
    automatically; existing values are never silently overwritten and can be corrected through the
    controlled amendment form above.
    """
    user = require_user(request, db, AMEND_ALLOWED)
    sample = db.get(SampleRequest, sample_id)
    if not sample or not can_access_site(user, sample.site_id):
        return RedirectResponse("/intake", status_code=303)
    assert_sample_period_open(db, sample)
    if not sample.commercial_case_id:
        raise ValueError("This sample is not linked to a commercial case")
    payload = _safe_direct_document(upload)
    if not payload:
        raise ValueError("Select the updated Client Data Form")
    raw, ext, original_name = payload
    digest = hashlib.sha256(raw).hexdigest()
    folder = UPLOAD_DIR / "commercial"
    folder.mkdir(parents=True, exist_ok=True)
    stored = folder / f"case_{sample.commercial_case_id}_{digest[:20]}{ext}"
    if not stored.exists():
        stored.write_bytes(raw)
    content_type = "application/pdf" if ext == ".pdf" else {".jpg": "image/jpeg", ".png": "image/png", ".webp": "image/webp"}.get(ext, "application/octet-stream")
    row = CommercialAttachment(
        commercial_case_id=sample.commercial_case_id,
        document_type="CLIENT_DATA_FORM",
        original_name=original_name,
        stored_path=str(stored),
        content_type=content_type,
        sha256=digest,
        content_blob=raw,
        uploaded_by_id=user.id,
    )
    db.add(row)
    db.flush()
    changed = sync_missing_sample_metadata_from_case_data_form(db, sample.commercial_case_id)
    add_event(
        db, sample, user, "CLIENT_DATA_FORM_REVISION_ADDED", sample.status,
        f"New Client Data Form revision linked. {('Note: ' + note.strip()) if note.strip() else ''}".strip(),
    )
    add_audit(
        db, actor=user, request=request, action="INTAKE_CLIENT_DATA_FORM_REVISION_ADDED",
        entity_type="CommercialAttachment", entity_id=row.id,
        summary=f"{sample.request_number}: new Client Data Form revision {original_name}",
        details={"sample_id": sample.id, "case_id": sample.commercial_case_id, "sha256": digest, "missing_fields_backfilled": changed, "note": note.strip()},
    )
    db.commit()
    return RedirectResponse(f"/intake/{sample.id}?ok=New+Client+Data+Form+revision+linked", status_code=303)


@router.post("/{sample_id}/sync-client-data-form")
def sync_client_data_form_metadata(sample_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, WRITE_ALLOWED)
    sample = db.get(SampleRequest, sample_id)
    if not sample or not can_access_site(user, sample.site_id):
        return RedirectResponse("/intake", status_code=303)
    if not sample.commercial_case_id:
        raise ValueError("This sample is not linked to a commercial case / Client Data Form")
    changed = sync_missing_sample_metadata_from_case_data_form(db, sample.commercial_case_id)
    sample = db.get(SampleRequest, sample_id)
    add_audit(
        db, actor=user, request=request, action="INTAKE_CLIENT_DATA_FORM_SYNC",
        entity_type="SampleRequest", entity_id=sample.id,
        summary=f"{sample.request_number}: synchronized missing intake metadata from linked Client Data Form",
        details={"commercial_case_id": sample.commercial_case_id, "rows_changed": changed},
    )
    db.commit()
    return RedirectResponse(f"/intake/{sample.id}", status_code=303)


@router.post("/batch-release")
def batch_release(
    request: Request,
    sample_ids: list[int] = Form(...),
    note: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, WRITE_ALLOWED)
    ids = list(dict.fromkeys(int(x) for x in sample_ids))
    if not ids:
        raise ValueError("Select at least one received sample")
    samples = list(db.scalars(select(SampleRequest).where(SampleRequest.id.in_(ids))).all())
    if len(samples) != len(ids):
        raise ValueError("One or more selected samples no longer exist")
    for sample in samples:
        if not can_access_site(user, sample.site_id):
            raise PermissionError("Selected sample is outside the authenticated site scope")
        assert_sample_period_open(db, sample)
        if sample.status != SampleStatus.RECEIVED.value:
            raise ValueError(f"{sample.request_number} is not ready for laboratory distribution")
        if not sample.received_at:
            raise ValueError(f"{sample.request_number} requires TSCO intake registration and physical receipt before release")

    batch_id = sync_samples_to_operations(db, samples, user, phase="READY_FOR_LAB")
    for sample in samples:
        sample.status = SampleStatus.READY_FOR_LAB.value
        add_event(db, sample, user, "BATCHED_AND_DISTRIBUTED", sample.status, note.strip() or f"Released in controlled Lab Batch {batch_id}")
        sync_case_from_sample(db, sample, user, note=f"Sample released to laboratory in {batch_id}")
        add_audit(
            db, actor=user, request=request, action="INTAKE_BATCH_RELEASE",
            entity_type="SampleRequest", entity_id=sample.id,
            summary=f"{sample.request_number}: released in {batch_id}",
            details={"batch_id": batch_id, "sample_ids": ids, "priority": sample.priority, "required_tat": sample.required_tat, "due_at": sample.due_at.isoformat() if sample.due_at else ""},
        )
    db.commit()
    return RedirectResponse("/intake?view=released", status_code=303)


@router.post("/{sample_id}/decision")
def decision(
    sample_id: int,
    request: Request,
    action: str = Form(...),
    note: str = Form(""),
    issue_type: str = Form(""),
    priority: str = Form(""),
    required_tat: str = Form(""),
    due_at: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, WRITE_ALLOWED)
    sample = db.get(SampleRequest, sample_id)
    if not sample or not can_access_site(user, sample.site_id):
        return RedirectResponse("/intake", status_code=303)
    assert_sample_period_open(db, sample)

    action = action.upper()
    reviewable = {SampleStatus.SUBMITTED.value, SampleStatus.RETURNED.value}
    if action in {"ACCEPT_AND_REGISTER", "ACCEPT", "RETURN", "REJECT"} and sample.status not in reviewable:
        raise ValueError(f"Intake action {action} is not permitted from status {sample.status}")
    if action in {"REGISTER_TSCO"} and sample.status != SampleStatus.ACCEPTED.value:
        raise ValueError(f"TSCO registration is not permitted from status {sample.status}")
    if action == "SAVE_OPERATIONAL" and sample.status not in {SampleStatus.ACCEPTED.value, SampleStatus.AWAITING_RECEIPT.value, SampleStatus.RECEIVED.value}:
        raise ValueError(f"Operational Priority/TAT cannot be edited from status {sample.status}")
    if action not in {"ACCEPT_AND_REGISTER", "ACCEPT", "RETURN", "REJECT", "REGISTER_TSCO", "SAVE_OPERATIONAL"}:
        raise ValueError("Unsupported intake action")
    if action in {"RETURN", "REJECT"} and not note.strip():
        raise ValueError("A reason is required when returning or rejecting a sample")
    clean_issue_type = issue_type.strip()
    if len(clean_issue_type) > 80:
        raise ValueError("Issue type must be 80 characters or fewer")

    if action in {"ACCEPT_AND_REGISTER", "ACCEPT", "REGISTER_TSCO", "SAVE_OPERATIONAL"}:
        _apply_priority_tat(sample, priority, required_tat, due_at)

    if action == "SAVE_OPERATIONAL":
        add_event(db, sample, user, "OPERATIONAL_PRIORITY_TAT_CONFIRMED", sample.status, note.strip() or "Priority / TAT confirmed by Data Entry")
    elif action == "ACCEPT_AND_REGISTER":
        sample.status = SampleStatus.ACCEPTED.value
        sample.accepted_at = datetime.utcnow()
        sample.data_entry_note = note.strip()
        add_event(db, sample, user, "DATA_ACCEPTANCE", sample.status, note.strip())
        register_in_tsco(db, sample, user)
    elif action == "ACCEPT":
        sample.status = SampleStatus.ACCEPTED.value
        sample.accepted_at = datetime.utcnow()
        sample.data_entry_note = note.strip()
        add_event(db, sample, user, "DATA_ACCEPTANCE", sample.status, note.strip())
    elif action == "RETURN":
        sample.status = SampleStatus.RETURNED.value
        sample.return_reason = note.strip()
        add_event(db, sample, user, "RETURN_FOR_CORRECTION", sample.status, note.strip())
        db.add(DataQualityIssue(
            sample_request_id=sample.id,
            issue_type=clean_issue_type or "FIELD_DATA_ERROR",
            severity="MEDIUM",
            description=note.strip() or "Returned for correction",
            reported_by_id=user.id,
        ))
    elif action == "REJECT":
        sample.status = SampleStatus.REJECTED.value
        sample.rejection_reason = note.strip()
        add_event(db, sample, user, "REJECTION", sample.status, note.strip())
        db.add(DataQualityIssue(
            sample_request_id=sample.id,
            issue_type=clean_issue_type or "SAMPLE_REJECTED",
            severity="HIGH",
            description=note.strip() or "Sample rejected",
            reported_by_id=user.id,
        ))
    elif action in {"REGISTER_TSCO"}:
        if sample.status == SampleStatus.AWAITING_RECEIPT.value:
            raise ValueError("This sample is already registered in TSCO")
        register_in_tsco(db, sample, user)

    add_audit(
        db,
        actor=user,
        request=request,
        action=f"INTAKE_{action}",
        entity_type="SampleRequest",
        entity_id=sample.id,
        summary=f"{sample.request_number}: {action}",
        details={"note": note, "issue_type": issue_type, "status": sample.status},
    )
    db.commit()
    return RedirectResponse(f"/intake/{sample.id}", status_code=303)
