from __future__ import annotations

import hashlib
import json
from datetime import datetime
from io import BytesIO
from pathlib import Path

from PIL import Image, UnidentifiedImageError
from fastapi import APIRouter, Depends, File, Form, Request, UploadFile, HTTPException
from fastapi.responses import FileResponse, RedirectResponse, Response
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import (Client, CommercialAttachment, CommercialCase, CommercialEvent, CommercialRequestLine, ControlledReport, Notification, OperationalProject,
    Quotation, ReportSubmission, Role, SampleRequest, SampleStatus, Site, User)
from ..security import require_user
from ..services.audit import add_audit
from ..services.capabilities import (
    can_create_commercial_case, can_manage_controlled_commercial_documents,
    can_submit_client_report,
)
from ..services.lab_operations import package_catalog
from ..services.commercial import (
    COMMERCIAL_STAGES, STAGE_KEYS, STAGE_LABELS, advance_case, effective_stage,
    next_stage, parse_expected_serials, request_line_expected_serials, role_can_transition, refresh_case_request_summary, request_scope_lines,
)
from ..storage import UPLOAD_DIR

router = APIRouter(prefix="/commercial", tags=["business communication flow"])
VIEW = {
    Role.SALES_MARKETING.value, Role.OPERATIONS_MANAGER.value,
    Role.CLIENT_COORDINATOR.value, Role.TECHNICAL_MANAGER.value,
    Role.MANAGEMENT.value, Role.DATA_ENTRY.value, Role.SYSTEM_ADMIN.value,
}
CREATE = {Role.SALES_MARKETING.value, Role.CLIENT_COORDINATOR.value}
ATTACHMENT_UPLOAD = {Role.CLIENT_COORDINATOR.value}
MAX_COMMERCIAL_ATTACHMENT_BYTES = 10_000_000
COMMERCIAL_DOCUMENT_TYPES = {"QUOTATION", "PURCHASE_ORDER", "INVOICE", "CLIENT_REQUEST", "CLIENT_DATA_FORM", "HANDOVER", "OTHER"}
CLIENT_DELIVERY_MODES = {"CLIENT_DELIVERY", "TSCO_PICKUP", "TSCO_ONSITE_SAMPLING", "TSCO_COLLECTION", "TBD"}

# UAT/demo-only commercial rates. They intentionally do not represent TSCO's controlled production price list.
DEMO_PRICE_MASTER = [
    {"test":"Appearance","method":"ASTM D1524","rate":30.00},
    {"test":"Color ASTM","method":"ASTM D1500","rate":40.00},
    {"test":"Density of Oil @RT","method":"ASTM D4052","rate":55.00},
    {"test":"Viscosity @ 40 °C","method":"ASTM D445","rate":80.00},
    {"test":"Flash Point (Open Cup)","method":"ASTM D92","rate":120.00},
    {"test":"Flash Point (Closed Cup)","method":"ASTM D93","rate":120.00},
    {"test":"Water Content KF @RT","method":"IEC 60814 / ASTM D1533","rate":320.00},
    {"test":"Breakdown Voltage @2.5mm- AVG","method":"IEC 60156","rate":320.00},
    {"test":"Breakdown Voltage @1mm- AVG","method":"ASTM D1816","rate":320.00},
    {"test":"Power Factor @25°C/60Hz","method":"ASTM D924","rate":350.00},
    {"test":"Power Factor @100°C/60Hz","method":"ASTM D924","rate":350.00},
    {"test":"Total Acid Number","method":"ASTM D664","rate":170.00},
    {"test":"Interfacial Tension (IFT)","method":"ASTM D971","rate":170.00},
    {"test":"Resistivity @       °C/60Hz","method":"ASTM D1169","rate":200.00},
    {"test":"Dissolved Gas Analysis (DGA)","method":"IEC 60567 / ASTM D3612","rate":650.00},
    {"test":"Total Furanic Compounds","method":"IEC 61198","rate":240.00},
    {"test":"Corrosive Sulfur","method":"ASTM D1275B","rate":280.00},
    {"test":"Dibenzyl Disulfide (DBDS)","method":"IEC 62697-1","rate":300.00},
    {"test":"Antioxidant (BHT)","method":"IEC 60666","rate":250.00},
    {"test":"Polychlorinated Biphenyls (PCBs)","method":"IEC 61619","rate":450.00},
]


def _norm_price_name(value: str) -> str:
    return "".join(ch for ch in str(value or "").lower() if ch.isalnum())


def _demo_rate_for(test_name: str) -> dict:
    key = _norm_price_name(test_name)
    aliases = {
        "dissolvedgasanalysis":"Dissolved Gas Analysis (DGA)",
        "dga":"Dissolved Gas Analysis (DGA)",
        "watercontent":"Water Content KF @RT",
        "breakdownvoltage":"Breakdown Voltage @2.5mm- AVG",
        "powerfactor":"Power Factor @25°C/60Hz",
        "tanacidity":"Total Acid Number",
        "acidity":"Total Acid Number",
        "ift":"Interfacial Tension (IFT)",
        "furan":"Total Furanic Compounds",
        "dbds":"Dibenzyl Disulfide (DBDS)",
    }
    target = aliases.get(key, test_name)
    tkey = _norm_price_name(target)
    for row in DEMO_PRICE_MASTER:
        if _norm_price_name(row["test"]) == tkey:
            return row
    return {"test":test_name, "method":"Controlled method", "rate":120.00}


def _demo_quote_preview(lines: list[CommercialRequestLine], packages: list[dict]) -> dict:
    package_map = {str(p.get("name") or ""): p for p in packages}
    method_lookup: dict[str,str] = {}
    for package in packages:
        for item in package.get("tests", []):
            if isinstance(item, dict) and item.get("test"):
                method_lookup.setdefault(_norm_price_name(item.get("test")), str(item.get("method") or ""))
    quote_rows=[]; subtotal=0.0
    for line in lines:
        tests=[]
        if line.requested_package == "CUSTOM":
            try: tests=[str(x) for x in json.loads(line.requested_tests_json or "[]") if str(x).strip()]
            except Exception: tests=[]
        else:
            package=package_map.get(str(line.requested_package), {})
            tests=[str(x.get("test") or "") for x in package.get("tests",[]) if isinstance(x,dict) and str(x.get("test") or "").strip()]
        multiplier = 2.0 if str(line.required_tat or "").upper()=="12H" else 1.5 if str(line.required_tat or "").upper()=="24H" else 1.0
        for test in tests:
            rate_row=_demo_rate_for(test)
            method=method_lookup.get(_norm_price_name(test)) or rate_row["method"]
            unit=float(rate_row["rate"]); qty=int(line.quantity or 1); total=unit*qty*multiplier
            subtotal += total
            quote_rows.append({"test":test,"method":method,"unit_rate":unit,"qty":qty,"tat_multiplier":multiplier,"total":total})
    vat=round(subtotal*0.15,2)
    return {"rows":quote_rows,"net":round(subtotal,2),"vat":vat,"grand":round(subtotal+vat,2)}


def _validated_attachment(upload: UploadFile) -> tuple[bytes, str, str]:
    if not upload.filename:
        raise ValueError("Select a quotation, purchase order or client document to upload")
    raw = upload.file.read(MAX_COMMERCIAL_ATTACHMENT_BYTES + 1)
    if not raw:
        raise ValueError("The selected commercial document is empty")
    if len(raw) > MAX_COMMERCIAL_ATTACHMENT_BYTES:
        raise ValueError("Commercial attachments must be 10 MB or smaller")
    original = Path(upload.filename).name[:220]
    suffix = Path(original).suffix.lower()
    content_type = (upload.content_type or "").lower()
    if content_type == "application/pdf" or suffix == ".pdf":
        if not raw.startswith(b"%PDF-"):
            raise ValueError("The uploaded PDF is invalid")
        return raw, ".pdf", "application/pdf"
    if content_type.startswith("image/") or suffix in {".jpg", ".jpeg", ".png", ".webp"}:
        try:
            with Image.open(BytesIO(raw)) as image:
                image.verify()
                fmt = (image.format or "").upper()
        except (UnidentifiedImageError, OSError, SyntaxError, ValueError):
            raise ValueError("The uploaded commercial image is invalid or corrupt")
        mapping = {
            "JPEG": (".jpg", "image/jpeg"),
            "PNG": (".png", "image/png"),
            "WEBP": (".webp", "image/webp"),
        }
        if fmt not in mapping:
            raise ValueError("Commercial document images must be JPEG, PNG or WebP")
        ext, mime = mapping[fmt]
        return raw, ext, mime
    raise ValueError("Commercial attachments must be PDF, JPEG, PNG or WebP")


def _site(db: Session, user: User) -> Site:
    if user.site_id:
        row = db.get(Site, user.site_id)
    else:
        row = db.scalar(select(Site).where(Site.code == "DMM"))
    if not row:
        raise ValueError("Active site is required")
    return row


def _case_code(db: Session, site: Site) -> str:
    year = datetime.utcnow().year
    prefix = f"BC-{site.code}-{year}-"
    rows = db.scalars(select(CommercialCase.case_code).where(CommercialCase.case_code.like(f"{prefix}%"))).all()
    last = 0
    for value in rows:
        try: last = max(last, int(value.rsplit("-", 1)[-1]))
        except Exception: pass
    return f"{prefix}{last + 1:04d}"


def _visible_packages_for_client(packages: list[dict], client: Client | None) -> list[dict]:
    code = (client.code if client else "").strip().upper()
    return [p for p in packages if str(p.get("scope") or "GENERAL").strip().upper() in {"", "GENERAL", code}]


def _request_test_catalog(packages: list[dict]) -> list[dict]:
    excluded_fragments = ("rsd%", "temperature", "humidity in cellulose", "oil quality index", "indirect dp", "lifetime remaining", "calculation")
    rows: dict[str, dict] = {}
    for package in packages:
        for item in package.get("tests", []):
            if not isinstance(item, dict):
                continue
            name = str(item.get("test") or "").strip()
            method = str(item.get("method") or "").strip().lower()
            lowered = name.lower()
            if not name or lowered.startswith("room test") or method == "calculation" or any(x in lowered for x in excluded_fragments):
                continue
            rows.setdefault(lowered, {"test": name})
    return sorted(rows.values(), key=lambda row: row["test"].lower())


def _parse_scope_due(value: str, tat: str) -> datetime | None:
    clean = (value or "").strip()
    if tat == "EXACT_DUE":
        if not clean:
            raise ValueError("Exact Due request requires a due date/time")
        try:
            return datetime.fromisoformat(clean)
        except ValueError as exc:
            raise ValueError("Exact due date/time is invalid") from exc
    return None


def _parse_expected_arrival(value: str) -> datetime | None:
    clean = (value or "").strip()
    if not clean:
        return None
    try:
        return datetime.fromisoformat(clean)
    except ValueError as exc:
        raise ValueError("Expected sample arrival date/time is invalid") from exc


def _clean_delivery_mode(value: str) -> str:
    clean = (value or "TBD").strip().upper()
    if clean not in CLIENT_DELIVERY_MODES:
        raise ValueError("Sample route must be Client Delivery, TSCO Collection, or To Be Confirmed")
    return clean


@router.get("")
def workspace(request: Request, case_id: int | None = None, db: Session = Depends(get_db)):
    user = require_user(request, db, VIEW)
    site = _site(db, user)
    stmt = select(CommercialCase).where(CommercialCase.site_id == site.id).order_by(CommercialCase.updated_at.desc())
    cases = list(db.scalars(stmt.limit(200)).all())
    selected = db.get(CommercialCase, case_id) if case_id else (cases[0] if cases else None)
    if selected and selected.site_id != site.id:
        selected = None
    if case_id and selected and selected.request_source == "CLIENT_PORTAL" and selected.request_status == "RECEIVED" and user.role in {Role.SALES_MARKETING.value, Role.CLIENT_COORDINATOR.value}:
        selected.request_status = "UNDER_REVIEW"
        selected.request_opened_at = datetime.utcnow()
        selected.request_opened_by_id = user.id
        add_audit(db, actor=user, request=request, action="CLIENT_SERVICE_REQUEST_OPENED", entity_type="CommercialCase", entity_id=selected.id, summary=f"{selected.case_code} opened by {user.full_name}")
        db.commit()
    clients = list(db.scalars(select(Client).where(Client.active.is_(True)).order_by(Client.name)).all())
    coordinators = [u for u in db.scalars(select(User).where(User.active.is_(True), User.role == Role.CLIENT_COORDINATOR.value).order_by(User.full_name)).all() if can_manage_controlled_commercial_documents(u)]
    projects_stmt = select(OperationalProject).where(OperationalProject.site_id == site.id).order_by(OperationalProject.created_at.desc())
    projects = list(db.scalars(projects_stmt.limit(100)).all())
    effective = effective_stage(db, selected) if selected else ""
    expected = next_stage(effective) if selected else None
    can_advance = bool(selected and expected and role_can_transition(user, expected))
    released_reports = []
    report_submissions = {}
    if selected:
        sample_ids = list(db.scalars(select(SampleRequest.id).where(SampleRequest.commercial_case_id == selected.id)).all())
        if not sample_ids and selected.sample_request_id:
            sample_ids = [selected.sample_request_id]
        if sample_ids:
            released_reports = list(db.scalars(
                select(ControlledReport).where(
                    ControlledReport.sample_request_id.in_(sample_ids),
                    ControlledReport.status == SampleStatus.REPORT_RELEASED.value,
                ).order_by(ControlledReport.revision.desc(), ControlledReport.created_at.desc())
            ).all())
        if released_reports:
            report_ids = [r.id for r in released_reports]
            submitted = list(db.scalars(select(ReportSubmission).where(ReportSubmission.controlled_report_id.in_(report_ids)).order_by(ReportSubmission.submitted_at.desc())).all())
            for sub in submitted:
                report_submissions.setdefault(sub.controlled_report_id, []).append(sub)
    packages = _visible_packages_for_client(package_catalog(db, site.id), selected.client if selected else None)
    request_test_catalog = _request_test_catalog(packages)
    selected_request_lines = request_scope_lines(db, selected) if selected else []
    for line in selected_request_lines:
        try:
            tests = json.loads(line.requested_tests_json or "[]")
        except Exception:
            tests = []
        line.requested_tests_display = ", ".join(str(x) for x in tests)
        line.expected_serials_display = ", ".join(request_line_expected_serials(line))
    selected_received_samples = 0
    if selected:
        selected_received_samples = db.scalar(select(func.count()).select_from(SampleRequest).where(SampleRequest.commercial_case_id == selected.id)) or 0
    demo_quote = _demo_quote_preview(selected_request_lines, packages) if selected else {"rows":[],"net":0.0,"vat":0.0,"grand":0.0}
    return templates.TemplateResponse("commercial_flow.html", {
        "request": request, "user": user, "site": site, "cases": cases, "selected": selected,
        "clients": clients, "coordinators": coordinators, "projects": projects, "stages": COMMERCIAL_STAGES, "stage_keys": STAGE_KEYS,
        "stage_labels": STAGE_LABELS, "effective_stage": effective, "next_stage": expected,
        "can_advance": can_advance, "can_create": can_create_commercial_case(user),
        "can_upload_attachment": can_manage_controlled_commercial_documents(user),
        "can_submit_client_report": can_submit_client_report(user),
        "can_create_project": user.role == Role.OPERATIONS_MANAGER.value or can_manage_controlled_commercial_documents(user),
        "released_reports": released_reports, "report_submissions": report_submissions,
        "commercial_document_types": sorted(COMMERCIAL_DOCUMENT_TYPES),
        "packages": packages, "request_test_catalog": request_test_catalog, "selected_request_lines": selected_request_lines,
        "selected_received_samples": selected_received_samples,
        "demo_price_master": DEMO_PRICE_MASTER, "demo_quote": demo_quote,
    })


@router.post("/cases")
def create_case(
    request: Request,
    client_id: int = Form(...), lead_title: str = Form(...), lead_source: str = Form(""),
    expected_arrival_at: str = Form(""), sample_delivery_mode: str = Form("TBD"), sample_delivery_notes: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, CREATE)
    if not can_create_commercial_case(user):
        raise HTTPException(status_code=403, detail="Business case creation belongs to Sales & Marketing Specialist or Client Account & Coordination")
    site = _site(db, user)
    client = db.get(Client, client_id)
    if not client or not client.active:
        raise ValueError("Active client is required")
    title = lead_title.strip()
    if not title:
        raise ValueError("Lead / opportunity title is required")
    row = CommercialCase(
        case_code=_case_code(db, site), site_id=site.id, client_id=client.id, owner_id=user.id,
        current_stage="LEAD_GENERATION", lead_title=title[:220], lead_source=lead_source.strip()[:120],
        expected_arrival_at=_parse_expected_arrival(expected_arrival_at), sample_delivery_mode=_clean_delivery_mode(sample_delivery_mode),
        sample_delivery_notes=(sample_delivery_notes or "").strip()[:4000],
    )
    db.add(row); db.flush()
    from ..models import CommercialEvent
    db.add(CommercialEvent(commercial_case_id=row.id, actor_id=user.id, from_stage="", to_stage="LEAD_GENERATION", note="Business opportunity opened"))
    add_audit(db, actor=user, request=request, action="COMMERCIAL_CASE_CREATED", entity_type="CommercialCase", entity_id=row.id, summary=row.case_code, details={"client_id": client.id})
    db.commit()
    return RedirectResponse(f"/commercial?case_id={row.id}", status_code=303)


@router.post("/cases/{case_id}/request-logistics")
def update_request_logistics(
    case_id: int, request: Request, expected_arrival_at: str = Form(""), sample_delivery_mode: str = Form("TBD"),
    sample_delivery_notes: str = Form(""), db: Session = Depends(get_db),
):
    user = require_user(request, db, CREATE)
    site = _site(db, user)
    case = db.get(CommercialCase, case_id)
    if not case or case.site_id != site.id:
        raise ValueError("Business case was not found in the active site")
    if effective_stage(db, case) != "LEAD_GENERATION" or case.quotation_id:
        raise ValueError("Request logistics are locked after Quotation is created")
    case.expected_arrival_at = _parse_expected_arrival(expected_arrival_at)
    case.sample_delivery_mode = _clean_delivery_mode(sample_delivery_mode)
    case.sample_delivery_notes = (sample_delivery_notes or "").strip()[:4000]
    add_audit(db, actor=user, request=request, action="COMMERCIAL_REQUEST_LOGISTICS_UPDATED", entity_type="CommercialCase", entity_id=case.id, summary=case.case_code)
    db.commit()
    return RedirectResponse(f"/commercial?case_id={case.id}", status_code=303)


@router.post("/cases/{case_id}/request-lines")
def add_request_line(
    case_id: int, request: Request, quantity: int = Form(...), requested_package: str = Form(...),
    method_family: str = Form("DEFAULT"), priority: str = Form("NORMAL"), required_tat: str = Form(""),
    due_at: str = Form(""), expected_serials: str = Form(""), requested_tests: list[str] = Form([]), db: Session = Depends(get_db),
):
    user = require_user(request, db, CREATE)
    site = _site(db, user)
    case = db.get(CommercialCase, case_id)
    if not case or case.site_id != site.id:
        raise ValueError("Business case was not found in the active site")
    if effective_stage(db, case) != "LEAD_GENERATION" or case.quotation_id:
        raise ValueError("Client Request Scope is locked after Quotation is created")
    if quantity < 1 or quantity > 10000:
        raise ValueError("Requested quantity must be between 1 and 10000 samples")
    packages = _visible_packages_for_client(package_catalog(db, site.id), case.client)
    active_names = {str(row.get("name") or "") for row in packages}
    package = (requested_package or "").strip()
    if package != "CUSTOM" and package not in active_names:
        raise ValueError("Select an active controlled test package or Custom Tests")
    family = (method_family or "DEFAULT").strip().upper()
    if family not in {"DEFAULT", "ASTM", "IEC"}:
        raise ValueError("Method family must be Default, ASTM or IEC")
    clean_priority = (priority or "NORMAL").strip().upper()
    if clean_priority not in {"NORMAL", "HIGH", "URGENT"}:
        raise ValueError("Priority must be NORMAL, HIGH or URGENT")
    tat = (required_tat or "").strip().upper()
    if tat not in {"", "12H", "24H", "EXACT_DUE"}:
        raise ValueError("Required TAT must be Standard, 12H, 24H or Exact Due")
    exact_due = _parse_scope_due(due_at, tat)
    valid_test_names = {row["test"] for row in _request_test_catalog(packages)}
    tests = list(dict.fromkeys(str(value).strip() for value in requested_tests if str(value).strip()))
    if package == "CUSTOM":
        if not tests:
            raise ValueError("Custom Tests requires at least one requested test")
        unknown = [name for name in tests if name not in valid_test_names]
        if unknown:
            raise ValueError(f"Unknown requested test: {unknown[0]}")
    else:
        tests = []
    serials = parse_expected_serials(expected_serials)
    if len(serials) > quantity:
        raise ValueError("Expected transformer serials cannot exceed the requested sample quantity")
    next_line = (db.scalar(select(func.max(CommercialRequestLine.line_number)).where(CommercialRequestLine.commercial_case_id == case.id)) or 0) + 1
    row = CommercialRequestLine(
        commercial_case_id=case.id, line_number=next_line, quantity=quantity, requested_package=package,
        requested_tests_json=json.dumps(tests, ensure_ascii=False), expected_serials_json=json.dumps(serials, ensure_ascii=False), method_family=family, priority=clean_priority,
        required_tat=tat, due_at=exact_due, status="ACTIVE", created_by_id=user.id,
    )
    db.add(row); db.flush()
    refresh_case_request_summary(db, case)
    add_audit(db, actor=user, request=request, action="CLIENT_REQUEST_SCOPE_ADDED", entity_type="CommercialRequestLine", entity_id=row.id,
              summary=f"{case.case_code} line {row.line_number}: {quantity} x {package}",
              details={"method_family": family, "priority": clean_priority, "tat": tat, "tests": tests, "expected_serials": serials})
    db.commit()
    return RedirectResponse(f"/commercial?case_id={case.id}", status_code=303)


@router.post("/cases/{case_id}/request-lines/{line_id}/edit")
def edit_request_line(
    case_id: int, line_id: int, request: Request, quantity: int = Form(...),
    expected_serials: str = Form(""), priority: str = Form("NORMAL"), required_tat: str = Form(""),
    due_at: str = Form(""), db: Session = Depends(get_db),
):
    user = require_user(request, db, CREATE)
    site = _site(db, user)
    case = db.get(CommercialCase, case_id)
    row = db.get(CommercialRequestLine, line_id)
    if not case or case.site_id != site.id or not row or row.commercial_case_id != case.id or row.status != "ACTIVE":
        raise ValueError("Client Request Scope line was not found")
    if effective_stage(db, case) != "LEAD_GENERATION" or case.quotation_id:
        raise ValueError("Client Request Scope is locked after Quotation is created")
    if quantity < 1 or quantity > 10000:
        raise ValueError("Requested quantity must be between 1 and 10000 samples")
    serials = parse_expected_serials(expected_serials)
    if len(serials) > quantity:
        raise ValueError("Expected transformer serials cannot exceed the requested sample quantity")
    clean_priority = (priority or "NORMAL").strip().upper()
    if clean_priority not in {"NORMAL", "HIGH", "URGENT"}:
        raise ValueError("Priority must be NORMAL, HIGH or URGENT")
    tat = (required_tat or "").strip().upper()
    if tat not in {"", "12H", "24H", "EXACT_DUE"}:
        raise ValueError("Required TAT must be Standard, 12H, 24H or Exact Due")
    row.quantity = quantity
    row.expected_serials_json = json.dumps(serials, ensure_ascii=False)
    row.priority = clean_priority
    row.required_tat = tat
    row.due_at = _parse_scope_due(due_at, tat)
    refresh_case_request_summary(db, case)
    add_audit(db, actor=user, request=request, action="CLIENT_REQUEST_SCOPE_EDITED", entity_type="CommercialRequestLine", entity_id=row.id, summary=f"{case.case_code} line {row.line_number} edited")
    db.commit()
    return RedirectResponse(f"/commercial?case_id={case.id}", status_code=303)


@router.post("/cases/{case_id}/request-lines/{line_id}/remove")
def remove_request_line(case_id: int, line_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, CREATE)
    site = _site(db, user)
    case = db.get(CommercialCase, case_id)
    row = db.get(CommercialRequestLine, line_id)
    if not case or case.site_id != site.id or not row or row.commercial_case_id != case.id:
        raise ValueError("Client Request Scope line was not found")
    if effective_stage(db, case) != "LEAD_GENERATION" or case.quotation_id:
        raise ValueError("Client Request Scope is locked after Quotation is created")
    row.status = "REMOVED"
    refresh_case_request_summary(db, case)
    add_audit(db, actor=user, request=request, action="CLIENT_REQUEST_SCOPE_REMOVED", entity_type="CommercialRequestLine", entity_id=row.id, summary=f"{case.case_code} line {row.line_number} removed")
    db.commit()
    return RedirectResponse(f"/commercial?case_id={case.id}", status_code=303)


@router.post("/cases/{case_id}/advance")
def advance(
    case_id: int, request: Request,
    target_stage: str = Form(...), note: str = Form(""), reference: str = Form(""),
    quotation_number: str = Form(""), purchase_order_number: str = Form(""),
    handover_commercial: str = Form(""), handover_technical: str = Form(""), handover_client_info: str = Form(""),
    expected_samples: str = Form(""), requested_test_package: str = Form(""), default_priority: str = Form("NORMAL"), required_tat: str = Form(""),
    invoice_contract_number: str = Form(""), invoice_ses_number: str = Form(""), invoice_date: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, VIEW)
    case = db.get(CommercialCase, case_id)
    site = _site(db, user)
    if not case or case.site_id != site.id:
        raise ValueError("Business case was not found in the active site")
    before = effective_stage(db, case)
    coordinator_stages = {"QUOTATION", "CLIENT_FOLLOW_UP", "PURCHASE_ORDER_RECEIVED", "COMPLETE_HANDOVER", "INVOICING"}
    if target_stage in coordinator_stages and case.assigned_coordinator_id != user.id:
        raise HTTPException(status_code=403, detail="This controlled stage belongs to the Assigned Client Account & Coordination Officer")
    advance_case(
        db, case, user, target_stage=target_stage, note=note, reference=reference,
        quotation_number=quotation_number, purchase_order_number=purchase_order_number,
        handover_commercial=handover_commercial, handover_technical=handover_technical,
        handover_client_info=handover_client_info, expected_samples=expected_samples,
        requested_test_package=requested_test_package, default_priority=default_priority, required_tat=required_tat,
        invoice_contract_number=invoice_contract_number, invoice_ses_number=invoice_ses_number, invoice_date=invoice_date,
    )
    add_audit(db, actor=user, request=request, action="COMMERCIAL_STAGE_ADVANCED", entity_type="CommercialCase", entity_id=case.id, summary=f"{case.case_code}: {before} -> {target_stage}", details={"reference": reference.strip()})
    db.commit()
    return RedirectResponse(f"/commercial?case_id={case.id}", status_code=303)


@router.post("/cases/{case_id}/quotation-revise")
def revise_quotation(case_id: int, request: Request, quotation_number: str = Form(...), db: Session = Depends(get_db)):
    user = require_user(request, db, VIEW)
    site = _site(db, user)
    case = db.get(CommercialCase, case_id)
    if not case or case.site_id != site.id:
        raise ValueError("Business case was not found in the active site")
    if case.assigned_coordinator_id != user.id or not can_manage_controlled_commercial_documents(user):
        raise HTTPException(status_code=403, detail="Quotation revision belongs to the Assigned Client Account & Coordination Officer")
    if effective_stage(db, case) != "QUOTATION" or not case.quotation or case.quotation.status != "CLIENT_REJECTED":
        raise ValueError("Quotation revision is available only after a client revision request")
    number = (quotation_number or "").strip()[:80]
    if not number:
        raise ValueError("Revised quotation number is required")
    lines = request_scope_lines(db, case)
    scope_summary = "; ".join(
        f"{row.quantity} x {row.requested_package} / {row.method_family or 'DEFAULT'} / {row.priority}{(' / ' + row.required_tat) if row.required_tat else ''}"
        for row in lines
    )[:240]
    quote = db.scalar(select(Quotation).where(Quotation.client_id == case.client_id, Quotation.number == number))
    if not quote:
        quote = Quotation(client_id=case.client_id, number=number, status="ACTIVE", description=scope_summary or case.lead_title)
        db.add(quote); db.flush()
    else:
        quote.status = "ACTIVE"; quote.description = scope_summary or quote.description
    previous = case.quotation.number
    case.quotation_id = quote.id
    case.request_status = "QUOTATION_CREATED"
    db.add(CommercialEvent(commercial_case_id=case.id, actor_id=user.id, from_stage="QUOTATION", to_stage="QUOTATION", note=f"Revised quotation issued after client revision request; supersedes {previous}", reference=number))
    add_audit(db, actor=user, request=request, action="COMMERCIAL_QUOTATION_REVISED", entity_type="CommercialCase", entity_id=case.id, summary=f"{case.case_code}: revised quotation {number}")
    db.commit()
    return RedirectResponse(f"/commercial?case_id={case.id}", status_code=303)


@router.post("/cases/{case_id}/assign-coordinator")
def assign_coordinator(case_id: int, request: Request, coordinator_id: int = Form(...), reason: str = Form(""), db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.OPERATIONS_MANAGER.value})
    case = db.get(CommercialCase, case_id)
    site = _site(db, user)
    coordinator = db.get(User, coordinator_id)
    if not case or case.site_id != site.id:
        raise HTTPException(status_code=404, detail="Business case was not found in the active site")
    if not coordinator or not coordinator.active or coordinator.site_id != site.id or not can_manage_controlled_commercial_documents(coordinator):
        raise ValueError("Select an active Client Account & Coordination Officer from this site")
    previous = case.assigned_coordinator_id
    reason_text = reason.strip()
    if previous and previous != coordinator.id and not reason_text:
        raise ValueError("Coordinator reassignment reason is required")
    case.assigned_coordinator_id = coordinator.id
    add_audit(db, actor=user, request=request, action="COMMERCIAL_COORDINATOR_ASSIGNED", entity_type="CommercialCase", entity_id=case.id,
              summary=f"{case.case_code} assigned to {coordinator.full_name}", details={"previous_coordinator_id": previous, "coordinator_id": coordinator.id, "reason": reason_text})
    db.commit()
    return RedirectResponse(f"/commercial?case_id={case.id}", status_code=303)


@router.post("/projects")
def create_project(
    request: Request, project_reference: str = Form(...), project_name: str = Form(...), client_id: int = Form(...),
    commercial_case_id: str = Form(""), project_type: str = Form("GENERAL"), scope: str = Form(""),
    location_scope: str = Form(""), planned_start_at: str = Form(""), planned_end_at: str = Form(""),
    field_scope: str = Form(""), laboratory_scope: str = Form("1"), expected_samples: str = Form(""),
    test_package: str = Form(""), special_tat: str = Form(""), supporting_notes: str = Form(""), db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.OPERATIONS_MANAGER.value, Role.CLIENT_COORDINATOR.value})
    if user.role == Role.CLIENT_COORDINATOR.value and not can_manage_controlled_commercial_documents(user):
        raise HTTPException(status_code=403, detail="Operational Project submission belongs to Client Account & Coordination or Field Operations")
    site = _site(db, user)
    client = db.get(Client, client_id)
    if not client or not client.active:
        raise ValueError("Active client is required")
    case = db.get(CommercialCase, int(commercial_case_id)) if commercial_case_id.strip().isdigit() else None
    if case and (case.site_id != site.id or case.client_id != client.id):
        raise ValueError("Business case does not match the selected site/client")
    if case and user.role == Role.CLIENT_COORDINATOR.value and case.assigned_coordinator_id != user.id:
        raise HTTPException(status_code=403, detail="Only the Assigned Coordinator may submit a project for this Business Case")
    ref = project_reference.strip().upper()[:80]
    name = project_name.strip()[:220]
    if not ref or not name:
        raise ValueError("Project reference and project name are required")
    if db.scalar(select(OperationalProject).where(OperationalProject.project_reference == ref)):
        raise ValueError("Project reference already exists")
    start = datetime.fromisoformat(planned_start_at) if planned_start_at else None
    end = datetime.fromisoformat(planned_end_at) if planned_end_at else None
    if start and end and end < start:
        raise ValueError("Project end must not precede start")
    exp = int(expected_samples) if expected_samples.strip().isdigit() else None
    row = OperationalProject(
        project_reference=ref, project_name=name, site_id=site.id, client_id=client.id,
        commercial_case_id=case.id if case else None, created_by_id=user.id, project_type=project_type.strip().upper()[:80] or "GENERAL",
        scope=scope.strip(), location_scope=location_scope.strip()[:220], planned_start_at=start, planned_end_at=end,
        field_scope=field_scope.lower() in {"1","true","on","yes"}, laboratory_scope=laboratory_scope.lower() in {"1","true","on","yes"},
        expected_samples=exp, test_package=test_package.strip()[:160], special_tat=special_tat.strip()[:80],
        status="PENDING_GM_APPROVAL", supporting_notes=supporting_notes.strip(), submitted_at=datetime.utcnow(),
    )
    db.add(row); db.flush()
    add_audit(db, actor=user, request=request, action="OPERATIONAL_PROJECT_SUBMITTED", entity_type="OperationalProject", entity_id=row.id,
              summary=f"{row.project_reference} submitted for GM approval", details={"commercial_case_id": row.commercial_case_id, "field_scope": row.field_scope, "laboratory_scope": row.laboratory_scope})
    db.commit()
    return RedirectResponse(f"/commercial?case_id={case.id if case else ''}", status_code=303)


@router.post("/projects/{project_id}/approve")
def approve_project(project_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.MANAGEMENT.value})
    row = db.get(OperationalProject, project_id)
    if not row:
        raise HTTPException(status_code=404, detail="Operational Project not found")
    if row.status != "PENDING_GM_APPROVAL":
        raise ValueError("Only a pending project can be GM-approved")
    row.status = "APPROVED"; row.approved_by_id = user.id; row.approved_at = datetime.utcnow()
    if row.commercial_case_id:
        case = db.get(CommercialCase, row.commercial_case_id)
        if case: case.operational_project_id = row.id

    # GM approval is the controlled handoff into Field/Laboratory planning.
    # Notify only the managers whose operation is actually in scope; do not
    # create fake local HR/IT/Quality approval identities.
    managers = list(db.scalars(
        select(User).where(
            User.active.is_(True),
            User.site_id == row.site_id,
            User.role.in_([Role.OPERATIONS_MANAGER.value, Role.TECHNICAL_MANAGER.value]),
        )
    ).all())
    scope_bits = []
    if row.field_scope:
        scope_bits.append("Field")
    if row.laboratory_scope:
        scope_bits.append("Laboratory")
    workload = f"{row.expected_samples} expected sample(s)" if row.expected_samples else "workload TBD"
    start = row.planned_start_at.strftime("%Y-%m-%d %H:%M") if row.planned_start_at else "start TBD"
    tat = row.special_tat or "standard TAT"
    message = (
        f"{row.project_reference} · {row.client.name} · {' + '.join(scope_bits) or 'Operational'} scope · "
        f"{start} · {workload} · {row.test_package or 'test package TBD'} · {tat}."
    )
    for manager in managers:
        if manager.role == Role.OPERATIONS_MANAGER.value and not row.field_scope:
            continue
        if manager.role == Role.TECHNICAL_MANAGER.value and not row.laboratory_scope:
            continue
        target = "/operations#upcoming-projects" if manager.role == Role.OPERATIONS_MANAGER.value else "/management#upcoming-projects"
        db.add(Notification(
            site_id=row.site_id, user_id=manager.id, category="PROJECT",
            title=f"Operational Project Approved · {row.project_reference}",
            message=message, target_url=target, priority="HIGH" if row.special_tat else "NORMAL",
        ))
    add_audit(db, actor=user, request=request, action="OPERATIONAL_PROJECT_APPROVED", entity_type="OperationalProject", entity_id=row.id, summary=f"{row.project_reference} approved by GM")
    db.commit(); return RedirectResponse(f"/commercial?case_id={row.commercial_case_id or ''}", status_code=303)


@router.post("/projects/{project_id}/activate")
def activate_project(project_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.OPERATIONS_MANAGER.value, Role.CLIENT_COORDINATOR.value})
    if user.role == Role.CLIENT_COORDINATOR.value and not can_manage_controlled_commercial_documents(user):
        raise HTTPException(status_code=403, detail="Project activation belongs to Field Operations or Client Account & Coordination")
    row = db.get(OperationalProject, project_id)
    if not row: raise HTTPException(status_code=404, detail="Operational Project not found")
    if user.role == Role.CLIENT_COORDINATOR.value and row.commercial_case_id:
        case = db.get(CommercialCase, row.commercial_case_id)
        if case and case.assigned_coordinator_id != user.id:
            raise HTTPException(status_code=403, detail="Only the Assigned Coordinator may activate this Operational Project")
    if row.status != "APPROVED": raise ValueError("GM approval is required before project activation")
    row.status = "ACTIVE"
    add_audit(db, actor=user, request=request, action="OPERATIONAL_PROJECT_ACTIVATED", entity_type="OperationalProject", entity_id=row.id, summary=f"{row.project_reference} activated")
    db.commit(); return RedirectResponse(f"/commercial?case_id={row.commercial_case_id or ''}", status_code=303)


@router.post("/cases/{case_id}/attachments")
def upload_attachment(
    case_id: int,
    request: Request,
    document_type: str = Form(...),
    upload: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, ATTACHMENT_UPLOAD)
    if not can_manage_controlled_commercial_documents(user):
        raise HTTPException(status_code=403, detail="Controlled quotation/PO/handover attachments belong to Client Account & Coordination")
    case = db.get(CommercialCase, case_id)
    site = _site(db, user)
    if not case or case.site_id != site.id:
        raise ValueError("Business case was not found in the active site")
    kind = (document_type or "").strip().upper()
    if kind not in COMMERCIAL_DOCUMENT_TYPES:
        raise ValueError("Unsupported commercial document type")
    raw, ext, mime = _validated_attachment(upload)
    digest = hashlib.sha256(raw).hexdigest()
    folder = UPLOAD_DIR / "commercial"
    folder.mkdir(parents=True, exist_ok=True)
    stored = folder / f"case_{case.id}_{digest[:20]}{ext}"
    if not stored.exists():
        stored.write_bytes(raw)
    row = CommercialAttachment(
        commercial_case_id=case.id,
        document_type=kind,
        original_name=Path(upload.filename or f"document{ext}").name[:220],
        stored_path=str(stored),
        content_type=mime,
        sha256=digest,
        content_blob=raw,
        uploaded_by_id=user.id,
    )
    db.add(row)
    db.flush()
    add_audit(
        db, actor=user, request=request, action="COMMERCIAL_ATTACHMENT_UPLOADED",
        entity_type="CommercialAttachment", entity_id=row.id,
        summary=f"{case.case_code}: {kind} — {row.original_name}",
        details={"case_id": case.id, "document_type": kind, "sha256": digest},
    )
    db.commit()
    return RedirectResponse(f"/commercial?case_id={case.id}", status_code=303)


@router.get("/attachments/{attachment_id}")
def download_attachment(attachment_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, VIEW)
    row = db.get(CommercialAttachment, attachment_id)
    if not row:
        raise ValueError("Commercial attachment was not found")
    case = db.get(CommercialCase, row.commercial_case_id)
    site = _site(db, user)
    if not case or case.site_id != site.id:
        raise ValueError("Commercial attachment is outside the active site")
    path = Path(row.stored_path or "")
    if path.is_file():
        return FileResponse(
            path,
            media_type=row.content_type or "application/octet-stream",
            filename=Path(row.original_name).name,
            content_disposition_type="inline",
        )
    if row.content_blob:
        safe_name = Path(row.original_name).name.replace('"', '')
        return Response(content=bytes(row.content_blob), media_type=row.content_type or "application/octet-stream", headers={"Content-Disposition": f'inline; filename="{safe_name}"'})
    raise ValueError("Commercial attachment file is unavailable")
