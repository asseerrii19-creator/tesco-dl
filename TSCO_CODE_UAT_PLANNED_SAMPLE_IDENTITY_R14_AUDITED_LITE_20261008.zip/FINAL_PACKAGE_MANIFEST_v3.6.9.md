# Final Package Manifest — v3.6.9 / R11 UAT Consolidated Closeout

## Single consolidated UAT correction
1. DGA source-evidence release-gate integration + Evidence fallback upload.
2. Pending/assigned Technical Review visibility so samples do not silently disappear.
3. Canonical assignment families matching laboratory distribution.
4. Canonical result/review/report ordering across Senior review, QDF [7]-07-E and QDF-[7]-08-A.
5. Nine-gas DGA grouping and complete DGA diagnostic input set.
6. Water final average only in reports; instrument-level readings remain traceable audit evidence.
7. Whole-number RSD report display with exact calculation retained.
8. Lab Room Temperature/Humidity board-entry workflow tied to Water/BDV/PF assignment and per-sample snapshot.
9. Oil-family split: IFT/Color/Appearance; TAN/RSH/Peroxide; OQI; Furan; DBDS/Toluene/BHT/PCB; Corrosive/Flash/Metals.
10. Senior System Technical Screening, suggested Interpretation/Recommendation drafts, and explicit NOT SELECTED default condition.
11. Grouped Senior/Manager result review retains condition colors and history trend arrows.
12. Report-path terminology standardized to Lab Operational & Technical Manager.
13. Official report identity/room-condition layout cleanup and ordered result-family rendering.

## Deployment boundary
Code-only LITE package. Preserve PostgreSQL, uploaded/reference assets, environment values and the existing Start Command.
