# UAT unblock — 2026-10-07

- DGA release control now recognizes the original GC/TOGA CSV already synchronized from the DGA workstation for the exact sample.
- Technical Manager approval uses the same authoritative DGA source rule, eliminating duplicate upload requirements.
- Quality > Evidence now exposes a controlled evidence upload form for authorized governance roles as a fallback.
- No changes to official report rendering, result calculations, QC rules, or existing persistent data.
