# Final Verification — v3.7.1 / R12

Release: `3.7.1-R12-UAT-RELEASE-HARDENING-20261007`
Baseline: R11 / v3.6.9.
Alembic head: `d65f7a9b2c10` (unchanged).

## Verified controls
- Python compilation: PASS
- JavaScript syntax checks in release build: PASS
- QC UI deployment assertions: PASS
- QC clock assertions: PASS
- Phase-1 role authority assertions: PASS
- R12 + retained release regression set: PASS — 65 tests
- Official report PDF smoke render: PASS — 3 pages, rendered successfully

## Deployment compatibility
R12 is an in-place code update. Keep the existing PostgreSQL database and reference-asset overlay. Do not recreate UAT cases, samples, batches, evidence, QC, or chain-of-custody records.

The LITE archive intentionally excludes `app/reference_documents`; the deployment build must continue overlaying the existing `TSCO_REFERENCE_ASSETS.zip` before install/start.

## Post-deploy UAT focus
1. New sample or controlled report revision: LTD boundary (`<= DL`) presentation.
2. Water-derived order → BDV/PF → room-board snapshot.
3. Same-sample DGA evidence filename integrity.
4. Senior client-report Technical Sign-off snapshot.
5. Manager snapshot confirmation → separate final release.
6. Multi-sample request shows Partially Released until all sample reports release.
7. QR verification readability and release metadata.

Existing released PDFs are immutable by design; use a new/superseding revision to validate corrected official report output.
