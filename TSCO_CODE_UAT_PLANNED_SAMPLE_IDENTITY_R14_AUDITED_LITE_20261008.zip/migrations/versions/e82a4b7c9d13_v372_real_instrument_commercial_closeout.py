"""v3.7.2 real instrument + commercial closeout

Revision ID: e82a4b7c9d13
Revises: d65f7a9b2c10
Create Date: 2026-10-08
"""
from alembic import op
import sqlalchemy as sa

revision = 'e82a4b7c9d13'
down_revision = 'd65f7a9b2c10'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('commercial_cases', sa.Column('sales_order_number', sa.String(length=80), nullable=False, server_default=''))
    op.add_column('commercial_cases', sa.Column('sales_order_year', sa.Integer(), nullable=True))
    op.add_column('commercial_cases', sa.Column('sales_order_month', sa.Integer(), nullable=True))
    op.add_column('commercial_cases', sa.Column('invoice_date', sa.DateTime(), nullable=True))
    op.add_column('commercial_cases', sa.Column('invoice_contract_number', sa.String(length=120), nullable=False, server_default=''))
    op.add_column('commercial_cases', sa.Column('invoice_ses_number', sa.String(length=120), nullable=False, server_default=''))
    op.create_index('ix_commercial_cases_sales_order_number', 'commercial_cases', ['sales_order_number'])
    op.create_index('ix_commercial_cases_sales_order_year', 'commercial_cases', ['sales_order_year'])
    op.create_index('ix_commercial_cases_sales_order_month', 'commercial_cases', ['sales_order_month'])

    # Existing UAT databases may already contain the two coordinator accounts and client masters.
    # Seed the agreed account ownership only when those exact demo identities exist; do not create
    # users/clients or override any existing scope.
    bind = op.get_bind()
    scopes = [
        ('client.coordinator@tsco.local', 'ARM'),
        ('external.coordination@tsco.local', 'SEC'),
        ('external.coordination@tsco.local', 'GPEL'),
    ]
    for email, client_code in scopes:
        user_id = bind.execute(sa.text('SELECT id FROM users WHERE lower(email)=lower(:email) LIMIT 1'), {'email': email}).scalar()
        client_id = bind.execute(sa.text('SELECT id FROM clients WHERE upper(code)=upper(:code) LIMIT 1'), {'code': client_code}).scalar()
        if not user_id or not client_id:
            continue
        exists = bind.execute(sa.text('SELECT id FROM user_client_assignments WHERE user_id=:uid AND client_id=:cid LIMIT 1'), {'uid': user_id, 'cid': client_id}).scalar()
        if not exists:
            bind.execute(sa.text('INSERT INTO user_client_assignments (user_id, client_id, active, created_at) VALUES (:uid, :cid, :active, CURRENT_TIMESTAMP)'), {'uid': user_id, 'cid': client_id, 'active': True})


def downgrade():
    op.drop_index('ix_commercial_cases_sales_order_month', table_name='commercial_cases')
    op.drop_index('ix_commercial_cases_sales_order_year', table_name='commercial_cases')
    op.drop_index('ix_commercial_cases_sales_order_number', table_name='commercial_cases')
    op.drop_column('commercial_cases', 'invoice_ses_number')
    op.drop_column('commercial_cases', 'invoice_contract_number')
    op.drop_column('commercial_cases', 'invoice_date')
    op.drop_column('commercial_cases', 'sales_order_month')
    op.drop_column('commercial_cases', 'sales_order_year')
    op.drop_column('commercial_cases', 'sales_order_number')
