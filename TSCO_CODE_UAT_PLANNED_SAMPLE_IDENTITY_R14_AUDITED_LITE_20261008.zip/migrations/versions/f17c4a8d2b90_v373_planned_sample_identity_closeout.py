"""v3.7.3 planned sample identity / barcode closeout

Revision ID: f17c4a8d2b90
Revises: e82a4b7c9d13
Create Date: 2026-10-08
"""
from alembic import op
import sqlalchemy as sa

revision = 'f17c4a8d2b90'
down_revision = 'e82a4b7c9d13'
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        'planned_samples',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('commercial_case_id', sa.Integer(), sa.ForeignKey('commercial_cases.id'), nullable=False),
        sa.Column('commercial_request_line_id', sa.Integer(), sa.ForeignKey('commercial_request_lines.id'), nullable=False),
        sa.Column('site_id', sa.Integer(), sa.ForeignKey('sites.id'), nullable=False),
        sa.Column('client_id', sa.Integer(), sa.ForeignKey('clients.id'), nullable=False),
        sa.Column('sequence_no', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('request_number', sa.String(length=40), nullable=False),
        sa.Column('public_token', sa.String(length=80), nullable=False),
        sa.Column('barcode_value', sa.String(length=80), nullable=False),
        sa.Column('expected_serial_number', sa.String(length=120), nullable=False, server_default=''),
        sa.Column('sampling_point', sa.String(length=100), nullable=False, server_default=''),
        sa.Column('requested_package', sa.String(length=120), nullable=False, server_default='Routine Test'),
        sa.Column('requested_method_family', sa.String(length=20), nullable=False, server_default='DEFAULT'),
        sa.Column('requested_tests_json', sa.Text(), nullable=False, server_default='[]'),
        sa.Column('priority', sa.String(length=20), nullable=False, server_default='NORMAL'),
        sa.Column('required_tat', sa.String(length=30), nullable=False, server_default=''),
        sa.Column('due_at', sa.DateTime(), nullable=True),
        sa.Column('delivery_mode', sa.String(length=30), nullable=False, server_default='TBD'),
        sa.Column('expected_arrival_at', sa.DateTime(), nullable=True),
        sa.Column('status', sa.String(length=30), nullable=False, server_default='EXPECTED'),
        sa.Column('sample_request_id', sa.Integer(), sa.ForeignKey('sample_requests.id', name='fk_planned_sample_materialized'), nullable=True),
        sa.Column('label_pdf_path', sa.String(length=500), nullable=False, server_default=''),
        sa.Column('data_form_pdf_path', sa.String(length=500), nullable=False, server_default=''),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('materialized_at', sa.DateTime(), nullable=True),
        sa.UniqueConstraint('commercial_request_line_id', 'sequence_no', name='uq_planned_sample_line_sequence'),
        sa.UniqueConstraint('request_number', name='uq_planned_sample_request_number'),
        sa.UniqueConstraint('public_token', name='uq_planned_sample_public_token'),
        sa.UniqueConstraint('barcode_value', name='uq_planned_sample_barcode_value'),
        sa.UniqueConstraint('sample_request_id', name='uq_planned_sample_request_id'),
    )
    for name, cols in [
        ('ix_planned_samples_commercial_case_id', ['commercial_case_id']),
        ('ix_planned_samples_commercial_request_line_id', ['commercial_request_line_id']),
        ('ix_planned_samples_site_id', ['site_id']),
        ('ix_planned_samples_client_id', ['client_id']),
        ('ix_planned_samples_request_number', ['request_number']),
        ('ix_planned_samples_public_token', ['public_token']),
        ('ix_planned_samples_barcode_value', ['barcode_value']),
        ('ix_planned_samples_expected_serial_number', ['expected_serial_number']),
        ('ix_planned_samples_due_at', ['due_at']),
        ('ix_planned_samples_delivery_mode', ['delivery_mode']),
        ('ix_planned_samples_status', ['status']),
        ('ix_planned_samples_sample_request_id', ['sample_request_id']),
    ]:
        op.create_index(name, 'planned_samples', cols)

    # Batch mode keeps the migration valid on SQLite UAT while producing the same
    # FK/index structure on PostgreSQL production.
    with op.batch_alter_table('sampling_assignments') as batch_op:
        batch_op.add_column(sa.Column('planned_sample_id', sa.Integer(), nullable=True))
        batch_op.create_foreign_key('fk_sampling_assignment_planned_sample', 'planned_samples', ['planned_sample_id'], ['id'])
        batch_op.create_index('ix_sampling_assignments_planned_sample_id', ['planned_sample_id'], unique=True)


def downgrade():
    with op.batch_alter_table('sampling_assignments') as batch_op:
        batch_op.drop_index('ix_sampling_assignments_planned_sample_id')
        batch_op.drop_constraint('fk_sampling_assignment_planned_sample', type_='foreignkey')
        batch_op.drop_column('planned_sample_id')
    for name in [
        'ix_planned_samples_sample_request_id', 'ix_planned_samples_status', 'ix_planned_samples_delivery_mode',
        'ix_planned_samples_due_at', 'ix_planned_samples_expected_serial_number', 'ix_planned_samples_barcode_value',
        'ix_planned_samples_public_token', 'ix_planned_samples_request_number', 'ix_planned_samples_client_id',
        'ix_planned_samples_site_id', 'ix_planned_samples_commercial_request_line_id', 'ix_planned_samples_commercial_case_id',
    ]:
        op.drop_index(name, table_name='planned_samples')
    op.drop_table('planned_samples')
