# Final Verification — v3.7.2 / R13

Release: `3.7.2-R13-REAL-INSTRUMENT-COMMERCIAL-CLOSEOUT-20261008`  
Baseline: v3.7.1 / R12  
Alembic head: `e82a4b7c9d13`

## Verified release gates
- Python compilation: PASS
- Static JavaScript syntax: PASS
- Laboratory Operations inline JavaScript syntax: PASS
- Real-instrument UI assertions: PASS
- Commercial closeout assertions: PASS
- Alembic single-head assertion: PASS
- Fresh SQLite migration from empty database through R13 head: PASS
- R13 + retained authoritative regression set: **72 passed / 0 failed**
- `TSCO_RELEASE_CHECK=PASS`

## Real instrument validation
- Real-shaped Megger cumulative BDV CSV schema parsed directly by the shipped browser parser: PASS.
- Sample suffix → instrument `testId` matching: PASS.
- IEC 60156 six runs: PASS.
- ASTM D1816 five runs: PASS.
- Controlled single-sample BDV evidence PDF generation: PASS.
- Real supplied QDF DGA result PDF parsing: PASS — Sample number, IEC/ASTM family, Bottom/Tap Changer classification, nine STP gas values and printed calculated fields supported.
- DGA import writes into the existing DGA result model and retains the original PDF evidence: PASS.

## Commercial validation
- PO receipt creates Sales Order: PASS.
- Non-Aramco requests receive independent Sales Orders: PASS.
- Aramco requests in the same site/month reuse one monthly Sales Order: PASS.
- New month generates a new Aramco Sales Order: PASS.
- Sales Order metadata flows into laboratory sample metadata/profile: PASS.
- Aramco coordinator ownership and non-Aramco coordinator pool: PASS.
- Lab Manager release remains direct to Client Portal and triggers Coordinator invoice notification after all linked sample reports release: PASS.
- Invoice registration fields (Invoice No., date, Contract, SES) and authoritative PDF attachment boundary: PASS.

## Deployment compatibility
R13 requires the new migration but **does not require a database reset**. Keep the current database and deployment storage. Startup continues to run `alembic upgrade head` before Uvicorn.

The LITE code archive intentionally excludes `app/reference_documents`; continue overlaying the existing `TSCO_REFERENCE_ASSETS.zip` before install/start, exactly as in R12.

## Post-deploy UAT focus
1. Client request → quotation → PO → auto Sales Order; verify 10 samples inherit one SO.
2. Aramco: create two requests in the same month and confirm the same SO; create another-month case and confirm a new SO.
3. Verify Aramco request routes to the Aramco coordinator and SEC/other client request routes to the second coordinator.
4. BDV: upload the real cumulative device CSV and import one matching sample only; confirm Average/RSD and generated single-sample evidence PDF.
5. DGA: upload the real QDF result PDF and confirm the nine gases + applicable calculated fields populate the existing workstation and Final Report path.
6. Lab Manager final release → Client Portal visibility immediately; Coordinator receives invoice-required notification only after all case sample reports release.
7. Register official invoice references and upload the official invoice PDF.
