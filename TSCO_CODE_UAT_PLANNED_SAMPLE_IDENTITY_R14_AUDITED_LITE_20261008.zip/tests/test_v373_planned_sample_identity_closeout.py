from pathlib import Path

from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.database import Base
from app.models import Asset, Client, CommercialCase, CommercialRequestLine, PlannedSample, SampleRequest, Site
from app.services.planned_samples import ensure_planned_samples
from app.services.lab_operations import blank_operations_db

ROOT = Path(__file__).resolve().parents[1]


def _case_with_three_samples(db: Session):
    site = Site(code='DMM', name='Dammam', laboratory_name='TSCO Analytical Lab', active=True)
    client = Client(code='SEC', name='Saudi Electricity Company', active=True)
    db.add_all([site, client]); db.flush()
    case = CommercialCase(
        case_code='R14-BC-001', site_id=site.id, client_id=client.id,
        current_stage='COMPLETE_HANDOVER', status='ACTIVE',
        sample_delivery_mode='CLIENT_DELIVERY', sales_order_number='TIC-SO426009999',
    )
    db.add(case); db.flush()
    line = CommercialRequestLine(
        commercial_case_id=case.id, line_number=1, quantity=3,
        requested_package='Routine Test', requested_tests_json='["Water Content","BDV"]',
        expected_serials_json='["TR-001","TR-002","TR-003"]', method_family='IEC',
        priority='NORMAL', required_tat='', status='ACTIVE',
    )
    db.add(line); db.flush()
    return site, client, case, line


def test_handover_pre_generates_one_stable_identity_and_barcode_per_expected_sample():
    engine = create_engine('sqlite:///:memory:')
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        _, _, case, line = _case_with_three_samples(db)
        rows = ensure_planned_samples(db, case)
        db.flush()
        assert len(rows) == 3
        assert [r.sequence_no for r in rows] == [1, 2, 3]
        assert [r.expected_serial_number for r in rows] == ['TR-001', 'TR-002', 'TR-003']
        assert len({r.request_number for r in rows}) == 3
        assert len({r.barcode_value for r in rows}) == 3
        assert all(r.request_number.startswith('FS-DMM-') for r in rows)
        assert all(r.barcode_value.startswith('TSCO-DMM-') for r in rows)
        assert all(r.commercial_request_line_id == line.id for r in rows)
        assert all(r.status == 'EXPECTED' for r in rows)
        assert all(r.data_form_pdf_path and Path(r.data_form_pdf_path).is_file() for r in rows)

        # Idempotent: opening Intake/Client Portal later must never renumber or duplicate them.
        original = [(r.id, r.request_number, r.barcode_value) for r in rows]
        again = ensure_planned_samples(db, case)
        assert [(r.id, r.request_number, r.barcode_value) for r in again] == original
        assert db.query(PlannedSample).filter(PlannedSample.commercial_case_id == case.id).count() == 3



def test_upgrade_backfill_reuses_existing_sample_identity_instead_of_creating_duplicate_expected_sample():
    from datetime import datetime
    engine = create_engine('sqlite:///:memory:')
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        site, client, case, line = _case_with_three_samples(db)
        asset = Asset(client_id=client.id, asset_code='TR-OLD', serial_number='TR-001', equipment_type='Power Transformer', active=True)
        db.add(asset); db.flush()
        legacy = SampleRequest(
            request_number='FS-DMM-26-009001', public_token='legacy-token-9001', barcode_value='TSCO-DMM-26-00009001',
            status='RECEIVED', site_id=site.id, client_id=client.id, commercial_case_id=case.id,
            commercial_request_line_id=line.id, asset_id=asset.id, sample_date_time=datetime(2026,10,1,8,0),
            sampling_point='Bottom', requested_package='Routine Test', requested_method_family='IEC',
            requested_tests_json='["Water Content","BDV"]', priority='NORMAL', submission_channel='CLIENT_DELIVERED',
        )
        db.add(legacy); db.flush()
        rows = ensure_planned_samples(db, case)
        db.flush()
        assert len(rows) == 3
        materialized = [r for r in rows if r.sample_request_id == legacy.id]
        assert len(materialized) == 1
        assert materialized[0].request_number == legacy.request_number
        assert materialized[0].barcode_value == legacy.barcode_value
        assert materialized[0].status == 'MATERIALIZED'
        expected = [r for r in rows if r.sample_request_id is None]
        assert len(expected) == 2
        assert legacy.request_number not in {r.request_number for r in expected}


def test_intake_and_field_routes_preserve_the_pre_generated_identity_and_match_physical_receipt():
    intake = (ROOT / 'app' / 'routes' / 'intake.py').read_text(encoding='utf-8')
    field = (ROOT / 'app' / 'routes' / 'field.py').read_text(encoding='utf-8')
    tpl = (ROOT / 'app' / 'templates' / 'intake_queue.html').read_text(encoding='utf-8')
    review = (ROOT / 'app' / 'templates' / 'intake_review.html').read_text(encoding='utf-8')
    assert 'request_number, barcode_value, public_token = planned.request_number, planned.barcode_value, planned.public_token' in intake
    assert 'claim_planned_identity(planned, sample)' in intake
    assert 'EXPECTED_BARCODE_MATCH_AND_RECEIVE' in intake
    assert 'Match + Accept Physical Sample' in tpl
    assert 'Match + Accept Physical Sample' in review
    assert 'planned.barcode_value' in field
    assert 'planned.request_number' in field


def test_operations_uses_the_same_planned_samples_for_sampling_and_pickup_without_duplicate_work():
    route = (ROOT / 'app' / 'routes' / 'operations.py').read_text(encoding='utf-8')
    tpl = (ROOT / 'app' / 'templates' / 'operations_dashboard.html').read_text(encoding='utf-8')
    supervision = (ROOT / 'app' / 'templates' / 'sampling_supervision.html').read_text(encoding='utf-8')
    assert 'planned_sample_id=planned.id if planned else None' in route
    assert 'Assigned Sampleman must be an active TSCO field sampler at this site' in route
    assert 'Once controlled planned identities exist' in route
    assert 'Requests Waiting for Operations Review' in tpl
    assert 'Assign Sampleman now' in tpl
    assert 'READY_SAMPLE_PICKUP' in route and 'COLLECTION_DELIVERY' in route and 'ON_SITE_SAMPLING' in route
    assert 'Operations approves the Sampling Order and may assign named TSCO Samplemen immediately' in supervision


def test_client_portal_exposes_per_sample_data_form_barcode_after_handover():
    route = (ROOT / 'app' / 'routes' / 'client.py').read_text(encoding='utf-8')
    tpl = (ROOT / 'app' / 'templates' / 'client_request.html').read_text(encoding='utf-8')
    service = (ROOT / 'app' / 'services' / 'planned_samples.py').read_text(encoding='utf-8')
    assert '/sample-forms/{planned_id}' in route
    assert 'SAMPLE IDENTITIES & BARCODES' in tpl
    assert 'Print and keep this sheet with the matching physical sample/carton.' in service
    assert 'Scan this barcode' in service


def test_retention_default_is_fourteen_days_and_starts_after_official_report_release():
    engine = create_engine('sqlite:///:memory:')
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        site = Site(code='DMM', name='Dammam', laboratory_name='TSCO Analytical Lab', active=True)
        db.add(site); db.flush()
        payload = blank_operations_db(site)
        assert payload['settings']['normalRetentionDays'] == 14
        assert payload['settings']['urgentRetentionDays'] == 14
    service = (ROOT / 'app' / 'services' / 'lab_operations.py').read_text(encoding='utf-8')
    assert 'activate_retention_after_report_release' in service
    assert 'or 14' in service
