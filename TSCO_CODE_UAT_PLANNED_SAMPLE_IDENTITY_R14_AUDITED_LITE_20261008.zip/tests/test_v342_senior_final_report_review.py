from __future__ import annotations

import json
from datetime import datetime
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import Asset, Client, ControlledReport, SampleRequest, Site, TechnicalAssessmentRecord, User
import app.routes.control_center as cc
from app.services.technical_review_assignments import ensure_review_assignment


def login(c: TestClient, email: str):
    r = c.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303


def logout(c: TestClient):
    c.post('/logout', follow_redirects=False)


def fake_payload(report_no='TEST'):
    return {
        'template_code': 'QDF-[7]-08-A',
        'report': {'number': report_no, 'revision': 1, 'condition': 'NORMAL', 'status': 'Technical Review', 'interpretation': '', 'recommendation': ''},
        'client': {'name': 'Saudi Electricity Company'},
        'asset': {'reference': 'TR-001', 'serial_number': 'SER-001'},
        'sample': {'request_number': 'SAMPLE-001', 'sampling_from': 'Main Tank'},
        'dga': {'columns': [{'sample_id': 999, 'number': report_no, 'date': '01/10/2026'}], 'rows': []},
        'furan': {'columns': [{'sample_id': 999, 'number': report_no, 'date': '01/10/2026'}], 'rows': []},
        'oil': {'columns': [{'sample_id': 999, 'number': report_no, 'date': '01/10/2026'}], 'rows': [
            {'test': 'Water Content KF @RT', 'unit': 'ppm', 'values': {'999': '12.4'}, 'method': 'IEC 60814', 'normal': '<30', 'caution': '>40'},
            {'test': 'Breakdown Voltage @2.5mm AVG', 'unit': 'kV', 'values': {'999': '68.2'}, 'method': 'IEC 60156', 'normal': '>40', 'caution': '<30'},
        ]},
        'corrosion': {'rows': []},
    }


def test_senior_final_report_review_is_a_required_gate(monkeypatch):
    token = uuid4().hex[:8].upper()
    with TestClient(app) as c:
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            client = db.scalar(select(Client).where(Client.code == 'SEC')); assert client
            asset = db.scalar(select(Asset).where(Asset.client_id == client.id)); assert asset
            asset.serial_number = asset.serial_number or f'SER-{token}'
            sample = SampleRequest(
                request_number=f'V342-{token}', public_token=f'PUB-{token}', barcode_value=f'BAR-{token}',
                status='TECHNICAL_REVIEW', site_id=site.id, client_id=client.id, asset_id=asset.id,
                sample_date_time=datetime.utcnow(), sampling_point='Main Tank', sample_origin='Client-Originated / Direct Delivery',
            )
            db.add(sample); db.flush()
            assignment = ensure_review_assignment(db, sample)
            assert assignment is not None
            senior = db.get(User, assignment.primary_senior_id); assert senior
            db.add(TechnicalAssessmentRecord(
                sample_request_id=sample.id, decision='APPROVED', recommendation='Proceed to final report review.', reviewed_by_id=senior.id,
            ))
            db.commit(); sid = sample.id; senior_email = senior.email

        login(c, senior_email)
        number = f'TSCO-V342-{token}'
        r = c.post('/control/report', data={
            'sample_request_id': sid, 'report_number': number, 'condition_status': 'NORMAL',
            'interpretation': '', 'recommendation': '', 'dga_requested': '', 'corrosive_requested': '', 'paper_requested': '',
            'supersedes_report_id': '', 'amendment_reason': '',
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            report = db.scalar(select(ControlledReport).where(ControlledReport.report_number == number)); assert report
            rid = report.id
            assert report.status == 'TECHNICAL_REVIEW'
            assert report.reviewed_by_id is None
        assert r.headers['location'] == f'/control/report/{rid}/review'

        # Manager cannot bypass the Senior review gate.
        logout(c); login(c, 'technical@tsco.local')
        blocked = c.post(f'/control/report/{rid}/approve', follow_redirects=False)
        assert blocked.status_code == 400
        assert 'Senior final-report review must be completed first' in blocked.text

        # The Senior workspace contains the report preview, result cards and recommendation field.
        logout(c); login(c, senior_email)
        monkeypatch.setattr(cc, 'platform_sample_lab_readiness', lambda db, sample: (True, ''))
        def payload_builder(db, row, site, verification_url=''):
            p = fake_payload(row.report_number)
            for group in ('dga','furan','oil'):
                for col in p[group]['columns']:
                    col['sample_id'] = row.sample_request_id
                for result in p[group]['rows']:
                    result['values'] = {str(row.sample_request_id): next(iter(result['values'].values()))}
            p['sample']['request_number'] = row.sample.request_number
            p['asset']['serial_number'] = row.sample.asset.serial_number
            return p
        monkeypatch.setattr(cc, 'build_final_report_payload', payload_builder)

        page = c.get(f'/control/report/{rid}/review')
        assert page.status_code == 200
        for expected in ('Final Analysis Report Preview', 'Grouped Result Review', 'Water Content KF @RT', '68.2', 'Client Recommendation', 'Senior confirmation checklist'):
            assert expected in page.text

        # Draft save persists the Senior recommendation without advancing the workflow.
        saved = c.post(f'/control/report/{rid}/review', data={
            'action': 'SAVE', 'condition_status': 'CAUTION', 'interpretation': 'Trend requires attention.',
            'recommendation': 'Repeat sampling in six months and monitor DGA trend.',
            'confirm_results': '1', 'confirm_identity': '1', 'confirm_interpretation': '1',
            'confirm_evidence': '1', 'confirm_recommendation': '1',
        }, follow_redirects=False)
        assert saved.status_code == 303
        with SessionLocal() as db:
            report = db.get(ControlledReport, rid)
            assert report.status == 'TECHNICAL_REVIEW'
            assert report.condition_status == 'CAUTION'
            assert 'six months' in report.recommendation

        # Missing one Senior confirmation blocks handoff.
        incomplete = c.post(f'/control/report/{rid}/review', data={
            'action': 'COMPLETE', 'condition_status': 'CAUTION', 'interpretation': 'Trend requires attention.',
            'recommendation': 'Repeat sampling in six months and monitor DGA trend.',
            'confirm_results': '1', 'confirm_identity': '1', 'confirm_interpretation': '1', 'confirm_evidence': '1',
        }, follow_redirects=False)
        assert incomplete.status_code == 400

        complete = c.post(f'/control/report/{rid}/review', data={
            'action': 'COMPLETE', 'condition_status': 'CAUTION', 'interpretation': 'Trend requires attention.',
            'recommendation': 'Repeat sampling in six months and monitor DGA trend.',
            'confirm_results': '1', 'confirm_identity': '1', 'confirm_interpretation': '1',
            'confirm_evidence': '1', 'confirm_recommendation': '1',
        }, follow_redirects=False)
        assert complete.status_code == 303
        with SessionLocal() as db:
            report = db.get(ControlledReport, rid); sample = db.get(SampleRequest, sid)
            assert report.status == 'PENDING_MANAGER_APPROVAL'
            assert report.reviewed_by_id is not None
            assert sample.status == 'REPORT_APPROVED'
            review = json.loads(report.report_payload_json)['senior_review']
            assert review['status'] == 'COMPLETED' and review['completed_at']
            assert all(review['confirmations'].values())


def test_real_lab_ready_sample_flows_senior_review_to_manager_release():
    from pathlib import Path
    from app.services.lab_operations import get_operations_state, save_operations_state, platform_sample_lab_readiness

    token = uuid4().hex[:8].upper()
    with TestClient(app) as c:
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            client = db.scalar(select(Client).where(Client.code == 'SEC')); assert client
            asset = db.scalar(select(Asset).where(Asset.client_id == client.id)); assert asset
            asset.serial_number = asset.serial_number or f'SER-{token}'
            chem = db.scalar(select(User).where(User.email == 'chemist@tsco.local')); assert chem
            sample = SampleRequest(
                request_number=f'V342-REAL-{token}', public_token=f'PUB-REAL-{token}', barcode_value=f'BAR-REAL-{token}',
                status='TECHNICAL_REVIEW', site_id=site.id, client_id=client.id, asset_id=asset.id,
                sample_date_time=datetime.utcnow(), sampling_point='Main Tank', sample_origin='Client-Originated / Direct Delivery',
                oil_temperature_c=45,
            )
            db.add(sample); db.flush()
            assignment = ensure_review_assignment(db, sample)
            assert assignment is not None
            senior = db.get(User, assignment.primary_senior_id); assert senior
            db.add(TechnicalAssessmentRecord(
                sample_request_id=sample.id, decision='APPROVED', recommendation='Continue routine monitoring.', reviewed_by_id=senior.id,
            ))
            state, payload = get_operations_state(db, site)
            batch_id = f'B-V342-{token}'; assignment_id = f'A-V342-{token}'
            payload.setdefault('batches', []).append({
                'id': batch_id, 'platform_sample_id': sample.id, 'platform_sample_ids': [sample.id],
                'samples': [sample.request_number], 'sample_meta': {sample.request_number: {'temp': 45}},
                'tests': [{'test': 'Water Content', 'method': 'IEC 60814', 'station': 'Water', 'unit': 'ppm'}],
                'status': 'Technical Review', 'priority': 'Normal',
            })
            payload.setdefault('results', []).append({
                'id': f'R-V342-{token}', 'sample': sample.request_number, 'test': 'WATER:KF_RT',
                'display_test': 'Water Content KF @RT', 'result': '12.4', 'unit': 'ppm', 'method': 'IEC 60814',
                'qc_status': 'PASS', 'analyst': chem.full_name, 'ts': datetime.utcnow().isoformat(),
            })
            payload.setdefault('testAssignments', []).append({
                'id': assignment_id, 'batch_id': batch_id, 'scope': 'BATCH', 'workstation': 'Water', 'mode': 'SINGLE',
                'primary_user_id': chem.id, 'primary_name': chem.full_name, 'revision': 1,
                'assigned_by': senior.full_name, 'assigned_at': datetime.utcnow().isoformat(),
            })
            payload.setdefault('assignmentCompletions', []).append({
                'id': f'C-V342-{token}', 'batch_id': batch_id, 'workstation': 'Water', 'assignment_id': assignment_id,
                'completed_by_user_id': chem.id, 'completed_by': chem.full_name, 'completed_at': datetime.utcnow().isoformat(),
            })
            save_operations_state(db, state, payload, actor=senior)
            db.commit(); sid = sample.id; senior_email = senior.email
            ready, reason = platform_sample_lab_readiness(db, sample)
            assert ready, reason

        login(c, senior_email)
        number = f'TSCO-V342-REAL-{token}'
        created = c.post('/control/report', data={
            'sample_request_id': sid, 'report_number': number, 'condition_status': 'NORMAL',
            'interpretation': '', 'recommendation': '', 'dga_requested': '', 'corrosive_requested': '', 'paper_requested': '',
            'supersedes_report_id': '', 'amendment_reason': '',
        }, follow_redirects=False)
        assert created.status_code == 303
        with SessionLocal() as db:
            report = db.scalar(select(ControlledReport).where(ControlledReport.report_number == number)); rid = report.id

        review_page = c.get(f'/control/report/{rid}/review')
        assert review_page.status_code == 200
        assert 'Water Content KF @RT' in review_page.text and '12.4' in review_page.text
        assert 'READY FOR SENIOR SIGN-OFF' in review_page.text

        completed = c.post(f'/control/report/{rid}/review', data={
            'action': 'COMPLETE', 'condition_status': 'NORMAL',
            'interpretation': 'Water content is within the reviewed normal condition for this sample.',
            'recommendation': 'Continue routine monitoring and repeat sampling at the normal interval.',
            'confirm_results': '1', 'confirm_identity': '1', 'confirm_interpretation': '1',
            'confirm_evidence': '1', 'confirm_recommendation': '1',
        }, follow_redirects=False)
        assert completed.status_code == 303, completed.text[:300]

        logout(c); login(c, 'technical@tsco.local')
        manager_review = c.get(f'/control/report/{rid}/review')
        assert manager_review.status_code == 200
        assert 'Continue routine monitoring' in manager_review.text
        blocked = c.post(f'/control/report/{rid}/approve', follow_redirects=False)
        assert blocked.status_code == 400
        internal = c.post(
            f'/control/report/{rid}/manager-review',
            data={'action': 'APPROVE_INTERNAL', 'comment': 'Internal package reviewed before official release.'},
            follow_redirects=False,
        )
        assert internal.status_code == 303, internal.text[:500]
        released = c.post(f'/control/report/{rid}/approve', follow_redirects=False)
        assert released.status_code == 303, released.text[:500]
        with SessionLocal() as db:
            report = db.get(ControlledReport, rid); sample = db.get(SampleRequest, sid)
            assert report.status == 'REPORT_RELEASED' and sample.status == 'REPORT_RELEASED'
            assert report.official_pdf_path and Path(report.official_pdf_path).is_file()
            assert report.official_pdf_sha256 and len(report.official_pdf_sha256) == 64
