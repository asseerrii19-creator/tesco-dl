from types import SimpleNamespace

from app.routes import control_center
from app.services import final_report_data, report_ordering, technical_assessment
from app.services.lab_operations import _lab_sample_metadata


def test_official_ltd_thresholds_and_equal_boundary_are_controlled():
    expected = {
        'Dibenzyl Disulfide (DBDS)': '0.5',
        'Peroxide Number': '0.1',
        'Total Mercaptan (RSH)': '0.1',
        'Hydrogen Sulfide Gas (H2S)': '0.1',
        'Toluene': '0.1',
        'Total Acid Number': '0.01',
        '2-Furfural (2FAL)': '0.01',
        'Passivator (Irgamet 39)': '0.01',
        'Antioxidant (BHT)': '0.01',
    }
    for test, dl in expected.items():
        assert final_report_data.REPORT_SPECS[test]['dl'] == dl
        assert final_report_data._report_display_result(test, dl, detection_limit=dl) == 'LTD'
        assert final_report_data._report_display_result(test, float(dl) / 2, detection_limit=dl) == 'LTD'
        assert final_report_data._report_display_result(test, float(dl) * 2, detection_limit=dl) != 'LTD'


def test_dga_dl_values_are_ltd_and_diagnostic_ratios_do_not_use_censored_values():
    for gas in ('Hydrogen (H2)','Methane (CH4)','Ethane (C2H6)','Ethylene (C2H4)','Acetylene (C2H2)','Carbon Monoxide (CO)','Carbon Dioxide (CO2)'):
        assert final_report_data._report_display_result(gas, 1, detection_limit=1) == 'LTD'
        assert final_report_data._report_display_result(gas, 0, detection_limit=1) == 'LTD'
    # A zero/below-DL denominator is not a valid basis for an IEC ratio.
    assert technical_assessment._iec_dga_fault({'H2':7.4,'CH4':2.27,'C2H6':0,'C2H4':1.96,'C2H2':0}) is None


def test_water_family_exact_subsection_order():
    names = [
        'Water Content KF @RT','Transformer Oil Temperature','Water Content @20 °C',
        'Humidity in Cellulose','Relative Saturation Water in Oil','Mineral Oil Log Cw','Cw',
        'Breakdown Voltage @2.5mm AVG','RSD% of BDV @2.5mm',
        'Power Factor @25°C/60Hz','Power Factor @100°C/60Hz',
        'Room Test Temperature','Room Test Humidity',
    ]
    assert sorted(names, key=lambda x: report_ordering.report_sort_key(x, 'Water / BDV / PF / Lab Room Conditions')) == names


def test_water_24_is_not_poor_under_controlled_report_band():
    assert technical_assessment._band(24, lambda v: v < 30, lambda v: 30 <= v <= 40) == 'GOOD'
    assert technical_assessment._band(35, lambda v: v < 30, lambda v: 30 <= v <= 40) == 'FAIR'
    assert technical_assessment._band(45, lambda v: v < 30, lambda v: 30 <= v <= 40) == 'POOR'


def test_dga_source_filename_cannot_reference_another_sample():
    assert control_center._dga_source_identity_matches('FS-DMM-26-000003', 'DGA_UAT_FS-DMM-26-000003.csv')
    assert not control_center._dga_source_identity_matches('FS-DMM-26-000003', 'DGA_UAT_FS-DMM-26-000004.csv')
    assert control_center._dga_source_identity_matches('FS-DMM-26-000003', 'instrument-export.csv')


def test_intake_metadata_does_not_fabricate_lab_room_from_field_ambient():
    sample = SimpleNamespace(
        oil_temperature_c=48.0, sampling_point='Bottom', request_number='FS-DMM-26-000003',
        lms_number=None, asset=SimpleNamespace(asset_code='A', serial_number='S', station_name='ST', asset_location_label='LOC'),
        quotation=None, purchase_order=None, barcode_value='B', submission_channel='CLIENT', priority='URGENT',
        required_tat='24H', requested_method_family='DEFAULT', requested_tests_json='[]', due_at=None, sampling_assignment=None, commercial_case_id=None,
    )
    meta = _lab_sample_metadata(SimpleNamespace(), sample)
    assert 'roomTemp' not in meta and 'roomHumidity' not in meta


def test_review_and_release_surfaces_require_client_report_confirmation():
    senior = open('app/templates/senior_final_report_review.html', encoding='utf-8').read()
    route = open('app/routes/control_center.py', encoding='utf-8').read()
    assert 'confirm_client_preview' in senior
    assert 'confirm_client_preview' in route
    assert 'TECHNICAL SIGN-OFF → LAB OPERATIONAL & TECHNICAL MANAGER' in senior
    assert 'READY FOR FINAL RELEASE' in senior
    assert 'APPROVE MANAGER REVIEW → READY FOR FINAL RELEASE' in senior
    assert 'INTERNAL APPROVED · READY FOR FINAL RELEASE' in senior
    assert 'client_preview_snapshot' in route and 'client_preview_sha256' in route
    assert 'Client-report snapshot integrity check failed' in route


def test_client_report_has_one_ltd_legend_and_official_not_template_wording():
    preview = open('app/templates/controlled_report_preview.html', encoding='utf-8').read()
    assert preview.count('LTD = Less Than Detection Limit') == 1
    assert 'LDT/LTD' not in preview
    assert 'OFFICIAL ANALYSIS REPORT' in preview
    assert 'OFFICIAL CLIENT REPORT TEMPLATE' not in preview
    assert 'Back to Sample Dashboard' in preview


def test_pdf_uses_dynamic_family_pagination_and_no_single_report_fake_trend():
    pdf = open('app/services/final_report_pdf.py', encoding='utf-8').read()
    data = open('app/services/final_report_data.py', encoding='utf-8').read()
    assert 'Test families stay in the agreed order' in pdf
    assert "if len(reports) >= 2 and sum(v is not None for v in values) >= 2" in data
    assert 'FINAL ASSESSMENT & AUTHORIZATION' in pdf


def test_public_verification_uses_human_status_and_identity_fields():
    html = open('app/templates/report_verify.html', encoding='utf-8').read()
    assert 'VERIFIED · VALID CONTROLLED REPORT' in html
    assert 'Officially Released' in html
    assert 'REVIEWED BY' in html and 'APPROVED BY' in html and 'RELEASED AT' in html
    assert '<b>{{report.status}}</b>' not in html


def test_partial_multi_sample_release_status_is_supported():
    commercial = open('app/services/commercial.py', encoding='utf-8').read()
    request = open('app/templates/client_request.html', encoding='utf-8').read()
    client_route = open('app/routes/client.py', encoding='utf-8').read()
    assert "target_status = 'PARTIALLY_RELEASED'" in commercial
    assert 'PARTIALLY_RELEASED' in request
    assert '_client_orderable_test_names' in client_route
    assert 'line.requested_tests_display = ", ".join(requested)' in client_route
