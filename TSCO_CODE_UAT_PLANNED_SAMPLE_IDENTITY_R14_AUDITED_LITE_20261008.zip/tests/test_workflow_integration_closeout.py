from pathlib import Path
from types import SimpleNamespace

from fastapi.testclient import TestClient

from app.main import app
from app.services.lab_operations import platform_sample_lab_projection_from_payload


def _sample():
    return SimpleNamespace(id=777, request_number='FS-DMM-26-TEST777', lms_number=None, status='TESTING')


def _payload(complete=False):
    sample = _sample()
    batch = {
        'id': 'LB-INTEGRATION-1',
        'platform_sample_id': sample.id,
        'samples': [sample.request_number],
        'tests': [
            {'test': 'Total Acid Number', 'method': 'ASTM D664', 'station': 'TAN / Peroxide / RSH / H2S'},
            {'test': 'Breakdown Voltage @2.5mm- AVG', 'method': 'IEC 60156', 'station': 'Electrical'},
        ],
        'status': 'Testing',
    }
    payload = {
        'batches': [batch],
        'results': [
            {'id': 'R-TAN', 'sample': sample.request_number, 'test': 'Total Acid Number', 'result': '0.03', 'qc_status': 'PASS'},
        ],
        'testAssignments': [
            {'id': 'A-TAN', 'batch_id': batch['id'], 'workstation': 'TAN / Peroxide / RSH / H2S', 'revision': 1},
            {'id': 'A-EL', 'batch_id': batch['id'], 'workstation': 'Electrical', 'revision': 1},
        ],
        'assignmentCompletions': [
            {'id': 'C-TAN', 'batch_id': batch['id'], 'workstation': 'TAN / Peroxide / RSH / H2S', 'assignment_id': 'A-TAN', 'completed_at': '2026-10-05T12:00:00'},
        ],
        'retests': [],
        'qc': [],
    }
    if complete:
        payload['results'].append({'id': 'R-BDV', 'sample': sample.request_number, 'test': 'Breakdown Voltage @2.5mm- AVG', 'result': '68.0', 'qc_status': 'PASS'})
        payload['assignmentCompletions'].append({'id': 'C-EL', 'batch_id': batch['id'], 'workstation': 'Electrical', 'assignment_id': 'A-EL', 'completed_at': '2026-10-05T12:01:00'})
    return sample, payload


def test_canonical_projection_exposes_exact_missing_result_and_workstation_blockers():
    sample, payload = _payload(False)
    row = platform_sample_lab_projection_from_payload(payload, sample)
    assert row['tests_complete'] == 1
    assert row['tests_required'] == 2
    assert row['workstations_closed'] == 1
    assert row['workstations_required'] == 2
    assert 'Breakdown Voltage @2.5mm- AVG' in row['missing_tests']
    assert row['open_workstations'] == ['Water / BDV / PF / Room Conditions']
    assert row['ready_for_technical_review'] is False
    assert row['blocker'].startswith('Missing laboratory result(s):')
    assert any('Workstation closeout pending: Water / BDV / PF / Room Conditions' in x for x in row['blockers'])


def test_canonical_projection_becomes_review_ready_only_after_results_and_closeouts_are_complete():
    sample, payload = _payload(True)
    row = platform_sample_lab_projection_from_payload(payload, sample)
    assert row['tests_complete'] == 2
    assert row['workstations_closed'] == 2
    assert row['blockers'] == []
    assert row['ready_for_technical_review'] is True


def test_senior_primary_navigation_uses_server_queue_not_browser_supervisor_mirror():
    base = (Path(__file__).resolve().parents[1] / 'app' / 'templates' / 'base.html').read_text()
    queue = (Path(__file__).resolve().parents[1] / 'app' / 'templates' / 'lab_workspace.html').read_text()
    assert "item('/lab','My Technical Review','TR','/lab')" in base
    assert "item('/lab/operations?section=supervisor','My Technical Review'" not in base
    assert 'Canonical Laboratory Workflow' in queue
    assert 'Current blocker / next action' in queue


def test_embedded_console_boot_is_server_first_and_read_only_tracking_does_not_autosave():
    source = (Path(__file__).resolve().parents[1] / 'app' / 'lab_ops' / 'index_template.html').read_text()
    assert 'autoDerivedCalculations();renderAll();bootstrapStorage();' not in source
    assert 'bootstrapStorage();' in source
    assert "const READ_ONLY_PLATFORM_VIEW=['dashboard','labprogress','tracking','finalreport','knowledge'].includes(CURRENT_PLATFORM_SECTION);" in source
    assert 'if(!READ_ONLY_PLATFORM_VIEW)scheduleCloudSave()' in source


def test_operations_and_management_use_same_server_workflow_language():
    ops = (Path(__file__).resolve().parents[1] / 'app' / 'templates' / 'operations_overview.html').read_text()
    mgmt = (Path(__file__).resolve().parents[1] / 'app' / 'templates' / 'management.html').read_text()
    assert 'Laboratory & Report Journey' in ops
    assert 'Current blocker / next step' in ops
    assert 'Sample Workflow Monitor' in mgmt
    assert 'Current blocker / next step' in mgmt


def _login(client: TestClient, email: str):
    r = client.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303


def test_server_rendered_tracking_surfaces_render_for_senior_operations_and_manager():
    with TestClient(app) as client:
        _login(client, 'senior.technical@tsco.local')
        senior = client.get('/lab')
        assert senior.status_code == 200
        assert 'Canonical Laboratory Workflow' in senior.text
        assert 'NO BROWSER STATE' in senior.text

        client.get('/logout')
        _login(client, 'operations@tsco.local')
        ops = client.get('/operations')
        assert ops.status_code == 200
        assert 'Laboratory &amp; Report Journey' in ops.text or 'Laboratory & Report Journey' in ops.text

        client.get('/logout')
        _login(client, 'technical@tsco.local')
        mgmt = client.get('/management')
        assert mgmt.status_code == 200
        assert 'Sample Workflow Monitor' in mgmt.text


def test_senior_login_home_and_legacy_supervisor_routes_land_on_canonical_queue():
    with TestClient(app) as client:
        r = client.post('/login', data={'email': 'senior.technical@tsco.local', 'password': 'Demo123!'}, follow_redirects=False)
        assert r.status_code == 303
        home = client.get('/', follow_redirects=False)
        assert home.status_code == 303
        assert home.headers['location'] == '/lab'
        legacy = client.get('/lab/operations?section=supervisor', follow_redirects=False)
        assert legacy.status_code == 303
        assert legacy.headers['location'] == '/lab'
        legacy_app = client.get('/lab/operations/app?embed=1&section=supervisor', follow_redirects=False)
        assert legacy_app.status_code == 303
        assert legacy_app.headers['location'] == '/lab'
        page = client.get('/lab')
        assert page.status_code == 200
        assert 'Canonical Laboratory Workflow' in page.text
        assert 'NO BROWSER STATE' in page.text


def test_senior_sidebar_does_not_expose_legacy_browser_operations_overview():
    base = (Path(__file__).resolve().parents[1] / 'app' / 'templates' / 'base.html').read_text()
    assert "user.role == 'technical_manager' %}{{ item('/management','Operations Overview'" in base
    assert "item('/lab/operations?section=dashboard','Operations Overview'" not in base


def test_read_only_browser_views_cannot_schedule_or_force_merge_autosave():
    source = (Path(__file__).resolve().parents[1] / 'app' / 'lab_ops' / 'index_template.html').read_text()
    assert 'function scheduleCloudSave(){if(READ_ONLY_PLATFORM_VIEW)return;' in source
    assert "if(READ_ONLY_PLATFORM_VIEW&&operation==='merge'){setSyncState('connected','READ ONLY');return false}" in source
    assert 'function saveDraftInput(el){if(READ_ONLY_PLATFORM_VIEW)return;' in source


def test_no_visible_senior_or_operations_links_point_to_retired_or_forbidden_tracking_surfaces():
    senior_resp = (Path(__file__).resolve().parents[1] / 'app' / 'templates' / 'senior_responsibilities.html').read_text()
    ops = (Path(__file__).resolve().parents[1] / 'app' / 'templates' / 'operations_overview.html').read_text()
    admin = (Path(__file__).resolve().parents[1] / 'app' / 'templates' / 'admin_dashboard.html').read_text()
    lab = (Path(__file__).resolve().parents[1] / 'app' / 'templates' / 'lab_workspace.html').read_text()
    assert '/lab/operations?section=supervisor' not in senior_resp
    assert 'href="/lab">Open Laboratory Queue' not in ops
    assert 'href="/intake">Track direct intake' not in ops
    assert 'href="/lab/operations?section=dashboard"' not in admin
    assert 'href="/lab/operations?section=labprogress"' not in admin
    assert 'href="/field"' not in admin
    assert '/lab/operations?section=dashboard">Laboratory Detail' not in lab


def test_retired_browser_supervisor_dashboard_sections_are_not_role_authority_for_senior_or_technical_manager():
    from app.lab_sections import LAB_ROLE_SECTIONS
    assert 'supervisor' not in LAB_ROLE_SECTIONS['senior_chemist']
    assert 'dashboard' not in LAB_ROLE_SECTIONS['senior_chemist']
    assert 'supervisor' not in LAB_ROLE_SECTIONS['technical_manager']
    assert 'dashboard' not in LAB_ROLE_SECTIONS['technical_manager']


def test_key_tracking_role_landings_and_visible_links_are_authorized():
    import html as html_lib
    import re
    accounts = {
        'senior.technical@tsco.local': '/lab',
        'technical@tsco.local': '/management',
        'operations@tsco.local': '/operations',
        'admin@tsco.local': '/admin',
    }
    href_re = re.compile(r'<a[^>]+href="([^"]+)"')
    redirects = {301,302,303,307,308}
    with TestClient(app) as client:
        for email, expected in accounts.items():
            client.get('/logout')
            _login(client, email)
            home = client.get('/', follow_redirects=False)
            assert home.status_code == 303, (email, home.status_code)
            assert home.headers['location'] == expected, (email, home.headers.get('location'))
            page = client.get(expected, follow_redirects=False)
            assert page.status_code == 200, (email, expected, page.status_code)
            links = {html_lib.unescape(x) for x in href_re.findall(page.text) if html_lib.unescape(x).startswith('/')}
            assert links, (email, 'no links')
            for href in sorted(links):
                response = client.get(href, follow_redirects=False)
                assert response.status_code < 500, (email, href, response.status_code)
                assert response.status_code != 403, (email, href, 'visible link forbidden')
                # A visible link may intentionally redirect to its canonical server surface,
                # but it must never redirect back into retired supervisor/dashboard mirrors.
                if response.status_code in redirects:
                    target = response.headers.get('location','')
                    assert 'section=supervisor' not in target and 'section=dashboard' not in target, (email, href, target)


def _two_sample_payload():
    s1 = SimpleNamespace(id=901, request_number='FS-DMM-26-000003', lms_number=None, status='TESTING')
    s2 = SimpleNamespace(id=902, request_number='FS-DMM-26-000004', lms_number=None, status='TESTING')
    batch = {
        'id': 'LB-TWO-SAMPLE-UAT',
        'platform_sample_ids': [901,902],
        'samples': [s1.request_number, s2.request_number],
        'tests': [
            {'test':'Breakdown Voltage @2.5mm- AVG','method':'IEC 60156','station':'Electrical'},
            {'test':'Power Factor @25°C/60Hz','method':'ASTM D924','station':'Electrical'},
            {'test':'Power Factor @100°C/60Hz','method':'ASTM D924','station':'Electrical'},
            {'test':'Total Acid Number','method':'ASTM D664','station':'TAN / Peroxide / RSH / H2S'},
        ],
        'status':'Testing',
    }
    payload = {
        'batches':[batch],
        'results':[],
        'testAssignments':[
            {'id':'A-EL','batch_id':batch['id'],'workstation':'Electrical','revision':1},
            {'id':'A-TAN','batch_id':batch['id'],'workstation':'TAN / Peroxide / RSH / H2S','revision':1},
        ],
        'assignmentCompletions':[],
        'retests':[], 'qc':[],
    }
    for sample in (s1,s2):
        for test,value in [
            ('Breakdown Voltage @2.5mm- AVG','68.0'),
            ('Power Factor @25°C/60Hz','0.0008'),
            ('Power Factor @100°C/60Hz','0.0085'),
            ('Total Acid Number','0.03'),
        ]:
            payload['results'].append({'id':f'R-{sample.id}-{test}','sample':sample.request_number,'test':test,'result':value,'qc_status':'PASS'})
    return s1,s2,payload,batch


def test_two_sample_batch_requires_both_workstation_closeouts_then_both_samples_become_review_ready():
    s1,s2,payload,batch = _two_sample_payload()
    before1 = platform_sample_lab_projection_from_payload(payload,s1)
    before2 = platform_sample_lab_projection_from_payload(payload,s2)
    assert before1['tests_complete'] == before1['tests_required'] == 4
    assert before2['tests_complete'] == before2['tests_required'] == 4
    assert before1['ready_for_technical_review'] is False
    assert set(before1['open_workstations']) == {'Water / BDV / PF / Room Conditions','TAN / RSH / Peroxide'}
    payload['assignmentCompletions'] = [
        {'id':'C-EL','batch_id':batch['id'],'workstation':'Electrical','assignment_id':'A-EL','completed_at':'2026-10-05T20:00:00'},
        {'id':'C-TAN','batch_id':batch['id'],'workstation':'TAN / Peroxide / RSH / H2S','assignment_id':'A-TAN','completed_at':'2026-10-05T20:01:00'},
    ]
    after1 = platform_sample_lab_projection_from_payload(payload,s1)
    after2 = platform_sample_lab_projection_from_payload(payload,s2)
    assert after1['workstations_closed'] == after1['workstations_required'] == 2
    assert after2['workstations_closed'] == after2['workstations_required'] == 2
    assert after1['blockers'] == [] and after2['blockers'] == []
    assert after1['ready_for_technical_review'] is True
    assert after2['ready_for_technical_review'] is True
