from types import SimpleNamespace

from app.routes import control_center


class FakeDB:
    def __init__(self, site):
        self.site = site

    def get(self, model, key):
        return self.site


def test_exact_sample_dga_workstation_source_satisfies_bridge(monkeypatch):
    site = SimpleNamespace(id=1)
    sample = SimpleNamespace(request_number='FS-DMM-26-000003')
    row = SimpleNamespace(site_id=1, sample=sample)
    payload = {
        'dgaAttachments': [
            {'sample':'FS-DMM-26-000004','kind':'result-import','name':'wrong.csv','data':'data:text/csv;base64,WA==','ts':'2026-10-07T01:00:00'},
            {'sample':'FS-DMM-26-000003','kind':'instrument-report','name':'report.pdf','data':'data:application/pdf;base64,WA==','ts':'2026-10-07T01:01:00'},
            {'sample':'FS-DMM-26-000003','kind':'result-import','name':'source.csv','data':'data:text/csv;base64,WA==','ts':'2026-10-07T01:02:00'},
        ]
    }
    monkeypatch.setattr(control_center, 'get_operations_state', lambda db, site: (None, payload))
    found = control_center._operations_dga_source(FakeDB(site), row)
    assert found is not None
    assert found['sample'] == 'FS-DMM-26-000003'
    assert found['name'] == 'source.csv'


def test_other_sample_dga_source_does_not_cross_satisfy(monkeypatch):
    site = SimpleNamespace(id=1)
    sample = SimpleNamespace(request_number='FS-DMM-26-000003')
    row = SimpleNamespace(site_id=1, sample=sample)
    payload = {'dgaAttachments': [
        {'sample':'FS-DMM-26-000004','kind':'result-import','name':'other.csv','data':'data:text/csv;base64,WA==','ts':'2026-10-07T01:00:00'},
    ]}
    monkeypatch.setattr(control_center, 'get_operations_state', lambda db, site: (None, payload))
    assert control_center._operations_dga_source(FakeDB(site), row) is None


def test_quality_evidence_tab_has_fallback_upload_form():
    html = open('app/templates/quality_center.html', encoding='utf-8').read()
    assert 'Attach Controlled Evidence' in html
    assert 'action="/control/evidence"' in html
    assert 'DGA_SOURCE' in html
