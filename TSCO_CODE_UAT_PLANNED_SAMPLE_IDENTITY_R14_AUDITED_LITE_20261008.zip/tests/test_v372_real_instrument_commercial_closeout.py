from datetime import datetime
from io import BytesIO
from pathlib import Path

from reportlab.pdfgen import canvas
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.database import Base
from app.models import Client, CommercialCase, Site
from app.routes.lab_operations import _parse_dga_result_pdf_bytes, _bdv_evidence_pdf
from app.services.commercial import ensure_sales_order, next_stage

ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / 'app' / 'lab_ops' / 'index_template.html').read_text(encoding='utf-8')


def _dga_fixture_pdf() -> bytes:
    buf = BytesIO()
    c = canvas.Canvas(buf)
    y = 800
    rows = [
        'Gulf Laboratory Technical Services QDF [7]-07-c',
        'Sample# 4185 Method: IEC',
        'Run# 1679',
        'Date 15/Jun/2026 20:19',
        'Calibration Date 15/3/2026',
        'Hydrogen (H2) 0.0 0.0 <1.0',
        'Oxygen (O2) 4350.6 4235.1 -',
        'Nitrogen (N2) 19257.7 18746.5 -',
        'Ethylene (C2H4) 0.8 0.8 <1.0',
        'Ethane (C2H6) 6.3 6.2 <1.0',
        'Acetylene (C2H2) 0.0 0.0 <1.0',
        'Methane (CH4) 2.4 2.3 <1.0',
        'Carbon Monoxide (CO) 12.6 12.3 <1.0',
        'Carbon Dioxide (CO2) 109.6 106.7 <1.0',
        'TCG (Total Combustible Gases) (IEEE) 0.0 %',
        'Total Volume of Gas 2.3 %',
        'Equilibrium Gas Pressure @ 40 C 228 hPa',
        'TCG (Total Combustible Gases) 22 ppm',
    ]
    for row in rows:
        c.drawString(40, y, row)
        y -= 20
    c.save()
    return buf.getvalue()


def test_real_dga_pdf_maps_to_existing_result_values():
    parsed = _parse_dga_result_pdf_bytes(_dga_fixture_pdf())
    assert parsed['sample_number'] == '4185'
    assert parsed['method_family'] == 'IEC'
    assert parsed['variant'] == 'BOTTOM'
    assert parsed['complete'] is True
    assert parsed['gases'] == {
        'H2': 0.0, 'O2': 4235.1, 'N2': 18746.5,
        'C2H4': 0.8, 'C2H6': 6.2, 'C2H2': 0.0,
        'CH4': 2.3, 'CO': 12.3, 'CO2': 106.7,
    }
    assert parsed['derived']['TCG'] == 22.0
    assert parsed['derived']['TVG'] == 2.3
    assert parsed['derived']['EQP40'] == 228.0


def test_dga_workstation_uses_real_pdf_without_changing_result_model():
    assert 'Original DGA Result PDF' in HTML
    assert 'class="dga-pdf"' in HTML
    assert "'/lab-operations/dga/parse-pdf'" in HTML
    assert "test:'DGA:'+k" in HTML
    assert "test:'DGA_CALC:'+k" in HTML
    assert "source:'DGA result PDF'" in HTML
    assert "type:'application/pdf',kind:'result-import'" in HTML


def test_bdv_cumulative_import_and_single_sample_evidence_are_present():
    assert 'BDV Instrument Export (cumulative CSV)' in HTML
    assert 'parseElectricalCsv(text,sample)' in HTML
    assert "'bdv-instrument-source'" in HTML
    assert "kind:'bdv-result-sheet'" in HTML
    assert 'instrument_record_id' in HTML
    assert '/lab-operations/bdv/result-sheet' in HTML
    name, pdf = _bdv_evidence_pdf({
        'sample': 'DM-26007295', 'method': 'IEC 60156',
        'runs': [60.9, 63.6, 61.1, 58.2, 51.2, 61.1],
        'average': 59.35, 'rsd': 7,
        'meta': {'testId': '7295', 'serialNumber': '101067478', 'testName': 'IEC 60156-2018'},
    })
    assert name == 'DM-26007295_BDV_Instrument_Result.pdf'
    assert pdf.startswith(b'%PDF-')


def test_sales_order_policy_one_request_except_aramco_monthly_pool():
    engine = create_engine('sqlite:///:memory:')
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        site = Site(code='DMM', name='Dammam', laboratory_name='TSCO Analytical Lab', active=True)
        arm = Client(code='ARM', name='Saudi Arabian Oil Company (Aramco)', active=True)
        sec = Client(code='SEC', name='Saudi Electricity Company', active=True)
        db.add_all([site, arm, sec]); db.flush()
        cases = [
            CommercialCase(case_code='R13-ARM-1', site_id=site.id, client_id=arm.id, client=arm),
            CommercialCase(case_code='R13-ARM-2', site_id=site.id, client_id=arm.id, client=arm),
            CommercialCase(case_code='R13-ARM-3', site_id=site.id, client_id=arm.id, client=arm),
            CommercialCase(case_code='R13-SEC-1', site_id=site.id, client_id=sec.id, client=sec),
            CommercialCase(case_code='R13-SEC-2', site_id=site.id, client_id=sec.id, client=sec),
        ]
        db.add_all(cases); db.flush()
        arm_oct_1 = ensure_sales_order(db, cases[0], at=datetime(2026, 10, 8)); db.flush()
        arm_oct_2 = ensure_sales_order(db, cases[1], at=datetime(2026, 10, 24)); db.flush()
        arm_nov = ensure_sales_order(db, cases[2], at=datetime(2026, 11, 1)); db.flush()
        sec_1 = ensure_sales_order(db, cases[3], at=datetime(2026, 10, 8)); db.flush()
        sec_2 = ensure_sales_order(db, cases[4], at=datetime(2026, 10, 8))
        assert arm_oct_1 == arm_oct_2
        assert arm_nov != arm_oct_1
        assert sec_1 != sec_2
        assert all(x.startswith('TIC-SO426') for x in (arm_oct_1, sec_1, sec_2, arm_nov))

def test_coordinator_account_ownership_and_post_release_invoice_boundary():
    client_source = (ROOT / 'app' / 'routes' / 'client.py').read_text(encoding='utf-8')
    seed_source = (ROOT / 'app' / 'seed.py').read_text(encoding='utf-8')
    commercial_source = (ROOT / 'app' / 'services' / 'commercial.py').read_text(encoding='utf-8')
    assert "clients[\"ARM\"]" in seed_source
    assert '"client.coordinator@tsco.local"' in seed_source
    assert '"external.coordination@tsco.local"' in seed_source
    assert 'non_aramco_pool' in client_source and 'aramco_ids' in client_source
    assert 'one Sales Order per client/site/calendar month' in commercial_source
    assert 'partial release must never open the invoice stage early' in commercial_source
    control_source = (ROOT / 'app' / 'routes' / 'control_center.py').read_text(encoding='utf-8')
    assert 'all_released=bool(linked_samples)' in control_source
    assert 'Lab completed · invoice required' in control_source
    assert next_stage('FINAL_REPORT_RELEASE') == 'INVOICING'
    assert next_stage('REPORT_SUBMISSION') == 'INVOICING'



def test_bdv_real_megger_cumulative_csv_parser_matches_sample_suffix_and_method_runs():
    import json as _json
    import subprocess
    csv_text = """resultId,instrumentType,serialNumber,firmwareVersion,stdLibVersion,testId,dateTime,dateFormat,testName,electrodeType,electrodeGap,gapUnits,stirrerType,oilType,tripSetting,testNotes,oilTemperature,temperatureUnits,voltageRate,resultCount,maxVoltage,result1,result2,result3,result4,result5,result6,result7,result8,result9,result10,result11,result12,averageVoltage,dispersion,stdDeviation,range,validationParam,validationValue,validationResult,reserved1,reserved2,reserved3,reserved4,reserved5,reserved6\n4,8,101067478,1.02,0.06,2250,1776010308,1,IEC 60156-95,1,2.5,mm,1,1,1,,18,C,2000,6,1000,72.2,64.4,61.4,76.4,81.3,73,0,0,0,0,0,0,71.4,0.1,7.41,19.9,0,0,Pass,1,0,0,0,0,0\n6,8,101067478,1.02,0.06,2017,1776081563,1,ASTM D 1816-04,1,1,mm,2,1,1,,18,C,500,5,1000,40.3,37,40.7,28.8,41.5,0,0,0,0,0,0,0,37.7,0.14,5.24,12.7,120,45.2,Pass,2,0,0,0,0,0\n"""
    start = HTML.index('function _csvRows')
    end = HTML.index('function roomConditionPanel', start)
    funcs = HTML[start:end]
    script = funcs + "\n" + f"const a=parseElectricalCsv({_json.dumps(csv_text)},'DM-26002250'); const b=parseElectricalCsv({_json.dumps(csv_text)},'DM-26002017'); console.log(JSON.stringify({{a,b}}));"
    out = subprocess.check_output(['node', '-e', script], text=True)
    parsed = _json.loads(out)
    assert parsed['a']['meta']['testId'] == '2250'
    assert parsed['a']['meta']['serialNumber'] == '101067478'
    assert list(parsed['a']['runs'].values()) == [72.2, 64.4, 61.4, 76.4, 81.3, 73]
    assert parsed['a']['meta']['resultCount'] == 6
    assert parsed['b']['meta']['testName'] == 'ASTM D 1816-04'
    assert list(parsed['b']['runs'].values()) == [40.3, 37, 40.7, 28.8, 41.5]
    assert parsed['b']['meta']['resultCount'] == 5


def test_dga_pdf_parser_detects_tap_changer_astm_without_changing_result_model():
    buf = BytesIO()
    c = canvas.Canvas(buf)
    y = 800
    rows = [
        'Gulf Laboratory Technical Services Company QDF [7]-07-C',
        'DGA Tap Changer (ASTM D 3612-C)',
        'Sample # BH0000',
        'Hydrogen (H2) 45 48.0 <5',
        'Oxygen (O2) 25000 26679.4 -',
        'Nitrogen (N2) 63000 67232.0 -',
        'Ethylene (C2H4) 30 32.0 <1',
        'Ethane (C2H6) 50 53.4 <1',
        'Acetylene (C2H2) 1 1.1 <1',
        'Methane (CH4) 70 74.7 <1',
        'Carbon Monoxide (CO) 400 426.9 <25',
        'Carbon Dioxide (CO2) 4000 4268.7 <25',
        'TCG (Total Combustible Gases) 636.1 ppm',
        'Total Volume of Gas 9.9 %',
        'TDHG 161.0',
        'C2H4/C2H2 29.1',
        'TDHG/C2H2 146.4',
    ]
    for row in rows:
        c.drawString(40, y, row); y -= 20
    c.save()
    parsed = _parse_dga_result_pdf_bytes(buf.getvalue())
    assert parsed['method_family'] == 'ASTM'
    assert parsed['variant'] == 'TAP_CHANGER'
    assert parsed['complete'] is True
    assert parsed['derived']['TDHG'] == 161.0
    assert parsed['derived']['C2H4_C2H2'] == 29.1
    assert parsed['derived']['TDHG_C2H2'] == 146.4


def test_bdv_result_sheet_endpoint_returns_data_url_key_used_by_workstation():
    source = (ROOT / 'app' / 'routes' / 'lab_operations.py').read_text(encoding='utf-8')
    assert '"data_url": data_url' in source
    assert "data:bdvSheet.data_url||''" in HTML


def test_invoice_registration_captures_real_invoice_references_and_date_fields():
    tpl = (ROOT / 'app' / 'templates' / 'commercial_flow.html').read_text(encoding='utf-8')
    service = (ROOT / 'app' / 'services' / 'commercial.py').read_text(encoding='utf-8')
    route = (ROOT / 'app' / 'routes' / 'commercial.py').read_text(encoding='utf-8')
    for marker in ('Invoice Date', 'invoice_contract_number', 'invoice_ses_number', 'authoritative invoice PDF'):
        assert marker in tpl
    assert 'invoice_date: str = ""' in service
    assert 'datetime.strptime(invoice_date.strip(), "%Y-%m-%d")' in service
    assert 'invoice_date: str = Form("")' in route


def test_sample_profile_displays_quotation_po_and_sales_order_linkage():
    assert '<span>QUOTATION</span>' in HTML
    assert '<span>PO</span>' in HTML
    assert '<span>SALES ORDER</span>' in HTML
    assert "m.salesOrder||'—'" in HTML
