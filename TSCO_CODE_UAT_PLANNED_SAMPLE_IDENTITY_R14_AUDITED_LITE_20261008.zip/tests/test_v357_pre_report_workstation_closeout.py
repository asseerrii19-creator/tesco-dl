from pathlib import Path

from app.services.lab_operations import (
    _ensure_corrosion_result_pair,
    _qc_source_package_test,
    _result_qc_context,
    _sample_complete,
    _workstation_complete,
)

ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / 'app' / 'lab_ops' / 'index_template.html').read_text(encoding='utf-8')


def test_workstation_copy_is_clean_and_role_neutral_before_report_uat():
    for bad in (
        'Only workstations assigned to the authenticated chemist',
        'FIXED WORKSTATION CONTROL',
        'Controlled completion:',
        'DGA results — file first:',
        'six IEC/ASTM breakdown runs',
        'Complete the fixed Analytical QC panel',
    ):
        assert bad not in HTML
    assert 'Only workstations assigned to you are shown.' in HTML
    assert 'Workstation closeout' in HTML


def test_electrical_ui_respects_method_defined_bdv_run_counts_and_all_requested_methods():
    assert 'IEC 60156 uses 6 breakdowns; ASTM D1816/D877 use 5.' in HTML
    assert "nums.length>=5" in HTML
    assert "runVals.length!==need" in HTML
    assert "Number(formula.series||runVals.length)+' original run statistics'" in HTML
    assert "excluded_runs:excluded" in HTML
    assert "rsd_display_integer:true" in HTML
    assert "bdvStatus=e.bdv.map" in HTML
    assert 'BDV method / gap' in HTML
    assert 'PF Instrument Result File (CSV)' in HTML


def test_linked_workstations_are_grouped_by_sample_not_scattered_by_test():
    assert 'function renderGroupedSampleTests' in HTML
    assert "WS_TAN='TAN / RSH / Peroxide'" in HTML
    assert "WS_GC='DBDS / Toluene / BHT / PCB'" in HTML
    assert "WS_CORROSION='Corrosive Sulfur / Flash Point / Metals'" in HTML
    assert 'renderGroupedSampleTests(b,tests,WS_TAN)' in HTML
    assert 'renderGroupedSampleTests(b,tests,WS_GC)' in HTML


def test_corrosive_sulfur_always_has_status_and_tarnish_companion():
    rows = _ensure_corrosion_result_pair([
        {'test': 'Corrosive Sulfur', 'method': 'ASTM D1275b', 'station': 'Corrosion / CCD', 'unit': 'Pass/Fail'}
    ])
    assert [row['test'] for row in rows] == ['Corrosive Sulfur', 'Tarnish Level']
    assert rows[1]['method'].upper() == 'ASTM D1275B'
    assert rows[1]['station'] == 'Corrosive Sulfur / Flash Point / Metals'
    assert rows[1]['unit'] == '1a–4c'

    # Idempotent when a controlled package already contains the companion result.
    assert len(_ensure_corrosion_result_pair(rows)) == 2


def test_tarnish_is_linked_to_parent_qc_not_a_second_artificial_qc_event():
    rows = _ensure_corrosion_result_pair([
        {'test': 'Corrosive Sulfur', 'method': 'ASTM D1275b', 'station': 'Corrosion / CCD', 'unit': 'Pass/Fail'}
    ])
    assert _qc_source_package_test(rows[0])
    assert not _qc_source_package_test(rows[1])
    batch = {'id': 'B-CORR', 'tests': rows}
    ctx = _result_qc_context(batch, {'test': 'Tarnish Level', 'display_test': 'Tarnish Level'})
    assert ctx['test'] == 'Corrosive Sulfur'
    assert ctx['method'].upper() == 'ASTM D1275B'
    assert ctx['workstation'] == 'Corrosive Sulfur / Flash Point / Metals'
    assert ctx['group'] == 'Corrosive Sulfur'


def test_corrosion_ui_uses_controlled_status_and_classification_values():
    assert "const CORROSIVE_STATUS_OPTIONS=['Non-corrosive','Corrosive']" in HTML
    assert "const PASS_FAIL_OPTIONS=['Pass','Fail']" in HTML
    assert "const TARNISH_OPTIONS=['1a','1b','2a','2b','2c','2d','2e','3a','3b','4a','4b','4c']" in HTML
    assert "if(/^corrosive sulfur$/i.test(t))return CORROSIVE_STATUS_OPTIONS" in HTML
    assert "if(/^potentially corrosive sulfur \\(ccd\\)$/i.test(t))return PASS_FAIL_OPTIONS" in HTML


def test_physical_assignment_can_close_before_cross_workstation_oqi_but_sample_cannot():
    sample = 'S-OQI-1'
    batch = {
        'id': 'B-OQI', 'samples': [sample],
        'tests': [
            {'test': 'Interfacial Tension (IFT)', 'method': 'ASTM D971', 'station': 'Physical / Chemistry'},
            {'test': 'Oil Quality Index', 'method': 'calculation', 'station': 'Physical / Chemistry'},
        ],
    }
    payload = {
        'batches': [batch],
        'results': [{'id': 'R-IFT', 'sample': sample, 'batch': batch['id'], 'test': 'Interfacial Tension (IFT)', 'result': '40'}],
    }
    assert _workstation_complete(payload, batch, 'Physical / Chemistry')
    assert not _sample_complete(payload, sample)

    payload['results'].append({'id': 'R-OQI', 'sample': sample, 'batch': batch['id'], 'test': 'Oil Quality Index', 'result': '4000', 'calculated': True})
    assert _sample_complete(payload, sample)


def test_dga_still_requires_all_nine_gases_before_workstation_closeout():
    keys = ('H2','O2','N2','CH4','CO','CO2','C2H4','C2H6','C2H2')
    sample = 'S-DGA-1'
    batch = {'id':'B-DGA','samples':[sample],'tests':[{'test':'Dissolved Gas Analysis (DGA)','method':'IEC 60567','station':'DGA'}]}
    payload = {'batches':[batch], 'results':[{'id':f'R-{k}','sample':sample,'batch':'B-DGA','test':f'DGA:{k}','result':'1'} for k in keys[:-1]]}
    assert not _workstation_complete(payload,batch,'DGA')
    payload['results'].append({'id':'R-C2H2','sample':sample,'batch':'B-DGA','test':'DGA:C2H2','result':'1'})
    assert _workstation_complete(payload,batch,'DGA')


def test_water_and_existing_specialized_flows_remain_present():
    for marker in (
        'SAVE BOTH READINGS + AVERAGE',
        'WATER_DUAL_AVERAGE',
        'Import Original GC/TOGA Results CSV',
        'DGA RESULTS COMPLETE',
        'SAVE 2-FAL + CALCULATE',
        'COMPLETE MY ASSIGNMENT',
    ):
        assert marker in HTML
