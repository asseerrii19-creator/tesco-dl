#!/usr/bin/env bash
set -euo pipefail
MARKER="TSCO-PLANNED-SAMPLE-IDENTITY-CLOSEOUT-20261008-R14"
echo "TSCO_BUILD_MARKER=${MARKER}"
echo "TSCO_RELEASE_AUTHORITY_SCOPE=R13_BASELINE+PREGENERATED_SAMPLE_IDENTITY+BARCODE_MATCH+OPERATIONS_ROUTING+14D_RETENTION"
python -m compileall -q app migrations
for f in app/static/app.js app/static/field-form.js app/static/service-worker.js; do node --check "$f"; done
python - <<'PY'
from pathlib import Path
from jinja2 import Environment
import re
for f in [
    'app/templates/intake_queue.html','app/templates/intake_review.html','app/templates/operations_dashboard.html',
    'app/templates/sampling_supervision.html','app/templates/client_request.html'
]:
    Environment().parse(Path(f).read_text(encoding='utf-8'))
html=Path('app/lab_ops/index_template.html').read_text(encoding='utf-8')
parts=re.findall(r'<script[^>]*>(.*?)</script>',html,re.S)
if len(parts)!=1:
    raise SystemExit(f'Expected one inline Laboratory Operations script, found {len(parts)}')
Path('/tmp/tsco_lab_ops_release.js').write_text(parts[0], encoding='utf-8')
print('TSCO_TEMPLATE_PARSE_ASSERTION=PASS')
PY
node --check /tmp/tsco_lab_ops_release.js
echo "TSCO_CODE_SYNTAX_ASSERTION=PASS"
python - <<'PY'
from pathlib import Path
p=Path('app/lab_ops/index_template.html')
html=p.read_text(encoding='utf-8')
required=[
    'Analytical QC — Result Validity','DGA QC / CRM Instrument CSV','Original DGA Result PDF',
    '/lab-operations/dga/parse-pdf',"source:'DGA result PDF'",'DGA RESULTS COMPLETE','Required gases:',
    'BDV Instrument Export (cumulative CSV)','parseElectricalCsv(text,sample)','/lab-operations/bdv/result-sheet',
    "'bdv-instrument-source'","kind:'bdv-result-sheet'",'instrument_record_id','bdvSheet.data_url',
    'PF Instrument Result File (CSV)','IEC 60156 uses 6 breakdowns; ASTM D1816/D877 use 5.',
    'function applyAnalyticalQcActionLocks()','SAVE BOTH READINGS + AVERAGE','WATER_DUAL_AVERAGE',
    'function reconcile409AndRetry(localPayload)', 'function equipmentClassSupportsContext',
    "if((STORAGE.dirty||STORAGE.saving)&&!force)return false;", 'normalRetentionDays:14',
]
missing=[x for x in required if x not in html]
if missing:
    raise SystemExit('R14 Laboratory Operations assertion failed; missing: '+', '.join(missing))
print('TSCO_REAL_INSTRUMENT_AND_RETENTION_UI_ASSERTION=PASS')
PY
python - <<'PY'
from pathlib import Path
version=Path('VERSION').read_text(encoding='utf-8').strip()
expected='3.7.3-R14-PLANNED-SAMPLE-IDENTITY-CLOSEOUT-20261008'
if version != expected:
    raise SystemExit(f'Unexpected R14 VERSION: {version}')
models=Path('app/models.py').read_text(encoding='utf-8')
planned=Path('app/services/planned_samples.py').read_text(encoding='utf-8')
commercial=Path('app/services/commercial.py').read_text(encoding='utf-8')
intake=Path('app/routes/intake.py').read_text(encoding='utf-8')
field=Path('app/routes/field.py').read_text(encoding='utf-8')
operations=Path('app/routes/operations.py').read_text(encoding='utf-8')
client=Path('app/routes/client.py').read_text(encoding='utf-8')
for marker in ('class PlannedSample','planned_sample_id','barcode_value','data_form_pdf_path'):
    if marker not in models:
        raise SystemExit(f'Planned-sample model marker missing: {marker}')
for marker in ('ensure_planned_samples','generate_planned_data_form_pdf','next_request_identifiers','Print and keep this sheet'):
    if marker not in planned:
        raise SystemExit(f'Planned-sample service marker missing: {marker}')
if 'ensure_planned_samples(db, case)' not in commercial:
    raise SystemExit('Complete Handover does not pre-generate controlled sample identities')
for marker in ('/match-barcode','EXPECTED_BARCODE_MATCH_AND_RECEIVE','claim_planned_identity(planned, sample)','physical_receipt_completed'):
    if marker not in intake:
        raise SystemExit(f'Intake identity marker missing: {marker}')
for marker in ('planned.barcode_value','planned.request_number','claim_planned_identity(planned, sample)'):
    if marker not in field:
        raise SystemExit(f'Field identity marker missing: {marker}')
for marker in ('available_planned_for_line','planned_sample_id=planned.id if planned else None','assigned_sampler_id'):
    if marker not in operations:
        raise SystemExit(f'Operations identity/assignment marker missing: {marker}')
if '/sample-forms/{planned_id}' not in client:
    raise SystemExit('Client sample-specific Data Form route missing')
print('TSCO_PLANNED_SAMPLE_IDENTITY_ASSERTION=PASS')
PY
python - <<'PY'
from pathlib import Path
models=Path('app/models.py').read_text(encoding='utf-8')
commercial=Path('app/services/commercial.py').read_text(encoding='utf-8')
client=Path('app/routes/client.py').read_text(encoding='utf-8')
for marker in ('sales_order_number','sales_order_year','sales_order_month','invoice_contract_number','invoice_ses_number'):
    if marker not in models:
        raise SystemExit(f'Commercial model marker missing: {marker}')
for marker in ('ensure_sales_order','TIC-SO4','one Sales Order per client/site/calendar month','FINAL_REPORT_RELEASE", "REPORT_SUBMISSION'):
    if marker not in commercial:
        raise SystemExit(f'Commercial workflow marker missing: {marker}')
for marker in ('UserClientAssignment','non_aramco_pool','aramco_ids'):
    if marker not in client:
        raise SystemExit(f'Coordinator routing marker missing: {marker}')
seed=Path('app/seed.py').read_text(encoding='utf-8')
if 'external.coordination@tsco.local' not in seed or 'client.coordinator@tsco.local' not in seed:
    raise SystemExit('Active two-coordinator UAT ownership markers missing')
print('TSCO_COMMERCIAL_CLOSEOUT_ASSERTION=PASS')
PY
python - <<'PY'
from pathlib import Path
migration=Path('migrations/versions/f17c4a8d2b90_v373_planned_sample_identity_closeout.py').read_text(encoding='utf-8')
if "revision = 'f17c4a8d2b90'" not in migration or "down_revision = 'e82a4b7c9d13'" not in migration:
    raise SystemExit('R14 migration lineage assertion failed')
if "batch_alter_table('sampling_assignments')" not in migration:
    raise SystemExit('R14 SQLite-safe sampling-assignment migration assertion failed')
print('TSCO_R14_MIGRATION_ASSERTION=PASS')
PY
if [[ "$(alembic heads | awk '{print $1}')" != "f17c4a8d2b90" ]]; then
  echo "Unexpected Alembic head" >&2
  alembic heads >&2
  exit 1
fi
echo 'TSCO_ALEMBIC_HEAD_ASSERTION=PASS'
rm -f /tmp/tsco_r14_migration.db
DATABASE_URL=sqlite:////tmp/tsco_r14_migration.db alembic upgrade head >/tmp/tsco_r14_migration.log 2>&1
if ! grep -q 'f17c4a8d2b90' /tmp/tsco_r14_migration.log; then
  cat /tmp/tsco_r14_migration.log >&2
  echo 'Fresh SQLite migration did not reach R14 head' >&2
  exit 1
fi
echo 'TSCO_FRESH_MIGRATION_ASSERTION=PASS'
if [[ -f app/reference_documents/catalog.json ]]; then
  echo 'TSCO_REFERENCE_ASSETS=LOCAL_PRESENT'
else
  echo 'TSCO_REFERENCE_ASSETS=LITE_EXTERNAL'
fi
# Current R14 authority: preserve the audited R13 real-instrument/commercial behavior and
# add stable request-time sample identities, physical barcode matching, Operations routing,
# and the controlled 14-calendar-day retention policy.
pytest -q \
  tests/test_v373_planned_sample_identity_closeout.py \
  tests/test_v372_real_instrument_commercial_closeout.py \
  tests/test_v371_uat_release_hardening.py \
  tests/test_v368_consolidated_review_qc_closeout.py \
  tests/test_v369_uat_dga_evidence_bridge.py \
  tests/test_v370_uat_consolidated_closeout.py \
  tests/test_v359_qc_append_only_matrix.py \
  tests/test_v367_post_senior_report_experience.py \
  tests/test_v353_uat_blocker_closeout.py \
  tests/test_closeout_result_rules.py \
  tests/test_v354_electrical_qc_closeout.py::test_live_equipment_mapping_has_controlled_fallbacks \
  tests/test_v354_electrical_qc_closeout.py::test_rsd_is_derived_child_not_independent_electrical_entry \
  tests/test_v355_uat_behavioral_closeout.py::test_iec60156_six_run_average_and_rsd_are_server_verified_as_one_run_set \
  tests/test_v355_uat_behavioral_closeout.py::test_iec60156_rejects_missing_sixth_breakdown \
  tests/test_v355_uat_behavioral_closeout.py::test_astm_bdv_keeps_method_defined_five_run_protocol \
  tests/test_v355_uat_behavioral_closeout.py::test_live_equipment_resolver_has_exact_controlled_assets_for_current_blockers \
  tests/test_v356_dga_results_closeout.py::test_dga_workstation_requires_full_controlled_nine_gas_set \
  tests/test_v356_dga_results_closeout.py::test_dga_uat_csv_fixtures_cover_qc_and_all_nine_results
echo 'TSCO_RELEASE_CHECK=PASS'
