# Final Package Manifest — v3.7.2 / R13

Package type: **AUDITED LITE code package**  
Release: `3.7.2-R13-REAL-INSTRUMENT-COMMERCIAL-CLOSEOUT-20261008`

## Included
- Full FastAPI application and templates from R12 baseline plus R13 additive changes
- Real cumulative BDV CSV import + duplicate protection + generated single-sample evidence PDF
- Real QDF DGA result PDF import into the existing DGA result model
- Commercial Demo Price Master and quotation preview
- Sales Order generation / Aramco monthly reuse policy
- Client-account Coordinator routing
- Post-release Coordinator invoice notification and invoice registration fields
- New Alembic migration `e82a4b7c9d13`
- R13 release test `tests/test_v372_real_instrument_commercial_closeout.py`
- Deployment/runbook files and retained historical closeout records
- R13 closeout and final verification records

## Intentionally external
`app/reference_documents` source bytes are not bundled in the LITE archive. Existing deployment must overlay `TSCO_REFERENCE_ASSETS.zip` before application install/start.

## Intentionally excluded
- runtime/test SQLite databases
- `.pytest_cache`, `__pycache__`, `.pyc`
- runtime uploads / generated reports / secrets
- user-provided real instrument files used for local validation

## Database
R13 is an in-place update with one new migration. **Do not reset or replace the existing database.** Run `alembic upgrade head` as part of normal startup.
