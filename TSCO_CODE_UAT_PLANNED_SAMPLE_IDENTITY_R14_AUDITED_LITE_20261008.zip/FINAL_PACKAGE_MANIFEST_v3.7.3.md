# Final Package Manifest — v3.7.3 / R14

Package type: **AUDITED LITE code package**  
Release: `3.7.3-R14-PLANNED-SAMPLE-IDENTITY-CLOSEOUT-20261008`

## Included
- Full FastAPI application/templates from R13 baseline plus R14 additive intake/operations changes
- `PlannedSample` controlled pre-arrival identity model
- Stable per-sample Sample ID / public token / barcode generation at Complete Handover
- Client sample-specific Data Form + barcode PDF generation / print route
- Expected Arrivals individual barcode matching in Data Entry
- One-action barcode match + Data Acceptance + TSCO Registration + Physical Receipt for expected client-delivered samples
- Same-barcode receiving path for TSCO field-sampled / pickup samples already materialized by Sampleman
- Operations Manager direct Sampleman assignment with note/instructions while preserving Sampling Supervisor visibility/reassignment
- Planned-identity binding for On-site Sampling / Ready Sample Pickup / Collection Delivery
- In-place legacy/UAT sample backfill without duplicate expected sample creation
- Corrected default retained-sample period of 14 calendar days after official report release
- R13 real BDV cumulative CSV import, real DGA result PDF import and commercial/Sales Order/invoice closeout retained unchanged
- New Alembic migration `f17c4a8d2b90`
- New R14 release test `tests/test_v373_planned_sample_identity_closeout.py`
- R14 closeout / verification / manifest records

## Intentionally external
`app/reference_documents` source bytes are not bundled in the LITE archive. Existing deployment must overlay `TSCO_REFERENCE_ASSETS.zip` before application install/start.

## Intentionally excluded
- runtime/test SQLite databases
- `.pytest_cache`, `__pycache__`, `.pyc`
- runtime uploads, generated barcodes/reports and secrets
- user-provided instrument/commercial files used for UAT validation

## Database
R14 is an in-place update from R13 with one new migration. **Do not reset or replace the existing database.** Run `alembic upgrade head` as part of normal startup.
