# Final Verification — v3.7.3 / R14

Release: `3.7.3-R14-PLANNED-SAMPLE-IDENTITY-CLOSEOUT-20261008`  
Baseline: v3.7.2 / R13  
Alembic head: `f17c4a8d2b90`

## Verified release gates
- Python compilation: PASS
- Static JavaScript syntax: PASS
- Jinja template parse for changed intake/operations/client pages: PASS
- Laboratory Operations inline JavaScript syntax: PASS
- R13 real BDV / DGA behavior retained: PASS
- Planned-sample identity assertions: PASS
- Commercial closeout assertions: PASS
- Alembic single-head assertion: PASS
- Fresh SQLite migration from empty database through R14 head: PASS
- R14 + retained authoritative regression set: **78 passed / 0 failed**
- `TSCO_RELEASE_CHECK=PASS`

## Planned identity / barcode validation
- One approved request line quantity produces one stable Sample ID + barcode per expected physical sample: PASS.
- Generation is idempotent; reopening Intake / Client Portal does not renumber or duplicate identities: PASS.
- Existing pre-R14 SampleRequests are backfilled as MATERIALIZED planned identities using their existing request number/barcode/token instead of creating duplicate expected samples: PASS.
- Client Portal sample-specific printable Data Form/barcode route: PASS.
- Data Entry barcode match uses the same pre-generated identity: PASS.
- Client-delivered expected barcode can complete match + acceptance + TSCO registration + physical receipt and move to Smart Batch Cards: PASS.
- Field/pickup SampleRequest can be re-matched at Data Entry by the same pre-generated barcode without creating a second SampleRequest: PASS.

## Operations validation
- Approved field/pickup handovers are visible to Operations Manager: PASS.
- Operations assignment supports On-site Sampling / Ready Sample Pickup / Collection Delivery: PASS.
- Operations Manager can select a named active TSCO Sampleman during assignment creation: PASS.
- Assignment is linked to the existing Planned Sample ID where controlled identities exist: PASS.
- Sampling Supervisor can see/manage the same assignment rather than creating duplicate field work: PASS.
- Exhausted planned identities do not fall back to legacy quantity math and create extra assignments: PASS.

## Retained sample validation
- New operations-state default: 14 calendar days: PASS.
- Former 15-day UAT default is normalized to 14 while non-default explicit settings remain preserved: PASS.
- Retention timer still starts after official TSCO report release: PASS.
- Storage allocation / retained-sample location model unchanged: PASS.

## Deployment compatibility
R14 requires migration `f17c4a8d2b90` but **does not require a database reset**. Keep the current database and persistent controlled-file storage. Startup continues to run `alembic upgrade head` before Uvicorn.

The LITE code archive intentionally excludes `app/reference_documents`; continue overlaying the existing `TSCO_REFERENCE_ASSETS.zip` before application install/start, exactly as in R12/R13.

## Post-deploy UAT focus
1. Complete one Request with 3 samples and verify 3 Sample IDs/barcodes are generated after handover under one Sales Order.
2. Client Portal: open/print each sample-specific Data Form and confirm correct barcode/sample identity.
3. Client Delivery: scan one barcode at Data Entry → verify serial/Data Form → Match + Accept Physical Sample → confirm the same Sample ID appears in Smart Batch Cards.
4. TSCO On-site Sampling: Operations Manager creates order, assigns Sampleman with note, Sampleman completes the pre-generated sample, then Data Entry scans the same barcode and receives it without a duplicate ID.
5. TSCO Pickup: repeat with Ready Sample Pickup and verify collection task differs while identity/receiving path stays the same.
6. Release batch to Laboratory and confirm requested tests are inherited from the Request.
7. Confirm retained-storage location is assigned by the existing workflow and the retention timer remains inactive until final report release, then starts at 14 days.
8. Recheck R13 BDV cumulative CSV and DGA PDF imports to confirm no regression.
