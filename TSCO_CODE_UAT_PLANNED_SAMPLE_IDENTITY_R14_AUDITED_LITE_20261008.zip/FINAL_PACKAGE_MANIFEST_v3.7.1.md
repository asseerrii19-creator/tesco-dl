# Final Package Manifest — v3.7.1 / R12

Package type: **AUDITED LITE code package**
Release: `3.7.1-R12-UAT-RELEASE-HARDENING-20261007`

## Included
- FastAPI application and templates
- Laboratory Operations workstation application
- controlled report / client portal / QR verification changes
- migrations (unchanged head retained)
- release tests including `test_v371_uat_release_hardening.py`
- deployment/runbook files
- historical closeout records retained for traceability
- R12 closeout and final verification records

## Intentionally external
`app/reference_documents` source bytes are not bundled in the LITE archive. Existing deployment overlays `TSCO_REFERENCE_ASSETS.zip` before installation/startup.

## Database
No reset and no new migration required. Current head remains `d65f7a9b2c10`.
