from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from urllib.parse import quote_plus

from fastapi import APIRouter, Depends, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import Client, MonthlyClosePeriod, Role, Site, EquipmentAsset, SampleRequest, ControlledReport
from ..lab_sections import LAB_ROLE_SECTIONS, LAB_SECTION_INFO
from ..security import require_user
from ..services.lab_operations import blank_operations_db, get_operations_state, merge_scoped_operations_update, package_catalog, reconcile_operations_to_platform, save_operations_state, scope_operations_payload, validate_operations_update
from ..services.audit import add_audit
from ..services.final_report_data import canonical_test_name
from ..services.report_ordering import REPORT_GROUP_ORDER, report_group_key, report_group_label, report_sort_key, report_display_result, is_raw_water_instrument_row

router = APIRouter(tags=["integrated laboratory operations"])
ALLOWED = {
    Role.LAB_TECHNICIAN.value, Role.SENIOR_CHEMIST.value, Role.QUALITY.value,
    Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value,
}
WRITE_ALLOWED = ALLOWED
BASE_DIR = Path(__file__).resolve().parents[1]
TEMPLATE_FILE = BASE_DIR / "lab_ops" / "index_template.html"

SECTION_INFO = LAB_SECTION_INFO
ROLE_SECTIONS = LAB_ROLE_SECTIONS

def _script_json(value) -> str:
    """Serialize data for an inline <script> without allowing HTML/script termination."""
    return (
        json.dumps(value, ensure_ascii=False)
        .replace("&", "\\u0026")
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("\u2028", "\\u2028")
        .replace("\u2029", "\\u2029")
    )


def _site_for_user(db: Session, user) -> Site:
    site = db.get(Site, user.site_id) if user.site_id else None
    if not site:
        site = db.query(Site).filter(Site.code == "DMM").first()
    return site


def _authorized_section(user, requested: str) -> str:
    allowed = ROLE_SECTIONS.get(user.role, set())
    if not allowed:
        raise HTTPException(status_code=403, detail="This role has no Laboratory Operations workspace")
    requested = (requested or "").strip()
    if not requested:
        preferred = ["workstations", "supervisor", "quality", "labprogress", "dashboard", "knowledge"]
        return next((item for item in preferred if item in allowed), sorted(allowed)[0])
    if requested not in SECTION_INFO:
        raise HTTPException(status_code=404, detail="Laboratory section not found")
    if requested not in allowed:
        raise HTTPException(status_code=403, detail="This laboratory section is not authorized for the current role")
    return requested


DISPLAY_ALLOWED = {Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value}


def _operations_records_context(db: Session, user, site: Site) -> dict:
    """Canonical server-side result/QC history used by Senior and Lab Manager records views."""
    _, payload = get_operations_state(db, site)
    rows = []
    for row in payload.get("results", []):
        if not isinstance(row, dict):
            continue
        rows.append({
            "date": str(row.get("ts") or ""), "sample": str(row.get("sample") or ""),
            "test": str(row.get("display_test") or row.get("test") or ""), "result": str(row.get("result") or ""),
            "unit": str(row.get("unit") or ""), "employee": str(row.get("analyst") or row.get("by") or "TSCO Server"),
            "batch": str(row.get("batch") or row.get("batch_id") or ""), "type": "RESULT",
        })
    for row in payload.get("qc", []):
        if not isinstance(row, dict) or str(row.get("mode") or "routine").lower() == "qualify":
            continue
        rows.append({
            "date": str(row.get("ts") or ""), "sample": str(row.get("sample") or "QC"),
            "test": str(row.get("test") or row.get("group") or "Analytical QC"), "result": str(row.get("result") or row.get("status") or ""),
            "unit": str(row.get("unit") or ""), "employee": str(row.get("analyst") or ""),
            "batch": str(row.get("batch_id") or ""), "type": "QC",
        })
    rows.sort(key=lambda x: x["date"], reverse=True)
    samples = {r["sample"] for r in rows if r["sample"] and r["sample"] != "QC"}
    employees = {r["employee"] for r in rows if r["employee"]}
    retests = [r for r in payload.get("retests", []) if isinstance(r, dict)]
    sample_groups = []
    for sample_no in sorted(samples, key=lambda value: max((r["date"] for r in rows if r["sample"] == value), default=""), reverse=True):
        items = [r for r in rows if r["sample"] == sample_no and r["type"] == "RESULT"]
        sample_row = db.query(SampleRequest).filter(SampleRequest.site_id == site.id, SampleRequest.request_number == sample_no).first()
        sample_groups.append({
            "sample": sample_no, "rows": items, "count": len(items),
            "last_date": max((r["date"] for r in items), default=""),
            "employees": sorted({r["employee"] for r in items if r["employee"]}),
            "status": sample_row.status if sample_row else "RECORDED",
            "client": sample_row.client.name if sample_row and sample_row.client else "—",
            "asset": sample_row.asset.asset_code if sample_row and sample_row.asset else "—",
        })
    qc_rows = [r for r in rows if r["type"] == "QC"]
    qc_groups = []
    for test_name in sorted({r["test"] for r in qc_rows if r["test"]}):
        items = [r for r in qc_rows if r["test"] == test_name]
        qc_groups.append({"test": test_name, "rows": items, "count": len(items), "last_date": max((r["date"] for r in items), default="")})
    return {
        "records": rows[:500], "record_groups": sample_groups, "qc_groups": qc_groups,
        "record_result_count": sum(1 for r in rows if r["type"] == "RESULT"),
        "record_qc_count": sum(1 for r in rows if r["type"] == "QC"), "record_retest_count": len(retests),
        "record_sample_count": len(samples), "record_employee_count": len(employees),
    }




def _worksheet_context(db: Session, user, site: Site) -> dict:
    """Server-authoritative QDF [7]-07-E register using the same family order as Senior/client review."""
    _, payload = get_operations_state(db, site)
    by_sample: dict[str, list[dict]] = {}
    for row in payload.get("results", []):
        if not isinstance(row, dict):
            continue
        sample_no = str(row.get("sample") or "").strip()
        if not sample_no:
            continue
        raw_test = str(row.get("display_test") or row.get("test") or "")
        if is_raw_water_instrument_row(raw_test) or is_raw_water_instrument_row(str(row.get("test") or "")):
            # Dual-instrument Water readings remain in the audit/result stream; QDF [7]-07-E shows the controlled final average only.
            continue
        test = canonical_test_name(row)
        by_sample.setdefault(sample_no, []).append({
            "date": str(row.get("ts") or row.get("timestamp") or ""),
            "test": test,
            "method": str(row.get("method") or row.get("test_method") or "—"),
            "result": report_display_result(test, row.get("result") or "—"),
            "unit": str(row.get("unit") or ""),
            "chemist": str(row.get("analyst") or row.get("by") or "TSCO Server"),
            "group_key": report_group_key(test),
        })
    sample_rows = (db.query(SampleRequest).filter(SampleRequest.site_id == site.id)
                   .order_by(SampleRequest.created_at.desc()).limit(300).all())
    report_rows = (db.query(ControlledReport).filter(ControlledReport.site_id == site.id)
                   .order_by(ControlledReport.revision.desc(), ControlledReport.created_at.desc()).all())
    report_by_sample = {}
    for report in report_rows:
        report_by_sample.setdefault(report.sample_request_id, report)
    worksheets = []
    for sample in sample_rows:
        source_results = sorted(by_sample.get(sample.request_number, []), key=lambda row: row["date"])
        latest_by_test: dict[str, dict] = {}
        for result in source_results:
            latest_by_test[result["test"]] = result

        # Compatibility fallback for batches created before room conditions were saved as result rows.
        batch = next((b for b in payload.get("batches", []) if sample.request_number in [str(x) for x in b.get("samples", [])]), None)
        meta = ((batch or {}).get("sample_meta") or {}).get(sample.request_number, {}) if batch else {}
        room_fallbacks = [
            ("Room Test Temperature", meta.get("roomTemp") or (batch or {}).get("roomTemp"), "°C"),
            ("Room Test Humidity", meta.get("roomHumidity") or (batch or {}).get("roomHumidity"), "%RH"),
        ]
        for test, value, unit in room_fallbacks:
            if test not in latest_by_test and value not in (None, "", "—"):
                latest_by_test[test] = {
                    "date": str(meta.get("roomConditionAt") or (batch or {}).get("roomConditionAt") or (batch or {}).get("created_at") or ""),
                    "test": test, "method": "Operational input", "result": str(value), "unit": unit,
                    "chemist": str(meta.get("roomConditionBy") or (batch or {}).get("roomConditionBy") or "Water / BDV / PF assignee"),
                    "group_key": "water_electrical",
                }
        results = sorted(latest_by_test.values(), key=lambda row: report_sort_key(row["test"]))
        if not results and sample.status not in {"TECHNICAL_REVIEW", "REPORT_APPROVED", "REPORT_RELEASED"}:
            continue
        groups = []
        for key in REPORT_GROUP_ORDER:
            rows = [r for r in results if r.get("group_key") == key]
            if rows:
                groups.append({"key": key, "label": report_group_label(key), "rows": rows})
        worksheets.append({
            "sample": sample, "results": results, "groups": groups, "result_count": len(results),
            "report": report_by_sample.get(sample.id),
            "last_result_at": max((row["date"] for row in results), default=""),
        })
    return {"worksheets": worksheets, "worksheet_count": len(worksheets)}


@router.get("/lab/result-worksheets")
def result_worksheets(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    site = _site_for_user(db, user)
    context = _worksheet_context(db, user, site)
    return templates.TemplateResponse("internal_worksheets.html", {"request": request, "user": user, "site": site, **context})


@router.get("/lab/display")
def laboratory_display(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, DISPLAY_ALLOWED)
    return templates.TemplateResponse("lab_display.html", {"request": request, "user": user})


@router.get("/lab/operations")
def operations_shell(request: Request, section: str = "", workstation: str = "", db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    requested = (section or "").strip()
    # Senior/Technical Manager supervisory tracking is server-rendered from the canonical
    # SampleRequest + OperationsState projection. Do not open the legacy browser-state
    # supervisor/dashboard mirror for these roles.
    if user.role == Role.SENIOR_CHEMIST.value and requested in {"", "supervisor", "dashboard"}:
        return RedirectResponse("/lab", status_code=303)
    if user.role == Role.TECHNICAL_MANAGER.value and requested == "dashboard":
        return RedirectResponse("/management", status_code=303)
    if user.role == Role.TECHNICAL_MANAGER.value and requested == "supervisor":
        return RedirectResponse("/lab", status_code=303)
    if requested == "tracking" and user.role in {Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value}:
        site = _site_for_user(db, user)
        context = _operations_records_context(db, user, site)
        return templates.TemplateResponse("operations_records.html", {"request": request, "user": user, **context})
    if requested == "finalreport":
        return RedirectResponse("/lab/result-worksheets", status_code=303)
    section = _authorized_section(user, section)
    title, description = SECTION_INFO[section]
    if user.role == Role.LAB_TECHNICIAN.value and section == "quality":
        title = "Analytical / Test QC"
        description = "Assigned analytical QC required before routine result entry."
    allowed_sections = ROLE_SECTIONS.get(user.role, {section})
    visible_info = {k: {"title": SECTION_INFO[k][0], "description": SECTION_INFO[k][1]} for k in allowed_sections if k in SECTION_INFO}
    return templates.TemplateResponse(
        "lab_operations.html",
        {"request": request, "user": user, "section": section, "section_title": title, "section_description": description, "section_info": visible_info, "workstation": workstation, "workstation_query": quote_plus(workstation)},
    )


@router.get("/lab/operations/app", response_class=HTMLResponse)
def operations_console(request: Request, section: str = "", workstation: str = "", embed: int = 1, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    requested = (section or "").strip()
    if user.role == Role.SENIOR_CHEMIST.value and requested in {"", "supervisor", "dashboard"}:
        return RedirectResponse("/lab", status_code=303)
    if user.role == Role.TECHNICAL_MANAGER.value and requested == "dashboard":
        return RedirectResponse("/management", status_code=303)
    if user.role == Role.TECHNICAL_MANAGER.value and requested == "supervisor":
        return RedirectResponse("/lab", status_code=303)
    if requested == "tracking" and user.role in {Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value}:
        return RedirectResponse("/lab/operations?section=tracking", status_code=303)
    if requested == "finalreport":
        return RedirectResponse("/lab/result-worksheets", status_code=303)
    section = _authorized_section(user, section)
    html = TEMPLATE_FILE.read_text(encoding="utf-8")
    site = _site_for_user(db, user)
    active_clients = db.query(Client).filter(Client.active.is_(True)).order_by(Client.name).all()
    central_clients = [{"id": str(row.id), "name": row.name, "code": row.code, "active": True} for row in active_clients]
    central_packages = package_catalog(db, site.id)
    equipment_rows = db.query(EquipmentAsset).filter(EquipmentAsset.site_id == site.id).order_by(EquipmentAsset.equipment_id).all()
    analytical_equipment = [{
        "id": row.id, "equipment_id": row.equipment_id, "name": row.name,
        "workstation": row.workstation or "", "test_method": row.test_method or "",
        "status": row.status or "", "active": bool(row.active),
        "next_calibration_at": row.next_calibration_at.isoformat() if row.next_calibration_at else "",
        "next_verification_at": row.next_verification_at.isoformat() if row.next_verification_at else "",
    } for row in equipment_rows]
    from ..models import ControlledDocument
    from ..storage import CONTROLLED_DOCUMENT_DIR
    docs = db.query(ControlledDocument).filter(ControlledDocument.status.in_(["ACTIVE", "REFERENCE"])).all()
    docs = [d for d in docs if d.site_id in {None, user.site_id} and (CONTROLLED_DOCUMENT_DIR / Path(d.stored_filename).name).is_file()]
    docs.sort(key=lambda d: (d.status == "ACTIVE", d.site_id == user.site_id, d.created_at), reverse=True)
    available_docs = [{
        "id": d.id,
        "code": d.code,
        "type": d.document_type,
        "title": d.title,
        "status": d.status,
        "revision": d.revision,
        "workstation": d.workstation or "",
        "test": d.test_name or "",
        "method": d.method_name or "",
        "file": f"/documents/{d.id}/download",
    } for d in docs]
    embed_css = """
    <style id="platformEmbedStyle">
      html,body{background:transparent!important}
      body.platform-embed{min-height:0!important;background:transparent!important;overflow:hidden!important}
      body.platform-embed>header,body.platform-embed>nav{display:none!important}
      body.platform-embed main{padding:0 2px 24px!important;margin:0!important;max-width:none!important}
      body.platform-embed .page{scroll-margin-top:0!important}
      body.platform-embed .page.on{animation:none!important}
      body.platform-embed .dashboard-hero{margin-top:0!important}
      body.platform-embed .card{box-shadow:0 2px 10px rgba(16,42,67,.055)!important}
      body.platform-embed .modal{position:fixed!important}
      @media(max-width:760px){body.platform-embed main{padding:0 0 18px!important}}
    </style>
    """ if embed else ""
    injection = (
        embed_css
        + f"<script>window.TSCO_PLATFORM_ROLE={_script_json(user.role)};"
        + f"window.TSCO_PLATFORM_SENIOR_DOMAIN={_script_json(getattr(user, 'senior_responsibility_domain', '') or '')};"
        + f"window.TSCO_PLATFORM_USER={_script_json(user.full_name)};"
        + f"window.TSCO_PLATFORM_USER_ID={_script_json(user.id)};"
        + f"window.TSCO_PLATFORM_SITE={_script_json(user.site.code if user.site else 'DMM')};"
        + f"window.TSCO_PLATFORM_SECTION={_script_json(section)};"
        + f"window.TSCO_PLATFORM_WORKSTATION={_script_json(workstation)};"
        + f"window.TSCO_PLATFORM_ALLOWED_SECTIONS={_script_json(sorted(ROLE_SECTIONS.get(user.role, {section})))};"
        + f"window.TSCO_DOCUMENTS={_script_json(available_docs)};"
        + f"window.TSCO_PLATFORM_CLIENTS={_script_json(central_clients)};"
        + f"window.TSCO_PLATFORM_TEST_PACKAGES={_script_json(central_packages)};"
        + f"window.TSCO_ANALYTICAL_EQUIPMENT={_script_json(analytical_equipment)};"
        + f"window.TSCO_PLATFORM_EMBED={_script_json(bool(embed))};</script>"
    )
    html = html.replace("</head>", injection + "</head>", 1)
    boot = """
    <script>
    (function(){
      const embedded=!!window.TSCO_PLATFORM_EMBED;
      if(embedded){document.body.classList.add('platform-embed');}
      function notifyHeight(){
        if(!embedded||window.parent===window)return;
        const h=Math.max(document.documentElement.scrollHeight,document.body.scrollHeight,620);
        window.parent.postMessage({type:'TSCO_LAB_HEIGHT',height:h},location.origin);
      }
      function notifySection(section){
        if(!embedded||window.parent===window||!section)return;
        window.parent.postMessage({type:'TSCO_LAB_SECTION_CHANGE',section:String(section)},location.origin);
      }
      function openRequested(){
        const section=window.TSCO_PLATFORM_SECTION;
        const workstation=window.TSCO_PLATFORM_WORKSTATION;
        if(typeof goPage==='function'&&section){try{goPage(section)}catch(_){}}
        if(section==='workstations'&&workstation&&typeof openWs==='function'){
          try{openWs(workstation)}catch(_){}
        }
        if(section==='quality'&&workstation&&typeof availableQcTests==='function'&&typeof qcWorkstation==='function'){
          try{const matches=availableQcTests().filter(q=>qcWorkstation(q)===workstation);if(matches.length)ACTIVE_QC=matches[0];if(typeof renderQuality==='function')renderQuality()}catch(_){}
        }
        setTimeout(notifyHeight,80);
      }
      function wrapNavigation(){
        if(typeof goPage!=='function'||goPage.__platformWrapped)return;
        const original=goPage;
        const wrapped=function(section){
          const result=original.apply(this,arguments);
          notifySection(section);
          setTimeout(notifyHeight,50);
          setTimeout(notifyHeight,220);
          return result;
        };
        wrapped.__platformWrapped=true;
        window.goPage=wrapped;
      }
      function pruneUnauthorizedPages(){
        const allowed=new Set(Array.isArray(window.TSCO_PLATFORM_ALLOWED_SECTIONS)?window.TSCO_PLATFORM_ALLOWED_SECTIONS:[]);
        // Keep unauthorized page nodes inert/hidden instead of removing them. The embedded
        // laboratory console performs asynchronous server synchronization after DOMContentLoaded;
        // removing those nodes caused later render passes to throw before/while applying the
        // freshly loaded central OperationsState, leaving Senior supervision stuck at 0/0.
        document.querySelectorAll('main .page[id]').forEach(page=>{
          if(!allowed.has(page.id)){
            page.hidden=true;
            page.inert=true;
            page.classList.remove('on');
            page.setAttribute('aria-hidden','true');
          }
        });
        document.querySelectorAll('nav button[data-p]').forEach(btn=>{if(!allowed.has(btn.dataset.p))btn.remove();});
      }
      function boot(){
        openRequested();
        wrapNavigation();
        pruneUnauthorizedPages();
        if(window.ResizeObserver){new ResizeObserver(()=>requestAnimationFrame(notifyHeight)).observe(document.body);}
        window.addEventListener('resize',notifyHeight);
        window.addEventListener('load',notifyHeight);
        document.addEventListener('click',()=>setTimeout(notifyHeight,120),true);
        setTimeout(notifyHeight,350);
      }
      if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
      window.addEventListener('message',event=>{
        if(event.origin!==location.origin)return;
        if(event.data&&event.data.type==='TSCO_LAB_SECTION'&&typeof goPage==='function'){
          goPage(event.data.section);
          setTimeout(notifyHeight,80);
        }
      });
    })();
    </script>
    """
    # Insert at the real document closing tag. The laboratory template contains
    # a literal </body> inside the batch-print JavaScript template string; using
    # str.replace(..., 1) injected this boot script into that JavaScript and
    # broke the entire embedded console at runtime.
    body_close = html.rfind("</body>")
    if body_close < 0:
        raise RuntimeError("Laboratory operations template is missing </body>")
    html = html[:body_close] + boot + html[body_close:]
    return HTMLResponse(html)


@router.get("/lab-ops/documents/{filename}")
def protected_document(filename: str, request: Request, db: Session = Depends(get_db)):
    require_user(request, db, ALLOWED)
    import json
    from ..services.document_catalog import SOURCE_DIR
    mapping = json.loads((SOURCE_DIR / "legacy_links.json").read_text())
    code = mapping.get(filename)
    if not code:
        raise HTTPException(status_code=404, detail="Document reference not found")
    return RedirectResponse("/documents/by-code/" + code, status_code=303)


@router.get("/api/lab-operations/data")
def operations_load(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    site = _site_for_user(db, user)
    state, payload = get_operations_state(db, site)
    # Persist a newly materialized monthly Quality Distribution on the actual browser/API load.
    # get_operations_state itself remains read-safe for internal validation/restore flows, so it
    # never surprises an in-flight optimistic-lock update by incrementing the revision.
    try:
        durable = json.loads(state.json_data or "{}")
    except (json.JSONDecodeError, TypeError):
        durable = {}
    durable_ids = {
        str(row.get("id")) for row in durable.get("qualityDistributions", [])
        if isinstance(row, dict) and row.get("id")
    }
    materialized_ids = {
        str(row.get("id")) for row in payload.get("qualityDistributions", [])
        if isinstance(row, dict) and row.get("id")
    }
    if materialized_ids - durable_ids:
        save_operations_state(db, state, payload, actor=None)
    db.commit()
    visible = scope_operations_payload(payload, user)
    return {"db": visible, "savedAt": state.updated_at.isoformat() if state.updated_at else datetime.utcnow().isoformat(), "revision": state.revision}


@router.get("/api/lab-operations/backup")
def operations_backup(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value})
    site = _site_for_user(db, user)
    state, payload = get_operations_state(db, site)
    db.commit()
    return {
        "format": "TSCO-LAB-OPERATIONS-SERVER-BACKUP",
        "version": "3.4.9",
        "exportedAt": datetime.utcnow().isoformat(),
        "site": site.code,
        "revision": state.revision,
        "db": payload,
    }


@router.put("/api/lab-operations/data")
async def operations_save(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, WRITE_ALLOWED)
    site = _site_for_user(db, user)
    now = datetime.utcnow()
    closed_period = db.query(MonthlyClosePeriod).filter_by(site_id=site.id, year=now.year, month=now.month, status="CLOSED").first()
    if closed_period:
        return JSONResponse({"error": f"{now.year}-{now.month:02d} is a closed operational archive; reopen through controlled Monthly Close before editing"}, status_code=423)
    max_bytes = 5_000_000
    try:
        declared_size = int(request.headers.get("content-length") or 0)
    except ValueError:
        declared_size = 0
    if declared_size > max_bytes:
        return JSONResponse({"error": "Laboratory synchronization payload is too large"}, status_code=413)
    chunks: list[bytes] = []
    total = 0
    async for chunk in request.stream():
        total += len(chunk)
        if total > max_bytes:
            return JSONResponse({"error": "Laboratory synchronization payload is too large"}, status_code=413)
        chunks.append(chunk)
    try:
        body = json.loads(b"".join(chunks) or b"{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return JSONResponse({"error": "Invalid JSON payload"}, status_code=400)
    if not isinstance(body, dict):
        return JSONResponse({"error": "Invalid operations request"}, status_code=400)
    state, current = get_operations_state(db, site)
    try:
        client_revision = int(body.get("clientRevision", -1))
    except (TypeError, ValueError):
        client_revision = -1
    if client_revision != int(state.revision or 0):
        return JSONResponse(
            {"error": "Sync conflict: server data changed since this page was loaded", "revision": state.revision, "db": scope_operations_payload(current, user)},
            status_code=409,
        )

    operation = body.get("operation")
    if user.role == Role.SYSTEM_ADMIN.value and operation not in {"reset-operational", "restore-backup"}:
        return JSONResponse({"error": "System Administrator may perform technical backup/restore/reset only; business laboratory updates require the responsible operational role"}, status_code=403)
    new_quality_events: list[dict] = []
    new_test_assignments: list[dict] = []
    if operation == "reset-operational":
        if user.role != Role.SYSTEM_ADMIN.value or body.get("confirmation") != "DELETE SITE DATA":
            return JSONResponse({"error": "Reset requires system administrator"}, status_code=403)
        payload = blank_operations_db(site)
        add_audit(db, actor=user, request=request, action="LAB_OPERATIONS_RESET", entity_type="OperationsState", entity_id=state.id, summary=f"Reset operational data for {site.code}")
    elif operation == "restore-backup":
        if user.role != Role.SYSTEM_ADMIN.value:
            return JSONResponse({"error": "Backup restore requires system administrator"}, status_code=403)
        backup = body.get("backup") or {}
        incoming = backup.get("db") if isinstance(backup, dict) else None
        if not isinstance(backup, dict) or backup.get("format") not in {"TSCO-LAB-OPERATIONS-SERVER-BACKUP", "TSCO-TRANSFORMER-OIL-LAB-OPERATIONS-BACKUP"}:
            return JSONResponse({"error": "Invalid TSCO operations backup format"}, status_code=400)
        backup_site = str(backup.get("site") or "").strip().upper()
        if backup.get("format") == "TSCO-LAB-OPERATIONS-SERVER-BACKUP" and backup_site != site.code:
            return JSONResponse({"error": "Backup belongs to a different laboratory site"}, status_code=400)
        if backup_site and backup_site != site.code:
            return JSONResponse({"error": "Backup belongs to a different laboratory site"}, status_code=400)
        if not isinstance(incoming, dict) or not isinstance(incoming.get("batches"), list) or not isinstance(incoming.get("results"), list):
            return JSONResponse({"error": "Invalid TSCO operations backup data"}, status_code=400)
        list_fields = ("batches", "results", "qc", "qualifiedQcProfiles", "reports", "retained", "retests", "storageAssignments", "batchHistory", "cancelledSamples", "supervisorNotes", "standards", "dgaAttachments", "resultEvidence", "qualityDistributions", "qualityTaskEvents", "testAssignments", "assignmentCompletions", "clients", "customPackages", "formulaDefinitions", "staff", "samplePoints")
        dict_fields = ("calculationDrafts", "testUnits", "drafts", "settings", "meta")
        if any(key in incoming and not isinstance(incoming.get(key), list) for key in list_fields):
            return JSONResponse({"error": "Backup contains an invalid list field"}, status_code=400)
        if any(key in incoming and not isinstance(incoming.get(key), dict) for key in dict_fields):
            return JSONResponse({"error": "Backup contains an invalid object field"}, status_code=400)
        unknown = set(incoming) - set(current)
        if unknown:
            return JSONResponse({"error": "Backup contains unsupported database fields"}, status_code=400)
        payload = dict(current)
        payload.update(incoming)
        # Never restore browser copies of centrally administered master data/configuration.
        for key in ("clients", "customPackages", "formulaDefinitions", "staff", "samplePoints", "testUnits", "settings"):
            payload[key] = current.get(key)
        payload["meta"] = current.get("meta")
        add_audit(
            db, actor=user, request=request, action="LAB_OPERATIONS_BACKUP_RESTORED", entity_type="OperationsState", entity_id=state.id,
            summary=f"Restored operational backup for {site.code}", details={"backup_exported_at": backup.get("exportedAt", ""), "backup_revision": backup.get("revision", "")},
        )
    else:
        incoming = body.get("db") or scope_operations_payload(current, user)
        try:
            payload = merge_scoped_operations_update(current, incoming, user)
            payload = validate_operations_update(current, payload, user, db=db, site_id=site.id)
            existing_quality_event_ids = {str(row.get("id")) for row in current.get("qualityTaskEvents", [])}
            new_quality_events = [row for row in payload.get("qualityTaskEvents", []) if str(row.get("id")) not in existing_quality_event_ids]
            existing_assignment_ids = {str(row.get("id")) for row in current.get("testAssignments", [])}
            new_test_assignments = [row for row in payload.get("testAssignments", []) if str(row.get("id")) not in existing_assignment_ids]
        except PermissionError as exc:
            return JSONResponse({"error": str(exc)}, status_code=403)
        except ValueError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    save_operations_state(db, state, payload, user)
    for assignment in new_test_assignments:
        add_audit(
            db, actor=user, request=request, action="LAB_WORKSTATION_ASSIGNED",
            entity_type="LaboratoryWorkstationAssignment", entity_id=str(assignment.get("id") or ""),
            summary=f"{assignment.get('workstation', 'Workstation')} assigned for {assignment.get('batch_id', '')}",
            details={
                "mode": assignment.get("mode"), "primary": assignment.get("primary_name", ""),
                "backup": assignment.get("backup_name", ""), "revision": assignment.get("revision"),
            },
        )
    for event in new_quality_events:
        add_audit(
            db, actor=user, request=request, action="QUALITY_ROUTINE_CHECK_RECORDED",
            entity_type="QualityRoutineCheck", entity_id=str(event.get("assignment_id") or event.get("id")),
            summary=f"{event.get('task', 'Quality check')} — {event.get('status', '')}",
            details={
                "distribution_id": event.get("distribution_id"), "period": event.get("period_label"),
                "domain": event.get("domain"), "note": event.get("note", ""),
            },
        )
    reconcile_operations_to_platform(db, payload, site.id, user)
    db.commit()
    return {"ok": True, "db": scope_operations_payload(payload, user), "savedAt": state.updated_at.isoformat(), "revision": state.revision}
