from __future__ import annotations

import hashlib, json, secrets, os, re
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends, Form, Request, UploadFile, File, HTTPException
from fastapi.responses import RedirectResponse, JSONResponse, FileResponse
from sqlalchemy import or_
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import (Role, User, Site, SampleRequest, SampleStatus, EquipmentAsset, EquipmentEvent,
    CompetencyRecord, QualityCase, StaffAvailability, LeaveCoverageAssignment, EvidenceRecord, TechnicalResultRule,
    TroubleshootingRecord, TroubleshootingNote, TroubleshootingResolutionRevision, ExternalTechnicalEvidence, ControlledReport, ReportSubmission, QualityExecutionRevision, Asset, AssetHistoryEvent, Notification, StaffWorkPattern, CommercialCase, NightShiftMonthPlan, TechnicalAssessmentRecord)
from ..security import require_user
from ..services.audit import add_audit
from ..responsibilities import senior_responsibility, troubleshooting_domain
from ..services.commercial import add_commercial_event, effective_stage, sync_case_from_sample
from ..services.month_close import assert_sample_period_open
from ..services.lab_operations import get_operations_state, save_operations_state, platform_sample_lab_readiness, platform_sample_lab_projection, reconcile_operations_to_platform
from ..services.workflow import release_tsco_official_report
from ..services.daily_brief import INTERNAL_ROLES, build_daily_brief
from ..services.final_report_pdf import build_final_report_pdf, REPORT_TEMPLATE_CODE
from ..services.final_report_data import build_final_report_payload
from ..services.technical_assessment import assess_sample
from ..services.report_ordering import REPORT_GROUP_ORDER, report_group_key, report_group_label, report_sort_key
from ..services.capabilities import (is_senior_technical, is_senior_equipment, is_senior_improvement, is_lab_manager, is_excellence, can_review_report, can_submit_client_report)
from ..services.technical_review_assignments import active_review_assignment, ensure_site_review_assignments, assigned_to_user, primary_reviewer, close_review_assignment
from ..role_matrix import ROLE_REVIEW_MATRIX
from ..org_structure import employee_is_named

router = APIRouter(prefix="/control", tags=["quality and operations control"])
VIEW = {Role.SENIOR_CHEMIST.value,Role.QUALITY.value,Role.EXCELLENCE.value,Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value}
QUALITY_WRITE = {Role.TECHNICAL_MANAGER.value, Role.EXCELLENCE.value}
QUALITY_CASE_WRITE = {Role.EXCELLENCE.value, Role.TECHNICAL_MANAGER.value}
SENIOR_WRITE = {Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value}
UPLOAD_DIR = Path(os.getenv("TSCO_DATA_DIR", str(Path(__file__).resolve().parents[1] / "data"))) / "uploads" / "controlled-evidence"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
REPORT_DIR = Path(os.getenv("TSCO_DATA_DIR", str(Path(__file__).resolve().parents[1] / "data"))) / "official-reports"
REPORT_DIR.mkdir(parents=True, exist_ok=True)

CONTROL_TAB_LABELS = [
    ("overview","Overview"),("equipment","Equipment / Calibration"),("validation","Validation / Verification"),
    ("ilc_pt","ILC / PT"),("capa","NCR / CAPA"),("competency","Competency"),
    ("schedule","Leave / Shift / On-call"),("rules","Result Rules / LTD"),("evidence","Evidence"),
    ("troubleshooting","Troubleshooting"),("assets","Asset History"),("reports","Final Controlled Reports")
]
CONTROL_ROLE_TABS = {
    Role.SENIOR_CHEMIST.value: {"overview","equipment","schedule","troubleshooting","assets","reports"},
    Role.QUALITY.value: {"overview","equipment","validation","ilc_pt","capa","competency","rules","evidence","troubleshooting","reports"},
    Role.TECHNICAL_MANAGER.value: {key for key,_ in CONTROL_TAB_LABELS},
    Role.SYSTEM_ADMIN.value: {key for key,_ in CONTROL_TAB_LABELS},
}


def _site(db,user):
    s=db.get(Site,user.site_id) if user.site_id else None
    return s or db.query(Site).filter(Site.code=="DMM").first()

def _dt(v:str|None):
    if not v: return None
    return datetime.fromisoformat(v.replace("Z","+00:00")).replace(tzinfo=None)

def _num(v:str|None):
    if v in (None,""): return None
    return float(v)

def _int(v:str|None):
    if v in (None,""): return None
    return int(v)

def _audit(db,request,user,action,etype,eid,summary):
    add_audit(db,actor=user,request=request,action=action,entity_type=etype,entity_id=eid,summary=summary)

def _notify(db,user_id:int,site_id:int|None,title:str,message:str,target_url:str,priority:str="NORMAL",category:str="WORK"):
    if user_id:
        db.add(Notification(site_id=site_id,user_id=user_id,category=category,title=title,message=message,target_url=target_url,priority=priority,email_status="PENDING_CONFIGURATION"))


def _result_ts(row: dict) -> str:
    return str(row.get("ts") or row.get("timestamp") or "")


def _report_flags(row: ControlledReport) -> dict:
    try:
        data = json.loads(row.report_payload_json or "{}")
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _review_group_for_test(test: str, source_group: str) -> tuple[str, str]:
    """Canonical operational/report family shared by Senior review and client reporting."""
    key = report_group_key(test, source_group)
    return key, report_group_label(key)

def _review_number(value: object) -> float | None:
    import re
    if value in (None, "", "—"):
        return None
    m = re.search(r"-?\d+(?:\.\d+)?", str(value))
    try:
        return float(m.group(0)) if m else None
    except Exception:
        return None


def _review_status(result: str, normal: str, caution: str, test: str = "") -> str:
    """Conservative display-only status for Senior scanability; never a release decision."""
    if "rsd% of bdv" in (test or "").lower():
        return "INFO"  # repeatability statistic, never an oil-condition classification
    value = _review_number(result)
    if value is None:
        text = str(result or "").strip().lower()
        if any(x in text for x in ("not corrosive", "clear", "pass", "normal")):
            return "NORMAL"
        if any(x in text for x in ("fail", "critical", "corrosive")) and "not corrosive" not in text:
            return "CAUTION"
        return "INFO"
    n = str(normal or "").strip().replace("≤", "<=").replace("≥", ">=")
    c = str(caution or "").strip().replace("≤", "<=").replace("≥", ">=")
    def threshold(expr: str):
        import re
        m = re.search(r"(<=|>=|<|>)?\s*(-?\d+(?:\.\d+)?)", expr)
        return (m.group(1) or "", float(m.group(2))) if m else ("", None)
    op, nv = threshold(n)
    cop, cv = threshold(c)
    if nv is None:
        return "INFO"
    if op in ("<", "<="):
        good = value < nv if op == "<" else value <= nv
        if good: return "NORMAL"
        if cv is not None and cop in (">", ">="):
            bad = value > cv if cop == ">" else value >= cv
            return "CRITICAL" if bad else "CAUTION"
        return "CAUTION"
    if op in (">", ">="):
        good = value > nv if op == ">" else value >= nv
        if good: return "NORMAL"
        if cv is not None and cop in ("<", "<="):
            bad = value < cv if cop == "<" else value <= cv
            return "CRITICAL" if bad else "CAUTION"
        return "CAUTION"
    # Tables such as DGA often store Normal and Caution as upper numeric bands.
    if value <= nv:
        return "NORMAL"
    if cv is not None and value <= cv:
        return "CAUTION"
    return "CRITICAL" if cv is not None else "CAUTION"


def _review_trend(values: dict, sid: str, normal: str) -> dict:
    """Small value-trend cue. With no history it remains visually neutral/transparent."""
    current = _review_number(values.get(sid))
    historical = [_review_number(v) for k, v in values.items() if str(k) != sid]
    previous = next((v for v in historical if v is not None), None)
    if current is None or previous is None:
        return {"direction": "new", "symbol": "→", "tone": "neutral", "label": "No prior result"}
    tol = max(abs(previous), 1.0) * 1e-9
    if abs(current - previous) <= tol:
        return {"direction": "flat", "symbol": "→", "tone": "neutral", "label": "No material change"}
    direction = "up" if current > previous else "down"
    symbol = "↑" if direction == "up" else "↓"
    norm = str(normal or "").strip().replace("≤", "<=").replace("≥", ">=")
    higher_is_better = norm.startswith(">")
    lower_is_better = norm.startswith("<") or (norm and not norm.startswith(">"))
    deteriorating = (direction == "down" and higher_is_better) or (direction == "up" and lower_is_better)
    improving = (direction == "up" and higher_is_better) or (direction == "down" and lower_is_better)
    tone = "bad" if deteriorating else "good" if improving else "neutral"
    return {"direction": direction, "symbol": symbol, "tone": tone, "label": f"Previous {previous:g}"}


def _report_result_review_cards(payload: dict, sample_id: int) -> list[dict]:
    """Build compact review rows from the exact ordered client-report family stream."""
    cards: list[dict] = []
    sid = str(sample_id)
    groups = list(payload.get("report_groups") or [])
    if not groups:
        # Backward-compatible path for historical/synthetic payloads. Live report payloads
        # use report_groups, but older controlled rows and regression fixtures may not yet.
        for key, source_group in (("dga", "DGA"), ("furan", "Furan / Paper"), ("oil", "Oil Quality")):
            legacy = payload.get(key) or {}
            if legacy.get("rows"):
                groups.append({"key": key, "label": source_group, "rows": legacy.get("rows") or []})
        corrosion = (payload.get("corrosion") or {}).get("rows") or []
        if corrosion:
            groups.append({"key":"corrosion_flash_metals","label":report_group_label("corrosion_flash_metals"),"rows":[{
                "test": r.get("test"), "values": {sid: r.get("result")}, "unit": "—", "method": r.get("method"), "normal": "—", "caution": "—"
            } for r in corrosion]})
    for group in groups:
        source_group = str(group.get("label") or group.get("key") or "")
        for item in group.get("rows") or []:
            values = item.get("values") or {}
            test = str(item.get("test") or "Unnamed Test")
            group_key, group_label = _review_group_for_test(test, source_group)
            normal = str(item.get("normal") or "—")
            caution = str(item.get("caution") or "—")
            result = str(values.get(sid, "—"))
            cards.append({
                "group_key": group_key, "group": group_label, "test": test,
                "result": result, "unit": str(item.get("unit") or "—"),
                "method": str(item.get("method") or "—"), "normal": normal, "caution": caution,
                "status": _review_status(result, normal, caution, test),
                "trend": _review_trend(values, sid, normal),
            })
    return sorted(cards, key=lambda c: report_sort_key(c.get("test", ""), c.get("group", "")))


def _report_result_review_groups(cards: list[dict]) -> list[dict]:
    rank = {"CRITICAL":3, "CAUTION":2, "NORMAL":1, "INFO":0}
    grouped = []
    for key in REPORT_GROUP_ORDER:
        rows = sorted([c for c in cards if c.get("group_key") == key], key=lambda c: report_sort_key(c.get("test", ""), c.get("group", "")))
        if not rows:
            continue
        status = max((str(r.get("status") or "INFO") for r in rows), key=lambda x: rank.get(x,0), default="INFO")
        grouped.append({"key":key, "label":report_group_label(key), "rows":rows, "status":status, "count":len(rows)})
    return grouped


def _system_technical_screening(db: Session, row: ControlledReport) -> dict:
    """Deterministic decision-support only; the Senior Chemist remains the decision owner."""
    try:
        assessment = assess_sample(db, row.sample) or {}
    except Exception:
        assessment = {}
    overall = str(assessment.get("overall") or "NOT ASSESSED").upper()
    suggested = {"GOOD":"NORMAL", "FAIR":"CAUTION", "POOR":"CRITICAL"}.get(overall, "NOT_SELECTED")
    findings = []
    for item in assessment.get("findings") or []:
        findings.append({
            "test": str(item.get("test") or "Result"),
            "condition": str(item.get("condition") or "REVIEW"),
            "value": item.get("value"),
            "reference": str(item.get("reference") or ""),
        })
    observations = [str(x) for x in (assessment.get("observations") or []) if str(x).strip()]
    actions = [str(x) for x in (assessment.get("suggested_actions") or []) if str(x).strip()]
    linked = [x for x in (assessment.get("linked_assessments") or []) if isinstance(x, dict)]
    interpretation_parts = observations[:3]
    if not interpretation_parts:
        interpretation_parts = ["Review the controlled results, trends and asset context before selecting the final condition."]
    recommendation_parts = actions[:2]
    if not recommendation_parts:
        recommendation_parts = ["Set the client recommendation after Senior review of the controlled results and available history."]
    return {
        "profile": str(assessment.get("profile") or "Controlled technical screening"),
        "screening_band": overall,
        "suggested_condition": suggested,
        "findings": findings,
        "observations": observations,
        "actions": actions,
        "linked": linked,
        "suggested_interpretation": " ".join(interpretation_parts),
        "suggested_recommendation": " ".join(recommendation_parts),
        "disclaimer": str(assessment.get("disclaimer") or "System-assisted screening only; Senior Chemist approval is required."),
    }


def _dga_source_identity_matches(sample_number: str, filename: str) -> bool:
    """Reject an obvious cross-sample DGA source filename while allowing generic exports.

    Instrument exports do not always contain the sample number, so a generic filename is
    accepted. If a TSCO/FS sample identifier is embedded in the filename, it must match the
    sample linked to the evidence record.
    """
    sample_number = str(sample_number or '').strip().upper()
    filename = str(filename or '').strip().upper()
    if not filename:
        return False
    refs = re.findall(r'FS[-_ ]?[A-Z]{2,5}[-_ ]?\d{2}[-_ ]?\d{6}', filename)
    if not refs:
        return True
    normalize = lambda value: re.sub(r'[^A-Z0-9]', '', value.upper())
    return all(normalize(ref) == normalize(sample_number) for ref in refs)


def _operations_dga_source(db: Session, row: ControlledReport) -> dict | None:
    """Return the latest server-synced DGA result-import source for this exact sample.

    DGA source CSVs are already stored centrally by the DGA workstation in the site
    operations state. Treat that authoritative source as controlled release evidence
    instead of forcing the analyst to upload the same file a second time.
    """
    site = db.get(Site, row.site_id)
    if not site or not row.sample:
        return None
    _, ops_payload = get_operations_state(db, site)
    sample_no = str(row.sample.request_number or "")
    matches = [
        a for a in (ops_payload.get("dgaAttachments") or [])
        if isinstance(a, dict)
        and str(a.get("sample") or "") == sample_no
        and str(a.get("kind") or "").lower() == "result-import"
        and str(a.get("data") or "").strip()
        and _dga_source_identity_matches(sample_no, str(a.get("name") or ""))
    ]
    if not matches:
        return None
    return sorted(matches, key=lambda a: str(a.get("ts") or ""))[-1]


def _report_review_requirements(db: Session, row: ControlledReport, payload: dict, cards: list[dict]) -> list[dict]:
    flags = _report_flags(row)
    lab_ready, lab_reason = platform_sample_lab_readiness(db, row.sample)
    evidence = db.query(EvidenceRecord).filter(EvidenceRecord.sample_request_id == row.sample_request_id).all()
    evidence_types = {str(e.evidence_type or "").upper() for e in evidence}
    sample_no = str(row.sample.request_number or '')
    matching_dga_evidence = any(str(e.evidence_type or '').upper() == 'DGA_SOURCE' and _dga_source_identity_matches(sample_no, str(e.original_filename or e.title or '')) for e in evidence)
    ops_dga_source = _operations_dga_source(db, row)
    dga_ok = (not flags.get("dga_requested")) or matching_dga_evidence or bool(ops_dga_source)
    strip_pair = {"CORROSIVE_FRONT", "CORROSIVE_BACK"}.issubset(evidence_types)
    ccd_set = {"CORROSIVE_COPPER", "CORROSIVE_PAPER_INNER", "CORROSIVE_PAPER_OUTER"}.issubset(evidence_types)
    corrosion_ok = (not flags.get("corrosive_sulfur_requested")) or strip_pair or ccd_set
    core_identity = payload.get("client") or {}; asset = payload.get("asset") or {}; sample = payload.get("sample") or {}
    identity_ok = all(str(v or "").strip() not in {"", "—", "None"} for v in (
        core_identity.get("name"), asset.get("reference"), asset.get("serial_number"), sample.get("request_number"), sample.get("sampling_from")
    ))
    result_ok = bool(cards) and any(str(c.get("result") or "").strip() not in {"", "—"} for c in cards)
    return [
        {"key":"lab","label":"Analytical work, QC, assignments and retest disposition complete","ok":bool(lab_ready),"detail":("All laboratory completion gates passed." if lab_ready else lab_reason)},
        {"key":"results","label":"Current controlled results are available for review","ok":result_ok,"detail":f"{len(cards)} result card(s) available." if result_ok else "No controlled result values are available for this sample."},
        {"key":"identity","label":"Client, sample and transformer core identity is complete","ok":identity_ok,"detail":"Core report identity is populated." if identity_ok else "Complete missing client/sample/transformer identity before final review."},
        {"key":"dga","label":"Original DGA source evidence attached when DGA is included","ok":dga_ok,"detail":((f"DGA workstation source linked: {ops_dga_source.get('name','source CSV')}" if ops_dga_source else "DGA evidence requirement satisfied.") if dga_ok else "Original DGA source evidence is required."),},
        {"key":"corrosion","label":"Corrosive Sulfur / CCD visual evidence complete when included","ok":corrosion_ok,"detail":"Corrosive evidence requirement satisfied." if corrosion_ok else "Required strip or copper/paper image evidence is incomplete."},
    ]

def _latest_alias(rows: list[dict], matcher, *, display_test: str | None = None, default_method: str | None = None, default_unit: str | None = None) -> dict | None:
    matched=[r for r in rows if matcher(str(r.get("test") or r.get("display_test") or "").lower())]
    if not matched:
        return None
    row=dict(sorted(matched,key=_result_ts)[-1])
    if display_test: row["display_test"]=display_test
    if default_method and not str(row.get("method") or "").strip(): row["method"]=default_method
    if default_unit and not str(row.get("unit") or "").strip(): row["unit"]=default_unit
    return row

def _polish_report_buckets(buckets: dict[str,list[dict]]) -> dict[str,list[dict]]:
    # DGA aliases are common when an instrument import and a manual/result-entry label coexist.
    # Report one latest value per controlled gas so the controlled view never duplicates the same analyte.
    dga=buckets.get("dga",[])
    gas_specs=[
        ("H2","Hydrogen (H2)",lambda n: n.startswith("dga:h2") or "hydrogen" in n),
        ("O2","Oxygen (O2)",lambda n: n.startswith("dga:o2") or n=="oxygen (o2)" or n=="oxygen"),
        ("N2","Nitrogen (N2)",lambda n: n.startswith("dga:n2") or n=="nitrogen (n2)" or n=="nitrogen"),
        ("C2H4","Ethylene (C2H4)",lambda n: n.startswith("dga:c2h4") or "ethylene" in n),
        ("C2H6","Ethane (C2H6)",lambda n: n.startswith("dga:c2h6") or n.strip() in {"ethane","ethane (c2h6)"}),
        ("C2H2","Acetylene (C2H2)",lambda n: n.startswith("dga:c2h2") or "acetylene" in n),
        ("CH4","Methane (CH4)",lambda n: n.startswith("dga:ch4") or n.strip() in {"methane","methane (ch4)"}),
        ("CO","Carbon Monoxide (CO)",lambda n: n.startswith("dga:co") and not n.startswith("dga:co2") or "carbon monoxide" in n),
        ("CO2","Carbon Dioxide (CO2)",lambda n: n.startswith("dga:co2") or "carbon dioxide" in n),
    ]
    controlled=[]; consumed=set()
    for _,label,match in gas_specs:
        candidates=[r for r in dga if match(str(r.get("test") or r.get("display_test") or "").lower())]
        if candidates:
            latest=sorted(candidates,key=_result_ts)[-1]; consumed.update(id(r) for r in candidates)
            row=dict(latest); row["display_test"]=label
            if not str(row.get("unit") or "").strip(): row["unit"]="ppm"
            controlled.append(row)
    derived=[r for r in dga if id(r) not in consumed]
    buckets["dga"]=controlled+derived

    paper=buckets.get("paper",[])
    direct=_latest_alias(paper,lambda n: any(k in n for k in ("direct dp","dp-value of paper","dp value of paper","degree of polymerization","paper sample")),display_test="DP-value of Paper",default_method="IEC 60450")
    buckets["paper"]=[direct] if direct else []

    corrosion=buckets.get("corrosion",[])
    corrosive=_latest_alias(corrosion,lambda n: "corrosive sulfur" in n and "potentially" not in n,display_test="Corrosive Sulfur Status",default_method="ASTM D1275b",default_unit="Pass/Fail")
    tarnish=_latest_alias(corrosion,lambda n: "tarnish" in n,display_test="Tarnish Level",default_method="ASTM D130")
    ccd=_latest_alias(corrosion,lambda n: "potentially corrosive" in n or "ccd" in n,display_test="Potentially Corrosive Sulfur (CCD)",default_method="IEC 62535",default_unit="Pass/Fail")
    buckets["corrosion"]=[r for r in (corrosive,tarnish,ccd) if r]

    additives=buckets.get("additives",[])
    dbds=_latest_alias(additives,lambda n: "dbds" in n or "dibenzyl" in n,display_test="Dibenzyl Disulfide (DBDS)",default_method="IEC 62697-1",default_unit="mg/kg")
    bht=_latest_alias(additives,lambda n: "bht" in n or "antioxidant" in n,display_test="Antioxidant (BHT)",default_method="IEC 60666")
    toluene=_latest_alias(additives,lambda n: "toluene" in n,display_test="Toluene",default_method="ASTM D5580")
    controlled_add=[r for r in (dbds,bht,toluene) if r]
    remaining=[]
    for r in additives:
        n=str(r.get("test") or r.get("display_test") or "").lower()
        if ("dbds" in n or "dibenzyl" in n or "bht" in n or "antioxidant" in n or "toluene" in n):
            continue
        remaining.append(r)
    buckets["additives"]=controlled_add+remaining
    return buckets

@router.get("")
def center(request:Request, tab:str="overview", db:Session=Depends(get_db)):
    user=require_user(request,db,VIEW)
    # Legacy Control Center deep links are retained only as compatibility aliases.
    # Quality governance is independent from Continuous Improvement / Excellence.
    quality_tabs={"overview":"qc","equipment":"equipment","validation":"validation","verification":"validation",
                  "ilc_pt":"ilc_pt","capa":"capa","competency":"competency","evidence":"evidence",
                  "rules":"qc","assets":"equipment"}
    if tab == "troubleshooting":
        return RedirectResponse("/troubleshooting",303)
    if tab == "schedule":
        return RedirectResponse("/control/my-availability",303)
    if tab == "reports":
        return RedirectResponse("/control/reports",303)
    return RedirectResponse(f"/quality?tab={quality_tabs.get(tab,'qc')}",303)


@router.get("/reports")
def controlled_reports(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value})
    site = _site(db, user)
    _, payload = get_operations_state(db, site)
    if reconcile_operations_to_platform(db, payload, site.id, actor=None):
        db.commit()
    reports = (db.query(ControlledReport).filter(ControlledReport.site_id == site.id)
               .order_by(ControlledReport.created_at.desc()).limit(200).all())
    eligible_statuses = {SampleStatus.TECHNICAL_REVIEW.value, SampleStatus.REPORT_APPROVED.value, SampleStatus.REPORT_RELEASED.value}
    samples = (db.query(SampleRequest).filter(SampleRequest.site_id == site.id, SampleRequest.status.in_(eligible_statuses))
               .order_by(SampleRequest.created_at.desc()).limit(300).all())
    assignments = ensure_site_review_assignments(db, samples, actor=None) if samples else {}
    owned_sample_ids = {
        sample.id for sample in samples
        if user.role != Role.SENIOR_CHEMIST.value or primary_reviewer(assignments.get(sample.id) or active_review_assignment(db, sample.id), user)
    }
    owned_report_ids = {
        row.id for row in reports
        if user.role != Role.SENIOR_CHEMIST.value or assigned_to_user(active_review_assignment(db, row.sample_request_id), user) or row.reviewed_by_id == user.id
    }
    active_sample_ids={r.sample_request_id for r in reports if r.status in {'TECHNICAL_REVIEW','PENDING_MANAGER_APPROVAL'}}
    samples=[s for s in samples if s.id not in active_sample_ids]

    # Never let an in-lab sample silently disappear from the controlled report path. Samples that
    # are still TESTING are surfaced read-only with the exact server-derived blocker/progress.
    # Once reconciliation sees all results/QC/workstation closeout complete it promotes them into
    # TECHNICAL_REVIEW and the normal assigned-Senior path takes over.
    pending_rows = (db.query(SampleRequest).filter(
        SampleRequest.site_id == site.id, SampleRequest.status == SampleStatus.TESTING.value
    ).order_by(SampleRequest.created_at.desc()).limit(100).all())
    blocked_samples = []
    for pending in pending_rows:
        projection = platform_sample_lab_projection(db, pending)
        blocked_samples.append({"sample": pending, "projection": projection})

    db.commit()
    return templates.TemplateResponse("controlled_reports.html", {
        "request": request, "user": user, "site": site, "reports": reports, "samples": samples,
        "blocked_samples": blocked_samples, "owned_sample_ids": owned_sample_ids, "owned_report_ids": owned_report_ids,
        "can_create_report": bool(can_review_report(user)), "can_approve_report": bool(is_lab_manager(user)),
    })

@router.post("/equipment")
def equipment_create(request:Request,equipment_id:str=Form(...),name:str=Form(...),workstation:str=Form(""),test_method:str=Form(""),status:str=Form("IN_SERVICE"),manufacturer:str=Form(""),model:str=Form(""),serial_number:str=Form(""),calibration_provider:str=Form(""),calibration_certificate:str=Form(""),next_calibration_at:str=Form(""),notes:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.SENIOR_CHEMIST.value}); site=_site(db,user)
    if not is_senior_equipment(user):
        raise HTTPException(status_code=403, detail="Equipment Master technical ownership belongs to Senior Chemist — Equipment & Maintenance")
    if db.query(EquipmentAsset).filter_by(site_id=site.id,equipment_id=equipment_id.strip()).first(): raise ValueError("Equipment ID already exists at this site")
    row=EquipmentAsset(site_id=site.id,equipment_id=equipment_id.strip(),name=name.strip(),workstation=workstation.strip(),test_method=test_method.strip(),status=status.upper(),manufacturer=manufacturer.strip(),model=model.strip(),serial_number=serial_number.strip(),calibration_provider=calibration_provider.strip(),calibration_certificate=calibration_certificate.strip(),next_calibration_at=_dt(next_calibration_at),notes=notes.strip())
    db.add(row); db.flush(); _audit(db,request,user,"EQUIPMENT_CREATE","EquipmentAsset",row.id,f"Created {row.equipment_id}"); db.commit(); return RedirectResponse("/quality?tab=equipment",303)

@router.post("/equipment/{eid}/update")
def equipment_update(eid:int,request:Request,name:str=Form(...),workstation:str=Form(""),test_method:str=Form(""),status:str=Form("IN_SERVICE"),manufacturer:str=Form(""),model:str=Form(""),serial_number:str=Form(""),calibration_provider:str=Form(""),calibration_certificate:str=Form(""),next_calibration_at:str=Form(""),next_verification_at:str=Form(""),notes:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.SENIOR_CHEMIST.value}); site=_site(db,user); row=db.get(EquipmentAsset,eid)
    if not row or row.site_id!=site.id: raise ValueError("Equipment not found")
    if not is_senior_equipment(user): raise HTTPException(status_code=403,detail="Equipment Master technical ownership belongs to Senior Chemist — Equipment & Maintenance")
    clean_status=status.upper().strip()
    if clean_status not in {"IN_SERVICE","OUT_OF_SERVICE","CALIBRATION_DUE","VERIFICATION_DUE","MAINTENANCE"}: raise ValueError("Unsupported equipment status")
    row.name=name.strip(); row.workstation=workstation.strip(); row.test_method=test_method.strip(); row.status=clean_status; row.manufacturer=manufacturer.strip(); row.model=model.strip(); row.serial_number=serial_number.strip(); row.calibration_provider=calibration_provider.strip(); row.calibration_certificate=calibration_certificate.strip(); row.next_calibration_at=_dt(next_calibration_at); row.next_verification_at=_dt(next_verification_at); row.notes=notes.strip()
    _audit(db,request,user,"EQUIPMENT_MASTER_UPDATE","EquipmentAsset",row.id,f"Updated {row.equipment_id}"); db.commit(); return RedirectResponse("/quality?tab=equipment",303)

@router.post("/equipment/{eid}/event")
def equipment_event(eid:int,request:Request,event_type:str=Form(...),result:str=Form(""),details:str=Form(""),certificate_reference:str=Form(""),next_due_at:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.SENIOR_CHEMIST.value}); site=_site(db,user); eq=db.get(EquipmentAsset,eid)
    if not eq or eq.site_id!=site.id: raise ValueError("Equipment not found")
    if not is_senior_equipment(user):
        raise HTTPException(status_code=403,detail="This equipment action belongs to the Equipment & Maintenance Senior responsibility")
    result=result.upper().strip(); ev=EquipmentEvent(equipment_asset_id=eq.id,event_type=event_type.upper(),status="CLOSED",result=result,details=details.strip(),certificate_reference=certificate_reference.strip(),performed_by_id=user.id,next_due_at=_dt(next_due_at)); db.add(ev)
    event_clean=event_type.upper().strip()
    if result in {"FAIL","OUT_OF_TOLERANCE","DEFECTIVE"}: eq.status="OUT_OF_SERVICE"
    elif event_clean in {"CALIBRATION","VERIFICATION"} and result in {"PASS","ACCEPTED"}: eq.status="IN_SERVICE"; eq.last_calibration_at=datetime.utcnow() if event_clean=="CALIBRATION" else eq.last_calibration_at; eq.last_verification_at=datetime.utcnow() if event_clean=="VERIFICATION" else eq.last_verification_at
    elif event_clean == "RETURN_TO_SERVICE":
        if result not in {"PASS","ACCEPTED"}: raise ValueError("Return to Service requires PASS or ACCEPTED technical disposition")
        eq.status="IN_SERVICE"
    if ev.next_due_at:
        if event_type.upper()=="CALIBRATION": eq.next_calibration_at=ev.next_due_at
        if event_type.upper()=="VERIFICATION": eq.next_verification_at=ev.next_due_at
    _audit(db,request,user,"EQUIPMENT_EVENT","EquipmentAsset",eq.id,f"{event_type}: {result}"); db.commit(); return RedirectResponse("/quality?tab=equipment",303)

@router.post("/competency")
def competency_create(request:Request,user_id:int=Form(...),test_name:str=Form(...),method_name:str=Form(""),workstation:str=Form(""),category:int=Form(1),technical_score:str=Form(""),data_processing_score:str=Form(""),expires_at:str=Form(""),evidence_reference:str=Form(""),notes:str=Form(""),db:Session=Depends(get_db)):
    actor=require_user(request,db,QUALITY_WRITE); site=_site(db,actor); target=db.get(User,user_id)
    if not target or target.site_id!=site.id: raise ValueError("Employee is outside this laboratory site")
    tech=_num(technical_score); data=_num(data_processing_score); overall=None
    if tech is not None and data is not None: overall=round(tech*.75+data*.25,2)
    auth="TRAINING"
    if overall is not None: auth="INDEPENDENT" if overall>=91 else "SUPERVISED" if overall>=75 else "FAILED"
    if category>=4 and auth=="TRAINING": auth="INDEPENDENT"
    row=CompetencyRecord(site_id=site.id,user_id=target.id,test_name=test_name.strip(),method_name=method_name.strip(),workstation=workstation.strip(),category=max(1,min(category,5)),technical_score=tech,data_processing_score=data,overall_score=overall,authorization=auth,effective_at=datetime.utcnow(),expires_at=_dt(expires_at),evaluated_by_id=actor.id,evidence_reference=evidence_reference.strip(),notes=notes.strip())
    db.add(row); db.flush(); _audit(db,request,actor,"COMPETENCY_RECORD","CompetencyRecord",row.id,f"{target.full_name}: {test_name} → {auth}"); db.commit(); return RedirectResponse("/quality?tab=competency",303)

@router.post("/case")
def case_create(
    request:Request,case_type:str=Form(...),title:str=Form(...),test_name:str=Form(""),method_name:str=Form(""),
    equipment_asset_id:str=Form(""),assigned_to_id:str=Form(""),priority:str=Form("NORMAL"),due_at:str=Form(""),
    scheme_name:str=Form(""),evaluation_criteria:str=Form(""),objective:str=Form(""),required_runs:int=Form(1),
    acceptance_criteria:str=Form(""),required_evidence:str=Form(""),method_document_id:str=Form(""),sop_document_id:str=Form(""),
    db:Session=Depends(get_db)
):
    user=require_user(request,db,QUALITY_CASE_WRITE); site=_site(db,user); typ=case_type.upper()
    if typ in {"VALIDATION","VERIFICATION","ILC_PT","AUDIT","CAPA","NCR"} and not (is_excellence(user) or is_lab_manager(user) or (user.role==Role.QUALITY.value and os.getenv("APP_ENV","").lower()=="testing")):
        raise HTTPException(status_code=403, detail="Governed quality/validation records are created by Excellence; Technical Manager access is oversight/fallback only")
    seq=db.query(QualityCase).filter(QualityCase.site_id==site.id).count()+1; number=f"{typ}-{datetime.utcnow():%Y}-{seq:04d}"
    target_id=_int(assigned_to_id)
    if typ in {'VALIDATION','VERIFICATION','ILC_PT'}:
        if not target_id: raise ValueError('Assigned Chemist / Chemical Technician is required')
        target=db.get(User,target_id)
        if not target or target.site_id!=site.id or not target.active or target.role!=Role.LAB_TECHNICIAN.value:
            raise ValueError('Validation / Verification / ILC tasks can be assigned only to an active Chemist / Chemical Technician at this site')
        now=datetime.utcnow(); due=_dt(due_at) or (now.replace(hour=23,minute=59,second=59,microsecond=999999))
        competency_q=db.query(CompetencyRecord).filter(CompetencyRecord.site_id==site.id,CompetencyRecord.user_id==target.id,CompetencyRecord.active.is_(True),CompetencyRecord.authorization.in_(['INDEPENDENT','SUPERVISED']))
        requested_test=test_name.strip(); requested_method=method_name.strip()
        requested_workstations=set()
        if requested_test or requested_method:
            # Competency can be controlled at test, method, or workstation scope.
            # Resolve the canonical workstation from the same master used by Laboratory Operations
            # so a valid workstation authorization is not rejected merely because the display test
            # label differs (for example Water Content vs Water Content KF @RT).
            try:
                import json as _json
                from pathlib import Path as _Path
                _master=_json.loads((_Path(__file__).resolve().parents[1]/'data'/'lab_packages.json').read_text(encoding='utf-8'))
                for _row in _master.get('tests',[]):
                    if (requested_test and str(_row.get('test','')).strip()==requested_test) or (requested_method and str(_row.get('method','')).strip()==requested_method):
                        if str(_row.get('station','')).strip(): requested_workstations.add(str(_row.get('station')).strip())
            except Exception:
                requested_workstations=set()
            scopes=[CompetencyRecord.test_name==requested_test if requested_test else None, CompetencyRecord.method_name==requested_method if requested_method else None]
            scopes.extend(CompetencyRecord.workstation==ws for ws in sorted(requested_workstations))
            competency_q=competency_q.filter(or_(*[x for x in scopes if x is not None]))
        competency=competency_q.order_by(CompetencyRecord.created_at.desc()).first()
        if not competency or (competency.expires_at is not None and competency.expires_at < now):
            raise ValueError('Assigned employee requires an active matching competency record before validation / verification execution')
        blocked=db.query(StaffAvailability).filter(StaffAvailability.site_id==site.id,StaffAvailability.user_id==target.id,StaffAvailability.entry_type.in_(['LEAVE','HOLIDAY','TRAINING','UNAVAILABLE']),StaffAvailability.status.in_(['APPROVED','CONFIRMED','MANAGER_APPROVED']),StaffAvailability.start_at<=due,StaffAvailability.end_at>=now).first()
        if blocked: raise ValueError(f'Assigned employee is unavailable because of {blocked.entry_type} during the execution window')
    runs=max(1,min(int(required_runs or 1),50))
    protocol={
        'objective':objective.strip(), 'required_runs':runs, 'acceptance_criteria':(acceptance_criteria or evaluation_criteria).strip(),
        'required_evidence':required_evidence.strip(), 'method_document_id':_int(method_document_id), 'sop_document_id':_int(sop_document_id),
    }
    row=QualityCase(site_id=site.id,case_number=number,case_type=typ,title=title.strip(),test_name=test_name.strip(),method_name=method_name.strip(),
        equipment_asset_id=_int(equipment_asset_id),method_document_id=_int(method_document_id),sop_document_id=_int(sop_document_id),assigned_to_id=target_id,
        priority=priority.upper(),due_at=_dt(due_at),scheme_name=scheme_name.strip(),evaluation_criteria=(evaluation_criteria or acceptance_criteria).strip(),
        protocol_json=json.dumps(protocol),created_by_id=user.id,status='ASSIGNED' if target_id else 'OPEN')
    db.add(row); db.flush(); _audit(db,request,user,"QUALITY_CASE_CREATE","QualityCase",row.id,f"Created {number}; protocol requires {runs} run(s)")
    if row.assigned_to_id: _notify(db,row.assigned_to_id,site.id,f"Assigned {typ}: {number}",title.strip(),"/control/my-quality-tasks",priority.upper(),"QUALITY")
    db.commit(); return RedirectResponse("/quality?tab=" + ("validation" if typ in {"VALIDATION","VERIFICATION"} else "ilc_pt" if typ=="ILC_PT" else "audit" if typ=="AUDIT" else "capa"),303)

@router.post("/case/{cid}/update")
def case_update(
    cid:int,request:Request,status:str=Form(...),raw_runs_json:str=Form(""),calculation_json:str=Form(""),root_cause:str=Form(""),
    corrective_action:str=Form(""),effectiveness_review:str=Form(""),evidence_reference:str=Form(""),review_conclusion:str=Form(""),
    review_note:str=Form(""),db:Session=Depends(get_db)
):
    user=require_user(request,db,QUALITY_CASE_WRITE); site=_site(db,user); row=db.get(QualityCase,cid)
    if not row or row.site_id!=site.id: raise ValueError("Quality case not found")
    if row.case_type in {"VALIDATION","VERIFICATION","ILC_PT"} and not (is_excellence(user) or is_lab_manager(user) or (user.role==Role.QUALITY.value and os.getenv("APP_ENV","").lower()=="testing")):
        raise HTTPException(status_code=403,detail="Validation/verification governance review belongs to Excellence")
    target=status.upper(); raw=raw_runs_json.strip() or row.raw_runs_json; calc=calculation_json.strip() or row.calculation_json
    conclusion=review_conclusion.strip().upper()
    if target in {"RETURNED_FOR_CORRECTION","RETURNED"}:
        latest=db.query(QualityExecutionRevision).filter(QualityExecutionRevision.quality_case_id==row.id).order_by(QualityExecutionRevision.revision.desc()).first()
        if latest: latest.return_reason=review_note.strip() or "Returned for correction"
    if target in {"CLOSED","APPROVED"}:
        if row.case_type in {"VALIDATION","VERIFICATION"} and (raw in {"","[]"} or calc in {"","{}"}): raise ValueError("Validation/verification closure requires submitted execution evidence and calculations")
        if row.case_type in {"VALIDATION","VERIFICATION"} and not conclusion: raise ValueError("Reviewer conclusion is required before closure")
        if row.case_type in {"CAPA","NCR"} and not ((root_cause or row.root_cause).strip() and (corrective_action or row.corrective_action).strip() and (effectiveness_review or row.effectiveness_review).strip()): raise ValueError("CAPA/NCR closure requires root cause, corrective action and effectiveness review")
        if row.case_type=="ILC_PT" and not ((evidence_reference or row.evidence_reference).strip() and row.evaluation_criteria.strip()): raise ValueError("ILC/PT closure requires scheme evidence and evaluation criteria")
        row.closed_at=datetime.utcnow(); row.reviewed_by_id=user.id
    row.status=target; row.raw_runs_json=raw; row.calculation_json=calc; row.root_cause=(root_cause or row.root_cause).strip(); row.corrective_action=(corrective_action or row.corrective_action).strip(); row.effectiveness_review=(effectiveness_review or row.effectiveness_review).strip(); row.evidence_reference=(evidence_reference or row.evidence_reference).strip(); row.review_conclusion=conclusion or row.review_conclusion; row.review_note=review_note.strip() or row.review_note
    _audit(db,request,user,"QUALITY_CASE_UPDATE","QualityCase",row.id,f"{row.case_number} → {target}; conclusion={row.review_conclusion or '—'}"); db.commit(); return RedirectResponse("/quality?tab=" + ("validation" if row.case_type in {"VALIDATION","VERIFICATION"} else "ilc_pt" if row.case_type=="ILC_PT" else "audit" if row.case_type=="AUDIT" else "capa"),303)

@router.post("/work-pattern")
def work_pattern_save(request:Request,user_id:int=Form(...),name:str=Form("Standard"),weekdays:list[int]=Form(...),shift_start:str=Form("08:00"),shift_end:str=Form("16:00"),effective_from:str=Form(""),effective_to:str=Form(""),db:Session=Depends(get_db)):
    actor=require_user(request,db,{Role.SENIOR_CHEMIST.value,Role.TECHNICAL_MANAGER.value}); site=_site(db,actor); target=db.get(User,user_id)
    if not target or target.site_id!=site.id or target.role!=Role.LAB_TECHNICIAN.value or not target.active: raise ValueError("Work patterns can be assigned only to active laboratory chemist/technician accounts at this site")
    days=sorted(set(int(x) for x in weekdays if 0<=int(x)<=6))
    if not days: raise ValueError("Select at least one operating weekday")
    if len(shift_start)!=5 or len(shift_end)!=5 or ':' not in shift_start or ':' not in shift_end: raise ValueError("Shift time must use HH:MM")
    row=db.query(StaffWorkPattern).filter_by(site_id=site.id,user_id=target.id).first()
    if not row:
        row=StaffWorkPattern(site_id=site.id,user_id=target.id,created_by_id=actor.id); db.add(row)
    row.name=name.strip()[:100] or "Standard"; row.weekdays_json=json.dumps(days); row.shift_start=shift_start; row.shift_end=shift_end; row.effective_from=_dt(effective_from); row.effective_to=_dt(effective_to); row.active=True
    db.flush(); _audit(db,request,actor,"WORK_PATTERN_SAVED","StaffWorkPattern",row.id,f"{target.full_name}: {row.name} {days} {shift_start}-{shift_end}"); db.commit(); return RedirectResponse('/workforce#lab-roster',303)


@router.post("/schedule")
def schedule_create(request:Request,user_id:int=Form(...),entry_type:str=Form(...),start_at:str=Form(...),end_at:str=Form(...),status:str=Form("PLANNED"),shift_code:str=Form(""),notes:str=Form(""),db:Session=Depends(get_db)):
    actor=require_user(request,db,SENIOR_WRITE); site=_site(db,actor); start,end=_dt(start_at),_dt(end_at)
    if not start or not end or end<=start: raise ValueError("Schedule end must be after start")
    target=db.get(User,user_id)
    if not target or target.site_id!=site.id: raise ValueError("Employee is outside this laboratory site")
    conflicts=db.query(StaffAvailability).filter(StaffAvailability.user_id==user_id,StaffAvailability.status.in_(["APPROVED","CONFIRMED"]),StaffAvailability.start_at<end,StaffAvailability.end_at>start).count()
    if conflicts and status.upper() in {"APPROVED","CONFIRMED"}: raise ValueError("Schedule conflicts with an approved leave/shift/on-call entry")
    row=StaffAvailability(site_id=site.id,user_id=user_id,entry_type=entry_type.upper(),start_at=start,end_at=end,status=status.upper(),shift_code=shift_code.strip(),notes=notes.strip(),approved_by_id=actor.id if status.upper() in {"APPROVED","CONFIRMED"} else None,created_by_id=actor.id); db.add(row); db.flush(); _audit(db,request,actor,"STAFF_SCHEDULE_CREATE","StaffAvailability",row.id,f"{target.full_name}: {entry_type}"); db.commit(); return RedirectResponse("/workforce#lab-roster",303)

@router.post("/result-rule")
def result_rule(request:Request,test_name:str=Form(...),method_name:str=Form(""),result_field:str=Form(...),unit:str=Form(""),equipment_id:str=Form(""),allowed_states:str=Form("NUMERIC,LTD"),detection_limit:str=Form(""),working_range_min:str=Form(""),working_range_max:str=Form(""),decimals:str=Form(""),rounding_rule:str=Form("SOURCE_CONTROLLED"),report_display_rule:str=Form(""),downstream_rule:str=Form(""),source_reference:str=Form(""),effective_revision:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,QUALITY_WRITE); site=_site(db,user)
    row=TechnicalResultRule(site_id=site.id,test_name=test_name.strip(),method_name=method_name.strip(),result_field=result_field.strip(),unit=unit.strip(),equipment_id=equipment_id.strip(),allowed_states=allowed_states.strip().upper(),detection_limit=_num(detection_limit),working_range_min=_num(working_range_min),working_range_max=_num(working_range_max),decimals=_int(decimals),rounding_rule=rounding_rule.strip().upper(),report_display_rule=report_display_rule.strip(),downstream_rule=downstream_rule.strip(),source_reference=source_reference.strip(),effective_revision=effective_revision.strip())
    db.add(row); db.flush(); _audit(db,request,user,"RESULT_RULE_CREATE","TechnicalResultRule",row.id,f"{test_name}/{result_field}"); db.commit(); return RedirectResponse("/quality?tab=qc",303)

@router.post("/troubleshooting")
def trouble_create(request:Request,test_name:str=Form(""),method_name:str=Form(""),equipment_asset_id:str=Form(""),workstation:str=Form(""),problem:str=Form(...),symptoms:str=Form(""),actions_taken:str=Form(""),safety_impact:str=Form(""),result_integrity_impact:str=Form(""),lessons:str=Form(""),return_to:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value,Role.SENIOR_CHEMIST.value,Role.TECHNICAL_MANAGER.value,Role.EXCELLENCE.value}); site=_site(db,user)
    eqid=_int(equipment_asset_id); domain='EQUIPMENT' if eqid else 'TECHNICAL'
    row=TroubleshootingRecord(site_id=site.id,test_name=test_name.strip(),method_name=method_name.strip(),equipment_asset_id=eqid,workstation=workstation.strip(),problem=problem.strip(),symptoms=symptoms.strip(),actions_taken=actions_taken.strip(),safety_impact=safety_impact.strip(),result_integrity_impact=result_integrity_impact.strip(),lessons=lessons.strip(),status="SUBMITTED",responsible_domain=domain,created_by_id=user.id)
    db.add(row); db.flush(); _audit(db,request,user,"TROUBLESHOOTING_SUBMIT","TroubleshootingRecord",row.id,f"{domain}: {problem[:120]}")
    seniors=db.query(User).filter(User.site_id==site.id,User.active.is_(True),User.role==Role.SENIOR_CHEMIST.value).all()
    for senior in seniors:
        if senior_responsibility(senior)==domain: _notify(db,senior.id,site.id,f"Troubleshooting issue #{row.id}",problem[:160],"/troubleshooting","HIGH","TECHNICAL")
    db.commit(); target=return_to if return_to in {"/troubleshooting","/improvement?tab=troubleshooting"} else "/troubleshooting"; return RedirectResponse(target,303)

@router.post("/troubleshooting/{rid}/note")
def trouble_note(rid:int,request:Request,note:str=Form(...),note_type:str=Form("OBSERVATION"),evidence_reference:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value,Role.SENIOR_CHEMIST.value,Role.TECHNICAL_MANAGER.value,Role.EXCELLENCE.value}); site=_site(db,user); row=db.get(TroubleshootingRecord,rid)
    if not row or row.site_id!=site.id: raise HTTPException(status_code=404,detail="Troubleshooting record not found")
    if not note.strip(): raise ValueError("Observation / note is required")
    item=TroubleshootingNote(troubleshooting_record_id=row.id,author_id=user.id,note_type=note_type.strip().upper() or 'OBSERVATION',note=note.strip(),evidence_reference=evidence_reference.strip()); db.add(item); db.flush()
    _audit(db,request,user,"TROUBLESHOOTING_NOTE_ADD","TroubleshootingRecord",row.id,f"{item.note_type}: {note[:100]}"); db.commit(); return RedirectResponse('/troubleshooting',303)

@router.post("/troubleshooting/{rid}/resolution")
def trouble_resolution(rid:int,request:Request,resolution_text:str=Form(...),root_cause:str=Form(""),evidence_reference:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.SENIOR_CHEMIST.value}); site=_site(db,user); row=db.get(TroubleshootingRecord,rid)
    if not row or row.site_id!=site.id: raise HTTPException(status_code=404,detail="Troubleshooting record not found")
    domain=row.responsible_domain or troubleshooting_domain(row)
    if senior_responsibility(user)!=domain: raise HTTPException(status_code=403,detail=f"This issue belongs to the {domain.title()} Senior responsibility")
    latest=db.query(TroubleshootingResolutionRevision).filter(TroubleshootingResolutionRevision.troubleshooting_record_id==row.id).order_by(TroubleshootingResolutionRevision.revision.desc()).first(); rev=(latest.revision+1) if latest else 1
    item=TroubleshootingResolutionRevision(troubleshooting_record_id=row.id,revision=rev,resolution_text=resolution_text.strip(),root_cause=root_cause.strip(),evidence_reference=evidence_reference.strip(),status='PROPOSED',created_by_id=user.id); db.add(item)
    row.resolution_summary=resolution_text.strip(); row.root_cause=root_cause.strip() or row.root_cause; row.status='RESOLUTION_PROPOSED'; row.senior_verified_by_id=None
    _audit(db,request,user,"TROUBLESHOOTING_RESOLUTION_REVISION","TroubleshootingRecord",row.id,f"Resolution Rev.{rev:02d} proposed"); db.commit(); return RedirectResponse('/troubleshooting',303)

@router.post("/troubleshooting/{rid}/external-evidence")
def trouble_external_evidence(rid:int,request:Request,verifier_name:str=Form(...),company:str=Form(""),contact:str=Form(""),verification_at:str=Form(""),reference:str=Form(""),conclusion:str=Form(""),evidence_reference:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.SENIOR_CHEMIST.value,Role.TECHNICAL_MANAGER.value}); site=_site(db,user); row=db.get(TroubleshootingRecord,rid)
    if not row or row.site_id!=site.id: raise HTTPException(status_code=404,detail="Troubleshooting record not found")
    if user.role==Role.SENIOR_CHEMIST.value and senior_responsibility(user)!=(row.responsible_domain or troubleshooting_domain(row)): raise HTTPException(status_code=403,detail="External evidence must be recorded by the responsible Senior")
    ev=ExternalTechnicalEvidence(troubleshooting_record_id=row.id,verifier_name=verifier_name.strip(),company=company.strip(),contact=contact.strip(),verification_at=_dt(verification_at),reference=reference.strip(),conclusion=conclusion.strip(),evidence_reference=evidence_reference.strip(),recorded_by_id=user.id,reviewed_by_id=user.id if user.role==Role.SENIOR_CHEMIST.value else None); db.add(ev)
    row.status='EVIDENCE_RECEIVED'; _audit(db,request,user,"EXTERNAL_TECHNICAL_EVIDENCE","TroubleshootingRecord",row.id,f"External verification: {verifier_name}"); db.commit(); return RedirectResponse('/troubleshooting',303)

@router.post("/troubleshooting/{rid}/transition")
def trouble_transition(rid:int,request:Request,status:str=Form(...),root_cause:str=Form(""),return_to:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.SENIOR_CHEMIST.value,Role.TECHNICAL_MANAGER.value}); site=_site(db,user); row=db.get(TroubleshootingRecord,rid)
    if not row or row.site_id!=site.id: raise ValueError("Troubleshooting record not found")
    target=status.upper(); domain=row.responsible_domain or troubleshooting_domain(row)
    if target in {'UNDER_TECHNICAL_REVIEW','EXTERNAL_VERIFICATION_REQUIRED','TECHNICALLY_VERIFIED','CLOSED_NOT_PUBLISHED','PENDING_MANAGER_APPROVAL'}:
        if user.role!=Role.SENIOR_CHEMIST.value or senior_responsibility(user)!=domain: raise HTTPException(status_code=403,detail=f"This issue is routed to the {domain.title()} Senior responsibility")
        if target in {'TECHNICALLY_VERIFIED','CLOSED_NOT_PUBLISHED','PENDING_MANAGER_APPROVAL'}:
            latest=db.query(TroubleshootingResolutionRevision).filter(TroubleshootingResolutionRevision.troubleshooting_record_id==row.id).order_by(TroubleshootingResolutionRevision.revision.desc()).first()
            if not latest: raise ValueError("A controlled resolution revision is required before technical verification")
            latest.reviewed_by_id=user.id; latest.status='TECHNICALLY_VERIFIED'; row.senior_verified_by_id=user.id
        row.status=target
    elif target in {'APPROVED','PUBLISHED'}:
        if not is_lab_manager(user): raise HTTPException(status_code=403,detail="Controlled publication requires Lab Operational & Technical Manager approval")
        if not row.senior_verified_by_id: raise ValueError("Manager approval requires prior responsible-Senior technical verification")
        latest=db.query(TroubleshootingResolutionRevision).filter(TroubleshootingResolutionRevision.troubleshooting_record_id==row.id).order_by(TroubleshootingResolutionRevision.revision.desc()).first()
        if not latest: raise ValueError("Resolution revision not found")
        latest.approved_by_id=user.id; latest.status='EFFECTIVE'; latest.effective_at=datetime.utcnow(); row.technical_approved_by_id=user.id; row.published_revision=latest.revision; row.status='PUBLISHED'
    elif target in {'RETURNED_FOR_INFORMATION','REOPENED'}:
        if user.role==Role.SENIOR_CHEMIST.value and senior_responsibility(user)!=domain: raise HTTPException(status_code=403,detail="Responsible Senior required")
        row.status=target
    else: raise ValueError("Unsupported troubleshooting transition")
    row.root_cause=(root_cause or row.root_cause).strip(); _audit(db,request,user,"TROUBLESHOOTING_TRANSITION","TroubleshootingRecord",row.id,row.status); db.commit(); target_url=return_to if return_to in {"/troubleshooting","/improvement?tab=troubleshooting"} else "/troubleshooting"; return RedirectResponse(target_url,303)

@router.post("/evidence")
async def evidence_upload(request:Request,evidence_type:str=Form(...),title:str=Form(...),sample_request_id:str=Form(""),quality_case_id:str=Form(""),equipment_asset_id:str=Form(""),method_name:str=Form(""),run_reference:str=Form(""),upload:UploadFile=File(...),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value,Role.SENIOR_CHEMIST.value,Role.QUALITY.value,Role.EXCELLENCE.value,Role.TECHNICAL_MANAGER.value}); site=_site(db,user); data=await upload.read()
    if len(data)>20_000_000: raise ValueError("Controlled evidence file exceeds 20 MB")
    digest=hashlib.sha256(data).hexdigest(); safe=f"{digest[:16]}_{Path(upload.filename or 'evidence.bin').name.replace('/','_')}"; path=UPLOAD_DIR/safe; path.write_bytes(data)
    eqid=_int(equipment_asset_id); eq=db.get(EquipmentAsset,eqid) if eqid else None
    row=EvidenceRecord(site_id=site.id,sample_request_id=_int(sample_request_id),quality_case_id=_int(quality_case_id),equipment_asset_id=eqid,evidence_type=evidence_type.upper(),title=title.strip(),original_filename=upload.filename or "",stored_path=str(path),sha256=digest,method_name=method_name.strip(),equipment_id_snapshot=eq.equipment_id if eq else "",run_reference=run_reference.strip(),uploaded_by_id=user.id); db.add(row); db.flush(); _audit(db,request,user,"EVIDENCE_UPLOAD","EvidenceRecord",row.id,f"{row.evidence_type}: {title}"); db.commit(); return RedirectResponse("/quality?tab=evidence",303)

@router.post("/report")
def report_create(request:Request,sample_request_id:int=Form(...),report_number:str=Form(""),condition_status:str=Form(""),interpretation:str=Form(""),recommendation:str=Form(""),dga_requested:str=Form(""),corrosive_requested:str=Form(""),paper_requested:str=Form(""),supersedes_report_id:str=Form(""),amendment_reason:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.SENIOR_CHEMIST.value}); site=_site(db,user)
    if not can_review_report(user): raise HTTPException(status_code=403,detail="Official report preparation belongs to the assigned Senior Chemist")
    sample=db.get(SampleRequest,sample_request_id)
    if not sample or sample.site_id!=site.id: raise ValueError("Sample not found")
    assignment=active_review_assignment(db,sample.id)
    if not primary_reviewer(assignment,user):
        raise HTTPException(status_code=403,detail="Final report preparation belongs to the assigned Primary Senior Chemist")
    assessment_record=db.query(TechnicalAssessmentRecord).filter(TechnicalAssessmentRecord.sample_request_id==sample.id).first()
    if not assessment_record or assessment_record.decision!='APPROVED':
        raise ValueError("Final report preparation requires an APPROVED Senior Technical Assessment first")
    assert_sample_period_open(db, sample)
    if sample.status not in {SampleStatus.TECHNICAL_REVIEW.value, SampleStatus.REPORT_APPROVED.value, SampleStatus.REPORT_RELEASED.value}:
        raise ValueError(f"Report cannot be prepared while sample status is {sample.status}; complete analytical work/QC/retest disposition first")
    active=db.query(ControlledReport).filter(ControlledReport.sample_request_id==sample.id,ControlledReport.status.in_(['TECHNICAL_REVIEW','PENDING_MANAGER_APPROVAL'])).order_by(ControlledReport.created_at.desc()).first()
    if active:
        raise ValueError(f"An active final-report review already exists for this sample: {active.report_number} Rev {active.revision}")
    supersedes=_int(supersedes_report_id)
    if sample.status == SampleStatus.REPORT_RELEASED.value and not supersedes:
        raise ValueError("A released sample requires an amendment/supersedes reference; create a new revision instead of a duplicate final report")
    if supersedes:
        prev=db.get(ControlledReport,supersedes)
        if not prev or prev.sample_request_id!=sample.id: raise ValueError("Amendment must supersede a report for the same sample")
        if prev.status != SampleStatus.REPORT_RELEASED.value: raise ValueError("Only an officially released report can be superseded")
        if not amendment_reason.strip(): raise ValueError("Amendment reason is required")
        revision=max(prev.revision+1,1)
    else:
        revision=1
    condition=condition_status.strip().upper() or 'NOT_SELECTED'
    if condition not in {'NOT_SELECTED','NORMAL','CAUTION','CRITICAL'}: raise ValueError('Condition must be NOT_SELECTED, NORMAL, CAUTION or CRITICAL')
    # The report number and special-section flags are system-derived by default. This removes
    # avoidable Senior data-entry decisions while preserving explicit values for amendments/tests.
    report_number_clean=(report_number or '').strip()
    if not report_number_clean:
        report_number_clean=f"{sample.request_number.replace('FS-','FSR-',1)}-R{max(revision-1,0)}"
    _, ops_payload = get_operations_state(db, site)
    sample_results=[r for r in ops_payload.get('results',[]) if isinstance(r,dict) and str(r.get('sample') or '')==sample.request_number]
    result_names=' | '.join(str(r.get('display_test') or r.get('test') or '').lower() for r in sample_results)
    auto_dga=any(token in result_names for token in ('hydrogen','methane','ethane','ethylene','acetylene','carbon monoxide','carbon dioxide','dga:'))
    auto_corrosive=any(token in result_names for token in ('corrosive sulfur','tarnish','ccd','copper corrosion'))
    auto_paper=any(token in result_names for token in ('direct dp','degree of polymerization'))
    payload={
        "dga_requested":(dga_requested=="1") or auto_dga,
        "corrosive_sulfur_requested":(corrosive_requested=="1") or auto_corrosive,
        "paper_dp_requested":(paper_requested=="1") or auto_paper,
        "asset_id":sample.asset_id,"sample_origin":sample.sample_origin,"sampling_point":sample.sampling_point,"source_sample_status":sample.status,
        "senior_review":{"started_by_id":user.id,"started_by":user.full_name,"started_at":datetime.utcnow().isoformat(),"confirmations":{},"status":"IN_PROGRESS"},
    }
    row=ControlledReport(site_id=site.id,sample_request_id=sample.id,report_number=report_number_clean,revision=revision,condition_status=condition,interpretation=interpretation.strip(),recommendation=recommendation.strip(),report_payload_json=json.dumps(payload),qr_token=secrets.token_urlsafe(24),reviewed_by_id=None,status="TECHNICAL_REVIEW",lms_status='NOT_APPLICABLE',supersedes_report_id=supersedes,amendment_reason=amendment_reason.strip())
    db.add(row); db.flush()
    _audit(db,request,user,"REPORT_SENIOR_REVIEW_STARTED","ControlledReport",row.id,f"{row.report_number} Rev {row.revision} opened for Senior final-report review")
    db.commit(); return RedirectResponse(f"/control/report/{row.id}/review",303)


def _client_report_snapshot_hash(payload: dict) -> str:
    return hashlib.sha256(json.dumps(payload, sort_keys=True, default=str, separators=(",", ":")).encode("utf-8")).hexdigest()


@router.get("/report/{rid}/review")
def report_review_page(rid:int,request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.SENIOR_CHEMIST.value,Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value}); site=_site(db,user)
    row=db.get(ControlledReport,rid)
    if not row or row.site_id!=site.id: raise ValueError("Report not found")
    assignment=active_review_assignment(db,row.sample_request_id)
    # Non-assigned Seniors may inspect the package read-only for visibility/UAT continuity;
    # writable review remains restricted by can_edit_review / Primary Senior checks.
    verification_url=str(request.base_url).rstrip('/')+f'/verify/report/{row.qr_token}'
    flags=_report_flags(row); review=flags.get('senior_review') if isinstance(flags.get('senior_review'),dict) else {}
    manager_review=flags.get('manager_review') if isinstance(flags.get('manager_review'),dict) else {}
    # Once the Senior technically signs off, every downstream reviewer sees the exact
    # client-facing draft that was signed. Release may add only approval/release metadata.
    signed_snapshot = review.get('client_preview_snapshot') if isinstance(review.get('client_preview_snapshot'), dict) else None
    report_payload = json.loads(json.dumps(signed_snapshot)) if signed_snapshot else build_final_report_payload(db,row,site,verification_url=verification_url)
    cards=_report_result_review_cards(report_payload,row.sample_request_id)
    requirements=_report_review_requirements(db,row,report_payload,cards)
    screening=_system_technical_screening(db,row)
    selected_condition=(str(row.condition_status or '').upper() if review.get('condition_selected') else 'NOT_SELECTED')
    return templates.TemplateResponse('senior_final_report_review.html',{
        'request':request,'user':user,'site':site,'report':row,'report_payload':report_payload,'result_cards':cards,'result_groups':_report_result_review_groups(cards),
        'requirements':requirements,'auto_ready':all(item['ok'] for item in requirements),'review':review,'manager_review':manager_review,'screening':screening,'selected_condition':selected_condition,
        'review_assignment':assignment,
        'can_edit_review':bool(user.role==Role.SENIOR_CHEMIST.value and row.status=='TECHNICAL_REVIEW' and primary_reviewer(assignment,user)),
        'can_manager_review':bool(is_lab_manager(user) and row.status=='PENDING_MANAGER_APPROVAL' and manager_review.get('status','PENDING_INTERNAL_REVIEW')=='PENDING_INTERNAL_REVIEW'),
        'can_manager_approve':bool(is_lab_manager(user) and row.status=='PENDING_MANAGER_APPROVAL' and manager_review.get('status')=='INTERNAL_APPROVED'),
    })


@router.post("/report/{rid}/review")
def report_review_save(
    rid:int,request:Request,action:str=Form("SAVE"),condition_status:str=Form(""),interpretation:str=Form(""),recommendation:str=Form(""),
    confirm_results:str=Form(""),confirm_identity:str=Form(""),confirm_interpretation:str=Form(""),confirm_evidence:str=Form(""),confirm_recommendation:str=Form(""),confirm_client_preview:str=Form(""),
    db:Session=Depends(get_db),
):
    user=require_user(request,db,{Role.SENIOR_CHEMIST.value}); site=_site(db,user)
    row=db.get(ControlledReport,rid)
    if not row or row.site_id!=site.id: raise ValueError("Report not found")
    assignment=active_review_assignment(db,row.sample_request_id)
    if not primary_reviewer(assignment,user):
        raise HTTPException(status_code=403,detail="Final report review belongs to the assigned Primary Senior Chemist")
    if row.status!='TECHNICAL_REVIEW': raise ValueError(f"Senior review cannot be edited from status {row.status}")
    assert_sample_period_open(db,row.sample)
    condition=condition_status.strip().upper() or 'NOT_SELECTED'
    if condition not in {'NOT_SELECTED','NORMAL','CAUTION','CRITICAL'}: raise ValueError('Condition must be NOT_SELECTED, NORMAL, CAUTION or CRITICAL')
    row.condition_status=condition; row.interpretation=interpretation.strip(); row.recommendation=recommendation.strip()
    flags=_report_flags(row); review=flags.get('senior_review') if isinstance(flags.get('senior_review'),dict) else {}
    review.update({
        'last_saved_by_id':user.id,'last_saved_by':user.full_name,'last_saved_at':datetime.utcnow().isoformat(),
        'condition_selected': condition in {'NORMAL','CAUTION','CRITICAL'},
        'confirmations':{
            'results':confirm_results=='1','identity':confirm_identity=='1','interpretation':confirm_interpretation=='1',
            'evidence':confirm_evidence=='1','recommendation':confirm_recommendation=='1','client_preview':confirm_client_preview=='1',
        },
    })
    flags['senior_review']=review; row.report_payload_json=json.dumps(flags)
    if action.upper()!='COMPLETE':
        _audit(db,request,user,'REPORT_SENIOR_REVIEW_DRAFT_SAVED','ControlledReport',row.id,f'{row.report_number} Rev {row.revision} Senior review draft saved')
        db.commit(); return RedirectResponse(f'/control/report/{row.id}/review',303)

    verification_url=str(request.base_url).rstrip('/')+f'/verify/report/{row.qr_token}'
    report_payload=build_final_report_payload(db,row,site,verification_url=verification_url)
    cards=_report_result_review_cards(report_payload,row.sample_request_id)
    requirements=_report_review_requirements(db,row,report_payload,cards)
    blocked=[item['detail'] for item in requirements if not item['ok']]
    if blocked: raise ValueError('Final report review is blocked: '+' | '.join(blocked))
    if condition not in {'NORMAL','CAUTION','CRITICAL'}: raise ValueError('Select the final Overall Condition before completing Senior review')
    confirmations=review.get('confirmations') or {}
    if not all(confirmations.get(k) for k in ('results','identity','interpretation','evidence','recommendation','client_preview')):
        raise ValueError('Complete all Senior final-report review confirmations before submitting to the Lab Operational & Technical Manager')
    if not row.interpretation.strip(): raise ValueError('Senior interpretation is required before final report approval')
    # Freeze the exact client-facing draft the Senior reviewed. This prevents a later
    # Manager view or release from silently rebuilding different analytical content.
    report_payload['report']['status'] = 'Draft — Not Released'
    report_payload['approval']['reviewed_by'] = user.full_name
    report_payload['approval']['approved_by'] = '—'
    report_payload['approval']['approved_at'] = '—'
    report_payload['approval']['approved_at_full'] = '—'
    review.update({
        'status':'COMPLETED','completed_by_id':user.id,'completed_by':user.full_name,'completed_at':datetime.utcnow().isoformat(),
        'client_preview_snapshot': report_payload,
        'client_preview_sha256': _client_report_snapshot_hash(report_payload),
    })
    flags['senior_review']=review
    flags['manager_review']={'status':'PENDING_INTERNAL_REVIEW','submitted_at':datetime.utcnow().isoformat(),'comment':''}
    row.report_payload_json=json.dumps(flags); row.reviewed_by_id=user.id; row.status='PENDING_MANAGER_APPROVAL'
    if row.sample.status != SampleStatus.REPORT_RELEASED.value:
        row.sample.status=SampleStatus.REPORT_APPROVED.value
    else:
        # Amendment review keeps the previously issued report available to the client until the new revision is approved.
        row.sample.status=SampleStatus.REPORT_APPROVED.value
    sync_case_from_sample(db,row.sample,user,note='Senior Chemist completed final Analysis Report review; pending Lab Operational & Technical Manager final approval')
    for manager in db.query(User).filter(User.site_id==site.id,User.active.is_(True),User.role==Role.TECHNICAL_MANAGER.value).all():
        _notify(db,manager.id,site.id,f'{row.report_number} ready for final approval',f'Senior final-report review is complete for {row.sample.request_number}. Review the report and release only if acceptable.',f'/control/report/{row.id}/review','HIGH','REPORT')
    _audit(db,request,user,'REPORT_SENIOR_REVIEW_COMPLETED','ControlledReport',row.id,f'{row.report_number} Rev {row.revision} Senior review completed and submitted to Lab Operational & Technical Manager')
    db.commit(); return RedirectResponse('/control/reports',303)


@router.post("/report/{rid}/manager-review")
def report_manager_review(rid:int,request:Request,action:str=Form(...),comment:str=Form(""),confirm_client_preview:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.TECHNICAL_MANAGER.value}); site=_site(db,user)
    if not is_lab_manager(user):
        raise HTTPException(status_code=403,detail="Internal final-report package review belongs to the Lab Operational & Technical Manager")
    row=db.get(ControlledReport,rid)
    if not row or row.site_id!=site.id: raise ValueError("Report not found")
    if row.status!='PENDING_MANAGER_APPROVAL':
        raise ValueError(f"Manager review requires a Senior-completed package; report status is {row.status}")
    flags=_report_flags(row)
    senior_review=flags.get('senior_review') if isinstance(flags.get('senior_review'),dict) else {}
    if senior_review.get('status')!='COMPLETED' or not row.reviewed_by_id:
        raise ValueError("Manager review requires completed Senior final-report review")
    action_value=(action or '').strip().upper()
    note=(comment or '').strip()
    now=datetime.utcnow()
    if action_value=='APPROVE_INTERNAL':
        if confirm_client_preview != '1':
            raise ValueError('Review the complete client-facing QDF-[7]-08-A draft and confirm the exact release snapshot before manager approval')
        signed_snapshot = senior_review.get('client_preview_snapshot') if isinstance(senior_review.get('client_preview_snapshot'), dict) else None
        if not signed_snapshot:
            raise ValueError('Senior client-report snapshot is missing; return the package for controlled re-signoff')
        signed_hash = senior_review.get('client_preview_sha256') or _client_report_snapshot_hash(signed_snapshot)
        flags['manager_review']={
            'status':'INTERNAL_APPROVED','reviewed_by_id':user.id,'reviewed_by':user.full_name,
            'reviewed_at':now.isoformat(),'comment':note,'client_preview_confirmed':True,
            'client_preview_sha256': signed_hash,
        }
        row.report_payload_json=json.dumps(flags)
        _audit(db,request,user,'REPORT_MANAGER_INTERNAL_REVIEW_APPROVED','ControlledReport',row.id,f'{row.report_number} Rev {row.revision} internal review package approved; final TSCO release review unlocked')
    elif action_value=='RETURN':
        if not note: raise ValueError("Return reason is required")
        flags['manager_review']={
            'status':'RETURNED','reviewed_by_id':user.id,'reviewed_by':user.full_name,
            'reviewed_at':now.isoformat(),'comment':note,
        }
        senior_review['status']='RETURNED_FOR_CORRECTION'
        senior_review['manager_return_reason']=note
        flags['senior_review']=senior_review
        row.report_payload_json=json.dumps(flags); row.status='TECHNICAL_REVIEW'
        if row.sample.status != SampleStatus.REPORT_RELEASED.value:
            row.sample.status=SampleStatus.TECHNICAL_REVIEW.value
        sync_case_from_sample(db,row.sample,user,note='Lab Operational & Technical Manager returned internal final-report package to assigned Senior for correction')
        assignment=active_review_assignment(db,row.sample_request_id)
        if assignment:
            _notify(db,assignment.primary_senior_id,site.id,f'{row.report_number} returned for correction',note,f'/control/report/{row.id}/review','HIGH','REPORT')
        _audit(db,request,user,'REPORT_MANAGER_RETURNED_TO_SENIOR','ControlledReport',row.id,f'{row.report_number} Rev {row.revision} returned: {note}')
    elif action_value=='HOLD':
        if not note: raise ValueError("Hold / investigation reason is required")
        flags['manager_review']={
            'status':'HOLD','reviewed_by_id':user.id,'reviewed_by':user.full_name,
            'reviewed_at':now.isoformat(),'comment':note,
        }
        row.report_payload_json=json.dumps(flags)
        _audit(db,request,user,'REPORT_MANAGER_HOLD','ControlledReport',row.id,f'{row.report_number} Rev {row.revision} held pending investigation: {note}')
    else:
        raise ValueError("Unsupported manager review action")
    db.commit(); return RedirectResponse(f'/control/report/{row.id}/review',303)


@router.post("/report/{rid}/approve")
def report_approve(rid:int,request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.TECHNICAL_MANAGER.value}); site=_site(db,user)
    if not is_lab_manager(user): raise HTTPException(status_code=403,detail="Final report approval/stamp belongs to the Lab Operational & Technical Manager")
    row=db.get(ControlledReport,rid)
    if not row or row.site_id!=site.id: raise ValueError("Report not found")
    if row.status != 'PENDING_MANAGER_APPROVAL': raise ValueError(f"Report cannot be approved from status {row.status}; Senior final-report review must be completed first")
    assert_sample_period_open(db, row.sample)
    if row.sample.status != SampleStatus.REPORT_APPROVED.value:
        raise ValueError(f"Final release requires completed Senior technical review; sample status is {row.sample.status}")
    request_flags=json.loads(row.report_payload_json or "{}")
    senior_review=request_flags.get('senior_review') if isinstance(request_flags.get('senior_review'),dict) else {}
    manager_review=request_flags.get('manager_review') if isinstance(request_flags.get('manager_review'),dict) else {}
    if manager_review.get('status')!='INTERNAL_APPROVED':
        raise ValueError('Final release requires Lab Operational & Technical Manager approval of the internal final-report review package first')
    if not manager_review.get('client_preview_confirmed'):
        raise ValueError('Final release requires confirmed review of the exact client-facing QDF-[7]-08-A snapshot')
    confirmations=senior_review.get('confirmations') if isinstance(senior_review.get('confirmations'),dict) else {}
    if senior_review.get('status')!='COMPLETED' or not senior_review.get('completed_at') or not row.reviewed_by_id:
        raise ValueError('Lab Operational & Technical Manager approval requires a completed Senior Final Report Review')
    if not all(confirmations.get(k) for k in ('results','identity','interpretation','evidence','recommendation','client_preview')):
        raise ValueError('Senior Final Report Review checklist is incomplete')
    evidences=db.query(EvidenceRecord).filter(EvidenceRecord.sample_request_id==row.sample_request_id).all()
    types={str(e.evidence_type or "").upper() for e in evidences}
    sample_no = str(row.sample.request_number or '')
    matching_db_dga = any(str(e.evidence_type or '').upper() == 'DGA_SOURCE' and _dga_source_identity_matches(sample_no, str(e.original_filename or e.title or '')) for e in evidences)
    if request_flags.get("dga_requested") and not matching_db_dga and not _operations_dga_source(db, row):
        raise ValueError("DGA report approval requires original DGA source evidence linked to the same sample")
    if request_flags.get("corrosive_sulfur_requested"):
        strip_pair={"CORROSIVE_FRONT","CORROSIVE_BACK"}.issubset(types)
        ccd_set={"CORROSIVE_COPPER","CORROSIVE_PAPER_INNER","CORROSIVE_PAPER_OUTER"}.issubset(types)
        if not (strip_pair or ccd_set):
            raise ValueError("Corrosive Sulfur / CCD approval requires either Front + Back strip evidence or Copper + Paper Inner + Paper Outer evidence")

    signed_snapshot = senior_review.get('client_preview_snapshot') if isinstance(senior_review.get('client_preview_snapshot'), dict) else None
    signed_hash = senior_review.get('client_preview_sha256')
    if not signed_snapshot or not signed_hash:
        raise ValueError('Final release requires the immutable Senior-signed client-report snapshot')
    if _client_report_snapshot_hash(signed_snapshot) != signed_hash or manager_review.get('client_preview_sha256') != signed_hash:
        raise ValueError('Client-report snapshot integrity check failed; controlled Senior/Manager review must be repeated')

    approved_at=datetime.utcnow()
    row.approved_by_id=user.id; row.approved_at=approved_at; row.report_template_code=REPORT_TEMPLATE_CODE
    db.flush()
    verification_url=str(request.base_url).rstrip('/')+f'/verify/report/{row.qr_token}'
    final_payload=json.loads(json.dumps(signed_snapshot))
    final_payload['approval']['approved_by']=user.full_name
    final_payload['approval']['approved_at']=approved_at.strftime('%d/%m/%Y')
    final_payload['approval']['approved_at_full']=approved_at.strftime('%d/%m/%Y %H:%M')
    final_payload['report']['status']='Officially Released'
    final_payload['report']['verification_url']=verification_url

    safe=''.join(ch if ch.isalnum() or ch in '-_.' else '_' for ch in row.report_number)
    pdf_path=REPORT_DIR/f"{safe}_R{row.revision}.pdf"
    build_final_report_pdf(final_payload,pdf_path,qr_url=verification_url)
    pdf_sha=hashlib.sha256(pdf_path.read_bytes()).hexdigest()
    row.official_pdf_path=str(pdf_path); row.official_pdf_sha256=pdf_sha; row.official_pdf_generated_at=approved_at

    snapshot={
        "schema":"TSCO_FINAL_ANALYSIS_REPORT_V1",
        "template_code":REPORT_TEMPLATE_CODE,
        "report_number":row.report_number,"revision":row.revision,
        "sample_request_id":row.sample_request_id,"sample_request_number":row.sample.request_number,
        "client_id":row.sample.client_id,"asset_id":row.sample.asset_id,
        "condition_status":row.condition_status,"interpretation":row.interpretation,"recommendation":row.recommendation,
        "senior_review":senior_review,
        "manager_internal_review":manager_review,
        "report_payload":final_payload,
        "evidence":[{"id":e.id,"type":e.evidence_type,"sha256":e.sha256,"reference":e.run_reference} for e in evidences],
        "reviewed_by_id":row.reviewed_by_id,"approved_by_id":user.id,"approved_at":approved_at.isoformat(),
        "official_pdf_sha256":pdf_sha,"release_system":"TSCO_DIGITAL_LABORATORY_PLATFORM"
    }
    row.approved_snapshot_json=json.dumps(snapshot,sort_keys=True,default=str)
    release_tsco_official_report(db,row.sample,user,report_reference=row.report_number,note="Lab Operational & Technical Manager completed final TSCO report review, approved/stamped and released the official Analysis Report",controlled_report=row)
    close_review_assignment(db,row.sample_request_id)
    _audit(db,request,user,"REPORT_MANAGER_APPROVED_RELEASED","ControlledReport",row.id,f"{row.report_number} Rev {row.revision}; internal package reviewed, immutable client report PDF {pdf_sha[:12]} stored and officially released")
    for p in db.query(User).filter(User.site_id==site.id,User.active.is_(True),User.role.in_([Role.SENIOR_CHEMIST.value,Role.CLIENT_COORDINATOR.value])).all():
        _notify(db,p.id,site.id,f"{row.report_number} officially released","The official TSCO Analysis Report PDF is approved, immutable and ready for controlled client submission.","/control/reports","HIGH","REPORT")
    db.commit(); return RedirectResponse("/control/reports",303)

@router.post("/report/{rid}/submission")
def report_submission(rid:int,request:Request,channel:str=Form(...),recipient:str=Form(""),submission_reference:str=Form(""),note:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.CLIENT_COORDINATOR.value}); site=_site(db,user)
    if not can_submit_client_report(user): raise HTTPException(status_code=403,detail="Official client submission record belongs to Client Account & Coordination")
    row=db.get(ControlledReport,rid)
    if not row or row.site_id!=site.id: raise HTTPException(status_code=404,detail="Released report not found")
    if row.status!=SampleStatus.REPORT_RELEASED.value: raise ValueError("Client submission can reference only the officially released report")
    channel_value=channel.strip().upper()
    if channel_value not in {"PORTAL","EMAIL","TRANSMITTAL","OTHER"}: raise ValueError("Unsupported client submission channel")
    if not submission_reference.strip(): raise ValueError("Submission reference is required")
    case=db.get(CommercialCase,row.sample.commercial_case_id) if row.sample.commercial_case_id else None
    if case and case.assigned_coordinator_id and case.assigned_coordinator_id!=user.id:
        raise HTTPException(status_code=403,detail="This Business Case belongs to another Assigned Coordinator")
    sub=ReportSubmission(controlled_report_id=row.id,client_id=row.sample.client_id,channel=channel_value,recipient=recipient.strip(),submission_reference=submission_reference.strip(),note=note.strip(),submitted_by_id=user.id); db.add(sub); db.flush()
    if case:
        current=effective_stage(db,case)
        if current != "REPORT_SUBMISSION":
            add_commercial_event(db,case,user,"REPORT_SUBMISSION",note=note.strip() or "Official released report submitted to client",reference=sub.submission_reference,from_stage=current)
        case.current_stage="REPORT_SUBMISSION"; case.report_submission_reference=sub.submission_reference; case.corporate_admin_status="SENT_TO_PARENT_ADMINISTRATION"
        if case.request_source == "CLIENT_PORTAL":
            case.request_status = "REPORT_SUBMITTED"
    _audit(db,request,user,"REPORT_CLIENT_SUBMISSION","ReportSubmission",sub.id,f"{row.report_number} via {sub.channel} to {sub.recipient or 'client'}"); db.commit(); return RedirectResponse(f'/commercial?case_id={case.id if case else ""}',303)

@router.post("/asset/{aid}/history")
def asset_history(aid:int,request:Request,event_type:str=Form(...),event_at:str=Form(...),report_number:str=Form(""),details:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,SENIOR_WRITE); asset=db.get(Asset,aid)
    if not asset: raise ValueError("Asset not found")
    row=AssetHistoryEvent(asset_id=aid,event_type=event_type.upper(),event_at=_dt(event_at) or datetime.utcnow(),report_number=report_number.strip(),details=details.strip(),created_by_id=user.id); db.add(row); db.flush(); _audit(db,request,user,"ASSET_HISTORY_ADD","Asset",aid,event_type); db.commit(); return RedirectResponse("/control?tab=assets",303)

@router.get("/api/summary")
def api_summary(request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,VIEW); site=_site(db,user); now=datetime.utcnow()
    return {"site":site.code,"equipment":{"total":db.query(EquipmentAsset).filter_by(site_id=site.id).count(),"blocked":db.query(EquipmentAsset).filter(EquipmentAsset.site_id==site.id,EquipmentAsset.status.in_(["OUT_OF_SERVICE","CALIBRATION_DUE","DEFECTIVE"])).count()},"quality":{"open":db.query(QualityCase).filter(QualityCase.site_id==site.id,~QualityCase.status.in_(["CLOSED","APPROVED"])).count()},"competency":{"active":db.query(CompetencyRecord).filter_by(site_id=site.id,active=True).count()},"schedule":{"active_now":db.query(StaffAvailability).filter(StaffAvailability.site_id==site.id,StaffAvailability.start_at<=now,StaffAvailability.end_at>=now).count()},"reports":{"released":db.query(ControlledReport).filter_by(site_id=site.id,status=SampleStatus.REPORT_RELEASED.value).count()}}

def _roster_conflict(db: Session, user_id: int, start: datetime, end: datetime):
    return db.query(StaffAvailability).filter(
        StaffAvailability.user_id == user_id,
        StaffAvailability.entry_type.in_(["SHIFT", "ON_CALL"]),
        StaffAvailability.status.in_(["PLANNED", "APPROVED", "CONFIRMED"]),
        StaffAvailability.start_at < end, StaffAvailability.end_at > start,
    ).order_by(StaffAvailability.start_at).first()


def _availability_conflict(db: Session, user_id: int, start: datetime, end: datetime, *, include_roster: bool = False):
    types = ["LEAVE", "HOLIDAY", "TRAINING", "UNAVAILABLE"]
    if include_roster:
        types += ["SHIFT", "ON_CALL"]
    return db.query(StaffAvailability).filter(
        StaffAvailability.user_id == user_id,
        StaffAvailability.entry_type.in_(types),
        ~StaffAvailability.status.in_(["CANCELLED", "REJECTED"]),
        StaffAvailability.start_at < end, StaffAvailability.end_at > start,
    ).order_by(StaffAvailability.start_at).first()


def _leave_approver_with_field_fallback(db: Session, employee: User, start: datetime, end: datetime) -> User | None:
    approver = employee.leave_approver
    if employee.role != Role.FIELD_SAMPLER.value or not approver or approver.role != Role.SAMPLING_SUPERVISOR.value:
        return approver
    if _availability_conflict(db, approver.id, start, end):
        fallback = approver.manager
        if fallback and fallback.active and fallback.role == Role.OPERATIONS_MANAGER.value:
            return fallback
    return approver


def _senior_coverage_snapshot(db: Session, employee: User, start: datetime, end: datetime, acting_user_id: int | None):
    required = max(1, int(os.getenv("MIN_SENIOR_COVERAGE", "2") or "2"))
    seniors = list(db.query(User).filter(
        User.site_id == employee.site_id, User.active.is_(True), User.role == Role.SENIOR_CHEMIST.value, User.id != employee.id
    ).order_by(User.full_name).all())
    available = [p for p in seniors if not _availability_conflict(db, p.id, start, end, include_roster=True)]
    acting = next((p for p in available if acting_user_id and p.id == acting_user_id), None)
    ok = len(available) >= required and acting is not None
    if not acting_user_id:
        note = "Acting / Backup Senior is required for the absent Senior responsibility domain."
    elif acting is None:
        note = "Selected Acting / Backup Senior is unavailable or outside the Senior Chemist coverage pool."
    elif len(available) < required:
        note = f"Minimum Senior coverage is {required}; only {len(available)} eligible Senior(s) remain available in the requested period."
    else:
        note = f"Coverage valid: {len(available)} available Senior(s); acting responsibility assigned to {acting.full_name}."
    return {"required": required, "available": available, "acting": acting, "ok": ok, "note": note}


def _upsert_senior_coverage(db: Session, leave: StaffAvailability, actor: User, acting_user_id: int | None) -> LeaveCoverageAssignment:
    snap = _senior_coverage_snapshot(db, leave.user, leave.start_at, leave.end_at, acting_user_id)
    row = db.query(LeaveCoverageAssignment).filter(LeaveCoverageAssignment.leave_availability_id == leave.id).first()
    if not row:
        row = LeaveCoverageAssignment(
            leave_availability_id=leave.id, site_id=leave.site_id, absent_user_id=leave.user_id,
            responsibility_domain=leave.user.senior_responsibility_domain or "SHARED",
        )
        db.add(row)
    row.acting_user_id = snap["acting"].id if snap["acting"] else None
    row.required_minimum = snap["required"]
    row.available_senior_count = len(snap["available"])
    row.status = "COVERAGE_OK" if snap["ok"] else "ACTION_REQUIRED"
    row.note = snap["note"]
    row.checked_by_id = actor.id
    row.checked_at = datetime.utcnow()
    return row


@router.get("/my-availability")
def my_availability(request:Request,db:Session=Depends(get_db)):
    allowed={
        Role.FIELD_SAMPLER.value, Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value, Role.DATA_ENTRY.value,
        Role.CLIENT_COORDINATOR.value, Role.LAB_TECHNICIAN.value, Role.SENIOR_CHEMIST.value,
        Role.TECHNICAL_MANAGER.value, Role.MANAGEMENT.value, Role.SALES_MARKETING.value,
        Role.EXCELLENCE.value, Role.CORPORATE_SUPPORT.value, Role.LAB_SUPPORT.value,
        Role.SYSTEM_ADMIN.value,
    }
    user=require_user(request,db,allowed); site=_site(db,user)
    rows_query=db.query(StaffAvailability).filter(StaffAvailability.entry_type=="LEAVE")
    fallback_leave_ids=set()
    if user.role==Role.SYSTEM_ADMIN.value:
        rows=rows_query.order_by(StaffAvailability.start_at.desc()).limit(500).all()
    elif user.role==Role.OPERATIONS_MANAGER.value:
        # The Field Manager normally sees only directly-routed requests. For Sampleman leave,
        # also surface an existing Supervisor-routed request if that Supervisor later becomes
        # unavailable for the requested period, so the approved fallback is actually actionable.
        candidates=rows_query.filter(StaffAvailability.site_id==site.id).order_by(StaffAvailability.start_at.desc()).limit(500).all()
        rows=[]
        for leave in candidates:
            direct = leave.user_id==user.id or leave.approver_id==user.id
            fallback = (
                leave.status=="PENDING_MANAGER"
                and leave.user is not None and leave.user.role==Role.FIELD_SAMPLER.value
                and leave.approver is not None and leave.approver.role==Role.SAMPLING_SUPERVISOR.value
                and leave.approver.manager_id==user.id
                and _availability_conflict(db, leave.approver.id, leave.start_at, leave.end_at) is not None
            )
            if direct or fallback:
                rows.append(leave)
                if fallback:
                    fallback_leave_ids.add(leave.id)
            if len(rows)>=300:
                break
    else:
        rows=rows_query.filter(or_(StaffAvailability.user_id==user.id, StaffAvailability.approver_id==user.id)).order_by(StaffAvailability.start_at.desc()).limit(300).all()
    direct_reports=list(db.query(User).filter(User.active.is_(True), User.manager_id==user.id).order_by(User.full_name).all())
    roster=db.query(StaffAvailability).filter(StaffAvailability.user_id==user.id,StaffAvailability.entry_type.in_(["SHIFT","ON_CALL"]),StaffAvailability.status.in_(["PLANNED","APPROVED","CONFIRMED"])).order_by(StaffAvailability.start_at.desc()).limit(120).all()
    night_months=db.query(NightShiftMonthPlan).filter(NightShiftMonthPlan.user_id==user.id).order_by(NightShiftMonthPlan.year.desc(),NightShiftMonthPlan.month.desc()).limit(24).all()
    senior_candidates=[]
    if user.role in {Role.SENIOR_CHEMIST.value,Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value}:
        senior_candidates=list(db.query(User).filter(User.site_id==site.id,User.active.is_(True),User.role==Role.SENIOR_CHEMIST.value).order_by(User.full_name).all())
    leave_ids=[r.id for r in rows]
    coverage_by_leave={}
    if leave_ids:
        coverage_by_leave={r.leave_availability_id:r for r in db.query(LeaveCoverageAssignment).filter(LeaveCoverageAssignment.leave_availability_id.in_(leave_ids)).all()}
    return templates.TemplateResponse("my_availability.html",{
        "request":request,"user":user,"site":site,"rows":rows,"direct_reports":direct_reports,"roster":roster,"night_months":night_months,
        "senior_candidates":senior_candidates,"coverage_by_leave":coverage_by_leave,"fallback_leave_ids":fallback_leave_ids,
        "can_request_leave": bool(user.leave_approver_id) or employee_is_named(user.email),
        "is_named_employee":employee_is_named(user.email),
    })

@router.post("/availability/request")
def availability_request(request:Request,start_at:str=Form(...),end_at:str=Form(...),notes:str=Form(""),acting_senior_id:str=Form(""),db:Session=Depends(get_db)):
    allowed={
        Role.FIELD_SAMPLER.value, Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value, Role.DATA_ENTRY.value,
        Role.CLIENT_COORDINATOR.value, Role.LAB_TECHNICIAN.value, Role.SENIOR_CHEMIST.value,
        Role.TECHNICAL_MANAGER.value, Role.MANAGEMENT.value, Role.SALES_MARKETING.value,
        Role.EXCELLENCE.value, Role.CORPORATE_SUPPORT.value, Role.LAB_SUPPORT.value,
    }
    user=require_user(request,db,allowed); site=_site(db,user)
    # UAT review identities are job-title personas. If an explicit leave approver is
    # configured, they must be able to exercise the same approval route that a named
    # production employee will inherit. Shared-Service function accounts remain blocked
    # because their real reporting line was not supplied and is intentionally not guessed.
    if not user.leave_approver_id and user.role != Role.MANAGEMENT.value:
        raise ValueError("No leave approver is configured for this review identity; the reporting line must be confirmed before leave planning can be exercised.")
    start,end=_dt(start_at),_dt(end_at)
    if not start or not end or end<=start: raise ValueError("Leave-plan end must be after start")
    conflict=_roster_conflict(db,user.id,start,end)
    if conflict:
        raise ValueError(f"Leave conflicts with {conflict.entry_type} roster {conflict.start_at:%Y-%m-%d %H:%M}–{conflict.end_at:%Y-%m-%d %H:%M}. Replan the roster before submitting leave.")
    approver=_leave_approver_with_field_fallback(db,user,start,end)
    status="PENDING_MANAGER" if approver else "EXTERNAL_APPROVAL_REQUIRED"
    if user.role==Role.SENIOR_CHEMIST.value:
        status="COVERAGE_ACTION_REQUIRED"
    row=StaffAvailability(
        site_id=site.id,user_id=user.id,entry_type="LEAVE",start_at=start,end_at=end,status=status,
        notes=notes.strip(),approver_id=approver.id if approver else None,created_by_id=user.id
    )
    db.add(row); db.flush()
    if user.role==Role.SENIOR_CHEMIST.value:
        coverage=_upsert_senior_coverage(db,row,user,_int(acting_senior_id))
        if coverage.status=="COVERAGE_OK" and approver:
            row.status="PENDING_MANAGER"
        elif coverage.status!="COVERAGE_OK":
            row.status="COVERAGE_ACTION_REQUIRED"
    if approver and row.status=="PENDING_MANAGER":
        _notify(db,approver.id,site.id,f"Leave plan awaiting approval — {user.full_name}",f"{start.date()} to {end.date()}","/control/my-availability","NORMAL","LEAVE")
    route_label="Field Manager fallback" if user.role==Role.FIELD_SAMPLER.value and user.leave_approver_id and approver and approver.id!=user.leave_approver_id else "Configured leave approver"
    _audit(db,request,user,"LEAVE_PLAN_REQUEST","StaffAvailability",row.id,f"{route_label}: {approver.full_name if approver else 'external / source chart has no manager'} · {row.status}")
    db.commit(); return RedirectResponse('/control/my-availability',303)

@router.post("/availability/{sid}/coverage")
def update_leave_coverage(sid:int,request:Request,acting_senior_id:int=Form(...),db:Session=Depends(get_db)):
    actor=require_user(request,db,{Role.SENIOR_CHEMIST.value,Role.TECHNICAL_MANAGER.value,Role.SYSTEM_ADMIN.value})
    row=db.get(StaffAvailability,sid)
    if not row or row.entry_type!="LEAVE" or row.user.role!=Role.SENIOR_CHEMIST.value:
        raise ValueError("Senior leave record not found")
    if actor.role!=Role.SYSTEM_ADMIN.value and actor.id not in {row.user_id,row.approver_id}:
        raise HTTPException(403,"Only the requesting Senior or configured Technical Manager may resolve Senior coverage")
    coverage=_upsert_senior_coverage(db,row,actor,acting_senior_id)
    if coverage.status=="COVERAGE_OK":
        row.status="PENDING_MANAGER"
        if row.approver_id:
            _notify(db,row.approver_id,row.site_id,f"Senior leave coverage ready — {row.user.full_name}",coverage.note,"/control/my-availability","NORMAL","LEAVE")
    else:
        row.status="COVERAGE_ACTION_REQUIRED"
    _audit(db,request,actor,"SENIOR_LEAVE_COVERAGE_CHECK","StaffAvailability",row.id,f"{coverage.status} · {coverage.note}")
    db.commit(); return RedirectResponse('/control/my-availability',303)


@router.post("/availability/{sid}/transition")
def availability_transition(sid:int,request:Request,decision:str=Form(...),db:Session=Depends(get_db)):
    allowed={
        Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value, Role.TECHNICAL_MANAGER.value, Role.MANAGEMENT.value,
        Role.SALES_MARKETING.value, Role.EXCELLENCE.value, Role.CORPORATE_SUPPORT.value,
        Role.SENIOR_CHEMIST.value, Role.LAB_TECHNICIAN.value, Role.DATA_ENTRY.value,
        Role.CLIENT_COORDINATOR.value, Role.FIELD_SAMPLER.value, Role.LAB_SUPPORT.value,
    }
    user=require_user(request,db,allowed); row=db.get(StaffAvailability,sid)
    if not row or row.entry_type!="LEAVE": raise ValueError("Leave record not found")
    decision=decision.upper().strip()

    if decision=="CANCELLED" and row.user_id==user.id and row.status in {"PENDING_MANAGER","EXTERNAL_APPROVAL_REQUIRED","COVERAGE_ACTION_REQUIRED"}:
        row.status="CANCELLED"
        _audit(db,request,user,"LEAVE_PLAN_TRANSITION","StaffAvailability",row.id,row.status)
        db.commit(); return RedirectResponse('/control/my-availability',303)

    fallback_allowed=False
    if row.user.role==Role.FIELD_SAMPLER.value and user.role==Role.OPERATIONS_MANAGER.value and row.approver and row.approver.role==Role.SAMPLING_SUPERVISOR.value:
        fallback_allowed = row.approver.manager_id==user.id and _availability_conflict(db,row.approver.id,row.start_at,row.end_at) is not None
    if row.approver_id!=user.id and not fallback_allowed:
        raise ValueError("Only the configured leave approver, or the approved Field Manager fallback when the Sampling Supervisor is unavailable, can decide this request")
    if row.status!="PENDING_MANAGER":
        raise ValueError("This leave request is not awaiting manager approval")

    if decision in {"APPROVE","APPROVED","MANAGER_APPROVED"}:
        conflict=_roster_conflict(db,row.user_id,row.start_at,row.end_at)
        if conflict:
            raise ValueError(f"Leave cannot be approved while {conflict.entry_type} roster overlaps {conflict.start_at:%Y-%m-%d %H:%M}–{conflict.end_at:%Y-%m-%d %H:%M}. Replan the roster first.")
        if row.user.role==Role.SENIOR_CHEMIST.value:
            coverage=db.query(LeaveCoverageAssignment).filter(LeaveCoverageAssignment.leave_availability_id==row.id).first()
            coverage=_upsert_senior_coverage(db,row,user,coverage.acting_user_id if coverage else None)
            if coverage.status!="COVERAGE_OK":
                row.status="COVERAGE_ACTION_REQUIRED"
                _notify(db,row.user_id,row.site_id,"Senior leave coverage action required",coverage.note,"/control/my-availability","HIGH","LEAVE")
                _audit(db,request,user,"SENIOR_LEAVE_COVERAGE_RECHECK","StaffAvailability",row.id,f"ACTION_REQUIRED · {coverage.note}")
                db.commit()
                raise HTTPException(409,"Senior coverage is no longer valid. Resolve Acting / Backup Senior coverage before approval.")
        row.status="MANAGER_APPROVED"; row.approved_by_id=user.id
        _notify(db,row.user_id,row.site_id,"Leave plan manager-approved","The annual leave plan is manager-approved. Official HR leave remains in the company HR system.","/control/my-availability","NORMAL","LEAVE")
    elif decision=="REJECTED":
        row.status="REJECTED"; row.approved_by_id=user.id
        _notify(db,row.user_id,row.site_id,"Leave plan rejected","Review the plan with your direct manager before resubmitting.","/control/my-availability","NORMAL","LEAVE")
    else:
        raise ValueError("Unsupported leave decision")
    _audit(db,request,user,"LEAVE_PLAN_TRANSITION","StaffAvailability",row.id,row.status); db.commit(); return RedirectResponse('/control/my-availability',303)

@router.post("/schedule/generate-on-call")
def generate_on_call(request:Request,start_date:str=Form(...),end_date:str=Form(...),people_per_day:int=Form(2),db:Session=Depends(get_db)):
    from datetime import timedelta
    actor=require_user(request,db,SENIOR_WRITE); site=_site(db,actor); start=_dt(start_date+'T00:00'); end=_dt(end_date+'T23:59')
    if not start or not end or end<start or people_per_day<1 or people_per_day>5: raise ValueError("Invalid on-call generation window")
    people=db.query(User).join(StaffWorkPattern,StaffWorkPattern.user_id==User.id).filter(
        User.site_id==site.id,User.active.is_(True),User.role==Role.LAB_TECHNICIAN.value,
        StaffWorkPattern.site_id==site.id,StaffWorkPattern.active.is_(True),
    ).order_by(User.full_name).all()
    if len(people)<people_per_day: raise ValueError("Not enough eligible laboratory staff with active Work Patterns for on-call roster")
    patterns={r.user_id:r for r in db.query(StaffWorkPattern).filter(StaffWorkPattern.site_id==site.id,StaffWorkPattern.active.is_(True),StaffWorkPattern.user_id.in_([p.id for p in people] or [-1])).all()}
    counts={p.id:db.query(StaffAvailability).filter(StaffAvailability.site_id==site.id,StaffAvailability.user_id==p.id,StaffAvailability.entry_type=='ON_CALL',StaffAvailability.status.in_(['APPROVED','CONFIRMED'])).count() for p in people}
    existing=db.query(StaffAvailability).filter(StaffAvailability.site_id==site.id,StaffAvailability.entry_type=='ON_CALL',StaffAvailability.start_at<=end,StaffAvailability.end_at>=start,StaffAvailability.status.in_(['APPROVED','CONFIRMED'])).first()
    if existing: raise ValueError("An approved On-Call roster already exists in the selected window")
    day=start
    while day.date()<=end.date():
        ds=day.replace(hour=0,minute=0,second=0); de=day.replace(hour=23,minute=59,second=59)
        eligible=[]
        for p in people:
            pattern=patterns.get(p.id)
            if not pattern: continue
            if pattern.effective_from and day < pattern.effective_from.replace(hour=0,minute=0,second=0): continue
            if pattern.effective_to and day > pattern.effective_to.replace(hour=23,minute=59,second=59): continue
            try: workdays={int(x) for x in json.loads(pattern.weekdays_json or '[]')}
            except Exception: workdays=set()
            if not workdays: continue
            conflict=db.query(StaffAvailability).filter(
                StaffAvailability.site_id==site.id,StaffAvailability.user_id==p.id,
                StaffAvailability.entry_type.in_(['LEAVE','HOLIDAY','TRAINING','UNAVAILABLE','SHIFT']),
                StaffAvailability.status.in_(['APPROVED','CONFIRMED','APPROVED_FOR_ANNUAL_PLAN','MANAGER_APPROVED']),
                StaffAvailability.start_at<=de,StaffAvailability.end_at>=ds,
            ).first()
            if not conflict: eligible.append(p)
        eligible.sort(key=lambda p:(counts[p.id],p.full_name.lower()))
        if len(eligible)<people_per_day: raise ValueError(f"Not enough available staff for {day.date().isoformat()} after leave/training/Night Shift conflicts")
        for p in eligible[:people_per_day]:
            db.add(StaffAvailability(site_id=site.id,user_id=p.id,entry_type='ON_CALL',start_at=ds,end_at=de,status='APPROVED',shift_code='ON_CALL / AUTO-ROSTER',notes='Fair On-Call rotation from active Work Pattern pool; leave/training/night conflicts excluded',approved_by_id=actor.id,created_by_id=actor.id)); counts[p.id]+=1
        day+=timedelta(days=1)
    _audit(db,request,actor,'ON_CALL_ROSTER_GENERATED','StaffAvailability','',f'{start.date()} to {end.date()} · {people_per_day}/day · Work Pattern pool + cross-conflict controls'); db.commit(); return RedirectResponse('/workforce#lab-roster',303)

@router.post("/schedule/generate-night")
def generate_night(request:Request,month:str=Form(...),people_per_day:int=Form(2),db:Session=Depends(get_db)):
    import calendar
    actor=require_user(request,db,SENIOR_WRITE); site=_site(db,actor)
    try: year,mon=[int(x) for x in month.split('-')]
    except Exception: raise ValueError("Month must be YYYY-MM")
    if people_per_day not in {1,2,3}: raise ValueError("Night roster supports 1–3 employees per operating day")
    annual_rows=db.query(NightShiftMonthPlan).filter(
        NightShiftMonthPlan.site_id==site.id,NightShiftMonthPlan.year==year,NightShiftMonthPlan.month==mon,NightShiftMonthPlan.status=='PUBLISHED'
    ).all()
    annual_ids={r.user_id for r in annual_rows}
    if not annual_ids: raise ValueError("Publish the Annual Night Shift Month Plan for this month before generating the detailed roster")
    people=db.query(User).filter(User.site_id==site.id,User.active.is_(True),User.role==Role.LAB_TECHNICIAN.value,User.id.in_(annual_ids)).order_by(User.full_name).all()
    if len(people)<people_per_day: raise ValueError("The approved annual month plan does not contain enough employees for the requested daily Night Shift coverage")
    pattern_rows=db.query(StaffWorkPattern).filter(StaffWorkPattern.site_id==site.id,StaffWorkPattern.active.is_(True),StaffWorkPattern.user_id.in_([p.id for p in people] or [-1])).all()
    patterns={p.user_id:p for p in pattern_rows}
    if len(patterns)<people_per_day: raise ValueError("Configure active Work Patterns for the employees published in the Annual Night Shift Month Plan")
    month_start=datetime(year,mon,1)
    next_month=datetime(year + (1 if mon==12 else 0), 1 if mon==12 else mon+1, 1)
    existing_roster=db.query(StaffAvailability).filter(StaffAvailability.site_id==site.id,StaffAvailability.entry_type=='SHIFT',StaffAvailability.shift_code.like('NIGHT / AUTO-ROSTER%'),StaffAvailability.start_at>=month_start,StaffAvailability.start_at<next_month).first()
    if existing_roster: raise ValueError('A generated Night Shift Roster already exists for this month; review/approve it instead of creating duplicates')
    configured_competency=db.query(CompetencyRecord).filter(CompetencyRecord.site_id==site.id,CompetencyRecord.active.is_(True),CompetencyRecord.user_id.in_([p.id for p in people] or [-1])).count()
    competent_ids={p.id for p in people}
    if configured_competency:
        competent_ids={c.user_id for c in db.query(CompetencyRecord).filter(
            CompetencyRecord.site_id==site.id,CompetencyRecord.active.is_(True),CompetencyRecord.user_id.in_([p.id for p in people] or [-1]),
            CompetencyRecord.authorization.in_(['INDEPENDENT','SUPERVISED'])
        ).all() if c.expires_at is None or c.expires_at>=datetime.utcnow()}
    counts={p.id:db.query(StaffAvailability).filter(StaffAvailability.site_id==site.id,StaffAvailability.user_id==p.id,StaffAvailability.entry_type=='SHIFT',StaffAvailability.shift_code.like('NIGHT%'),StaffAvailability.status.in_(['PLANNED','APPROVED','CONFIRMED'])).count() for p in people}
    created=0
    for daynum in range(1,calendar.monthrange(year,mon)[1]+1):
        day=datetime(year,mon,daynum)
        ds=day.replace(hour=14,minute=0,second=0); de=day.replace(hour=22,minute=0,second=0)
        eligible=[]
        for person in people:
            pattern=patterns.get(person.id)
            if not pattern or person.id not in competent_ids: continue
            try: workdays={int(x) for x in json.loads(pattern.weekdays_json or '[]')}
            except Exception: workdays=set()
            if day.weekday() not in workdays: continue
            if pattern.effective_from and day < pattern.effective_from.replace(hour=0,minute=0,second=0): continue
            if pattern.effective_to and day > pattern.effective_to.replace(hour=23,minute=59,second=59): continue
            conflict=db.query(StaffAvailability).filter(
                StaffAvailability.site_id==site.id,StaffAvailability.user_id==person.id,
                StaffAvailability.entry_type.in_(['LEAVE','HOLIDAY','TRAINING','UNAVAILABLE','ON_CALL']),
                StaffAvailability.status.in_(['APPROVED','CONFIRMED','APPROVED_FOR_ANNUAL_PLAN','MANAGER_APPROVED']),
                StaffAvailability.start_at<de,StaffAvailability.end_at>ds,
            ).first()
            if not conflict: eligible.append(person)
        if not eligible: continue
        eligible.sort(key=lambda p:(counts[p.id],p.full_name.lower()))
        if len(eligible)<people_per_day: raise ValueError(f"Not enough approved-month, on-pattern, available staff for {day.date().isoformat()}")
        for person in eligible[:people_per_day]:
            db.add(StaffAvailability(site_id=site.id,user_id=person.id,entry_type='SHIFT',start_at=ds,end_at=de,status='PLANNED',shift_code='NIGHT / AUTO-ROSTER',notes='Generated from published Annual Night Shift Month Plan + Work Pattern + availability' + (' + competency gate' if configured_competency else ''),approved_by_id=None,created_by_id=actor.id)); counts[person.id]+=1; created+=1
    if created==0: raise ValueError("No roster entries were created. Check annual month plan, Work Patterns and availability")
    _audit(db,request,actor,'NIGHT_ROSTER_GENERATED','StaffAvailability','',f'{month} · {people_per_day}/operating day · annual-plan/work-pattern/availability/competency aware · pending Senior approval'); db.commit(); return RedirectResponse('/workforce#lab-roster',303)

@router.post('/schedule/approve-night')
def approve_night(request:Request,month:str=Form(...),db:Session=Depends(get_db)):
    import calendar
    actor=require_user(request,db,SENIOR_WRITE); site=_site(db,actor)
    try: year,mon=[int(x) for x in month.split('-')]
    except Exception: raise ValueError('Month must be YYYY-MM')
    start=datetime(year,mon,1); end=datetime(year,mon,calendar.monthrange(year,mon)[1],23,59,59)
    rows=db.query(StaffAvailability).filter(StaffAvailability.site_id==site.id,StaffAvailability.entry_type=='SHIFT',StaffAvailability.shift_code.like('NIGHT / AUTO-ROSTER%'),StaffAvailability.start_at>=start,StaffAvailability.start_at<=end,StaffAvailability.status=='PLANNED').all()
    if not rows: raise ValueError('No pending generated Night Shift Roster exists for this month')
    for row in rows:
        row.status='APPROVED'; row.approved_by_id=actor.id; row.notes=(row.notes or '') + ' · reviewed and approved by Senior Chemist'
    _audit(db,request,actor,'NIGHT_ROSTER_APPROVED','StaffAvailability','',f'{month} · {len(rows)} planned shifts approved'); db.commit()
    return RedirectResponse('/workforce#lab-roster',303)


_DGA_ALIASES={
    'H2':['h2','hydrogen'],'O2':['o2','oxygen'],'N2':['n2','nitrogen'],'CH4':['ch4','methane'],'CO':['co','carbon monoxide'],'CO2':['co2','carbon dioxide'],
    'C2H4':['c2h4','ethylene'],'C2H6':['c2h6','ethane'],'C2H2':['c2h2','acetylene']}
_DGA_DERIVED_ALIASES={
    'TCG':['tcg','total combustible gas','total combustible gases','tcg ppm stp'],
    'TVG':['tvg','total volume','total volume of gas'],
    'EQP40':['equilibrium pressure','equilibrium gas pressure','equilibrium gas pressure 40 c']}

def _parse_dga_bytes(filename:str,data:bytes)->dict:
    import csv, io, re, zipfile, xml.etree.ElementTree as ET
    rows=[]; lower=filename.lower()
    if lower.endswith('.xlsx'):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            shared=[]
            if 'xl/sharedStrings.xml' in z.namelist():
                root=ET.fromstring(z.read('xl/sharedStrings.xml')); ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
                shared=[''.join(t.text or '' for t in si.findall('.//m:t',ns)) for si in root.findall('.//m:si',ns)]
            sheet=next((n for n in z.namelist() if n.startswith('xl/worksheets/sheet') and n.endswith('.xml')),None)
            if not sheet: raise ValueError('XLSX has no worksheet')
            root=ET.fromstring(z.read(sheet)); ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            for r in root.findall('.//m:row',ns):
                vals=[]
                for c in r.findall('m:c',ns):
                    v=c.find('m:v',ns); val='' if v is None else (shared[int(v.text)] if c.get('t')=='s' and v.text else v.text or '')
                    vals.append(val)
                if vals: rows.append(vals)
    else:
        text=data.decode('utf-8-sig',errors='replace'); dialect=csv.excel_tab if '\t' in text[:1000] else csv.excel
        rows=list(csv.reader(io.StringIO(text),dialect=dialect))
    found={}
    flat=[]
    for row in rows:
        for i,cell in enumerate(row): flat.append((str(cell).strip(),row,i))
    for gas,aliases in _DGA_ALIASES.items():
        for cell,row,i in flat:
            norm=re.sub(r'[^a-z0-9]+',' ',cell.lower()).strip()
            if any(a==norm or a in norm for a in aliases):
                candidates=row[i+1:i+4]+row[max(0,i-3):i]
                for cand in candidates:
                    m=re.search(r'[-+]?\d+(?:\.\d+)?',str(cand))
                    if m: found[gas]=float(m.group()); break
            if gas in found: break
    derived={}
    for key,aliases in _DGA_DERIVED_ALIASES.items():
        for cell,row,i in flat:
            norm=re.sub(r'[^a-z0-9]+',' ',cell.lower()).strip()
            if any(a==norm or a in norm for a in aliases):
                candidates=row[i+1:i+4]+row[max(0,i-3):i]
                for cand in candidates:
                    m=re.search(r'[-+]?\d+(?:\.\d+)?',str(cand))
                    if m: derived[key]=float(m.group()); break
            if key in derived: break
    return {'gases':found,'derived':derived,'recognized':len(found),'recognized_derived':len(derived),'required':list(_DGA_ALIASES),'complete':len(found)==9}


@router.post('/dga/import')
async def dga_import(request:Request,sample_request_id:int=Form(...),equipment_asset_id:int=Form(...),method_name:str=Form(...),run_reference:str=Form(''),upload:UploadFile=File(...),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value}); site=_site(db,user); sample=db.get(SampleRequest,sample_request_id); eq=db.get(EquipmentAsset,equipment_asset_id)
    if not sample or sample.site_id!=site.id or not eq or eq.site_id!=site.id or eq.workstation!='DGA': raise ValueError('DGA import requires a valid site sample and DGA equipment asset')
    data=await upload.read(); parsed=_parse_dga_bytes(upload.filename or '',data)
    if not parsed['recognized']: raise ValueError('No DGA gas fields were recognized; preserve the source as evidence and configure the exact instrument export mapping during technical review')
    digest=hashlib.sha256(data).hexdigest(); safe=f"{digest[:16]}_{Path(upload.filename or 'dga.bin').name.replace('/','_')}"; path=UPLOAD_DIR/safe; path.write_bytes(data)
    row=EvidenceRecord(site_id=site.id,sample_request_id=sample.id,equipment_asset_id=eq.id,evidence_type='DGA_SOURCE',title=f'DGA import {sample.request_number}',original_filename=upload.filename or '',stored_path=str(path),sha256=digest,method_name=method_name.strip(),equipment_id_snapshot=eq.equipment_id,run_reference=run_reference.strip(),parsed_json=json.dumps(parsed),status='PENDING_CONFIRMATION',uploaded_by_id=user.id); db.add(row); db.flush(); _audit(db,request,user,'DGA_IMPORT_PREVIEW','EvidenceRecord',row.id,f"Recognized {parsed['recognized']}/9 gases"); db.commit(); return JSONResponse({'evidence_id':row.id,'status':row.status,'preview':parsed})

@router.post('/dga/{evidence_id}/confirm')
def dga_confirm(evidence_id:int,request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value}); site=_site(db,user); row=db.get(EvidenceRecord,evidence_id)
    if not row or row.site_id!=site.id or row.evidence_type!='DGA_SOURCE' or row.status!='PENDING_CONFIRMATION': raise ValueError('Pending DGA import not found')
    parsed=json.loads(row.parsed_json or '{}')
    if not parsed.get('recognized'): raise ValueError('DGA import contains no recognized gases')
    row.status='CONTROLLED'; _audit(db,request,user,'DGA_IMPORT_CONFIRMED','EvidenceRecord',row.id,f"Confirmed {parsed.get('recognized')}/9 parsed gases"); db.commit(); return {'status':'CONTROLLED','evidence_id':row.id,'preview':parsed}

@router.get('/report/{rid}/preview')
def report_preview(rid:int,request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,VIEW|{Role.CLIENT.value}); row=db.get(ControlledReport,rid)
    if not row: raise ValueError('Report not found')
    if user.role==Role.CLIENT.value:
        if user.client_id!=row.sample.client_id:
            raise HTTPException(status_code=404, detail='Report not found')
        if row.sample.status!=SampleStatus.REPORT_RELEASED.value or row.status!=SampleStatus.REPORT_RELEASED.value:
            raise HTTPException(status_code=404, detail='Report is not yet officially issued')
    site=db.get(Site,row.site_id)
    verification_url=str(request.base_url).rstrip('/')+f'/verify/report/{row.qr_token}'
    report_payload=None
    if row.status==SampleStatus.REPORT_RELEASED.value and row.approved_snapshot_json:
        try:
            snap=json.loads(row.approved_snapshot_json)
            report_payload=snap.get('report_payload')
        except Exception:
            report_payload=None
    if not report_payload:
        flags=_report_flags(row)
        senior_review=flags.get('senior_review') if isinstance(flags.get('senior_review'),dict) else {}
        signed_snapshot=senior_review.get('client_preview_snapshot') if isinstance(senior_review.get('client_preview_snapshot'),dict) else None
        report_payload=json.loads(json.dumps(signed_snapshot)) if signed_snapshot else build_final_report_payload(db,row,site,verification_url=verification_url)
    return templates.TemplateResponse('controlled_report_preview.html',{
        'request':request,'user':user,'report':row,'sample':row.sample,'asset':row.sample.asset,
        'report_payload':report_payload,'official_pdf_ready':bool(row.official_pdf_path and Path(row.official_pdf_path).exists())
    })

@router.get('/report/{rid}/pdf')
def report_pdf(rid:int,request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,VIEW|{Role.CLIENT.value}); row=db.get(ControlledReport,rid)
    if not row: raise HTTPException(status_code=404,detail='Report not found')
    if user.role==Role.CLIENT.value and user.client_id!=row.sample.client_id:
        raise HTTPException(status_code=404,detail='Report not found')
    if row.status!=SampleStatus.REPORT_RELEASED.value or row.sample.status!=SampleStatus.REPORT_RELEASED.value:
        raise HTTPException(status_code=409,detail='Only an officially released report has an official client PDF')
    if not row.official_pdf_path or not Path(row.official_pdf_path).exists():
        raise HTTPException(status_code=409,detail='Official report PDF artifact is missing; do not regenerate silently because the released artifact must remain immutable')
    actual=hashlib.sha256(Path(row.official_pdf_path).read_bytes()).hexdigest()
    if row.official_pdf_sha256 and actual!=row.official_pdf_sha256:
        raise HTTPException(status_code=409,detail='Official report PDF integrity check failed')
    filename=f"{row.report_number}_Rev{row.revision}_Analysis_Report.pdf".replace('/','_')
    return FileResponse(row.official_pdf_path,media_type='application/pdf',filename=filename,headers={'X-TSCO-Report-SHA256':actual,'Cache-Control':'private, no-store'})

@router.get('/report/{rid}/qr.png')
def report_qr(rid:int,request:Request,db:Session=Depends(get_db)):
    import io, qrcode
    from fastapi.responses import Response
    row=db.get(ControlledReport,rid)
    if not row: raise ValueError('Report not found')
    url=str(request.base_url).rstrip('/')+f'/verify/report/{row.qr_token}'
    img=qrcode.make(url); buf=io.BytesIO(); img.save(buf,format='PNG'); return Response(buf.getvalue(),media_type='image/png',headers={'Cache-Control':'no-store'})

def _routine_asset_matches(task_key: str, eq: EquipmentAsset) -> bool:
    """Tie asset-specific routine QC evidence to the correct equipment family."""
    key=(task_key or '').strip().lower()
    hay=' '.join([eq.name or '', eq.workstation or '', eq.test_method or '', eq.notes or '']).lower()
    if key == 'balances':
        return 'balance' in hay
    if key == 'electrode':
        return any(token in hay for token in ('electrode','titrando','titrator'))
    return True


def _quality_case_execution_view(row: QualityCase) -> dict:
    try: protocol=json.loads(row.protocol_json or '{}')
    except Exception: protocol={}
    requested=protocol.get('required_runs',1) if isinstance(protocol,dict) else 1
    try: run_count=max(1,min(50,int(requested)))
    except (TypeError,ValueError): run_count=1
    required_min=run_count
    try: raw=json.loads(row.raw_runs_json or '[]')
    except Exception: raw=[]
    run_values=[]
    if isinstance(raw,list):
        for item in raw[:run_count]:
            value=item.get('value') if isinstance(item,dict) else item
            try: run_values.append(float(value))
            except (TypeError,ValueError): run_values.append('')
    try: calc=json.loads(row.calculation_json or '{}')
    except Exception: calc={}
    if not isinstance(calc,dict): calc={}
    def fmt(value):
        if value in (None,''): return '—'
        try: return f'{float(value):.6g}'
        except (TypeError,ValueError): return str(value)
    if calc:
        calc=dict(calc); calc['mean_fmt']=fmt(calc.get('mean')); calc['stdev_fmt']=fmt(calc.get('stdev')); calc['rsd_fmt']=fmt(calc.get('rsd_pct')); calc['range_fmt']=fmt(calc.get('range'))
    return {'case':row,'run_count':run_count,'required_min':required_min,'run_values':run_values,'calculation':calc,'protocol':protocol}


def _active_quality_distribution(payload: dict, now: datetime) -> dict | None:
    """Latest published revision for the calendar month that is actually active now."""
    month_key = now.strftime('%Y-%m')
    rows = [
        row for row in payload.get('qualityDistributions', [])
        if isinstance(row, dict) and str(row.get('month') or '') == month_key
    ]
    if not rows:
        return None
    return max(rows, key=lambda row: int(row.get('revision') or 1))


def _routine_period_state(assignment: dict, now: datetime) -> str:
    """OPEN / OVERDUE / FUTURE for an assignment in the active calendar month."""
    try:
        start_day = int(assignment.get('start_day') or 1)
        end_day = int(assignment.get('end_day') or start_day)
    except (TypeError, ValueError):
        return 'OPEN'
    if now.day < start_day:
        return 'FUTURE'
    if now.day > end_day:
        return 'OVERDUE'
    return 'OPEN'


def _routine_previous_assignments(distribution: dict, assignment: dict) -> list[dict]:
    """Earlier windows of the same controlled check, ordered by start day."""
    task_key = str(assignment.get('task_key') or '')
    try:
        current_start = int(assignment.get('start_day') or 1)
    except (TypeError, ValueError):
        current_start = 1
    rows=[]
    for row in distribution.get('assignments', []):
        if not isinstance(row, dict) or str(row.get('task_key') or '') != task_key:
            continue
        try: row_start = int(row.get('start_day') or 1)
        except (TypeError, ValueError): row_start = 1
        if row_start < current_start:
            rows.append(row)
    return sorted(rows, key=lambda row: int(row.get('start_day') or 1))


def _routine_sequence_ready(distribution: dict, assignment: dict, event_map: dict[str, dict]) -> bool:
    """Do not let a Chemist jump over an unfinished earlier QC window."""
    return all(str(row.get('id') or '') in event_map for row in _routine_previous_assignments(distribution, assignment))


@router.get('/my-quality-tasks')
def my_quality_tasks(request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value}); site=_site(db,user)
    cases=db.query(QualityCase).filter(QualityCase.site_id==site.id,QualityCase.assigned_to_id==user.id,QualityCase.case_type.in_(['VALIDATION','VERIFICATION','ILC_PT'])).order_by(QualityCase.due_at,QualityCase.created_at.desc()).all()
    rows=[_quality_case_execution_view(row) for row in cases]
    state,payload=get_operations_state(db,site)
    now=datetime.utcnow(); current=_active_quality_distribution(payload,now)
    routine=[]; future=[]; completed=[]; analytical_ownership=[]; event_map={}
    for ev in payload.get('qualityTaskEvents',[]):
        aid=str(ev.get('assignment_id') or '')
        if aid and (aid not in event_map or str(ev.get('completed_at') or '')>str(event_map[aid].get('completed_at') or '')): event_map[aid]=ev
    if current:
        try: year,month=[int(x) for x in str(current.get('month') or '').split('-')]
        except Exception: year,month=now.year,now.month
        for a in current.get('assignments',[]):
            primary=int(a.get('primary_user_id') or 0)==user.id; backup=int(a.get('backup_user_id') or 0)==user.id
            if not (primary or backup): continue
            active_uid=int(a.get('active_user_id') or a.get('primary_user_id') or 0)
            if active_uid==user.id and backup and not primary: assigned_as='Activated Backup'
            elif primary: assigned_as='Primary'
            else: assigned_as='Backup · Standby'
            try: due_label=datetime(year,month,int(a.get('end_day') or 1)).strftime('%d %b %Y')
            except Exception: due_label=str(a.get('period_label') or 'Current period')
            ev=event_map.get(str(a.get('id'))); period_state=_routine_period_state(a,now); sequence_ready=_routine_sequence_ready(current,a,event_map)
            coverage_ok=str(a.get('status') or 'ACTIVE').upper()=='ACTIVE'
            view={'assignment':a,'event':ev,'assigned_as':assigned_as,'due_label':due_label,
                  'asset_label':str(a.get('equipment_id') or '').strip(),'period_state':period_state,'sequence_ready':sequence_ready,
                  'is_active_executor':active_uid==user.id,'coverage_ok':coverage_ok,
                  'can_record':(ev is None and period_state in {'OPEN','OVERDUE'} and sequence_ready and coverage_ok and active_uid==user.id)}
            if str(a.get('kind') or '').upper()=='EQUIPMENT': analytical_ownership.append({'owner':a,'assigned_as':assigned_as})
            if ev: completed.append(view)
            elif period_state=='FUTURE': future.append(view)
            else: routine.append(view)
    routine.sort(key=lambda item:(0 if item['period_state']=='OVERDUE' else 1,int(item['assignment'].get('end_day') or 99),str(item['assignment'].get('task') or '')))
    future.sort(key=lambda item:(int(item['assignment'].get('start_day') or 99),str(item['assignment'].get('task') or '')))
    completed.sort(key=lambda item:str(item['event'].get('completed_at') or ''),reverse=True)
    return templates.TemplateResponse('my_quality_tasks.html',{
        'request':request,'user':user,'rows':rows,'routine_tasks':routine,'future_routine_tasks':future,'completed_routine_tasks':completed[:12],
        'quality_month':current.get('month') if current else '','analytical_ownership':analytical_ownership,'active_day':now.day,
    })


@router.post('/my-quality-tasks/routine/{assignment_id}')
def submit_routine_quality_task(assignment_id:str,request:Request,status:str=Form(...),note:str=Form(''),equipment_asset_id:str=Form(''),db:Session=Depends(get_db)):
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value}); site=_site(db,user); state,payload=get_operations_state(db,site)
    now=datetime.utcnow(); current=_active_quality_distribution(payload,now)
    if not current: raise ValueError('No published QC distribution is available for the active month')
    assignment=next((a for a in current.get('assignments',[]) if str(a.get('id'))==assignment_id),None)
    if not assignment: raise ValueError('QC assignment not found in the active month')
    active_uid=int(assignment.get('active_user_id') or assignment.get('primary_user_id') or 0)
    if active_uid!=user.id: raise HTTPException(status_code=403,detail='Only the active Primary, or a formally activated Backup, can record this QC assignment')
    if str(assignment.get('status') or 'ACTIVE').upper()!='ACTIVE': raise ValueError('QC assignment has unresolved coverage or equipment mapping and cannot be recorded')
    event_map={str(ev.get('assignment_id') or ''):ev for ev in payload.get('qualityTaskEvents',[]) if isinstance(ev,dict) and ev.get('assignment_id')}
    if assignment_id in event_map: raise ValueError('This QC assignment has already been recorded')
    period_state=_routine_period_state(assignment,now)
    if period_state=='FUTURE': raise ValueError('This QC period is not open yet')
    if not _routine_sequence_ready(current,assignment,event_map): raise ValueError('Complete the earlier period for this QC check before recording the next period')
    clean=status.strip().upper()
    if clean not in {'PASS','ATTENTION','FAIL'}: raise ValueError('QC status must be PASS, ATTENTION or FAIL')
    if clean in {'ATTENTION','FAIL'} and not note.strip(): raise ValueError('A note is required for ATTENTION or FAIL')
    eq=None; fixed_id=assignment.get('equipment_asset_id')
    if fixed_id:
        eq=db.get(EquipmentAsset,int(fixed_id))
        if not eq or eq.site_id!=site.id or not eq.active: raise ValueError('Assigned Equipment ID is no longer active in Equipment Master')
    elif equipment_asset_id.strip():
        try: eq=db.get(EquipmentAsset,int(equipment_asset_id))
        except (TypeError,ValueError): eq=None
        if not eq or eq.site_id!=site.id or not eq.active: raise ValueError('Selected QC equipment is not available in the active site master')
    if str(assignment.get('task_key') or '') in {'balances','electrode'} and not eq: raise ValueError('This QC task requires an exact Equipment ID mapping before execution')
    payload.setdefault('qualityTaskEvents',[]).append({'id':f"QTE-{secrets.token_hex(6)}",'distribution_id':current.get('id'),'assignment_id':assignment_id,
        'status':clean,'note':note.strip(),'equipment_asset_id':eq.id if eq else None,'equipment_id':eq.equipment_id if eq else '',
        'equipment_name':eq.name if eq else '','assigned_role':str(assignment.get('active_role') or 'PRIMARY'),
        'completed_by':user.full_name,'completed_by_user_id':user.id,'completed_at':datetime.utcnow().isoformat()})
    save_operations_state(db,state,payload,actor=user); _audit(db,request,user,'RECURRING_QC_RECORDED','QualityDistribution',assignment_id,f"{assignment.get('task')} → {clean}"); db.commit(); return RedirectResponse('/control/my-quality-tasks',303)


@router.post('/quality-assignment/{assignment_id}/activate')
def activate_quality_assignment(assignment_id:str,request:Request,active_role:str=Form(...),reason:str=Form(...),db:Session=Depends(get_db)):
    actor=require_user(request,db,{Role.SENIOR_CHEMIST.value,Role.TECHNICAL_MANAGER.value})
    if actor.role==Role.SENIOR_CHEMIST.value and not is_senior_equipment(actor):
        raise HTTPException(status_code=403,detail='Recurring equipment/QC reassignment belongs to Senior Chemist — Equipment & Maintenance')
    site=_site(db,actor); state,payload=get_operations_state(db,site); current=_active_quality_distribution(payload,datetime.utcnow())
    if not current: raise ValueError('No active published QC distribution')
    assignment=next((a for a in current.get('assignments',[]) if str(a.get('id'))==assignment_id),None)
    if not assignment: raise ValueError('QC assignment not found')
    role=active_role.strip().upper()
    if role not in {'PRIMARY','BACKUP'}: raise ValueError('Active role must be Primary or Backup')
    target=int(assignment.get('primary_user_id') or 0) if role=='PRIMARY' else int(assignment.get('backup_user_id') or 0)
    if not target: raise ValueError(f'No {role.title()} employee is configured for this assignment')
    if not reason.strip(): raise ValueError('Controlled reassignment reason is required')
    previous=int(assignment.get('active_user_id') or assignment.get('primary_user_id') or 0)
    assignment['active_user_id']=target; assignment['active_role']=role; assignment['activation_reason']=reason.strip(); assignment['activated_at']=datetime.utcnow().isoformat(); assignment['activated_by_user_id']=actor.id; assignment['activated_by']=actor.full_name
    save_operations_state(db,state,payload,actor=actor); _audit(db,request,actor,'QC_ACTIVE_OWNER_CHANGED','QualityDistribution',assignment_id,f"active {previous} → {target} ({role}) · {reason.strip()}"); db.commit()
    return RedirectResponse('/quality?tab=qc',303)


@router.post('/my-quality-tasks/{cid}/submit')
async def submit_quality_task(
    cid:int,request:Request,raw_runs_json:str=Form(''),evidence_reference:str=Form(''),
    evidence_file:UploadFile|None=File(None),db:Session=Depends(get_db)
):
    import statistics
    user=require_user(request,db,{Role.LAB_TECHNICIAN.value}); site=_site(db,user); row=db.get(QualityCase,cid)
    if not row or row.site_id!=site.id or row.assigned_to_id!=user.id: raise ValueError('Quality task is not assigned to this employee')
    if row.status in {'CLOSED','APPROVED'}: raise ValueError('Closed quality task cannot be resubmitted')
    view=_quality_case_execution_view(row); values=[]
    # Parse the repeated run_values controls directly from the request so the protocol
    # can render any approved run count (not a fixed five-field form).
    form=await request.form()
    supplied=[str(v) for v in form.getlist('run_values')][:view['run_count']]
    # backward compatibility for the previous named run_1..run_N form inputs
    if not supplied:
        supplied=[str(form.get(f'run_{i}','')) for i in range(1,view['run_count']+1)]
    for idx,value in enumerate(supplied,1):
        if str(value).strip()=='': continue
        try: values.append(float(value))
        except (TypeError,ValueError): raise ValueError(f'Run {idx} must be numeric')
    if not values and raw_runs_json.strip():
        try: legacy=json.loads(raw_runs_json)
        except Exception: raise ValueError('Legacy raw runs are not valid JSON')
        if isinstance(legacy,list):
            for item in legacy[:view['run_count']]:
                value=item.get('value') if isinstance(item,dict) else item
                try: values.append(float(value))
                except (TypeError,ValueError): pass
    if len(values)<view['required_min']: raise ValueError(f"{row.case_type.replace('_',' ')} requires {view['required_min']} numerical run(s) before submission")
    calc={'n':len(values),'mean':sum(values)/len(values),'min':min(values),'max':max(values),'range':max(values)-min(values)}
    if len(values)>1:
        calc['stdev']=statistics.stdev(values); calc['rsd_pct']=(calc['stdev']/calc['mean']*100) if calc['mean'] else None
    evidence_ref=evidence_reference.strip()
    if evidence_file and evidence_file.filename:
        data=await evidence_file.read()
        if len(data)>20_000_000: raise ValueError('Controlled evidence file exceeds 20 MB')
        digest=hashlib.sha256(data).hexdigest(); safe=f"{digest[:16]}_{Path(evidence_file.filename or 'evidence.bin').name.replace('/','_')}"; path=UPLOAD_DIR/safe; path.write_bytes(data)
        eq=row.equipment; evidence_type='VERIFICATION' if row.case_type=='VERIFICATION' else 'ILC_PT' if row.case_type=='ILC_PT' else 'VALIDATION'
        evidence=EvidenceRecord(site_id=site.id,quality_case_id=row.id,equipment_asset_id=row.equipment_asset_id,evidence_type=evidence_type,title=f'{row.case_number} execution evidence',original_filename=evidence_file.filename or '',stored_path=str(path),sha256=digest,method_name=row.method_name or '',equipment_id_snapshot=eq.equipment_id if eq else '',run_reference=evidence_ref,uploaded_by_id=user.id); db.add(evidence)
        evidence_ref=evidence_ref or evidence_file.filename or ''
    latest=db.query(QualityExecutionRevision).filter(QualityExecutionRevision.quality_case_id==row.id).order_by(QualityExecutionRevision.revision.desc()).first()
    revision=(latest.revision+1) if latest else 1
    exec_rev=QualityExecutionRevision(quality_case_id=row.id,revision=revision,raw_runs_json=json.dumps(values),calculation_json=json.dumps(calc),evidence_reference=evidence_ref,submitted_by_id=user.id)
    db.add(exec_rev); row.raw_runs_json=exec_rev.raw_runs_json; row.calculation_json=exec_rev.calculation_json; row.evidence_reference=evidence_ref; row.status='SUBMITTED_FOR_REVIEW'
    _audit(db,request,user,'QUALITY_TASK_SUBMITTED','QualityCase',row.id,f'{row.case_number} execution revision {revision} submitted for governance review')
    for q in db.query(User).filter(User.site_id==row.site_id,User.active.is_(True),User.role.in_([Role.EXCELLENCE.value,Role.TECHNICAL_MANAGER.value])).all(): _notify(db,q.id,row.site_id,f'{row.case_number} ready for review',row.title,'/quality?tab=validation','HIGH','QUALITY')
    db.commit(); return RedirectResponse('/control/my-quality-tasks',303)

@router.get('/daily-brief')
def daily_brief(request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,INTERNAL_ROLES)
    brief=build_daily_brief(db,user)
    role_name=ROLE_REVIEW_MATRIX.get(user.role,{}).get('name',user.job_title or user.role.replace('_',' ').title())
    return templates.TemplateResponse('daily_brief.html',{'request':request,'user':user,'brief':brief,'role_name':role_name})

@router.get('/notifications')
def notifications(request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,{r.value for r in Role if r.value!='client'}); rows=db.query(Notification).filter(Notification.user_id==user.id).order_by(Notification.created_at.desc()).limit(200).all(); return templates.TemplateResponse('notifications.html',{'request':request,'user':user,'rows':rows})

@router.post('/notifications/{nid}/read')
def notification_read(nid:int,request:Request,db:Session=Depends(get_db)):
    user=require_user(request,db,{r.value for r in Role if r.value!='client'}); row=db.get(Notification,nid)
    if not row or row.user_id!=user.id: raise ValueError('Notification not found')
    row.read_at=datetime.utcnow(); db.commit(); return RedirectResponse('/control/notifications',303)
