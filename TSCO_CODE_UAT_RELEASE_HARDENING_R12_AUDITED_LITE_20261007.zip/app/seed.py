from __future__ import annotations

import os
from datetime import datetime

from sqlalchemy import select

from .database import SessionLocal
from .models import ApprovalPolicy, Asset, Client, ClientUnit, CommercialCase, CommercialEvent, ControlledReport, Department, PurchaseOrder, Quotation, Role, SampleRequest, SampleStatus, Site, User, UserClientAssignment, UserClientUnitAssignment, WorkflowDefinition, WorkflowStep, TechnicalResultRule, EquipmentAsset, CompetencyRecord
from .services.lab_operations import ensure_baseline_test_packages
from .security import hash_password
from .org_structure import EMPLOYEE_BY_EMAIL


def _truthy(name: str, default: str = "false") -> bool:
    return os.getenv(name, default).strip().lower() in {"1", "true", "yes", "on"}




def _ensure_core_workflows(db) -> None:
    """Seed controlled master workflows in every environment, never only demo."""
    flow = db.scalar(select(WorkflowDefinition).where(WorkflowDefinition.site_id.is_(None), WorkflowDefinition.code == "LAB-SAMPLE-LIFECYCLE", WorkflowDefinition.active.is_(True)))
    if not flow:
        flow = WorkflowDefinition(site_id=None, code="LAB-SAMPLE-LIFECYCLE", name="Integrated Sample Lifecycle", sample_type="TRANSFORMER OIL", version=4, active=True)
        db.add(flow); db.flush()
    sample_steps = [
        (1,"sampling_order","Sampling Order",Role.OPERATIONS_MANAGER.value,False,False),
        (2,"supervisor_assignment","Supervisor Assignment",Role.SAMPLING_SUPERVISOR.value,False,False),
        (3,"field_capture","Field Capture",Role.FIELD_SAMPLER.value,False,False),
        (4,"data_entry","Data Entry Verification",Role.DATA_ENTRY.value,False,False),
        (5,"tsco_registration","TSCO Internal Registration",Role.DATA_ENTRY.value,False,False),
        (6,"receiving","Physical / Barcode Receiving",Role.DATA_ENTRY.value,False,False),
        (7,"batch_distribution","Batch & Distribution",Role.DATA_ENTRY.value,False,False),
        (8,"laboratory","Laboratory Operations",Role.LAB_TECHNICIAN.value,False,False),
        (9,"technical_review","Technical Assessment / Senior Review",Role.SENIOR_CHEMIST.value,True,False),
        (10,"final_report_release","Final TSCO Report Approval & Release",Role.TECHNICAL_MANAGER.value,True,True),
    ]
    existing = list(db.scalars(select(WorkflowStep).where(WorkflowStep.workflow_id == flow.id)).all())
    expected = [x[1] for x in sample_steps]
    if flow.version != 4 or [x.step_key for x in sorted(existing, key=lambda r: r.step_order)] != expected or [x.responsible_role for x in sorted(existing, key=lambda r: r.step_order)] != [x[3] for x in sample_steps]:
        for row in existing: db.delete(row)
        db.flush(); flow.version = 4
        for order,key,label,role,approval,terminal in sample_steps:
            db.add(WorkflowStep(workflow_id=flow.id, step_order=order, step_key=key, label=label, responsible_role=role, approval_required=approval, terminal=terminal))

    business = db.scalar(select(WorkflowDefinition).where(WorkflowDefinition.site_id.is_(None), WorkflowDefinition.code == "BUSINESS-COMMUNICATION-FLOW", WorkflowDefinition.active.is_(True)))
    if not business:
        business = WorkflowDefinition(site_id=None, code="BUSINESS-COMMUNICATION-FLOW", name="TSCO Communication Flow — Lead to Report Submission / Corporate Handoff", sample_type="BUSINESS CASE", version=6, active=True)
        db.add(business); db.flush()
    business_steps = [
        (1,"lead_generation","Client Request / Lead",Role.SALES_MARKETING.value,False,False),
        (2,"quotation","Quotation",Role.CLIENT_COORDINATOR.value,False,False),
        (3,"client_follow_up","Client Decision / Follow-up",Role.CLIENT_COORDINATOR.value,False,False),
        (4,"purchase_order_received","Purchase Order Received",Role.CLIENT_COORDINATOR.value,False,False),
        (5,"complete_handover","Complete Handover — Commercial / Technical / Client Information",Role.CLIENT_COORDINATOR.value,True,False),
        (6,"client_coordination","Client Coordination",Role.OPERATIONS_MANAGER.value,False,False),
        (7,"sampling","Sampling",Role.SAMPLING_SUPERVISOR.value,False,False),
        (8,"sample_delivery","Sample Delivery to Laboratory",Role.DATA_ENTRY.value,False,False),
        (9,"testing","Testing",Role.LAB_TECHNICIAN.value,False,False),
        (10,"review","Senior Technical Review",Role.SENIOR_CHEMIST.value,True,False),
        (11,"final_report_release","Final TSCO Report Approval & Release",Role.TECHNICAL_MANAGER.value,True,False),
        (12,"report_submission","Report Submission to Client",Role.CLIENT_COORDINATOR.value,False,False),
        (13,"invoicing","Corporate Invoicing (External)","external_parent_admin",False,False),
        (14,"payment_collection","Corporate Payment Processing (External)","external_parent_admin",False,True),
    ]
    existing = list(db.scalars(select(WorkflowStep).where(WorkflowStep.workflow_id == business.id)).all())
    expected = [x[1] for x in business_steps]
    if business.version != 6 or [x.step_key for x in sorted(existing, key=lambda r: r.step_order)] != expected or [x.responsible_role for x in sorted(existing, key=lambda r: r.step_order)] != [x[3] for x in business_steps]:
        for row in existing: db.delete(row)
        db.flush(); business.version = 6
        for order,key,label,role,approval,terminal in business_steps:
            db.add(WorkflowStep(workflow_id=business.id, step_order=order, step_key=key, label=label, responsible_role=role, approval_required=approval, terminal=terminal))

    legacy = db.scalar(select(ApprovalPolicy).where(ApprovalPolicy.site_id.is_(None), ApprovalPolicy.code == "LMS-SUBMISSION"))
    if legacy:
        legacy.active = False
    if not db.scalar(select(ApprovalPolicy).where(ApprovalPolicy.site_id.is_(None), ApprovalPolicy.code == "TSCO-REPORT-RELEASE")):
        db.add(ApprovalPolicy(site_id=None, code="TSCO-REPORT-RELEASE", name="TSCO Final Report Approval & Release", entity_type="SAMPLE_REPORT", stages_json='[{"stage":"Result Entry","role":"lab_technician"},{"stage":"Technical Review","role":"senior_chemist"},{"stage":"Final Approval & Release","role":"technical_manager"}]', active=True))




def _migrate_standalone_report_state(db) -> None:
    """Convert the former external-release gate into the standalone TSCO release state.

    Approved legacy external-release rows already passed the Technical Manager gate under the old design,
    so they become official TSCO releases. Orphan sample states fall back to REPORT_APPROVED
    and must pass the controlled report route before client submission.
    """
    rows = list(db.scalars(select(ControlledReport).where(ControlledReport.status == SampleStatus.READY_FOR_LMS.value)).all())
    released_sample_ids = set()
    for row in rows:
        if row.approved_by_id and row.approved_at:
            row.status = SampleStatus.REPORT_RELEASED.value
            row.lms_status = "NOT_APPLICABLE"
            row.lms_reference = ""
            if row.sample:
                row.sample.status = SampleStatus.REPORT_RELEASED.value
                row.sample.released_at = row.sample.released_at or row.approved_at
                released_sample_ids.add(row.sample_id if hasattr(row, "sample_id") else row.sample_request_id)
    orphan_samples = list(db.scalars(select(SampleRequest).where(SampleRequest.status == SampleStatus.READY_FOR_LMS.value)).all())
    for sample in orphan_samples:
        if sample.id not in released_sample_ids:
            sample.status = SampleStatus.REPORT_APPROVED.value

def seed() -> None:
    db = SessionLocal()
    try:
        _migrate_standalone_report_state(db)
        dammam = db.scalar(select(Site).where(Site.code == "DMM"))
        if not dammam:
            dammam = Site(code="DMM", name="Dammam", laboratory_name="Transformer Oil Laboratory")
            db.add(dammam)
            db.flush()
        if not db.scalar(select(Site).where(Site.code == "JBL")):
            db.add(Site(code="JBL", name="Jubail", laboratory_name="Hydrocarbon Laboratory", active=False))
        if not db.scalar(select(Site).where(Site.code == "BHR")):
            db.add(Site(code="BHR", name="Bahrain", laboratory_name="Laboratory Operations", active=False))
        db.flush()
        # Organizational departments/functions mirror the supplied TSCO Analytical Lab org chart.
        # Workflow stages (Receiving, QC, Continuous Improvement, etc.) are not invented as departments.
        departments = [
            (None, "CORP", "General Management"),
            (None, "SAM", "Sales & Marketing Department"),
            (None, "SHARED", "Shared Services"),
            (dammam.id, "LABS", "Dammam & Bahrain Labs"),
            (dammam.id, "FIELD", "Field Operations"),
            (dammam.id, "LAB", "Laboratory Operations"),
        ]
        for sid, code, name in departments:
            stmt = select(Department).where(Department.code == code)
            stmt = stmt.where(Department.site_id.is_(None)) if sid is None else stmt.where(Department.site_id == sid)
            department = db.scalar(stmt)
            if not department:
                db.add(Department(site_id=sid, code=code, name=name, active=True))
            else:
                department.name = name
                department.active = True

        # Retire v3.1.2 organizational inventions on existing databases.  Keep rows for
        # historical FK integrity, but never present them as active departments.
        for retired_code in {"OPS", "RCV", "QLT", "EXC", "FIN"}:
            for retired in db.scalars(select(Department).where(Department.code == retired_code)).all():
                retired.active = False

        bootstrap_email = os.getenv("BOOTSTRAP_ADMIN_EMAIL", "admin@tsco.local").lower().strip()
        bootstrap_password = os.getenv("BOOTSTRAP_ADMIN_PASSWORD", "").strip()
        app_env = os.getenv("APP_ENV", "development").strip().lower()
        admin = db.scalar(select(User).where(User.email == bootstrap_email))
        if not admin:
            if not bootstrap_password:
                raise RuntimeError("BOOTSTRAP_ADMIN_PASSWORD must be configured when creating the bootstrap administrator")
            admin = User(
                email=bootstrap_email,
                full_name=os.getenv("BOOTSTRAP_ADMIN_NAME", "System Administrator"),
                password_hash=hash_password(bootstrap_password),
                role=Role.SYSTEM_ADMIN.value,
                site_id=dammam.id,
                must_change_password=_truthy("REQUIRE_BOOTSTRAP_PASSWORD_CHANGE", "false"),
            )
            db.add(admin)

        # Baseline laboratory packages are application master data, not demo data.
        # Import them once into SQL; from that point Admin/SQL is authoritative.
        ensure_baseline_test_packages(db)

        # Confirmed TSCO technical-result rules from QDF-[7]-08-A current Analysis Report.
        # These are controlled baseline rules; unconfirmed DL/range/precision values remain configurable, never guessed.
        confirmed_rules = [
            ("Furan", "IEC 61198", "2-Furfural (2FAL)", "mg/kg", 0.01, "Numeric <= DL -> LTD; retain raw value internally; LTD -> Total Furan LTD; Indirect DP >1000; Paper Lifetime >30 Years"),
            ("Total Acid Number", "ASTM D664", "Total Acid Number", "mg KOH/g", 0.01, "Numeric <= DL -> LTD; retain raw value internally"),
            ("DBDS", "IEC 62697-1", "Dibenzyl Disulfide (DBDS)", "mg/kg", 0.5, "Numeric <= DL -> LTD; retain raw value internally"),
            ("Peroxide", "ASTM D3703", "Peroxide Number", "", 0.1, "Numeric <= DL -> LTD; retain raw value internally"),
            ("RSH", "UOP 163", "Total Mercaptan (RSH)", "mg KOH/g", 0.1, "Numeric <= DL -> LTD; retain raw value internally"),
            ("H2S", "UOP 163", "Hydrogen Sulfide Gas (H2S)", "", 0.1, "Numeric <= DL -> LTD; retain raw value internally"),
            ("Toluene", "ASTM D5580", "Toluene", "mg/kg", 0.1, "Numeric <= DL -> LTD; retain raw value internally"),
            ("BHT", "IEC 60666", "Antioxidant (BHT)", "mg/kg", 0.01, "Numeric <= DL -> LTD; retain raw value internally"),
            ("Passivator", "IEC 60666", "Passivator (Irgamet 39)", "mg/kg", 0.01, "Numeric <= DL -> LTD; retain raw value internally"),
            ("Passivator", "IEC 60666", "Passivator (TTA)", "mg/kg", 0.01, "Numeric <= DL -> LTD; retain raw value internally"),
            ("Passivator", "IEC 60666", "Passivator (BTA)", "mg/kg", 0.01, "Numeric <= DL -> LTD; retain raw value internally"),
        ] + [("DGA", "IEC 60567", gas, "ppm", 1.0, "Numeric <= analyte DL -> LTD; retain raw value internally") for gas in ["Hydrogen (H2)","Ethylene (C2H4)","Ethane (C2H6)","Acetylene (C2H2)","Methane (CH4)","Carbon Monoxide (CO)","Carbon Dioxide (CO2)"]]
        for test, method, field, unit, dl, downstream in confirmed_rules:
            exists = db.scalar(select(TechnicalResultRule).where(TechnicalResultRule.site_id==dammam.id, TechnicalResultRule.test_name==test, TechnicalResultRule.method_name==method, TechnicalResultRule.result_field==field, TechnicalResultRule.equipment_id==""))
            if not exists:
                db.add(TechnicalResultRule(site_id=dammam.id,test_name=test,method_name=method,result_field=field,unit=unit,allowed_states="NUMERIC,LTD",detection_limit=dl,rounding_rule="SOURCE_CONTROLLED",downstream_rule=downstream,source_reference="QDF-[7]-08-A Analysis Report",effective_revision="Current review reference"))

        # Controlled Dammam Equipment Master baseline. EQ-03/EQ-04 and EQ-05 are taken from
        # the controlled IFT and Color EOPs; the Electrical/Water/HPLC IDs are from the supplied
        # Dammam equipment register. Structural mappings are reconciled on every startup so a
        # legacy row cannot silently keep the workstation QC/report path blocked. Operational
        # status and calibration/verification due dates remain authoritative and are never reset.
        equipment_baseline = [
            ("EQ-03","Sigma 702ET Interfacial Tensiometer","Physical / Chemistry","ASTM D971"),
            ("EQ-04","Sigma 702ET Interfacial Tensiometer","Physical / Chemistry","ASTM D971"),
            ("EQ-05","Lovibond EC3000 Color Meter","Physical / Chemistry","ASTM D1500"),
            ("EQ-23","DGA GC-TOGA","DGA","IEC 60567"),
            ("EQ-64","DGA GC-TOGA","DGA","IEC 60567"),
            ("EQ-69","Karl Fischer Water Instrument","Water","IEC 60814"),("EQ-70","Karl Fischer Water Instrument","Water","IEC 60814"),
            ("EQ-24","BDV Instrument","Electrical","IEC 60156 / ASTM D1816 / ASTM D877"),("EQ-25","BDV Instrument","Electrical","IEC 60156 / ASTM D1816 / ASTM D877"),("EQ-30","BDV Instrument","Electrical","IEC 60156 / ASTM D1816 / ASTM D877"),
            ("EQ-26","Megger OTD LG2-P3 Power/Dissipation Factor Instrument","Electrical","ASTM D924 / IEC 60247 / ASTM D1169"),("EQ-49","Power/Dissipation Factor Instrument","Electrical","ASTM D924 / IEC 60247 / ASTM D1169"),("EQ-130","Power/Dissipation Factor Instrument","Electrical","ASTM D924 / IEC 60247 / ASTM D1169"),
            ("EQ-9","HPLC","Furan / Passivator","IEC 61198"),("EQ-10","HPLC","Furan / Passivator","IEC 61198"),("EQ-11","HPLC","Furan / Passivator","IEC 61198"),("EQ-12","HPLC","Furan / Passivator","IEC 61198"),("EQ-128","HPLC","Furan / Passivator","IEC 61198"),
            ("EQ-79","Metrohm 907 Titrando","TAN / Peroxide / RSH / H2S","ASTM D664 / ASTM D3703 / UOP 163"),("EQ-80","Metrohm 907 Titrando","TAN / Peroxide / RSH / H2S","ASTM D664 / ASTM D3703 / UOP 163"),
        ]
        for eid,name,ws,method in equipment_baseline:
            equipment = db.scalar(select(EquipmentAsset).where(EquipmentAsset.site_id==dammam.id,EquipmentAsset.equipment_id==eid))
            if not equipment:
                db.add(EquipmentAsset(site_id=dammam.id,equipment_id=eid,name=name,workstation=ws,test_method=method,status="IN_SERVICE",active=True,notes="Controlled Dammam equipment baseline; calibration/provider metadata remains Quality-controlled."))
                continue
            # Reconcile only controlled structural identity/mapping. Preserve real operational
            # status plus calibration/verification dates. IN_SERVICE + inactive is contradictory
            # master data, so normalize the active flag without reviving OUT_OF_SERVICE assets.
            equipment.name = name
            equipment.workstation = ws
            equipment.test_method = method
            if str(equipment.status or "").upper() == "IN_SERVICE":
                equipment.active = True

        # Emit a non-sensitive startup preflight so deployment verification can prove whether
        # report-critical equipment is actually ready in the live database before UAT resumes.
        now = datetime.utcnow()
        preflight = []
        db.flush()
        for eid in ("EQ-03","EQ-04","EQ-05","EQ-24","EQ-25","EQ-26","EQ-30","EQ-49","EQ-79","EQ-80","EQ-130"):
            equipment = db.scalar(select(EquipmentAsset).where(EquipmentAsset.site_id==dammam.id, EquipmentAsset.equipment_id==eid))
            if not equipment:
                preflight.append(f"{eid}:MISSING")
                continue
            reasons = []
            if not equipment.active: reasons.append("INACTIVE")
            if str(equipment.status or "").upper() != "IN_SERVICE": reasons.append(str(equipment.status or "NOT_IN_SERVICE").upper())
            if equipment.next_calibration_at and equipment.next_calibration_at < now: reasons.append("CAL_OVERDUE")
            if equipment.next_verification_at and equipment.next_verification_at < now: reasons.append("VER_OVERDUE")
            preflight.append(f"{eid}:{'READY' if not reasons else '+'.join(reasons)}")
        print("TSCO_EQUIPMENT_PREFLIGHT=" + ";".join(preflight), flush=True)

        _ensure_core_workflows(db)

        # Organization correction: receiving is not a standalone system role. Existing legacy users
        # are folded into the unified Sample Intake & Receiving role before any environment returns.
        for legacy_user in db.scalars(select(User).where(User.role == Role.SAMPLE_RECEIVING.value)).all():
            legacy_user.role = Role.DATA_ENTRY.value

        seed_demo = _truthy("SEED_DEMO_DATA", "false")
        if app_env in {"uat", "production"} and seed_demo:
            raise RuntimeError("SEED_DEMO_DATA must remain false in UAT/production")
        if not seed_demo:
            db.commit()
            return

        clients: dict[str, Client] = {}
        for code, name in [
            ("ARM", "Saudi Aramco"),
            ("SEC", "Saudi Electricity Company"),
            ("GPEL", "GPEL"),
        ]:
            client = db.scalar(select(Client).where(Client.code == code))
            if not client:
                client = Client(code=code, name=name)
                db.add(client)
                db.flush()
            clients[code] = client

        sec = clients["SEC"]
        # Client hierarchies are seeded as examples of long-term scoped access.
        hierarchy_specs = [
            ("SEC", None, "REGION", "SEC-EAST", "Eastern Region"),
            ("SEC", None, "REGION", "SEC-CENTRAL", "Central Region"),
            ("SEC", None, "REGION", "SEC-WEST", "Western Region"),
            ("SEC", None, "REGION", "SEC-SOUTH", "Southern Region"),
            ("ARM", None, "AREA", "ARM-ABQ", "Abqaiq"),
            ("ARM", None, "AREA", "ARM-HAR", "Haradh"),
            ("ARM", None, "AREA", "ARM-DHA", "Dhahran"),
            ("GPEL", None, "SITE", "GPEL-DEMO-SITE", "GPEL Review Site"),
        ]
        unit_map = {}
        for client_code, parent_code, unit_type, code, name in hierarchy_specs:
            c = clients[client_code]
            unit = db.scalar(select(ClientUnit).where(ClientUnit.client_id == c.id, ClientUnit.code == code))
            if not unit:
                parent = unit_map.get((client_code, parent_code)) if parent_code else None
                unit = ClientUnit(client_id=c.id, parent_id=parent.id if parent else None, unit_type=unit_type, code=code, name=name, active=True)
                db.add(unit); db.flush()
            unit_map[(client_code, code)] = unit
        child_specs = [
            ("SEC", "SEC-EAST", "SUBSTATION", "SEC-DMM-WEST", "Dammam West Substation"),
            ("ARM", "ARM-ABQ", "FACILITY", "ARM-ABQ-PLANT", "Abqaiq Plant"),
            ("ARM", "ARM-HAR", "FACILITY", "ARM-HAR-PLANT", "Haradh Gas Plant"),
            ("ARM", "ARM-DHA", "FACILITY", "ARM-DHA-HQ", "Dhahran Facilities"),
            ("GPEL", "GPEL-DEMO-SITE", "SUBSTATION", "GPEL-DEMO-SS", "Main Review Substation"),
        ]
        for client_code, parent_code, unit_type, code, name in child_specs:
            c=clients[client_code]; parent=unit_map[(client_code,parent_code)]
            unit=db.scalar(select(ClientUnit).where(ClientUnit.client_id==c.id,ClientUnit.code==code))
            if not unit:
                unit=ClientUnit(client_id=c.id,parent_id=parent.id,unit_type=unit_type,code=code,name=name,active=True); db.add(unit); db.flush()
            unit_map[(client_code,code)] = unit
        quote = db.scalar(select(Quotation).where(Quotation.client_id == sec.id, Quotation.number == "QT-SEC-2026-014"))
        if not quote:
            quote = Quotation(client_id=sec.id, number="QT-SEC-2026-014", description="Transformer oil testing services")
            db.add(quote)
            db.flush()
        po = db.scalar(select(PurchaseOrder).where(PurchaseOrder.client_id == sec.id, PurchaseOrder.number == "PO-SEC-2026-221"))
        if not po:
            po = PurchaseOrder(client_id=sec.id, quotation_id=quote.id, number="PO-SEC-2026-221")
            db.add(po)
        asset = db.scalar(select(Asset).where(Asset.client_id == sec.id, Asset.asset_code == "SEC-DMM-TR-001"))
        if not asset:
            asset = Asset(
                client_id=sec.id,
                client_unit_id=unit_map[("SEC","SEC-DMM-WEST")].id,
                asset_code="SEC-DMM-TR-001",
                serial_number="SN-SEC-884120",
                equipment_type="Power Transformer",
                manufacturer="Demo Manufacturer",
                voltage_kv=132,
                rated_mva=100,
                station_name="Dammam West Substation",
                asset_location_label="Bay 4 / Main Transformer",
                latitude=26.4207,
                longitude=50.0888,
            )
            db.add(asset)

        # Review-only asset examples make the Client → Location → Transformer tree visible
        # for every demo client. They are clearly marked as UAT examples and are not used as
        # real client master data outside SEED_DEMO_DATA environments.
        demo_assets = [
            ("SEC", "SEC-DMM-WEST", "SEC-DMM-TR-002", "UAT-SEC-002", "UAT Example Manufacturer", 132, 50, "Dammam West Substation", "Review Bay 2"),
            ("ARM", "ARM-ABQ-PLANT", "ARM-ABQ-TR-001", "UAT-ARM-ABQ-001", "UAT Example Manufacturer", 115, 75, "Abqaiq Plant", "Review Transformer Yard"),
            ("ARM", "ARM-HAR-PLANT", "ARM-HAR-TR-001", "UAT-ARM-HAR-001", "UAT Example Manufacturer", 115, 50, "Haradh Gas Plant", "Review Transformer Yard"),
            ("GPEL", "GPEL-DEMO-SS", "GPEL-DEMO-TR-001", "UAT-GPEL-001", "UAT Example Manufacturer", 33, 20, "Main Review Substation", "Review Bay 1"),
        ]
        for client_code, unit_code, asset_code, serial, manufacturer, voltage, mva, station, location in demo_assets:
            c = clients[client_code]
            existing_asset = db.scalar(select(Asset).where(Asset.client_id == c.id, Asset.asset_code == asset_code))
            if not existing_asset:
                db.add(Asset(
                    client_id=c.id, client_unit_id=unit_map[(client_code, unit_code)].id, asset_code=asset_code,
                    serial_number=serial, equipment_type="Power Transformer", manufacturer=manufacturer,
                    voltage_kv=voltage, rated_mva=mva, station_name=station, asset_location_label=location,
                ))

        demo_user_password = os.getenv("DEMO_USER_PASSWORD", "").strip()
        if not demo_user_password:
            raise RuntimeError("DEMO_USER_PASSWORD must be configured when SEED_DEMO_DATA=true")
        demo_password = hash_password(demo_user_password)
        # v3.1.8 UAT identity policy: reviewers log in by job title / function, not by
        # current employee name. This keeps role walkthroughs neutral and avoids implying
        # that staffing assignments are already final. Production IT can later create named
        # accounts and bind them to the same role, department and approval relationships.
        role_review_specs = [
            ("general.manager@tsco.local", "UAT Role — General Manager", Role.MANAGEMENT.value, None, None),
            ("excellence.specialist@tsco.local", "UAT Role — Excellence Specialist", Role.EXCELLENCE.value, None, None),
            ("secretary@tsco.local", "UAT Role — Secretary", Role.CORPORATE_SUPPORT.value, None, None),
            ("sales.marketing.specialist@tsco.local", "UAT Role — Sales & Marketing Specialist", Role.SALES_MARKETING.value, dammam.id, None),
            ("salesman@tsco.local", "UAT Role — Salesman", Role.SALES_MARKETING.value, dammam.id, None),
            ("field.manager@tsco.local", "UAT Role — Field Operational & Technical Manager", Role.OPERATIONS_MANAGER.value, dammam.id, None),
            ("sampling.supervisor@tsco.local", "UAT Role — Sampling Supervisor", Role.SAMPLING_SUPERVISOR.value, dammam.id, None),
            ("data.entry@tsco.local", "UAT Role — Data Entry", Role.DATA_ENTRY.value, dammam.id, None),
            ("sampleman@tsco.local", "UAT Role — Sampleman", Role.FIELD_SAMPLER.value, dammam.id, None),
            ("client.coordinator@tsco.local", "UAT Role — Client Account & Coordination Officer", Role.CLIENT_COORDINATOR.value, dammam.id, None),
            ("external.coordination@tsco.local", "UAT Role — External Coordination Officer", Role.CLIENT_COORDINATOR.value, dammam.id, None),
            ("lab.manager@tsco.local", "UAT Role — Lab Operational & Technical Manager", Role.TECHNICAL_MANAGER.value, dammam.id, None),
            ("senior.technical@tsco.local", "UAT Role — Senior Chemist (Technical)", Role.SENIOR_CHEMIST.value, dammam.id, None),
            ("senior.equipment@tsco.local", "UAT Role — Senior Chemist (Equipment & Maintenance)", Role.SENIOR_CHEMIST.value, dammam.id, None),
            ("senior.improvement@tsco.local", "UAT Role — Senior Chemist (Continuous Improvement)", Role.SENIOR_CHEMIST.value, dammam.id, None),
            ("chemist@tsco.local", "UAT Role — Chemist", Role.LAB_TECHNICIAN.value, dammam.id, None),
            ("technician@tsco.local", "UAT Role — Chemical Technician", Role.LAB_TECHNICIAN.value, dammam.id, None),
            ("lab.support@tsco.local", "UAT Role — Glassware Cleaning / Laboratory Support", Role.LAB_SUPPORT.value, dammam.id, None),
            # External/client review identities remain scenario-based rather than employee-based.
            ("clientsampler@sec.local", "SEC Client Sampler", Role.CLIENT_SAMPLER.value, dammam.id, sec.id),
            ("clientops@sec.local", "SEC Client Operations", Role.CLIENT_OPERATIONS.value, dammam.id, sec.id),
            ("client@sec.local", "SEC Client User", Role.CLIENT.value, None, sec.id),
            ("client@aramco.local", "Saudi Aramco Corporate User", Role.CLIENT.value, None, clients["ARM"].id),
            ("abqaiq@aramco.local", "Aramco Abqaiq User", Role.CLIENT.value, None, clients["ARM"].id),
            ("eastern@sec.local", "SEC Eastern Region User", Role.CLIENT.value, None, sec.id),
        ]

        # Named employees remain available only in the automated testing environment so the
        # historical regression suite can validate the exact organizational source chart.
        # They are not UAT review logins.
        named_test_specs = [
            ("salah.alshajira@tsco.local", "Salah Al-Shajira", Role.MANAGEMENT.value, None, None),
            ("ohood.alhareeqi@tsco.local", "Ohood Al Hareeqi", Role.EXCELLENCE.value, None, None),
            ("renad.alqahtani@tsco.local", "Renad Al Qahtani", Role.CORPORATE_SUPPORT.value, None, None),
            ("humayoon@tsco.local", "Humayoon", Role.SALES_MARKETING.value, dammam.id, None),
            ("khalid.alali@tsco.local", "Khalid Alali", Role.SALES_MARKETING.value, dammam.id, None),
            ("abdulmajeed@tsco.local", "Abdulmajeed", Role.OPERATIONS_MANAGER.value, dammam.id, None),
            ("ahmed.alqahtani@tsco.local", "Ahmed Al Qahtani", Role.DATA_ENTRY.value, dammam.id, None),
            ("mohammed.amir@tsco.local", "Mohammed Amir", Role.FIELD_SAMPLER.value, dammam.id, None),
            ("matiullah.khan@tsco.local", "Matiullah Khan", Role.FIELD_SAMPLER.value, dammam.id, None),
            ("rahmatullah.abdulmomin@tsco.local", "Rahmatullah Abdul Momin", Role.FIELD_SAMPLER.value, dammam.id, None),
            ("mohammed.majid@tsco.local", "Mohammed Majid", Role.FIELD_SAMPLER.value, dammam.id, None),
            ("mubarak.abdullah@tsco.local", "Mubarak Abdullah", Role.FIELD_SAMPLER.value, dammam.id, None),
            ("malindu.eranda@tsco.local", "Malindu Eranda", Role.CLIENT_COORDINATOR.value, dammam.id, None),
            ("mohammed.athaf@tsco.local", "Mohammed Athaf", Role.CLIENT_COORDINATOR.value, dammam.id, None),
            ("muhammed.arsalan@tsco.local", "Muhammed Arsalan", Role.CLIENT_COORDINATOR.value, dammam.id, None),
            ("sara.alotaibi@tsco.local", "Sara Al Otaibi", Role.CLIENT_COORDINATOR.value, dammam.id, None),
            ("rwad@tsco.local", "Rwad", Role.TECHNICAL_MANAGER.value, dammam.id, None),
            ("mohammed.alyahya@tsco.local", "Mohammed Al Yahya", Role.SENIOR_CHEMIST.value, dammam.id, None),
            ("tara.alghamdi@tsco.local", "Tara Al Ghamdi", Role.SENIOR_CHEMIST.value, dammam.id, None),
            ("reem.alotaibi@tsco.local", "Reem Al Otaibi", Role.SENIOR_CHEMIST.value, dammam.id, None),
            ("ali.alorain@tsco.local", "Ali Al Orain", Role.LAB_TECHNICIAN.value, dammam.id, None),
            ("syed.azhar@tsco.local", "Syed Azhar", Role.LAB_TECHNICIAN.value, dammam.id, None),
            ("hadeel.alrashidi@tsco.local", "Hadeel Al Rashidi", Role.LAB_TECHNICIAN.value, dammam.id, None),
            ("anandhu.krishna@tsco.local", "Anandhu Krishna", Role.LAB_TECHNICIAN.value, dammam.id, None),
            ("subindev.valuparampil@tsco.local", "Subindev Valuparampil", Role.LAB_TECHNICIAN.value, dammam.id, None),
            ("abdullah.alhindi@tsco.local", "Abdullah Al Hindi", Role.LAB_TECHNICIAN.value, dammam.id, None),
            ("ziyad.alharbi@tsco.local", "Ziyad Al-Harbi", Role.LAB_TECHNICIAN.value, dammam.id, None),
            ("faisal.alshihri@tsco.local", "Faisal Al Shihri", Role.LAB_TECHNICIAN.value, dammam.id, None),
            ("sultan.alsubaie@tsco.local", "Sultan Al Subaie", Role.LAB_TECHNICIAN.value, dammam.id, None),
            ("anas.asiri@tsco.local", "Anas Asiri", Role.LAB_TECHNICIAN.value, dammam.id, None),
            ("muhanand.alazhri@tsco.local", "Muhanand Al Azhri", Role.LAB_TECHNICIAN.value, dammam.id, None),
            ("sahid.husain@tsco.local", "Sahid Husain", Role.LAB_SUPPORT.value, dammam.id, None),
        ]

        user_specs = list(role_review_specs)
        if app_env == "testing":
            user_specs.extend(named_test_specs)
            # Historical test-only identities not represented by a current UAT role persona.
            user_specs.extend([
                ("hr@tsco.local", "HR", Role.SHARED_SERVICES.value, None, None),
                ("qhse@tsco.local", "QHSE", Role.QUALITY.value, dammam.id, None),
                ("legal@tsco.local", "Legal Affairs", Role.SHARED_SERVICES.value, None, None),
                ("procurement@tsco.local", "Procurement", Role.SHARED_SERVICES.value, None, None),
                ("finance@tsco.local", "Finance", Role.FINANCE.value, dammam.id, None),
                ("it@tsco.local", "IT", Role.SHARED_SERVICES.value, None, None),
                ("erb@tsco.local", "ERB", Role.SHARED_SERVICES.value, None, None),
                ("fieldman@tsco.local", "Field Sampleman", Role.FIELD_SAMPLER.value, dammam.id, None),
                ("operations@tsco.local", "Operations Manager", Role.OPERATIONS_MANAGER.value, dammam.id, None),
                ("intake@tsco.local", "Data Entry", Role.DATA_ENTRY.value, dammam.id, None),
                ("chemist@tsco.local", "Laboratory Chemist", Role.LAB_TECHNICIAN.value, dammam.id, None),
                ("chemist2@tsco.local", "Laboratory Chemist 2", Role.LAB_TECHNICIAN.value, dammam.id, None),
                ("quality@tsco.local", "Quality Officer", Role.QUALITY.value, dammam.id, None),
                ("manager@tsco.local", "Management", Role.MANAGEMENT.value, None, None),
                ("corporate@tsco.local", "Corporate Management", Role.MANAGEMENT.value, None, None),
                ("sales@tsco.local", "Sales & Marketing", Role.SALES_MARKETING.value, dammam.id, None),
                ("coordinator@tsco.local", "Client Coordinator", Role.CLIENT_COORDINATOR.value, dammam.id, None),
                ("excellence@tsco.local", "Excellence Specialist", Role.EXCELLENCE.value, None, None),
                ("senior@tsco.local", "Senior Chemist", Role.SENIOR_CHEMIST.value, dammam.id, None),
                ("senior.maintenance@tsco.local", "Senior Chemist — Maintenance", Role.SENIOR_CHEMIST.value, dammam.id, None),
                ("technical@tsco.local", "Technical Manager", Role.TECHNICAL_MANAGER.value, dammam.id, None),
                ("supervisor@tsco.local", "Sampling Supervisor", Role.SAMPLING_SUPERVISOR.value, dammam.id, None),
                ("receiving@tsco.local", "Legacy Receiving Test Alias", Role.DATA_ENTRY.value, dammam.id, None),
            ])

        users: dict[str, User] = {}
        for email, name, role, site_id, client_id in user_specs:
            user = db.scalar(select(User).where(User.email == email))
            if not user:
                user = User(
                    email=email,
                    full_name=name,
                    password_hash=demo_password,
                    role=role,
                    site_id=site_id,
                    client_id=client_id,
                )
                db.add(user)
                db.flush()
            else:
                # Demo/UAT seed is authoritative for review personas. This also reactivates
                # identities that existed as inactive compatibility aliases in older packages.
                user.full_name = name
                user.password_hash = demo_password
                user.role = role
                user.site_id = site_id
                user.client_id = client_id
                user.active = True
            users[email] = user

        job_titles = {
            # v3.1.8 role-review identities shown during UAT walkthroughs.
            "general.manager@tsco.local": "General Manager",
            "excellence.specialist@tsco.local": "Excellence Specialist",
            "secretary@tsco.local": "Secretary",
            "sales.marketing.specialist@tsco.local": "Sales & Marketing Specialist",
            "salesman@tsco.local": "Salesman",
            "field.manager@tsco.local": "Field Operational & Technical Manager",
            "sampling.supervisor@tsco.local": "Sampling Supervisor",
            "data.entry@tsco.local": "Data Entry",
            "sampleman@tsco.local": "Sampleman",
            "client.coordinator@tsco.local": "Client Account & Coordination Officer",
            "external.coordination@tsco.local": "External Coordination Officer",
            "lab.manager@tsco.local": "Lab Operational & Technical Manager",
            "senior.technical@tsco.local": "Senior Chemist — Technical",
            "senior.equipment@tsco.local": "Senior Chemist — Equipment & Maintenance",
            "senior.improvement@tsco.local": "Senior Chemist — Continuous Improvement",
            "chemist@tsco.local": "Chemist",
            "technician@tsco.local": "Chemical Technician",
            "lab.support@tsco.local": "Glassware Cleaning",
            "salah.alshajira@tsco.local": "General Manager",
            "ohood.alhareeqi@tsco.local": "Excellence Specialist",
            "renad.alqahtani@tsco.local": "Secretary",
            "humayoon@tsco.local": "Sales & Marketing Specialist",
            "khalid.alali@tsco.local": "Salesman",
            "abdulmajeed@tsco.local": "Field Operational & Technical Manager",
            "ahmed.alqahtani@tsco.local": "Data Entry",
            "mohammed.amir@tsco.local": "Sampleman", "matiullah.khan@tsco.local": "Sampleman",
            "rahmatullah.abdulmomin@tsco.local": "Sampleman", "mohammed.majid@tsco.local": "Sampleman",
            "mubarak.abdullah@tsco.local": "Sampleman",
            "malindu.eranda@tsco.local": "Client Account & Coordination Officer",
            "mohammed.athaf@tsco.local": "Client Account & Coordination Officer",
            "muhammed.arsalan@tsco.local": "Client Account & Coordination Officer",
            "sara.alotaibi@tsco.local": "External Coordination Officer",
            "rwad@tsco.local": "Lab Operational & Technical Manager",
            "mohammed.alyahya@tsco.local": "Senior Chemist", "tara.alghamdi@tsco.local": "Senior Chemist", "reem.alotaibi@tsco.local": "Senior Chemist",
            "ali.alorain@tsco.local": "Chemist", "syed.azhar@tsco.local": "Chemist", "hadeel.alrashidi@tsco.local": "Chemist",
            "anandhu.krishna@tsco.local": "Chemist", "subindev.valuparampil@tsco.local": "Chemist", "abdullah.alhindi@tsco.local": "Chemist", "ziyad.alharbi@tsco.local": "Chemist",
            "faisal.alshihri@tsco.local": "Chemical Technician", "sultan.alsubaie@tsco.local": "Chemical Technician", "anas.asiri@tsco.local": "Chemical Technician", "muhanand.alazhri@tsco.local": "Chemical Technician",
            "sahid.husain@tsco.local": "Glassware Cleaning",
            "hr@tsco.local": "HR", "qhse@tsco.local": "QHSE", "legal@tsco.local": "Legal Affairs",
            "procurement@tsco.local": "Procurement", "finance@tsco.local": "Finance", "it@tsco.local": "IT", "erb@tsco.local": "ERB",
        }
        # Compatibility aliases display the same real job-title baseline rather than invented departments.
        alias_titles = {
            "fieldman@tsco.local": "Sampleman", "operations@tsco.local": "Field Operational & Technical Manager",
            "intake@tsco.local": "Data Entry", "chemist2@tsco.local": "Chemist",
            "quality@tsco.local": "QHSE", "manager@tsco.local": "Lab Operational & Technical Manager",
            "corporate@tsco.local": "General Manager", "sales@tsco.local": "Sales & Marketing Specialist",
            "coordinator@tsco.local": "Client Account & Coordination Officer", "excellence@tsco.local": "Excellence Specialist",
            "senior@tsco.local": "Senior Chemist", "senior.maintenance@tsco.local": "Senior Chemist",
            "technical@tsco.local": "Lab Operational & Technical Manager",
        }
        job_titles.update(alias_titles)
        for email, title in job_titles.items():
            if email in users:
                users[email].job_title = title
                users[email].senior_responsibility_domain = ""

        # Fixed additional Senior Chemist responsibility domains. These are responsibility
        # sections on the same Senior Chemist accounts, never separate roles/departments.
        # Mohammed Al Yahya carries the Technical / Methods / Troubleshooting coordination;
        # Tara Al Ghamdi carries Instrument Maintenance / Equipment / Calibration follow-up;
        # Reem Al Otaibi carries Continuous Improvement coordination with Excellence.
        senior_domains = {
            # Three distinct Senior Chemist UAT review accounts; same role, different responsibility section.
            "senior.technical@tsco.local": "TECHNICAL",
            "senior.equipment@tsco.local": "EQUIPMENT",
            "senior.improvement@tsco.local": "IMPROVEMENT",
            "mohammed.alyahya@tsco.local": "TECHNICAL",
            "tara.alghamdi@tsco.local": "EQUIPMENT",
            "reem.alotaibi@tsco.local": "IMPROVEMENT",
            # Historical automated-test aliases preserve the same three fixed slots.
            "senior@tsco.local": "TECHNICAL",
            "senior.maintenance@tsco.local": "EQUIPMENT",
            "senior.improvement@tsco.local": "IMPROVEMENT",
        }
        for email, domain in senior_domains.items():
            if email in users:
                users[email].senior_responsibility_domain = domain

        # Final organization alignment: Receiving is a workflow stage inside the single Data Entry workspace under Dammam & Bahrain Labs.
        # Legacy review accounts are deactivated instead of presenting a second employee/department/workspace.
        legacy_receiving = db.scalar(select(User).where(User.email == "receiving@tsco.local"))
        if legacy_receiving:
            legacy_receiving.role = Role.DATA_ENTRY.value
            if app_env != "testing":
                legacy_receiving.active = False

        if app_env != "testing":
            # Older review packages created duplicate convenience logins for the same people.
            # They remain test-only compatibility identities and must not appear as real employee accounts.
            compatibility_aliases = {
                "fieldman@tsco.local", "operations@tsco.local", "intake@tsco.local",
                "chemist2@tsco.local", "quality@tsco.local",
                "manager@tsco.local", "corporate@tsco.local", "sales@tsco.local",
                "coordinator@tsco.local", "excellence@tsco.local", "senior@tsco.local",
                "senior.maintenance@tsco.local",
                "technical@tsco.local", "supervisor@tsco.local", "receiving@tsco.local",
            }
            for alias in db.scalars(select(User).where(User.email.in_(compatibility_aliases))).all():
                alias.active = False

        active_departments = db.scalars(select(Department).where(Department.active.is_(True))).all()
        dept_by_code = {d.code: d for d in active_departments}
        dept_map = {
            # v3.1.8 UAT role-review identities
            "general.manager@tsco.local": "CORP", "excellence.specialist@tsco.local": "CORP", "secretary@tsco.local": "CORP",
            "sales.marketing.specialist@tsco.local": "SAM", "salesman@tsco.local": "SAM",
            "field.manager@tsco.local": "FIELD", "sampling.supervisor@tsco.local": "FIELD", "sampleman@tsco.local": "FIELD",
            "client.coordinator@tsco.local": "FIELD", "external.coordination@tsco.local": "FIELD",
            "data.entry@tsco.local": "LABS",
            "lab.manager@tsco.local": "LAB", "senior.technical@tsco.local": "LAB", "senior.equipment@tsco.local": "LAB", "senior.improvement@tsco.local": "LAB",
            "chemist@tsco.local": "LAB", "technician@tsco.local": "LAB", "lab.support@tsco.local": "LAB",
            "salah.alshajira@tsco.local": "CORP", "ohood.alhareeqi@tsco.local": "CORP", "renad.alqahtani@tsco.local": "CORP",
            "humayoon@tsco.local": "SAM", "khalid.alali@tsco.local": "SAM",
            "abdulmajeed@tsco.local": "FIELD",
            "mohammed.amir@tsco.local": "FIELD", "matiullah.khan@tsco.local": "FIELD", "rahmatullah.abdulmomin@tsco.local": "FIELD",
            "mohammed.majid@tsco.local": "FIELD", "mubarak.abdullah@tsco.local": "FIELD",
            "malindu.eranda@tsco.local": "FIELD", "mohammed.athaf@tsco.local": "FIELD", "muhammed.arsalan@tsco.local": "FIELD", "sara.alotaibi@tsco.local": "FIELD",
            "ahmed.alqahtani@tsco.local": "LABS",
            "rwad@tsco.local": "LAB", "mohammed.alyahya@tsco.local": "LAB", "tara.alghamdi@tsco.local": "LAB", "reem.alotaibi@tsco.local": "LAB",
            "ali.alorain@tsco.local": "LAB", "syed.azhar@tsco.local": "LAB", "hadeel.alrashidi@tsco.local": "LAB", "anandhu.krishna@tsco.local": "LAB",
            "subindev.valuparampil@tsco.local": "LAB", "abdullah.alhindi@tsco.local": "LAB", "ziyad.alharbi@tsco.local": "LAB",
            "faisal.alshihri@tsco.local": "LAB", "sultan.alsubaie@tsco.local": "LAB", "anas.asiri@tsco.local": "LAB", "muhanand.alazhri@tsco.local": "LAB", "sahid.husain@tsco.local": "LAB",
            "hr@tsco.local": "SHARED", "qhse@tsco.local": "SHARED", "legal@tsco.local": "SHARED", "procurement@tsco.local": "SHARED",
            "finance@tsco.local": "SHARED", "it@tsco.local": "SHARED", "erb@tsco.local": "SHARED",
            # Compatibility aliases
            "fieldman@tsco.local": "FIELD", "operations@tsco.local": "FIELD", "intake@tsco.local": "LABS",
            "chemist@tsco.local": "LAB", "chemist2@tsco.local": "LAB", "quality@tsco.local": "SHARED",
            "manager@tsco.local": "LAB", "corporate@tsco.local": "CORP", "sales@tsco.local": "SAM",
            "coordinator@tsco.local": "FIELD", "excellence@tsco.local": "CORP", "senior@tsco.local": "LAB",
            "senior.maintenance@tsco.local": "LAB", "senior.improvement@tsco.local": "LAB", "technical@tsco.local": "LAB",
            "supervisor@tsco.local": "FIELD",
        }
        for email, code in dept_map.items():
            if email in users and code in dept_by_code:
                users[email].department_id = dept_by_code[code].id

        # Named organizational source of truth retained for regression/reference: one employee, one job title, one
        # reporting line and one direct leave approver.  This prevents generic role-based
        # leave routing (for example, sending a GM secretary through a laboratory Senior).
        for email, spec in EMPLOYEE_BY_EMAIL.items():
            person = users.get(email)
            if not person:
                continue
            person.full_name = spec.name
            person.job_title = spec.job_title
            person.role = spec.role
            if spec.department_code in dept_by_code:
                person.department_id = dept_by_code[spec.department_code].id
        db.flush()
        for email, spec in EMPLOYEE_BY_EMAIL.items():
            person = users.get(email)
            if not person:
                continue
            manager = users.get(spec.manager_email) if spec.manager_email else None
            leave_approver = users.get(spec.leave_approver_email) if spec.leave_approver_email else None
            person.manager_id = manager.id if manager else None
            person.leave_approver_id = leave_approver.id if leave_approver else None

        # v3.1.8 role-review reporting / leave approval routes. These are intentionally
        # job-title based for UAT; production named users inherit the same relationships.
        role_review_reporting = {
            "excellence.specialist@tsco.local": ("general.manager@tsco.local", "general.manager@tsco.local"),
            "secretary@tsco.local": ("general.manager@tsco.local", "general.manager@tsco.local"),
            "sales.marketing.specialist@tsco.local": ("general.manager@tsco.local", "general.manager@tsco.local"),
            "salesman@tsco.local": ("general.manager@tsco.local", "general.manager@tsco.local"),
            "field.manager@tsco.local": ("general.manager@tsco.local", "general.manager@tsco.local"),
            "sampling.supervisor@tsco.local": ("field.manager@tsco.local", "field.manager@tsco.local"),
            "data.entry@tsco.local": ("field.manager@tsco.local", "field.manager@tsco.local"),
            "sampleman@tsco.local": ("sampling.supervisor@tsco.local", "sampling.supervisor@tsco.local"),
            "client.coordinator@tsco.local": ("field.manager@tsco.local", "field.manager@tsco.local"),
            "external.coordination@tsco.local": ("field.manager@tsco.local", "field.manager@tsco.local"),
            "lab.manager@tsco.local": ("general.manager@tsco.local", "general.manager@tsco.local"),
            "senior.technical@tsco.local": ("lab.manager@tsco.local", "lab.manager@tsco.local"),
            "senior.equipment@tsco.local": ("lab.manager@tsco.local", "lab.manager@tsco.local"),
            "senior.improvement@tsco.local": ("lab.manager@tsco.local", "lab.manager@tsco.local"),
            "chemist@tsco.local": ("lab.manager@tsco.local", "lab.manager@tsco.local"),
            "technician@tsco.local": ("lab.manager@tsco.local", "lab.manager@tsco.local"),
            "lab.support@tsco.local": ("lab.manager@tsco.local", "lab.manager@tsco.local"),
        }
        for email, (manager_email, approver_email) in role_review_reporting.items():
            person = users.get(email)
            manager = users.get(manager_email)
            approver = users.get(approver_email)
            if person:
                person.manager_id = manager.id if manager else None
                person.leave_approver_id = approver.id if approver else None

        # UAT/testing review identities require explicit competency because production
        # assignment is hard-gated even when no prior competency records exist. These are
        # demo-only authorizations and are never seeded in production because SEED_DEMO_DATA
        # is forbidden there.
        competency_workstations = [
            "Water", "Electrical", "DGA", "Furan / Passivator", "Paper DP / Furan",
            "DBDS / BHT / Toluene / PCB", "TAN / Peroxide / RSH / H2S",
            "Corrosion / CCD", "Physical / Chemistry", "Additives / Special Tests",
        ]
        lab_demo_users = [u for u in users.values() if u.role == Role.LAB_TECHNICIAN.value and u.site_id == dammam.id and u.active]
        evaluator = users.get("lab.manager@tsco.local") or admin
        for person in lab_demo_users:
            for workstation in competency_workstations:
                exists = db.scalar(select(CompetencyRecord).where(
                    CompetencyRecord.site_id == dammam.id, CompetencyRecord.user_id == person.id,
                    CompetencyRecord.workstation == workstation, CompetencyRecord.active.is_(True),
                ))
                if not exists:
                    db.add(CompetencyRecord(
                        site_id=dammam.id, user_id=person.id, test_name="UAT workstation authorization",
                        method_name="Controlled by assignment/test method", workstation=workstation, category=3,
                        authorization="INDEPENDENT", effective_at=datetime.utcnow(),
                        evaluated_by_id=evaluator.id if evaluator else None, evidence_reference="UAT baseline competency evidence",
                        notes="Review-only competency seed; production competency must be configured from controlled evidence.",
                    ))

        # When upgrading an existing v3.1.6 review database, old named staff identities are
        # retained only as inactive records. UAT reviewers see job-title accounts instead.
        if app_env != "testing":
            named_emails = list(EMPLOYEE_BY_EMAIL.keys())
            for old_named_user in db.scalars(select(User).where(User.email.in_(named_emails))).all():
                old_named_user.active = False

        # Shared Services review identities represent functions, not named employees.
        # Do not fabricate reporting managers or leave approval chains for them.
        for email in {"hr@tsco.local", "qhse@tsco.local", "legal@tsco.local", "procurement@tsco.local", "finance@tsco.local", "it@tsco.local", "erb@tsco.local"}:
            if email in users:
                users[email].manager_id = None
                users[email].leave_approver_id = None

        # Scoped client accounts: corporate users have no unit assignment; regional users are constrained to a subtree.
        for email, unit_key in [
            ("abqaiq@aramco.local", ("ARM","ARM-ABQ")),
            ("eastern@sec.local", ("SEC","SEC-EAST")),
        ]:
            usr=users[email]; unit=unit_map[unit_key]
            if not db.scalar(select(UserClientUnitAssignment).where(UserClientUnitAssignment.user_id==usr.id, UserClientUnitAssignment.client_unit_id==unit.id)):
                db.add(UserClientUnitAssignment(user_id=usr.id, client_unit_id=unit.id))

        fieldman = users.get("fieldman@tsco.local", users["sampleman@tsco.local"])
        if not db.scalar(
            select(UserClientAssignment).where(
                UserClientAssignment.user_id == fieldman.id,
                UserClientAssignment.client_id == sec.id,
            )
        ):
            db.add(UserClientAssignment(user_id=fieldman.id, client_id=sec.id))

        demo_case = db.scalar(select(CommercialCase).where(CommercialCase.case_code=="BC-DMM-2026-0001"))
        if not demo_case:
            demo_case = CommercialCase(
                case_code="BC-DMM-2026-0001", site_id=dammam.id, client_id=sec.id,
                owner_id=users.get("coordinator@tsco.local", users["client.coordinator@tsco.local"]).id, quotation_id=quote.id, purchase_order_id=po.id,
                current_stage="COMPLETE_HANDOVER", status="ACTIVE",
                lead_title="Transformer oil testing services", lead_source="Existing client",
                proposal_reference="PR-SEC-2026-014", client_follow_up="Scope and schedule confirmed with client.",
                po_received_reference=po.number,
                handover_commercial=f"Quotation {quote.number}; Purchase Order {po.number}; commercial scope confirmed.",
                handover_technical="Transformer oil analysis scope, required test package and TAT confirmed.",
                handover_client_info="Client contacts and Eastern Region coordination information confirmed.",
            )
            db.add(demo_case); db.flush()
            for stage, note in [
                ("LEAD_GENERATION","Business opportunity opened"),("QUOTATION",quote.number),("PROPOSAL","PR-SEC-2026-014"),
                ("CLIENT_FOLLOW_UP","Client scope confirmed"),("PURCHASE_ORDER",po.number),
                ("PURCHASE_ORDER_RECEIVED",po.number),("COMPLETE_HANDOVER","Commercial, technical and client information handed over"),
            ]:
                db.add(CommercialEvent(commercial_case_id=demo_case.id, actor_id=users.get("coordinator@tsco.local", users["client.coordinator@tsco.local"]).id, from_stage="", to_stage=stage, note=note))

        # Controlled workflow master data is seeded above in every environment.
        db.commit()
    finally:
        db.close()
