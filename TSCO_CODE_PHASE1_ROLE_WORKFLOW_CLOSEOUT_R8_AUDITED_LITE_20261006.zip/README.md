# TSCO Digital Laboratory Platform — Project 00012 v3.4.9

Current UAT package: **v3.4.9 — QC Workstation Entry-Point Fix + Global Analytical/Test QC Framework**.

The release preserves the existing PostgreSQL UAT journey and consolidates live defects found from Client Request through Data Entry and first Laboratory Workstation execution. It does not reintroduce LMS.

See `START_HERE.md`, `V3.4.9_GLOBAL_ANALYTICAL_QC.md`, and the retained v3.4.7 intake amendment record.

Database migration head: `c43a7d9e2f10` (unchanged from v3.4.4).

## v3.6.0 R6 — Workflow Integration Closeout
Senior Chemist, Operations, and Management tracking now use a shared server-authoritative sample workflow projection with exact blockers, result progress, workstation closeout progress, and Technical Review readiness. Read-only tracking surfaces no longer autosave browser OperationsState.
