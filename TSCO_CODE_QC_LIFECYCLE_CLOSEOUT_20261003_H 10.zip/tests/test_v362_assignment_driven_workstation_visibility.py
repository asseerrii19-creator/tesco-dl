from datetime import datetime
from types import SimpleNamespace
from pathlib import Path

from app.services import lab_operations as ops


def _chemist():
    return SimpleNamespace(role='lab_technician', id=17, full_name='UAT Role — Chemist')


def _empty_uat_payload():
    return {
        'staff': [
            {'id':17,'name':'UAT Role — Chemist','role':'lab_technician','active':True},
            {'id':18,'name':'UAT Role — Chemical Technician','role':'lab_technician','active':True},
        ],
        'batches': [],
        'testAssignments': [
            {'id':'BAD-E','batch_id':'*','workstation':'Electrical','mode':'SINGLE','primary_user_id':18,'primary_name':'UAT Role — Chemical Technician','revision':7,'source':'AUTO_14_DAY_ROTATION_CONTINUITY_REPAIR','cycle_key':'20260927-20261010','cycle_start':'2026-09-27T00:00:00','cycle_end':'2026-10-10T23:59:59','assigned_at':'2026-10-04T03:00:00'},
            {'id':'BAD-A','batch_id':'*','workstation':'Additives / Special Tests','mode':'SINGLE','primary_user_id':17,'primary_name':'UAT Role — Chemist','revision':3,'source':'AUTO_14_DAY_ROTATION_CONTINUITY_REPAIR','cycle_key':'20260927-20261010','cycle_start':'2026-09-27T00:00:00','cycle_end':'2026-10-10T23:59:59','assigned_at':'2026-10-04T03:00:00'},
        ],
        'results': [], 'qc': [], 'qualifiedQcProfiles': [], 'qcLots': [], 'qcLotEvents': [], 'qcEvidence': [],
        'retests': [], 'dgaAttachments': [], 'resultEvidence': [], 'assignmentCompletions': [],
        'qualityDistributions': [], 'qualityTaskEvents': [], 'reports': [], 'retained': [], 'storageAssignments': [],
        'batchHistory': [], 'cancelledSamples': [], 'supervisorNotes': [],
    }


def test_current_uat_cycle_repair_does_not_require_visible_batch_anchor():
    payload = _empty_uat_payload()
    repaired = ops.repair_known_uat_cycle_assignments(payload, 'DMM', when=datetime(2026,10,4,9,0,0))
    assert repaired
    electrical = ops._authoritative_global_assignment(payload, 'Electrical', when=datetime(2026,10,4,9,0,0))
    additives = ops._authoritative_global_assignment(payload, 'Additives / Special Tests', when=datetime(2026,10,4,9,0,0))
    assert electrical['primary_user_id'] == 17
    assert electrical['source'] == 'CONTROLLED_UAT_STATE_REPAIR'
    assert additives['mode'] == 'UNASSIGNED'


def test_scoped_payload_exposes_owned_global_workstations_even_with_empty_queue():
    payload = _empty_uat_payload()
    ops.repair_known_uat_cycle_assignments(payload, 'DMM', when=datetime(2026,10,4,9,0,0))
    scoped = ops.scope_operations_payload(payload, _chemist())
    workstations = {row['workstation'] for row in scoped['testAssignments']}
    assert 'Electrical' in workstations
    assert 'TAN / Peroxide / RSH / H2S' in workstations
    assert 'Additives / Special Tests' not in workstations
    assert scoped['batches'] == []


def test_server_qc_authorization_is_assignment_driven_not_batch_driven():
    payload = _empty_uat_payload()
    ops.repair_known_uat_cycle_assignments(payload, 'DMM', when=datetime(2026,10,4,9,0,0))
    assert ops._user_has_workstation_assignment(payload, 'Electrical', _chemist()) is True
    assert ops._user_has_workstation_assignment(payload, 'Additives / Special Tests', _chemist()) is False


def test_browser_workstation_and_qc_navigation_use_authoritative_assignment_not_queue_presence():
    html = Path('app/lab_ops/index_template.html').read_text()
    assert "const a=authoritativeGlobalAssignment(w);if(assignmentAllowsUser(a))out.add(w)" in html
    assert "const global=authoritativeGlobalAssignment(workstation);if(global&&assignmentAllowsUser(global))return global" in html
    assert "const owned=visibleWorkstations();all.forEach(q=>{if(q&&owned.has(qcWorkstation(q))" in html
