from datetime import datetime
from types import SimpleNamespace
from app.services import lab_operations as ops


def _chemist():
    return SimpleNamespace(role='lab_technician', id=17, full_name='UAT Role — Chemist')


def test_original_14_day_publication_beats_later_corrupt_auto_rows_without_staff_repair_dependency():
    payload = {
        'batches': [{
            'id': 'LB-20261001175803-A162C1',
            'samples': ['DMM26-000003', 'DMM26-000004'],
            'sample_meta': {},
            'tests': [
                {'test': 'Room Test Temperature', 'station': 'Additives / Special Tests', 'method': '-'},
                {'test': 'Room Test Humidity', 'station': 'Additives / Special Tests', 'method': '-'},
                {'test': 'Breakdown Voltage @2.5mm- AVG', 'station': 'Electrical', 'method': 'IEC 60156'},
                {'test': 'Power Factor @25°C/60Hz', 'station': 'Electrical', 'method': 'ASTM D924'},
            ],
        }],
        'staff': [],
        'testAssignments': [
            {
                'id':'WSA-AUTO-20260927-20261010-ELECTRICAL','batch_id':'*','workstation':'Electrical',
                'mode':'SINGLE','primary_user_id':17,'primary_name':'UAT Role — Chemist','revision':1,
                'source':'AUTO_14_DAY_ROTATION','cycle_key':'20260927-20261010','assigned_at':'2026-09-29T15:51:50',
            },
            {
                'id':'BAD-E','batch_id':'*','workstation':'Electrical','mode':'SINGLE','primary_user_id':18,
                'primary_name':'UAT Role — Chemical Technician','revision':7,
                'source':'AUTO_14_DAY_ROTATION','cycle_key':'20260927-20261010','assigned_at':'2026-10-04T03:00:00',
            },
            {
                'id':'BAD-A','batch_id':'*','workstation':'Additives / Special Tests','mode':'SINGLE','primary_user_id':17,
                'primary_name':'UAT Role — Chemist','revision':3,
                'source':'AUTO_14_DAY_ROTATION_CONTINUITY_REPAIR','cycle_key':'20260927-20261010','assigned_at':'2026-10-04T03:00:00',
            },
        ],
        'results': [], 'qc': [], 'qualifiedQcProfiles': [], 'qcLots': [], 'qcLotEvents': [], 'qcEvidence': [],
        'retests': [], 'dgaAttachments': [], 'resultEvidence': [], 'assignmentCompletions': [],
        'qualityDistributions': [], 'qualityTaskEvents': [], 'reports': [], 'retained': [], 'storageAssignments': [],
        'batchHistory': [], 'cancelledSamples': [], 'supervisorNotes': [],
    }
    current = ops._current_test_assignment(payload, 'LB-20261001175803-A162C1', 'Electrical')
    assert current['id'] == 'WSA-AUTO-20260927-20261010-ELECTRICAL'
    assert current['primary_user_id'] == 17

    scoped = ops.scope_operations_payload(payload, _chemist())
    assert [b['id'] for b in scoped['batches']] == ['LB-20261001175803-A162C1']
    tests = [r['test'] for r in scoped['batches'][0]['tests']]
    assert 'Breakdown Voltage @2.5mm- AVG' in tests
    assert 'Power Factor @25°C/60Hz' in tests
    assert 'Room Test Temperature' not in tests
    assert 'Room Test Humidity' not in tests
    assert {a['workstation'] for a in scoped['testAssignments']} == {'Electrical'}


def test_batch_specific_senior_exception_still_overrides_stable_global_cycle_owner():
    payload = {
        'batches': [{'id':'B1','samples':['S1'],'tests':[{'test':'Breakdown Voltage @2.5mm- AVG'}]}],
        'testAssignments': [
            {'id':'G','batch_id':'*','workstation':'Electrical','mode':'SINGLE','primary_user_id':17,'revision':1,'source':'AUTO_14_DAY_ROTATION','cycle_key':'20260927-20261010','assigned_at':'2026-09-29T10:00:00'},
            {'id':'X','batch_id':'B1','workstation':'Electrical','mode':'SINGLE','primary_user_id':18,'revision':1,'source':'SENIOR_EXCEPTION','assigned_at':'2026-10-04T05:00:00'},
        ]
    }
    assert ops._current_test_assignment(payload, 'B1', 'Electrical')['id'] == 'X'


def test_controlled_uat_repair_neutralizes_ghost_additives_global_assignment():
    payload = {
        'batches': [{
            'id': 'LB-20261001175803-A162C1',
            'samples': ['DMM26-000003', 'DMM26-000004'],
            'sample_meta': {},
            'tests': [
                {'test': 'Breakdown Voltage @2.5mm- AVG', 'station': 'Electrical', 'method': 'IEC 60156'},
                {'test': 'Power Factor @25°C/60Hz', 'station': 'Electrical', 'method': 'ASTM D924'},
                {'test': 'Passivator Content', 'station': 'Additives / Special Tests', 'method': 'IEC 60666'},
            ],
        }],
        'staff': [
            {'id':17,'name':'UAT Role — Chemist','role':'lab_technician','active':True},
            {'id':18,'name':'UAT Role — Chemical Technician','role':'lab_technician','active':True},
        ],
        'testAssignments': [
            {'id':'E0','batch_id':'*','workstation':'Electrical','mode':'SINGLE','primary_user_id':17,'primary_name':'UAT Role — Chemist','revision':1,'source':'AUTO_14_DAY_ROTATION','cycle_key':'20260927-20261010','assigned_at':'2026-09-29T10:00:00'},
            {'id':'A-BAD','batch_id':'*','workstation':'Additives / Special Tests','mode':'SINGLE','primary_user_id':17,'primary_name':'UAT Role — Chemist','revision':4,'source':'AUTO_14_DAY_ROTATION_CONTINUITY_REPAIR','cycle_key':'20260927-20261010','assigned_at':'2026-10-04T03:00:00'},
        ],
        'results': [], 'qc': [], 'qualifiedQcProfiles': [], 'qcLots': [], 'qcLotEvents': [], 'qcEvidence': [],
        'retests': [], 'dgaAttachments': [], 'resultEvidence': [], 'assignmentCompletions': [],
        'qualityDistributions': [], 'qualityTaskEvents': [], 'reports': [], 'retained': [], 'storageAssignments': [],
        'batchHistory': [], 'cancelledSamples': [], 'supervisorNotes': [],
    }
    repaired = ops.repair_known_uat_cycle_assignments(payload, 'DMM', when=datetime(2026,10,4,6,0,0))
    assert any(r['workstation'] == 'Additives / Special Tests' and r['mode'] == 'UNASSIGNED' for r in repaired)
    assert ops._current_test_assignment(payload, 'LB-20261001175803-A162C1', 'Additives / Special Tests')['mode'] == 'UNASSIGNED'
    scoped = ops.scope_operations_payload(payload, _chemist())
    assert {'Electrical', 'TAN / Peroxide / RSH / H2S'}.issubset({a['workstation'] for a in scoped['testAssignments']})
    assert 'Additives / Special Tests' not in {a['workstation'] for a in scoped['testAssignments']}
    assert [r['test'] for r in scoped['batches'][0]['tests']] == ['Breakdown Voltage @2.5mm- AVG', 'Power Factor @25°C/60Hz']
