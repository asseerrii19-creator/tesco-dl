from __future__ import annotations

import json
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import Asset, Client, CommercialAttachment, CommercialCase, PurchaseOrder, Quotation, SampleRequest, Site, TestPackageConfig, AuditLog
from app.services.lab_operations import get_operations_state


def login(client: TestClient, email: str) -> None:
    r = client.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303


def scope():
    token = uuid4().hex[:8].upper()
    with SessionLocal() as db:
        site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
        client = db.scalar(select(Client).where(Client.code == 'SEC')); assert client
        asset = db.scalar(select(Asset).where(Asset.client_id == client.id)); assert asset
        pkg = db.scalar(select(TestPackageConfig).where(TestPackageConfig.active.is_(True)).order_by(TestPackageConfig.id)); assert pkg
        quote = Quotation(client_id=client.id, number=f'QT-V347-{token}', status='ACTIVE', description='Controlled amendment UAT')
        db.add(quote); db.flush()
        po = PurchaseOrder(client_id=client.id, quotation_id=quote.id, number=f'PO-V347-{token}', status='ACTIVE')
        db.add(po); db.flush()
        case = CommercialCase(case_code=f'BC-DMM-2026-{token}', site_id=site.id, client_id=client.id,
                              quotation_id=quote.id, purchase_order_id=po.id, current_stage='COMPLETE_HANDOVER', status='ACTIVE',
                              lead_title='Controlled intake amendment', handover_commercial='Approved quote and PO',
                              handover_technical='Transformer oil testing', handover_client_info='Direct delivery',
                              expected_samples=1, requested_test_package=pkg.name, default_priority='URGENT', required_tat='24H')
        db.add(case); db.commit()
        return site.id, client.id, asset.id, quote.id, po.id, case.id, pkg.name


def released_sample(browser: TestClient):
    site_id, client_id, asset_id, quote_id, po_id, case_id, pkg = scope()
    login(browser, 'data.entry@tsco.local')
    r = browser.post('/intake/direct', data={
        'client_id': client_id, 'asset_id': asset_id, 'quotation_id': quote_id, 'purchase_order_id': po_id,
        'requested_package': pkg, 'sampling_point': 'Bottom', 'sample_count': 1, 'container_count': 1,
        'client_sample_reference': 'V347', 'priority': 'URGENT', 'required_tat': '24H',
    }, follow_redirects=False)
    assert r.status_code == 303
    with SessionLocal() as db:
        sample = db.scalar(select(SampleRequest).where(SampleRequest.commercial_case_id == case_id)); assert sample
        sid = sample.id
    assert browser.post('/intake/bulk-decision', data={'sample_ids': [sid], 'note': 'verified'}, follow_redirects=False).status_code == 303
    assert browser.post('/intake/bulk-receive', data={'sample_ids': [sid], 'seal_status': 'Intact', 'condition_note': ''}, follow_redirects=False).status_code == 303
    assert browser.post('/intake/batch-release', data={'sample_ids': [sid], 'note': 'lab handoff'}, follow_redirects=False).status_code == 303
    return site_id, sid


def test_data_entry_can_amend_released_intake_and_lab_projection_reads_new_values():
    with TestClient(app) as browser:
        site_id, sid = released_sample(browser)
        r = browser.post(f'/intake/{sid}/amend-intake-data', data={
            'sampling_point': 'Bottom Drain Valve',
            'sample_date_time': '2026-10-01T20:50',
            'oil_temperature_c': '49',
            'ambient_temperature_c': '36',
            'ambient_humidity_pct': '46',
            'sampling_reason': 'Routine condition assessment',
            'equipment_status': 'In service',
            'client_sample_reference': 'UPDATED-REF',
            'container_count': '1',
            'amendment_reason': 'Verified against revised client data form',
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            sample = db.get(SampleRequest, sid); assert sample
            assert sample.status == 'READY_FOR_LAB'
            assert sample.oil_temperature_c == 49
            assert sample.ambient_temperature_c == 36
            assert sample.ambient_humidity_pct == 46
            assert sample.sampling_point == 'Bottom Drain Valve'
            site = db.get(Site, site_id); assert site
            _, payload = get_operations_state(db, site)
            batch = next(b for b in payload['batches'] if sid in (b.get('platform_sample_ids') or []))
            key = sample.lms_number or sample.request_number
            meta = batch['sample_meta'][key.upper()]
            assert meta['temp'] == '49.0'
            assert meta['roomTemp'] == '36.0'
            assert meta['roomHumidity'] == '46.0'
            assert meta['point'] == 'Bottom Drain Valve'
            audit = db.scalar(select(AuditLog).where(AuditLog.entity_type == 'SampleRequest', AuditLog.entity_id == sid, AuditLog.action == 'INTAKE_DATA_AMENDED').order_by(AuditLog.id.desc()))
            assert audit is not None
            details = json.loads(audit.details or '{}')
            assert details['reason'] == 'Verified against revised client data form'
            assert details['after']['oil_temperature_c'] == 49.0


def test_system_admin_can_use_same_controlled_amendment_but_physical_received_at_is_not_editable():
    with TestClient(app) as browser:
        _, sid = released_sample(browser)
        with SessionLocal() as db:
            sample = db.get(SampleRequest, sid); assert sample
            received_before = sample.received_at
        browser.get('/logout')
        login(browser, 'admin@tsco.local')
        page = browser.get(f'/intake/{sid}')
        assert page.status_code == 200
        assert 'Admin Override — Save Controlled Amendment' in page.text
        assert 'Physical Received At is system-controlled' in page.text
        r = browser.post(f'/intake/{sid}/amend-intake-data', data={
            'sampling_point': 'Bottom', 'sample_date_time': '2026-10-01T20:50', 'oil_temperature_c': '48',
            'ambient_temperature_c': '35', 'ambient_humidity_pct': '45', 'sampling_reason': 'Updated',
            'equipment_status': 'In service', 'client_sample_reference': '', 'container_count': '1',
            'amendment_reason': 'Emergency correction verified by source document',
            'received_at': '1999-01-01T00:00',
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            sample = db.get(SampleRequest, sid); assert sample
            assert sample.received_at == received_before
            assert sample.oil_temperature_c == 48


def test_data_entry_can_link_newer_client_data_form_revision_without_deleting_history():
    with TestClient(app) as browser:
        _, sid = released_sample(browser)
        with SessionLocal() as db:
            sample = db.get(SampleRequest, sid); assert sample and sample.commercial_case_id
            case_id = sample.commercial_case_id
            before = list(db.scalars(select(CommercialAttachment).where(CommercialAttachment.commercial_case_id == case_id)).all())
        fake_pdf = b"%PDF-1.4\n1 0 obj<</Type/Catalog>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF"
        r = browser.post(
            f'/intake/{sid}/upload-client-data-form',
            data={'note': 'Client issued revised sheet'},
            files={'upload': ('Revised_Client_Data_Form.pdf', fake_pdf, 'application/pdf')},
            follow_redirects=False,
        )
        assert r.status_code == 303
        with SessionLocal() as db:
            rows = list(db.scalars(select(CommercialAttachment).where(CommercialAttachment.commercial_case_id == case_id, CommercialAttachment.document_type == 'CLIENT_DATA_FORM').order_by(CommercialAttachment.id)).all())
            assert len(rows) >= 1
            assert rows[-1].original_name == 'Revised_Client_Data_Form.pdf'
            assert rows[-1].content_blob == fake_pdf
            assert len(list(db.scalars(select(CommercialAttachment).where(CommercialAttachment.commercial_case_id == case_id)).all())) == len(before) + 1


def test_lab_technician_has_analytical_qc_workspace_and_clear_qc_gate():
    with TestClient(app) as browser:
        login(browser, 'technician@tsco.local')
        page = browser.get('/lab/operations?section=quality')
        assert page.status_code == 200
        assert 'Analytical / Test QC' in page.text
        app_page = browser.get('/lab/operations/app?embed=1&section=quality')
        assert app_page.status_code == 200
        assert 'ANALYTICAL QC' in app_page.text
        assert 'Water Analytical / Test QC is required for the current assignment before result entry.' in app_page.text
        assert "data.error||('Server rejected save (" in app_page.text
