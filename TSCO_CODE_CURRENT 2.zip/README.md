# TSCO Digital Laboratory Platform — Project 00012 v3.4.7

Current UAT package: **v3.4.7 — Controlled Intake Amendment + Live Intake Projection**.

The release preserves the existing PostgreSQL UAT journey and consolidates live defects found from Client Request through Data Entry and first Laboratory Workstation execution. It does not reintroduce LMS.

See `START_HERE.md` and `V3.4.7_CONTROLLED_INTAKE_AMENDMENT.md`.

Database migration head: `c43a7d9e2f10` (unchanged from v3.4.4).
