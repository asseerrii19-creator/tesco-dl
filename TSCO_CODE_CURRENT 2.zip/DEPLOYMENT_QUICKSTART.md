# Deployment Quick Start — v3.4.7

Deploy over the existing Render service and PostgreSQL database. Do not reset or recreate the database.
Expected Alembic head: `c43a7d9e2f10`.
