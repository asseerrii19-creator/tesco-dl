#!/usr/bin/env bash
set -euo pipefail
pytest -q \
  tests/test_v340_standalone_closeout.py \
  tests/test_v341_final_analysis_report.py \
  tests/test_v342_senior_final_report_review.py \
  tests/test_v343_intake_continuity_hotfix.py \
  tests/test_v344_data_form_backfill.py \
  tests/test_v345_consolidated_intake_closeout.py \
  tests/test_v346_live_intake_projection.py \
  tests/test_v347_controlled_intake_amendment.py
