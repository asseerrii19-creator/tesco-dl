#!/usr/bin/env bash
set -euo pipefail
MARKER="TSCO-MULTI-DATA-FORM-CUSTODY-20261010-R14.2"
echo "TSCO_BUILD_MARKER=${MARKER}"
echo "TSCO_RELEASE_AUTHORITY_SCOPE=R14_BASELINE+REAL_QDF_DATA_FORM+MULTI_TRANSFORMER+MULTI_SAMPLE+CLIENT_LOCK_REOPEN+STABLE_BARCODE+INTERNAL_CUSTODY"
python -m compileall -q app migrations tests
for f in app/static/app.js app/static/field-form.js app/static/service-worker.js; do node --check "$f"; done
python - <<'PY'
from pathlib import Path
from jinja2 import Environment
import re
for f in [
    'app/templates/intake_queue.html','app/templates/intake_review.html','app/templates/operations_dashboard.html',
    'app/templates/sampling_supervision.html','app/templates/client_request.html','app/templates/commercial_flow.html','app/templates/field_new.html'
]:
    Environment().parse(Path(f).read_text(encoding='utf-8'))
html=Path('app/lab_ops/index_template.html').read_text(encoding='utf-8')
parts=re.findall(r'<script[^>]*>(.*?)</script>',html,re.S)
if len(parts)!=1:
    raise SystemExit(f'Expected one inline Laboratory Operations script, found {len(parts)}')
Path('/tmp/tsco_lab_ops_release.js').write_text(parts[0], encoding='utf-8')
print('TSCO_TEMPLATE_PARSE_ASSERTION=PASS')
PY
node --check /tmp/tsco_lab_ops_release.js
echo "TSCO_CODE_SYNTAX_ASSERTION=PASS"
python - <<'PY'
from pathlib import Path
html=Path('app/lab_ops/index_template.html').read_text(encoding='utf-8')
required=[
    'Analytical QC — Result Validity','DGA QC / CRM Instrument CSV','Original DGA Result PDF',
    '/lab-operations/dga/parse-pdf',"source:'DGA result PDF'",'DGA RESULTS COMPLETE','Required gases:',
    'BDV Instrument Export (cumulative CSV)','parseElectricalCsv(text,sample)','/lab-operations/bdv/result-sheet',
    "'bdv-instrument-source'","kind:'bdv-result-sheet'",'instrument_record_id','bdvSheet.data_url',
    'PF Instrument Result File (CSV)','IEC 60156 uses 6 breakdowns; ASTM D1816/D877 use 5.',
    'function applyAnalyticalQcActionLocks()','SAVE BOTH READINGS + AVERAGE','WATER_DUAL_AVERAGE',
    'function reconcile409AndRetry(localPayload)', 'function equipmentClassSupportsContext',
    "if((STORAGE.dirty||STORAGE.saving)&&!force)return false;", 'normalRetentionDays:14',
]
missing=[x for x in required if x not in html]
if missing:
    raise SystemExit('R14 Laboratory Operations assertion failed; missing: '+', '.join(missing))
print('TSCO_R14_LAB_BASELINE_ASSERTION=PASS')
for marker in ('function storageSlots(){const rows=[4,4,4,4,2]','function storageCode(x)','normalRetentionDays:14'):
    if marker not in html:
        raise SystemExit(f'Existing storage authority marker missing: {marker}')
print('TSCO_EXISTING_STORAGE_MAP_ASSERTION=PASS')

PY
python - <<'PY'
from pathlib import Path
version=Path('VERSION').read_text(encoding='utf-8').strip()
expected='3.7.5-R14.2-MULTI-DATA-FORM-CUSTODY-20261010'
if version != expected:
    raise SystemExit(f'Unexpected R14.2 VERSION: {version}')
models=Path('app/models.py').read_text(encoding='utf-8')
client=Path('app/routes/client.py').read_text(encoding='utf-8')
commercial_route=Path('app/routes/commercial.py').read_text(encoding='utf-8')
field=Path('app/routes/field.py').read_text(encoding='utf-8')
form_service=Path('app/services/sampling_data_form.py').read_text(encoding='utf-8')
planned=Path('app/services/planned_samples.py').read_text(encoding='utf-8')
tpl=Path('app/templates/client_request.html').read_text(encoding='utf-8')
field_tpl=Path('app/templates/field_new.html').read_text(encoding='utf-8')
for marker in ('class ClientSamplingDataForm','class SamplingDiscrepancy','client_revision_open','sample_indices_json','form_sample_index'):
    if marker not in models:
        raise SystemExit(f'R14.1 model marker missing: {marker}')
for marker in ('FORM_CODE = "QDF [7]-03-A"','SOURCE_REVISION = "03"','Number of Samples','Sample Identification & Barcode Schedule','generated_pdf_blob'):
    if marker not in form_service and marker not in models:
        raise SystemExit(f'Real Data Form marker missing: {marker}')
for marker in ('/client/requests/{case_id}/data-form','Confirm every Sampling Data Form before submitting the request','Every physical sample in the Sampling Data Form must have exactly one Service Scope','assigned Coordinator must reopen','edit_data_form'):
    if marker not in client:
        raise SystemExit(f'Client request control marker missing: {marker}')
for marker in ('Upload Existing Data Form','Fill Data Form Online','data-form-paper','Data Form confirmed','Edit Data Form','packageInfoButton','PACKAGE CONTENT','sampling_from_other'):
    if marker not in tpl:
        raise SystemExit(f'Client paper-form/UI marker missing: {marker}')
if 'Transformer Serial Number(s)' in tpl or 'name="expected_serials"' in tpl:
    raise SystemExit('Duplicate manual transformer serial entry still exists in Client Request UI')
for marker in ('/reopen-client-request','Only the assigned Client Coordinator can reopen this request','Client-owned request scope cannot be edited by TSCO'):
    if marker not in commercial_route:
        raise SystemExit(f'Coordinator revision-control marker missing: {marker}')
for marker in ('SAMPLING_FIELD_MISMATCH_REPORTED','SamplingDiscrepancy','verification_action'):
    if marker not in field:
        raise SystemExit(f'Field verification marker missing: {marker}')
for marker in ('Report Mismatch — Do Not Sample','Accept Match & Complete Sampling','APPROVED CLIENT DATA'):
    if marker not in field_tpl:
        raise SystemExit(f'Field matching UI marker missing: {marker}')
for marker in ('ensure_planned_samples','form_sample_index','sampling_point','refresh_pdf'):
    if marker not in planned:
        raise SystemExit(f'Planned-sample/Data Form marker missing: {marker}')
print('TSCO_REAL_QDF_REQUEST_ALIGNMENT_ASSERTION=PASS')
for marker in ('forms_json',):
    if marker not in models:
        raise SystemExit(f'Multi Data Form model marker missing: {marker}')
for marker in ('TAP_CHANGER_POSITIONS = ["H1", "H2", "H3", "Other"]','def data_form_forms','def sample_rows_by_index','def form_by_number'):
    if marker not in form_service:
        raise SystemExit(f'Multi Data Form service marker missing: {marker}')
for marker in ('+ New Data Form','paper-choice-group','Tap Changer Position','SAMPLE IDENTITIES & BARCODES'):
    if marker not in tpl:
        raise SystemExit(f'Multi Data Form UI marker missing: {marker}')
intake=Path('app/routes/intake.py').read_text(encoding='utf-8')
intake_tpl=Path('app/templates/intake_queue.html').read_text(encoding='utf-8')
for marker in ('def _internal_custody_rows','storageAssignments','received_at'):
    if marker not in intake:
        raise SystemExit(f'Internal custody route marker missing: {marker}')
for marker in ('INTERNAL SAMPLE CUSTODY · TSCO ONLY','Storage Location','no second barcode or sample identity is created'):
    if marker not in intake_tpl:
        raise SystemExit(f'Internal custody UI marker missing: {marker}')
print('TSCO_MULTI_DATA_FORM_CUSTODY_ASSERTION=PASS')

PY
python - <<'PY'
from pathlib import Path
models=Path('app/models.py').read_text(encoding='utf-8')
commercial=Path('app/services/commercial.py').read_text(encoding='utf-8')
client=Path('app/routes/client.py').read_text(encoding='utf-8')
for marker in ('sales_order_number','sales_order_year','sales_order_month','invoice_contract_number','invoice_ses_number'):
    if marker not in models:
        raise SystemExit(f'Commercial model marker missing: {marker}')
for marker in ('ensure_sales_order','TIC-SO4','one Sales Order per client/site/calendar month','FINAL_REPORT_RELEASE", "REPORT_SUBMISSION'):
    if marker not in commercial:
        raise SystemExit(f'Commercial workflow marker missing: {marker}')
for marker in ('UserClientAssignment','non_aramco_pool','aramco_ids'):
    if marker not in client:
        raise SystemExit(f'Coordinator routing marker missing: {marker}')
seed=Path('app/seed.py').read_text(encoding='utf-8')
if 'external.coordination@tsco.local' not in seed or 'client.coordinator@tsco.local' not in seed:
    raise SystemExit('Active two-coordinator UAT ownership markers missing')
print('TSCO_COMMERCIAL_CLOSEOUT_ASSERTION=PASS')
PY
python - <<'PY'
from pathlib import Path
migration=Path('migrations/versions/b3f1d8a6c920_v375_multi_data_form_custody.py').read_text(encoding='utf-8')
if "revision = 'b3f1d8a6c920'" not in migration or "down_revision = 'a1d4c7f9e820'" not in migration:
    raise SystemExit('R14.2 migration lineage assertion failed')
if 'forms_json' not in migration:
    raise SystemExit('R14.2 forms_json migration marker missing')
print('TSCO_R14_2_MIGRATION_ASSERTION=PASS')
PY
if [[ "$(alembic heads | awk '{print $1}')" != "b3f1d8a6c920" ]]; then
  echo "Unexpected Alembic head" >&2
  alembic heads >&2
  exit 1
fi
echo 'TSCO_ALEMBIC_HEAD_ASSERTION=PASS'
rm -f /tmp/tsco_r14_2_migration.db
DATABASE_URL=sqlite:////tmp/tsco_r14_2_migration.db APP_ENV=testing alembic upgrade head >/tmp/tsco_r14_2_migration.log 2>&1
if ! grep -q 'b3f1d8a6c920' /tmp/tsco_r14_2_migration.log; then
  cat /tmp/tsco_r14_2_migration.log >&2
  echo 'Fresh SQLite migration did not reach R14.2 head' >&2
  exit 1
fi
echo 'TSCO_FRESH_MIGRATION_ASSERTION=PASS'
rm -f /tmp/tsco_r14_2_upgrade.db
DATABASE_URL=sqlite:////tmp/tsco_r14_2_upgrade.db APP_ENV=testing alembic upgrade a1d4c7f9e820 >/tmp/tsco_r14_2_upgrade_pre.log 2>&1
python - <<'PYUP1'
import sqlite3
con=sqlite3.connect('/tmp/tsco_r14_2_upgrade.db')
cols=[r[1] for r in con.execute('pragma table_info(client_sampling_data_forms)')]
if 'forms_json' in cols: raise SystemExit('forms_json unexpectedly exists before R14.2 upgrade')
PYUP1
DATABASE_URL=sqlite:////tmp/tsco_r14_2_upgrade.db APP_ENV=testing alembic upgrade head >/tmp/tsco_r14_2_upgrade_post.log 2>&1
python - <<'PYUP2'
import sqlite3
con=sqlite3.connect('/tmp/tsco_r14_2_upgrade.db')
cols=[r[1] for r in con.execute('pragma table_info(client_sampling_data_forms)')]
if 'forms_json' not in cols: raise SystemExit('forms_json missing after R14.2 upgrade')
head=con.execute('select version_num from alembic_version').fetchone()[0]
if head!='b3f1d8a6c920': raise SystemExit(f'Unexpected upgraded head: {head}')
PYUP2
echo 'TSCO_IN_PLACE_UPGRADE_ASSERTION=PASS'
python - <<'PY'
from pathlib import Path
import hashlib
expected={
'app/services/final_report_pdf.py':'33852209fad2f15d8176cb5b74575fa50f746f8021d2b8e6556830107a3154ea',
'app/services/final_report_data.py':'00a75e7235a9f4d7f4d80475f5d2f6e3f6f22de236c0c79e93b08bf608cea964',
'app/routes/control_center.py':'db5ced87e40f1710cd8f40429fe245c5051599f2078121584fd7d79d794a518c',
'app/lab_ops/index_template.html':'f17f57b8456bd3080eaf35fd3f5cfa1a8b05df3daa8b1aee3e19add7a3b96055',
'app/services/lab_operations.py':'0ac1610575f992919757964d4f2e679421d7e114d31739520427f392a53079f2',
}
for path,want in expected.items():
    got=hashlib.sha256(Path(path).read_bytes()).hexdigest()
    if got!=want: raise SystemExit(f'Locked authority file changed unexpectedly: {path}')
print('TSCO_LOCKED_AUTHORITY_HASH_ASSERTION=PASS')
PY
if [[ -f app/reference_documents/catalog.json ]]; then
  echo 'TSCO_REFERENCE_ASSETS=LOCAL_PRESENT'
else
  echo 'TSCO_REFERENCE_ASSETS=LITE_EXTERNAL'
fi
# R14.2 authority: retain audited laboratory/report behavior while closing multi-transformer,
# multi-sample Data Form, stable barcode and internal-custody continuity.
pytest -q \
  tests/test_v375_multi_data_form_custody.py \
  tests/test_v374_request_data_form_alignment.py \
  tests/test_v373_planned_sample_identity_closeout.py \
  tests/test_v372_real_instrument_commercial_closeout.py \
  tests/test_v371_uat_release_hardening.py \
  tests/test_v368_consolidated_review_qc_closeout.py \
  tests/test_v369_uat_dga_evidence_bridge.py \
  tests/test_v370_uat_consolidated_closeout.py \
  tests/test_v359_qc_append_only_matrix.py \
  tests/test_v367_post_senior_report_experience.py \
  tests/test_v353_uat_blocker_closeout.py \
  tests/test_closeout_result_rules.py \
  tests/test_v354_electrical_qc_closeout.py::test_live_equipment_mapping_has_controlled_fallbacks \
  tests/test_v354_electrical_qc_closeout.py::test_rsd_is_derived_child_not_independent_electrical_entry \
  tests/test_v355_uat_behavioral_closeout.py::test_iec60156_six_run_average_and_rsd_are_server_verified_as_one_run_set \
  tests/test_v355_uat_behavioral_closeout.py::test_iec60156_rejects_missing_sixth_breakdown \
  tests/test_v355_uat_behavioral_closeout.py::test_astm_bdv_keeps_method_defined_five_run_protocol \
  tests/test_v355_uat_behavioral_closeout.py::test_live_equipment_resolver_has_exact_controlled_assets_for_current_blockers \
  tests/test_v356_dga_results_closeout.py::test_dga_workstation_requires_full_controlled_nine_gas_set \
  tests/test_v356_dga_results_closeout.py::test_dga_uat_csv_fixtures_cover_qc_and_all_nine_results
echo 'TSCO_RELEASE_CHECK=PASS'
