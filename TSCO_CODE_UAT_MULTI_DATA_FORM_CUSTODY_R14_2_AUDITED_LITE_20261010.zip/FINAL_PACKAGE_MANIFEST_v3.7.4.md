# Final Package Manifest — v3.7.4 / R14.1

## Release identity
- Version: `3.7.4-R14.1-REQUEST-DATA-FORM-ALIGNMENT-20261010`
- Build marker: `TSCO-REQUEST-DATA-FORM-ALIGNMENT-20261010-R14.1`
- Alembic head: `a1d4c7f9e820`
- Previous head: `f17c4a8d2b90`

## Principal changed components
- `app/models.py` — structured Data Form, sample-index mapping, client-revision control, field discrepancy persistence.
- `app/routes/client.py` — real Data Form entry/review/confirm, client ownership lock, service-scope alignment, static paper view after confirmation.
- `app/templates/client_request.html` — paper-form UI, upload-or-fill path, package information preview, no duplicate manual serial scope field.
- `app/services/sampling_data_form.py` — QDF [7]-03-A Rev 03 Page-1 schema, controlled PDF, multi-sample rows and barcodes.
- `app/services/planned_samples.py` — structured form mapping and planned identity/barcode refresh after controlled handover.
- `app/routes/commercial.py` / `app/templates/commercial_flow.html` — assigned-Coordinator reopen-for-client-revision control.
- `app/routes/field.py` / `app/templates/field_new.html` — match / mismatch field verification and discrepancy path.
- `app/static/styles.css` — paper-form and responsive presentation.
- `migrations/versions/a1d4c7f9e820_v374_request_data_form_alignment.py` — additive migration.
- `tests/test_v374_request_data_form_alignment.py` — R14.1 regression tests.

## Deployment packaging
This is a **Lite code package**. `app/reference_documents` is intentionally excluded because the existing deployment process extracts `TSCO_REFERENCE_ASSETS.zip` before the code package. No UAT runtime uploads, caches or local databases are included.
