# Final Verification — v3.7.5 / R14.2

Executed on the assembled R14.2 work tree on **2026-10-10**.

- Python compile: **PASS**
- JavaScript syntax: **PASS**
- Jinja template parse: **PASS**
- R14 locked Laboratory Operations markers: **PASS**
- Existing storage map / 14-day retention markers: **PASS**
- Real QDF request alignment: **PASS**
- Multi Data Form / multi-transformer / multi-sample controls: **PASS**
- Paper-style selectable Data Form controls: **PASS**
- Tap Changer H1/H2/H3 support: **PASS**
- Stable planned Sample ID + Barcode per physical sample: **PASS**
- Internal custody adds Received At + existing Storage Location to same identity: **PASS**
- Client submit lock / assigned Coordinator reopen controls: **PASS**
- Locked final-report / Laboratory Operations authority hashes: **PASS**
- Alembic head: **b3f1d8a6c920**
- Fresh SQLite migration to head: **PASS**
- In-place upgrade `a1d4c7f9e820 → b3f1d8a6c920`: **PASS**
- Controlled release regression suite: **90 passed / 0 failed**

The LITE ZIP must be unpacked with the existing TSCO reference asset bundle before running the same release check, consistent with prior LITE releases.
