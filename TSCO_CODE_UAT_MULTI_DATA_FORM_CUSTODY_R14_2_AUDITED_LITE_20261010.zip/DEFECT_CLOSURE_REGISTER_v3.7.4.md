# Defect Closure Register — R14.1

| ID | Finding | R14.1 disposition |
|---|---|---|
| REQ-01 | Duplicate manual Transformer Serial Number in Request Scope | Removed; transformer identity comes from confirmed Data Form |
| DF-01 | Client Data Form upload behaved as attachment only | Structured upload/review path added; original evidence retained |
| DF-02 | Dummy form did not match real TSCO QDF | Replaced by QDF [7]-03-A Rev 03 Page-1-aligned paper form |
| DF-03 | One-transformer / multi-physical-sample structure missing | Number of Samples + physical sample lines added |
| DF-04 | Confirmed online form still looked like an editor | Confirmed form now returns to read-only paper view; explicit draft Edit Data Form action |
| DF-05 | Scanned/handwritten forms could be overstated as parsed | Scan/image path explicitly Review Required; no fabricated handwriting extraction |
| SCOPE-01 | Package name could hide included services | Package `ⓘ` preview reads Package Master tests/methods |
| OWN-01 | Client submitted data ownership/revision control incomplete | Submit locks; assigned Coordinator reopens with reason; client corrects/resubmits |
| FIELD-01 | Sampleman could re-key submitted client identity | Field path now verifies planned vs actual; no silent overwrite |
| FIELD-02 | Mismatch workflow incomplete | Discrepancy record + Operations/Coordinator notification + client correction path |
| ID-01 | Planned barcode not represented on printable Data Form | Data Form refreshed with per-sample Code128 barcodes after controlled handover |
| FR-06 | Previously released PDF artifact disappeared after deployment | **Open separate blocker**; no silent regeneration introduced |
