# Final Package Manifest — v3.7.5 / R14.2

Package authority: R14 baseline + R14.1 request/data-form controls + multi Data Form / multi physical sample / internal custody alignment.

## New/changed authority files
- `VERSION`
- `app/models.py`
- `app/routes/client.py`
- `app/routes/field.py`
- `app/routes/intake.py`
- `app/services/planned_samples.py`
- `app/services/sampling_data_form.py`
- `app/templates/client_request.html`
- `app/templates/intake_queue.html`
- `app/static/styles.css`
- `migrations/versions/b3f1d8a6c920_v375_multi_data_form_custody.py`
- `tests/test_v374_request_data_form_alignment.py`
- `tests/test_v375_multi_data_form_custody.py`
- `R14_2_MULTI_DATA_FORM_CUSTODY_20261010.md`
- `FINAL_VERIFICATION_v3.7.5.md`
- `DEFECT_CLOSURE_REGISTER_v3.7.5.md`
- `BUILD_RELEASE_CHECK.sh`

## Migration
- New head: `b3f1d8a6c920`
- Down revision: `a1d4c7f9e820`
- Additive only: adds `forms_json` to `client_sampling_data_forms`.
- No DB reset or destructive migration.

## Reference assets
The audited LITE package does not duplicate large controlled reference assets. Deployment/release verification uses the existing TSCO reference asset bundle in the same manner as prior LITE packages.
