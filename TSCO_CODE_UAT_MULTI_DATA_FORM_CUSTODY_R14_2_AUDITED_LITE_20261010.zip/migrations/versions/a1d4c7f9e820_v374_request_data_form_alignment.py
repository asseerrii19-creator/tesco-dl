"""v3.7.4 request / real Sampling Data Form alignment

Revision ID: a1d4c7f9e820
Revises: f17c4a8d2b90
Create Date: 2026-10-10
"""
from alembic import op
import sqlalchemy as sa

revision = 'a1d4c7f9e820'
down_revision = 'f17c4a8d2b90'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('commercial_request_lines', sa.Column('sample_indices_json', sa.Text(), nullable=False, server_default='[]'))

    with op.batch_alter_table('commercial_cases') as batch:
        batch.add_column(sa.Column('client_revision_open', sa.Boolean(), nullable=False, server_default=sa.false()))
        batch.add_column(sa.Column('client_revision_reason', sa.Text(), nullable=False, server_default=''))
        batch.add_column(sa.Column('client_revision_number', sa.Integer(), nullable=False, server_default='0'))
        batch.add_column(sa.Column('client_revision_opened_at', sa.DateTime(), nullable=True))
        batch.add_column(sa.Column('client_revision_opened_by_id', sa.Integer(), nullable=True))
        batch.add_column(sa.Column('client_resubmitted_at', sa.DateTime(), nullable=True))
        batch.create_foreign_key('fk_commercial_cases_client_revision_opened_by', 'users', ['client_revision_opened_by_id'], ['id'])
    op.create_index('ix_commercial_cases_client_revision_open', 'commercial_cases', ['client_revision_open'])
    op.create_index('ix_commercial_cases_client_revision_opened_by_id', 'commercial_cases', ['client_revision_opened_by_id'])

    op.add_column('planned_samples', sa.Column('form_sample_index', sa.Integer(), nullable=True))
    op.create_index('ix_planned_samples_form_sample_index', 'planned_samples', ['form_sample_index'])

    op.create_table(
        'client_sampling_data_forms',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('commercial_case_id', sa.Integer(), sa.ForeignKey('commercial_cases.id'), nullable=False),
        sa.Column('revision', sa.Integer(), nullable=False, server_default='1'),
        sa.Column('status', sa.String(length=30), nullable=False, server_default='DRAFT'),
        sa.Column('entry_method', sa.String(length=20), nullable=False, server_default='ONLINE'),
        sa.Column('source_attachment_id', sa.Integer(), sa.ForeignKey('commercial_attachments.id'), nullable=True),
        sa.Column('form_code', sa.String(length=80), nullable=False, server_default='QDF [7]-03-A'),
        sa.Column('source_revision', sa.String(length=40), nullable=False, server_default='03'),
        sa.Column('digital_revision', sa.String(length=40), nullable=False, server_default='UAT-01'),
        sa.Column('client_json', sa.Text(), nullable=False, server_default='{}'),
        sa.Column('asset_json', sa.Text(), nullable=False, server_default='{}'),
        sa.Column('sampling_json', sa.Text(), nullable=False, server_default='{}'),
        sa.Column('samples_json', sa.Text(), nullable=False, server_default='[]'),
        sa.Column('extraction_json', sa.Text(), nullable=False, server_default='{}'),
        sa.Column('generated_pdf_blob', sa.LargeBinary(), nullable=True),
        sa.Column('generated_pdf_sha256', sa.String(length=64), nullable=False, server_default=''),
        sa.Column('created_by_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('confirmed_by_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('confirmed_at', sa.DateTime(), nullable=True),
        sa.Column('locked_at', sa.DateTime(), nullable=True),
        sa.UniqueConstraint('commercial_case_id', 'revision', name='uq_client_sampling_data_form_revision'),
    )
    for name, cols in [
        ('ix_client_sampling_data_forms_commercial_case_id', ['commercial_case_id']),
        ('ix_client_sampling_data_forms_status', ['status']),
        ('ix_client_sampling_data_forms_entry_method', ['entry_method']),
        ('ix_client_sampling_data_forms_source_attachment_id', ['source_attachment_id']),
        ('ix_client_sampling_data_forms_generated_pdf_sha256', ['generated_pdf_sha256']),
        ('ix_client_sampling_data_forms_created_by_id', ['created_by_id']),
        ('ix_client_sampling_data_forms_confirmed_by_id', ['confirmed_by_id']),
        ('ix_client_sampling_data_forms_created_at', ['created_at']),
    ]:
        op.create_index(name, 'client_sampling_data_forms', cols)

    op.create_table(
        'sampling_discrepancies',
        sa.Column('id', sa.Integer(), primary_key=True),
        sa.Column('commercial_case_id', sa.Integer(), sa.ForeignKey('commercial_cases.id'), nullable=False),
        sa.Column('sampling_assignment_id', sa.Integer(), sa.ForeignKey('sampling_assignments.id'), nullable=False),
        sa.Column('planned_sample_id', sa.Integer(), sa.ForeignKey('planned_samples.id'), nullable=True),
        sa.Column('reported_by_id', sa.Integer(), sa.ForeignKey('users.id'), nullable=True),
        sa.Column('discrepancy_type', sa.String(length=80), nullable=False, server_default='FIELD_MISMATCH'),
        sa.Column('submitted_value', sa.Text(), nullable=False, server_default=''),
        sa.Column('observed_value', sa.Text(), nullable=False, server_default=''),
        sa.Column('note', sa.Text(), nullable=False, server_default=''),
        sa.Column('status', sa.String(length=30), nullable=False, server_default='OPEN'),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('CURRENT_TIMESTAMP')),
        sa.Column('resolved_at', sa.DateTime(), nullable=True),
    )
    for name, cols in [
        ('ix_sampling_discrepancies_commercial_case_id', ['commercial_case_id']),
        ('ix_sampling_discrepancies_sampling_assignment_id', ['sampling_assignment_id']),
        ('ix_sampling_discrepancies_planned_sample_id', ['planned_sample_id']),
        ('ix_sampling_discrepancies_reported_by_id', ['reported_by_id']),
        ('ix_sampling_discrepancies_discrepancy_type', ['discrepancy_type']),
        ('ix_sampling_discrepancies_status', ['status']),
        ('ix_sampling_discrepancies_created_at', ['created_at']),
    ]:
        op.create_index(name, 'sampling_discrepancies', cols)


def downgrade():
    for name in [
        'ix_sampling_discrepancies_created_at','ix_sampling_discrepancies_status','ix_sampling_discrepancies_discrepancy_type',
        'ix_sampling_discrepancies_reported_by_id','ix_sampling_discrepancies_planned_sample_id','ix_sampling_discrepancies_sampling_assignment_id',
        'ix_sampling_discrepancies_commercial_case_id',
    ]:
        op.drop_index(name, table_name='sampling_discrepancies')
    op.drop_table('sampling_discrepancies')
    for name in [
        'ix_client_sampling_data_forms_created_at','ix_client_sampling_data_forms_confirmed_by_id','ix_client_sampling_data_forms_created_by_id',
        'ix_client_sampling_data_forms_generated_pdf_sha256','ix_client_sampling_data_forms_source_attachment_id','ix_client_sampling_data_forms_entry_method',
        'ix_client_sampling_data_forms_status','ix_client_sampling_data_forms_commercial_case_id',
    ]:
        op.drop_index(name, table_name='client_sampling_data_forms')
    op.drop_table('client_sampling_data_forms')
    op.drop_index('ix_planned_samples_form_sample_index', table_name='planned_samples')
    op.drop_column('planned_samples', 'form_sample_index')
    op.drop_index('ix_commercial_cases_client_revision_opened_by_id', table_name='commercial_cases')
    op.drop_index('ix_commercial_cases_client_revision_open', table_name='commercial_cases')
    with op.batch_alter_table('commercial_cases') as batch:
        batch.drop_constraint('fk_commercial_cases_client_revision_opened_by', type_='foreignkey')
        for col in ['client_resubmitted_at','client_revision_opened_by_id','client_revision_opened_at','client_revision_number','client_revision_reason','client_revision_open']:
            batch.drop_column(col)
    op.drop_column('commercial_request_lines', 'sample_indices_json')
