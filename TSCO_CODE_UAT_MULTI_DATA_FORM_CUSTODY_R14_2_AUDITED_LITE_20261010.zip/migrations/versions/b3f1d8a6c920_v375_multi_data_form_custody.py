"""v3.7.5 multi Data Form / sample custody alignment

Revision ID: b3f1d8a6c920
Revises: a1d4c7f9e820
Create Date: 2026-10-10
"""
from alembic import op
import sqlalchemy as sa

revision = 'b3f1d8a6c920'
down_revision = 'a1d4c7f9e820'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('client_sampling_data_forms', sa.Column('forms_json', sa.Text(), nullable=False, server_default='[]'))


def downgrade():
    op.drop_column('client_sampling_data_forms', 'forms_json')
