from datetime import datetime
from io import BytesIO
from pathlib import Path

from pypdf import PdfReader
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.database import Base
from app.models import Asset, Client, ClientSamplingDataForm, CommercialCase, CommercialRequestLine, SampleRequest, SampleStatus, Site, User
from app.routes.intake import _internal_custody_rows
from app.services.planned_samples import ensure_planned_samples
from app.services.sampling_data_form import (
    all_forms_confirmed,
    data_form_forms,
    data_form_payload,
    internal_priority,
    render_pdf_bytes,
    sample_count,
    sample_rows_by_index,
    update_form_payload,
)

ROOT = Path(__file__).resolve().parents[1]


def _base(db: Session):
    site = Site(code="DMM", name="Dammam", laboratory_name="TSCO Analytical Lab", active=True)
    client = Client(code="UAT", name="UAT Client", active=True)
    db.add_all([site, client]); db.flush()
    user = User(email="multi-form@example.local", password_hash="x", full_name="Client UAT", role="client", active=True, site_id=site.id, client_id=client.id)
    db.add(user); db.flush()
    case = CommercialCase(
        case_code="BC-DMM-2026-9750", site_id=site.id, client_id=client.id, owner_id=user.id,
        current_stage="COMPLETE_HANDOVER", status="ACTIVE", request_source="CLIENT_PORTAL", request_status="HANDOVER_COMPLETE",
        sample_delivery_mode="TSCO_ONSITE_SAMPLING", sales_order_number="TIC-SO4-UAT-9750",
    )
    db.add(case); db.flush()
    form = ClientSamplingDataForm(commercial_case_id=case.id, revision=1, status="DRAFT", entry_method="ONLINE", created_by_id=user.id)
    db.add(form); db.flush()
    return site, client, user, case, form


def _multi_form_fixture(db: Session):
    site, client, user, case, form = _base(db)
    update_form_payload(
        form, 1,
        client={"company_name": client.name},
        asset={"serial_number":"TR-A","tag_number":"UNIT-A","manufacturer_name":"MFR-A"},
        sampling={"test_priority":"Normal", "sampling_date_time":"2026-10-10 08:00", "reason_of_sampling":"Routine"},
        samples=[
            {"sampling_from":"Bottom Tank"},
            {"sampling_from":"Tap Changer","tap_changer_position":"H1"},
            {"sampling_from":"Tap Changer","tap_changer_position":"H2"},
            {"sampling_from":"Tap Changer","tap_changer_position":"H3"},
        ], actor=user, confirm=True,
    )
    update_form_payload(
        form, 2,
        client={"company_name": client.name},
        asset={"serial_number":"TR-B","tag_number":"UNIT-B","manufacturer_name":"MFR-B"},
        sampling={"test_priority":"Emergency", "sampling_date_time":"2026-10-10 09:30", "reason_of_sampling":"Emergency check"},
        samples=[{"sampling_from":"Top Tank"}], actor=user, confirm=True,
    )
    line1 = CommercialRequestLine(
        commercial_case_id=case.id, line_number=1, quantity=4, requested_package="Routine Test", requested_tests_json="[]",
        expected_serials_json="[]", sample_indices_json="[1,2,3,4]", method_family="DEFAULT", priority="NORMAL", required_tat="", status="ACTIVE", created_by_id=user.id,
    )
    line2 = CommercialRequestLine(
        commercial_case_id=case.id, line_number=2, quantity=1, requested_package="Routine Test", requested_tests_json="[]",
        expected_serials_json="[]", sample_indices_json="[5]", method_family="DEFAULT", priority="URGENT", required_tat="12H", status="ACTIVE", created_by_id=user.id,
    )
    db.add_all([line1, line2]); db.flush()
    return site, client, user, case, form, line1, line2


def test_request_supports_multiple_transformer_forms_and_multiple_samples_per_transformer():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        _, _, _, _, form, _, _ = _multi_form_fixture(db)
        forms = data_form_forms(form)
        assert len(forms) == 2
        assert all_forms_confirmed(form)
        assert sample_count(form) == 5
        rows = sample_rows_by_index(form)
        assert [(rows[i]["form_number"], rows[i]["serial_number"]) for i in range(1, 6)] == [
            (1,"TR-A"),(1,"TR-A"),(1,"TR-A"),(1,"TR-A"),(2,"TR-B")
        ]
        assert [rows[i]["sampling_point_label"] for i in range(1,6)] == [
            "Bottom Tank", "Tap Changer — H1", "Tap Changer — H2", "Tap Changer — H3", "Top Tank"
        ]
        assert rows[1]["sampling_date_time"] == "2026-10-10 08:00"
        assert rows[5]["sampling_date_time"] == "2026-10-10 09:30"
        assert internal_priority(form) == "URGENT"


def test_controlled_handover_creates_one_stable_identity_barcode_per_physical_sample_across_all_forms():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        _, _, _, case, form, _, _ = _multi_form_fixture(db)
        planned = ensure_planned_samples(db, case)
        assert len(planned) == 5
        assert len({p.request_number for p in planned}) == 5
        assert len({p.barcode_value for p in planned}) == 5
        by_index = {p.form_sample_index:p for p in planned}
        assert [by_index[i].expected_serial_number for i in range(1,6)] == ["TR-A","TR-A","TR-A","TR-A","TR-B"]
        assert [by_index[i].sampling_point for i in range(1,6)] == [
            "Bottom Tank", "Tap Changer — H1", "Tap Changer — H2", "Tap Changer — H3", "Top Tank"
        ]
        raw = render_pdf_bytes(db, form, case)
        text = "\n".join((p.extract_text() or "") for p in PdfReader(BytesIO(raw)).pages)
        assert text.count("Sampling Data Form") >= 2
        assert "TR-A" in text and "TR-B" in text
        assert "Tap Changer — H1" in text and "Tap Changer — H2" in text and "Tap Changer — H3" in text
        assert "Sample Identification & Barcode Schedule" in text
        assert all(p.request_number in text for p in planned)


def test_paper_ui_exposes_real_form_choices_and_multi_form_controls_without_duplicate_serial_scope_entry():
    tpl = (ROOT / "app/templates/client_request.html").read_text(encoding="utf-8")
    css = (ROOT / "app/static/styles.css").read_text(encoding="utf-8")
    route = (ROOT / "app/routes/client.py").read_text(encoding="utf-8")
    assert "Fill Data Form Online" in tpl and "Upload Existing Data Form" in tpl and "+ New Data Form" in tpl
    assert "paper-choice-group" in tpl and "paper-box" in tpl and ".paper-choice" in css
    assert "tapPositions" in tpl and "H1" not in tpl  # controlled options are injected from service constant, not duplicated in HTML
    assert 'TAP_CHANGER_POSITIONS = ["H1", "H2", "H3", "Other"]' in (ROOT / "app/services/sampling_data_form.py").read_text(encoding="utf-8")
    for field in ("sealing_system", "cooling_type", "tap_changer_type", "tap_changer_chamber", "unit_in_service", "test_priority", "sampling_from"):
        assert field in tpl
    assert "Transformer Serial Number(s)" not in tpl and 'name="expected_serials"' not in tpl
    assert "Confirm every Sampling Data Form before adding Service Scope" in route
    assert "Every physical sample in the Sampling Data Form must have exactly one Service Scope" in route
    assert "packageInfoButton" in tpl and "PACKAGE CONTENT" in tpl


def test_internal_custody_stage_appends_received_and_storage_metadata_to_same_identity_without_new_barcode():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        site = Site(code="DMM", name="Dammam", laboratory_name="TSCO Analytical Lab", active=True)
        client = Client(code="UAT", name="UAT Client", active=True)
        db.add_all([site, client]); db.flush()
        asset = Asset(client_id=client.id, asset_code="UAT-TR-A", serial_number="TR-A", station_name="UAT", active=True)
        db.add(asset); db.flush()
        sample = SampleRequest(
            request_number="FS-DMM-26-009999", public_token="PUB-009999", barcode_value="TSCO-BC-009999",
            status=SampleStatus.READY_FOR_LAB.value, site_id=site.id, client_id=client.id, asset_id=asset.id,
            sample_date_time=datetime(2026,10,10,8,0), sampling_point="Tap Changer — H2", requested_package="Routine Test",
            lms_number="LAB-009999", received_at=datetime(2026,10,10,10,15),
        )
        db.add(sample); db.flush()
        before_barcode = sample.barcode_value
        rows = _internal_custody_rows([sample], {"storageAssignments":[{
            "sample":"LAB-009999", "row":1, "cabinet":1, "shelf":"A", "slot":4,
            "code":"R1-C01-A-04", "status":"Reserved", "assigned_at":"2026-10-10T10:30:00",
        }]})
        assert rows == [{
            "sample_id":"FS-DMM-26-009999", "barcode":"TSCO-BC-009999", "serial_number":"TR-A",
            "sample_type":"Tap Changer — H2", "received_at":datetime(2026,10,10,10,15),
            "storage_code":"R1-C01-A-04", "storage_status":"Reserved", "sample_status":SampleStatus.READY_FOR_LAB.value,
        }]
        assert sample.barcode_value == before_barcode
        tpl = (ROOT / "app/templates/intake_queue.html").read_text(encoding="utf-8")
        assert "INTERNAL SAMPLE CUSTODY · TSCO ONLY" in tpl
        assert "no second barcode or sample identity is created" in tpl
        assert "Storage Location" in tpl and "Received At" in tpl


def test_existing_storage_map_and_retention_controls_remain_present():
    html = (ROOT / "app/lab_ops/index_template.html").read_text(encoding="utf-8")
    assert "function storageSlots()" in html
    assert "function reserveStorage(sample)" in html
    assert "function activateRetention(sample)" in html
    assert "normalRetentionDays:14" in html
    assert "Row ${row}" in html and "Cabinet ${String(a.cabinet).padStart(2,'0')}" in html


def test_client_can_build_one_request_with_two_transformer_forms_and_five_physical_samples_then_submit_locked():
    from uuid import uuid4
    from fastapi.testclient import TestClient
    from sqlalchemy import select
    from app.main import app
    from app.database import SessionLocal
    from app.models import CommercialCase, ClientSamplingDataForm, CommercialRequestLine

    token = uuid4().hex[:6].upper()
    with TestClient(app) as browser:
        assert browser.post('/login', data={'email':'client@sec.local','password':'Demo123!'}, follow_redirects=False).status_code == 303
        r = browser.post('/client/requests', data={
            'lead_title':f'Multi Data Form {token}', 'sample_delivery_mode':'TSCO_ONSITE_SAMPLING', 'sample_delivery_notes':'UAT only'
        }, follow_redirects=False)
        assert r.status_code == 303
        case_id = int(r.headers['location'].rstrip('/').split('/')[-1])

        r = browser.post(f'/client/requests/{case_id}/data-forms/new', follow_redirects=False)
        assert r.status_code == 303
        first = {
            'company_name':'Saudi Electricity Company (SEC)', 'serial_number':f'TR-A-{token}', 'tag_number':'UNIT-A',
            'number_of_samples':'4', 'test_priority':'Normal', 'unit_in_service':'Yes',
            'sampling_from_1':'Bottom Tank',
            'sampling_from_2':'Tap Changer','tap_changer_position_2':'H1',
            'sampling_from_3':'Tap Changer','tap_changer_position_3':'H2',
            'sampling_from_4':'Tap Changer','tap_changer_position_4':'H3',
        }
        assert browser.post(f'/client/requests/{case_id}/data-forms/1', data=first, follow_redirects=False).status_code == 303

        r = browser.post(f'/client/requests/{case_id}/data-forms/new', follow_redirects=False)
        assert r.status_code == 303
        second = {
            'company_name':'Saudi Electricity Company (SEC)', 'serial_number':f'TR-B-{token}', 'tag_number':'UNIT-B',
            'number_of_samples':'1', 'test_priority':'Emergency', 'unit_in_service':'Yes',
            'sampling_from_1':'Top Tank',
        }
        assert browser.post(f'/client/requests/{case_id}/data-forms/2', data=second, follow_redirects=False).status_code == 303

        page = browser.get(f'/client/requests/{case_id}')
        assert page.status_code == 200
        assert f'TR-A-{token}' in page.text and f'TR-B-{token}' in page.text
        assert '5' in page.text and 'Tap Changer — H1' in page.text and 'Tap Changer — H3' in page.text
        assert page.text.count('Data Form confirmed') >= 2

        assert browser.post(f'/client/requests/{case_id}/lines', data={
            'requested_package':'Routine Test','method_family':'DEFAULT','required_tat':'','due_at':'',
            'sample_indices':['1','2','3','4'],
        }, follow_redirects=False).status_code == 303
        assert browser.post(f'/client/requests/{case_id}/lines', data={
            'requested_package':'Routine Test','method_family':'DEFAULT','required_tat':'12H','due_at':'',
            'sample_indices':['5'],
        }, follow_redirects=False).status_code == 303
        assert browser.post(f'/client/requests/{case_id}/submit', data={'client_message':'Ready'}, follow_redirects=False).status_code == 303

        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case
            form = db.scalar(select(ClientSamplingDataForm).where(ClientSamplingDataForm.commercial_case_id==case_id).order_by(ClientSamplingDataForm.revision.desc())); assert form
            lines = list(db.scalars(select(CommercialRequestLine).where(CommercialRequestLine.commercial_case_id==case_id, CommercialRequestLine.status=='ACTIVE').order_by(CommercialRequestLine.line_number)).all())
            assert case.expected_samples == 5 and case.default_priority == 'URGENT' and case.request_status == 'RECEIVED'
            assert form.status == 'LOCKED' and len(data_form_forms(form)) == 2 and sample_count(form) == 5
            assert [line.sample_indices_json for line in lines] == ['[1, 2, 3, 4]','[5]']
            assert [line.priority for line in lines] == ['NORMAL','URGENT']

def test_four_different_transformers_can_each_contribute_one_physical_sample_to_one_request():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        _, client, user, case, form = _base(db)
        points = ["Bottom Tank", "Top Tank", "Buchholz Relay", "Tap Changer"]
        for n in range(1, 5):
            sample = {"sampling_from": points[n-1]}
            if points[n-1] == "Tap Changer":
                sample["tap_changer_position"] = "H1"
            update_form_payload(
                form, n,
                client={"company_name": client.name},
                asset={"serial_number": f"TR-{n}", "tag_number": f"UNIT-{n}"},
                sampling={"test_priority": "Normal"},
                samples=[sample], actor=user, confirm=True,
            )
        assert len(data_form_forms(form)) == 4
        assert sample_count(form) == 4
        rows = sample_rows_by_index(form)
        assert [rows[i]["serial_number"] for i in range(1, 5)] == ["TR-1", "TR-2", "TR-3", "TR-4"]
        for n in range(1, 5):
            db.add(CommercialRequestLine(
                commercial_case_id=case.id, line_number=n, quantity=1, requested_package="Routine Test",
                requested_tests_json="[]", expected_serials_json="[]", sample_indices_json=f"[{n}]",
                method_family="DEFAULT", priority="NORMAL", required_tat="", status="ACTIVE", created_by_id=user.id,
            ))
        db.flush()
        planned = ensure_planned_samples(db, case)
        assert len(planned) == 4
        assert len({p.request_number for p in planned}) == 4
        assert len({p.barcode_value for p in planned}) == 4
        assert [p.expected_serial_number for p in planned] == ["TR-1", "TR-2", "TR-3", "TR-4"]
