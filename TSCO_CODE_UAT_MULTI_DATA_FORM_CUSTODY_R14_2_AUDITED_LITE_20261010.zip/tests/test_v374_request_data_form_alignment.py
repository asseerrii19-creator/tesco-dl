from pathlib import Path

from pypdf import PdfReader
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from app.database import Base
from app.models import Client, ClientSamplingDataForm, CommercialCase, CommercialRequestLine, Site, User
from app.services.planned_samples import ensure_planned_samples
from app.services.sampling_data_form import data_form_payload, internal_priority, refresh_pdf, save_payload

ROOT = Path(__file__).resolve().parents[1]


def _fixture(db: Session):
    site = Site(code='DMM', name='Dammam', laboratory_name='TSCO Analytical Lab', active=True)
    client = Client(code='SEC', name='Saudi Electricity Company', active=True)
    db.add_all([site, client]); db.flush()
    user = User(email='client-test@example.local', password_hash='x', full_name='Client Test', role='client', active=True, site_id=site.id, client_id=client.id)
    db.add(user); db.flush()
    case = CommercialCase(case_code='BC-DMM-2026-9998', site_id=site.id, client_id=client.id, owner_id=user.id,
                          current_stage='COMPLETE_HANDOVER', status='ACTIVE', request_source='CLIENT_PORTAL', request_status='HANDOVER_COMPLETE',
                          sample_delivery_mode='TSCO_ONSITE_SAMPLING', sales_order_number='TIC-SO4-UAT-9998')
    db.add(case); db.flush()
    form = ClientSamplingDataForm(commercial_case_id=case.id, revision=1, status='DRAFT', entry_method='ONLINE', created_by_id=user.id)
    db.add(form); db.flush()
    save_payload(form,
        client={'company_name': client.name},
        asset={'serial_number':'TR-REAL-001','tag_number':'UNIT-3','manufacturer_name':'MITSUBISHI','substation':'POWER PLANT','location':'UNIT YARD','cooling_type':'Other','cooling_type_other':'ODAF'},
        sampling={'test_priority':'Emergency','reason_of_sampling':'Client request'},
        samples=[{'index':1,'sampling_from':'Bottom Tank'},{'index':2,'sampling_from':'Top Tank'},{'index':3,'sampling_from':'Other','sampling_from_other':'Radiator valve'}],
        actor=user, confirm=True)
    line = CommercialRequestLine(commercial_case_id=case.id, line_number=1, quantity=3, requested_package='Routine Test',
                                 requested_tests_json='[]', expected_serials_json='[]', sample_indices_json='[1,2,3]', method_family='DEFAULT',
                                 priority='URGENT', required_tat='24H', status='ACTIVE', created_by_id=user.id)
    db.add(line); db.flush()
    return site, client, user, case, form, line


def test_real_data_form_is_source_for_count_priority_serial_sampling_points_and_barcode_pdf(tmp_path, monkeypatch):
    engine = create_engine('sqlite:///:memory:')
    Base.metadata.create_all(engine)
    with Session(engine) as db:
        _, _, _, case, form, _ = _fixture(db)
        assert len(data_form_payload(form)['samples']) == 3
        assert internal_priority(form) == 'URGENT'
        rows = ensure_planned_samples(db, case)
        assert len(rows) == 3
        assert [r.form_sample_index for r in rows] == [1,2,3]
        assert [r.expected_serial_number for r in rows] == ['TR-REAL-001'] * 3
        assert [r.sampling_point for r in rows] == ['Bottom Tank','Top Tank','Other: Radiator valve']
        raw = refresh_pdf(db, form, case)
        assert raw.startswith(b'%PDF-')
        text = '\n'.join((p.extract_text() or '') for p in PdfReader(__import__('io').BytesIO(raw)).pages)
        assert 'Sampling Data Form' in text
        assert 'Number of Samples' in text
        assert 'TR-REAL-001' in text
        assert 'ODAF' in text and 'Radiator valve' in text
        assert 'Sample Identification & Barcode Schedule' in text
        assert all(r.request_number in text for r in rows)


def test_client_request_ui_has_real_paper_form_and_no_manual_transformer_serial_scope_entry():
    tpl = (ROOT/'app/templates/client_request.html').read_text(encoding='utf-8')
    route = (ROOT/'app/routes/client.py').read_text(encoding='utf-8')
    css = (ROOT/'app/static/styles.css').read_text(encoding='utf-8')
    assert 'Sampling Data Form' in tpl and 'QDF [7]-03-A' not in tpl  # code is injected from controlled constant
    assert 'Upload Existing Data Form' in tpl and 'Fill Data Form Online' in tpl
    assert 'Number of Samples' in tpl and 'sampling_from' in tpl
    assert 'Transformer Serial Number(s)' not in tpl
    assert 'name="expected_serials"' not in tpl
    assert 'packageInfoButton' in tpl and 'PACKAGE CONTENT' in tpl
    assert 'data-form-paper' in tpl and '.data-form-paper' in css
    assert 'Every physical sample in the Sampling Data Form must have exactly one Service Scope' in route
    assert 'assigned Coordinator must reopen' in route
    assert 'Data Form confirmed' in tpl and 'Edit Data Form' in tpl


def test_submitted_client_data_is_client_owned_and_coordinator_reopens_instead_of_editing():
    commercial = (ROOT/'app/routes/commercial.py').read_text(encoding='utf-8')
    field = (ROOT/'app/routes/field.py').read_text(encoding='utf-8')
    field_tpl = (ROOT/'app/templates/field_new.html').read_text(encoding='utf-8')
    assert '/reopen-client-request' in commercial
    assert 'Only the assigned Client Coordinator can reopen this request' in commercial
    assert 'Client-owned request scope cannot be edited by TSCO' in commercial
    assert 'SAMPLING_FIELD_MISMATCH_REPORTED' in field
    assert 'SamplingDiscrepancy' in field
    assert 'Report Mismatch — Do Not Sample' in field_tpl
    assert 'Accept Match & Complete Sampling' in field_tpl
    assert 'APPROVED CLIENT DATA' in field_tpl



def test_client_request_runtime_flow_locks_data_form_and_coordinator_reopens_for_client_revision():
    from uuid import uuid4
    from fastapi.testclient import TestClient
    from sqlalchemy import select
    from app.main import app
    from app.database import SessionLocal
    from app.models import CommercialCase, ClientSamplingDataForm, CommercialRequestLine, User

    token = uuid4().hex[:8].upper()
    with TestClient(app) as browser:
        r = browser.post('/login', data={'email':'client@sec.local','password':'Demo123!'}, follow_redirects=False)
        assert r.status_code == 303
        r = browser.post('/client/requests', data={
            'lead_title': f'Real Data Form {token}', 'client_message':'',
            'sample_delivery_mode':'TSCO_ONSITE_SAMPLING', 'sample_delivery_notes':'UAT site',
        }, follow_redirects=False)
        assert r.status_code == 303
        case_id = int(r.headers['location'].rstrip('/').split('/')[-1])
        payload = {
            'company_name':'Saudi Electricity Company (SEC)', 'serial_number':f'TR-{token}', 'tag_number':'UNIT 3',
            'voltage_rating_hv_lv':'380 / 21 kV', 'rated_power_mva':'140 MVA', 'manufacturer_name':'MITSUBISHI',
            'manufacture_year':'2009', 'country_of_manufacture':'Japan', 'substation':'UAT Power Plant', 'location':'Dammam',
            'sealing_system':'Conservator with Bladder', 'cooling_type':'Other', 'cooling_type_other':'ODAF',
            'tap_changer_type':'On-load', 'tap_changer_chamber':'Connected', 'number_of_samples':'2',
            'sampling_from':['Bottom Tank','Other'], 'sampling_from_other':['','Radiator valve'],
            'unit_in_service':'Yes', 'reason_of_sampling':'Routine condition assessment', 'test_priority':'Emergency',
        }
        r = browser.post(f'/client/requests/{case_id}/data-form', data=payload, follow_redirects=False)
        assert r.status_code == 303
        page = browser.get(f'/client/requests/{case_id}')
        assert page.status_code == 200
        assert 'data-form-paper' in page.text
        assert 'Transformer Serial Number(s)' not in page.text
        assert 'packageInfoButton' in page.text
        # Save & Confirm returns to a paper/read-only Data Form view while the overall request is still a draft.
        assert 'Data Form confirmed' in page.text
        assert 'Edit Data Form' in page.text
        assert 'data-editable="0"' in page.text
        assert 'ODAF' in page.text
        assert 'Radiator valve' in page.text
        # Explicit draft edit mode reopens the same paper form; request submission is the hard ownership lock.
        edit_page = browser.get(f'/client/requests/{case_id}?edit_data_form=1')
        assert edit_page.status_code == 200
        assert 'Save & Confirm Data Form' in edit_page.text
        assert 'Other — specify' in edit_page.text
        assert 'data-editable="1"' in edit_page.text
        assert '"sampling_from": "Bottom Tank"' in edit_page.text
        assert '"sampling_from_other": "Radiator valve"' in edit_page.text

        r = browser.post(f'/client/requests/{case_id}/lines', data={
            'requested_package':'Routine Test', 'method_family':'DEFAULT', 'required_tat':'24H', 'due_at':'',
            'sample_indices':['1','2'],
        }, follow_redirects=False)
        assert r.status_code == 303
        r = browser.post(f'/client/requests/{case_id}/submit', data={'client_message':'Ready'}, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case
            form = db.scalar(select(ClientSamplingDataForm).where(ClientSamplingDataForm.commercial_case_id==case_id).order_by(ClientSamplingDataForm.revision.desc())); assert form
            line = db.scalar(select(CommercialRequestLine).where(CommercialRequestLine.commercial_case_id==case_id)); assert line
            coordinator = db.get(User, case.assigned_coordinator_id); assert coordinator
            assert (case.request_status, case.expected_samples, case.default_priority) == ('RECEIVED', 2, 'URGENT')
            assert form.status == 'LOCKED' and form.generated_pdf_blob
            assert line.sample_indices_json == '[1, 2]' and line.expected_serials_json == '[]' and line.priority == 'URGENT'
            coordinator_email = coordinator.email

        # Submitted client data is not editable until the assigned Coordinator reopens it.
        r = browser.post(f'/client/requests/{case_id}/logistics', data={'sample_delivery_mode':'CLIENT_DELIVERY'}, follow_redirects=False)
        assert r.status_code == 400
        browser.post('/logout')
        assert browser.post('/login', data={'email':coordinator_email,'password':'Demo123!'}, follow_redirects=False).status_code == 303
        r = browser.post(f'/commercial/cases/{case_id}/reopen-client-request', data={'reason':'Field identity mismatch — client correction required'}, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case and case.client_revision_open and case.client_revision_number == 1

        browser.post('/logout')
        assert browser.post('/login', data={'email':'client@sec.local','password':'Demo123!'}, follow_redirects=False).status_code == 303
        corrected = dict(payload)
        corrected['serial_number'] = f'TR-{token}-CORRECTED'
        r = browser.post(f'/client/requests/{case_id}/data-form', data=corrected, follow_redirects=False)
        assert r.status_code == 303
        r = browser.post(f'/client/requests/{case_id}/submit', data={'client_message':'Corrected and resubmitted'}, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case and not case.client_revision_open
            forms = list(db.scalars(select(ClientSamplingDataForm).where(ClientSamplingDataForm.commercial_case_id==case_id).order_by(ClientSamplingDataForm.revision)).all())
            assert [(x.revision, x.status) for x in forms][-2:] == [(1, 'SUPERSEDED'), (2, 'LOCKED')]


def test_existing_scan_upload_is_preserved_as_evidence_and_never_claimed_as_parsed_handwriting(tmp_path):
    import io
    from fastapi.testclient import TestClient
    from PIL import Image
    from sqlalchemy import select
    from app.main import app
    from app.database import SessionLocal
    from app.models import ClientSamplingDataForm, CommercialAttachment

    image = Image.new('RGB', (120, 160), 'white')
    buf = io.BytesIO(); image.save(buf, format='JPEG'); raw = buf.getvalue()
    with TestClient(app) as browser:
        assert browser.post('/login', data={'email':'client@sec.local','password':'Demo123!'}, follow_redirects=False).status_code == 303
        r = browser.post('/client/requests', data={'lead_title':'Scan upload evidence','sample_delivery_mode':'CLIENT_DELIVERY'}, follow_redirects=False)
        case_id = int(r.headers['location'].rstrip('/').split('/')[-1])
        r = browser.post(f'/client/requests/{case_id}/attachments', files={'upload':('sampling-form.jpg', raw, 'image/jpeg')}, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            form = db.scalar(select(ClientSamplingDataForm).where(ClientSamplingDataForm.commercial_case_id==case_id)); assert form
            source = db.get(CommercialAttachment, form.source_attachment_id); assert source
            assert form.entry_method == 'UPLOAD' and form.status == 'DRAFT'
            assert source.content_blob == raw and source.sha256
            assert '"source_kind": "SCAN_OR_IMAGE"' in form.extraction_json
            assert '"review_required": true' in form.extraction_json
