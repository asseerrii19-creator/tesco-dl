from __future__ import annotations

import copy
import hashlib
import io
import json
import re
from datetime import datetime
from typing import Any

from reportlab.graphics.barcode import code128
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..models import ClientSamplingDataForm, CommercialCase, PlannedSample, User
from .client_data_form import extract_pdf_text, parse_client_data_form

FORM_CODE = "QDF [7]-03-A"
SOURCE_REVISION = "03"
DIGITAL_REVISION = "UAT-02"
SAMPLING_POINTS = [
    "Bottom Tank", "Top Tank", "Buchholz Relay", "Tap Changer",
    "Cable Box", "Bushings", "Conservator", "Other",
]
# User-confirmed operational refinement for Tap Changer physical samples.
TAP_CHANGER_POSITIONS = ["H1", "H2", "H3", "Other"]
SEALING_SYSTEMS = [
    "Conservator with Bladder", "Hermetical", "Free Breathing (No Bladder in Conservator)",
    "Conservator with Diaphragm", "Pressurized N2", "Other",
]
COOLING_TYPES = ["ONAN", "ONAF", "OFAF", "Other"]
TAP_CHANGER_TYPES = ["On-load", "Off-load", "Other"]
TAP_CHANGER_CHAMBERS = ["Connected", "Not Connected"]
UNIT_IN_SERVICE = ["Yes", "No (New)", "No (De-energized)", "Other"]
TEST_PRIORITIES = ["Normal", "Emergency"]


def _loads(value: str | None, fallback: Any) -> Any:
    try:
        return json.loads(value or "")
    except Exception:
        return fallback


def _text(value: Any, limit: int = 500) -> str:
    return str(value or "").strip()[:limit]


def _clean_samples(samples: Any) -> list[dict[str, Any]]:
    if not isinstance(samples, list):
        return []
    out: list[dict[str, Any]] = []
    for pos, raw in enumerate(samples, start=1):
        if not isinstance(raw, dict):
            continue
        item = dict(raw)
        item["index"] = pos
        point = _text(item.get("sampling_from"), 100)
        if point not in SAMPLING_POINTS:
            point = "Other" if point else ""
            if point == "Other" and not item.get("sampling_from_other"):
                item["sampling_from_other"] = _text(raw.get("sampling_from"), 240)
        item["sampling_from"] = point
        if point != "Other":
            item["sampling_from_other"] = ""
        position = _text(item.get("tap_changer_position"), 40)
        if point != "Tap Changer":
            position = ""
            item["tap_changer_position_other"] = ""
        elif position and position not in TAP_CHANGER_POSITIONS:
            item["tap_changer_position"] = "Other"
            item["tap_changer_position_other"] = position
            position = "Other"
        item["tap_changer_position"] = position
        if position != "Other":
            item["tap_changer_position_other"] = ""
        out.append(item)
    return out


def _legacy_form(row: ClientSamplingDataForm) -> dict[str, Any]:
    status = "CONFIRMED" if row.status in {"CONFIRMED", "LOCKED"} else "DRAFT"
    return {
        "form_number": 1,
        "status": status,
        "entry_method": row.entry_method or "ONLINE",
        "source_attachment_id": row.source_attachment_id,
        "client": _loads(row.client_json, {}),
        "asset": _loads(row.asset_json, {}),
        "sampling": _loads(row.sampling_json, {}),
        "samples": _clean_samples(_loads(row.samples_json, [])),
        "extraction": _loads(row.extraction_json, {}),
    }


def data_form_forms(row: ClientSamplingDataForm | None) -> list[dict[str, Any]]:
    """Return the active request's ordered Data Form sheets.

    v3.7.5 stores multiple transformer forms in ``forms_json``. For databases upgraded from
    v3.7.4, the old single-form columns are losslessly projected as Data Form 1.
    """
    if not row:
        return []
    forms = _loads(getattr(row, "forms_json", "[]"), [])
    if not isinstance(forms, list) or not forms:
        return [_legacy_form(row)]
    out: list[dict[str, Any]] = []
    for pos, raw in enumerate(forms, start=1):
        if not isinstance(raw, dict):
            continue
        form = copy.deepcopy(raw)
        form["form_number"] = pos
        form["status"] = "CONFIRMED" if str(form.get("status") or "").upper() in {"CONFIRMED", "LOCKED"} else "DRAFT"
        form["entry_method"] = str(form.get("entry_method") or "ONLINE").upper()
        form["client"] = form.get("client") if isinstance(form.get("client"), dict) else {}
        form["asset"] = form.get("asset") if isinstance(form.get("asset"), dict) else {}
        form["sampling"] = form.get("sampling") if isinstance(form.get("sampling"), dict) else {}
        form["samples"] = _clean_samples(form.get("samples"))
        form["extraction"] = form.get("extraction") if isinstance(form.get("extraction"), dict) else {}
        out.append(form)
    return out or [_legacy_form(row)]


def _store_forms(row: ClientSamplingDataForm, forms: list[dict[str, Any]]) -> None:
    normalized: list[dict[str, Any]] = []
    for pos, raw in enumerate(forms, start=1):
        form = copy.deepcopy(raw)
        form["form_number"] = pos
        form["samples"] = _clean_samples(form.get("samples"))
        normalized.append(form)
    row.forms_json = json.dumps(normalized, ensure_ascii=False)
    # Keep the original v3.7.4 columns mirrored to Data Form 1 so older read paths remain safe.
    first = normalized[0] if normalized else {"client": {}, "asset": {}, "sampling": {}, "samples": [], "extraction": {}}
    row.client_json = json.dumps(first.get("client", {}), ensure_ascii=False)
    row.asset_json = json.dumps(first.get("asset", {}), ensure_ascii=False)
    row.sampling_json = json.dumps(first.get("sampling", {}), ensure_ascii=False)
    row.samples_json = json.dumps(first.get("samples", []), ensure_ascii=False)
    row.extraction_json = json.dumps(first.get("extraction", {}), ensure_ascii=False)
    row.entry_method = str(first.get("entry_method") or row.entry_method or "ONLINE")
    row.source_attachment_id = first.get("source_attachment_id")
    if normalized and all(str(f.get("status") or "").upper() == "CONFIRMED" for f in normalized):
        row.status = "CONFIRMED"
    else:
        row.status = "DRAFT"
    row.updated_at = datetime.utcnow()


def current_data_form(db: Session, case_id: int) -> ClientSamplingDataForm | None:
    return db.scalar(
        select(ClientSamplingDataForm)
        .where(ClientSamplingDataForm.commercial_case_id == case_id, ClientSamplingDataForm.status != "SUPERSEDED")
        .order_by(ClientSamplingDataForm.revision.desc(), ClientSamplingDataForm.id.desc())
    )


def data_form_payload(row: ClientSamplingDataForm | None) -> dict[str, Any]:
    forms = data_form_forms(row)
    if not forms:
        return {"client": {}, "asset": {}, "sampling": {}, "samples": [], "forms": [], "extraction": {}}
    flattened: list[dict[str, Any]] = []
    request_index = 0
    for form in forms:
        asset = form.get("asset", {})
        sampling = form.get("sampling", {})
        for local_pos, sample in enumerate(form.get("samples", []), start=1):
            request_index += 1
            item = copy.deepcopy(sample)
            item.update({
                "index": request_index,
                "request_index": request_index,
                "local_index": local_pos,
                "form_number": int(form.get("form_number") or 1),
                "serial_number": _text(asset.get("serial_number"), 120),
                "tag_number": _text(asset.get("tag_number"), 100),
                "test_priority": _text(sampling.get("test_priority"), 30) or "Normal",
                "sampling_date_time": _text(sampling.get("sampling_date_time"), 80),
                "reason_of_sampling": _text(sampling.get("reason_of_sampling"), 240),
                "unit_oil_temperature_c": _text(sampling.get("unit_oil_temperature_c"), 40),
                "ambient_temperature_c": _text(sampling.get("ambient_temperature_c"), 40),
                "ambient_humidity_pct": _text(sampling.get("ambient_humidity_pct"), 40),
                "winding_temperature_c": _text(sampling.get("winding_temperature_c"), 40),
                "form_status": form.get("status") or "DRAFT",
            })
            flattened.append(item)
    first = forms[0]
    return {
        "client": first.get("client", {}), "asset": first.get("asset", {}), "sampling": first.get("sampling", {}),
        "samples": flattened, "forms": forms, "extraction": first.get("extraction", {}),
    }


def sample_count(row: ClientSamplingDataForm | None) -> int:
    return len(data_form_payload(row).get("samples", [])) if row else 0


def all_forms_confirmed(row: ClientSamplingDataForm | None) -> bool:
    forms = data_form_forms(row)
    return bool(forms) and all(str(f.get("status") or "").upper() == "CONFIRMED" for f in forms)


def internal_priority(row: ClientSamplingDataForm | None) -> str:
    for form in data_form_forms(row):
        p = _text(form.get("sampling", {}).get("test_priority")).lower()
        if p in {"emergency", "urgent"}:
            return "URGENT"
    return "NORMAL"


def priority_for_indices(row: ClientSamplingDataForm | None, indices: list[int]) -> str:
    sample_map = sample_rows_by_index(row)
    return "URGENT" if any(_text(sample_map.get(i, {}).get("test_priority")).lower() in {"emergency", "urgent"} for i in indices) else "NORMAL"


def sample_point_label(item: dict[str, Any]) -> str:
    point = _text(item.get("sampling_from"), 100)
    if point == "Other" and _text(item.get("sampling_from_other"), 240):
        return f"Other: {_text(item.get('sampling_from_other'), 240)}"
    if point == "Tap Changer":
        position = _text(item.get("tap_changer_position"), 40)
        if position == "Other" and _text(item.get("tap_changer_position_other"), 120):
            position = _text(item.get("tap_changer_position_other"), 120)
        if position:
            return f"Tap Changer — {position}"
    return point


def sample_rows_by_index(row: ClientSamplingDataForm | None) -> dict[int, dict[str, Any]]:
    rows: dict[int, dict[str, Any]] = {}
    for item in data_form_payload(row).get("samples", []):
        try:
            idx = int(item.get("request_index") or item.get("index"))
        except Exception:
            continue
        clean = dict(item)
        clean["index"] = idx
        clean["sampling_point_label"] = sample_point_label(clean)
        rows[idx] = clean
    return rows


def form_number_for_sample_index(row: ClientSamplingDataForm | None, request_index: int | None) -> int | None:
    if not request_index:
        return None
    item = sample_rows_by_index(row).get(int(request_index))
    return int(item.get("form_number")) if item and item.get("form_number") else None


def form_by_number(row: ClientSamplingDataForm | None, form_number: int) -> dict[str, Any] | None:
    return next((f for f in data_form_forms(row) if int(f.get("form_number") or 0) == int(form_number)), None)


def _next_revision(db: Session, case_id: int) -> int:
    return int(db.scalar(select(func.max(ClientSamplingDataForm.revision)).where(ClientSamplingDataForm.commercial_case_id == case_id)) or 0) + 1


def create_or_editable_form(db: Session, case: CommercialCase, actor: User, *, entry_method: str = "ONLINE", source_attachment_id: int | None = None) -> ClientSamplingDataForm:
    row = current_data_form(db, case.id)
    if row and row.status in {"DRAFT", "CONFIRMED"}:
        return row
    # Submitted/locked client data is revised append-only. When Coordinator reopens the request,
    # clone the prior sheets into a new editable controlled revision instead of overwriting history.
    prior_forms = data_form_forms(row) if row else []
    if row:
        row.status = "SUPERSEDED"
    new = ClientSamplingDataForm(
        commercial_case_id=case.id, revision=_next_revision(db, case.id), status="DRAFT",
        entry_method=entry_method, source_attachment_id=source_attachment_id,
        form_code=FORM_CODE, source_revision=SOURCE_REVISION, digital_revision=DIGITAL_REVISION,
        created_by_id=actor.id,
    )
    db.add(new); db.flush()
    if prior_forms:
        cloned = copy.deepcopy(prior_forms)
        for f in cloned:
            f["status"] = "CONFIRMED"
        _store_forms(new, cloned)
        new.status = "CONFIRMED"
    return new


def add_blank_form(row: ClientSamplingDataForm, case: CommercialCase, actor: User) -> int:
    forms = data_form_forms(row)
    # A brand-new row exposes a legacy blank form only when old columns have content. Avoid turning
    # an untouched placeholder into two sheets.
    if len(forms) == 1 and not any(forms[0].get(k) for k in ("asset", "sampling", "samples")):
        forms = []
    n = len(forms) + 1
    forms.append({
        "form_number": n, "status": "DRAFT", "entry_method": "ONLINE", "source_attachment_id": None,
        "client": {"company_name": case.client.name}, "asset": {}, "sampling": {"test_priority": "Normal"},
        "samples": [{"index": 1, "sampling_from": "", "sampling_from_other": "", "tap_changer_position": "", "tap_changer_position_other": ""}],
        "extraction": {"review_required": False},
    })
    _store_forms(row, forms)
    row.created_by_id = row.created_by_id or actor.id
    return n


def remove_form(row: ClientSamplingDataForm, form_number: int) -> None:
    forms = data_form_forms(row)
    forms = [f for f in forms if int(f.get("form_number") or 0) != int(form_number)]
    if not forms:
        raise ValueError("At least one Sampling Data Form is required")
    _store_forms(row, forms)


def _field(text: str, label: str) -> str:
    m = re.search(rf"(?im)^\s*{re.escape(label)}\s*[:\-]?\s+(.+?)\s*$", text or "")
    return _text(m.group(1), 240) if m else ""


def prefill_from_uploaded_source(raw: bytes, content_type: str) -> dict[str, Any]:
    """Best-effort extraction only; scanned/handwritten sources always require human review."""
    text = extract_pdf_text(raw) if content_type == "application/pdf" else ""
    extraction = {
        "text_found": bool(text.strip()), "review_required": True,
        "source_kind": "TEXT_PDF" if text.strip() else "SCAN_OR_IMAGE",
        "message": "Values require client review before request submission.",
    }
    client: dict[str, Any] = {}
    asset: dict[str, Any] = {}
    sampling: dict[str, Any] = {}
    samples: list[dict[str, Any]] = []
    if text.strip():
        client = {
            "company_name": _field(text, "Company Name"), "email": _field(text, "E-mail"),
            "contact_person": _field(text, "Contact Person"), "address": _field(text, "Address"),
            "mobile_number": _field(text, "Mobile Number"), "telephone_number": _field(text, "Telephone Number"),
        }
        asset = {
            "serial_number": _field(text, "Serial Number"), "tag_number": _field(text, "ID / Tag Number"),
            "voltage_rating_hv_lv": _field(text, "Voltage Rating HV/LV (kV)"), "rated_power_mva": _field(text, "Rated Power (MVA)"),
            "sap_number": _field(text, "SAP number"), "manufacturer_name": _field(text, "Manufacturer Name"),
            "manufacture_year": _field(text, "Manufacture Year"), "country_of_manufacture": _field(text, "Country of Manufacture"),
            "substation": _field(text, "Substation"), "location": _field(text, "Location"), "load_pct": _field(text, "Load%"),
            "oil_type": _field(text, "Oil Type"), "oil_weight": _field(text, "Oil Weight (Ton / Kg)"),
        }
        sampling = {
            "unit_oil_temperature_c": _field(text, "Unit Oil Temperature, °C") or _field(text, "Unit Oil Temperature, C"),
            "reason_of_sampling": _field(text, "Reason of Sampling"),
            "ambient_temperature_c": _field(text, "Ambient Temperature, °C") or _field(text, "Ambient Temperature, C"),
            "ambient_humidity_pct": _field(text, "Ambient Humidity, %"),
            "winding_temperature_c": _field(text, "Winding Temperature, °C") or _field(text, "Winding Temperature, C"),
            "sample_man_name": _field(text, "Sample Man Name"), "sampling_date_time": _field(text, "Sampling Date & Time"),
        }
        legacy = parse_client_data_form(raw)
        legacy_samples = legacy.get("samples", {}) if isinstance(legacy, dict) else {}
        if legacy_samples:
            first = next(iter(legacy_samples.values()))
            asset.update({
                "serial_number": asset.get("serial_number") or first.get("serial_number", ""),
                "tag_number": asset.get("tag_number") or first.get("tag_number", ""),
                "manufacturer_name": asset.get("manufacturer_name") or first.get("manufacturer", ""),
                "manufacture_year": asset.get("manufacture_year") or first.get("manufacture_year", ""),
                "substation": asset.get("substation") or first.get("station_name", ""),
                "cooling_type": first.get("cooling_type", ""), "oil_type": asset.get("oil_type") or first.get("oil_type", ""),
            })
            for pos, sample in enumerate(legacy_samples.values(), start=1):
                samples.append({"index": pos, "sampling_from": sample.get("sampling_point", ""), "tap_changer_position": ""})
            sampling.update({
                "test_priority": "Emergency" if str(first.get("priority") or "").upper() in {"URGENT", "EMERGENCY"} else "Normal",
                "unit_oil_temperature_c": sampling.get("unit_oil_temperature_c") or first.get("oil_temperature_c", ""),
                "ambient_temperature_c": sampling.get("ambient_temperature_c") or first.get("ambient_temperature_c", ""),
                "ambient_humidity_pct": sampling.get("ambient_humidity_pct") or first.get("ambient_humidity_pct", ""),
                "reason_of_sampling": sampling.get("reason_of_sampling") or first.get("sampling_reason", ""),
                "sample_man_name": sampling.get("sample_man_name") or first.get("sample_man", ""),
                "sampling_date_time": sampling.get("sampling_date_time") or first.get("sample_date_time", ""),
            })
            extraction["legacy_fixture_detected"] = True
    return {"client": client, "asset": asset, "sampling": sampling, "samples": _clean_samples(samples), "extraction": extraction}


def update_form_payload(row: ClientSamplingDataForm, form_number: int, *, client: dict[str, Any], asset: dict[str, Any], sampling: dict[str, Any], samples: list[dict[str, Any]], actor: User, confirm: bool = True, entry_method: str | None = None, source_attachment_id: int | None = None, extraction: dict[str, Any] | None = None) -> None:
    forms = data_form_forms(row)
    while len(forms) < form_number:
        forms.append({"form_number": len(forms)+1, "status": "DRAFT", "entry_method": "ONLINE", "client": {}, "asset": {}, "sampling": {}, "samples": [], "extraction": {}})
    form = forms[form_number - 1]
    form["client"] = client
    form["asset"] = asset
    form["sampling"] = sampling
    form["samples"] = _clean_samples(samples)
    if entry_method:
        form["entry_method"] = entry_method
    if source_attachment_id is not None:
        form["source_attachment_id"] = source_attachment_id
    if extraction is not None:
        form["extraction"] = extraction
    if confirm:
        form["status"] = "CONFIRMED"
        form["confirmed_by_id"] = actor.id
        form["confirmed_at"] = datetime.utcnow().isoformat()
    _store_forms(row, forms)
    row.confirmed_by_id = actor.id if all_forms_confirmed(row) else row.confirmed_by_id
    if all_forms_confirmed(row):
        row.confirmed_at = datetime.utcnow()


def save_payload(row: ClientSamplingDataForm, *, client: dict[str, Any], asset: dict[str, Any], sampling: dict[str, Any], samples: list[dict[str, Any]], actor: User, confirm: bool = True) -> None:
    """Backward-compatible helper: writes Data Form 1."""
    update_form_payload(row, 1, client=client, asset=asset, sampling=sampling, samples=samples, actor=actor, confirm=confirm)


def lock_form(row: ClientSamplingDataForm, actor: User) -> None:
    forms = data_form_forms(row)
    if not forms or not all(str(f.get("status") or "").upper() == "CONFIRMED" for f in forms):
        raise ValueError("Every Sampling Data Form must be confirmed before request submission")
    row.status = "LOCKED"
    row.confirmed_by_id = actor.id
    row.confirmed_at = row.confirmed_at or datetime.utcnow()
    row.locked_at = datetime.utcnow()


def _cell(value: Any, *, bold: bool = False, small: bool = False) -> Paragraph:
    style = ParagraphStyle("cell", fontName="Helvetica-Bold" if bold else "Helvetica", fontSize=6.4 if small else 7.2, leading=8 if small else 9, textColor=colors.HexColor("#111111"))
    safe = str(value or "—").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return Paragraph(safe, style)


def _checks(options: list[str], selected: str, other_detail: str = "") -> str:
    target = _text(selected).lower(); detail = _text(other_detail)
    bits = []
    for option in options:
        mark = "[X]" if option.lower() == target else "[ ]"
        label = f"Other: {detail}" if option == "Other" and detail else option
        bits.append(f"{mark} {label}")
    return "   ".join(bits)


def _sheet_table(case: CommercialCase, form: dict[str, Any], planned_by_index: dict[int, PlannedSample], global_start: int) -> tuple[Table, int]:
    client, asset, sampling, samples = form.get("client", {}), form.get("asset", {}), form.get("sampling", {}), form.get("samples", [])
    styles = getSampleStyleSheet()
    section_style = ParagraphStyle("section", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=7.5, textColor=colors.white, leading=9)
    def section_row(text: str) -> list[Any]: return [Paragraph(text, section_style), "", "", ""]
    data: list[list[Any]] = [
        [_cell("Request / Case", bold=True), _cell(case.case_code), _cell("Sale Order Number (SON)", bold=True), _cell(case.sales_order_number or "Pending controlled handover")],
        [_cell("Data Form", bold=True), _cell(f"{int(form.get('form_number') or 1)} of request"), _cell("Number of Samples", bold=True), _cell(len(samples))],
        section_row("CLIENT INFORMATION"),
        [_cell("Company Name", bold=True), _cell(client.get("company_name") or case.client.name), _cell("E-mail", bold=True), _cell(client.get("email"))],
        [_cell("Contact Person", bold=True), _cell(client.get("contact_person")), _cell("Address", bold=True), _cell(client.get("address"))],
        [_cell("Mobile Number", bold=True), _cell(client.get("mobile_number")), _cell("Telephone Number", bold=True), _cell(client.get("telephone_number"))],
        section_row("TRANSFORMER INFORMATION"),
        [_cell("Serial Number", bold=True), _cell(asset.get("serial_number")), _cell("ID / Tag Number", bold=True), _cell(asset.get("tag_number"))],
        [_cell("Voltage Rating HV/LV (kV)", bold=True), _cell(asset.get("voltage_rating_hv_lv")), _cell("Rated Power (MVA)", bold=True), _cell(asset.get("rated_power_mva"))],
        [_cell("SAP number", bold=True), _cell(asset.get("sap_number")), _cell("Manufacturer Name", bold=True), _cell(asset.get("manufacturer_name"))],
        [_cell("Manufacture Year", bold=True), _cell(asset.get("manufacture_year")), _cell("Country of Manufacture", bold=True), _cell(asset.get("country_of_manufacture"))],
        [_cell("Substation", bold=True), _cell(asset.get("substation")), _cell("Location", bold=True), _cell(asset.get("location"))],
        [_cell("Load%", bold=True), _cell(asset.get("load_pct")), _cell("Oil Type", bold=True), _cell(asset.get("oil_type"))],
        [_cell("Sealing System", bold=True), _cell(_checks(SEALING_SYSTEMS, asset.get("sealing_system"), asset.get("sealing_system_other")), small=True), _cell("Cooling Type", bold=True), _cell(_checks(COOLING_TYPES, asset.get("cooling_type"), asset.get("cooling_type_other")), small=True)],
        [_cell("Oil Weight (Ton / Kg)", bold=True), _cell(asset.get("oil_weight")), _cell("Tap Changer Type", bold=True), _cell(_checks(TAP_CHANGER_TYPES, asset.get("tap_changer_type"), asset.get("tap_changer_type_other")), small=True)],
        [_cell("Tap Changer Chamber", bold=True), _cell(_checks(TAP_CHANGER_CHAMBERS, asset.get("tap_changer_chamber")), small=True), _cell("", bold=True), _cell("")],
        section_row("SAMPLING DATA"),
    ]
    global_index = global_start
    for local_idx, sample in enumerate(samples, start=1):
        global_index += 1
        plan = planned_by_index.get(global_index)
        point = sample_point_label(sample)
        if plan:
            barcode = code128.Code128(plan.barcode_value, barHeight=6.0*mm, barWidth=0.11*mm, humanReadable=False)
            data.append([_cell(f"Sample {local_idx}", bold=True), _cell(point), _cell(plan.request_number, bold=True), barcode])
        else:
            data.append([_cell(f"Sample {local_idx}", bold=True), _cell(point), _cell("Sample ID / Barcode", bold=True), _cell("Generated after controlled handover", small=True)])
    data.extend([
        [_cell("Unit Oil Temperature, °C", bold=True), _cell(sampling.get("unit_oil_temperature_c")), _cell("Unit In Service", bold=True), _cell(_checks(UNIT_IN_SERVICE, sampling.get("unit_in_service"), sampling.get("unit_in_service_other")), small=True)],
        [_cell("Reason of Sampling", bold=True), _cell(sampling.get("reason_of_sampling")), _cell("Test Priority", bold=True), _cell(_checks(TEST_PRIORITIES, sampling.get("test_priority")), small=True)],
        [_cell("Ambient Temperature, °C", bold=True), _cell(sampling.get("ambient_temperature_c")), _cell("Ambient Humidity, %", bold=True), _cell(sampling.get("ambient_humidity_pct"))],
        [_cell("Winding Temperature, °C", bold=True), _cell(sampling.get("winding_temperature_c")), _cell("Sample Man Name", bold=True), _cell(sampling.get("sample_man_name") or "Assigned TSCO Sampleman records actual execution")],
        [_cell("Sampling Date & Time", bold=True), _cell(sampling.get("sampling_date_time") or "Planned / actual field time recorded during execution"), _cell("", bold=True), _cell("")],
        section_row("CUSTODY / RECEIVING"),
        [_cell("Delivered By", bold=True), _cell(sampling.get("delivered_by")), _cell("Received By", bold=True), _cell(sampling.get("received_by"))],
        [_cell("Date", bold=True), _cell(sampling.get("delivered_date")), _cell("Date", bold=True), _cell(sampling.get("received_date"))],
        [_cell("Signature", bold=True), _cell("________________________"), _cell("Signature", bold=True), _cell("________________________")],
        [_cell("Contact No.", bold=True), _cell(sampling.get("delivered_contact_no")), _cell("", bold=True), _cell("")],
    ])
    table = Table(data, colWidths=[42*mm, 54*mm, 42*mm, 45*mm], repeatRows=2)
    style = TableStyle([
        ("GRID", (0,0), (-1,-1), 0.45, colors.HexColor("#777777")), ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING", (0,0), (-1,-1), 2.2*mm), ("RIGHTPADDING", (0,0), (-1,-1), 2*mm),
        ("TOPPADDING", (0,0), (-1,-1), 1.1*mm), ("BOTTOMPADDING", (0,0), (-1,-1), 1.1*mm),
    ])
    for r, rowdata in enumerate(data):
        if isinstance(rowdata[0], Paragraph) and getattr(rowdata[0], "text", "") in {"CLIENT INFORMATION", "TRANSFORMER INFORMATION", "SAMPLING DATA", "CUSTODY / RECEIVING"}:
            style.add("SPAN", (0,r), (-1,r)); style.add("BACKGROUND", (0,r), (-1,r), colors.HexColor("#555555"))
    table.setStyle(style)
    return table, global_index


def render_pdf_bytes(db: Session, row: ClientSamplingDataForm, case: CommercialCase, *, only_form_number: int | None = None) -> bytes:
    forms = data_form_forms(row)
    if only_form_number:
        forms = [f for f in forms if int(f.get("form_number") or 0) == int(only_form_number)]
        if not forms:
            raise ValueError("Sampling Data Form was not found")
    planned = list(db.scalars(select(PlannedSample).where(PlannedSample.commercial_case_id == case.id).order_by(PlannedSample.form_sample_index, PlannedSample.id)).all())
    planned_by_index = {int(p.form_sample_index): p for p in planned if p.form_sample_index}
    payload_map = sample_rows_by_index(row)

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, rightMargin=12*mm, leftMargin=12*mm, topMargin=9*mm, bottomMargin=9*mm)
    styles = getSampleStyleSheet()
    title = ParagraphStyle("title", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=14, leading=16, alignment=TA_CENTER, spaceAfter=2*mm)
    center = ParagraphStyle("center", parent=styles["Normal"], fontSize=7, alignment=TA_CENTER, leading=8.5)
    foot = ParagraphStyle("foot", parent=styles["Normal"], fontSize=5.8, alignment=TA_CENTER, textColor=colors.HexColor("#555555"))
    story: list[Any] = []
    # Global start index for each source sheet in the full request.
    starts: dict[int, int] = {}; running = 0
    for f in data_form_forms(row):
        starts[int(f.get("form_number") or 1)] = running
        running += len(f.get("samples", []))
    for pos, form in enumerate(forms):
        if pos:
            story.append(PageBreak())
        story.append(Paragraph("TSCO · GCC Technical Services Co", ParagraphStyle("brand", parent=styles["Normal"], fontName="Helvetica-Bold", fontSize=9)))
        story.append(Paragraph("Sampling Data Form", title))
        story.append(Paragraph(f"Source Form: {FORM_CODE} · Current paper revision: {SOURCE_REVISION} · Proposed Digital Revision {row.digital_revision}", center))
        story.append(Spacer(1, 2*mm))
        sheet, _ = _sheet_table(case, form, planned_by_index, starts.get(int(form.get("form_number") or 1), 0))
        story.append(sheet); story.append(Spacer(1, 2*mm))
        story.append(Paragraph(f"Form No. {FORM_CODE} · Source Rev. {SOURCE_REVISION} · Proposed Digital Revision {row.digital_revision} · UAT / pending Quality approval", foot))

    selected_form_numbers = {int(f.get("form_number") or 0) for f in forms}
    selected_planned = [p for p in planned if (not only_form_number or int(payload_map.get(int(p.form_sample_index or 0), {}).get("form_number") or 0) in selected_form_numbers)]
    if selected_planned:
        story.append(PageBreak())
        story.append(Paragraph("Sample Identification & Barcode Schedule", title))
        story.append(Paragraph(f"{case.case_code} · {case.client.name} · {len(selected_planned)} physical sample(s)", center)); story.append(Spacer(1, 4*mm))
        for p in sorted(selected_planned, key=lambda x: (x.form_sample_index or 999999, x.id)):
            meta = payload_map.get(int(p.form_sample_index or 0), {})
            barcode = code128.Code128(p.barcode_value, barHeight=12*mm, barWidth=0.28*mm, humanReadable=True)
            block = Table([
                [_cell(f"Data Form {meta.get('form_number') or '—'} · Sample {meta.get('local_index') or p.sequence_no}", bold=True), _cell(sample_point_label(meta) or p.sampling_point or "—"), _cell(p.request_number, bold=True)],
                [_cell("Transformer Serial", bold=True), _cell(p.expected_serial_number or meta.get("serial_number") or "—"), barcode],
            ], colWidths=[46*mm, 62*mm, 72*mm], rowHeights=[8*mm, 20*mm])
            block.setStyle(TableStyle([("GRID", (0,0), (-1,-1), .5, colors.HexColor("#777777")), ("VALIGN", (0,0), (-1,-1), "MIDDLE"), ("ALIGN", (2,1), (2,1), "CENTER"), ("LEFTPADDING", (0,0), (-1,-1), 2*mm)]))
            story.append(block); story.append(Spacer(1, 3*mm))
    doc.build(story)
    return buf.getvalue()


def refresh_pdf(db: Session, row: ClientSamplingDataForm, case: CommercialCase) -> bytes:
    raw = render_pdf_bytes(db, row, case)
    row.generated_pdf_blob = raw
    row.generated_pdf_sha256 = hashlib.sha256(raw).hexdigest()
    row.updated_at = datetime.utcnow()
    return raw
