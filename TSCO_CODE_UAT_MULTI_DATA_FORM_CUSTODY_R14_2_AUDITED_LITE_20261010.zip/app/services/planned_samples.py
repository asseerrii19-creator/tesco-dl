from __future__ import annotations

import io
import json
from datetime import datetime
from pathlib import Path

import qrcode
from pypdf import PdfReader, PdfWriter
from reportlab.graphics.barcode import code128
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfgen.canvas import Canvas
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import CommercialAttachment, CommercialCase, PlannedSample, SampleRequest, Site
from ..storage import BARCODE_DIR
from .barcodes import generate_assets
from .client_data_form import case_data_form_payload
from .commercial import request_line_expected_serials, request_line_sample_indices, request_scope_lines
from .identifiers import next_request_identifiers
from .sampling_data_form import current_data_form, form_number_for_sample_index, refresh_pdf, render_pdf_bytes, sample_point_label, sample_rows_by_index


def _safe_text(value: object, limit: int = 120) -> str:
    return str(value or '').strip()[:limit]


def _latest_client_data_form(db: Session, case_id: int) -> CommercialAttachment | None:
    return db.scalar(
        select(CommercialAttachment)
        .where(
            CommercialAttachment.commercial_case_id == case_id,
            CommercialAttachment.document_type == 'CLIENT_DATA_FORM',
        )
        .order_by(CommercialAttachment.created_at.desc(), CommercialAttachment.id.desc())
    )


def _source_pdf_bytes(attachment: CommercialAttachment | None) -> bytes | None:
    if not attachment:
        return None
    if attachment.content_blob and bytes(attachment.content_blob).startswith(b'%PDF-'):
        return bytes(attachment.content_blob)
    try:
        path = Path(attachment.stored_path or '')
        raw = path.read_bytes() if path.is_file() else b''
        return raw if raw.startswith(b'%PDF-') else None
    except Exception:
        return None


def generate_planned_data_form_pdf(db: Session, planned: PlannedSample) -> str:
    """Create one client-facing sample identity/data-form bundle.

    Page 1 is sample-specific and contains the stable Sample ID + barcode. If the client
    supplied a PDF Data Form, its original pages are appended unchanged behind the barcode
    cover so the client can print one controlled bundle per physical bottle/carton without
    exposing any other TSCO internal records.
    """
    structured = current_data_form(db, planned.commercial_case_id)
    if structured:
        form_number = form_number_for_sample_index(structured, planned.form_sample_index)
        raw = render_pdf_bytes(db, structured, planned.case, only_form_number=form_number) if form_number else refresh_pdf(db, structured, planned.case)
        BARCODE_DIR.mkdir(parents=True, exist_ok=True)
        suffix = f'_form_{form_number}' if form_number else ''
        out = BARCODE_DIR / f'case_{planned.commercial_case_id}{suffix}_sampling_data_form_r{structured.revision}.pdf'
        out.write_bytes(raw)
        planned.data_form_pdf_path = str(out)
        return str(out)

    BARCODE_DIR.mkdir(parents=True, exist_ok=True)
    safe = planned.barcode_value.replace('/', '-').replace('\\', '-')
    out = BARCODE_DIR / f'{safe}_client_data_form.pdf'
    qr_path = BARCODE_DIR / f'{safe}_client_qr.png'

    qr = qrcode.QRCode(version=4, box_size=8, border=2)
    qr.add_data(planned.barcode_value)
    qr.make(fit=True)
    qr.make_image(fill_color='black', back_color='white').save(qr_path)

    buffer = io.BytesIO()
    canvas = Canvas(buffer, pagesize=A4)
    width, height = A4
    canvas.setTitle(f'TSCO Client Sample Data Form {planned.request_number}')
    canvas.setFont('Helvetica-Bold', 15)
    canvas.drawString(18 * mm, height - 22 * mm, 'TSCO CLIENT SAMPLE DATA FORM / BARCODE')
    canvas.setFont('Helvetica', 8)
    canvas.drawString(18 * mm, height - 28 * mm, 'Print and keep this sheet with the matching physical sample/carton.')

    rows = [
        ('Sample ID', planned.request_number),
        ('Barcode', planned.barcode_value),
        ('Client', f'{planned.client.code} — {planned.client.name}'),
        ('Business Case', planned.case.case_code),
        ('Sales Order', planned.case.sales_order_number or '—'),
        ('Request Scope', f'Line {planned.request_line.line_number} · {planned.requested_package}'),
        ('Expected Serial', planned.expected_serial_number or 'To be confirmed / matched at collection or receipt'),
        ('Sampling Point', planned.sampling_point or 'As stated on the client Data Form / collection record'),
        ('Route', planned.delivery_mode.replace('_', ' ').title()),
        ('Expected Arrival', planned.expected_arrival_at.strftime('%Y-%m-%d %H:%M') if planned.expected_arrival_at else 'To be confirmed'),
        ('Priority / TAT', f'{planned.priority} / {planned.required_tat or "Standard"}'),
    ]
    y = height - 43 * mm
    for label, value in rows:
        canvas.setFont('Helvetica-Bold', 8)
        canvas.drawString(18 * mm, y, f'{label}:')
        canvas.setFont('Helvetica', 8)
        canvas.drawString(55 * mm, y, _safe_text(value, 95))
        y -= 7 * mm

    canvas.drawImage(str(qr_path), 155 * mm, height - 62 * mm, width=32 * mm, height=32 * mm, preserveAspectRatio=True)
    barcode = code128.Code128(planned.barcode_value, barHeight=17 * mm, barWidth=0.34 * mm, humanReadable=True)
    barcode.drawOn(canvas, 18 * mm, 38 * mm)
    canvas.setFont('Helvetica-Bold', 9)
    canvas.drawString(18 * mm, 28 * mm, 'Receiving control: Scan this barcode → match the expected sample → confirm physical receipt.')
    canvas.setFont('Helvetica', 7)
    canvas.drawString(18 * mm, 22 * mm, 'This identity is generated before arrival and remains unchanged through sampling, intake, laboratory testing and retained-sample storage.')
    canvas.showPage(); canvas.save(); buffer.seek(0)

    writer = PdfWriter()
    for page in PdfReader(buffer).pages:
        writer.add_page(page)
    source = _source_pdf_bytes(_latest_client_data_form(db, planned.commercial_case_id))
    if source:
        try:
            for page in PdfReader(io.BytesIO(source)).pages:
                writer.add_page(page)
        except Exception:
            pass
    with out.open('wb') as fh:
        writer.write(fh)
    qr_path.unlink(missing_ok=True)
    planned.data_form_pdf_path = str(out)
    return str(out)


def ensure_planned_samples(db: Session, case: CommercialCase) -> list[PlannedSample]:
    """Create the stable physical-sample identities for an approved request.

    This is idempotent and in-place-upgrade safe. Existing R13/legacy SampleRequest rows are
    first represented as MATERIALIZED planned identities using their *existing* Sample ID,
    barcode and public token. Only the still-missing quantity receives new expected identities.
    Therefore opening Intake after deployment cannot create duplicate expected bottles for
    samples that already exist in the database.
    """
    site = db.get(Site, case.site_id)
    if not site:
        raise ValueError('Business Case site is missing')
    structured_form = current_data_form(db, case.id)
    structured_samples = sample_rows_by_index(structured_form) if structured_form else {}
    _, parsed = case_data_form_payload(db, case.id)
    parsed_samples = parsed.get('samples', {}) if isinstance(parsed, dict) else {}
    all_rows: list[PlannedSample] = []
    consumed_structured_indices: set[int] = set()
    for line in request_scope_lines(db, case):
        existing = list(db.scalars(
            select(PlannedSample).where(PlannedSample.commercial_request_line_id == line.id).order_by(PlannedSample.sequence_no)
        ).all())
        used_sequences = {int(row.sequence_no) for row in existing}
        linked_sample_ids = {int(row.sample_request_id) for row in existing if row.sample_request_id}
        expected_serials = request_line_expected_serials(line)
        configured_indices = request_line_sample_indices(line)
        if structured_form and not configured_indices:
            available = [idx for idx in sorted(structured_samples) if idx not in consumed_structured_indices]
            configured_indices = available[:max(int(line.quantity or 0), 0)]
        consumed_structured_indices.update(configured_indices)

        # Backfill identities for samples created before this release without renumbering them.
        legacy_samples = list(db.scalars(
            select(SampleRequest).where(SampleRequest.commercial_request_line_id == line.id).order_by(SampleRequest.created_at, SampleRequest.id)
        ).all())
        for sample in legacy_samples:
            if sample.id in linked_sample_ids:
                continue
            seq = 1
            while seq in used_sequences:
                seq += 1
            form_index = configured_indices[seq - 1] if seq - 1 < len(configured_indices) else None
            structured_metadata = structured_samples.get(form_index, {}) if form_index else {}
            serial = _safe_text(structured_metadata.get('serial_number') or getattr(getattr(sample, 'asset', None), 'serial_number', ''), 120)
            metadata = structured_metadata or (parsed_samples.get(serial.upper(), {}) if serial else {})
            planned = PlannedSample(
                commercial_case_id=case.id,
                commercial_request_line_id=line.id,
                site_id=case.site_id,
                client_id=case.client_id,
                sequence_no=seq,
                request_number=sample.request_number,
                public_token=sample.public_token,
                barcode_value=sample.barcode_value,
                expected_serial_number=serial or (expected_serials[seq - 1] if seq - 1 < len(expected_serials) else ''),
                sampling_point=_safe_text(sample.sampling_point or sample_point_label(metadata) or metadata.get('sampling_point'), 100),
                form_sample_index=form_index,
                requested_package=sample.requested_package or line.requested_package,
                requested_method_family=sample.requested_method_family or line.method_family or 'DEFAULT',
                requested_tests_json=sample.requested_tests_json or line.requested_tests_json or '[]',
                priority=(sample.priority or line.priority or 'NORMAL').upper(),
                required_tat=sample.required_tat or line.required_tat or '',
                due_at=sample.due_at or line.due_at,
                delivery_mode=case.sample_delivery_mode or 'TBD',
                expected_arrival_at=case.expected_arrival_at,
                status='MATERIALIZED',
                sample_request_id=sample.id,
                materialized_at=sample.created_at or datetime.utcnow(),
            )
            db.add(planned); db.flush()
            existing.append(planned)
            used_sequences.add(seq)
            linked_sample_ids.add(sample.id)

        # Create only the unmaterialized balance of the approved line quantity.
        target_quantity = max(int(line.quantity or 0), len(existing))
        while len(existing) < target_quantity:
            seq = 1
            while seq in used_sequences:
                seq += 1
            form_index = configured_indices[seq - 1] if seq - 1 < len(configured_indices) else None
            structured_metadata = structured_samples.get(form_index, {}) if form_index else {}
            serial = _safe_text(structured_metadata.get('serial_number'), 120) or (expected_serials[seq - 1] if seq - 1 < len(expected_serials) else '')
            metadata = structured_metadata or (parsed_samples.get(serial.upper(), {}) if serial else {})
            request_number, barcode_value, public_token = next_request_identifiers(db, site)
            planned = PlannedSample(
                commercial_case_id=case.id,
                commercial_request_line_id=line.id,
                site_id=case.site_id,
                client_id=case.client_id,
                sequence_no=seq,
                request_number=request_number,
                public_token=public_token,
                barcode_value=barcode_value,
                expected_serial_number=serial,
                sampling_point=_safe_text(sample_point_label(metadata) or metadata.get('sampling_point'), 100),
                form_sample_index=form_index,
                requested_package=line.requested_package,
                requested_method_family=line.method_family or 'DEFAULT',
                requested_tests_json=line.requested_tests_json or '[]',
                priority=('URGENT' if str(metadata.get('test_priority') or '').lower() in {'emergency','urgent'} else (line.priority or 'NORMAL')).upper(),
                required_tat=line.required_tat or '',
                due_at=line.due_at,
                delivery_mode=case.sample_delivery_mode or 'TBD',
                expected_arrival_at=case.expected_arrival_at,
                status='EXPECTED',
            )
            db.add(planned); db.flush()
            label = generate_assets(
                planned.barcode_value,
                planned.request_number,
                planned.client.name,
                planned.expected_serial_number or f'Expected sample {planned.sequence_no}',
                BARCODE_DIR,
            )
            planned.label_pdf_path = str(label.get('label_pdf') or '')
            generate_planned_data_form_pdf(db, planned)
            existing.append(planned)
            used_sequences.add(seq)
        all_rows.extend(sorted(existing, key=lambda row: row.sequence_no))
    if structured_form and all_rows:
        # Refresh the full client bundle, then keep each physical sample linked to the specific
        # transformer Data Form sheet that owns it. One stable Sample ID/barcode is reused.
        refresh_pdf(db, structured_form, case)
        for planned in all_rows:
            if not planned.data_form_pdf_path:
                generate_planned_data_form_pdf(db, planned)
    return all_rows


def planned_samples_for_case(db: Session, case_id: int, *, active_only: bool = False) -> list[PlannedSample]:
    stmt = select(PlannedSample).where(PlannedSample.commercial_case_id == case_id)
    if active_only:
        stmt = stmt.where(PlannedSample.status.notin_(['MATERIALIZED', 'CANCELLED', 'VOID']))
    return list(db.scalars(stmt.order_by(PlannedSample.commercial_request_line_id, PlannedSample.sequence_no)).all())


def claim_planned_identity(planned: PlannedSample, sample: SampleRequest) -> None:
    if planned.sample_request_id and planned.sample_request_id != sample.id:
        raise ValueError('This expected sample identity has already been used')
    planned.sample_request_id = sample.id
    planned.status = 'MATERIALIZED'
    planned.materialized_at = datetime.utcnow()


def available_planned_for_line(db: Session, line_id: int) -> list[PlannedSample]:
    return list(db.scalars(
        select(PlannedSample).where(
            PlannedSample.commercial_request_line_id == line_id,
            PlannedSample.status.in_(['EXPECTED', 'ASSIGNED', 'IN_TRANSIT']),
            PlannedSample.sample_request_id.is_(None),
        ).order_by(PlannedSample.sequence_no)
    ).all())
