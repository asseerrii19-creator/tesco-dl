from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime
from io import BytesIO
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from fastapi.responses import FileResponse, RedirectResponse, Response
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from PIL import Image, UnidentifiedImageError

from ..database import get_db
from ..dependencies import templates
from ..models import (Asset, Client, ClientUnit, ClientSamplingDataForm, CommercialAttachment, CommercialCase, CommercialEvent, CommercialRequestLine, ControlledReport,
                      Notification, PlannedSample, PurchaseOrder, Quotation, Role, SampleRequest, SampleStatus, Site, User, UserClientAssignment)
from ..security import current_user, require_user
from ..services.audit import add_audit
from ..services.commercial import canonical_stage, ensure_sales_order, refresh_case_request_summary, request_line_sample_indices, request_scope_lines
from ..services.lab_operations import package_catalog
from ..services.sampling_data_form import (
    COOLING_TYPES, FORM_CODE, SAMPLING_POINTS, SEALING_SYSTEMS, SOURCE_REVISION, TAP_CHANGER_CHAMBERS,
    TAP_CHANGER_POSITIONS, TAP_CHANGER_TYPES, TEST_PRIORITIES, UNIT_IN_SERVICE, add_blank_form, all_forms_confirmed,
    create_or_editable_form, current_data_form, data_form_forms, data_form_payload, form_by_number, form_number_for_sample_index,
    internal_priority, lock_form, prefill_from_uploaded_source, priority_for_indices, refresh_pdf, remove_form,
    render_pdf_bytes, sample_count, sample_rows_by_index, update_form_payload,
)
from ..services.capabilities import can_manage_controlled_commercial_documents
from ..services.scope import allowed_client_unit_ids, can_access_asset, can_access_sample, client_scope_labels
from ..services.workflow import STATUS_LABELS, STATUS_ORDER
from ..storage import UPLOAD_DIR

router = APIRouter(tags=["client"])

CLIENT_DELIVERY_MODES = {"CLIENT_DELIVERY", "TSCO_PICKUP", "TSCO_ONSITE_SAMPLING", "TSCO_COLLECTION", "TBD"}
MAX_CLIENT_ATTACHMENT_BYTES = 10_000_000


def _client_case_editable(case: CommercialCase) -> bool:
    return case.request_status == "DRAFT" or bool(case.client_revision_open)


def _parse_sample_indices(values: list[str], *, max_index: int) -> list[int]:
    out: list[int] = []
    for value in values:
        try:
            idx = int(str(value).strip())
        except Exception:
            continue
        if 1 <= idx <= max_index and idx not in out:
            out.append(idx)
    return sorted(out)


def _normalize_real_form_payload(form) -> tuple[dict, dict, dict, list[dict]]:
    """Build structured data only from fields proven by QDF [7]-03-A Page 1 + approved multi-sample extension."""
    def v(name: str, limit: int = 500) -> str:
        return str(form.get(name) or "").strip()[:limit]

    client = {
        "company_name": v("company_name"), "email": v("email"), "contact_person": v("contact_person"),
        "address": v("address"), "mobile_number": v("mobile_number"), "telephone_number": v("telephone_number"),
    }
    asset = {
        "serial_number": v("serial_number"), "tag_number": v("tag_number"),
        "voltage_rating_hv_lv": v("voltage_rating_hv_lv"), "rated_power_mva": v("rated_power_mva"),
        "sap_number": v("sap_number"), "manufacturer_name": v("manufacturer_name"),
        "manufacture_year": v("manufacture_year"), "country_of_manufacture": v("country_of_manufacture"),
        "substation": v("substation"), "location": v("location"), "load_pct": v("load_pct"),
        "sealing_system": v("sealing_system"), "sealing_system_other": v("sealing_system_other"),
        "cooling_type": v("cooling_type"), "cooling_type_other": v("cooling_type_other"), "oil_type": v("oil_type"),
        "oil_weight": v("oil_weight"), "tap_changer_type": v("tap_changer_type"), "tap_changer_type_other": v("tap_changer_type_other"),
        "tap_changer_chamber": v("tap_changer_chamber"),
    }
    sampling = {
        "unit_oil_temperature_c": v("unit_oil_temperature_c"), "unit_in_service": v("unit_in_service"),
        "unit_in_service_other": v("unit_in_service_other"), "reason_of_sampling": v("reason_of_sampling"), "test_priority": v("test_priority"),
        "ambient_temperature_c": v("ambient_temperature_c"), "ambient_humidity_pct": v("ambient_humidity_pct"),
        "winding_temperature_c": v("winding_temperature_c"), "sample_man_name": v("sample_man_name"),
        "sampling_date_time": v("sampling_date_time"), "delivered_by": v("delivered_by"),
        "delivered_date": v("delivered_date"), "delivered_contact_no": v("delivered_contact_no"),
        "received_by": v("received_by"), "received_date": v("received_date"),
    }
    try:
        count = max(1, min(100, int(v("number_of_samples") or "1")))
    except Exception:
        raise ValueError("Number of Samples must be between 1 and 100")
    indexed = any(str(form.get(f"sampling_from_{i}") or "").strip() for i in range(1, count + 1))
    if indexed:
        points = [str(form.get(f"sampling_from_{i}") or "").strip() for i in range(1, count + 1)]
        point_others = [str(form.get(f"sampling_from_other_{i}") or "").strip()[:500] for i in range(1, count + 1)]
        tap_positions = [str(form.get(f"tap_changer_position_{i}") or "").strip() for i in range(1, count + 1)]
        tap_position_others = [str(form.get(f"tap_changer_position_other_{i}") or "").strip()[:120] for i in range(1, count + 1)]
    else:
        points = [str(x or "").strip() for x in form.getlist("sampling_from")]
        point_others = [str(x or "").strip()[:500] for x in form.getlist("sampling_from_other")]
        tap_positions = [str(x or "").strip() for x in form.getlist("tap_changer_position")]
        tap_position_others = [str(x or "").strip()[:120] for x in form.getlist("tap_changer_position_other")]
    samples = [{
        "index": i,
        "sampling_from": (points[i-1] if i-1 < len(points) else ""),
        "sampling_from_other": (point_others[i-1] if i-1 < len(point_others) else ""),
        "tap_changer_position": (tap_positions[i-1] if i-1 < len(tap_positions) else ""),
        "tap_changer_position_other": (tap_position_others[i-1] if i-1 < len(tap_position_others) else ""),
    } for i in range(1, count + 1)]
    if sampling["test_priority"] not in TEST_PRIORITIES:
        raise ValueError("Test Priority must be Normal or Emergency")
    for key, allowed in (("sealing_system", SEALING_SYSTEMS), ("cooling_type", COOLING_TYPES), ("tap_changer_type", TAP_CHANGER_TYPES), ("tap_changer_chamber", TAP_CHANGER_CHAMBERS)):
        if asset[key] and asset[key] not in allowed:
            raise ValueError(f"Invalid {key.replace('_',' ')} option")
    if sampling["unit_in_service"] and sampling["unit_in_service"] not in UNIT_IN_SERVICE:
        raise ValueError("Invalid Unit In Service option")
    for item in samples:
        if item["sampling_from"] and item["sampling_from"] not in SAMPLING_POINTS:
            raise ValueError("Invalid Sampling From option")
        if item["sampling_from"] != "Other":
            item["sampling_from_other"] = ""
        if item["sampling_from"] == "Tap Changer":
            if item["tap_changer_position"] and item["tap_changer_position"] not in TAP_CHANGER_POSITIONS:
                raise ValueError("Invalid Tap Changer position")
            if item["tap_changer_position"] != "Other":
                item["tap_changer_position_other"] = ""
        else:
            item["tap_changer_position"] = ""
            item["tap_changer_position_other"] = ""
    if asset.get("sealing_system") != "Other":
        asset["sealing_system_other"] = ""
    if asset.get("cooling_type") != "Other":
        asset["cooling_type_other"] = ""
    if asset.get("tap_changer_type") != "Other":
        asset["tap_changer_type_other"] = ""
    if sampling.get("unit_in_service") != "Other":
        sampling["unit_in_service_other"] = ""
    return client, asset, sampling, samples


def _parse_expected_arrival(value: str) -> datetime | None:
    clean = (value or "").strip()
    if not clean:
        return None
    try:
        return datetime.fromisoformat(clean)
    except ValueError as exc:
        raise ValueError("Expected sample arrival date/time is invalid") from exc


def _clean_delivery_mode(value: str) -> str:
    clean = (value or "TBD").strip().upper()
    if clean not in CLIENT_DELIVERY_MODES:
        raise ValueError("Sample route must be Client Delivery, TSCO Collection, or To Be Confirmed")
    return clean


def _validated_client_attachment(upload: UploadFile) -> tuple[bytes, str, str]:
    if not upload.filename:
        raise ValueError("Select a Data Form / client document to upload")
    raw = upload.file.read(MAX_CLIENT_ATTACHMENT_BYTES + 1)
    if not raw:
        raise ValueError("The selected client document is empty")
    if len(raw) > MAX_CLIENT_ATTACHMENT_BYTES:
        raise ValueError("Client documents must be 10 MB or smaller")
    suffix = Path(upload.filename).suffix.lower()
    content_type = (upload.content_type or "").lower()
    if content_type == "application/pdf" or suffix == ".pdf":
        if not raw.startswith(b"%PDF-"):
            raise ValueError("The uploaded PDF is invalid")
        return raw, ".pdf", "application/pdf"
    if content_type.startswith("image/") or suffix in {".jpg", ".jpeg", ".png", ".webp"}:
        try:
            with Image.open(BytesIO(raw)) as image:
                image.verify()
                fmt = (image.format or "").upper()
        except (UnidentifiedImageError, OSError, SyntaxError, ValueError):
            raise ValueError("The uploaded client image is invalid or corrupt")
        mapping = {"JPEG": (".jpg", "image/jpeg"), "PNG": (".png", "image/png"), "WEBP": (".webp", "image/webp")}
        if fmt not in mapping:
            raise ValueError("Client document images must be JPEG, PNG or WebP")
        return raw, *mapping[fmt]
    raise ValueError("Client documents must be PDF, JPEG, PNG or WebP")


def _client_site(db: Session, user: User) -> Site:
    row = db.get(Site, user.site_id) if user.site_id else db.scalar(select(Site).where(Site.code == "DMM"))
    if not row:
        raise ValueError("Active site is required")
    return row


def _client_case_code(db: Session, site: Site) -> str:
    year = datetime.utcnow().year
    prefix = f"BC-{site.code}-{year}-"
    rows = db.scalars(select(CommercialCase.case_code).where(CommercialCase.case_code.like(f"{prefix}%"))).all()
    last = 0
    for value in rows:
        try:
            last = max(last, int(value.rsplit("-", 1)[-1]))
        except Exception:
            pass
    return f"{prefix}{last + 1:04d}"


def _client_visible_packages(packages: list[dict], client: Client | None) -> list[dict]:
    """Expose only GENERAL packages plus packages explicitly scoped to this client."""
    code = (client.code if client else "").strip().upper()
    visible = []
    for package in packages:
        scope = str(package.get("scope") or "GENERAL").strip().upper()
        if scope in {"", "GENERAL", code}:
            visible.append(package)
    return visible


def _client_orderable_test_names(package: dict) -> list[str]:
    """Return the client-visible analytical scope for one package (no QC/derived helper rows)."""
    excluded_fragments = (
        "rsd%", "temperature", "humidity in cellulose", "oil quality index",
        "indirect dp", "lifetime remaining", "calculation",
    )
    names: list[str] = []
    for item in package.get("tests", []):
        if not isinstance(item, dict):
            continue
        name = str(item.get("test") or "").strip()
        method = str(item.get("method") or "").strip().lower()
        lowered = name.lower()
        if not name or lowered.startswith("room test") or method == "calculation":
            continue
        if any(fragment in lowered for fragment in excluded_fragments):
            continue
        if name not in names:
            names.append(name)
    return names


def _client_request_test_catalog(packages: list[dict]) -> list[dict]:
    """Client-orderable services only; hide methods, QC outputs and derived calculations."""
    rows: dict[str, dict] = {}
    for package in packages:
        for name in _client_orderable_test_names(package):
            rows.setdefault(name.lower(), {"test": name})
    return sorted(rows.values(), key=lambda row: row["test"].lower())


def _client_scope_due(value: str, tat: str) -> datetime | None:
    clean = (value or "").strip()
    if tat == "EXACT_DUE":
        if not clean:
            raise ValueError("Exact Due request requires a due date/time")
        try:
            return datetime.fromisoformat(clean)
        except ValueError as exc:
            raise ValueError("Exact due date/time is invalid") from exc
    return None


def _owned_client_case(db: Session, user: User, case_id: int) -> CommercialCase:
    row = db.get(CommercialCase, case_id)
    if not row or not user.client_id or row.client_id != user.client_id or row.request_source != "CLIENT_PORTAL":
        raise ValueError("Client request was not found in this account")
    return row


def _auto_assign_client_coordinator(db: Session, case: CommercialCase) -> User | None:
    """Assign a submitted client request to the least-loaded eligible site coordinator.

    The assignment is deterministic and auditable. Operations can still reassign later.
    """
    if case.assigned_coordinator_id:
        return db.get(User, case.assigned_coordinator_id)
    rows = list(db.scalars(select(User).where(
        User.active.is_(True), User.site_id == case.site_id, User.role == Role.CLIENT_COORDINATOR.value,
    ).order_by(User.full_name, User.id)).all())
    rows = [u for u in rows if can_manage_controlled_commercial_documents(u)]
    if not rows:
        return None
    counts = dict(db.execute(
        select(CommercialCase.assigned_coordinator_id, func.count(CommercialCase.id))
        .where(CommercialCase.status == "ACTIVE", CommercialCase.assigned_coordinator_id.is_not(None))
        .group_by(CommercialCase.assigned_coordinator_id)
    ).all())
    # Account ownership is authoritative when configured. This supports the operating model
    # where one coordinator owns Aramco and the second owns the remaining client accounts.
    owned_ids = set(db.scalars(select(UserClientAssignment.user_id).where(
        UserClientAssignment.client_id == case.client_id,
        UserClientAssignment.active.is_(True),
    )).all())
    scoped = [u for u in rows if u.id in owned_ids]
    if scoped:
        pool = scoped
    else:
        client = db.get(Client, case.client_id)
        is_aramco = bool(client and (str(client.code or '').upper() in {'ARM','ARAMCO'} or 'ARAMCO' in str(client.name or '').upper()))
        if is_aramco:
            pool = rows
        else:
            aramco_ids = set(db.scalars(
                select(UserClientAssignment.user_id)
                .join(Client, Client.id == UserClientAssignment.client_id)
                .where(
                    UserClientAssignment.active.is_(True),
                    ((func.upper(Client.code).in_(['ARM','ARAMCO'])) | (func.upper(Client.name).like('%ARAMCO%'))),
                )
            ).all())
            non_aramco_pool = [u for u in rows if u.id not in aramco_ids]
            pool = non_aramco_pool or rows
    chosen = min(pool, key=lambda u: (int(counts.get(u.id, 0)), u.full_name.lower(), u.id))
    case.assigned_coordinator_id = chosen.id
    return chosen


def _notify_case_coordinator(db: Session, case: CommercialCase, *, title: str, message: str, priority: str = "NORMAL") -> None:
    recipients: list[User] = []
    if case.assigned_coordinator_id:
        row = db.get(User, case.assigned_coordinator_id)
        if row and row.active:
            recipients.append(row)
    if not recipients:
        recipients = list(db.scalars(select(User).where(
            User.active.is_(True), User.site_id == case.site_id, User.role == Role.CLIENT_COORDINATOR.value,
        )).all())
    for recipient in recipients:
        db.add(Notification(site_id=case.site_id, user_id=recipient.id, category="CLIENT_REQUEST", title=title[:220], message=message[:500], target_url=f"/commercial?case_id={case.id}", priority=priority, email_status="PENDING_CONFIGURATION"))


@router.get("/client")
def client_dashboard(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.CLIENT.value, Role.SYSTEM_ADMIN.value})
    stmt = select(SampleRequest).order_by(SampleRequest.created_at.desc())
    scope_labels: list[str] = []
    if user.role == Role.CLIENT.value:
        stmt = stmt.where(SampleRequest.client_id == user.client_id)
        allowed_units = allowed_client_unit_ids(db, user, user.client_id)
        if allowed_units is not None:
            if allowed_units:
                stmt = stmt.join(Asset, SampleRequest.asset_id == Asset.id).where(Asset.client_unit_id.in_(allowed_units))
            else:
                stmt = stmt.where(SampleRequest.id == -1)
        scope_labels = client_scope_labels(db, user)
    samples = db.scalars(stmt.limit(100)).all()
    service_requests = []
    if user.client_id:
        service_requests = list(db.scalars(
            select(CommercialCase).where(
                CommercialCase.client_id == user.client_id, CommercialCase.request_source == "CLIENT_PORTAL"
            ).order_by(CommercialCase.updated_at.desc()).limit(100)
        ).all())
    visible_sample_ids = {row.id for row in samples if row.status == SampleStatus.REPORT_RELEASED.value}
    reports_by_sample = {}
    if visible_sample_ids:
        reports = db.scalars(
            select(ControlledReport)
            .where(ControlledReport.sample_request_id.in_(visible_sample_ids), ControlledReport.status == SampleStatus.REPORT_RELEASED.value)
            .order_by(ControlledReport.sample_request_id, ControlledReport.revision.desc(), ControlledReport.created_at.desc())
        ).all()
        for report in reports:
            reports_by_sample.setdefault(report.sample_request_id, report)
    return templates.TemplateResponse(
        "client_dashboard.html",
        {"request": request, "user": user, "samples": samples, "service_requests": service_requests, "status_labels": STATUS_LABELS, "scope_labels": scope_labels, "reports_by_sample": reports_by_sample},
    )


@router.post("/client/requests")
def start_client_request(
    request: Request, lead_title: str = Form(...), client_message: str = Form(""),
    expected_arrival_at: str = Form(""), sample_delivery_mode: str = Form("TBD"), sample_delivery_notes: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.CLIENT.value})
    if not user.client_id:
        raise ValueError("Client account is not linked to an organization")
    title = (lead_title or "").strip()
    if not title:
        raise ValueError("Request title is required")
    site = _client_site(db, user)
    row = CommercialCase(
        case_code=_client_case_code(db, site), site_id=site.id, client_id=user.client_id, owner_id=user.id,
        current_stage="LEAD_GENERATION", status="ACTIVE", lead_title=title[:220], lead_source="Client Portal",
        request_source="CLIENT_PORTAL", request_status="DRAFT", client_message=(client_message or "").strip()[:4000],
        expected_arrival_at=_parse_expected_arrival(expected_arrival_at), sample_delivery_mode=_clean_delivery_mode(sample_delivery_mode),
        sample_delivery_notes=(sample_delivery_notes or "").strip()[:4000],
    )
    db.add(row); db.flush()
    db.add(CommercialEvent(commercial_case_id=row.id, actor_id=user.id, from_stage="", to_stage="LEAD_GENERATION", note="Client service request draft opened"))
    add_audit(db, actor=user, request=request, action="CLIENT_SERVICE_REQUEST_DRAFT_CREATED", entity_type="CommercialCase", entity_id=row.id, summary=row.case_code)
    db.commit()
    return RedirectResponse(f"/client/requests/{row.id}", status_code=303)


@router.get("/client/requests/{case_id}")
def client_request_detail(case_id: int, request: Request, edit_data_form: int = 0, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.CLIENT.value})
    row = _owned_client_case(db, user, case_id)
    site = _client_site(db, user)
    packages = _client_visible_packages(package_catalog(db, site.id), user.client)
    lines = request_scope_lines(db, row)
    package_map = {str(package.get("name") or ""): package for package in packages}
    data_form = current_data_form(db, row.id)
    data_payload = data_form_payload(data_form)
    data_forms = data_form_forms(data_form)
    sample_catalog = sample_rows_by_index(data_form)
    used_indices: set[int] = set()
    for line in lines:
        try:
            requested = [str(x) for x in json.loads(line.requested_tests_json or "[]") if str(x).strip()]
        except Exception:
            requested = []
        if not requested and line.requested_package != "CUSTOM":
            requested = _client_orderable_test_names(package_map.get(str(line.requested_package), {}))
        line.requested_tests_display = ", ".join(requested)
        line.sample_indices = request_line_sample_indices(line)
        line.sample_labels = [sample_catalog.get(i, {}) for i in line.sample_indices]
        used_indices.update(line.sample_indices)
    planned_samples = list(db.scalars(
        select(PlannedSample).where(PlannedSample.commercial_case_id == row.id).order_by(PlannedSample.form_sample_index, PlannedSample.id)
    ).all())
    available_indices = [i for i in range(1, sample_count(data_form) + 1) if i not in used_indices]
    request_editable = _client_case_editable(row)
    return templates.TemplateResponse("client_request.html", {
        "request": request, "user": user, "case": row, "lines": lines, "packages": packages,
        "request_test_catalog": _client_request_test_catalog(packages), "planned_samples": planned_samples,
        "data_form": data_form, "data_forms": data_forms, "data_payload": data_payload,
        "request_editable": request_editable, "edit_data_form_number": int(edit_data_form or 0),
        "available_sample_indices": available_indices, "sample_catalog": sample_catalog,
        "sampling_points": SAMPLING_POINTS, "tap_changer_positions": TAP_CHANGER_POSITIONS,
        "sealing_systems": SEALING_SYSTEMS, "cooling_types": COOLING_TYPES,
        "tap_changer_types": TAP_CHANGER_TYPES, "tap_changer_chambers": TAP_CHANGER_CHAMBERS,
        "unit_in_service_options": UNIT_IN_SERVICE, "test_priorities": TEST_PRIORITIES,
        "form_code": FORM_CODE, "source_revision": SOURCE_REVISION,
    })


@router.get("/client/requests/{case_id}/sample-forms/{planned_id}")
def client_planned_sample_form(case_id: int, planned_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    planned = db.get(PlannedSample, planned_id)
    if not planned or planned.commercial_case_id != case.id or planned.client_id != user.client_id:
        raise ValueError("Expected sample Data Form was not found in this account")
    structured = current_data_form(db, case.id)
    if structured:
        form_number = form_number_for_sample_index(structured, planned.form_sample_index)
        raw = render_pdf_bytes(db, structured, case, only_form_number=form_number) if form_number else refresh_pdf(db, structured, case)
        if not form_number:
            db.commit()
        return Response(content=raw, media_type="application/pdf", headers={"Content-Disposition": f'inline; filename="{case.case_code}_Data_Form_{form_number or "All"}_R{structured.revision}.pdf"'})
    path = Path(planned.data_form_pdf_path or "")
    if not path.is_file():
        from ..services.planned_samples import generate_planned_data_form_pdf
        path = Path(generate_planned_data_form_pdf(db, planned)); db.commit()
    return FileResponse(path, media_type="application/pdf", filename=f"{planned.request_number}_Client_Data_Form.pdf")


@router.post("/client/requests/{case_id}/logistics")
def update_client_request_logistics(
    case_id: int, request: Request, expected_arrival_at: str = Form(""), sample_delivery_mode: str = Form("TBD"),
    sample_delivery_notes: str = Form(""), db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    if not _client_case_editable(case):
        raise ValueError("Submitted client requests are locked; the assigned Coordinator must reopen the request for client revision")
    case.expected_arrival_at = _parse_expected_arrival(expected_arrival_at)
    case.sample_delivery_mode = _clean_delivery_mode(sample_delivery_mode)
    case.sample_delivery_notes = (sample_delivery_notes or "").strip()[:4000]
    add_audit(db, actor=user, request=request, action="CLIENT_REQUEST_LOGISTICS_UPDATED", entity_type="CommercialCase", entity_id=case.id, summary=case.case_code)
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}", status_code=303)


@router.post("/client/requests/{case_id}/data-forms/new")
def add_client_sampling_data_form(case_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    if not _client_case_editable(case):
        raise ValueError("Submitted client requests are locked; the assigned Coordinator must reopen the request for client revision")
    if request_scope_lines(db, case):
        raise ValueError("Remove Service Scope before adding another Data Form / transformer so physical-sample mapping cannot change silently")
    row = create_or_editable_form(db, case, user)
    number = add_blank_form(row, case, user)
    refresh_pdf(db, row, case)
    add_audit(db, actor=user, request=request, action="CLIENT_SAMPLING_DATA_FORM_ADDED", entity_type="ClientSamplingDataForm", entity_id=row.id, summary=f"{case.case_code}: Data Form {number} added")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}?edit_data_form={number}#data-form-{number}", status_code=303)


@router.post("/client/requests/{case_id}/data-forms/{form_number}/remove")
def remove_client_sampling_data_form(case_id: int, form_number: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    if not _client_case_editable(case):
        raise ValueError("Submitted client requests are locked")
    if request_scope_lines(db, case):
        raise ValueError("Remove Service Scope before removing a Data Form / transformer")
    row = create_or_editable_form(db, case, user)
    remove_form(row, form_number)
    case.expected_samples = sample_count(row)
    case.default_priority = internal_priority(row)
    refresh_pdf(db, row, case)
    add_audit(db, actor=user, request=request, action="CLIENT_SAMPLING_DATA_FORM_REMOVED", entity_type="ClientSamplingDataForm", entity_id=row.id, summary=f"{case.case_code}: Data Form {form_number} removed")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}#data-form", status_code=303)


@router.post("/client/requests/{case_id}/attachments")
def upload_client_request_attachment(
    case_id: int, request: Request, upload: UploadFile = File(...), form_number: int = Form(0), db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    if not _client_case_editable(case):
        raise ValueError("Submitted client requests are locked; the assigned Coordinator must reopen the request for client revision")
    row = create_or_editable_form(db, case, user, entry_method="UPLOAD")
    if form_number <= 0:
        if request_scope_lines(db, case):
            raise ValueError("Remove Service Scope before adding another Data Form / transformer")
        form_number = add_blank_form(row, case, user)
    if not form_by_number(row, form_number):
        raise ValueError("Sampling Data Form was not found")
    raw, ext, mime = _validated_client_attachment(upload)
    digest = hashlib.sha256(raw).hexdigest()
    folder = UPLOAD_DIR / "commercial"; folder.mkdir(parents=True, exist_ok=True)
    stored = folder / f"case_{case.id}_form_{form_number}_{digest[:20]}{ext}"
    if not stored.exists(): stored.write_bytes(raw)
    attachment = CommercialAttachment(
        commercial_case_id=case.id, document_type="CLIENT_DATA_FORM", original_name=Path(upload.filename or f"data-form{ext}").name[:220],
        stored_path=str(stored), content_type=mime, sha256=digest, content_blob=raw, uploaded_by_id=user.id,
    )
    db.add(attachment); db.flush()
    parsed = prefill_from_uploaded_source(raw, mime)
    existing = form_by_number(row, form_number) or {}
    client = parsed["client"] or existing.get("client", {}) or {"company_name": case.client.name}
    asset = parsed["asset"] or existing.get("asset", {})
    sampling = parsed["sampling"] or existing.get("sampling", {}) or {"test_priority": "Normal"}
    samples = parsed["samples"] or existing.get("samples", []) or [{"index":1,"sampling_from":"","sampling_from_other":"","tap_changer_position":"","tap_changer_position_other":""}]
    update_form_payload(row, form_number, client=client, asset=asset, sampling=sampling, samples=samples, actor=user, confirm=False,
                        entry_method="UPLOAD", source_attachment_id=attachment.id, extraction=parsed["extraction"])
    refresh_pdf(db, row, case)
    add_audit(db, actor=user, request=request, action="CLIENT_DATA_FORM_SOURCE_UPLOADED", entity_type="ClientSamplingDataForm", entity_id=row.id, summary=f"{case.case_code}: Data Form {form_number} · {attachment.original_name}; review required")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}?edit_data_form={form_number}#data-form-{form_number}", status_code=303)


async def _save_client_sampling_data_form_sheet(case_id: int, form_number: int, request: Request, db: Session):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    if not _client_case_editable(case):
        raise ValueError("Submitted client requests are locked; the assigned Coordinator must reopen the request for client revision")
    row = create_or_editable_form(db, case, user)
    existing = form_by_number(row, form_number)
    if not existing:
        raise ValueError("Sampling Data Form was not found")
    form = await request.form()
    client, asset, sampling, samples = _normalize_real_form_payload(form)
    if not asset.get("serial_number"):
        raise ValueError("Transformer Serial Number is required in the Sampling Data Form")
    if not samples:
        raise ValueError("The Sampling Data Form must contain at least one physical sample")
    active_scope = request_scope_lines(db, case)
    if active_scope and len(samples) != len(existing.get("samples", [])):
        raise ValueError("Remove Service Scope before changing Number of Samples; existing scope is mapped to the current physical samples")
    extraction = dict(existing.get("extraction") or {})
    extraction.update({"review_required": False, "confirmed_in_platform": True, "confirmed_at": datetime.utcnow().isoformat()})
    update_form_payload(row, form_number, client=client, asset=asset, sampling=sampling, samples=samples, actor=user, confirm=True,
                        entry_method=existing.get("entry_method") or "ONLINE", source_attachment_id=existing.get("source_attachment_id"), extraction=extraction)
    case.expected_samples = sample_count(row)
    case.default_priority = internal_priority(row)
    for line in active_scope:
        line.priority = priority_for_indices(row, request_line_sample_indices(line))
    refresh_pdf(db, row, case)
    add_audit(db, actor=user, request=request, action="CLIENT_SAMPLING_DATA_FORM_CONFIRMED", entity_type="ClientSamplingDataForm", entity_id=row.id,
              summary=f"{case.case_code}: Data Form {form_number}; {len(samples)} physical sample(s); serial {asset.get('serial_number')}")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}#data-form-{form_number}", status_code=303)


@router.post("/client/requests/{case_id}/data-forms/{form_number}")
async def save_client_sampling_data_form_sheet(case_id: int, form_number: int, request: Request, db: Session = Depends(get_db)):
    return await _save_client_sampling_data_form_sheet(case_id, form_number, request, db)


# Backward-compatible v3.7.4 endpoint: Data Form 1.
@router.post("/client/requests/{case_id}/data-form")
async def save_client_sampling_data_form(case_id: int, request: Request, db: Session = Depends(get_db)):
    return await _save_client_sampling_data_form_sheet(case_id, 1, request, db)


@router.get("/client/requests/{case_id}/data-form.pdf")
def client_sampling_data_form_pdf(case_id: int, request: Request, form_number: int = 0, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    row = current_data_form(db, case.id)
    if not row:
        raise ValueError("Sampling Data Form has not been created")
    if form_number:
        raw = render_pdf_bytes(db, row, case, only_form_number=form_number)
        name = f"{case.case_code}_Data_Form_{form_number}_R{row.revision}.pdf"
    else:
        raw = refresh_pdf(db, row, case); db.commit()
        name = f"{case.case_code}_Sampling_Data_Forms_R{row.revision}.pdf"
    return Response(content=raw, media_type="application/pdf", headers={"Content-Disposition": f'inline; filename="{name}"'})


@router.get("/client/requests/{case_id}/attachments/{attachment_id}")
def open_client_request_attachment(case_id: int, attachment_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    row = db.get(CommercialAttachment, attachment_id)
    if not row or row.commercial_case_id != case.id:
        raise ValueError("Client request attachment was not found")
    path = Path(row.stored_path or "")
    if path.is_file():
        return FileResponse(path, media_type=row.content_type or "application/octet-stream", filename=Path(row.original_name).name, content_disposition_type="inline")
    if row.content_blob:
        safe_name = Path(row.original_name).name.replace('"', '')
        return Response(content=bytes(row.content_blob), media_type=row.content_type or "application/octet-stream", headers={"Content-Disposition": f'inline; filename="{safe_name}"'})
    raise ValueError("Client request attachment file is unavailable")


@router.post("/client/requests/{case_id}/quotation-decision")
def client_quotation_decision(
    case_id: int, request: Request, decision: str = Form(...), note: str = Form(""), db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    quote = case.quotation
    if not quote:
        raise ValueError("Quotation is not available yet")
    action = (decision or "").strip().upper()
    if action not in {"ACCEPT", "REJECT"}:
        raise ValueError("Quotation decision must be Accept or Reject")
    current = canonical_stage(case.current_stage)
    if current not in {"QUOTATION", "CLIENT_FOLLOW_UP"}:
        raise ValueError("Quotation decision is no longer available at this stage")
    if action == "ACCEPT":
        quote.status = "CLIENT_ACCEPTED"
        case.request_status = "QUOTATION_ACCEPTED"
        case.client_follow_up = (note or "Client accepted quotation in portal").strip()[:4000]
        if current == "QUOTATION":
            db.add(CommercialEvent(commercial_case_id=case.id, actor_id=user.id, from_stage="QUOTATION", to_stage="CLIENT_FOLLOW_UP", note=case.client_follow_up, reference=quote.number))
            case.current_stage = "CLIENT_FOLLOW_UP"
        _notify_case_coordinator(db, case, title=f"Quotation accepted — {case.case_code}", message=f"{case.client.name} accepted quotation {quote.number}.", priority="HIGH")
    else:
        quote.status = "CLIENT_REJECTED"
        case.request_status = "QUOTATION_REJECTED"
        rejection_note = (note or "Client requested quotation revision").strip()[:4000]
        case.client_follow_up = rejection_note
        db.add(CommercialEvent(commercial_case_id=case.id, actor_id=user.id, from_stage=current, to_stage=current, note=rejection_note, reference=quote.number))
        _notify_case_coordinator(db, case, title=f"Quotation revision requested — {case.case_code}", message=f"{case.client.name} rejected / requested revision to quotation {quote.number}. {rejection_note}", priority="HIGH")
    add_audit(db, actor=user, request=request, action=f"CLIENT_QUOTATION_{action}", entity_type="CommercialCase", entity_id=case.id, summary=f"{case.case_code}: quotation {quote.number} {action.lower()}")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}", status_code=303)


@router.post("/client/requests/{case_id}/purchase-order")
def client_purchase_order_upload(
    case_id: int, request: Request, purchase_order_number: str = Form(...), upload: UploadFile = File(...), db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    quote = case.quotation
    if not quote or quote.status != "CLIENT_ACCEPTED":
        raise ValueError("Accept the current quotation before uploading the purchase order")
    current = canonical_stage(case.current_stage)
    if current not in {"CLIENT_FOLLOW_UP", "PURCHASE_ORDER_RECEIVED"}:
        raise ValueError("Purchase order upload is not available at this stage")
    number = (purchase_order_number or "").strip()[:80]
    if not number:
        raise ValueError("Purchase order number is required")
    raw, ext, mime = _validated_client_attachment(upload)
    po = db.scalar(select(PurchaseOrder).where(PurchaseOrder.client_id == case.client_id, PurchaseOrder.number == number))
    if po and po.quotation_id and po.quotation_id != quote.id:
        raise ValueError("Purchase order number is already linked to a different quotation")
    if not po:
        po = PurchaseOrder(client_id=case.client_id, quotation_id=quote.id, number=number, status="ACTIVE")
        db.add(po); db.flush()
    else:
        po.quotation_id = quote.id; po.status = "ACTIVE"
    case.purchase_order_id = po.id
    case.po_received_reference = number
    case.request_status = "PO_RECEIVED"
    sales_order = ensure_sales_order(db, case)
    digest = hashlib.sha256(raw).hexdigest()
    folder = UPLOAD_DIR / "commercial"; folder.mkdir(parents=True, exist_ok=True)
    stored = folder / f"case_{case.id}_po_{digest[:20]}{ext}"
    if not stored.exists(): stored.write_bytes(raw)
    existing = db.scalar(select(CommercialAttachment).where(
        CommercialAttachment.commercial_case_id == case.id,
        CommercialAttachment.document_type == "PURCHASE_ORDER",
        CommercialAttachment.sha256 == digest,
    ))
    if not existing:
        doc = CommercialAttachment(commercial_case_id=case.id, document_type="PURCHASE_ORDER", original_name=Path(upload.filename or f"purchase-order{ext}").name[:220], stored_path=str(stored), content_type=mime, sha256=digest, content_blob=raw, uploaded_by_id=user.id)
        db.add(doc)
    if current != "PURCHASE_ORDER_RECEIVED":
        db.add(CommercialEvent(commercial_case_id=case.id, actor_id=user.id, from_stage=current, to_stage="PURCHASE_ORDER_RECEIVED", note=f"Client uploaded approved purchase order in portal · Sales Order {sales_order}", reference=number))
        case.current_stage = "PURCHASE_ORDER_RECEIVED"
    _notify_case_coordinator(db, case, title=f"Purchase order received — {case.case_code}", message=f"{case.client.name} uploaded PO {number}; complete the controlled handover.", priority="HIGH")
    add_audit(db, actor=user, request=request, action="CLIENT_PURCHASE_ORDER_UPLOADED", entity_type="CommercialCase", entity_id=case.id, summary=f"{case.case_code}: PO {number} received from client")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}", status_code=303)


@router.post("/client/requests/{case_id}/lines")
def add_client_request_line(
    case_id: int, request: Request, requested_package: str = Form(...),
    method_family: str = Form("DEFAULT"), required_tat: str = Form(""), due_at: str = Form(""),
    sample_indices: list[str] = Form([]), requested_tests: list[str] = Form([]), db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    if not _client_case_editable(case):
        raise ValueError("Submitted client requests are locked; the assigned Coordinator must reopen the request for client revision")
    data_form = current_data_form(db, case.id)
    if not data_form or not all_forms_confirmed(data_form):
        raise ValueError("Confirm every Sampling Data Form before adding Service Scope")
    total = sample_count(data_form)
    indices = _parse_sample_indices(sample_indices, max_index=total)
    if not indices:
        raise ValueError("Select at least one physical sample for this Service Scope")
    already = {idx for line in request_scope_lines(db, case) for idx in request_line_sample_indices(line)}
    duplicate = sorted(set(indices) & already)
    if duplicate:
        raise ValueError(f"Sample {duplicate[0]} already has a Service Scope")
    site = _client_site(db, user)
    packages = _client_visible_packages(package_catalog(db, site.id), user.client)
    active_names = {str(row.get("name") or "") for row in packages}
    package = (requested_package or "").strip()
    if package != "CUSTOM" and package not in active_names:
        raise ValueError("Select an available test package or Custom Tests")
    family = (method_family or "DEFAULT").strip().upper()
    if family not in {"DEFAULT", "ASTM", "IEC"}:
        raise ValueError("Method family must be Default, ASTM or IEC")
    tat = (required_tat or "").strip().upper()
    if tat not in {"", "12H", "24H", "EXACT_DUE"}:
        raise ValueError("Required TAT must be Standard, 12H, 24H or Exact Due")
    exact_due = _client_scope_due(due_at, tat)
    valid_test_names = {row["test"] for row in _client_request_test_catalog(packages)}
    tests = list(dict.fromkeys(str(value).strip() for value in requested_tests if str(value).strip()))
    if package == "CUSTOM":
        if not tests:
            raise ValueError("Custom Tests requires at least one requested test")
        unknown = [name for name in tests if name not in valid_test_names]
        if unknown:
            raise ValueError(f"Unknown requested test: {unknown[0]}")
    else:
        tests = []
    next_line = (db.scalar(select(func.max(CommercialRequestLine.line_number)).where(CommercialRequestLine.commercial_case_id == case.id)) or 0) + 1
    row = CommercialRequestLine(
        commercial_case_id=case.id, line_number=next_line, quantity=len(indices), requested_package=package,
        requested_tests_json=json.dumps(tests, ensure_ascii=False), expected_serials_json="[]", sample_indices_json=json.dumps(indices),
        method_family=family, priority=priority_for_indices(data_form, indices), required_tat=tat, due_at=exact_due, status="ACTIVE", created_by_id=user.id,
    )
    db.add(row); db.flush(); refresh_case_request_summary(db, case)
    add_audit(db, actor=user, request=request, action="CLIENT_REQUEST_SCOPE_ADDED_BY_CLIENT", entity_type="CommercialRequestLine", entity_id=row.id, summary=f"{case.case_code} line {row.line_number}: samples {indices} · {package}")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}#scope", status_code=303)


@router.post("/client/requests/{case_id}/lines/{line_id}/edit")
def edit_client_request_line(
    case_id: int, line_id: int, request: Request, required_tat: str = Form(""), due_at: str = Form(""), db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    if not _client_case_editable(case):
        raise ValueError("Submitted client requests are locked")
    row = db.get(CommercialRequestLine, line_id)
    if not row or row.commercial_case_id != case.id or row.status != "ACTIVE":
        raise ValueError("Request scope line was not found")
    tat = (required_tat or "").strip().upper()
    if tat not in {"", "12H", "24H", "EXACT_DUE"}:
        raise ValueError("Required TAT is invalid")
    data_form = current_data_form(db, case.id)
    row.priority = priority_for_indices(data_form, request_line_sample_indices(row))
    row.required_tat = tat
    row.due_at = _client_scope_due(due_at, tat)
    refresh_case_request_summary(db, case)
    add_audit(db, actor=user, request=request, action="CLIENT_REQUEST_SCOPE_EDITED_BY_CLIENT", entity_type="CommercialRequestLine", entity_id=row.id, summary=f"{case.case_code} line {row.line_number} TAT edited")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}#scope", status_code=303)


@router.post("/client/requests/{case_id}/lines/{line_id}/remove")
def remove_client_request_line(case_id: int, line_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    if not _client_case_editable(case):
        raise ValueError("Submitted client requests are locked")
    row = db.get(CommercialRequestLine, line_id)
    if not row or row.commercial_case_id != case.id:
        raise ValueError("Request scope line was not found")
    row.status = "REMOVED"; refresh_case_request_summary(db, case)
    add_audit(db, actor=user, request=request, action="CLIENT_REQUEST_SCOPE_REMOVED_BY_CLIENT", entity_type="CommercialRequestLine", entity_id=row.id, summary=f"{case.case_code} line {row.line_number} removed")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}#scope", status_code=303)


@router.post("/client/requests/{case_id}/submit")
def submit_client_request(case_id: int, request: Request, client_message: str = Form(""), db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.CLIENT.value})
    case = _owned_client_case(db, user, case_id)
    is_revision = bool(case.client_revision_open)
    if case.request_status != "DRAFT" and not is_revision:
        raise ValueError("Client request is already submitted")
    data_form = current_data_form(db, case.id)
    if not data_form or not all_forms_confirmed(data_form):
        raise ValueError("Confirm every Sampling Data Form before submitting the request")
    total = sample_count(data_form)
    lines = request_scope_lines(db, case)
    if not lines:
        raise ValueError("Add Service Scope for the expected samples before submitting")
    covered = [idx for line in lines for idx in request_line_sample_indices(line)]
    expected = list(range(1, total + 1))
    if sorted(covered) != expected or len(covered) != len(set(covered)):
        raise ValueError("Every physical sample in the Sampling Data Form must have exactly one Service Scope before submission")
    case.client_message = (client_message or case.client_message or "").strip()[:4000]
    case.expected_samples = total
    case.default_priority = internal_priority(data_form)
    lock_form(data_form, user)
    refresh_pdf(db, data_form, case)
    now = datetime.utcnow()
    if is_revision:
        case.client_revision_open = False
        case.client_resubmitted_at = now
        db.add(CommercialEvent(commercial_case_id=case.id, actor_id=user.id, from_stage=case.current_stage, to_stage=case.current_stage, note=f"Client corrected and resubmitted request revision {case.client_revision_number}."))
        _notify_case_coordinator(db, case, title=f"Client revision resubmitted — {case.case_code}", message=f"{case.client.name} resubmitted requested corrections for revision {case.client_revision_number}.", priority="HIGH")
        audit_action = "CLIENT_SERVICE_REQUEST_REVISION_RESUBMITTED"
    else:
        case.request_status = "RECEIVED"
        case.client_submitted_at = now
        assigned = _auto_assign_client_coordinator(db, case)
        assignment_note = f" Assigned coordinator: {assigned.full_name}." if assigned else " Awaiting coordinator assignment."
        db.add(CommercialEvent(commercial_case_id=case.id, actor_id=user.id, from_stage="LEAD_GENERATION", to_stage="LEAD_GENERATION", note="Client service request submitted and locked." + assignment_note))
        _notify_case_coordinator(db, case, title=f"New client request — {case.case_code}", message=f"{case.client.name}: {case.lead_title}", priority="HIGH" if case.default_priority == "URGENT" else "NORMAL")
        sales = list(db.scalars(select(User).where(User.active.is_(True), User.site_id == case.site_id, User.role == Role.SALES_MARKETING.value)).all())
        for recipient in sales:
            db.add(Notification(site_id=case.site_id, user_id=recipient.id, category="CLIENT_REQUEST", title=f"New client request — {case.case_code}", message=f"{case.client.name}: {case.lead_title}"[:500], target_url=f"/commercial?case_id={case.id}", priority="HIGH" if case.default_priority == "URGENT" else "NORMAL", email_status="PENDING_CONFIGURATION"))
        audit_action = "CLIENT_SERVICE_REQUEST_SUBMITTED"
    refresh_case_request_summary(db, case)
    # Data Form is the authority for physical-sample count and request-level priority.
    # Service Scope remains authoritative for package/method/TAT, but mixed scope-line
    # priorities must not downgrade an Emergency Data Form to a generic MIXED status.
    case.expected_samples = total
    case.default_priority = internal_priority(data_form)
    add_audit(db, actor=user, request=request, action=audit_action, entity_type="CommercialCase", entity_id=case.id, summary=f"{case.case_code}: Data Form locked; {total} sample(s)")
    db.commit()
    return RedirectResponse(f"/client/requests/{case.id}", status_code=303)


@router.get("/track/{token}")
def public_tracking(token: str, request: Request, db: Session = Depends(get_db)):
    sample = db.scalar(select(SampleRequest).where(SampleRequest.public_token == token))
    if not sample:
        return templates.TemplateResponse("not_found.html", {"request": request}, status_code=404)
    public_enabled = os.getenv("ENABLE_PUBLIC_TRACKING", "false").strip().lower() in {"1", "true", "yes", "on"}
    user = current_user(request, db)
    if not public_enabled:
        if not user:
            return RedirectResponse("/login", status_code=303)
        if not can_access_sample(db, user, sample):
            return templates.TemplateResponse("not_found.html", {"request": request, "user": user}, status_code=404)
    completed = {event.status for event in sample.events}
    completed.add(sample.status)
    # Workflow is monotonic for client-safe milestones. If the authoritative sample is at
    # a later stage, all prerequisite milestones must render complete even when an older
    # database lacks one historical custody event.
    try:
        current_index = STATUS_ORDER.index(sample.status)
        completed.update(STATUS_ORDER[: current_index + 1])
    except ValueError:
        pass
    return templates.TemplateResponse(
        "public_track.html",
        {
            "request": request,
            "user": user,
            "sample": sample,
            "status_labels": STATUS_LABELS,
            "status_order": STATUS_ORDER,
            "completed": completed,
        },
    )
