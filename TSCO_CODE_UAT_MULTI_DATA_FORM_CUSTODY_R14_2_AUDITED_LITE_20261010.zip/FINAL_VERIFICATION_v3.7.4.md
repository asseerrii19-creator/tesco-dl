# Final Verification — v3.7.4 / R14.1

## Verification status
- `BUILD_RELEASE_CHECK.sh`: PASS
- Curated regression: **83 passed / 0 failed**
- R14.1 focused tests: **5 passed / 0 failed**
- Alembic fresh-database upgrade: PASS to `a1d4c7f9e820`
- Real image-upload path: PASS; scan/photo preserved as evidence and marked Review Required rather than falsely parsed as handwriting.
- Runtime Client Request workflow: PASS — Data Form confirmation -> paper/read-only view -> explicit draft edit -> Service Scope -> Submit/lock -> assigned Coordinator reopen -> client correction -> resubmit/new locked revision.
- Multi-sample Data Form: PASS — one transformer, multiple physical sample lines, planned IDs/barcodes after controlled handover.
- Printable Data Form: PASS — A4 paper form plus barcode schedule; barcodes remain within page bounds.

## Locked areas comparison
The following R14 source files are byte-for-byte unchanged from the R14 baseline:
- `app/services/final_report_pdf.py`
- `app/services/final_report_data.py`
- `app/routes/control_center.py`

The final report pipeline was not redesigned in this corrective release.

## Source limitation
Only QDF [7]-03-A Revision 03 **Page 1 of 2** was available as a real source. Page 2 is unknown and deliberately not fabricated. The digital revision is UAT-only / pending TSCO Quality approval.
