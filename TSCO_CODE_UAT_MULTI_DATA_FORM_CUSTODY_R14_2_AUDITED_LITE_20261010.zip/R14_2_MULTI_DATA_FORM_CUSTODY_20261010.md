# R14.2 — Multi Data Form + Internal Custody Alignment

Release: **v3.7.5**  
Date: **2026-10-10**

## Controlled scope

This corrective UAT release aligns Client Request, the real Sampling Data Form structure, planned sample identity, field/receiving matching, and internal sample custody without changing locked laboratory/report workflows.

### Request and Sampling Data Form
- One Client Request may contain **multiple Sampling Data Forms**.
- Each Sampling Data Form represents **one transformer / asset / serial number**.
- Each Data Form may contain **one or more physical samples** from that transformer.
- Expected Samples is the aggregate physical-sample count across all Data Forms.
- Supported mixed cases include one transformer with several samples, several transformers with one sample each, and any combination of both.
- Digital form entry uses paper-style selectable controls for fields that are choices on the controlled form.
- User-confirmed Tap Changer sample positions: **H1 / H2 / H3 / Other**.
- Package / Tests / Method / Required TAT remain in Service Scope, outside the Sampling Data Form.
- Routine Package details are previewed from Package Master.

### Lock / revision control
- Client can edit while the request is Draft.
- Submit locks the Client Request and Data Forms.
- The assigned Coordinator may reopen the request for Client Revision; the Client performs the correction and resubmits.
- Existing audit/revision controls remain in place.

### Sample identity and barcode
- After controlled commercial handover, the system creates **one stable Sample ID + Barcode per physical sample** before physical arrival.
- Receiving / Data Entry scans and matches that planned identity; it does not create a new sample identity.
- The same Sample ID + Barcode continues through laboratory execution, review, reporting, custody, and retention.

### Internal custody stage
After receiving/matching, TSCO internal custody adds operational metadata to the **same identity**:
- Transformer Serial
- Sample Type / Sampling Point
- Received At
- Storage Location
- Storage Status

The existing storage model is reused unchanged: Row → Cabinet → Shelf → Slot. No second barcode is created.

### Controlled-document note
The real reference available for this work is **QDF [7]-03-A, Rev.03, Page 1**. The real Page 2 has not been supplied and is not invented in this release. The system-generated barcode schedule is an application page, not claimed to be the missing controlled QDF Page 2. The proposed digital presentation remains subject to Quality controlled-document approval before production adoption.

## Locked areas unchanged
- PF
- QC lifecycle and QC gating
- DGA and BDV controlled result flows
- Senior Review
- Lab Operational & Technical Manager final approval
- Final report content/release logic
- QR verification
- Immediate Client Portal release after final technical release
- BDV/PF grouping
- Existing database data (no reset)
