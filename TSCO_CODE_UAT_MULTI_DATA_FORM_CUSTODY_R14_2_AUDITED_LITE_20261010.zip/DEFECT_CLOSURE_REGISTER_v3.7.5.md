# Defect Closure Register — v3.7.5 / R14.2

## Closed in this corrective release

### CORE-01 — Sampling Data Form / Request source-of-truth alignment
**Status: CLOSED FOR UAT**
- Request supports multiple Data Forms.
- One Data Form represents one transformer/serial and can contain N physical samples.
- Expected Samples aggregates all Data Forms.
- Duplicate manual transformer-serial entry in Service Scope remains removed.

### CORE-02 — Digital Data Form selectable controls
**Status: CLOSED FOR UAT**
- Choice fields are rendered as paper-style selectable controls.
- Confirmed form becomes read-only/printable.
- Tap Changer H1/H2/H3/Other is supported per user-confirmed operation.

### CORE-03 — Mixed transformer/sample cardinality
**Status: CLOSED FOR UAT**
- One transformer → many samples.
- Many transformers → one or many samples each.
- Service Scope maps global physical-sample indices without duplicate coverage.

### CORE-04 — Two-stage barcode/custody continuity
**Status: CLOSED FOR UAT**
- Stage 1 creates one stable Sample ID + Barcode per physical sample before arrival after controlled handover.
- Stage 2 adds Received At, Storage Location and Storage Status internally to the same identity.
- No second barcode is generated.

## Existing separate blocker not closed here
### FR-06 — Released PDF Artifact Persistence
Remains outside this corrective scope. Historical released reports must not be silently regenerated.
