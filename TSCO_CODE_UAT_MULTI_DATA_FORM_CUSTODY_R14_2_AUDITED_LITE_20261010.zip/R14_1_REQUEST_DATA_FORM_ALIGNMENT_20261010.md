# TSCO Digital Laboratory Platform — R14.1 Request / Sampling Data Form Alignment

**Version:** 3.7.4-R14.1-REQUEST-DATA-FORM-ALIGNMENT-20261010  
**Project:** 00012  
**Baseline:** R14 / v3.7.3  
**Date:** 2026-10-10

## Controlled source
This corrective release aligns the Client Request and field-verification path to the real TSCO **Sampling Data Form QDF [7]-03-A, Revision 03, Page 1 of 2** supplied for UAT review. Only fields and options visible on that real Page 1 are treated as source fields. The content of Page 2 is **not available and is not invented or implemented**.

The digital form is labeled **Proposed Digital Revision UAT-01 / pending Quality approval**. It must not be represented as a new controlled QDF revision until TSCO Quality formally approves it.

## Corrected request / Data Form behavior
- Client Request no longer asks for a duplicate manual `Transformer Serial Number(s)` in Service Scope.
- The Sampling Data Form is shown as a single paper-style form rather than a collection of cards.
- Two entry methods use the same structured record:
  1. **Upload Existing Data Form** — PDF, scan, clear photo, typed or handwritten.
  2. **Fill Data Form Online** — same Page-1 field structure with controlled selections for paper checkboxes.
- The original uploaded file is preserved as evidence with hash and attachment record.
- Text PDFs may best-effort prefill proven labels. Scanned images / handwriting are **not falsely claimed as parsed**; they remain `Review Required` until the user confirms the data.
- Proposed digital extension: **Number of Samples** plus one physical-sample line per sample. One transformer/asset record can therefore support multiple samples from different `Sampling From` points without repeating the transformer data.
- After **Save & Confirm Data Form**, the client sees a read-only paper record by default for review/printing. While the overall request is still a draft, `Edit Data Form` explicitly re-enters edit mode. After request submission, the client-owned request is locked.
- Submitted client-owned request/Data Form content can only be reopened by the **assigned Client Coordinator**, with a reason. The client performs the correction and resubmits; prior revision history is retained.

## Service Scope separation
Service Scope remains outside the Sampling Data Form:
- Package / selected tests
- Method family
- Required TAT / exact due date

The Package selector exposes an `ⓘ` package-content preview using the current Package Master so the client can see included tests and methods before submission.

The Data Form supplies the request summary for confirmed sample/asset information, physical sample count and priority. A submitted request requires every physical sample line to be covered by exactly one Service Scope line.

## Planned identity and barcode
- Planned Sample ID / Barcode generation remains on the controlled commercial handover path, before physical sample arrival.
- Before handover, the printable Data Form indicates that identity/barcode is pending controlled handover.
- After handover, the same Data Form PDF is refreshed with one Sample ID and Code128 barcode per physical sample and includes a printable barcode schedule.
- Receiving scans/matches the pre-generated identity; it does not create a new identity.

## Field / Sampleman behavior
- The assigned TSCO Sampleman receives the already-prepared client Data Form and job information.
- Client-owned submitted asset/request information is read-only in the field workflow.
- The Sampleman verifies planned vs actual field identity.
- **Match:** accept and record actual execution data.
- **Mismatch:** no silent overwrite and no sampling completion. A discrepancy record is created and Operations Manager + assigned Coordinator are notified. The Coordinator can reopen the request for client correction.

## Explicitly unchanged / out of scope
- Final Report generation/release pipeline
- Senior Chemist review
- Lab Operational & Technical Manager final release
- Client Portal immediate approved-report availability
- QR verification behavior
- QC lifecycle and QC gates
- PF workflow
- BDV/PF grouping
- DGA and BDV locked instrument-file behavior
- Existing database records; no DB reset
- FR-06 historical released-PDF artifact persistence remains a separate blocker and is **not** masked by silent regeneration.
