# TSCO Digital Laboratory Platform v2.6.9

Integrated laboratory operations web application for the complete sample lifecycle, including controlled field-sampling requests and direct client-delivered samples.

Current package status: **LMS-aligned Production Deployment Candidate for controlled corporate UAT**. Production go-live still requires the company environment, security, LMS integration and organizational acceptance gates.

Start with `START_HERE.md`. Final verification: `FINAL_VERIFICATION_v2.6.9.md`. Special-test method completion items: `MASTER_DATA_COMPLETION_NOTES_v2.6.9.md`.

Core application: FastAPI + SQLAlchemy. Local developer review uses SQLite. Shared deployment supports PostgreSQL/Docker. The LMS integration boundary is isolated under `app/integrations/lms/`; the current connector remains a mock adapter until IT provides the official LMS interface/API specification.

**Reporting boundary:** the platform approves results as `READY_FOR_LMS`; LMS performs final job closure and issues the official client report. See `SYSTEM_BOUNDARY_LMS_REPORTING.md`.

**v2.6.9 final-UAT alignment:** Data Review, LMS Registration, Physical Receiving and Sample Batch/Distribution are presented as one **Sample Intake & Distribution** workspace. Direct client-delivered paper samples enter the same controlled intake path. Sampling Supervision can raise an operational request to Operations, which creates the official Sampling Order. Senior Chemist owns retained-sample operations; Quality has compliance/QC and read-only site audit visibility. The Quality workspace now digitizes the monthly Quality Control Distribution with server-generated Primary/Backup chemist rotation for equipment/safety and materials/gases/storage routine checks.

**v2.6.9 laboratory control correction:** analytical access is now role + assignment scoped on the server. Chemists can be assigned as Single, Primary+Backup, or All Laboratory Chemists; the actual logged-in actor is retained on results. Operational workstation grouping was corrected to Water, Electrical, DGA, Furan/Passivator, DBDS/BHT/Toluene/PCB, TAN/Peroxide/RSH/H2S, Corrosion/CCD, and Physical/Chemistry. Analytical/Test QC remains separate from the independent Monthly/Routine QC assignment. Controlled documents can be linked to workstation, test and method. See `V2.6.9_FINAL_INTEGRITY_HARDENING.md` and the inherited v2.6.8 functional corrections in `V2.6.8_FINAL_UAT_CORRECTIONS.md`.

## v2.6 developer baseline

The developer-review package now includes:

- Multi-client master data and isolated client portal accounts.
- Multi-site structure for Dammam, Jubail, Bahrain and future sites.
- Site-scoped operational users plus corporate management visibility across sites.
- Platform-admin configuration for sites, clients, users/access, controlled SOP/Method/EOP revisions and test packages without source-code edits.
- Database-backed configuration changes that become available while the application remains running.
- Existing sample lifecycle, laboratory operations, audit, barcode, technical assessment and client tracking.

Code-level feature changes still require a normal application deployment. Production-grade zero-downtime deployment, backups, SSO/security and the official LMS connector are finalized with IT.


## Architecture Baseline
Adds Corporate/Site/Department hierarchy, client organization units, runtime workflow versioning, approval-policy configuration, master-data center, and an integration control queue. See `docs/15_ENTERPRISE_ARCHITECTURE_BASELINE_v2.4.md`.

## v2.6 Laboratory workspace integration
The established Laboratory Operations module is now presented inside one continuous platform shell: one sidebar, one top bar, no duplicate laboratory navigation, synchronized section routing and automatic content-height sizing.


## v2.6 Client Hierarchy
Client access supports company-wide or scoped organization visibility (region/area/project/facility/station) with descendant inheritance. See `docs/16_CLIENT_HIERARCHICAL_ACCESS_v2.6.md`.
