from __future__ import annotations

from .models import Role

LAB_SECTION_INFO = {
    "dashboard": ("Operations Overview", "Management-level laboratory flow, workload and operational status."),
    "labprogress": ("Laboratory Progress", "Live team board showing sample priority, assignment and completion progress."),
    "supervisor": ("Technical Supervision", "Senior Chemist result search, review, retest, release and technical actions."),
    "batch": ("Batch Diagnostics", "Admin-only compatibility view. Operational sample batching is owned by Sample Intake & Distribution."),
    "workstations": ("Test Workstations", "Enter results with quick procedures, method references and calculation support."),
    "finalreport": ("Reports", "Review controlled worksheet results, revisions and Technical Manager approval for LMS submission."),
    "retained": ("Retained Samples", "Storage location, retention period, due dates and controlled disposal."),
    "quality": ("Quality Control", "Monthly Quality Distribution, equipment/safety and materials/gas checks, QC status, exceptions and compliance oversight."),
    "knowledge": ("Methods & Procedures", "Controlled methods, SOPs, EOPs and quick operating guidance."),
    "tracking": ("Operations Records", "Searchable sample history, result actions and operational records."),
    "general": ("Laboratory Settings", "Site, staff, document and controlled calculation configuration."),
}

LAB_ROLE_SECTIONS = {
    Role.LAB_TECHNICIAN.value: {"workstations", "quality", "knowledge"},
    Role.SENIOR_CHEMIST.value: {"dashboard", "labprogress", "supervisor", "workstations", "finalreport", "retained", "quality", "knowledge", "tracking"},
    Role.QUALITY.value: {"dashboard", "labprogress", "finalreport", "retained", "quality", "knowledge", "tracking"},
    Role.TECHNICAL_MANAGER.value: {"dashboard", "labprogress", "supervisor", "workstations", "finalreport", "retained", "quality", "knowledge", "tracking", "general"},
    Role.MANAGEMENT.value: {"dashboard", "labprogress", "finalreport", "tracking"},
    Role.SYSTEM_ADMIN.value: set(LAB_SECTION_INFO),
}



def lab_section_allowed(role: str, section: str) -> bool:
    return section in LAB_ROLE_SECTIONS.get(role, set())
