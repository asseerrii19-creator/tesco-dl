from __future__ import annotations
from datetime import datetime, timedelta
from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import (TechnicalResultRule, EquipmentAsset, CompetencyRecord, StaffAvailability,
    QualityCase, Site, User, Client, Asset, SampleRequest, ControlledReport, EvidenceRecord)


def login(client,email):
    r=client.post('/login',data={'email':email,'password':'Demo123!'},follow_redirects=False)
    assert r.status_code==303


def test_confirmed_ltd_rules_and_equipment_master_are_seeded():
    with TestClient(app):
        with SessionLocal() as db:
            dmm=db.scalar(select(Site).where(Site.code=='DMM'))
            furan=db.scalar(select(TechnicalResultRule).where(TechnicalResultRule.site_id==dmm.id,TechnicalResultRule.result_field=='2-Furfural (2FAL)'))
            tan=db.scalar(select(TechnicalResultRule).where(TechnicalResultRule.site_id==dmm.id,TechnicalResultRule.result_field=='Total Acid Number'))
            assert furan.detection_limit==0.01 and 'DP >1000' in furan.downstream_rule
            assert tan.detection_limit==0.010
            assert db.scalar(select(EquipmentAsset).where(EquipmentAsset.site_id==dmm.id,EquipmentAsset.equipment_id=='EQ-64')).workstation=='DGA'
            assert db.scalar(select(EquipmentAsset).where(EquipmentAsset.site_id==dmm.id,EquipmentAsset.equipment_id=='EQ-69')).workstation=='Water'


def test_competency_weighting_and_authorization_are_server_calculated():
    with TestClient(app) as c:
        login(c,'quality@tsco.local')
        with SessionLocal() as db: chem=db.scalar(select(User).where(User.email=='chemist@tsco.local')); uid=chem.id
        r=c.post('/control/competency',data={'user_id':uid,'test_name':'Water Content','method_name':'IEC 60814','workstation':'Water','category':4,'technical_score':'95','data_processing_score':'91','evidence_reference':'QDF [6]-02-B'},follow_redirects=False)
        assert r.status_code==303
        with SessionLocal() as db:
            row=db.scalar(select(CompetencyRecord).where(CompetencyRecord.user_id==uid,CompetencyRecord.workstation=='Water').order_by(CompetencyRecord.id.desc()))
            assert row.overall_score==94.0 and row.authorization=='INDEPENDENT'


def test_schedule_rejects_overlapping_approved_entries():
    with TestClient(app) as c:
        login(c,'senior@tsco.local')
        with SessionLocal() as db: uid=db.scalar(select(User).where(User.email=='chemist@tsco.local')).id
        start=(datetime.utcnow()+timedelta(days=10)).replace(microsecond=0); end=start+timedelta(days=5)
        payload={'user_id':uid,'entry_type':'LEAVE','start_at':start.isoformat(timespec='minutes'),'end_at':end.isoformat(timespec='minutes'),'status':'APPROVED','shift_code':'','notes':'Annual plan'}
        assert c.post('/control/schedule',data=payload,follow_redirects=False).status_code==303
        payload.update({'entry_type':'ON_CALL','start_at':(start+timedelta(days=1)).isoformat(timespec='minutes'),'end_at':(start+timedelta(days=1,hours=8)).isoformat(timespec='minutes')})
        r=c.post('/control/schedule',data=payload,follow_redirects=False)
        assert r.status_code==400 and 'conflicts' in r.text.lower()


def test_capa_cannot_close_without_root_cause_action_and_effectiveness():
    with TestClient(app) as c:
        login(c,'quality@tsco.local')
        r=c.post('/control/case',data={'case_type':'CAPA','title':'QC excursion','priority':'HIGH'},follow_redirects=False); assert r.status_code==303
        with SessionLocal() as db: case=db.scalar(select(QualityCase).where(QualityCase.case_type=='CAPA').order_by(QualityCase.id.desc())); cid=case.id
        bad=c.post(f'/control/case/{cid}/update',data={'status':'CLOSED','root_cause':'','corrective_action':'','effectiveness_review':'','raw_runs_json':'','calculation_json':'','evidence_reference':''},follow_redirects=False)
        assert bad.status_code==400
        good=c.post(f'/control/case/{cid}/update',data={'status':'CLOSED','root_cause':'Reference drift','corrective_action':'Recalibrated and reran QC','effectiveness_review':'Three acceptable checks','raw_runs_json':'','calculation_json':'','evidence_reference':'CAPA evidence'},follow_redirects=False)
        assert good.status_code==303


def _ensure_sample():
    with SessionLocal() as db:
        dmm=db.scalar(select(Site).where(Site.code=='DMM')); client=db.scalar(select(Client).where(Client.code=='SEC')); asset=db.scalar(select(Asset).where(Asset.client_id==client.id))
        sample=db.scalar(select(SampleRequest).where(SampleRequest.request_number=='TSCO-270-REPORT-TEST'))
        if not sample:
            sample=SampleRequest(request_number='TSCO-270-REPORT-TEST',public_token='PUB-270-REPORT',barcode_value='BAR-270-REPORT',status='TECHNICAL_REVIEW',site_id=dmm.id,client_id=client.id,asset_id=asset.id,sample_date_time=datetime.utcnow(),sampling_point='Main Tank / Bottom',sample_origin='Client-Originated / Direct Delivery')
            db.add(sample); db.commit(); db.refresh(sample)
        return sample.id


def test_report_release_requires_dga_and_corrosive_controlled_evidence():
    with TestClient(app) as c:
        sid=_ensure_sample(); login(c,'senior@tsco.local')
        number=f'DM-TEST-{datetime.utcnow().timestamp():.0f}'
        r=c.post('/control/report',data={'sample_request_id':sid,'report_number':number,'condition_status':'NORMAL','interpretation':'Review','recommendation':'Annual sample','dga_requested':'1','corrosive_requested':'1'},follow_redirects=False); assert r.status_code==303
        with SessionLocal() as db: rid=db.scalar(select(ControlledReport).where(ControlledReport.report_number==number)).id
        c.post('/logout'); login(c,'technical@tsco.local')
        blocked=c.post(f'/control/report/{rid}/approve',follow_redirects=False); assert blocked.status_code==400
        c.post('/logout'); login(c,'quality@tsco.local')
        for typ in ['DGA_SOURCE','CORROSIVE_FRONT','CORROSIVE_BACK']:
            up=c.post('/control/evidence',data={'evidence_type':typ,'title':typ,'sample_request_id':str(sid),'quality_case_id':'','equipment_asset_id':'','method_name':'','run_reference':'R1'},files={'upload':(f'{typ}.txt',b'evidence')},follow_redirects=False); assert up.status_code==303
        c.post('/logout'); login(c,'technical@tsco.local')
        ok=c.post(f'/control/report/{rid}/approve',follow_redirects=False); assert ok.status_code==303
        with SessionLocal() as db: assert db.get(ControlledReport,rid).status=='READY_FOR_LMS'


def test_troubleshooting_requires_senior_then_technical_manager_for_publish():
    with TestClient(app) as c:
        login(c,'chemist@tsco.local')
        r=c.post('/control/troubleshooting',data={'test_name':'DGA','method_name':'IEC 60567','equipment_asset_id':'','workstation':'DGA','problem':'Autosampler stopped','symptoms':'Sequence halted','actions_taken':'Stopped run','safety_impact':'None','result_integrity_impact':'Run incomplete','lessons':'Escalate'},follow_redirects=False); assert r.status_code==303
        from app.models import TroubleshootingRecord
        with SessionLocal() as db: tid=db.scalar(select(TroubleshootingRecord).order_by(TroubleshootingRecord.id.desc())).id
        c.post('/logout'); login(c,'technical@tsco.local')
        premature=c.post(f'/control/troubleshooting/{tid}/transition',data={'status':'PUBLISHED','root_cause':'Autosampler fault'},follow_redirects=False); assert premature.status_code==400
        c.post('/logout'); login(c,'senior@tsco.local'); assert c.post(f'/control/troubleshooting/{tid}/transition',data={'status':'SENIOR_VERIFIED','root_cause':'Autosampler fault'},follow_redirects=False).status_code==303
        c.post('/logout'); login(c,'technical@tsco.local'); assert c.post(f'/control/troubleshooting/{tid}/transition',data={'status':'PUBLISHED','root_cause':'Autosampler fault'},follow_redirects=False).status_code==303


def test_control_center_and_public_report_verification_render():
    with TestClient(app) as c:
        login(c,'quality@tsco.local'); assert c.get('/control').status_code==200
        with SessionLocal() as db: report=db.scalar(select(ControlledReport).order_by(ControlledReport.id.desc()))
        if report:
            c.post('/logout'); page=c.get(f'/verify/report/{report.qr_token}'); assert page.status_code==200 and report.report_number in page.text

def test_dga_offline_parser_recognizes_nine_gases_and_requires_confirmation():
    from app.routes.control_center import _parse_dga_bytes
    data=b'H2,42\nO2,9149\nN2,81687\nCH4,59\nCO,459\nCO2,1385\nC2H4,12\nC2H6,68\nC2H2,0.5\n'
    parsed=_parse_dga_bytes('export.csv',data)
    assert parsed['complete'] is True and parsed['recognized']==9 and parsed['gases']['C2H2']==0.5
