from datetime import datetime

import pytest
from sqlalchemy import select

from app.database import SessionLocal
from app.models import Client, CustodyEvent, Role, SampleRequest, SampleStatus, Site, User
from app.services.workflow import confirm_lms_official_report_issued


def _sample(db, status):
    site = db.scalar(select(Site).where(Site.code == "DMM"))
    client = db.scalar(select(Client).where(Client.code == "SEC"))
    sampler = db.scalar(select(User).where(User.role == Role.FIELD_SAMPLER.value))
    assert site and client and sampler
    # Reuse an existing seeded asset if available through a sample; these tests only need state transition logic.
    existing = db.scalar(select(SampleRequest).limit(1))
    if existing:
        existing.status = status
        existing.released_at = None
        db.flush()
        return existing
    pytest.skip("Seeded sample fixture unavailable")


def test_official_report_cannot_be_claimed_before_lms_ready_state():
    with SessionLocal() as db:
        sample = _sample(db, SampleStatus.REPORT_APPROVED.value)
        with pytest.raises(ValueError, match="Official LMS report cannot be issued"):
            confirm_lms_official_report_issued(db, sample, report_reference="LMS-RPT-1")


def test_lms_confirmation_is_the_only_terminal_official_release_boundary():
    with SessionLocal() as db:
        sample = _sample(db, SampleStatus.READY_FOR_LMS.value)
        before = datetime.utcnow()
        confirm_lms_official_report_issued(db, sample, report_reference="LMS-RPT-1")
        assert sample.status == SampleStatus.REPORT_RELEASED.value
        assert sample.released_at is not None and sample.released_at >= before
        db.flush()
        event = db.scalar(select(CustodyEvent).where(CustodyEvent.sample_request_id == sample.id, CustodyEvent.event_type == "LMS_OFFICIAL_REPORT_ISSUED"))
        assert event is not None
