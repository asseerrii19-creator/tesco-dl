from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from urllib.parse import quote_plus

from fastapi import APIRouter, Depends, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import Client, Role, Site
from ..lab_sections import LAB_ROLE_SECTIONS, LAB_SECTION_INFO
from ..security import require_user
from ..services.lab_operations import blank_operations_db, get_operations_state, merge_scoped_operations_update, package_catalog, reconcile_operations_to_platform, save_operations_state, scope_operations_payload, validate_operations_update
from ..services.audit import add_audit

router = APIRouter(tags=["integrated laboratory operations"])
ALLOWED = {
    Role.LAB_TECHNICIAN.value, Role.SENIOR_CHEMIST.value, Role.QUALITY.value,
    Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value,
}
WRITE_ALLOWED = ALLOWED - {Role.MANAGEMENT.value}
BASE_DIR = Path(__file__).resolve().parents[1]
TEMPLATE_FILE = BASE_DIR / "lab_ops" / "index_template.html"

SECTION_INFO = LAB_SECTION_INFO
ROLE_SECTIONS = LAB_ROLE_SECTIONS

def _script_json(value) -> str:
    """Serialize data for an inline <script> without allowing HTML/script termination."""
    return (
        json.dumps(value, ensure_ascii=False)
        .replace("&", "\\u0026")
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("\u2028", "\\u2028")
        .replace("\u2029", "\\u2029")
    )


def _site_for_user(db: Session, user) -> Site:
    site = db.get(Site, user.site_id) if user.site_id else None
    if not site:
        site = db.query(Site).filter(Site.code == "DMM").first()
    return site


def _authorized_section(user, requested: str) -> str:
    allowed = ROLE_SECTIONS.get(user.role, set())
    if not allowed:
        raise HTTPException(status_code=403, detail="This role has no Laboratory Operations workspace")
    requested = (requested or "").strip()
    if not requested:
        preferred = ["workstations", "supervisor", "quality", "labprogress", "dashboard", "knowledge"]
        return next((item for item in preferred if item in allowed), sorted(allowed)[0])
    if requested not in SECTION_INFO:
        raise HTTPException(status_code=404, detail="Laboratory section not found")
    if requested not in allowed:
        raise HTTPException(status_code=403, detail="This laboratory section is not authorized for the current role")
    return requested


@router.get("/lab/operations")
def operations_shell(request: Request, section: str = "", workstation: str = "", db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    section = _authorized_section(user, section)
    title, description = SECTION_INFO[section]
    allowed_sections = ROLE_SECTIONS.get(user.role, {section})
    visible_info = {k: {"title": SECTION_INFO[k][0], "description": SECTION_INFO[k][1]} for k in allowed_sections if k in SECTION_INFO}
    return templates.TemplateResponse(
        "lab_operations.html",
        {"request": request, "user": user, "section": section, "section_title": title, "section_description": description, "section_info": visible_info, "workstation": workstation, "workstation_query": quote_plus(workstation)},
    )


@router.get("/lab/operations/app", response_class=HTMLResponse)
def operations_console(request: Request, section: str = "", workstation: str = "", embed: int = 1, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    section = _authorized_section(user, section)
    html = TEMPLATE_FILE.read_text(encoding="utf-8")
    site = _site_for_user(db, user)
    active_clients = db.query(Client).filter(Client.active.is_(True)).order_by(Client.name).all()
    central_clients = [{"id": str(row.id), "name": row.name, "code": row.code, "active": True} for row in active_clients]
    central_packages = package_catalog(db, site.id)
    embed_css = """
    <style id="platformEmbedStyle">
      html,body{background:transparent!important}
      body.platform-embed{min-height:0!important;background:transparent!important;overflow:hidden!important}
      body.platform-embed>header,body.platform-embed>nav{display:none!important}
      body.platform-embed main{padding:0 2px 24px!important;margin:0!important;max-width:none!important}
      body.platform-embed .page{scroll-margin-top:0!important}
      body.platform-embed .page.on{animation:none!important}
      body.platform-embed .dashboard-hero{margin-top:0!important}
      body.platform-embed .card{box-shadow:0 2px 10px rgba(16,42,67,.055)!important}
      body.platform-embed .modal{position:fixed!important}
      @media(max-width:760px){body.platform-embed main{padding:0 0 18px!important}}
    </style>
    """ if embed else ""
    injection = (
        embed_css
        + f"<script>window.TSCO_PLATFORM_ROLE={_script_json(user.role)};"
        + f"window.TSCO_PLATFORM_USER={_script_json(user.full_name)};"
        + f"window.TSCO_PLATFORM_USER_ID={_script_json(user.id)};"
        + f"window.TSCO_PLATFORM_SITE={_script_json(user.site.code if user.site else 'DMM')};"
        + f"window.TSCO_PLATFORM_SECTION={_script_json(section)};"
        + f"window.TSCO_PLATFORM_WORKSTATION={_script_json(workstation)};"
        + f"window.TSCO_PLATFORM_ALLOWED_SECTIONS={_script_json(sorted(ROLE_SECTIONS.get(user.role, {section})))};"
        + f"window.TSCO_PLATFORM_CLIENTS={_script_json(central_clients)};"
        + f"window.TSCO_PLATFORM_TEST_PACKAGES={_script_json(central_packages)};"
        + f"window.TSCO_PLATFORM_EMBED={_script_json(bool(embed))};</script>"
    )
    html = html.replace("</head>", injection + "</head>", 1)
    boot = """
    <script>
    (function(){
      const embedded=!!window.TSCO_PLATFORM_EMBED;
      if(embedded){document.body.classList.add('platform-embed');}
      function notifyHeight(){
        if(!embedded||window.parent===window)return;
        const h=Math.max(document.documentElement.scrollHeight,document.body.scrollHeight,620);
        window.parent.postMessage({type:'TSCO_LAB_HEIGHT',height:h},location.origin);
      }
      function notifySection(section){
        if(!embedded||window.parent===window||!section)return;
        window.parent.postMessage({type:'TSCO_LAB_SECTION_CHANGE',section:String(section)},location.origin);
      }
      function openRequested(){
        const section=window.TSCO_PLATFORM_SECTION;
        const workstation=window.TSCO_PLATFORM_WORKSTATION;
        if(typeof goPage==='function'&&section){try{goPage(section)}catch(_){}}
        if(section==='workstations'&&workstation&&typeof openWs==='function'){
          try{openWs(workstation)}catch(_){}
        }
        setTimeout(notifyHeight,80);
      }
      function wrapNavigation(){
        if(typeof goPage!=='function'||goPage.__platformWrapped)return;
        const original=goPage;
        const wrapped=function(section){
          const result=original.apply(this,arguments);
          notifySection(section);
          setTimeout(notifyHeight,50);
          setTimeout(notifyHeight,220);
          return result;
        };
        wrapped.__platformWrapped=true;
        window.goPage=wrapped;
      }
      function pruneUnauthorizedPages(){
        const allowed=new Set(Array.isArray(window.TSCO_PLATFORM_ALLOWED_SECTIONS)?window.TSCO_PLATFORM_ALLOWED_SECTIONS:[]);
        document.querySelectorAll('main .page[id]').forEach(page=>{if(!allowed.has(page.id))page.remove();});
        document.querySelectorAll('nav button[data-p]').forEach(btn=>{if(!allowed.has(btn.dataset.p))btn.remove();});
      }
      function boot(){
        openRequested();
        wrapNavigation();
        pruneUnauthorizedPages();
        if(window.ResizeObserver){new ResizeObserver(()=>requestAnimationFrame(notifyHeight)).observe(document.body);}
        window.addEventListener('resize',notifyHeight);
        window.addEventListener('load',notifyHeight);
        document.addEventListener('click',()=>setTimeout(notifyHeight,120),true);
        setTimeout(notifyHeight,350);
      }
      if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
      window.addEventListener('message',event=>{
        if(event.origin!==location.origin)return;
        if(event.data&&event.data.type==='TSCO_LAB_SECTION'&&typeof goPage==='function'){
          goPage(event.data.section);
          setTimeout(notifyHeight,80);
        }
      });
    })();
    </script>
    """
    # Insert at the real document closing tag. The laboratory template contains
    # a literal </body> inside the batch-print JavaScript template string; using
    # str.replace(..., 1) injected this boot script into that JavaScript and
    # broke the entire embedded console at runtime.
    body_close = html.rfind("</body>")
    if body_close < 0:
        raise RuntimeError("Laboratory operations template is missing </body>")
    html = html[:body_close] + boot + html[body_close:]
    return HTMLResponse(html)


@router.get("/lab-ops/documents/{filename}")
def protected_document(filename: str, request: Request, db: Session = Depends(get_db)):
    require_user(request, db, ALLOWED)
    # Legacy embedded method/SOP files are intentionally not served as a second
    # controlled-document source. Approved revisions live in the central library.
    return RedirectResponse("/documents", status_code=303)


@router.get("/api/lab-operations/data")
def operations_load(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    site = _site_for_user(db, user)
    state, payload = get_operations_state(db, site)
    # Persist a newly materialized monthly Quality Distribution on the actual browser/API load.
    # get_operations_state itself remains read-safe for internal validation/restore flows, so it
    # never surprises an in-flight optimistic-lock update by incrementing the revision.
    try:
        durable = json.loads(state.json_data or "{}")
    except (json.JSONDecodeError, TypeError):
        durable = {}
    durable_ids = {
        str(row.get("id")) for row in durable.get("qualityDistributions", [])
        if isinstance(row, dict) and row.get("id")
    }
    materialized_ids = {
        str(row.get("id")) for row in payload.get("qualityDistributions", [])
        if isinstance(row, dict) and row.get("id")
    }
    if materialized_ids - durable_ids:
        save_operations_state(db, state, payload, actor=None)
    db.commit()
    visible = scope_operations_payload(payload, user)
    return {"db": visible, "savedAt": state.updated_at.isoformat() if state.updated_at else datetime.utcnow().isoformat(), "revision": state.revision}


@router.get("/api/lab-operations/backup")
def operations_backup(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value})
    site = _site_for_user(db, user)
    state, payload = get_operations_state(db, site)
    db.commit()
    return {
        "format": "TSCO-LAB-OPERATIONS-SERVER-BACKUP",
        "version": "2.8.3",
        "exportedAt": datetime.utcnow().isoformat(),
        "site": site.code,
        "revision": state.revision,
        "db": payload,
    }


@router.put("/api/lab-operations/data")
async def operations_save(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, WRITE_ALLOWED)
    site = _site_for_user(db, user)
    max_bytes = 5_000_000
    try:
        declared_size = int(request.headers.get("content-length") or 0)
    except ValueError:
        declared_size = 0
    if declared_size > max_bytes:
        return JSONResponse({"error": "Laboratory synchronization payload is too large"}, status_code=413)
    chunks: list[bytes] = []
    total = 0
    async for chunk in request.stream():
        total += len(chunk)
        if total > max_bytes:
            return JSONResponse({"error": "Laboratory synchronization payload is too large"}, status_code=413)
        chunks.append(chunk)
    try:
        body = json.loads(b"".join(chunks) or b"{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return JSONResponse({"error": "Invalid JSON payload"}, status_code=400)
    if not isinstance(body, dict):
        return JSONResponse({"error": "Invalid operations request"}, status_code=400)
    state, current = get_operations_state(db, site)
    try:
        client_revision = int(body.get("clientRevision", -1))
    except (TypeError, ValueError):
        client_revision = -1
    if client_revision != int(state.revision or 0):
        return JSONResponse(
            {"error": "Sync conflict: server data changed since this page was loaded", "revision": state.revision, "db": scope_operations_payload(current, user)},
            status_code=409,
        )

    operation = body.get("operation")
    new_quality_events: list[dict] = []
    new_test_assignments: list[dict] = []
    if operation == "reset-operational":
        if user.role != Role.SYSTEM_ADMIN.value or body.get("confirmation") != "DELETE SITE DATA":
            return JSONResponse({"error": "Reset requires system administrator"}, status_code=403)
        payload = blank_operations_db(site)
        add_audit(db, actor=user, request=request, action="LAB_OPERATIONS_RESET", entity_type="OperationsState", entity_id=state.id, summary=f"Reset operational data for {site.code}")
    elif operation == "restore-backup":
        if user.role != Role.SYSTEM_ADMIN.value:
            return JSONResponse({"error": "Backup restore requires system administrator"}, status_code=403)
        backup = body.get("backup") or {}
        incoming = backup.get("db") if isinstance(backup, dict) else None
        if not isinstance(backup, dict) or backup.get("format") not in {"TSCO-LAB-OPERATIONS-SERVER-BACKUP", "TSCO-TRANSFORMER-OIL-LAB-OPERATIONS-BACKUP"}:
            return JSONResponse({"error": "Invalid TSCO operations backup format"}, status_code=400)
        backup_site = str(backup.get("site") or "").strip().upper()
        if backup.get("format") == "TSCO-LAB-OPERATIONS-SERVER-BACKUP" and backup_site != site.code:
            return JSONResponse({"error": "Backup belongs to a different laboratory site"}, status_code=400)
        if backup_site and backup_site != site.code:
            return JSONResponse({"error": "Backup belongs to a different laboratory site"}, status_code=400)
        if not isinstance(incoming, dict) or not isinstance(incoming.get("batches"), list) or not isinstance(incoming.get("results"), list):
            return JSONResponse({"error": "Invalid TSCO operations backup data"}, status_code=400)
        list_fields = ("batches", "results", "qc", "qualifiedQcProfiles", "reports", "retained", "retests", "storageAssignments", "batchHistory", "cancelledSamples", "supervisorNotes", "standards", "dgaAttachments", "qualityDistributions", "qualityTaskEvents", "testAssignments", "clients", "customPackages", "formulaDefinitions", "staff", "samplePoints")
        dict_fields = ("calculationDrafts", "testUnits", "drafts", "settings", "meta")
        if any(key in incoming and not isinstance(incoming.get(key), list) for key in list_fields):
            return JSONResponse({"error": "Backup contains an invalid list field"}, status_code=400)
        if any(key in incoming and not isinstance(incoming.get(key), dict) for key in dict_fields):
            return JSONResponse({"error": "Backup contains an invalid object field"}, status_code=400)
        unknown = set(incoming) - set(current)
        if unknown:
            return JSONResponse({"error": "Backup contains unsupported database fields"}, status_code=400)
        payload = dict(current)
        payload.update(incoming)
        # Never restore browser copies of centrally administered master data/configuration.
        for key in ("clients", "customPackages", "formulaDefinitions", "staff", "samplePoints", "testUnits", "settings"):
            payload[key] = current.get(key)
        payload["meta"] = current.get("meta")
        add_audit(
            db, actor=user, request=request, action="LAB_OPERATIONS_BACKUP_RESTORED", entity_type="OperationsState", entity_id=state.id,
            summary=f"Restored operational backup for {site.code}", details={"backup_exported_at": backup.get("exportedAt", ""), "backup_revision": backup.get("revision", "")},
        )
    else:
        incoming = body.get("db") or scope_operations_payload(current, user)
        try:
            payload = merge_scoped_operations_update(current, incoming, user)
            payload = validate_operations_update(current, payload, user, db=db, site_id=site.id)
            existing_quality_event_ids = {str(row.get("id")) for row in current.get("qualityTaskEvents", [])}
            new_quality_events = [row for row in payload.get("qualityTaskEvents", []) if str(row.get("id")) not in existing_quality_event_ids]
            existing_assignment_ids = {str(row.get("id")) for row in current.get("testAssignments", [])}
            new_test_assignments = [row for row in payload.get("testAssignments", []) if str(row.get("id")) not in existing_assignment_ids]
        except PermissionError as exc:
            return JSONResponse({"error": str(exc)}, status_code=403)
        except ValueError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)

    save_operations_state(db, state, payload, user)
    for assignment in new_test_assignments:
        add_audit(
            db, actor=user, request=request, action="LAB_WORKSTATION_ASSIGNED",
            entity_type="LaboratoryWorkstationAssignment", entity_id=str(assignment.get("id") or ""),
            summary=f"{assignment.get('workstation', 'Workstation')} assigned for {assignment.get('batch_id', '')}",
            details={
                "mode": assignment.get("mode"), "primary": assignment.get("primary_name", ""),
                "backup": assignment.get("backup_name", ""), "revision": assignment.get("revision"),
            },
        )
    for event in new_quality_events:
        add_audit(
            db, actor=user, request=request, action="QUALITY_ROUTINE_CHECK_RECORDED",
            entity_type="QualityRoutineCheck", entity_id=str(event.get("assignment_id") or event.get("id")),
            summary=f"{event.get('task', 'Quality check')} — {event.get('status', '')}",
            details={
                "distribution_id": event.get("distribution_id"), "period": event.get("period_label"),
                "domain": event.get("domain"), "note": event.get("note", ""),
            },
        )
    reconcile_operations_to_platform(db, payload, site.id, user)
    db.commit()
    return {"ok": True, "db": scope_operations_payload(payload, user), "savedAt": state.updated_at.isoformat(), "revision": state.revision}
