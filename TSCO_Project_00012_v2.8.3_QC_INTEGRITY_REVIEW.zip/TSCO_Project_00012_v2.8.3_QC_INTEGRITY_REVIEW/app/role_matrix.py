from __future__ import annotations

from .models import Role

ROLE_REVIEW_MATRIX = {
    Role.CLIENT_OPERATIONS.value: {
        "name": "Client Operations",
        "purpose": "Submit and follow authorized client sampling demand within the client account scope without internal laboratory visibility.",
        "primary": ["Client Sampling Requests", "Authorized Asset Structure", "Field Status"],
        "must_not": ["Internal laboratory controls", "Other clients' assets", "Unreleased results"],
    },
    Role.CLIENT_SAMPLER.value: {
        "name": "Client Sampler",
        "purpose": "Execute authorized client-side sampling work against approved assets and sampling points.",
        "primary": ["My Field Work", "Authorized Asset Structure"],
        "must_not": ["Internal laboratory controls", "Other clients' data", "Management dashboards"],
    },
    Role.OPERATIONS_MANAGER.value: {
        "name": "Operations Manager",
        "purpose": "Own sampling demand, field progress, intake handoff, TAT visibility and operational exceptions without performing laboratory technical work.",
        "primary": ["Operations Overview", "Sampling Orders", "Sampling Assignments", "Field Progress", "Intake & Laboratory Handoff", "Continuous Improvement", "Asset Structure"],
        "must_not": ["Enter analytical results", "Perform laboratory QC", "Approve Senior Chemist technical decisions"],
    },
    Role.SAMPLING_SUPERVISOR.value: {
        "name": "Sampling Supervisor",
        "purpose": "Assign and follow field sampling work, availability and completion quality.",
        "primary": ["Sampling Supervision", "Field Progress", "Asset Structure", "Continuous Improvement"],
        "must_not": ["Laboratory result entry", "Technical assessment", "Final report release"],
    },
    Role.FIELD_SAMPLER.value: {
        "name": "Field Sampler",
        "purpose": "Execute only assigned field work and capture controlled transformer/site/sample evidence.",
        "primary": ["My Field Work", "Asset Structure", "Continuous Improvement"],
        "must_not": ["See unassigned field orders", "Laboratory controls", "Management dashboards"],
    },
    Role.DATA_ENTRY.value: {
        "name": "Data Entry",
        "purpose": "Review incoming information, register in LMS, and prepare controlled intake/distribution records.",
        "primary": ["Sample Intake & Distribution", "Asset Structure", "Continuous Improvement"],
        "must_not": ["Physical receiving sign-off unless separately authorized", "Laboratory result entry", "Technical release"],
    },
    Role.SAMPLE_RECEIVING.value: {
        "name": "Sample Receiving",
        "purpose": "Record physical receipt, container condition and custody handoff.",
        "primary": ["Physical Receiving", "Asset Structure", "Continuous Improvement"],
        "must_not": ["LMS data approval", "Laboratory result entry", "Technical review"],
    },
    Role.LAB_TECHNICIAN.value: {
        "name": "Laboratory Chemist / Technician",
        "purpose": "Execute assigned analytical work, enter results, complete assigned QC/validation tasks and use controlled methods.",
        "primary": ["Test Workstations", "My QC / Validation Tasks", "Methods & Procedures", "Controlled Documents", "My Availability", "Submit Improvement Opportunity"],
        "must_not": ["Senior Chemist technical approval", "Final LMS approval", "Management-only controls"],
    },
    Role.SENIOR_CHEMIST.value: {
        "name": "Senior Chemist",
        "purpose": "Supervise laboratory workload, review results, control retest/resample, retained samples and technical assessment.",
        "primary": ["Technical Supervision", "Laboratory Progress", "Technical Assessment", "QC Oversight", "Retained Samples", "Reports", "Methods & Procedures", "Operations Records", "My Availability", "Continuous Improvement (submit / progress assigned lab actions)"],
        "must_not": ["Routine analytical result entry", "Personal QC / Validation task execution", "Management dashboard as an operating workspace", "Final LMS release"],
    },
    Role.QUALITY.value: {
        "name": "Quality",
        "purpose": "Govern QC, validation/verification, ILC/PT, NCR/CAPA, competency, evidence, audit and controlled documents.",
        "primary": ["Quality Control", "Validation & Quality Center", "Quality & Audit Trail", "Controlled Documents", "Methods & Procedures", "Laboratory Progress", "Continuous Improvement (quality governance)"],
        "must_not": ["Analytical result entry", "Senior technical decision", "Sampling operations"],
    },
    Role.TECHNICAL_MANAGER.value: {
        "name": "Technical Manager",
        "purpose": "Provide technical governance, cross-functional oversight and controlled approval toward LMS.",
        "primary": ["Management Overview", "Technical Assessment Oversight", "Reports / LMS", "Operational & Quality Control", "Asset Structure", "Organization & Roles", "Continuous Improvement"],
        "must_not": ["Routine laboratory result entry", "Routine field execution"],
    },
    Role.MANAGEMENT.value: {
        "name": "Management",
        "purpose": "Read operational, quality, people and improvement evidence without performing workflow transactions.",
        "primary": ["Management Overview", "Continuous Improvement", "Organization & Roles", "Asset Structure"],
        "must_not": ["Laboratory result entry", "QC execution", "Technical assessment transaction", "Sampling transaction", "Change / close improvement actions"],
    },
    Role.CLIENT.value: {
        "name": "Client",
        "purpose": "See only authorized assets, sample status and released reports within the assigned client hierarchy.",
        "primary": ["Client Dashboard", "Authorized Asset Structure"],
        "must_not": ["Internal operations", "Other clients' data", "Unreleased laboratory results"],
    },
    Role.SYSTEM_ADMIN.value: {
        "name": "System Administrator",
        "purpose": "Configure platform master data, access, integrations and review controls; not a substitute for business-role approval in production.",
        "primary": ["Platform Overview", "Review Guide", "Master Data", "Users & Access", "Integration Control", "Audit", "All review workspaces"],
        "must_not": ["Use admin override as normal business approval practice"],
    },
}


def role_display(role: str) -> str:
    return ROLE_REVIEW_MATRIX.get(role, {}).get("name", role.replace("_", " ").title())
