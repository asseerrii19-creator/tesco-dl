from __future__ import annotations

import os

from sqlalchemy import select

from .database import SessionLocal
from .models import ApprovalPolicy, Asset, Client, ClientUnit, Department, PurchaseOrder, Quotation, Role, Site, User, UserClientAssignment, UserClientUnitAssignment, WorkflowDefinition, WorkflowStep, TechnicalResultRule, EquipmentAsset
from .services.lab_operations import ensure_baseline_test_packages
from .security import hash_password


def _truthy(name: str, default: str = "false") -> bool:
    return os.getenv(name, default).strip().lower() in {"1", "true", "yes", "on"}


def seed() -> None:
    db = SessionLocal()
    try:
        dammam = db.scalar(select(Site).where(Site.code == "DMM"))
        if not dammam:
            dammam = Site(code="DMM", name="Dammam", laboratory_name="Transformer Oil Laboratory")
            db.add(dammam)
            db.flush()
        if not db.scalar(select(Site).where(Site.code == "JBL")):
            db.add(Site(code="JBL", name="Jubail", laboratory_name="Hydrocarbon Laboratory", active=False))
        if not db.scalar(select(Site).where(Site.code == "BHR")):
            db.add(Site(code="BHR", name="Bahrain", laboratory_name="Laboratory Operations", active=False))
        db.flush()
        departments = [
            (None, "CORP", "Corporate Management"),
            (dammam.id, "OPS", "Operations"),
            (dammam.id, "RCV", "Sample Intake & Distribution"),
            (dammam.id, "LAB", "Laboratory Operations"),
            (dammam.id, "QLT", "Quality"),
        ]
        for sid, code, name in departments:
            stmt = select(Department).where(Department.code == code)
            stmt = stmt.where(Department.site_id.is_(None)) if sid is None else stmt.where(Department.site_id == sid)
            if not db.scalar(stmt): db.add(Department(site_id=sid, code=code, name=name, active=True))

        bootstrap_email = os.getenv("BOOTSTRAP_ADMIN_EMAIL", "admin@tsco.local").lower().strip()
        bootstrap_password = os.getenv("BOOTSTRAP_ADMIN_PASSWORD", "").strip()
        app_env = os.getenv("APP_ENV", "development").strip().lower()
        admin = db.scalar(select(User).where(User.email == bootstrap_email))
        if not admin:
            if not bootstrap_password:
                raise RuntimeError("BOOTSTRAP_ADMIN_PASSWORD must be configured when creating the bootstrap administrator")
            admin = User(
                email=bootstrap_email,
                full_name=os.getenv("BOOTSTRAP_ADMIN_NAME", "System Administrator"),
                password_hash=hash_password(bootstrap_password),
                role=Role.SYSTEM_ADMIN.value,
                site_id=dammam.id,
                must_change_password=_truthy("REQUIRE_BOOTSTRAP_PASSWORD_CHANGE", "false"),
            )
            db.add(admin)

        # Baseline laboratory packages are application master data, not demo data.
        # Import them once into SQL; from that point Admin/SQL is authoritative.
        ensure_baseline_test_packages(db)

        # Confirmed TSCO technical-result rules from QDF-[7]-08-A current Analysis Report.
        # These are controlled baseline rules; unconfirmed DL/range/precision values remain configurable, never guessed.
        confirmed_rules = [
            ("Furan", "IEC 61198", "2-Furfural (2FAL)", "mg/kg", 0.01, "LTD -> Total Furan LTD; Indirect DP >1000; Paper Lifetime >30 Years"),
            ("Total Acid Number", "IEC 62021/1-03", "Total Acid Number", "mg KOH/g", 0.010, "Numeric below DL -> LTD"),
        ] + [("DGA", "IEC 60567", gas, "ppm", 1.0, "Numeric below analyte DL -> LTD") for gas in ["Hydrogen (H2)","Ethylene (C2H4)","Ethane (C2H6)","Acetylene (C2H2)","Methane (CH4)","Carbon Monoxide (CO)","Carbon Dioxide (CO2)"]]
        for test, method, field, unit, dl, downstream in confirmed_rules:
            exists = db.scalar(select(TechnicalResultRule).where(TechnicalResultRule.site_id==dammam.id, TechnicalResultRule.test_name==test, TechnicalResultRule.method_name==method, TechnicalResultRule.result_field==field, TechnicalResultRule.equipment_id==""))
            if not exists:
                db.add(TechnicalResultRule(site_id=dammam.id,test_name=test,method_name=method,result_field=field,unit=unit,allowed_states="NUMERIC,LTD",detection_limit=dl,rounding_rule="SOURCE_CONTROLLED",downstream_rule=downstream,source_reference="QDF-[7]-08-A Analysis Report",effective_revision="Current review reference"))

        # Equipment IDs verified from the supplied Dammam equipment register. Names stay generic until Quality confirms exact asset descriptors.
        equipment_baseline = [
            ("EQ-64","DGA GC-TOGA","DGA","IEC 60567"),
            ("EQ-69","Karl Fischer Water Instrument","Water","IEC 60814"),("EQ-70","Karl Fischer Water Instrument","Water","IEC 60814"),
            ("EQ-24","BDV Instrument","Electrical","IEC 60156 / ASTM D1816 / ASTM D877"),("EQ-25","BDV Instrument","Electrical","IEC 60156 / ASTM D1816 / ASTM D877"),("EQ-30","BDV Instrument","Electrical","IEC 60156 / ASTM D1816 / ASTM D877"),
            ("EQ-49","Power/Dissipation Factor Instrument","Electrical","ASTM D924 / IEC 60247"),("EQ-130","Power/Dissipation Factor Instrument","Electrical","ASTM D924 / IEC 60247"),
            ("EQ-9","HPLC","Furan / Passivator","IEC 61198"),("EQ-10","HPLC","Furan / Passivator","IEC 61198"),("EQ-11","HPLC","Furan / Passivator","IEC 61198"),("EQ-12","HPLC","Furan / Passivator","IEC 61198"),("EQ-128","HPLC","Furan / Passivator","IEC 61198"),
            ("EQ-79","Metrohm 907 Titrando","Physical / Chemistry","Acid / pH / Peroxide titration"),("EQ-80","Metrohm 907 Titrando","Physical / Chemistry","Acid / pH / Peroxide titration"),
        ]
        for eid,name,ws,method in equipment_baseline:
            if not db.scalar(select(EquipmentAsset).where(EquipmentAsset.site_id==dammam.id,EquipmentAsset.equipment_id==eid)):
                db.add(EquipmentAsset(site_id=dammam.id,equipment_id=eid,name=name,workstation=ws,test_method=method,status="IN_SERVICE",notes="Imported closeout baseline; calibration/provider metadata to be confirmed during Quality review."))

        seed_demo = _truthy("SEED_DEMO_DATA", "false")
        if app_env in {"uat", "production"} and seed_demo:
            raise RuntimeError("SEED_DEMO_DATA must remain false in UAT/production")
        if not seed_demo:
            db.commit()
            return

        clients: dict[str, Client] = {}
        for code, name in [
            ("ARM", "Saudi Aramco"),
            ("SEC", "Saudi Electricity Company"),
            ("GPEL", "GPEL"),
        ]:
            client = db.scalar(select(Client).where(Client.code == code))
            if not client:
                client = Client(code=code, name=name)
                db.add(client)
                db.flush()
            clients[code] = client

        sec = clients["SEC"]
        # Client hierarchies are seeded as examples of long-term scoped access.
        hierarchy_specs = [
            ("SEC", None, "REGION", "SEC-EAST", "Eastern Region"),
            ("SEC", None, "REGION", "SEC-CENTRAL", "Central Region"),
            ("SEC", None, "REGION", "SEC-WEST", "Western Region"),
            ("SEC", None, "REGION", "SEC-SOUTH", "Southern Region"),
            ("ARM", None, "AREA", "ARM-ABQ", "Abqaiq"),
            ("ARM", None, "AREA", "ARM-HAR", "Haradh"),
            ("ARM", None, "AREA", "ARM-DHA", "Dhahran"),
            ("GPEL", None, "SITE", "GPEL-DEMO-SITE", "GPEL Review Site"),
        ]
        unit_map = {}
        for client_code, parent_code, unit_type, code, name in hierarchy_specs:
            c = clients[client_code]
            unit = db.scalar(select(ClientUnit).where(ClientUnit.client_id == c.id, ClientUnit.code == code))
            if not unit:
                parent = unit_map.get((client_code, parent_code)) if parent_code else None
                unit = ClientUnit(client_id=c.id, parent_id=parent.id if parent else None, unit_type=unit_type, code=code, name=name, active=True)
                db.add(unit); db.flush()
            unit_map[(client_code, code)] = unit
        child_specs = [
            ("SEC", "SEC-EAST", "SUBSTATION", "SEC-DMM-WEST", "Dammam West Substation"),
            ("ARM", "ARM-ABQ", "FACILITY", "ARM-ABQ-PLANT", "Abqaiq Plant"),
            ("ARM", "ARM-HAR", "FACILITY", "ARM-HAR-PLANT", "Haradh Gas Plant"),
            ("ARM", "ARM-DHA", "FACILITY", "ARM-DHA-HQ", "Dhahran Facilities"),
            ("GPEL", "GPEL-DEMO-SITE", "SUBSTATION", "GPEL-DEMO-SS", "Main Review Substation"),
        ]
        for client_code, parent_code, unit_type, code, name in child_specs:
            c=clients[client_code]; parent=unit_map[(client_code,parent_code)]
            unit=db.scalar(select(ClientUnit).where(ClientUnit.client_id==c.id,ClientUnit.code==code))
            if not unit:
                unit=ClientUnit(client_id=c.id,parent_id=parent.id,unit_type=unit_type,code=code,name=name,active=True); db.add(unit); db.flush()
            unit_map[(client_code,code)] = unit
        quote = db.scalar(select(Quotation).where(Quotation.client_id == sec.id, Quotation.number == "QT-SEC-2026-014"))
        if not quote:
            quote = Quotation(client_id=sec.id, number="QT-SEC-2026-014", description="Transformer oil testing services")
            db.add(quote)
            db.flush()
        po = db.scalar(select(PurchaseOrder).where(PurchaseOrder.client_id == sec.id, PurchaseOrder.number == "PO-SEC-2026-221"))
        if not po:
            po = PurchaseOrder(client_id=sec.id, quotation_id=quote.id, number="PO-SEC-2026-221")
            db.add(po)
        asset = db.scalar(select(Asset).where(Asset.client_id == sec.id, Asset.asset_code == "SEC-DMM-TR-001"))
        if not asset:
            asset = Asset(
                client_id=sec.id,
                client_unit_id=unit_map[("SEC","SEC-DMM-WEST")].id,
                asset_code="SEC-DMM-TR-001",
                serial_number="SN-SEC-884120",
                equipment_type="Power Transformer",
                manufacturer="Demo Manufacturer",
                voltage_kv=132,
                rated_mva=100,
                station_name="Dammam West Substation",
                asset_location_label="Bay 4 / Main Transformer",
                latitude=26.4207,
                longitude=50.0888,
            )
            db.add(asset)

        # Review-only asset examples make the Client → Location → Transformer tree visible
        # for every demo client. They are clearly marked as UAT examples and are not used as
        # real client master data outside SEED_DEMO_DATA environments.
        demo_assets = [
            ("SEC", "SEC-DMM-WEST", "SEC-DMM-TR-002", "UAT-SEC-002", "UAT Example Manufacturer", 132, 50, "Dammam West Substation", "Review Bay 2"),
            ("ARM", "ARM-ABQ-PLANT", "ARM-ABQ-TR-001", "UAT-ARM-ABQ-001", "UAT Example Manufacturer", 115, 75, "Abqaiq Plant", "Review Transformer Yard"),
            ("ARM", "ARM-HAR-PLANT", "ARM-HAR-TR-001", "UAT-ARM-HAR-001", "UAT Example Manufacturer", 115, 50, "Haradh Gas Plant", "Review Transformer Yard"),
            ("GPEL", "GPEL-DEMO-SS", "GPEL-DEMO-TR-001", "UAT-GPEL-001", "UAT Example Manufacturer", 33, 20, "Main Review Substation", "Review Bay 1"),
        ]
        for client_code, unit_code, asset_code, serial, manufacturer, voltage, mva, station, location in demo_assets:
            c = clients[client_code]
            existing_asset = db.scalar(select(Asset).where(Asset.client_id == c.id, Asset.asset_code == asset_code))
            if not existing_asset:
                db.add(Asset(
                    client_id=c.id, client_unit_id=unit_map[(client_code, unit_code)].id, asset_code=asset_code,
                    serial_number=serial, equipment_type="Power Transformer", manufacturer=manufacturer,
                    voltage_kv=voltage, rated_mva=mva, station_name=station, asset_location_label=location,
                ))

        demo_user_password = os.getenv("DEMO_USER_PASSWORD", "").strip()
        if not demo_user_password:
            raise RuntimeError("DEMO_USER_PASSWORD must be configured when SEED_DEMO_DATA=true")
        demo_password = hash_password(demo_user_password)
        user_specs = [
            ("fieldman@tsco.local", "Ahmed Field Sampler", Role.FIELD_SAMPLER.value, dammam.id, None),
            ("supervisor@tsco.local", "Sampling Supervisor", Role.SAMPLING_SUPERVISOR.value, dammam.id, None),
            ("operations@tsco.local", "Operations Manager", Role.OPERATIONS_MANAGER.value, dammam.id, None),
            ("clientsampler@sec.local", "SEC Client Sampler", Role.CLIENT_SAMPLER.value, dammam.id, sec.id),
            ("clientops@sec.local", "SEC Client Operations", Role.CLIENT_OPERATIONS.value, dammam.id, sec.id),
            ("intake@tsco.local", "Data Entry User", Role.DATA_ENTRY.value, dammam.id, None),
            ("receiving@tsco.local", "Sample Receiving User", Role.SAMPLE_RECEIVING.value, dammam.id, None),
            ("chemist@tsco.local", "Laboratory Chemist", Role.LAB_TECHNICIAN.value, dammam.id, None),
            ("chemist2@tsco.local", "Laboratory Chemist 2", Role.LAB_TECHNICIAN.value, dammam.id, None),
            ("quality@tsco.local", "Quality Reviewer", Role.QUALITY.value, dammam.id, None),
            ("manager@tsco.local", "Dammam Laboratory Manager", Role.MANAGEMENT.value, dammam.id, None),
            ("corporate@tsco.local", "Corporate Management", Role.MANAGEMENT.value, None, None),
            ("senior@tsco.local", "Senior Chemist", Role.SENIOR_CHEMIST.value, dammam.id, None),
            ("senior.maintenance@tsco.local", "Senior Chemist — Equipment & Maintenance", Role.SENIOR_CHEMIST.value, dammam.id, None),
            ("senior.improvement@tsco.local", "Senior Chemist — Continuous Improvement", Role.SENIOR_CHEMIST.value, dammam.id, None),
            ("technical@tsco.local", "Technical Manager", Role.TECHNICAL_MANAGER.value, dammam.id, None),
            ("client@sec.local", "SEC Client User", Role.CLIENT.value, None, sec.id),
            ("client@aramco.local", "Saudi Aramco Corporate User", Role.CLIENT.value, None, clients["ARM"].id),
            ("abqaiq@aramco.local", "Aramco Abqaiq User", Role.CLIENT.value, None, clients["ARM"].id),
            ("eastern@sec.local", "SEC Eastern Region User", Role.CLIENT.value, None, sec.id),
        ]
        users: dict[str, User] = {}
        for email, name, role, site_id, client_id in user_specs:
            user = db.scalar(select(User).where(User.email == email))
            if not user:
                user = User(
                    email=email,
                    full_name=name,
                    password_hash=demo_password,
                    role=role,
                    site_id=site_id,
                    client_id=client_id,
                )
                db.add(user)
                db.flush()
            users[email] = user

        senior_titles = {
            "senior@tsco.local": "Senior Chemist · Technical Responsibility",
            "senior.maintenance@tsco.local": "Senior Chemist · Equipment & Maintenance Responsibility",
            "senior.improvement@tsco.local": "Senior Chemist · Continuous Improvement Responsibility",
        }
        for email, title in senior_titles.items():
            if email in users and users[email].job_title != title:
                users[email].job_title = title

        # Scoped client accounts: corporate users have no unit assignment; regional users are constrained to a subtree.
        for email, unit_key in [
            ("abqaiq@aramco.local", ("ARM","ARM-ABQ")),
            ("eastern@sec.local", ("SEC","SEC-EAST")),
        ]:
            usr=users[email]; unit=unit_map[unit_key]
            if not db.scalar(select(UserClientUnitAssignment).where(UserClientUnitAssignment.user_id==usr.id, UserClientUnitAssignment.client_unit_id==unit.id)):
                db.add(UserClientUnitAssignment(user_id=usr.id, client_unit_id=unit.id))

        fieldman = users["fieldman@tsco.local"]
        if not db.scalar(
            select(UserClientAssignment).where(
                UserClientAssignment.user_id == fieldman.id,
                UserClientAssignment.client_id == sec.id,
            )
        ):
            db.add(UserClientAssignment(user_id=fieldman.id, client_id=sec.id))

        flow = db.scalar(select(WorkflowDefinition).where(WorkflowDefinition.site_id.is_(None), WorkflowDefinition.code=="LAB-SAMPLE-LIFECYCLE", WorkflowDefinition.active.is_(True)))
        if not flow:
            flow=WorkflowDefinition(site_id=None,code="LAB-SAMPLE-LIFECYCLE",name="Integrated Sample Lifecycle",sample_type="TRANSFORMER OIL",version=1,active=True); db.add(flow); db.flush()
            steps=[
                (1,"sampling_request","Sampling Requirement to Operations",Role.SAMPLING_SUPERVISOR.value,False,False),
                (2,"sampling_order","Official Sampling Order",Role.OPERATIONS_MANAGER.value,False,False),
                (3,"supervisor_assignment","Field Assignment",Role.SAMPLING_SUPERVISOR.value,False,False),
                (4,"field_capture","Field Sampling & Capture",Role.FIELD_SAMPLER.value,False,False),
                (5,"intake_review","Sample Intake — Data Review",Role.DATA_ENTRY.value,False,False),
                (6,"lms_registration","LMS Registration",Role.DATA_ENTRY.value,False,False),
                (7,"receiving","Physical Receiving",Role.SAMPLE_RECEIVING.value,False,False),
                (8,"batch_distribution","Batch & Distribution to Laboratory",Role.DATA_ENTRY.value,False,False),
                (9,"laboratory","Laboratory Operations",Role.LAB_TECHNICIAN.value,False,False),
                (10,"technical_review","Technical Review",Role.SENIOR_CHEMIST.value,True,False),
                (11,"lms_submission_approval","Approve for LMS Submission",Role.TECHNICAL_MANAGER.value,True,False),
                (12,"lms_official_report","LMS Job Closure / Official Report","external_lms",False,True),
            ]
            for order,key,label,role,approval,terminal in steps: db.add(WorkflowStep(workflow_id=flow.id,step_order=order,step_key=key,label=label,responsible_role=role,approval_required=approval,terminal=terminal))
        if not db.scalar(select(ApprovalPolicy).where(ApprovalPolicy.site_id.is_(None),ApprovalPolicy.code=="LMS-SUBMISSION")):
            db.add(ApprovalPolicy(site_id=None,code="LMS-SUBMISSION",name="LMS Submission Approval",entity_type="SAMPLE_REPORT",stages_json='[{"stage":"Result Entry","role":"lab_technician"},{"stage":"Technical Review","role":"senior_chemist"},{"stage":"Approve for LMS Submission","role":"technical_manager"},{"stage":"Official Report Issued","role":"external_lms"}]',active=True))
        db.commit()
    finally:
        db.close()
