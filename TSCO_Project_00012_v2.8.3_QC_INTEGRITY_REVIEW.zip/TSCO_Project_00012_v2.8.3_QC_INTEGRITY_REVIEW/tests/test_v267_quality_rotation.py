from __future__ import annotations

from datetime import datetime

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import AuditLog, Role, Site, User
from app.services.lab_operations import blank_operations_db, ensure_monthly_quality_distribution


def login(client: TestClient, email: str, password: str = "Demo123!") -> None:
    response = client.post("/login", data={"email": email, "password": password}, follow_redirects=False)
    assert response.status_code == 303


def load_operations(client: TestClient) -> dict:
    response = client.get("/api/lab-operations/data")
    assert response.status_code == 200
    return response.json()


def test_monthly_quality_distribution_is_generated_with_required_checks_and_primary_backup():
    with TestClient(app) as client:
        login(client, "quality@tsco.local")
        payload = load_operations(client)
        db = payload["db"]
        month = datetime.utcnow().strftime("%Y-%m")
        distribution = next(row for row in db["qualityDistributions"] if row["month"] == month)
        assignments = distribution["assignments"]

        assert distribution["status"] == "PUBLISHED"
        assert distribution["rotation"] == "AUTO_MONTHLY_PRIMARY_BACKUP"
        assert len(assignments) == 25  # six four-period checks + one monthly safety check
        names = {row["task"] for row in assignments}
        assert {
            "Gas Supplies Check",
            "Gas Cylinder Status / Daily Record",
            "Balances Check",
            "Electrode Check",
            "Chemical Inventory Check",
            "Sample Storage Check",
            "Shower & Eye Wash Check",
        }.issubset(names)
        assert {row["domain"] for row in assignments} == {"Equipment & Safety", "Materials, Gases & Storage"}
        assert all(row["primary_user_id"] for row in assignments)
        assert all(row["primary_name"] for row in assignments)
        assert all("backup_user_id" in row for row in assignments)
        assert distribution["period_model"] == "W1 1-11 / W2 12-18 / W3 19-25 / W4 26-EOM"


def test_rotation_changes_between_months_and_preserves_each_month_snapshot():
    with SessionLocal() as db:
        site = db.scalar(select(Site).where(Site.code == "DMM"))
        staff = db.scalars(
            select(User).where(
                User.site_id == site.id,
                User.active.is_(True),
                User.role == Role.LAB_TECHNICIAN.value,
            )
        ).all()
        assert staff
        # Add a second technician object to exercise month-to-month rotation without
        # incorrectly treating Senior Chemists as routine QC operators.
        staff = list(staff) + [User(id=9999, email="backup.tech@tsco.local", full_name="Backup Laboratory Technician", password_hash="test", role=Role.LAB_TECHNICIAN.value, site_id=site.id, active=True)]
        payload = blank_operations_db(site)
        sep = ensure_monthly_quality_distribution(payload, staff, when=datetime(2026, 9, 3))
        octo = ensure_monthly_quality_distribution(payload, staff, when=datetime(2026, 10, 3))

        assert sep and octo
        assert sep["id"] != octo["id"]
        assert len(payload["qualityDistributions"]) == 2
        sep_balance = next(x for x in sep["assignments"] if x["task_key"] == "balances" and x["period"] == "W1")
        oct_balance = next(x for x in octo["assignments"] if x["task_key"] == "balances" and x["period"] == "W1")
        assert sep_balance["primary_user_id"] != oct_balance["primary_user_id"]


def test_assigned_chemist_can_record_quality_check_and_event_is_audited():
    with TestClient(app) as client:
        # Quality can see the governed monthly schedule; the Chemist cannot.
        login(client, "quality@tsco.local")
        governed = load_operations(client)["db"]
        month = datetime.utcnow().strftime("%Y-%m")
        distribution = next(row for row in governed["qualityDistributions"] if row["month"] == month)
        with SessionLocal() as session:
            chemist = session.scalar(select(User).where(User.email == "chemist@tsco.local"))
            chemist_id = chemist.id
        assignment = next(
            row for row in distribution["assignments"]
            if chemist_id in {row.get("primary_user_id"), row.get("backup_user_id")}
        )

        client.post("/logout")
        login(client, "chemist@tsco.local")
        personal = client.get("/api/lab-operations/data").json()["db"]
        assert personal["qualityDistributions"] == []
        assert personal["qualityTaskEvents"] == []
        recorded = client.post(
            f"/control/my-quality-tasks/routine/{assignment['id']}",
            data={"status":"PASS","note":"Routine check completed"},
            follow_redirects=False,
        )
        assert recorded.status_code == 303

        with SessionLocal() as session:
            audit = session.scalar(select(AuditLog).where(AuditLog.action == "ROUTINE_QC_RECORDED").order_by(AuditLog.id.desc()))
            assert audit is not None
            assert assignment["task"] in audit.summary


def test_quality_role_cannot_complete_chemist_assignment_and_published_schedule_cannot_be_rewritten():
    with TestClient(app) as client:
        login(client, "quality@tsco.local")
        payload = load_operations(client)
        db = payload["db"]
        distribution = db["qualityDistributions"][-1]
        assignment = distribution["assignments"][0]

        db["qualityTaskEvents"].append({
            "id": "QTE-V267-QUALITY-BLOCKED",
            "distribution_id": distribution["id"],
            "assignment_id": assignment["id"],
            "status": "PASS",
            "note": "Quality should only oversee this task",
        })
        blocked = client.put(
            "/api/lab-operations/data",
            json={"db": db, "clientRevision": payload["revision"]},
        )
        assert blocked.status_code == 403
        assert "assigned laboratory chemist" in blocked.json()["error"]

        fresh = load_operations(client)
        tampered = fresh["db"]
        tampered["qualityDistributions"][-1]["assignments"][0]["primary_name"] = "Unauthorized Rewrite"
        blocked_schedule = client.put(
            "/api/lab-operations/data",
            json={"db": tampered, "clientRevision": fresh["revision"]},
        )
        assert blocked_schedule.status_code == 403
        assert "server-controlled" in blocked_schedule.json()["error"]


def test_senior_cannot_record_routine_quality_check_even_by_direct_payload():
    with TestClient(app) as client:
        login(client, "senior@tsco.local")
        payload = load_operations(client)
        db = payload["db"]
        distribution = db["qualityDistributions"][-1]
        assignment = distribution["assignments"][0]
        db["qualityTaskEvents"].append({
            "id": "QTE-V280-SENIOR-BLOCKED",
            "distribution_id": distribution["id"],
            "assignment_id": assignment["id"],
            "status": "PASS",
            "note": "Senior must not execute routine QC",
        })
        response = client.put(
            "/api/lab-operations/data",
            json={"db": db, "clientRevision": payload["revision"]},
        )
        assert response.status_code == 403
        assert "assigned laboratory chemist" in response.json()["error"]

def test_quality_workspace_contains_monthly_distribution_ui_and_all_required_duties():
    with TestClient(app) as client:
        login(client, "quality@tsco.local")
        response = client.get("/lab/operations/app?embed=1&section=quality")
        assert response.status_code == 200
        text = response.text
        for expected in (
            "Monthly Quality Control Distribution",
            "Equipment &amp; Safety",
            "Materials, Gases &amp; Storage",
            "Primary + Backup",
            "AUTO MONTHLY ROTATION",
            "qualityEquipmentRows",
            "qualityMaterialsRows",
        ):
            assert expected in text


def test_generated_monthly_distribution_is_persisted_on_api_load_without_client_save():
    with TestClient(app) as client:
        login(client, "quality@tsco.local")
        loaded = load_operations(client)
        month = datetime.utcnow().strftime("%Y-%m")
        distribution = next(row for row in loaded["db"]["qualityDistributions"] if row["month"] == month)
        assert loaded["revision"] >= 1

        with SessionLocal() as session:
            site = session.scalar(select(Site).where(Site.code == "DMM"))
            from app.models import OperationsState
            import json
            state = session.scalar(select(OperationsState).where(OperationsState.site_id == site.id))
            durable = json.loads(state.json_data)
            assert any(row.get("id") == distribution["id"] for row in durable.get("qualityDistributions", []))


def test_gas_supply_and_cylinder_responsibility_share_the_same_pair_per_period():
    with TestClient(app) as client:
        login(client, "quality@tsco.local")
        distribution = load_operations(client)["db"]["qualityDistributions"][-1]
        for period in ("W1", "W2", "W3", "W4"):
            supplies = next(x for x in distribution["assignments"] if x["task_key"] == "gas_supplies" and x["period"] == period)
            cylinder = next(x for x in distribution["assignments"] if x["task_key"] == "gas_cylinder" and x["period"] == period)
            assert supplies["primary_user_id"] == cylinder["primary_user_id"]
            assert supplies.get("backup_user_id") == cylinder.get("backup_user_id")
