from __future__ import annotations

import os

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import Role, Site, User
from app.security import hash_password
from app.seed import seed
from app.services.lab_operations import (
    TAN_WORKSTATION,
    _normalize_package_test,
    _workstation_for_test,
)


def test_forced_password_change_cannot_be_bypassed_by_direct_protected_url():
    with TestClient(app) as client:
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "DMM"))
            user = db.scalar(select(User).where(User.email == "forcechange269@tsco.local"))
            if not user:
                user = User(
                    email="forcechange269@tsco.local",
                    full_name="Forced Change Chemist",
                    password_hash=hash_password("Temporary123!"),
                    role=Role.LAB_TECHNICIAN.value,
                    site_id=site.id,
                    active=True,
                    must_change_password=True,
                )
                db.add(user)
            else:
                user.password_hash = hash_password("Temporary123!")
                user.must_change_password = True
                user.active = True
            db.commit()

        login = client.post(
            "/login",
            data={"email": "forcechange269@tsco.local", "password": "Temporary123!"},
            follow_redirects=False,
        )
        assert login.status_code == 303
        assert login.headers["location"] == "/change-password"

        bypass = client.get("/lab/operations", follow_redirects=False)
        assert bypass.status_code == 303
        assert bypass.headers["location"] == "/change-password"

        changed = client.post(
            "/change-password",
            data={
                "current_password": "Temporary123!",
                "new_password": "Permanent269!",
                "confirm_password": "Permanent269!",
            },
        )
        assert changed.status_code == 200
        assert "Password updated successfully" in changed.text

        allowed = client.get("/lab/operations", follow_redirects=False)
        assert allowed.status_code == 200


def test_package_normalization_repairs_legacy_method_but_preserves_future_approved_method():
    legacy = _normalize_package_test(
        {"test": "Total Acid Number", "method": "ASTM D664", "station": TAN_WORKSTATION, "unit": "mg KOH/g"}
    )
    assert legacy["method"] == "ASTM D974"

    future = _normalize_package_test(
        {"test": "Total Acid Number", "method": "APPROVED FUTURE METHOD", "station": TAN_WORKSTATION, "unit": "mg KOH/g"}
    )
    assert future["method"] == "APPROVED FUTURE METHOD"


def test_new_configured_test_can_use_an_existing_controlled_workstation_without_code_change():
    configured = _normalize_package_test(
        {"test": "New Oxidation Marker", "method": "TSCO-METHOD-001", "station": TAN_WORKSTATION, "unit": "mg/kg"}
    )
    assert configured["station"] == TAN_WORKSTATION
    batch = {"tests": [configured]}
    assert _workstation_for_test(batch, "New Oxidation Marker") == TAN_WORKSTATION


def test_existing_bootstrap_admin_does_not_require_bootstrap_secret_on_every_restart():
    # Initialize the disposable test database with the one-time bootstrap secret.
    with TestClient(app):
        pass
    previous = os.environ.pop("BOOTSTRAP_ADMIN_PASSWORD", None)
    try:
        seed()
    finally:
        if previous is not None:
            os.environ["BOOTSTRAP_ADMIN_PASSWORD"] = previous


def test_runtime_version_is_consistent_with_v269_candidate():
    assert app.version == "2.8.3"
    with TestClient(app) as client:
        health = client.get("/api/v1/health")
        assert health.status_code == 200
        assert health.json()["version"] == "2.8.3"
