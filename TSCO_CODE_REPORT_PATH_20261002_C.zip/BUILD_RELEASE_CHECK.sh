#!/usr/bin/env bash
set -euo pipefail
MARKER="TSCO-REPORT-PATH-CLOSEOUT-20261002-C"
echo "TSCO_BUILD_MARKER=${MARKER}"
if [[ -f ../TSCO_CODE_REPORT_PATH_20261002_C.zip ]]; then
  echo "TSCO_CODE_REPORT_PATH_SHA256=$(sha256sum ../TSCO_CODE_REPORT_PATH_20261002_C.zip | awk '{print $1}')"
fi
python - <<'PY'
from pathlib import Path
p=Path('app/lab_ops/index_template.html')
html=p.read_text(encoding='utf-8')
required=[
    'Analytical QC — Result Validity',
    "$('queues').innerHTML=qcHtml+",
    'function applyAnalyticalQcActionLocks()',
    'STARTUP QC',
    'SAVE BOTH READINGS + AVERAGE',
    'WATER_DUAL_AVERAGE',
    'EQUIPMENT NOT READY',
    "inherited_for:'Appearance'",
]
missing=[x for x in required if x not in html]
if missing:
    raise SystemExit('QC UI deployment assertion failed; missing: '+', '.join(missing))
print('TSCO_QC_UI_ASSERTION=PASS')
PY
pytest -q \
  tests/test_v340_standalone_closeout.py \
  tests/test_v341_final_analysis_report.py \
  tests/test_v342_senior_final_report_review.py \
  tests/test_v343_intake_continuity_hotfix.py \
  tests/test_v344_data_form_backfill.py \
  tests/test_v345_consolidated_intake_closeout.py \
  tests/test_v346_live_intake_projection.py \
  tests/test_v347_controlled_intake_amendment.py \
  tests/test_v349_qc_workstation_entrypoint.py \
  tests/test_v350_daily_analytical_qc_control.py \
  tests/test_v351_dual_water_workflow.py \
  tests/test_v352_report_path_closeout.py \
  tests/test_qc_framework_global.py
