from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timedelta
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import Asset, Client, SampleRequest, Site, TestPackageConfig, User
from app.services.lab_operations import get_operations_state, sync_samples_to_operations, validate_operations_update


def _user(db, email: str) -> User:
    row = db.scalar(select(User).where(User.email == email))
    assert row is not None, email
    return row


def _package_name(db) -> str:
    row = db.scalar(select(TestPackageConfig).where(TestPackageConfig.active.is_(True)).order_by(TestPackageConfig.id))
    assert row is not None
    return row.name


def test_intake_multi_sample_release_preserves_priority_tat_due_and_one_batch():
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "DMM")); assert site
            client = db.scalar(select(Client).where(Client.code == "SEC")); assert client
            asset = db.scalar(select(Asset).where(Asset.client_id == client.id)); assert asset
            actor = _user(db, "data.entry@tsco.local")
            package = _package_name(db)
            due = datetime.utcnow() + timedelta(hours=10)
            rows = []
            for i in range(2):
                token = uuid4().hex[:8]
                row = SampleRequest(
                    request_number=f"V321-{token}", public_token=f"PUB-{token}", barcode_value=f"BAR-{token}",
                    lms_number=f"LMS-{token}", status="RECEIVED", site_id=site.id, client_id=client.id, asset_id=asset.id,
                    sample_date_time=datetime.utcnow(), sampling_point=f"Point {i+1}", sample_origin="Client-Originated / Direct Delivery",
                    submission_channel="CLIENT_DELIVERED", requested_package=package, priority="URGENT", required_tat="12H", due_at=due,
                    received_at=datetime.utcnow(),
                )
                db.add(row); rows.append(row)
            db.flush()
            batch_id = sync_samples_to_operations(db, rows, actor, phase="READY_FOR_LAB")
            state, payload = get_operations_state(db, site)
            batch = next(b for b in payload["batches"] if b["id"] == batch_id)
            assert len(batch["samples"]) == 2
            assert sorted(batch["platform_sample_ids"]) == sorted([r.id for r in rows])
            assert batch["priority"] == "Urgent"
            assert batch["required_tat"] == "12H"
            assert batch["due_at"] == due.isoformat()
            assert all(batch["sample_meta"][key]["requiredTat"] == "12H" for key in batch["samples"])
            assert all(batch["sample_meta"][key]["priority"] == "Urgent" for key in batch["samples"])


def test_intake_release_rejects_mixed_priority_batch():
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "DMM")); assert site
            client = db.scalar(select(Client).where(Client.code == "SEC")); assert client
            asset = db.scalar(select(Asset).where(Asset.client_id == client.id)); assert asset
            actor = _user(db, "data.entry@tsco.local")
            package = _package_name(db)
            rows = []
            for priority in ("NORMAL", "URGENT"):
                token = uuid4().hex[:8]
                row = SampleRequest(
                    request_number=f"V321-MIX-{token}", public_token=f"PUB-{token}", barcode_value=f"BAR-{token}",
                    lms_number=f"LMS-{token}", status="RECEIVED", site_id=site.id, client_id=client.id, asset_id=asset.id,
                    sample_date_time=datetime.utcnow(), sampling_point="Main Tank", sample_origin="Client-Originated / Direct Delivery",
                    submission_channel="CLIENT_DELIVERED", requested_package=package, priority=priority, received_at=datetime.utcnow(),
                )
                db.add(row); rows.append(row)
            db.flush()
            with pytest.raises(ValueError, match="different priorities"):
                sync_samples_to_operations(db, rows, actor, phase="READY_FOR_LAB")


def _bench_payload(db, site, chemist):
    _, current = get_operations_state(db, site)
    current = deepcopy(current)
    current["batches"] = [{
        "id": "B-QC-GATE", "template": "Routine Test", "package_id": "TEST", "client_id": "1",
        "client_name": "Test", "client_code": "T", "priority": "Normal", "site": site.code,
        "samples": ["S-QC-1"], "sample_meta": {"S-QC-1": {}},
        "tests": [{"test": "Breakdown Voltage @2.5mm- AVG", "method": "IEC 60156", "unit": "kV"}],
        "status": "Testing", "created_at": datetime.utcnow().isoformat(),
    }]
    assignment = {
        "id": "WSA-QC-1", "batch_id": "B-QC-GATE", "scope": "BATCH", "workstation": "Electrical", "mode": "SINGLE",
        "primary_user_id": chemist.id, "primary_name": chemist.full_name, "backup_user_id": None, "backup_name": "",
        "assigned_by_user_id": chemist.id, "assigned_by": "Test Senior", "assigned_at": datetime.utcnow().isoformat(), "revision": 1,
        "access_scope": "NAMED_USERS",
    }
    current["testAssignments"] = [assignment]
    current["results"] = []; current["qc"] = []; current["assignmentCompletions"] = []
    return current, assignment


def test_chemist_result_is_server_blocked_until_current_assignment_qc_passes():
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "DMM")); assert site
            chemist = _user(db, "chemist@tsco.local")
            current, assignment = _bench_payload(db, site, chemist)
            proposed = deepcopy(current)
            proposed["results"].append({
                "id": "R-NO-QC", "batch": "B-QC-GATE", "sample": "S-QC-1",
                "test": "Breakdown Voltage @2.5mm- AVG", "result": "60", "unit": "kV", "isRetest": False,
            })
            with pytest.raises(PermissionError, match="QC must be completed"):
                validate_operations_update(current, proposed, chemist, db=db, site_id=site.id)

            proposed = deepcopy(current)
            proposed["qc"].append({
                "id": "QC-PASS-1", "mode": "routine", "test": "BDV", "workstation": "Electrical",
                "assignment_id": assignment["id"], "batch_id": "B-QC-GATE", "status": "PASS", "result": "25", "target": "25",
                "ts": datetime.utcnow().isoformat(),
            })
            proposed["results"].append({
                "id": "R-WITH-QC", "batch": "B-QC-GATE", "sample": "S-QC-1",
                "test": "Breakdown Voltage @2.5mm- AVG", "result": "60", "unit": "kV", "isRetest": False,
                "qc_record_id": "QC-PASS-1",
            })
            accepted = validate_operations_update(current, proposed, chemist, db=db, site_id=site.id)
            assert accepted["results"][-1]["qc_status"] == "RECORDED"
            assert accepted["results"][-1]["qc_record_id"] == "QC-PASS-1"


def test_complete_my_assignment_is_blocked_until_results_done_then_is_server_stamped():
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "DMM")); assert site
            chemist = _user(db, "chemist@tsco.local")
            current, assignment = _bench_payload(db, site, chemist)
            premature = deepcopy(current)
            premature["assignmentCompletions"].append({
                "id": "AC-PREMATURE", "batch_id": "B-QC-GATE", "workstation": "Electrical", "assignment_id": assignment["id"],
            })
            with pytest.raises(PermissionError, match="all required workstation results"):
                validate_operations_update(current, premature, chemist, db=db, site_id=site.id)

            with_qc = deepcopy(current)
            with_qc["qc"].append({
                "id": "QC-PASS-2", "mode": "routine", "test": "BDV", "workstation": "Electrical",
                "assignment_id": assignment["id"], "batch_id": "B-QC-GATE", "status": "PASS", "result": "25", "target": "25",
                "ts": datetime.utcnow().isoformat(),
            })
            with_qc["results"].append({
                "id": "R-DONE", "batch": "B-QC-GATE", "sample": "S-QC-1",
                "test": "Breakdown Voltage @2.5mm- AVG", "result": "60", "unit": "kV", "isRetest": False,
                "qc_record_id": "QC-PASS-2",
            })
            accepted = validate_operations_update(current, with_qc, chemist, db=db, site_id=site.id)
            closeout = deepcopy(accepted)
            closeout["assignmentCompletions"].append({
                "id": "AC-DONE", "batch_id": "B-QC-GATE", "workstation": "Electrical", "assignment_id": assignment["id"],
            })
            accepted2 = validate_operations_update(accepted, closeout, chemist, db=db, site_id=site.id)
            row = accepted2["assignmentCompletions"][-1]
            assert row["completed_by_user_id"] == chemist.id
            assert row["completed_by"] == chemist.full_name
            assert row["completed_at"]



def test_twelve_hour_tat_gets_server_due_countdown_and_preserves_it_on_resave():
    from app.routes.intake import _apply_priority_tat
    sample = SampleRequest(priority="NORMAL", required_tat="", due_at=None)
    before = datetime.utcnow()
    _apply_priority_tat(sample, "URGENT", "12H", "")
    first_due = sample.due_at
    assert sample.priority == "URGENT" and sample.required_tat == "12H"
    assert first_due is not None
    assert timedelta(hours=11, minutes=59) <= first_due - before <= timedelta(hours=12, minutes=1)
    _apply_priority_tat(sample, "URGENT", "12H", "")
    assert sample.due_at == first_due


def test_intake_release_rejects_mixed_tat_batch():
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "DMM")); assert site
            client = db.scalar(select(Client).where(Client.code == "SEC")); assert client
            asset = db.scalar(select(Asset).where(Asset.client_id == client.id)); assert asset
            actor = _user(db, "data.entry@tsco.local")
            package = _package_name(db)
            rows = []
            for tat in ("12H", "24H"):
                token = uuid4().hex[:8]
                row = SampleRequest(
                    request_number=f"V321-TAT-{token}", public_token=f"PUB-{token}", barcode_value=f"BAR-{token}",
                    lms_number=f"LMS-{token}", status="RECEIVED", site_id=site.id, client_id=client.id, asset_id=asset.id,
                    sample_date_time=datetime.utcnow(), sampling_point="Main Tank", sample_origin="Client-Originated / Direct Delivery",
                    submission_channel="CLIENT_DELIVERED", requested_package=package, priority="URGENT", required_tat=tat,
                    due_at=datetime.utcnow() + timedelta(hours=12 if tat == "12H" else 24), received_at=datetime.utcnow(),
                )
                db.add(row); rows.append(row)
            db.flush()
            with pytest.raises(ValueError, match="different TAT classes"):
                sync_samples_to_operations(db, rows, actor, phase="READY_FOR_LAB")


def test_qc_status_is_server_calculated_and_forged_pass_cannot_bypass_dga_rule():
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "DMM")); assert site
            chemist = _user(db, "chemist@tsco.local")
            _, current = get_operations_state(db, site)
            current = deepcopy(current)
            current["batches"] = [{
                "id":"B-DGA-QC", "template":"Routine", "package_id":"TEST", "client_id":"1", "client_name":"T", "client_code":"T",
                "priority":"Normal", "site":site.code, "samples":["DGA-S1"], "sample_meta":{"DGA-S1":{}},
                "tests":[{"test":"Dissolved Gas Analysis (DGA)","method":"ASTM D3612","station":"DGA","unit":""}], "status":"Testing",
            }]
            assignment={"id":"WSA-DGA","batch_id":"B-DGA-QC","scope":"BATCH","workstation":"DGA","mode":"SINGLE","primary_user_id":chemist.id,"primary_name":chemist.full_name,"backup_user_id":None,"backup_name":"","assigned_by_user_id":1,"assigned_by":"Senior","assigned_at":datetime.utcnow().isoformat(),"revision":1,"access_scope":"NAMED_USERS"}
            current["testAssignments"]=[assignment]; current["qc"]=[]; current["results"]=[]; current["assignmentCompletions"]=[]
            proposed=deepcopy(current)
            proposed["qc"].append({"id":"QC-DGA-FORGE","mode":"routine","test":"DGA","assignment_id":"WSA-DGA","batch_id":"B-DGA-QC","target":"100","result":"200","status":"PASS"})
            accepted=validate_operations_update(current, proposed, chemist, db=db, site_id=site.id)
            assert accepted["qc"][-1]["status"] == "FAIL"
            forged_result=deepcopy(accepted)
            forged_result["results"].append({"id":"R-DGA","batch":"B-DGA-QC","sample":"DGA-S1","test":"DGA:H2","display_test":"Hydrogen","result":"50","unit":"ppm","qc_record_id":"QC-DGA-FORGE"})
            with pytest.raises(PermissionError, match="requires acceptable QC"):
                validate_operations_update(accepted, forged_result, chemist, db=db, site_id=site.id)


def test_every_measured_test_uses_qc_gate_even_when_no_statistical_profile_exists():
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "DMM")); assert site
            chemist = _user(db, "chemist@tsco.local")
            _, current = get_operations_state(db, site); current=deepcopy(current)
            test_name="Power Factor @25°C/60Hz"
            current["batches"]=[{"id":"B-PF","template":"Routine","package_id":"TEST","client_id":"1","client_name":"T","client_code":"T","priority":"Normal","site":site.code,"samples":["PF-S1"],"sample_meta":{"PF-S1":{}},"tests":[{"test":test_name,"method":"ASTM D924","station":"Electrical","unit":""}],"status":"Testing"}]
            current["testAssignments"]=[{"id":"WSA-PF","batch_id":"B-PF","scope":"BATCH","workstation":"Electrical","mode":"SINGLE","primary_user_id":chemist.id,"primary_name":chemist.full_name,"backup_user_id":None,"backup_name":"","assigned_by_user_id":1,"assigned_by":"Senior","assigned_at":datetime.utcnow().isoformat(),"revision":1,"access_scope":"NAMED_USERS"}]
            current["qc"]=[]; current["results"]=[]; current["assignmentCompletions"]=[]
            no_qc=deepcopy(current); no_qc["results"].append({"id":"R-PF-NOQC","batch":"B-PF","sample":"PF-S1","test":test_name,"result":"0.001"})
            with pytest.raises(PermissionError, match="QC must be completed"):
                validate_operations_update(current,no_qc,chemist,db=db,site_id=site.id)
            with_qc=deepcopy(current); with_qc["qc"].append({"id":"QC-PF","mode":"routine","test":test_name,"assignment_id":"WSA-PF","batch_id":"B-PF","target":"0","result":"0.001","status":"PASS"})
            with_qc["results"].append({"id":"R-PF","batch":"B-PF","sample":"PF-S1","test":test_name,"result":"0.001","qc_record_id":"QC-PF"})
            accepted=validate_operations_update(current,with_qc,chemist,db=db,site_id=site.id)
            assert accepted["qc"][-1]["status"] == "RECORDED"
            assert accepted["results"][-1]["qc_status"] == "RECORDED"
