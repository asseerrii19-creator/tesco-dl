from __future__ import annotations

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import EquipmentAsset, Site, User
from app.seed import seed
from app.services.lab_operations import (
    _bind_required_qc_to_result,
    _qc_source_package_test,
    _result_qc_context,
    _validate_analytical_qc_assignment,
)


def _payload(user: User, tests: list[dict], workstation: str, batch_id: str = "LB-V352") -> dict:
    return {
        "batches": [{"id": batch_id, "samples": ["FS-V352-1"], "tests": tests, "status": "Testing"}],
        "testAssignments": [{
            "id": f"WSA-{batch_id}-{workstation}", "batch_id": batch_id,
            "workstation": workstation, "mode": "SINGLE",
            "primary_user_id": user.id, "primary_name": user.full_name,
            "backup_user_id": None, "backup_name": "", "revision": 1,
        }],
        "qc": [],
    }


def test_report_path_equipment_master_contains_verified_electrical_ift_and_color_assets():
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "DMM")); assert site
            expected = {
                "EQ-03": ("Physical / Chemistry", "ASTM D971"),
                "EQ-04": ("Physical / Chemistry", "ASTM D971"),
                "EQ-05": ("Physical / Chemistry", "ASTM D1500"),
                "EQ-24": ("Electrical", "IEC 60156"),
                "EQ-25": ("Electrical", "IEC 60156"),
                "EQ-30": ("Electrical", "IEC 60156"),
                "EQ-49": ("Electrical", "ASTM D924"),
                "EQ-130": ("Electrical", "ASTM D924"),
            }
            for equipment_id, (workstation, method_token) in expected.items():
                row = db.scalar(select(EquipmentAsset).where(
                    EquipmentAsset.site_id == site.id,
                    EquipmentAsset.equipment_id == equipment_id,
                ))
                assert row, equipment_id
                assert row.workstation == workstation
                assert method_token in row.test_method
                assert row.active is True
                assert row.status == "IN_SERVICE"


def test_startup_reconciles_legacy_structural_mapping_without_resetting_operational_dates():
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "DMM")); assert site
            row = db.scalar(select(EquipmentAsset).where(
                EquipmentAsset.site_id == site.id, EquipmentAsset.equipment_id == "EQ-49"
            )); assert row
            original_cal = row.next_calibration_at
            original_ver = row.next_verification_at
            row.name = "Legacy Wrong Name"
            row.workstation = "Legacy"
            row.test_method = "Wrong Method"
            row.active = False
            row.status = "IN_SERVICE"
            db.commit()

        seed()

        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "DMM")); assert site
            row = db.scalar(select(EquipmentAsset).where(
                EquipmentAsset.site_id == site.id, EquipmentAsset.equipment_id == "EQ-49"
            )); assert row
            assert row.name == "Power/Dissipation Factor Instrument"
            assert row.workstation == "Electrical"
            assert row.test_method == "ASTM D924 / IEC 60247"
            assert row.active is True
            assert row.status == "IN_SERVICE"
            assert row.next_calibration_at == original_cal
            assert row.next_verification_at == original_ver


def test_appearance_is_not_a_duplicate_equipment_qc_and_inherits_color_control_when_color_is_requested():
    assert not _qc_source_package_test({"test": "Appearance", "method": "ASTM D1524", "station": "Physical / Chemistry"})
    tests = [
        {"test": "Color ASTM", "method": "ASTM D1500", "station": "Physical / Chemistry"},
        {"test": "Appearance", "method": "ASTM D1524", "station": "Physical / Chemistry"},
    ]
    batch = {"id": "LB-A", "tests": tests}
    ctx = _result_qc_context(batch, {"test": "Appearance", "display_test": "Appearance"})
    assert ctx["group"] == "Color"
    assert ctx["test"] == "Color ASTM"
    assert ctx["method"] == "ASTM D1500"
    assert ctx["inherited_for"] == "Appearance"

    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == "DMM")); assert site
            user = db.scalar(select(User).where(User.email == "technician@tsco.local")); assert user
            eq = db.scalar(select(EquipmentAsset).where(
                EquipmentAsset.site_id == site.id, EquipmentAsset.equipment_id == "EQ-05"
            )); assert eq
            payload = _payload(user, tests, "Physical / Chemistry", "LB-A")
            qc = {
                "id": "QC-COLOR-V352", "mode": "routine", "test": "Color",
                "context_test": "Color ASTM", "method_name": "ASTM D1500",
                "workstation": "Physical / Chemistry", "batch_id": "LB-A",
                "assignment_id": "WSA-LB-A-Physical / Chemistry",
                "equipment_asset_id": eq.id, "result": "1", "status": "RECORDED",
                "ts": "2026-10-02T12:00:00",
            }
            _validate_analytical_qc_assignment(payload, qc, user, db=db, site_id=site.id)
            payload["qc"].append(qc)
            row = {
                "id": "R-APP-V352", "batch": "LB-A", "sample": "FS-V352-1",
                "test": "Appearance", "display_test": "Appearance", "result": "Clear",
            }
            _bind_required_qc_to_result(payload, payload["batches"][0], row, user, db=db, site_id=site.id)
            assert row["qc_group"] == "Color"
            assert row["qc_record_id"] == "QC-COLOR-V352"
            assert row["equipment_id"] == "EQ-05"
            assert row["test_method"] == "ASTM D1500"


def test_standalone_appearance_is_controlled_observation_without_fabricated_equipment_id():
    with TestClient(app):
        with SessionLocal() as db:
            user = db.scalar(select(User).where(User.email == "technician@tsco.local")); assert user
            tests = [{"test": "Appearance", "method": "ASTM D1524", "station": "Physical / Chemistry"}]
            payload = _payload(user, tests, "Physical / Chemistry", "LB-APP-ONLY")
            row = {
                "id": "R-APP-ONLY", "batch": "LB-APP-ONLY", "sample": "FS-V352-1",
                "test": "Appearance", "display_test": "Appearance", "result": "Clear",
            }
            _bind_required_qc_to_result(payload, payload["batches"][0], row, user, db=db, site_id=user.site_id)
            assert row["qc_status"] == "RECORDED"
            assert row["qc_schedule_reason"] == "CONTROLLED_OBSERVATION"
            assert row["equipment_asset_id"] is None
            assert row["equipment_id"] == ""
            assert row["test_method"] == "ASTM D1524"


def test_frontend_distinguishes_missing_master_data_from_not_ready_equipment_and_appearance_is_not_qc_panel_source():
    html = (app.root_path and "")  # keep app import live; assertion reads deployed source below
    from pathlib import Path
    source = (Path(__file__).resolve().parents[1] / "app" / "lab_ops" / "index_template.html").read_text()
    assert "function equipmentMappedForQcContext(ctx)" in source
    assert "EQUIPMENT NOT READY" in source
    assert "calibration is overdue" in source
    assert "verification is overdue" in source
    assert "paper lifetime|appearance" in source
    assert "inherited_for:'Appearance'" in source
