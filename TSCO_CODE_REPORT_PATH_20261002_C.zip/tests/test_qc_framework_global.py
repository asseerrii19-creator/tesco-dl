from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import select
import pytest

from app.main import app
from app.database import SessionLocal
from app.models import EquipmentAsset, Site, User
from app.services.lab_operations import (
    _bind_required_qc_to_result,
    _equipment_supports_method,
    _qc_group_for_result_test,
    _qc_source_package_test,
    _qc_workstation,
    _result_qc_context,
    _validate_analytical_qc_assignment,
)


def _login(client: TestClient, email: str) -> None:
    r = client.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303


def _payload_for(user: User, tests: list[dict], workstation: str, batch_id: str = 'LB-QC-FRAMEWORK') -> dict:
    return {
        'batches': [{
            'id': batch_id,
            'samples': ['FS-QC-1'],
            'tests': tests,
            'status': 'Testing',
        }],
        'testAssignments': [{
            'id': f'WSA-{batch_id}-{workstation}',
            'batch_id': batch_id,
            'workstation': workstation,
            'mode': 'SINGLE',
            'primary_user_id': user.id,
            'primary_name': user.full_name,
            'backup_user_id': None,
            'backup_name': '',
            'revision': 1,
        }],
        'qc': [],
    }


def test_global_qc_classifier_fixes_direct_dp_and_pour_point():
    assert _qc_group_for_result_test('Direct DP-value') == 'Paper DP'
    assert _qc_workstation('Direct DP-value') == 'Paper DP / Furan'
    assert _qc_workstation('Pour Point') == 'Physical / Chemistry'


def test_equipment_method_matching_is_controlled_not_free_text_equivalence():
    assert _equipment_supports_method('IEC 60156 / ASTM D1816 / ASTM D877', 'ASTM D1816')
    assert _equipment_supports_method('ASTM D924 / IEC 60247', 'IEC 60247')
    assert not _equipment_supports_method('ASTM D924 / IEC 60247', 'ASTM D1169')
    assert not _equipment_supports_method('', 'IEC 60814')


def test_qc_source_policy_excludes_only_operational_or_derived_outputs():
    for row in (
        {'test': 'Room Test Temperature', 'method': '-'},
        {'test': 'Room Test Humidity', 'method': '-'},
        {'test': 'Transformer Oil Temperature', 'method': '-'},
        {'test': 'Water Content @20 °C', 'method': 'IEC 60814'},
        {'test': 'Humidity in Cellulose', 'method': 'IEC 60814'},
        {'test': 'Oil Quality Index', 'method': 'calculation'},
        {'test': 'RSD% of BDV @2.5mm', 'method': 'IEC 60156'},
        {'test': 'Indirect DP-value', 'method': 'Calculation'},
        {'test': 'Paper Lifetime Remaining', 'method': 'Calculation'},
    ):
        assert not _qc_source_package_test(row), row

    for row in (
        {'test': 'Water Content KF @RT', 'method': 'IEC 60814'},
        {'test': 'Dissolved Gas Analysis (DGA)', 'method': 'IEC 60567'},
        {'test': 'Power Factor @25°C/60Hz', 'method': 'ASTM D924'},
        {'test': 'Breakdown Voltage @2.5mm- AVG', 'method': 'IEC 60156'},
        {'test': '2-Furfural (2FAL)', 'method': 'IEC 61198'},
        {'test': 'Direct DP-value', 'method': 'IEC 60450'},
        {'test': 'Dibenzyl Disulfide (DBDS)', 'method': 'IEC 62697-1'},
        {'test': 'Total Acid Number', 'method': 'ASTM D664'},
        {'test': 'Potentially Corrosive Sulfur (CCD)', 'method': 'IEC 62535'},
        {'test': 'Color ASTM', 'method': 'ASTM D1500'},
        {'test': 'Particle Count ISO', 'method': 'ISO 4406'},
    ):
        assert _qc_source_package_test(row), row


def test_every_master_measured_analytical_test_resolves_a_global_qc_context():
    catalog_path = Path(__file__).resolve().parents[1] / 'app' / 'data' / 'lab_packages.json'
    catalog = json.loads(catalog_path.read_text())
    source_tests = [row for row in catalog['tests'] if _qc_source_package_test(row)]
    assert len(source_tests) >= 100  # protects against accidentally narrowing QC to a short hand-maintained list

    failures = []
    for idx, row in enumerate(source_tests):
        batch = {'id': f'CAT-{idx}', 'tests': [row]}
        context = _result_qc_context(batch, {'test': row['test'], 'display_test': row['test']})
        if not context.get('group') or not context.get('test') or not context.get('workstation'):
            failures.append((row, context))
        assert context['test'] == row['test']
        assert context['method'] == str(row.get('method') or '')
        assert context['workstation'] == row['station']
    assert not failures


def test_bdv_rsd_inherits_exact_measured_bdv_qc_context():
    batch = {
        'id': 'LB-BDV-QC',
        'tests': [
            {'test': 'Breakdown Voltage @2.5mm- AVG', 'method': 'IEC 60156', 'station': 'Electrical'},
            {'test': 'RSD% of BDV @2.5mm', 'method': 'IEC 60156', 'station': 'Electrical'},
        ],
    }
    ctx = _result_qc_context(batch, {'test': 'RSD% of BDV @2.5mm', 'display_test': 'RSD% of BDV @2.5mm'})
    assert ctx == {
        'group': 'BDV',
        'test': 'Breakdown Voltage @2.5mm- AVG',
        'method': 'IEC 60156',
        'workstation': 'Electrical',
    }


@pytest.mark.parametrize(
    ('test_name', 'method', 'workstation'),
    [
        ('Dissolved Gas Analysis (DGA)', 'IEC 60567', 'DGA'),
        ('Power Factor @25°C/60Hz', 'ASTM D924', 'Electrical'),
        ('Breakdown Voltage @2.5mm- AVG', 'IEC 60156', 'Electrical'),
        ('2-Furfural (2FAL)', 'IEC 61198', 'Furan / Passivator'),
        ('Direct DP-value', 'IEC 60450', 'Paper DP / Furan'),
        ('Dibenzyl Disulfide (DBDS)', 'IEC 62697-1', 'DBDS / BHT / Toluene / PCB'),
        ('Total Acid Number', 'ASTM D664', 'TAN / Peroxide / RSH / H2S'),
        ('Potentially Corrosive Sulfur (CCD)', 'IEC 62535', 'Corrosion / CCD'),
        ('Color ASTM', 'ASTM D1500', 'Physical / Chemistry'),
        ('Particle Count ISO', 'ISO 4406', 'Additives / Special Tests'),
    ],
)
def test_non_water_families_are_blocked_by_the_same_qc_gate(test_name, method, workstation):
    with TestClient(app):
        with SessionLocal() as db:
            user = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert user
            batch_id = 'LB-GLOBAL-' + str(abs(hash((test_name, method))) % 1_000_000)
            test_row = {'test': test_name, 'method': method, 'station': workstation}
            payload = _payload_for(user, [test_row], workstation, batch_id=batch_id)
            result = {
                'id': 'R-GLOBAL', 'batch': batch_id, 'sample': 'FS-QC-1',
                'test': test_name, 'display_test': test_name, 'result': '1',
            }
            with pytest.raises(PermissionError, match='Analytical/Test QC must be completed'):
                _bind_required_qc_to_result(payload, payload['batches'][0], result, user, db=None, site_id=None)

            context = _result_qc_context(payload['batches'][0], result)
            payload['qc'].append({
                'id': 'QC-GLOBAL', 'mode': 'routine', 'test': context['group'],
                'context_test': context['test'], 'method_name': context['method'],
                'batch_id': batch_id, 'assignment_id': f'WSA-{batch_id}-{workstation}',
                'equipment_asset_id': 999, 'equipment_id': 'EQ-TEST',
                'result': '1', 'status': 'RECORDED', 'ts': '2026-10-02T12:00:00',
            })
            _bind_required_qc_to_result(payload, payload['batches'][0], result, user, db=None, site_id=None)
            assert result['qc_record_id'] == 'QC-GLOBAL'
            assert result['qc_context_test'] == context['test']
            assert result['test_method'] == context['method']
            assert result['workstation'] == workstation
            assert result['equipment_id'] == 'EQ-TEST'


def test_water_dual_instrument_qc_requires_both_equipment_and_each_raw_result_inherits_exact_qc():
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            user = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert user
            water69 = db.scalar(select(EquipmentAsset).where(EquipmentAsset.site_id == site.id, EquipmentAsset.equipment_id == 'EQ-69')); assert water69
            water70 = db.scalar(select(EquipmentAsset).where(EquipmentAsset.site_id == site.id, EquipmentAsset.equipment_id == 'EQ-70')); assert water70
            pf = db.scalar(select(EquipmentAsset).where(EquipmentAsset.site_id == site.id, EquipmentAsset.equipment_id == 'EQ-49')); assert pf

            tests = [{'test': 'Water Content KF @RT', 'method': 'IEC 60814', 'station': 'Water'}]
            payload = _payload_for(user, tests, 'Water')

            def add_qc(eq, qid, ts):
                row = {
                    'id': qid, 'mode': 'routine', 'test': 'Water',
                    'context_test': 'Water Content KF @RT', 'method_name': 'IEC 60814',
                    'batch_id': 'LB-QC-FRAMEWORK', 'assignment_id': 'WSA-LB-QC-FRAMEWORK-Water',
                    'equipment_asset_id': eq.id, 'result': '8.0', 'status': 'PASS', 'ts': ts,
                }
                _validate_analytical_qc_assignment(payload, row, user, db=db, site_id=site.id)
                payload['qc'].append(row)
                return row

            q69a = add_qc(water69, 'QC-69-1', '2026-10-02T12:00:00')
            q69b = add_qc(water69, 'QC-69-2', '2026-10-02T12:01:00')
            q70a = add_qc(water70, 'QC-70-1', '2026-10-02T12:00:30')
            q70b = add_qc(water70, 'QC-70-2', '2026-10-02T12:01:30')
            assert q69b['equipment_id'] == 'EQ-69'
            assert q70b['equipment_id'] == 'EQ-70'

            wrong = dict(q69a, id='QC-WRONG-EQ', equipment_asset_id=pf.id)
            with pytest.raises(PermissionError, match='belongs to Electrical, not Water'):
                _validate_analytical_qc_assignment(payload, wrong, user, db=db, site_id=site.id)

            result = {
                'id': 'R-WATER-69', 'batch': 'LB-QC-FRAMEWORK', 'sample': 'FS-QC-1',
                'test': 'WATER:KF_RT:EQ-69', 'display_test': 'Water Content KF @RT — EQ-69', 'result': '8',
                'equipment_asset_id': water69.id,
            }
            _bind_required_qc_to_result(payload, payload['batches'][0], result, user, db=db, site_id=site.id)
            assert result['qc_record_id'] == 'QC-69-2'
            assert result['qc_context_test'] == 'Water Content KF @RT'
            assert result['test_method'] == 'IEC 60814'
            assert result['equipment_asset_id'] == water69.id
            assert result['equipment_id'] == 'EQ-69'


def test_same_workstation_wrong_method_equipment_is_rejected():
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            user = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert user
            bdv = db.scalar(select(EquipmentAsset).where(EquipmentAsset.site_id == site.id, EquipmentAsset.equipment_id == 'EQ-24')); assert bdv
            payload = _payload_for(
                user,
                [{'test': 'Power Factor @25°C/60Hz', 'method': 'ASTM D924', 'station': 'Electrical'}],
                'Electrical',
                batch_id='LB-PF-QC',
            )
            qc = {
                'id': 'QC-WRONG-METHOD', 'mode': 'routine', 'test': 'Power Factor @25°C/60Hz',
                'context_test': 'Power Factor @25°C/60Hz', 'method_name': 'ASTM D924',
                'batch_id': 'LB-PF-QC', 'assignment_id': 'WSA-LB-PF-QC-Electrical',
                'equipment_asset_id': bdv.id, 'result': '1', 'status': 'RECORDED',
            }
            with pytest.raises(PermissionError, match='does not authorize method ASTM D924'):
                _validate_analytical_qc_assignment(payload, qc, user, db=db, site_id=site.id)


def test_derived_or_operational_rows_cannot_be_selected_as_qc_contexts():
    with TestClient(app):
        with SessionLocal() as db:
            user = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert user
            payload = _payload_for(
                user,
                [
                    {'test': 'Breakdown Voltage @2.5mm- AVG', 'method': 'IEC 60156', 'station': 'Electrical'},
                    {'test': 'RSD% of BDV @2.5mm', 'method': 'IEC 60156', 'station': 'Electrical'},
                ],
                'Electrical', batch_id='LB-DERIVED-QC',
            )
            qc = {
                'id': 'QC-BAD-DERIVED', 'mode': 'routine', 'test': 'BDV',
                'context_test': 'RSD% of BDV @2.5mm', 'method_name': 'IEC 60156',
                'batch_id': 'LB-DERIVED-QC', 'assignment_id': 'WSA-LB-DERIVED-QC-Electrical',
                'equipment_asset_id': 1, 'result': '1', 'status': 'RECORDED',
            }
            with pytest.raises(PermissionError, match='independently measured source test'):
                _validate_analytical_qc_assignment(payload, qc, user, db=None, site_id=None)


def test_lab_console_exposes_one_global_qc_policy_not_a_water_only_gate():
    with TestClient(app) as browser:
        _login(browser, 'technician@tsco.local')
        page = browser.get('/lab/operations/app?embed=1&section=quality')
        assert page.status_code == 200
        html = page.text
        assert 'Requested Test / Method Context' in html
        assert 'Exact Equipment ID' in html
        assert '<select id="qcContext">' in html
        assert '<select id="qi">' in html
        assert 'Analytical QC readiness' in html
        assert 'equipment_asset_id:equipment.id' in html
        assert 'One global QC gate applies to every independently measured analytical test' in html
        assert '.filter(qcSourceTest)' in html
        assert 'if(!qc)return alert(`Water Analytical/Test QC is required' not in html
        assert "test:code,display_test:'Water Content KF @RT — '+r.eqid" in html
        assert "upsertAutoResult(s,b,'WATER:KF_RT','Water Content KF @RT'" in html
