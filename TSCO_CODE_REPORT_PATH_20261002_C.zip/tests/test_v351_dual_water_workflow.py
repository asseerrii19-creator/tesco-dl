from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import Site, User
from app.services.lab_operations import (
    _bind_required_qc_to_result,
    _required_water_equipment_ids,
    _validate_calculated_result,
)


def _base_payload(user: User) -> dict:
    return {
        'batches': [{
            'id': 'B-WATER-DUAL',
            'samples': [f'S{i}' for i in range(1, 12)],
            'sample_meta': {f'S{i}': {'temp': 48} for i in range(1, 12)},
            'tests': [{'test': 'Water Content KF @RT', 'method': 'IEC 60814', 'station': 'Water', 'unit': 'mg/kg'}],
            'status': 'Testing',
        }],
        'testAssignments': [{
            'id': 'A-WATER-DUAL', 'batch_id': 'B-WATER-DUAL', 'workstation': 'Water',
            'mode': 'SINGLE', 'primary_user_id': user.id, 'revision': 1,
        }],
        'qc': [], 'results': [],
    }


def _ctx() -> dict[str, str]:
    return {'group': 'Water', 'test': 'Water Content KF @RT', 'method': 'IEC 60814', 'workstation': 'Water'}


def _qc(eq, n: int, ts: str) -> dict:
    return {
        'id': f'QC-{eq.equipment_id}-{n}', 'mode': 'routine', 'test': 'Water',
        'context_test': 'Water Content KF @RT', 'method_name': 'IEC 60814', 'workstation': 'Water',
        'equipment_asset_id': eq.id, 'equipment_id': eq.equipment_id, 'equipment_name': eq.name,
        'status': 'PASS', 'ts': ts, 'qc_day': '2026-10-02',
    }


def _raw(eq, sample: str, value: str, rid: str) -> dict:
    return {
        'id': rid, 'batch': 'B-WATER-DUAL', 'sample': sample,
        'test': f'WATER:KF_RT:{eq.equipment_id}',
        'display_test': f'Water Content KF @RT — {eq.equipment_id}',
        'result': value, 'unit': 'mg/kg', 'equipment_asset_id': eq.id,
    }


def test_water_blocks_first_sample_until_every_active_instrument_has_two_startup_qcs():
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            user = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert user
            payload = _base_payload(user)
            ids = _required_water_equipment_ids(payload, _ctx(), db=db, site_id=site.id)
            assert len(ids) >= 2
            equipment = [db.get(__import__('app.models', fromlist=['EquipmentAsset']).EquipmentAsset, eq_id) for eq_id in ids]
            assert all(equipment)

            first = equipment[0]
            payload['qc'].extend([
                _qc(first, 1, '2026-10-02T05:01:00'),
                _qc(first, 2, '2026-10-02T05:02:00'),
            ])
            row = _raw(first, 'S1', '8.0', 'R-FIRST')
            proposed = deepcopy(payload); proposed['results'].append(row)
            with pytest.raises(PermissionError, match='Analytical/Test QC must be completed'):
                _bind_required_qc_to_result(proposed, proposed['batches'][0], row, user, db=db, site_id=site.id)

            for idx, eq in enumerate(equipment[1:], start=1):
                payload['qc'].extend([
                    _qc(eq, 1, f'2026-10-02T05:0{2+idx}:00'),
                    _qc(eq, 2, f'2026-10-02T05:0{3+idx}:00'),
                ])
            row = _raw(first, 'S1', '8.0', 'R-FIRST-READY')
            proposed = deepcopy(payload); proposed['results'].append(row)
            _bind_required_qc_to_result(proposed, proposed['batches'][0], row, user, db=db, site_id=site.id)
            assert row['equipment_id'] == first.equipment_id
            assert row['qc_record_id'] == f'QC-{first.equipment_id}-2'


def test_final_water_is_verified_average_of_one_raw_reading_from_each_active_instrument():
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            user = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert user
            payload = _base_payload(user)
            ids = _required_water_equipment_ids(payload, _ctx(), db=db, site_id=site.id)
            assert len(ids) >= 2
            EquipmentAsset = __import__('app.models', fromlist=['EquipmentAsset']).EquipmentAsset
            equipment = [db.get(EquipmentAsset, eq_id) for eq_id in ids]
            for idx, eq in enumerate(equipment):
                payload['qc'].extend([
                    _qc(eq, 1, f'2026-10-02T05:{1+idx:02d}:00'),
                    _qc(eq, 2, f'2026-10-02T05:{3+idx:02d}:00'),
                ])

            values = [8.0 + idx * 0.4 for idx in range(len(equipment))]
            raw_rows = []
            for idx, (eq, value) in enumerate(zip(equipment, values), start=1):
                row = _raw(eq, 'S1', str(value), f'R-RAW-{idx}')
                proposed = deepcopy(payload); proposed['results'].extend(raw_rows + [row])
                _bind_required_qc_to_result(proposed, proposed['batches'][0], row, user, db=db, site_id=site.id)
                raw_rows.append(row)
            payload['results'].extend(raw_rows)

            expected = sum(values) / len(values)
            final = {
                'id': 'R-WATER-AVG', 'batch': 'B-WATER-DUAL', 'sample': 'S1',
                'test': 'WATER:KF_RT', 'display_test': 'Water Content KF @RT',
                'result': str(round(expected, 2)), 'unit': 'mg/kg', 'calculated': True,
            }
            _validate_calculated_result(payload, payload['batches'][0], final, db=db, site_id=site.id)

            wrong = dict(final, id='R-WATER-BAD', result=str(round(expected + 1.0, 2)))
            with pytest.raises(PermissionError, match='dual-instrument average'):
                _validate_calculated_result(payload, payload['batches'][0], wrong, db=db, site_id=site.id)


def test_water_workstation_ui_exposes_both_raw_readings_and_automatic_average():
    source = (Path(__file__).parents[1] / 'app' / 'lab_ops' / 'index_template.html').read_text()
    assert 'Water result entry stays locked until every active Water instrument is QC-ready.' in source
    assert 'SAVE BOTH READINGS + AVERAGE' in source
    assert "const code='WATER:KF_RT:'+eq.equipment_id" in source
    assert "source:'Water dual-instrument reading'" in source
    assert "formula_id:'WATER_DUAL_AVERAGE'" in source
    assert 'Final Water @RT' in source
    assert 'two acceptable startup QC runs on EACH active Water instrument' in source
    assert 'mandatory QC checkpoint on EACH Water instrument before sample 11' in source
