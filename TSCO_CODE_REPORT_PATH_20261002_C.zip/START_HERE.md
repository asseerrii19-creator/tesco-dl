# START HERE — Project 00012 v3.4.8 Global Analytical/Test QC UAT

1. Read `V3.4.8_GLOBAL_ANALYTICAL_QC.md` and retain `V3.4.7_CONTROLLED_INTAKE_AMENDMENT.md` as the prior intake-control record.
2. Deploy without database reset.
3. Continue the existing UAT case and Lab Batch; do not recreate samples.
4. In Data Entry > All Intake Records > View Record, use `Amend Intake Data` for verified corrections or `Newer Client Data Form` for a revised source document.
5. Return to Chemical Technician > Water; the current batch reads the latest authoritative Intake values automatically.

Alembic head remains `c43a7d9e2f10`.
