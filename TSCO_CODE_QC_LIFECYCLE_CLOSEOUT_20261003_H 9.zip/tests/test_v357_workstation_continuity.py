from pathlib import Path
from types import SimpleNamespace

from app.services import lab_operations as ops


def _u(uid=17, name='UAT Role — Chemist'):
    return SimpleNamespace(role='lab_technician', id=uid, full_name=name)


def _corrupted_payload():
    return {
        'staff': [
            {'id': 17, 'name': 'UAT Role — Chemist', 'role': 'lab_technician', 'active': True},
            {'id': 18, 'name': 'UAT Role — Chemical Technician', 'role': 'lab_technician', 'active': True},
        ],
        'batches': [{
            'id': 'LB-20261001175803-A162C1',
            'samples': ['FS-DMM-26-000003', 'FS-DMM-26-000004'],
            'sample_meta': {'FS-DMM-26-000003': {'portalRequest':'FS-DMM-26-000003'}, 'FS-DMM-26-000004': {'portalRequest':'FS-DMM-26-000004'}},
            'tests': [
                {'test': 'Room Test Temperature', 'method': '-', 'station': 'Additives / Special Tests'},
                {'test': 'Room Test Humidity', 'method': '-', 'station': 'Additives / Special Tests'},
                {'test': 'Breakdown Voltage @2.5mm- AVG', 'method': 'IEC 60156', 'station': 'Electrical'},
                {'test': 'RSD% of BDV @2.5mm', 'method': 'IEC 60156', 'station': 'Electrical'},
                {'test': 'Power Factor @25°C/60Hz', 'method': 'ASTM D924', 'station': 'Electrical'},
                {'test': 'Power Factor @100°C/60Hz', 'method': 'ASTM D924', 'station': 'Electrical'},
            ],
        }],
        'testAssignments': [
            {
                'id': 'BAD-ELECTRICAL', 'batch_id': '*', 'scope': 'WORKSTATION', 'workstation': 'Electrical',
                'mode': 'SINGLE', 'primary_user_id': 18, 'primary_name': 'UAT Role — Chemical Technician',
                'revision': 4, 'source': 'AUTO_14_DAY_ROTATION_CONTINUITY_REPAIR',
                'cycle_key': '20260927-20261010', 'assigned_at': '2026-10-04T03:00:00',
            },
            {
                'id': 'BAD-ADDITIVES', 'batch_id': '*', 'scope': 'WORKSTATION', 'workstation': 'Additives / Special Tests',
                'mode': 'SINGLE', 'primary_user_id': 17, 'primary_name': 'UAT Role — Chemist',
                'revision': 4, 'source': 'AUTO_14_DAY_ROTATION_CONTINUITY_REPAIR',
                'cycle_key': '20260927-20261010', 'assigned_at': '2026-10-04T03:00:01',
            },
        ],
        'results': [], 'qc': [], 'qualifiedQcProfiles': [], 'qcLots': [], 'qcLotEvents': [], 'qcEvidence': [],
        'retests': [], 'dgaAttachments': [], 'resultEvidence': [], 'assignmentCompletions': [],
        'qualityDistributions': [], 'qualityTaskEvents': [], 'reports': [], 'retained': [], 'storageAssignments': [],
        'batchHistory': [], 'cancelledSamples': [], 'supervisorNotes': [],
    }


def test_room_environment_rows_are_not_analytical_workstations():
    payload = _corrupted_payload()
    assert ops._batch_workstations(payload['batches'][0]) == {'Electrical'}


def test_browser_visibility_is_driven_by_assigned_batch_not_stray_global_row():
    html = Path('app/lab_ops/index_template.html').read_text(encoding='utf-8')
    assert "function visibleWorkstations(){if(CURRENT_ROLE!=='lab_technician')" in html
    assert "(DB.batches||[]).forEach(b=>batchWorkstations(b).forEach" in html
    assert "String(a.batch_id||'')==='*'&&assignmentAllowsUser(a)" not in html
    assert "isOperationalInputTest" in html


def test_outer_lab_shell_does_not_auto_reopen_stale_workstation_from_local_storage():
    wrapper = Path('app/routes/lab_operations.py').read_text(encoding='utf-8')
    assert "last-workstation" not in wrapper
    assert "reconcile_analytical_rotation_continuity" not in wrapper
    assert "ensure_analytical_rotation_assignments(db, site.id, payload, required_workstations)" not in wrapper
