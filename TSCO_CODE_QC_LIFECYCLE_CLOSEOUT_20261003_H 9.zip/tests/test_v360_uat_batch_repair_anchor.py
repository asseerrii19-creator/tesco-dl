from datetime import datetime

from app.services import lab_operations as ops


def test_known_uat_batch_id_arms_cycle_repair_when_request_refs_are_missing():
    payload = {
        "batches": [{
            "id": "LB-20261001175803-A162C1",
            "samples": ["DMM26-000003", "DMM26-000004"],
            "sample_meta": {},
            "tests": [
                {"test": "Breakdown Voltage @2.5mm- AVG", "method": "IEC 60156", "station": "Electrical"},
                {"test": "Power Factor @25°C/60Hz", "method": "ASTM D924", "station": "Electrical"},
            ],
        }],
        "staff": [
            {"id": 17, "name": "UAT Role — Chemist", "role": "lab_technician", "active": True},
            {"id": 18, "name": "UAT Role — Chemical Technician", "role": "lab_technician", "active": True},
        ],
        "testAssignments": [
            {
                "id": "bad-electrical", "batch_id": "*", "workstation": "Electrical",
                "mode": "SINGLE", "primary_user_id": 18, "primary_name": "UAT Role — Chemical Technician",
                "revision": 3, "assigned_at": "2026-10-01T08:00:00",
                "source": "AUTO_14_DAY_ROTATION", "cycle_key": "20260927-20261010",
            },
            {
                "id": "bad-additives", "batch_id": "*", "workstation": "Additives / Special Tests",
                "mode": "SINGLE", "primary_user_id": 17, "primary_name": "UAT Role — Chemist",
                "revision": 2, "assigned_at": "2026-10-01T08:00:00",
                "source": "AUTO_14_DAY_ROTATION", "cycle_key": "20260927-20261010",
            },
        ],
    }

    repaired = ops.repair_known_uat_cycle_assignments(
        payload, "DMM", when=datetime(2026, 10, 4, 6, 0, 0)
    )
    assert any(r["workstation"] == "Electrical" and r["primary_user_id"] == 17 for r in repaired)
    current = ops._current_test_assignment(payload, "LB-20261001175803-A162C1", "Electrical")
    assert current["primary_user_id"] == 17
    assert current["source"] == "CONTROLLED_UAT_STATE_REPAIR"
