from copy import deepcopy
from datetime import datetime
from types import SimpleNamespace

from app.services import lab_operations as ops


def _chemist():
    return SimpleNamespace(role='lab_technician', id=17, full_name='UAT Role — Chemist')


def _payload():
    return {
        'staff': [
            {'id': 17, 'name': 'UAT Role — Chemist', 'role': 'lab_technician', 'active': True},
            {'id': 18, 'name': 'UAT Role — Chemical Technician', 'role': 'lab_technician', 'active': True},
        ],
        'batches': [{
            'id': 'LB-20261001175803-A162C1', 'samples': ['FS-DMM-26-000003', 'FS-DMM-26-000004'],
            'sample_meta': {'FS-DMM-26-000003': {'portalRequest':'FS-DMM-26-000003'}, 'FS-DMM-26-000004': {'portalRequest':'FS-DMM-26-000004'}},
            'tests': [
                {'test': 'Room Test Temperature', 'station': 'Additives / Special Tests', 'method': '-'},
                {'test': 'Room Test Humidity', 'station': 'Additives / Special Tests', 'method': '-'},
                {'test': 'Breakdown Voltage @2.5mm- AVG', 'station': 'Electrical', 'method': 'IEC 60156'},
                {'test': 'RSD% of BDV @2.5mm', 'station': 'Electrical', 'method': 'IEC 60156'},
                {'test': 'Power Factor @25°C/60Hz', 'station': 'Electrical', 'method': 'ASTM D924'},
                {'test': 'Power Factor @100°C/60Hz', 'station': 'Electrical', 'method': 'ASTM D924'},
            ],
        }],
        'testAssignments': [
            {'id':'BAD-E','batch_id':'*','workstation':'Electrical','mode':'SINGLE','primary_user_id':18,'primary_name':'UAT Role — Chemical Technician','revision':7,'source':'AUTO_14_DAY_ROTATION_CONTINUITY_REPAIR','cycle_key':'20260927-20261010','assigned_at':'2026-10-04T03:00:00'},
            {'id':'BAD-A','batch_id':'*','workstation':'Additives / Special Tests','mode':'SINGLE','primary_user_id':17,'primary_name':'UAT Role — Chemist','revision':3,'source':'AUTO_14_DAY_ROTATION_CONTINUITY_REPAIR','cycle_key':'20260927-20261010','assigned_at':'2026-10-04T03:00:00'},
        ],
        'results': [], 'qc': [], 'qualifiedQcProfiles': [], 'qcLots': [], 'qcLotEvents': [], 'qcEvidence': [],
        'retests': [], 'dgaAttachments': [], 'resultEvidence': [], 'assignmentCompletions': [],
        'qualityDistributions': [], 'qualityTaskEvents': [], 'reports': [], 'retained': [], 'storageAssignments': [],
        'batchHistory': [], 'cancelledSamples': [], 'supervisorNotes': [],
    }


def test_exact_damaged_uat_cycle_is_repaired_from_known_good_backup_authority():
    p = _payload()
    repaired = ops.repair_known_uat_cycle_assignments(p, 'DMM', when=datetime(2026, 10, 4, 6, 0, 0))
    electrical = ops._latest_assignment_for_key(p, '*', 'Electrical')
    assert repaired
    assert electrical['primary_user_id'] == 17
    assert electrical['primary_name'] == 'UAT Role — Chemist'
    assert electrical['source'] == 'CONTROLLED_UAT_STATE_REPAIR'
    assert electrical['cycle_key'] == '20260927-20261010'


def test_repair_expires_outside_the_damaged_cycle_and_does_not_become_scheduler_logic():
    p = _payload()
    before = deepcopy(p['testAssignments'])
    repaired = ops.repair_known_uat_cycle_assignments(p, 'DMM', when=datetime(2026, 10, 20, 6, 0, 0))
    assert repaired == []
    assert p['testAssignments'] == before


def test_repaired_chemist_scope_contains_electrical_batch_and_not_room_input_additives():
    p = _payload()
    ops.repair_known_uat_cycle_assignments(p, 'DMM', when=datetime(2026, 10, 4, 6, 0, 0))
    scoped = ops.scope_operations_payload(p, _chemist())
    assert [b['id'] for b in scoped['batches']] == ['LB-20261001175803-A162C1']
    tests = [r['test'] for r in scoped['batches'][0]['tests']]
    assert 'Breakdown Voltage @2.5mm- AVG' in tests
    assert 'Power Factor @25°C/60Hz' in tests
    assert 'Room Test Temperature' not in tests
    assert 'Room Test Humidity' not in tests
    assert {a['workstation'] for a in scoped['testAssignments']} == {'Electrical'}


def test_batch_specific_senior_exception_remains_authoritative_after_global_repair():
    p = _payload()
    p['testAssignments'].append({
        'id':'SENIOR-EXCEPTION','batch_id':'LB-20261001175803-A162C1','workstation':'Electrical','mode':'SINGLE',
        'primary_user_id':18,'primary_name':'UAT Role — Chemical Technician','revision':1,'source':'SENIOR_EXCEPTION',
        'assigned_by':'UAT Role — Senior Chemist (Technical)','assigned_at':'2026-10-04T05:00:00',
    })
    ops.repair_known_uat_cycle_assignments(p, 'DMM', when=datetime(2026, 10, 4, 6, 0, 0))
    current = ops._current_test_assignment(p, 'LB-20261001175803-A162C1', 'Electrical')
    assert current['id'] == 'SENIOR-EXCEPTION'
    assert ops.scope_operations_payload(p, _chemist())['batches'] == []
