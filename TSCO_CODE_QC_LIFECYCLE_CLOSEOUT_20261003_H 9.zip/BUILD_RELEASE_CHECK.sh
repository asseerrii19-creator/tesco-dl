#!/usr/bin/env bash
set -euo pipefail
MARKER="TSCO-G-ROLLBACK-SAFE-QC-CLOSEOUT-20261004"
echo "TSCO_BUILD_MARKER=${MARKER}"
[[ "$(tr -d '\r\n' < VERSION)" == "3.5.5" ]] || { echo "VERSION assertion failed" >&2; exit 1; }
python -m py_compile app/services/lab_operations.py app/routes/lab_operations.py app/services/document_catalog.py
python - <<'PY'
from pathlib import Path
import re
html=Path('app/lab_ops/index_template.html').read_text(encoding='utf-8')
server=Path('app/services/lab_operations.py').read_text(encoding='utf-8')
route=Path('app/routes/lab_operations.py').read_text(encoding='utf-8')
required_ui=[
    'QC Material / Lot Control','LOT LIFECYCLE','FILE-FIRST','SAVE QC FILE & RESULT',
    'SUBMIT LOT FOR SENIOR APPROVAL','APPROVED LOT REQUIRED','v3.5.5-R1',
    'function isOperationalInputTest(test)',
    "(DB.batches||[]).forEach(b=>batchWorkstations(b).forEach",
]
missing=[x for x in required_ui if x not in html]
if missing: raise SystemExit('rollback-safe UI assertion failed; missing: '+', '.join(missing))
for forbidden in ["String(a.batch_id||'')==='*'&&assignmentAllowsUser(a)"]:
    if forbidden in html: raise SystemExit('forbidden global-row visibility behavior returned: '+forbidden)
required_server=[
    '_QC_ACCEPTABLE = {"PASS"}','def _parse_qc_csv_measurement(','def _sanitize_qc_lots(',
    'def _sanitize_qc_lot_events(','def _qc_record_has_lifecycle_evidence(',
    'def repair_known_uat_cycle_assignments(','def _is_operational_input_test(',
]
missing=[x for x in required_server if x not in server]
if missing: raise SystemExit('rollback-safe server assertion failed; missing: '+', '.join(missing))
for forbidden in ['def reconcile_analytical_rotation_continuity(','def _assignment_is_current_global_default(']:
    if forbidden in server: raise SystemExit('faulty continuity mutation still present: '+forbidden)
if 'repair_known_uat_cycle_assignments(payload, site.code)' not in route:
    raise SystemExit('narrow UAT state repair is not wired to operations load')
if 'reconcile_analytical_rotation_continuity' in route:
    raise SystemExit('faulty GET-time continuity reconciler still wired')
scripts=re.findall(r'<script[^>]*>(.*?)</script>',html,flags=re.S|re.I)
Path('/tmp/tsco_rollback_safe.js').write_text('\n'.join(scripts),encoding='utf-8')
print('TSCO_ROLLBACK_SAFE_ASSERTION=PASS')
PY
node --check /tmp/tsco_rollback_safe.js
pytest -q -W ignore --tb=no \
  tests/test_v347_controlled_intake_amendment.py::test_lab_technician_has_analytical_qc_workspace_and_clear_qc_gate \
  tests/test_v349_qc_workstation_entrypoint.py \
  tests/test_v350_daily_analytical_qc_control.py \
  tests/test_v351_dual_water_workflow.py \
  tests/test_v352_report_path_closeout.py \
  tests/test_v354_electrical_qc_closeout.py \
  tests/test_v355_uat_behavioral_closeout.py \
  tests/test_v356_qc_lifecycle_file_first.py \
  tests/test_v357_workstation_continuity.py \
  tests/test_v358_workstation_assignment_authority.py \
  tests/test_v359_uat_electrical_report_path.py
