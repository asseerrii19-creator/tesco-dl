# TSCO UAT Commercial Flow Fix Batch — R14.9 / v3.7.12

Includes R14.7 sampling import and the pending R14.8 package-parameter button fix.

## Fixes and causes

1. Quotation confirmation previously required a typed number. New quotations and revisions now allocate QT-{site}-{year}-{sequence} on the server using the existing atomic SQL identifier allocator. Submitted primary IDs are ignored. Numbers, issued pricing/PDF and Business Case linkage are immutable; External / ERP Reference is a separate optional field. Commercial events and audit records retain the generated reference.
2. Pricing previously read default package methods independently of the laboratory family resolver. Commercial preview, parameter review and laboratory scope now share controlled family mappings. Existing known DGA/KF mappings are populated in SQL during migration; explicit site mappings remain authoritative. Admin package rows retain optional ASTM/IEC mapping columns. BDV and its RSD pair resolve together. Tests without a configured equivalent require individual fixed-method review and a reason at quotation confirmation, stored with actor and scope. IEC water calculations do not acquire invented ASTM equivalents.
3. Issued quotations now freeze 14 commercial rows, quantities, methods, base rates, TAT multipliers, net, VAT, total, scope and a generated PDF. The Client Portal shows the same evidence before acceptance. Server acceptance requires published evidence, current quotation ID and acknowledgement of the displayed amount. Old/stale submissions fail. Client PDF access remains account-scoped. Later package edits cannot alter accepted scope/pricing/PDF or laboratory method resolution.
4. Supporting documents now distinguish Current / Confirmed Data Form and source uploads for every active sheet from collapsed Version History / Previous Uploads. No historical file or DB record is removed.

## Existing UAT quotation QT-UAT-0006

The migration preserves existing quotation numbers and Business Case BC-DMM-2026-0006. It does not invent historical approved prices. If this quotation has not yet been accepted, its assigned Coordinator must use **Publish Commercial Quotation**, reviewing any method exceptions, to freeze and expose its amounts/PDF before Client Acceptance. New quotations require no manual primary number.

Existing accepted quotations/POs and audit history are retained; this package does not reset the user's active Business Case or approve a quote on their behalf. Rates remain explicitly labeled UAT DEMO, as in the existing Coordinator preview.

## Validation

- BUILD_RELEASE_CHECK.sh: 112 passed (103 preserved baseline + 9 commercial regression tests).
- Fresh and in-place SQLite Alembic upgrades passed; head c6a2f9e81740.
- Concurrent server numbering, immutable identifiers, ASTMs for DGA/KF/BDV, 14-row preservation, fixed-method conflict rejection/review, client amounts/PDF, stale acceptance rejection, PO and four-sample Intake/laboratory inheritance, legacy publication, revision history and multi-form supporting-document separation covered.
- Package dialog JavaScript check passed for 10 primary parameter rows, custom selection and both controls. Family-specific method display uses the shared resolver.
- Generated quotation PDF rendered and visually reviewed; includes all 14 rows, totals and explicit method exceptions.

## Deployment

Upload only TSCO_CODE_UAT_COMMERCIAL_FLOW_R14_9_AUDITED_LITE_20261011.zip as the new code release. Retain existing TSCO_REFERENCE_ASSETS.zip. Update the Build Command to this ZIP and SHA-256. Keep the existing Start Command; it already runs alembic upgrade head. Regress Quotation → Client Acceptance → PO after deployment.

Laboratory result entry, QC rules, six/five-run BDV protocols, DGA evidence, report approval, sampling identities and previously verified parser/Data Form behavior remain covered by the baseline checks. Only method resolution and frozen commercial scope projection changed in lab_operations.py; its locked-file digest was updated for this authorized delta.
