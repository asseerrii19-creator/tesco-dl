"""Server-owned quotations and immutable commercial evidence.

Revision ID: c6a2f9e81740
Revises: b3f1d8a6c920
"""
import json
from alembic import op
import sqlalchemy as sa

revision = 'c6a2f9e81740'
down_revision = 'b3f1d8a6c920'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('quotations', sa.Column('business_case_id', sa.Integer(), nullable=True))
    op.create_index('ix_quotations_business_case_id', 'quotations', ['business_case_id'])
    op.add_column('quotations', sa.Column('external_reference', sa.String(180), nullable=False, server_default=''))
    op.add_column('quotations', sa.Column('commercial_snapshot_json', sa.Text(), nullable=False, server_default='{}'))
    op.add_column('quotations', sa.Column('generated_pdf_blob', sa.LargeBinary(), nullable=True))
    op.add_column('quotations', sa.Column('generated_pdf_sha256', sa.String(64), nullable=False, server_default=''))
    # Populate only known UAT baseline choices, preserving explicit site configuration.
    mappings = {
        'dissolved gas analysis (dga)': {'ASTM': 'ASTM D3612', 'IEC': 'IEC 60567'},
        'water content kf @rt': {'ASTM': 'ASTM D1533', 'IEC': 'IEC 60814'},
    }
    bind = op.get_bind()
    for package_id, raw in list(bind.execute(sa.text('SELECT id, tests_json FROM test_package_configs'))):
        try:
            tests = json.loads(raw or '[]')
        except (TypeError, ValueError):
            continue
        changed = False
        for test in tests if isinstance(tests, list) else []:
            if not isinstance(test, dict) or 'method_mappings' in test:
                continue
            mapping = mappings.get(str(test.get('test', '')).lower())
            if mapping and str(test.get('method', '')) in mapping.values():
                test['method_mappings'] = mapping
                changed = True
        if changed:
            bind.execute(sa.text('UPDATE test_package_configs SET tests_json = :tests WHERE id = :id'), {'tests': json.dumps(tests, ensure_ascii=False), 'id': package_id})
    # Existing IDs, approvals and files are preserved; do not invent historic prices.
    op.execute(sa.text('UPDATE quotations SET business_case_id = (SELECT MIN(id) FROM commercial_cases WHERE quotation_id = quotations.id)'))
    if op.get_bind().dialect.name != 'sqlite':
        op.create_foreign_key('fk_quotation_business_case', 'quotations', 'commercial_cases', ['business_case_id'], ['id'])


def downgrade():
    if op.get_bind().dialect.name != 'sqlite':
        op.drop_constraint('fk_quotation_business_case', 'quotations', type_='foreignkey')
    op.drop_index('ix_quotations_business_case_id', table_name='quotations')
    for name in ('generated_pdf_sha256', 'generated_pdf_blob', 'commercial_snapshot_json', 'external_reference', 'business_case_id'):
        op.drop_column('quotations', name)
