# R14.8 Package parameters

The package information click handler referenced an undefined `esc()` function, so it raised ReferenceError before opening the dialog. The count's circled-i prompt was plain text; the actual button inherited an unsuitable foreground color.

- Build the Test / Method table with DOM nodes and textContent, removing the missing helper and safely displaying package strings.
- Both the visible i button and the View parameters count button open the dialog.
- Use accessible labels, visible focus, 44px touch targets, a fixed visible icon color, and a scrollable dialog.
- Preserve R14.7 upload fixes and all existing scope/quotation/sample logic.

Validation: dialog logic exercised with ten parameter/method rows and the Custom Tests state; both controls registered. 103 release tests and BUILD_RELEASE_CHECK passed. Mobile Safari live verification is pending deployment.

This package is prepared but has not been uploaded to GitHub or deployed. Keep the current Start Command and reference assets. Update the code ZIP filename/checksum in the Build Command when deploying.
