"""One controlled method resolver for commercial scope and laboratory intake.

Package tests may declare method_mappings={"ASTM": "...", "IEC": "..."}.
Baseline DGA/KF mappings are seeded into SQL package master data; runtime never overrides SQL from a source-file fallback.
Derived IEC water results do NOT acquire a fictitious ASTM equivalent.
"""
from copy import deepcopy

BASELINE_MAPPINGS = {
    'dissolved gas analysis (dga)': {'ASTM': 'ASTM D3612', 'IEC': 'IEC 60567'},
    'water content kf @rt': {'ASTM': 'ASTM D1533', 'IEC': 'IEC 60814'},
}


def family_of(method):
    value = str(method or '').strip().upper()
    return 'ASTM' if value.startswith('ASTM') else 'IEC' if value.startswith('IEC') else ''


def resolve_methods(tests, catalog, family):
    requested = str(family or 'DEFAULT').upper()
    rows = deepcopy(tests)
    if requested not in {'ASTM', 'IEC'}:
        return rows
    # BDV gap and its RSD companion are resolved together; keep the commercial pair.
    positions = [i for i, r in enumerate(rows) if 'breakdown voltage' in str(r.get('test', '')).lower() or 'rsd% of bdv' in str(r.get('test', '')).lower()]
    if positions:
        candidates = [r for r in catalog if family_of(r.get('method')) == requested]
        preferred = 'ASTM D1816' if requested == 'ASTM' else 'IEC 60156'
        candidates = [r for r in candidates if str(r.get('method', '')).upper().startswith(preferred)]
        chosen = []
        for term in ('breakdown voltage', 'rsd% of bdv'):
            item = next((r for r in candidates if term in str(r.get('test', '')).lower()), None)
            if item:
                chosen.append(deepcopy(item))
        if len(chosen) == 2:
            first = min(positions)
            rows = [r for i, r in enumerate(rows) if i not in positions]
            rows[first:first] = chosen
    for row in rows:
        name = str(row.get('test', '')).strip().lower()
        mapping = row.get('method_mappings', {})
        method = mapping.get(requested) if isinstance(mapping, dict) else None
        if method and family_of(method) == requested:
            row['method'] = method
        elif family_of(row.get('method')) != requested:
            alt = next((r for r in catalog if str(r.get('test', '')).strip().lower() == name and family_of(r.get('method')) == requested), None)
            if alt:
                for key in ('method', 'station', 'unit'):
                    row[key] = alt.get(key, row.get(key, ''))
        method = str(row.get('method', '')).strip()
        if method.upper() not in {'', '-', 'CALCULATION'} and family_of(method) != requested:
            row['method_conflict'] = f'No configured {requested} equivalent; fixed method {method} requires explicit review'
        else:
            row.pop('method_conflict', None)
    return rows
