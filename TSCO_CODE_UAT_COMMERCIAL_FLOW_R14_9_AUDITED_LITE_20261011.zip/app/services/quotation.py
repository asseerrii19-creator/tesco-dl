from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from io import BytesIO
from pathlib import Path
import reportlab
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import CommercialCase, Quotation, Site
from .identifiers import _next_sequence
from .method_family import resolve_methods

# UAT/demo-only commercial rates. They intentionally do not represent TSCO's controlled production price list.
DEMO_PRICE_MASTER = [
    {"test":"Appearance","method":"ASTM D1524","rate":30.00},
    {"test":"Color ASTM","method":"ASTM D1500","rate":40.00},
    {"test":"Density of Oil @RT","method":"ASTM D4052","rate":55.00},
    {"test":"Viscosity @ 40 °C","method":"ASTM D445","rate":80.00},
    {"test":"Flash Point (Open Cup)","method":"ASTM D92","rate":120.00},
    {"test":"Flash Point (Closed Cup)","method":"ASTM D93","rate":120.00},
    {"test":"Water Content KF @RT","method":"IEC 60814 / ASTM D1533","rate":320.00},
    {"test":"Breakdown Voltage @2.5mm- AVG","method":"IEC 60156","rate":320.00},
    {"test":"Breakdown Voltage @1mm- AVG","method":"ASTM D1816","rate":320.00},
    {"test":"Power Factor @25°C/60Hz","method":"ASTM D924","rate":350.00},
    {"test":"Power Factor @100°C/60Hz","method":"ASTM D924","rate":350.00},
    {"test":"Total Acid Number","method":"ASTM D664","rate":170.00},
    {"test":"Interfacial Tension (IFT)","method":"ASTM D971","rate":170.00},
    {"test":"Resistivity @       °C/60Hz","method":"ASTM D1169","rate":200.00},
    {"test":"Dissolved Gas Analysis (DGA)","method":"IEC 60567 / ASTM D3612","rate":650.00},
    {"test":"Total Furanic Compounds","method":"IEC 61198","rate":240.00},
    {"test":"Corrosive Sulfur","method":"ASTM D1275B","rate":280.00},
    {"test":"Dibenzyl Disulfide (DBDS)","method":"IEC 62697-1","rate":300.00},
    {"test":"Antioxidant (BHT)","method":"IEC 60666","rate":250.00},
    {"test":"Polychlorinated Biphenyls (PCBs)","method":"IEC 61619","rate":450.00},
]


def _norm_price_name(value: str) -> str:
    return "".join(ch for ch in str(value or "").lower() if ch.isalnum())


def _demo_rate_for(test_name: str) -> dict:
    key = _norm_price_name(test_name)
    aliases = {
        "dissolvedgasanalysis":"Dissolved Gas Analysis (DGA)",
        "dga":"Dissolved Gas Analysis (DGA)",
        "watercontent":"Water Content KF @RT",
        "breakdownvoltage":"Breakdown Voltage @2.5mm- AVG",
        "powerfactor":"Power Factor @25°C/60Hz",
        "tanacidity":"Total Acid Number",
        "acidity":"Total Acid Number",
        "ift":"Interfacial Tension (IFT)",
        "furan":"Total Furanic Compounds",
        "dbds":"Dibenzyl Disulfide (DBDS)",
    }
    target = aliases.get(key, test_name)
    tkey = _norm_price_name(target)
    for row in DEMO_PRICE_MASTER:
        if _norm_price_name(row["test"]) == tkey:
            return row
    return {"test":test_name, "method":"Controlled method", "rate":120.00}



def _money(value):
    return float(Decimal(str(value)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP))


def quotation_snapshot(quote):
    if not quote:
        return {}
    try:
        data = json.loads(quote.commercial_snapshot_json or '{}')
        return data if isinstance(data, dict) and data.get('rows') and data.get('scope') else {}
    except (TypeError, ValueError):
        return {}


def quote_preview(db, case, lines, packages=None):
    from .lab_operations import package_catalog, _normalize_package_test, _ensure_corrosion_result_pair
    packages = packages if packages is not None else package_catalog(db, case.site_id)
    package_map = {str(p.get('name', '')).lower(): p for p in packages}
    catalog = [_normalize_package_test(t) for p in packages for t in p.get('tests', []) if isinstance(t, dict)]
    rows, scope, conflicts = [], [], []
    for line in lines:
        if line.requested_package.upper() == 'CUSTOM':
            names = json.loads(line.requested_tests_json or '[]')
            tests = []
            for name in names:
                item = next((r for r in catalog if str(r.get('test', '')).lower() == str(name).lower()), None)
                if not item:
                    raise ValueError(f'Requested test {name} is not active in controlled master data')
                tests.append(deepcopy(item))
        else:
            package = package_map.get(str(line.requested_package).lower())
            if not package:
                raise ValueError(f'Package {line.requested_package} is not active in controlled master data')
            tests = deepcopy(package.get('tests', []))
        tests = resolve_methods(_ensure_corrosion_result_pair(tests), catalog, line.method_family)
        if not tests:
            raise ValueError('Quotation scope has no configured tests')
        multiplier = 2.0 if str(line.required_tat).upper() == '12H' else 1.5 if str(line.required_tat).upper() == '24H' else 1.0
        for test in tests:
            key = f"{line.id}:{test['test']}:{test.get('method', '')}"
            if test.get('method_conflict'):
                conflicts.append({'key': key, 'test': test['test'], 'method': test.get('method', ''), 'family': line.method_family, 'message': test['method_conflict']})
            rate = _demo_rate_for(test['test'])
            unit = _money(rate['rate'])
            rows.append({'test': test['test'], 'method': test.get('method', ''), 'method_family': line.method_family, 'unit_rate': unit, 'qty': int(line.quantity), 'tat_multiplier': multiplier, 'total': _money(Decimal(str(unit)) * int(line.quantity) * Decimal(str(multiplier))), 'conflict_key': key if test.get('method_conflict') else '', 'method_conflict': test.get('method_conflict', '')})
        scope.append({'line_id': line.id, 'package': line.requested_package, 'quantity': int(line.quantity), 'method_family': str(line.method_family or 'DEFAULT').upper(), 'priority': line.priority, 'tat': line.required_tat or 'Standard', 'tests': tests})
    net = _money(sum(Decimal(str(r['total'])) for r in rows))
    vat = _money(Decimal(str(net)) * Decimal('0.15'))
    return {'rows': rows, 'scope': scope, 'conflicts': conflicts, 'net': net, 'vat': vat, 'grand': _money(Decimal(str(net)) + Decimal(str(vat))), 'currency': 'SAR', 'vat_rate': 15, 'rate_source': 'UAT DEMO ONLY - NOT TSCO CONTROLLED RATES'}


def _approved_snapshot(db, case, actor, approved_methods, reason):
    from .commercial import request_scope_lines
    snapshot = quote_preview(db, case, request_scope_lines(db, case))
    if not snapshot['rows']:
        raise ValueError('Client Request Scope must be recorded before creating the quotation')
    keys = {c['key'] for c in snapshot['conflicts']}
    approved = set(approved_methods or [])
    if approved - keys:
        raise ValueError('Method exception selection does not match the current request scope')
    if keys - approved or (keys and not str(reason or '').strip()):
        raise ValueError('Method Family conflicts require explicit fixed-method review and a recorded reason before quotation confirmation')
    snapshot['business_case_id'] = case.id
    snapshot['business_case_code'] = case.case_code
    snapshot['issued_by_id'] = actor.id
    snapshot['issued_at'] = datetime.utcnow().isoformat()
    snapshot['fixed_method_approval'] = {'keys': sorted(approved), 'reason': str(reason or '').strip()[:4000], 'approved_by_id': actor.id}
    for scope in snapshot['scope']:
        for test in scope['tests']:
            if test.pop('method_conflict', None):
                test['method_exception_reason'] = snapshot['fixed_method_approval']['reason']
                test['method_exception_approved_by_id'] = actor.id
    for row in snapshot['rows']:
        if row.get('method_conflict'):
            row['method_exception_reason'] = snapshot['fixed_method_approval']['reason']
            row['method_conflict'] = ''
    snapshot['conflicts'] = []
    return snapshot


def quotation_pdf(quote, case, snapshot):
    out = BytesIO()
    styles = getSampleStyleSheet()
    font_path = Path(reportlab.__file__).parent / 'fonts' / 'Vera.ttf'
    if font_path.is_file():
        if 'TSCOQuotation' not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(TTFont('TSCOQuotation', str(font_path)))
        for style in styles.byName.values():
            style.fontName = 'TSCOQuotation'
    doc = SimpleDocTemplate(out, title=f'Quotation {quote.number}', topMargin=30, bottomMargin=30)
    def p(text):
        return Paragraph(escape(str(text)), styles['BodyText'])
    story = [Paragraph('TSCO Commercial Quotation', styles['Title']), p(snapshot['rate_source']), Spacer(1, 12), p(f'Quotation Number: {quote.number}'), p(f"Business Case: {snapshot['business_case_code']}"), p(f'Client: {case.client.name}'), p(f"Issued: {snapshot['issued_at']}"), Spacer(1, 10)]
    if quote.external_reference:
        story.append(p('External / ERP Reference: ' + quote.external_reference))
    for line in snapshot['scope']:
        story.append(p(f"Scope: {line['quantity']} x {line['package']} / {line['method_family']} / {line['priority']} / {line['tat']}"))
    story.append(Spacer(1, 10))
    data = [[p(x) for x in ('Test / commercial item', 'Method', 'Rate SAR', 'Qty / TAT', 'Total SAR')]]
    for row in snapshot['rows']:
        method = row['method'] + (' (approved fixed method)' if row.get('method_exception_reason') else '')
        data.append([p(row['test']), p(method), p(f"{row['unit_rate']:.2f}"), p(f"{row['qty']} x {row['tat_multiplier']:.2f}"), p(f"{row['total']:.2f}")])
    table = Table(data, colWidths=[185, 110, 65, 65, 65], repeatRows=1)
    table.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#dbeef0')), ('GRID', (0, 0), (-1, -1), .5, colors.grey), ('VALIGN', (0, 0), (-1, -1), 'TOP'), ('TOPPADDING', (0, 0), (-1, -1), 6), ('BOTTOMPADDING', (0, 0), (-1, -1), 6)]))
    story.extend([table, Spacer(1, 12)])
    for name, key in [('Net Amount', 'net'), ('VAT 15%', 'vat'), ('Grand Total', 'grand')]:
        story.append(p(f"{name}: SAR {snapshot[key]:.2f}"))
    approval = snapshot.get('fixed_method_approval', {})
    if approval.get('keys'):
        story.extend([Spacer(1, 10), p('Explicit fixed-method review: ' + approval['reason'])])
    doc.build(story)
    return out.getvalue()


def publish_quotation_evidence(db, case, actor, approved_methods=(), reason=''):
    quote = case.quotation
    if not quote or quote.status not in {'ACTIVE', 'CLIENT_REJECTED'} or quotation_snapshot(quote):
        raise ValueError('Only an unpublished, unaccepted quotation can have its commercial evidence published')
    if quote.business_case_id and quote.business_case_id != case.id:
        raise ValueError('Quotation is permanently linked to another Business Case')
    snapshot = _approved_snapshot(db, case, actor, approved_methods, reason)
    quote.business_case_id = case.id
    quote.commercial_snapshot_json = json.dumps(snapshot, ensure_ascii=False)
    quote.generated_pdf_blob = quotation_pdf(quote, case, snapshot)
    quote.generated_pdf_sha256 = hashlib.sha256(quote.generated_pdf_blob).hexdigest()
    return quote


def issue_quotation(db, case, actor, approved_methods=(), reason='', external_reference=''):
    # The sequence allocator is atomic on PostgreSQL and SQLite, in this transaction.
    site = db.get(Site, case.site_id)
    year = datetime.utcnow().strftime('%Y')
    while True:
        sequence = _next_sequence(db, namespace='quotation', site=site, year=year)
        number = f'QT-{site.code}-{year}-{sequence:06d}'
        if db.scalar(select(Quotation.id).where(Quotation.number == number)) is None:
            break
    from .commercial import request_scope_lines
    summary = '; '.join(f"{s['quantity']} x {s['package']} / {s['method_family']} / {s['priority']} / {s['tat']}" for s in quote_preview(db, case, request_scope_lines(db, case))['scope'])[:240]
    quote = Quotation(client_id=case.client_id, number=number, status='ACTIVE', description=summary, external_reference=str(external_reference or '').strip()[:180], business_case_id=case.id)
    db.add(quote)
    db.flush()
    case.quotation = quote
    publish_quotation_evidence(db, case, actor, approved_methods, reason)
    return quote
