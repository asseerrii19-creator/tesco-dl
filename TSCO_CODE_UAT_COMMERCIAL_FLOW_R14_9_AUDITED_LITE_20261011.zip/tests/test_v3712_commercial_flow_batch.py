import hashlib
import json
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient
from pypdf import PdfReader
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import (Asset, AuditLog, Client, ClientSamplingDataForm, CommercialAttachment, CommercialCase,
                        CommercialEvent, CommercialRequestLine, Quotation, SampleRequest, Site, TestPackageConfig as PackageConfig, User)
from app.services.quotation import quote_preview, quotation_snapshot
from app.services.lab_operations import resolved_sample_package
from app.routes.admin import _tests_from_lines


def login(browser, email='client.coordinator@tsco.local'):
    assert browser.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False).status_code == 303


def make_case(family='ASTM', legacy=False):
    with SessionLocal() as db:
        site = db.scalar(select(Site).where(Site.code == 'DMM'))
        client = db.scalar(select(Client).where(Client.code == 'SEC'))
        actor = db.scalar(select(User).where(User.email == 'client.coordinator@tsco.local'))
        case = CommercialCase(case_code=f'BC-DMM-2026-{uuid4().hex[:10]}', site_id=site.id, client_id=client.id,
                              owner_id=actor.id, assigned_coordinator_id=actor.id, request_source='CLIENT_PORTAL',
                              request_status='UNDER_REVIEW', current_stage='LEAD_GENERATION', status='ACTIVE', lead_title='Commercial Batch UAT')
        db.add(case); db.flush()
        line = CommercialRequestLine(commercial_case_id=case.id, quantity=4, line_number=1, requested_package='Routine Test',
                                     method_family=family, priority='NORMAL', required_tat='', sample_indices_json='[1,2,3,4]', status='ACTIVE')
        db.add(line); db.flush()
        if legacy:
            quote = Quotation(client_id=client.id, number=f'QT-UAT-{uuid4().hex[:8]}', status='ACTIVE')
            db.add(quote); db.flush(); case.quotation = quote
            case.current_stage = 'QUOTATION'; case.request_status = 'QUOTATION_CREATED'
        db.commit()
        return case.id, line.id, case.case_code


def review(case_id):
    with SessionLocal() as db:
        case = db.get(CommercialCase, case_id)
        lines = list(db.scalars(select(CommercialRequestLine).where(CommercialRequestLine.commercial_case_id == case_id)))
        preview = quote_preview(db, case, lines)
        return {'approved_fixed_methods': [c['key'] for c in preview['conflicts']], 'method_review_reason': 'UAT explicit review of derived/fixed methods; preserve defined calculation protocol'}


def confirm(browser, case_id, **extra):
    return browser.post(f'/commercial/cases/{case_id}/advance', data={'target_stage': 'QUOTATION', **review(case_id), **extra}, follow_redirects=False)


def test_server_number_audit_link_and_readonly_identity():
    with TestClient(app) as browser:
        case_id, _, code = make_case()
        login(browser)
        assert confirm(browser, case_id, quotation_number='UNTRUSTED-ID', external_reference='SAP-9001').status_code == 303
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); quote = case.quotation
            assert quote.number.startswith('QT-DMM-2026-') and quote.number != 'UNTRUSTED-ID'
            assert quote.business_case_id == case.id and quote.external_reference == 'SAP-9001'
            assert quotation_snapshot(quote)['business_case_code'] == code
            event = db.scalar(select(CommercialEvent).where(CommercialEvent.commercial_case_id == case_id))
            assert event.reference == quote.number
            audit = db.scalar(select(AuditLog).where(AuditLog.action == 'COMMERCIAL_STAGE_ADVANCED', AuditLog.entity_id == str(case_id)))
            assert audit
            quote.number = 'MANUAL-CHANGE'
            with pytest.raises(ValueError, match='read-only'):
                db.flush()
            db.rollback()
        # Repeated confirmation must not replace the issued quote.
        assert confirm(browser, case_id).status_code == 400


def test_astm_mapping_preserves_14_lines_and_requires_explicit_conflict_review():
    with TestClient(app) as browser:
        case_id, line_id, _ = make_case()
        login(browser)
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id)
            preview = quote_preview(db, case, [db.get(CommercialRequestLine, line_id)])
            assert len(preview['rows']) == 14
            methods = {row['test']: row['method'] for row in preview['rows']}
            assert methods['Dissolved Gas Analysis (DGA)'] == 'ASTM D3612'
            assert methods['Water Content KF @RT'] == 'ASTM D1533'
            assert methods['Breakdown Voltage @1mm- AVG'] == methods['RSD% of BDV @1mm'] == 'ASTM D1816'
            assert {c['test'] for c in preview['conflicts']} == {'Water Content @20 °C', 'Humidity in Cellulose'}
        assert browser.post(f'/commercial/cases/{case_id}/advance', data={'target_stage': 'QUOTATION'}, follow_redirects=False).status_code == 400
        with SessionLocal() as db:
            assert not db.get(CommercialCase, case_id).quotation_id
        assert confirm(browser, case_id).status_code == 303
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); snapshot = quotation_snapshot(case.quotation)
            assert len(snapshot['rows']) == 14 and not snapshot['conflicts']
            assert snapshot['fixed_method_approval']['approved_by_id'] == case.assigned_coordinator_id


def test_client_commercial_document_acceptance_po_and_frozen_lab_scope():
    with TestClient(app) as browser:
        case_id, line_id, code = make_case()
        login(browser); assert confirm(browser, case_id).status_code == 303
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); quote_id = case.quotation_id
            snapshot = quotation_snapshot(case.quotation); pdf_bytes = bytes(case.quotation.generated_pdf_blob)
            number = case.quotation.number
            assert hashlib.sha256(pdf_bytes).hexdigest() == case.quotation.generated_pdf_sha256
        login(browser, 'client@sec.local')
        page = browser.get(f'/client/requests/{case_id}')
        assert page.status_code == 200
        for text in (number, 'Net Amount', 'VAT 15%', 'Grand Total', 'View Quotation PDF', 'Download Quotation PDF', 'ASTM D1533', f"{snapshot['grand']:.2f}"):
            assert text in page.text
        pdf = browser.get(f'/client/requests/{case_id}/quotation.pdf')
        assert pdf.content == pdf_bytes
        extracted = '\n'.join(p.extract_text() for p in PdfReader(BytesIO(pdf.content)).pages)
        for text in (number, code, 'Grand Total', 'ASTM D1533', 'RSD% of BDV @1mm'):
            assert text in extracted
        assert 'attachment;' in browser.get(f'/client/requests/{case_id}/quotation.pdf?download=1').headers['content-disposition']
        for fields in ({}, {'reviewed_quote_id': quote_id + 1, 'quotation_reviewed': 'yes'}):
            assert browser.post(f'/client/requests/{case_id}/quotation-decision', data={'decision': 'ACCEPT', **fields}, follow_redirects=False).status_code == 400
        assert browser.post(f'/client/requests/{case_id}/quotation-decision', data={'decision': 'ACCEPT', 'reviewed_quote_id': quote_id, 'quotation_reviewed': 'yes'}, follow_redirects=False).status_code == 303
        assert browser.post(f'/client/requests/{case_id}/purchase-order', data={'purchase_order_number': 'PO-' + uuid4().hex[:8]}, files={'upload': ('po.pdf', b'%PDF-1.4\n% UAT PO\n', 'application/pdf')}, follow_redirects=False).status_code == 303
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id)
            assert case.case_code == code and case.purchase_order.quotation_id == quote_id
            asset = db.scalar(select(Asset).where(Asset.client_id == case.client_id))
            sample = SampleRequest(site_id=case.site_id, client_id=case.client_id, asset_id=asset.id, quotation_id=quote_id, commercial_case_id=case_id,
                                   commercial_request_line_id=line_id, requested_package='Routine Test', requested_method_family='ASTM')
            db.add(sample)
            # No flush is necessary to prove immutable laboratory resolution.
            sample.quotation = case.quotation
            # A later master-data revision must not change this accepted scope/pricing.
            package = db.scalar(select(PackageConfig).where(PackageConfig.name == 'Routine Test'))
            original = package.tests_json
            package.tests_json = '[{"test":"Changed Master","method":"IEC 99999"}]'
            with db.no_autoflush:
                resolved = resolved_sample_package(db, sample)
            assert resolved['tests'] == snapshot['scope'][0]['tests']
            package.tests_json = original
            db.rollback()
        login(browser, 'client@aramco.local')
        assert browser.get(f'/client/requests/{case_id}/quotation.pdf').status_code == 400


def test_legacy_quote_requires_published_amounts_without_renumbering():
    with TestClient(app) as browser:
        case_id, _, _ = make_case(legacy=True)
        with SessionLocal() as db:
            quote = db.get(CommercialCase, case_id).quotation
            number, quote_id = quote.number, quote.id
        login(browser, 'client@sec.local')
        assert 'awaiting publication' in browser.get(f'/client/requests/{case_id}').text
        assert browser.post(f'/client/requests/{case_id}/quotation-decision', data={'decision': 'ACCEPT', 'reviewed_quote_id': quote_id, 'quotation_reviewed': 'yes'}, follow_redirects=False).status_code == 400
        login(browser)
        assert browser.post(f'/commercial/cases/{case_id}/quotation-publish', data=review(case_id), follow_redirects=False).status_code == 303
        with SessionLocal() as db:
            quote = db.get(CommercialCase, case_id).quotation
            assert quote.number == number and quote.id == quote_id and quote.generated_pdf_blob
        assert browser.post(f'/commercial/cases/{case_id}/quotation-publish', data=review(case_id), follow_redirects=False).status_code == 400


def test_revision_keeps_old_evidence_and_rejects_stale_acceptance():
    with TestClient(app) as browser:
        case_id, _, _ = make_case()
        login(browser); assert confirm(browser, case_id).status_code == 303
        with SessionLocal() as db:
            old = db.get(CommercialCase, case_id).quotation
            old_id, old_number, old_pdf = old.id, old.number, bytes(old.generated_pdf_blob)
        login(browser, 'client@sec.local')
        assert browser.post(f'/client/requests/{case_id}/quotation-decision', data={'decision': 'REJECT', 'note': 'Please revise'}, follow_redirects=False).status_code == 303
        login(browser)
        assert browser.post(f'/commercial/cases/{case_id}/quotation-revise', data=review(case_id), follow_redirects=False).status_code == 303
        with SessionLocal() as db:
            new = db.get(CommercialCase, case_id).quotation
            assert new.number != old_number and new.business_case_id == case_id
            old = db.get(Quotation, old_id)
            assert old.status == 'CLIENT_REJECTED' and bytes(old.generated_pdf_blob) == old_pdf
        login(browser, 'client@sec.local')
        assert browser.post(f'/client/requests/{case_id}/quotation-decision', data={'decision': 'ACCEPT', 'reviewed_quote_id': old_id, 'quotation_reviewed': 'yes'}, follow_redirects=False).status_code == 400


def test_supporting_documents_separate_current_multi_form_sources_and_history():
    with TestClient(app) as browser:
        case_id, _, _ = make_case(family='DEFAULT')
        with SessionLocal() as db:
            docs = [CommercialAttachment(commercial_case_id=case_id, document_type='CLIENT_DATA_FORM', original_name=f'upload-{i}.pdf', stored_path='', content_type='application/pdf', sha256=str(i)) for i in range(3)]
            db.add_all(docs); db.flush()
            form = ClientSamplingDataForm(commercial_case_id=case_id, status='LOCKED', revision=1, forms_json=json.dumps([
                {'form_number': 1, 'status': 'CONFIRMED', 'source_attachment_id': docs[1].id, 'asset': {'serial_number': 'SN1'}, 'samples': []},
                {'form_number': 2, 'status': 'CONFIRMED', 'source_attachment_id': docs[2].id, 'asset': {'serial_number': 'SN2'}, 'samples': []}]))
            db.add(form); db.commit()
        login(browser)
        page = browser.get(f'/commercial?case_id={case_id}')
        assert page.status_code == 200
        assert 'Current / Confirmed Data Form' in page.text
        assert 'Previous Data Form Uploads (1)' in page.text
        for i in range(3):
            assert f'upload-{i}.pdf' in page.text
        assert page.text.index('upload-1.pdf') < page.text.index('Version History') < page.text.index('upload-0.pdf')
        with SessionLocal() as db:
            assert len(list(db.scalars(select(CommercialAttachment).where(CommercialAttachment.commercial_case_id == case_id)))) == 3


def test_package_family_mappings_are_configurable_and_retained():
    from app.services.method_family import resolve_methods
    tests = _tests_from_lines('Example Test | IEC 12345 | Water | mg/kg | ASTM D9999 | IEC 12345')
    assert tests[0]['method_mappings'] == {'ASTM': 'ASTM D9999', 'IEC': 'IEC 12345'}
    assert resolve_methods(tests, tests, 'ASTM')[0]['method'] == 'ASTM D9999'
    assert not resolve_methods(tests, tests, 'ASTM')[0].get('method_conflict')


def test_concurrent_server_generation_uses_unique_atomic_sequence():
    from app.services.quotation import issue_quotation
    with TestClient(app):
        case_ids = [make_case(family='DEFAULT')[0] for _ in range(6)]
        def issue(case_id):
            with SessionLocal() as db:
                case = db.get(CommercialCase, case_id)
                actor = db.get(User, case.assigned_coordinator_id)
                quote = issue_quotation(db, case, actor)
                number = quote.number
                db.commit()
                return number
        with ThreadPoolExecutor(max_workers=6) as pool:
            numbers = list(pool.map(issue, case_ids))
        assert len(set(numbers)) == 6
        assert all(number.startswith('QT-DMM-2026-') for number in numbers)


def test_post_quotation_intake_inherits_astm_and_resolves_identical_lab_scope():
    with TestClient(app) as browser:
        case_id, line_id, _ = make_case()
        login(browser); assert confirm(browser, case_id).status_code == 303
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id)
            quote_id = case.quotation_id
            expected = quotation_snapshot(case.quotation)['scope'][0]['tests']
        login(browser, 'client@sec.local')
        assert browser.post(f'/client/requests/{case_id}/quotation-decision', data={'decision':'ACCEPT', 'reviewed_quote_id':quote_id, 'quotation_reviewed':'yes'}, follow_redirects=False).status_code == 303
        assert browser.post(f'/client/requests/{case_id}/purchase-order', data={'purchase_order_number':'PO-INTAKE-'+uuid4().hex[:8]}, files={'upload':('po.pdf', b'%PDF-1.4\n% UAT\n', 'application/pdf')}, follow_redirects=False).status_code == 303
        login(browser)
        assert browser.post(f'/commercial/cases/{case_id}/advance', data={'target_stage':'COMPLETE_HANDOVER', 'handover_commercial':'Accepted quotation + PO', 'handover_technical':'Four Routine ASTM samples', 'handover_client_info':'SEC UAT'}, follow_redirects=False).status_code == 303
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id)
            client_id, po_id = case.client_id, case.purchase_order_id
            asset_id = db.scalar(select(Asset.id).where(Asset.client_id==client_id))
        login(browser, 'data.entry@tsco.local')
        intake = browser.post('/intake/direct', data={'client_id':client_id, 'asset_id':asset_id, 'quotation_id':quote_id, 'purchase_order_id':po_id, 'commercial_request_line_id':line_id, 'requested_package':'Full Test', 'requested_method_family':'IEC', 'sampling_point':'Bottom Tank', 'sample_count':4, 'container_count':1, 'client_sample_reference':'Commercial Batch'}, follow_redirects=False)
        assert intake.status_code == 303, intake.text[:500]
        with SessionLocal() as db:
            samples = list(db.scalars(select(SampleRequest).where(SampleRequest.commercial_case_id==case_id)))
            assert len(samples) == 4
            assert all(s.requested_method_family=='ASTM' and s.requested_package=='Routine Test' and s.quotation_id==quote_id and s.purchase_order_id==po_id for s in samples)
            assert all(resolved_sample_package(db,s)['tests']==expected for s in samples)
