# R14.7 Sampling source import

Fixes the real uploaded QDF that imported scalar values while leaving Sampling From at 0/4.

- Supports explicit labels on separate lines and Manufacturer / Manufacture Name aliases.
- Imports marked sealing, cooling, tap changer type/chamber, unit-in-service and priority choices.
- Imports each checked sampling identity as one physical sample. Bottom Tank plus Tap Changer 1/2/3 remains four samples sharing one transformer serial.
- Imports delivered/received names, dates and contact number.
- Reads interactive PDF field values without requiring flattening, including the editable site-print copy.
- Preserves conflicting marked selections in extraction metadata and a visible review warning. The supplied ONAN + ONAF pair is retained as Other detail `ONAN / ONAF` because the current site accepts a single cooling choice.
- Does not claim OCR for scans/handwriting or invent unchecked options. Original uploaded evidence remains retained; client review/confirmation still applies.

Validation: 103 tests passed, including parser, real upload-route persistence, AcroForm and missing-selection regressions. BUILD_RELEASE_CHECK.sh passed.

Deployment: use this code ZIP with the existing TSCO_REFERENCE_ASSETS.zip. Change only the Build Command to reference the new ZIP and checksum. Keep the current Start Command. Existing uploaded forms are not silently rewritten; re-upload the source into the intended editable Data Form after deployment and review before confirming.
