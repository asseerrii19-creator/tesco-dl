from pathlib import Path
import io
from fastapi.testclient import TestClient
from sqlalchemy import select
from reportlab.pdfgen.canvas import Canvas
from app.database import SessionLocal
from app.main import app
from app.models import ClientSamplingDataForm
from app.services.sampling_data_form import prefill_from_uploaded_source, data_form_forms
from tests.test_v379_sampling_selection_identity import _login_client, _new_request, _new_form

SOURCE=Path(__file__).parent/'fixtures/sampling_import/r14_6_four_samples.pdf'

def test_real_uploaded_qdf_preserves_four_same_transformer_samples_and_fields():
    p=prefill_from_uploaded_source(SOURCE.read_bytes(),'application/pdf')
    assert p['asset']['serial_number']=='UAT-SEC-TR-004'
    assert p['asset']['manufacturer_name']=='WESCOSA'
    assert p['client']['email']=='uat.client@sec.example'
    assert p['client']['contact_person']=='SEC UAT Contact'
    assert [(s['sampling_from'],s['sampling_detail']) for s in p['samples']]==[
        ('Bottom Tank',''),('Tap Changer','1'),('Tap Changer','2'),('Tap Changer','3')]
    assert p['asset']['sealing_system']=='Conservator with Bladder'
    assert p['asset']['tap_changer_type']=='On-load'
    assert p['asset']['tap_changer_chamber']=='Not Connected'
    assert p['sampling']['unit_in_service']=='Yes'
    assert p['sampling']['unit_oil_temperature_c']=='48'
    assert p['sampling']['delivered_by']=='SEC UAT Sampler'
    assert p['sampling']['received_by']=='TSCO Receiving - UAT'
    assert p['sampling']['delivered_date']==p['sampling']['received_date']=='11-Oct-2026'
    assert p['extraction']['review_required']
    assert p['asset']['cooling_type_other']=='ONAN / ONAF'
    assert p['extraction']['source_selections']['cooling_type']==['ONAN','ONAF']
    assert 'multiple marked choices' in p['extraction']['message']

def test_upload_route_stores_four_samples_and_review_warning():
    with TestClient(app) as browser:
        _login_client(browser)
        case_id=_new_request(browser,4,'R14.7 imported QDF regression')
        number=_new_form(browser,case_id)
        r=browser.post(f'/client/requests/{case_id}/attachments',data={'form_number':number},files={'upload':('four.pdf',SOURCE.read_bytes(),'application/pdf')},follow_redirects=False)
        assert r.status_code==303
        with SessionLocal() as db:
            row=db.scalar(select(ClientSamplingDataForm).where(ClientSamplingDataForm.commercial_case_id==case_id))
            f=data_form_forms(row)[0]
            assert len(f['samples'])==4
            assert f['status']=='DRAFT'
            assert f['sampling']['unit_in_service']=='Yes'
        page=browser.get(r.headers['location'])
        assert 'multiple marked choices' in page.text
        assert 'checked' in page.text

def test_interactive_pdf_fields_are_read_without_flattening():
    b=io.BytesIO();c=Canvas(b)
    c.acroForm.textfield(name='row8_1_Serial Number',value='UAT-WIDGET-001',x=50,y=700,width=180,height=20)
    c.acroForm.choice(name='row19_1_Sample 1',value='Tap Changer - 3',options=['Select...','Tap Changer - 3'],fieldFlags='combo',x=50,y=660,width=180,height=20)
    c.showPage();c.save()
    p=prefill_from_uploaded_source(b.getvalue(),'application/pdf')
    assert p['asset']['serial_number']=='UAT-WIDGET-001'
    assert p['samples'][0]['sampling_detail']=='3'

def test_unchecked_and_missing_choices_are_never_invented():
    b=io.BytesIO();c=Canvas(b)
    t=c.beginText(30,750)
    for line in ['Number of Samples: 4','Sampling From','[ ] Bottom Tank','Tap Changer: [ ] 1 [ ] 2 [ ] 3','Unit In Service','[ ] Yes [ ] No (New)']:
        t.textLine(line)
    c.drawText(t);c.showPage();c.save()
    p=prefill_from_uploaded_source(b.getvalue(),'application/pdf')
    assert p['samples']==[]
    assert not p['sampling'].get('unit_in_service')
    assert 'extracted 0' in p['extraction']['message']
