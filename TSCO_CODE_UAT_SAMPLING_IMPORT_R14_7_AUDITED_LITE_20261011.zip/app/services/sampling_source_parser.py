"""Read explicit QDF labels and marked selections without guessing OCR results."""
from __future__ import annotations

import io
import re
from typing import Any
from pypdf import PdfReader

FIELDS = {
    'client': {
        'company_name': ['Company Name'], 'email': ['E-mail', 'Email'],
        'contact_person': ['Contact Person', 'Requester / Project Manager'],
        'address': ['Address'], 'mobile_number': ['Mobile Number', 'Mobile'],
        'telephone_number': ['Telephone Number', 'Telephone'],
    },
    'asset': {
        'serial_number': ['Serial Number', 'Transformer Serial Number'],
        'tag_number': ['ID / Tag Number', 'ID/Tag Number'],
        'voltage_rating_hv_lv': ['Voltage Rating HV/LV (kV)', 'HV/LV voltage'],
        'rated_power_mva': ['Rated Power (MVA)'], 'sap_number': ['SAP number'],
        'manufacturer_name': ['Manufacturer Name', 'Manufacture Name'],
        'manufacture_year': ['Manufacture Year'], 'country_of_manufacture': ['Country of Manufacture'],
        'substation': ['Substation'], 'location': ['Location'], 'load_pct': ['Load%'],
        'oil_type': ['Oil Type'], 'oil_weight': ['Oil Weight (Ton / Kg)'],
    },
    'sampling': {
        'unit_oil_temperature_c': ['Unit Oil Temperature, °C', 'Unit Oil Temperature, C'],
        'reason_of_sampling': ['Reason of Sampling'],
        'ambient_temperature_c': ['Ambient Temperature, °C', 'Ambient Temperature, C'],
        'ambient_humidity_pct': ['Ambient Humidity, %'],
        'winding_temperature_c': ['Winding Temperature, °C', 'Winding Temperature, C'],
        'sample_man_name': ['Sample Man Name'], 'sampling_date_time': ['Sampling Date & Time'],
        'delivered_by': ['Delivered By'], 'received_by': ['Received By'],
        'delivered_contact_no': ['Contact No.'],
    },
}
CHOICES = {
    'Sealing System': ('asset', 'sealing_system', ['Conservator with Bladder','Hermetical','Free Breathing (No Bladder in Conservator)','Conservator with Diaphragm','Pressurized N2','Other']),
    'Cooling Type': ('asset', 'cooling_type', ['ONAN','ONAF','OFAF','Other']),
    'Tap Changer Type': ('asset', 'tap_changer_type', ['On-load','Off-load','Other']),
    'Tap Changer Chamber': ('asset', 'tap_changer_chamber', ['Connected','Not Connected']),
    'Unit In Service': ('sampling', 'unit_in_service', ['Yes','No (New)','No (De-energized)','Other']),
    'Test Priority': ('sampling', 'test_priority', ['Normal','Emergency']),
}
DETAILS = {'Tap Changer':['Y','B','R','1','2','3'], 'Bushings':['N','Y','U','V','W','B'], 'Cable Box':['N','Y','U','V','W','H1','H2','H3']}
HEADINGS = [a for group in FIELDS.values() for aliases in group.values() for a in aliases] + list(CHOICES) + ['Sampling From','Custody / Receiving','Date','Signature','Sampling Data','Transformer Information',"Client's Information",'Client Information','Form No.']

def norm(value: Any) -> str:
    return re.sub(r'\s+', ' ', str(value or '')).strip().strip('*').strip()

def _blocks(text: str) -> dict[str, list[str]]:
    """Support both LABEL value and LABEL\nvalue; stop at the next known label."""
    labels = sorted(HEADINGS, key=len, reverse=True)
    pattern = re.compile(r'^\s*('+'|'.join(re.escape(x) for x in labels)+r')\s*(?:[:*]\s*)?(.*?)\s*$', re.I)
    blocks: dict[str, list[str]] = {}; current = None
    for line in text.splitlines():
        match = pattern.match(line)
        if match:
            current = norm(match[1]).casefold()
            blocks.setdefault(current, []).append(match[2].strip())
        elif current:
            blocks[current][-1] += '\n'+line
    return blocks

def _marked(block: str) -> list[str]:
    return [norm(m.group(1)) for m in re.finditer(r'(?:\[\s*[Xx✓✔]\s*\]|[☑☒])\s*([^\[☑☒\n]+)',block)]

def parse_sampling_source(raw: bytes, text: str) -> dict[str, Any]:
    out: dict[str, Any] = {'client':{},'asset':{},'sampling':{},'samples':[], 'warnings':[], 'source_selections':{}}
    blocks = _blocks(text)
    for group, fields in FIELDS.items():
        for key, aliases in fields.items():
            for alias in aliases:
                values = blocks.get(alias.casefold(), [])
                if values and norm(values[0]) and not norm(values[0]).startswith('['):
                    # A scalar value ends at its first line, not at a footer or next section.
                    out[group][key] = norm(values[0].strip().splitlines()[0])[:500]
                    break
    for label,(group,key,options) in CHOICES.items():
        block = '\n'.join(blocks.get(label.casefold(),[]))
        canonical = {x.casefold():x for x in options}
        selected = [canonical[x.casefold()] for x in _marked(block) if x.casefold() in canonical]
        out['source_selections'][key] = selected
        if len(selected)==1:
            out[group][key] = selected[0]
        elif len(selected)>1:
            out['warnings'].append(f'{label}: multiple marked choices ({", ".join(selected)}); review required.')
            if 'Other' in options:
                out[group][key]='Other'; out[group][key+'_other']=' / '.join(selected)
    sampling_block = '\n'.join(blocks.get('sampling from',[]))
    for point in ['Bottom Tank','Top Tank','Buchholz Relay','Conservator','Other']:
        if re.search(r'(?:\[\s*[Xx✓✔]\s*\]|[☑☒])\s*'+re.escape(point)+r'(?=\s|$)',sampling_block):
            out['samples'].append({'sampling_from':point,'sampling_detail':''})
    for point, options in DETAILS.items():
        match = re.search(re.escape(point)+r'\s*:\s*([^\n]+)',sampling_block,re.I)
        if match:
            for selected in _marked(match[1]):
                if selected in options:
                    out['samples'].append({'sampling_from':point,'sampling_detail':selected})
    custody_parts = re.split(r'CUSTODY\s*/\s*RECEIVING',text,maxsplit=1,flags=re.I)
    custody = custody_parts[1] if len(custody_parts)==2 else ''
    dates = _blocks(custody).get('date',[])
    for i,key in enumerate(['delivered_date','received_date']):
        if len(dates)>i and dates[i].strip(): out['sampling'][key]=norm(dates[i].strip().splitlines()[0])
    # Read interactive widgets directly; extract_text does not include AcroForm values.
    try:
        widgets=PdfReader(io.BytesIO(raw)).get_fields() or {}
    except Exception:
        widgets={}
    widget_samples=[]
    for name,field in widgets.items():
        value=norm(field.get('/V',''))
        if value in {'','Select...','/Off'}: continue
        label=re.sub(r'^row\d+_\d+_', '', name)
        if label=='Date' and re.fullmatch(r'row\d+_[13]_Date',name):
            out['sampling']['delivered_date' if '_1_Date' in name else 'received_date']=value
        for group,fields in FIELDS.items():
            for key,aliases in fields.items():
                if label==key or label.casefold() in [a.casefold() for a in aliases]:
                    out[group][key]=value
        for title,(group,key,options) in CHOICES.items():
            if label==key or label.casefold()==title.casefold():
                if value in options: out[group][key]=value
                else: out['warnings'].append(f'{title}: unrecognized value; review original source.')
        if re.fullmatch(r'Sample \d+', label):
            point,sep,detail=value.partition(' - ')
            if point in ['Bottom Tank','Top Tank','Buchholz Relay','Conservator','Other'] or (point in DETAILS and detail in DETAILS[point]):
                widget_samples.append((int(label.split()[-1]),{'sampling_from':point,'sampling_detail':detail}))
    if widget_samples: out['samples']=[s for _,s in sorted(widget_samples)]
    expected=re.search(r'Number of Samples\s*:\s*(\d+)',text,re.I)
    if expected and int(expected[1])!=len(out['samples']):
        out['warnings'].append(f'Declared {expected[1]} sample(s); extracted {len(out["samples"])}. Review Sampling From selections.')
    return out
