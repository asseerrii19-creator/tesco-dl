# R14.6 — Sampling Selection Identity
Date: 2026-10-11
Version: 3.7.9

## Purpose
Close the Data Form physical-sample entry defect without changing the locked laboratory, QC, report, storage, approval, or barcode continuity workflows.

## Locked request logic
- Expected Number of Samples is declared once when the client opens the Request.
- One Data Form represents one transformer / one Serial Number.
- The client does not use `+ Add Sample` and does not type a second quantity inside the Data Form.
- Each checked leaf option under **Sampling From** creates exactly one physical sample.
- The Data Form sample count is derived automatically from the selected sampling identities.
- The request cannot submit until the total physical samples mapped across all Data Forms equals the Request-declared quantity.
- A Serial Number cannot be split across multiple Data Forms.

## Sampling From matrix
The base QDF [7]-03-A Page 1 sampling points remain the source structure.

Direct single-sample points:
- Bottom Tank
- Top Tank
- Buchholz Relay
- Conservator
- Other (requires free-text detail)

Detailed physical-sample identities confirmed for the digital form:
- Tap Changer: Y, B, R, 1, 2, 3
- Bushings: N, Y, U, V, W, B
- Cable Box: N, Y, U, V, W, H1, H2, H3

Each selected detail is a distinct physical sample. Example: Request quantity = 4 and one transformer can be completed by selecting Bottom Tank + Tap Changer Y + Tap Changer 1 + Cable Box H1.

## Identity / barcode continuity
- Draft Request: no formal BC number.
- Client Submit: formal BC request number is generated.
- Controlled commercial handover: one FS Sample ID + Barcode is generated for each mapped physical sample.
- Receiving/Data Entry scans and matches the same barcode.
- Internal custody extends the same sample identity with received timestamp, storage location/status and retention history; no second barcode is created.

## Compatibility
- Pre-R14.6 stored records and in-flight legacy form payloads remain readable.
- No database migration or reset is required.
