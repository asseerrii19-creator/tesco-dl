from __future__ import annotations

import json
import math
import re
from typing import Any

from sqlalchemy.orm import Session

from ..models import SampleRequest
from .lab_operations import get_operations_state


def _number(value: Any) -> float | None:
    if value is None:
        return None
    match = re.search(r"[-+]?\d+(?:\.\d+)?", str(value).replace(",", "."))
    if not match:
        return None
    try:
        return float(match.group())
    except ValueError:
        return None


def _latest_results(payload: dict[str, Any], sample_keys: str | list[str] | tuple[str, ...] | set[str]) -> list[dict[str, Any]]:
    if isinstance(sample_keys, str):
        keys = {sample_keys.upper()}
    else:
        keys = {str(key).upper() for key in sample_keys if str(key).strip()}
    rows = [r for r in payload.get("results", []) if str(r.get("sample") or r.get("sample_id") or "").upper() in keys]
    rows.sort(key=lambda r: str(r.get("ts", "")))
    latest: dict[str, dict[str, Any]] = {}
    for row in rows:
        latest[str(row.get("test", ""))] = row
    return list(latest.values())


def _find(rows: list[dict[str, Any]], *patterns: str) -> tuple[str, float] | None:
    for row in reversed(rows):
        name = str(row.get("test", ""))
        low = name.lower()
        if any(re.search(pattern, low) for pattern in patterns):
            value = _number(row.get("result"))
            if value is not None:
                return name, value
    return None



def _controlled_water_average(rows: list[dict[str, Any]]) -> tuple[str, float] | None:
    """Return only the final dual-instrument Water average, never an EQ raw reading."""
    for row in reversed(rows):
        code = str(row.get("test") or "").strip().lower()
        display = str(row.get("display_test") or "").strip().lower()
        if code == "water:kf_rt" or (display == "water content kf @rt" and ":eq-" not in code and " eq-" not in display):
            value = _number(row.get("result"))
            if value is not None:
                return "Water Content KF @RT", value
    return None

def _find_row(rows: list[dict[str, Any]], *patterns: str) -> dict[str, Any] | None:
    for row in reversed(rows):
        name = str(row.get("test", ""))
        low = name.lower()
        if any(re.search(pattern, low) for pattern in patterns):
            return row
    return None


def _evidence(row: dict[str, Any] | None) -> str:
    if not row:
        return ""
    unit = str(row.get("unit") or "").strip()
    result = str(row.get("result") or "").strip()
    return f"{row.get('test', '')}: {result}{(' ' + unit) if unit else ''}"


def _negative_qualitative(row: dict[str, Any] | None) -> bool:
    if not row:
        return False
    text = str(row.get("result") or "").strip().lower()
    return any(token in text for token in ("non-corrosive", "non corrosive", "negative", "pass", "not detected", "none detected"))


def _band(value: float, good_test, fair_test) -> str:
    if good_test(value):
        return "GOOD"
    if fair_test(value):
        return "FAIR"
    return "POOR"


def _iec_dga_fault(g: dict[str, float]) -> dict[str, Any] | None:
    required = ["H2", "CH4", "C2H6", "C2H4", "C2H2"]
    if not all(k in g and g[k] is not None for k in required):
        return None
    def ratio(a: str, b: str) -> float | None:
        if not g.get(b):
            return None
        return g[a] / g[b]
    r1 = ratio("C2H2", "C2H4")
    r2 = ratio("CH4", "H2")
    r3 = ratio("C2H4", "C2H6")
    if r2 is None or r3 is None:
        return None
    fault = "UNDETERMINED"
    if r2 < 0.1 and r3 < 0.2:
        fault = "PD"
    elif r1 is not None and r1 > 1 and 0.1 <= r2 <= 0.5 and r3 > 1:
        fault = "D1"
    elif r1 is not None and 0.6 <= r1 <= 2.5 and 0.1 <= r2 <= 1 and r3 > 2:
        fault = "D2"
    elif r2 > 1 and r3 < 1:
        fault = "T1"
    elif r1 is not None and r1 < 0.1 and r2 > 1 and 1 <= r3 <= 4:
        fault = "T2"
    elif r1 is not None and r1 < 0.2 and r2 > 1 and r3 > 4:
        fault = "T3"
    return {"fault": fault, "ratios": {"C2H2/C2H4": r1, "CH4/H2": r2, "C2H4/C2H6": r3}}


def assess_sample(db: Session, sample: SampleRequest) -> dict[str, Any]:
    state, payload = get_operations_state(db, sample.site)
    key = (sample.lms_number or sample.request_number).upper()
    sample_keys = {sample.request_number, str(sample.id)}
    if sample.lms_number:
        sample_keys.add(sample.lms_number)
    rows = _latest_results(payload, sample_keys)
    findings: list[dict[str, Any]] = []

    # RSD is a repeatability/statistical output of the six BDV shots, not an oil-condition
    # parameter. Never let an "RSD% of BDV" row satisfy the IEC 60422 BDV screening lookup.
    bdv_rows = [row for row in rows if "rsd" not in str(row.get("test") or "").lower()]
    bdv = _find(bdv_rows, r"breakdown voltage.*2\.5", r"bdv.*2\.5")
    if bdv:
        findings.append({"test": bdv[0], "value": bdv[1], "condition": _band(bdv[1], lambda v: v > 60, lambda v: 50 <= v <= 60), "reference": "IEC 60422:2024 Table 5 — screening profile A"})
    water = _controlled_water_average(rows)
    if water:
        findings.append({"test": water[0], "value": water[1], "condition": _band(water[1], lambda v: v < 30, lambda v: 30 <= v <= 40), "reference": "Controlled report screening band — Normal <30, Caution 30–40, Poor >40"})
    ddf = _find(rows, r"dissipation factor.*90")
    if ddf:
        findings.append({"test": ddf[0], "value": ddf[1], "condition": _band(ddf[1], lambda v: v < 0.10, lambda v: 0.10 <= v <= 0.20), "reference": "IEC 60422:2024 Table 5 — screening profile A"})
    resistivity = _find(rows, r"resistivity")
    if resistivity:
        findings.append({"test": resistivity[0], "value": resistivity[1], "condition": _band(resistivity[1], lambda v: v > 10, lambda v: 3 <= v <= 10), "reference": "IEC 60422:2024 Table 5 — screening profile A"})
    ift = _find(rows, r"interfacial tension", r"\bift\b")
    if ift:
        findings.append({"test": ift[0], "value": ift[1], "condition": _band(ift[1], lambda v: v > 28, lambda v: 22 <= v <= 28), "reference": "IEC 60422:2024 Table 5 — inhibited-oil screening"})

    gases: dict[str, float] = {}
    aliases = {
        "H2": [r"dga:h2", r"\bhydrogen\b"], "CH4": [r"dga:ch4", r"\bmethane\b"],
        "C2H6": [r"dga:c2h6", r"\bethane\b"], "C2H4": [r"dga:c2h4", r"\bethylene\b"],
        "C2H2": [r"dga:c2h2", r"\bacetylene\b"], "CO": [r"dga:co$", r"carbon monoxide"],
        "CO2": [r"dga:co2", r"carbon dioxide"], "O2": [r"dga:o2", r"\boxygen\b"], "N2": [r"dga:n2", r"\bnitrogen\b"],
    }
    dga_detection_limits = {'H2':1.0, 'CH4':1.0, 'C2H6':1.0, 'C2H4':1.0, 'C2H2':1.0, 'CO':1.0, 'CO2':1.0}
    for gas, pats in aliases.items():
        found = _find(rows, *pats)
        if found:
            value = found[1]
            # Results at/below the controlled DGA DL are censored (LTD). They remain
            # stored numerically for traceability but are not silently substituted into
            # diagnostic ratios as zero, DL, or DL/2.
            if gas in dga_detection_limits and value <= dga_detection_limits[gas]:
                continue
            gases[gas] = value
    dga = _iec_dga_fault(gases)
    if dga and gases.get("CO"):
        dga["ratios"]["CO2/CO"] = gases.get("CO2", 0) / gases["CO"]

    # Cross-test interpretation groups. These are deliberately advisory: they connect related
    # evidence for the Senior Chemist without turning one result into an unsupported diagnosis.
    tan_row = _find_row(rows, r"total acid number", r"\bacidity\b")
    peroxide_row = _find_row(rows, r"peroxide", r"hydroperoxide")
    bht_row = _find_row(rows, r"\bbht\b", r"antioxidant")
    dbds_row = _find_row(rows, r"dbds", r"dibenzyl")
    passivator_row = _find_row(rows, r"passivator", r"irgamet", r"\btta\b", r"\bbta\b")
    corrosive_row = _find_row(rows, r"corrosive sulfur", r"copper corrosion")
    ccd_row = _find_row(rows, r"potentially corrosive", r"\bccd\b")
    rsh_row = _find_row(rows, r"mercaptan", r"\brsh\b")
    h2s_row = _find_row(rows, r"hydrogen sulfide", r"\bh2s\b")
    fal_row = _find_row(rows, r"furan:2fal", r"2-furfural", r"2-fal")
    dp_row = _find_row(rows, r"indirect dp", r"furan_calc:indirect_dp")
    life_row = _find_row(rows, r"paper lifetime", r"furan_calc:paper_life")
    pf_row = _find_row(rows, r"power factor", r"dissipation factor")

    linked_assessments: list[dict[str, Any]] = []

    oxidation_evidence = [x for x in (tan_row, peroxide_row, bht_row, _find_row(rows, r"interfacial tension", r"\bift\b"), pf_row, _find_row(rows, r"resistivity")) if x]
    if oxidation_evidence:
        notes = ["Review oxidation/ageing indicators as one condition set rather than isolated values."]
        peroxide_value = _number(peroxide_row.get("result")) if peroxide_row else None
        if peroxide_value is not None and peroxide_value > 0:
            notes.append("Hydroperoxide/Peroxide is detected; correlate with TAN, inhibitor content and trend before recommendation.")
        if bht_row:
            notes.append("BHT is the oxidation-inhibitor result; assess it against the applicable oil/client limit and history, not as a corrosive-sulfur result.")
        linked_assessments.append({
            "title": "Oil Oxidation / Ageing", "status": "REVIEW",
            "evidence": [_evidence(x) for x in oxidation_evidence], "notes": notes,
            "reference": "IEC 60422 oil-condition context + ASTM D3703 hydroperoxide indication; asset/client limits take precedence",
        })

    sulfur_evidence = [x for x in (dbds_row, passivator_row, corrosive_row, ccd_row, rsh_row, h2s_row) if x]
    if sulfur_evidence:
        notes = ["Review DBDS, passivator and qualitative corrosive-sulfur evidence together."]
        dbds_value = _number(dbds_row.get("result")) if dbds_row else None
        pass_value = _number(passivator_row.get("result")) if passivator_row else None
        qualitative_negative = _negative_qualitative(corrosive_row) or _negative_qualitative(ccd_row)
        status = "REVIEW"
        if dbds_value is not None and dbds_value > 0 and pass_value is not None and pass_value > 0 and qualitative_negative:
            status = "ATTENTION"
            notes.append("Passivator is present while DBDS is detected and a qualitative corrosion test is negative/non-corrosive. IEC 62697 warns that passivation can mask qualitative corrosive-sulfur response; do not treat the qualitative result alone as clearance.")
        if rsh_row or h2s_row:
            notes.append("RSH/H2S are reactive-sulfur evidence and should be considered with the DBDS/CCD/corrosion picture when present.")
        linked_assessments.append({
            "title": "Corrosive Sulfur / Passivation", "status": status,
            "evidence": [_evidence(x) for x in sulfur_evidence], "notes": notes,
            "reference": "IEC 62697-1 cross-check: metal passivator can affect qualitative D1275B / IEC 62535 interpretation",
        })

    cellulose_evidence = [x for x in (fal_row, dp_row, life_row) if x]
    if cellulose_evidence or gases.get("CO") is not None or gases.get("CO2") is not None:
        notes = ["Use Furan/2-FAL and derived DP/paper-life as cellulose-ageing evidence and correlate with transformer history."]
        if gases.get("CO") is not None or gases.get("CO2") is not None:
            notes.append("CO/CO2 are available from DGA; review them together with Furan/cellulose indicators rather than using one gas result alone.")
        gas_evidence = []
        if gases.get("CO") is not None: gas_evidence.append(f"DGA CO: {gases['CO']}")
        if gases.get("CO2") is not None: gas_evidence.append(f"DGA CO2: {gases['CO2']}")
        linked_assessments.append({
            "title": "Cellulose / Paper Ageing", "status": "REVIEW",
            "evidence": [_evidence(x) for x in cellulose_evidence] + gas_evidence, "notes": notes,
            "reference": "Furan/DP calculations + DGA cellulose-gas context; trend and asset context required",
        })

    bdv_evidence_row = _find_row(bdv_rows, r"breakdown voltage", r"bdv")
    electrical_evidence = [x for x in (_find_row(rows, r"water content kf", r"water:.*kf"), bdv_evidence_row, pf_row, _find_row(rows, r"resistivity")) if x]
    if electrical_evidence:
        linked_assessments.append({
            "title": "Moisture / Dielectric Condition", "status": "REVIEW",
            "evidence": [_evidence(x) for x in electrical_evidence],
            "notes": ["Evaluate Water and BDV together; use PF/DDF and Resistivity as complementary dielectric/contamination evidence when available.", "Keep the recorded ASTM/IEC method and test condition attached to every result; related methods are not automatically interchangeable."],
            "reference": "IEC 60422 condition assessment; method-specific result context retained",
        })

    severity = {"GOOD": 0, "FAIR": 1, "POOR": 2}
    overall = max((f["condition"] for f in findings), key=lambda x: severity[x], default="NOT ASSESSED")
    observations: list[str] = []
    actions: list[str] = []
    if any(f["condition"] == "POOR" for f in findings):
        observations.append("One or more oil-condition parameters are in the Poor screening band.")
        actions.append("Confirm abnormal results against history and consider a fresh sample before final action.")
    elif any(f["condition"] == "FAIR" for f in findings):
        observations.append("Oil deterioration is detectable in at least one screening parameter.")
        actions.append("Review complementary tests and consider increased sampling frequency.")
    elif findings:
        observations.append("Available screened parameters are within the Good band.")
        actions.append("Continue normal sampling, subject to trend and asset-specific requirements.")
    if water and bdv:
        observations.append("Water and BDV should be evaluated together rather than as isolated results.")
    if ift:
        actions.append("Review IFT together with acidity and DDF when ageing or contamination is suspected.")
    if dga:
        observations.append(f"IEC 60599 gas-ratio screening result: {dga['fault']}.")
        actions.append("Use gas history, rates of increase, equipment context and Senior Chemist judgement before diagnosis or recommendation.")

    return {
        "sample_key": key, "profile": "IEC 60422:2024 + IEC 60599:2022 screening",
        "results_count": len(rows), "overall": overall, "findings": findings,
        "gases": gases, "dga": dga, "linked_assessments": linked_assessments, "observations": observations, "suggested_actions": actions,
        "disclaimer": "System-assisted internal screening only. Senior Chemist approval is required; client/manufacturer limits take precedence where applicable.",
    }
