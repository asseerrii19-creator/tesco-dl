# Defect Closure Register — v3.7.6

- REQ-COUNT-01: Request-level expected sample count missing — CLOSED.
- REQ-MAP-02: Data Form count could become the request count implicitly — CLOSED.
- REQ-NUM-03: Formal BC number consumed at Draft creation — CLOSED.
- REQ-VIS-04: Client Draft visible to Commercial workspace before Submit — CLOSED.

Verification: 91 passed / 0 failed.
