# Defect Closure Register — v3.7.9 / R14.6

## Closed
### DF-SEL-01 — Manual physical-sample line creation duplicates Request quantity entry
Status: CLOSED
Resolution: physical samples are now derived directly from Sampling From leaf selections.

### DF-SEL-02 — Four samples expand the Data Form into repeated checkbox walls / newspaper layout
Status: CLOSED
Resolution: one compact Sampling From matrix is shown once per transformer Data Form.

### DF-SEL-03 — Operational sub-identities incomplete
Status: CLOSED
Resolution:
- Tap Changer: Y/B/R and 1/2/3
- Bushings: N/Y/U/V/W/B
- Cable Box: N/Y/U/V/W and H1/H2/H3

### DF-SEL-04 — Client could conceptually allocate more samples than Request quantity
Status: CLOSED
Resolution: UI disables additional unselected identities at the remaining quantity; server rejects over-allocation.

## Preserved
- Request BC allocated only at client Submit.
- FS Sample ID / Barcode allocated at controlled handover.
- Same barcode persists through matching, Data Entry and internal custody.
