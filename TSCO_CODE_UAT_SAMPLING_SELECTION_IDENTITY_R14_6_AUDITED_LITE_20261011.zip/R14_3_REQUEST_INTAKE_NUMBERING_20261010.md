# R14.3 — Request Intake & Numbering Alignment

Version: `3.7.6-R14.3-REQUEST-INTAKE-NUMBERING-20261010`

## Closed defects

1. Client Request now declares `Expected Number of Samples` at request creation.
2. Draft Data Forms allocate/map physical samples against that declared quantity; they may not exceed it.
3. Submit is blocked unless Data Forms map exactly the declared quantity and every physical sample has exactly one Service Scope.
4. Data Forms no longer silently redefine the request quantity.
5. Unsaved/unsubmitted client drafts no longer consume a formal `BC-DMM-YYYY-NNNN` number. A hidden internal draft token is used while the request is Draft.
6. Formal Business Case / Request number is allocated on first client Submit, before coordinator notification/review.
7. Draft client requests are excluded from Commercial workspace until submitted.
8. Physical Sample IDs / barcodes remain unchanged in timing: `FS-DMM-YY-NNNNNN` + barcode are generated only at controlled handover, one per mapped physical sample.

## Authority boundaries preserved

- BC number = Request / Business Case reference; it is not a sample number.
- FS number = physical sample identity.
- No schema change; Alembic head remains `b3f1d8a6c920`.
- Final Report, QC, PF, DGA, BDV, Senior Review, Final Approval, retention and existing storage authority were not changed.
