# R14.4 — Data Form Physical Sample Allocation

Version: `3.7.7-R14.4-DATA-FORM-SAMPLE-ALLOCATION-20261011`

## Closed intake / Data Form defects

1. The Request-level `Expected Number of Samples` remains the single declared quantity and is captured before any Data Form is created.
2. `Number of Samples` inside each Sampling Data Form is now derived from the physical sample lines; the client no longer types a second sample quantity in the Data Form.
3. One transformer / one Serial Number is represented by one Data Form. Multiple physical samples from that transformer are added as separate sample lines inside the same form.
4. A duplicate transformer Serial Number is blocked across Data Forms in the same Request. The client is directed to add the remaining physical samples to the existing form.
5. Every physical sample line must identify `Sampling From`. `Other` requires a description. `Tap Changer` requires H1 / H2 / H3 / Other, and Other requires a description.
6. Data Form sample lines cannot make the request exceed the declared Request quantity. Request Submit remains blocked until mapped physical samples equal the declared quantity exactly and every sample has exactly one Service Scope.
7. Formal BC numbering remains deferred until client Submit. Physical FS Sample IDs and stable barcodes remain generated only at controlled handover, one per mapped physical sample.

## Example supported directly

Request declares 4 physical samples.

One Data Form / Serial `TR-A` can contain:
- Sample 1 — Bottom Tank
- Sample 2 — Tap Changer H1
- Sample 3 — Tap Changer H2
- Sample 4 — Tap Changer H3

The Data Form automatically reports `Number of Samples: 4`. At controlled handover, those four physical lines receive four independent FS Sample IDs / barcodes while remaining linked to the same transformer Data Form.

## Authority boundaries preserved

- BC number = submitted Request / Business Case reference.
- FS number = physical sample identity.
- Same stable barcode continues through receipt, laboratory work and internal storage; no second barcode is created.
- No database schema change; Alembic head remains `b3f1d8a6c920`.
- QC, PF, DGA, BDV, Senior Review, Final Approval, final-report release, retention and existing storage authority are unchanged.
