# Final Package Manifest — v3.7.6 / R14.3

Release: R14.3 Request Intake & Numbering Alignment
Version: 3.7.6-R14.3-REQUEST-INTAKE-NUMBERING-20261010
Alembic head: b3f1d8a6c920

This package is cumulative over R14.2 / v3.7.5 and R14.1 / v3.7.4.
It requires the existing `TSCO_REFERENCE_ASSETS.zip` to be extracted before this LITE code package, using the established Render build command pattern.
