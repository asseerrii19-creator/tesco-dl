# Final Package Manifest — v3.7.7 / R14.4

Release: R14.4 Data Form Physical Sample Allocation
Version: `3.7.7-R14.4-DATA-FORM-SAMPLE-ALLOCATION-20261011`

Cumulative authority includes R14.3 + R14.2 + R14.1 and the earlier audited baseline.

Primary R14.4 changes:
- Request quantity remains authoritative.
- Data Form quantity is derived from physical sample lines.
- Add / Remove Physical Sample UI within one transformer Data Form.
- Duplicate Serial Number prevention across Data Forms.
- Required Sampling From identity per physical sample.
- Required Tap Changer H1/H2/H3/Other position when applicable.
- No change to BC-on-Submit or FS/barcode-on-Handover timing.
- No schema migration added.

Deployment model remains LITE + existing `TSCO_REFERENCE_ASSETS.zip`.
