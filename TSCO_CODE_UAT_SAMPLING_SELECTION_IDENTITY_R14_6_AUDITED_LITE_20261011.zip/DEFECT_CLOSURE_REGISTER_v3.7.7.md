# Defect Closure Register — v3.7.7

Release: R14.4 Data Form Physical Sample Allocation

- DF-ALLOC-01 — Data Form exposed a second manual Number of Samples input. CLOSED: count is derived from physical sample lines.
- DF-ALLOC-02 — Same transformer could be split accidentally across multiple Data Forms. CLOSED: duplicate Serial Number is blocked per Request.
- DF-ALLOC-03 — Physical sample lines could be confirmed without an actual Sampling From identity. CLOSED: every line requires a sampling point; Tap Changer requires H1/H2/H3/Other.
- DF-ALLOC-04 — Same-transformer multi-sample workflow was not explicit in the paper UI. CLOSED: Add/Remove Physical Sample controls keep all same-serial samples in one Data Form.

Verification: 94 passed / 0 failed in the audited regression set. Render build must rerun `BUILD_RELEASE_CHECK.sh` with the existing external `TSCO_REFERENCE_ASSETS.zip` before deployment goes live.
