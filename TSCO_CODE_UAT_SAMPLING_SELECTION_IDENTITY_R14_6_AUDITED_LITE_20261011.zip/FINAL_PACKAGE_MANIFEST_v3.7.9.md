# Final Package Manifest — v3.7.9 / R14.6

Package intent: cumulative LITE code release for Project 00012.

Includes all prior cumulative R14 baseline functionality plus:
- Request-declared expected sample quantity retained as authority.
- One transformer / Serial Number per Data Form.
- Sampling From checkbox matrix creates physical samples directly.
- Tap Changer options: Y, B, R, 1, 2, 3.
- Bushings options: N, Y, U, V, W, B.
- Cable Box options: N, Y, U, V, W, H1, H2, H3.
- Automatic selected/required sample counter.
- UI prevents selecting beyond remaining Request quantity; server enforces the same rule.
- No repeated per-sample checkbox wall and no manual Add Sample workflow.
- Existing formal request numbering and stable barcode lifecycle preserved.

No database reset. No new Alembic migration. No changes to locked QC, PF, DGA, BDV, Senior Review, Final Approval, report release, QR, or storage authority.
