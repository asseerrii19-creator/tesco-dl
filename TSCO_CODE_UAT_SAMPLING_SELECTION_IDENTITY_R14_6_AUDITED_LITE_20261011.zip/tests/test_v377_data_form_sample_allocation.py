from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import CommercialCase, ClientSamplingDataForm
from app.services.sampling_data_form import data_form_forms, sample_count, sample_rows_by_index


def _login_client(browser: TestClient):
    r = browser.post('/login', data={'email': 'client@sec.local', 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303


def _new_request(browser: TestClient, expected: int, title: str) -> int:
    r = browser.post('/client/requests', data={
        'lead_title': title,
        'expected_samples': str(expected),
        'sample_delivery_mode': 'CLIENT_DELIVERY',
    }, follow_redirects=False)
    assert r.status_code == 303
    return int(r.headers['location'].rstrip('/').split('/')[-1])


def _new_form(browser: TestClient, case_id: int) -> int:
    r = browser.post(f'/client/requests/{case_id}/data-forms/new', follow_redirects=False)
    assert r.status_code == 303
    return int(r.headers['location'].split('edit_data_form=')[1].split('#')[0])


def test_one_transformer_four_physical_samples_are_one_data_form_and_count_is_derived_from_lines():
    token = uuid4().hex[:8].upper()
    with TestClient(app) as browser:
        _login_client(browser)
        case_id = _new_request(browser, 4, f'R14.4 same transformer {token}')
        assert _new_form(browser, case_id) == 1
        page = browser.get(f'/client/requests/{case_id}?edit_data_form=1')
        assert page.status_code == 200
        assert 'derived automatically from Sampling From selections' in page.text
        assert 'name="number_of_samples"' not in page.text
        assert '+ Add Sample' not in page.text
        assert 'Request: 4 physical sample(s)' in page.text

        payload = {
            'company_name': 'Saudi Electricity Company',
            'serial_number': f'TR-{token}',
            'test_priority': 'Normal',
            'sample_line_index': ['1', '2', '3', '4'],
            'sampling_from_1': 'Bottom Tank',
            'sampling_from_2': 'Tap Changer', 'tap_changer_position_2': 'H1',
            'sampling_from_3': 'Tap Changer', 'tap_changer_position_3': 'H2',
            'sampling_from_4': 'Tap Changer', 'tap_changer_position_4': 'H3',
        }
        r = browser.post(f'/client/requests/{case_id}/data-forms/1', data=payload, follow_redirects=False)
        assert r.status_code == 303

        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case and case.expected_samples == 4
            row = db.scalar(select(ClientSamplingDataForm).where(ClientSamplingDataForm.commercial_case_id == case_id)); assert row
            assert sample_count(row) == 4
            forms = data_form_forms(row)
            assert len(forms) == 1 and len(forms[0]['samples']) == 4
            rows = sample_rows_by_index(row)
            assert [rows[i]['serial_number'] for i in range(1, 5)] == [f'TR-{token}'] * 4
            assert [rows[i]['sampling_point_label'] for i in range(1, 5)] == [
                'Bottom Tank', 'Tap Changer — H1', 'Tap Changer — H2', 'Tap Changer — H3'
            ]

        page = browser.get(f'/client/requests/{case_id}')
        assert '4 / 4 mapped in Data Forms' in page.text
        assert f'TR-{token}' in page.text


def test_same_transformer_serial_cannot_be_split_across_two_data_forms():
    token = uuid4().hex[:8].upper()
    serial = f'TR-DUP-{token}'
    with TestClient(app) as browser:
        _login_client(browser)
        case_id = _new_request(browser, 2, f'R14.4 duplicate serial {token}')
        _new_form(browser, case_id)
        r = browser.post(f'/client/requests/{case_id}/data-forms/1', data={
            'company_name': 'Saudi Electricity Company', 'serial_number': serial, 'test_priority': 'Normal',
            'sample_line_index': ['1'], 'sampling_from_1': 'Bottom Tank',
        }, follow_redirects=False)
        assert r.status_code == 303
        assert _new_form(browser, case_id) == 2
        r = browser.post(f'/client/requests/{case_id}/data-forms/2', data={
            'company_name': 'Saudi Electricity Company', 'serial_number': serial.lower(), 'test_priority': 'Normal',
            'sample_line_index': ['1'], 'sampling_from_1': 'Top Tank',
        }, follow_redirects=False)
        assert r.status_code == 400
        assert 'already belongs to Data Form 1' in r.text
        assert 'Add the remaining physical samples to that existing Data Form' in r.text


def test_each_physical_sample_line_requires_real_sampling_identity_before_confirmation():
    token = uuid4().hex[:8].upper()
    with TestClient(app) as browser:
        _login_client(browser)
        case_id = _new_request(browser, 2, f'R14.4 line validation {token}')
        _new_form(browser, case_id)
        r = browser.post(f'/client/requests/{case_id}/data-forms/1', data={
            'company_name': 'Saudi Electricity Company', 'serial_number': f'TR-{token}', 'test_priority': 'Normal',
            'sample_line_index': ['1', '2'], 'sampling_from_1': 'Bottom Tank',
        }, follow_redirects=False)
        assert r.status_code == 400
        assert 'Select Sampling From for physical Sample 2' in r.text

        r = browser.post(f'/client/requests/{case_id}/data-forms/1', data={
            'company_name': 'Saudi Electricity Company', 'serial_number': f'TR-{token}', 'test_priority': 'Normal',
            'sample_line_index': ['1', '2'], 'sampling_from_1': 'Bottom Tank', 'sampling_from_2': 'Tap Changer',
        }, follow_redirects=False)
        assert r.status_code == 400
        assert 'Select Tap Changer Position for physical Sample 2' in r.text


def test_r146_sampling_matrix_replaces_manual_add_sample_editor():
    token = uuid4().hex[:8].upper()
    with TestClient(app) as browser:
        _login_client(browser)
        case_id = _new_request(browser, 4, f'R14.6 selection editor {token}')
        _new_form(browser, case_id)
        page = browser.get(f'/client/requests/{case_id}?edit_data_form=1')
        assert page.status_code == 200
        assert 'sampling-selection-matrix' in page.text
        assert 'name="sample_selection"' in page.text
        assert '+ Add Sample' not in page.text
        assert 'Remove Last' not in page.text
        assert 'paper-sample-row-compact' not in page.text
