from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import User
from app.services.lab_operations import _analytical_qc_schedule_state, _bind_required_qc_to_result

LAB_TZ = ZoneInfo("Asia/Riyadh")
TODAY = datetime.now(timezone.utc).astimezone(LAB_TZ).date()
TODAY_S = TODAY.isoformat()
YESTERDAY_S = (TODAY - timedelta(days=1)).isoformat()


def payload(user, group='Water', test='Water Content KF @RT', method='IEC 60814', workstation='Water'):
    return {
        'batches': [
            {'id': 'B1', 'samples': [f'S{i}' for i in range(1, 15)], 'tests': [{'test': test, 'method': method, 'station': workstation}], 'status': 'Testing'},
            {'id': 'B2', 'samples': ['T1'], 'tests': [{'test': test, 'method': method, 'station': workstation}], 'status': 'Testing'},
        ],
        'testAssignments': [
            {'id': 'A1', 'batch_id': 'B1', 'workstation': workstation, 'mode': 'SINGLE', 'primary_user_id': user.id, 'revision': 1},
            {'id': 'A2', 'batch_id': 'B2', 'workstation': workstation, 'mode': 'SINGLE', 'primary_user_id': user.id, 'revision': 1},
        ],
        'qc': [], 'results': [],
    }


def qc(qid, group='Water', test='Water Content KF @RT', method='IEC 60814', workstation='Water', status='PASS', ts=f'{TODAY_S}T05:00:00', eq=69):
    return {'id': qid, 'mode': 'routine', 'test': group, 'context_test': test, 'method_name': method, 'workstation': workstation, 'equipment_asset_id': eq, 'equipment_id': f'EQ-{eq}', 'status': status, 'ts': ts, 'qc_day': TODAY_S}


def result(rid, sample, ts, qid='Q2', group='Water', method='IEC 60814', workstation='Water', eq=69):
    return {'id': rid, 'batch': 'B1', 'sample': sample, 'test': f'WATER:KF_RT:EQ-{eq}', 'display_test': f'Water Content KF @RT — EQ-{eq}', 'result': '9', 'qc_group': group, 'qc_record_id': qid, 'test_method': method, 'workstation': workstation, 'equipment_asset_id': eq, 'equipment_id': f'EQ-{eq}', 'ts': ts}


def test_water_requires_two_startup_qcs_then_blocks_the_11th_result():
    with TestClient(app):
        with SessionLocal() as db:
            user = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert user
            p = payload(user)
            ctx = {'group': 'Water', 'test': 'Water Content KF @RT', 'method': 'IEC 60814', 'workstation': 'Water'}
            now = datetime.now(timezone.utc)
            s = _analytical_qc_schedule_state(p, ctx, 69, now=now)
            assert s['reason'] == 'WATER_STARTUP_1'
            p['qc'].append(qc('Q1', ts=f'{TODAY_S}T05:01:00'))
            s = _analytical_qc_schedule_state(p, ctx, 69, now=now)
            assert s['reason'] == 'WATER_STARTUP_2'
            p['qc'].append(qc('Q2', ts=f'{TODAY_S}T05:02:00'))
            assert _analytical_qc_schedule_state(p, ctx, 69, now=now)['ready']
            for i in range(10):
                p['results'].append(result(f'R{i+1}', f'S{i+1}', f'{TODAY_S}T05:{10+i:02d}:00'))
            s = _analytical_qc_schedule_state(p, ctx, 69, now=now)
            assert s['reason'] == 'WATER_10_RESULT_CHECKPOINT'
            assert s['results_since_qc'] == 10


def test_water_tenth_pair_allowed_but_eleventh_pair_is_blocked_until_both_checkpoint_qcs():
    with TestClient(app):
        with SessionLocal() as db:
            user = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert user
            p = payload(user)
            p['qc'] = [
                qc('Q1-69', ts=f'{TODAY_S}T05:01:00', eq=69), qc('Q2-69', ts=f'{TODAY_S}T05:02:00', eq=69),
                qc('Q1-70', ts=f'{TODAY_S}T05:01:30', eq=70), qc('Q2-70', ts=f'{TODAY_S}T05:02:30', eq=70),
            ]
            for i in range(9):
                p['results'].append(result(f'R69-{i+1}', f'S{i+1}', f'{TODAY_S}T05:{10+i:02d}:00', qid='Q2-69', eq=69))
                p['results'].append(result(f'R70-{i+1}', f'S{i+1}', f'{TODAY_S}T05:{10+i:02d}:30', qid='Q2-70', eq=70))

            tenth69 = result('R69-10', 'S10', f'{TODAY_S}T05:19:00', qid='Q2-69', eq=69)
            tenth70 = result('R70-10', 'S10', f'{TODAY_S}T05:19:30', qid='Q2-70', eq=70)
            proposed = deepcopy(p); proposed['results'].extend([tenth69, tenth70])
            _bind_required_qc_to_result(proposed, proposed['batches'][0], tenth69, user, db=None, site_id=None)
            _bind_required_qc_to_result(proposed, proposed['batches'][0], tenth70, user, db=None, site_id=None)
            p['results'].extend([tenth69, tenth70])

            eleventh69 = result('R69-11', 'S11', f'{TODAY_S}T05:21:00', qid='Q2-69', eq=69)
            eleventh70 = result('R70-11', 'S11', f'{TODAY_S}T05:21:30', qid='Q2-70', eq=70)
            proposed = deepcopy(p); proposed['results'].extend([eleventh69, eleventh70])
            with pytest.raises(PermissionError, match='10 results'):
                _bind_required_qc_to_result(proposed, proposed['batches'][0], eleventh69, user, db=None, site_id=None)

            p['qc'].extend([
                qc('Q3-69', ts=f'{TODAY_S}T05:20:00', eq=69),
                qc('Q3-70', ts=f'{TODAY_S}T05:20:30', eq=70),
            ])
            proposed = deepcopy(p); proposed['results'].extend([eleventh69, eleventh70])
            _bind_required_qc_to_result(proposed, proposed['batches'][0], eleventh69, user, db=None, site_id=None)
            _bind_required_qc_to_result(proposed, proposed['batches'][0], eleventh70, user, db=None, site_id=None)
            assert eleventh69['qc_record_id'] == 'Q3-69'
            assert eleventh70['qc_record_id'] == 'Q3-70'


def test_non_water_daily_qc_spans_batches_but_old_day_does_not():
    with TestClient(app):
        with SessionLocal() as db:
            user = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert user
            p = payload(user, group='DGA', test='Dissolved Gas Analysis (DGA)', method='IEC 60567', workstation='DGA')
            q = qc('DGA-Q', group='DGA', test='Dissolved Gas Analysis (DGA)', method='IEC 60567', workstation='DGA', ts=f'{TODAY_S}T05:00:00', eq=1); p['qc']=[q]
            row={'id':'DG-R1','batch':'B2','sample':'T1','test':'DGA:H2','display_test':'Hydrogen','result':'10','qc_record_id':'DGA-Q'}
            proposed=deepcopy(p); proposed['results'].append(row)
            _bind_required_qc_to_result(proposed, proposed['batches'][1], row, user, db=None, site_id=None)
            assert row['qc_record_id']=='DGA-Q'
            p['qc'][0]['qc_day']=YESTERDAY_S; p['qc'][0]['ts']=f'{YESTERDAY_S}T05:00:00'
            row2={'id':'DG-R2','batch':'B2','sample':'T1','test':'DGA:H2','display_test':'Hydrogen','result':'10','qc_record_id':'DGA-Q'}
            proposed=deepcopy(p); proposed['results'].append(row2)
            with pytest.raises(PermissionError, match='Daily Analytical QC required'):
                _bind_required_qc_to_result(proposed, proposed['batches'][1], row2, user, db=None, site_id=None)


def test_latest_failed_qc_blocks_even_when_older_pass_exists():
    with TestClient(app):
        with SessionLocal() as db:
            user = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert user
            p = payload(user, group='TAN', test='Total Acid Number', method='ASTM D664', workstation='TAN / Peroxide / RSH / H2S')
            p['qc']=[qc('PASS1', group='TAN', test='Total Acid Number', method='ASTM D664', workstation='TAN / Peroxide / RSH / H2S', ts=f'{TODAY_S}T05:00:00', eq=2), qc('FAIL2', group='TAN', test='Total Acid Number', method='ASTM D664', workstation='TAN / Peroxide / RSH / H2S', status='FAIL', ts=f'{TODAY_S}T05:05:00', eq=2)]
            row={'id':'TAN-R','batch':'B1','sample':'S1','test':'Total Acid Number','display_test':'Total Acid Number','result':'0.1','qc_record_id':'PASS1'}
            proposed=deepcopy(p); proposed['results'].append(row)
            with pytest.raises(PermissionError, match='recovery required'):
                _bind_required_qc_to_result(proposed, proposed['batches'][0], row, user, db=None, site_id=None)


def test_workstation_ui_has_fixed_qc_panel_above_batches_and_save_lock():
    with TestClient(app) as browser:
        r=browser.post('/login',data={'email':'technician@tsco.local','password':'Demo123!'},follow_redirects=False); assert r.status_code==303
        page=browser.get('/lab/operations/app?embed=1&section=workstations&workstation=Water'); assert page.status_code==200
        html=page.text
        assert '<div id="wsQcPanel"></div><div id="queues"></div>' in html
        assert 'two acceptable startup QC runs on EACH active Water instrument' in html
        assert "WATER_10_RESULT_CHECKPOINT" in html
        assert "DAILY QC REQUIRED" in html
        assert "saveBtn.disabled=true;saveBtn.textContent='SAVING…'" in html
        assert "goPage('quality');renderQuality()" not in html
        assert "$('queues').innerHTML=qcHtml+" in html
        assert 'QC REQUIRED BEFORE RESULT' in html
        assert 'applyAnalyticalQcActionLocks' in html
        assert 'resultQcUiState' in html
        assert 'SAVE BOTH READINGS + AVERAGE' in html
        assert "'WATER:KF_RT:'+eq.equipment_id" in html
        assert 'Final Water @RT' in html
        assert 'Water result entry stays locked until every active Water instrument is QC-ready.' in html

@pytest.mark.parametrize(
    ('group', 'test_name', 'method', 'workstation'),
    [
        ('DGA', 'Dissolved Gas Analysis (DGA)', 'IEC 60567', 'DGA'),
        ('Furan', '2-Furfural (2FAL)', 'IEC 61198', 'Furan / Passivator'),
        ('BHT', 'Antioxidant (BHT)', 'IEC 60666', 'DBDS / BHT / Toluene / PCB'),
        ('Toluene', 'Toluene', 'ASTM D5580', 'DBDS / BHT / Toluene / PCB'),
        ('DBDS', 'Dibenzyl Disulfide (DBDS)', 'IEC 62697-1', 'DBDS / BHT / Toluene / PCB'),
        ('TAN', 'Total Acid Number', 'ASTM D664', 'TAN / Peroxide / RSH / H2S'),
    ],
)
def test_named_daily_qc_examples_cover_same_context_across_batches(group, test_name, method, workstation):
    """Daily Analytical QC is test/method/equipment scoped, not batch scoped."""
    with TestClient(app):
        with SessionLocal() as db:
            user = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert user
            p = payload(user, group=group, test=test_name, method=method, workstation=workstation)
            p['qc'] = [qc('DAILY-QC', group=group, test=test_name, method=method, workstation=workstation,
                          ts=f'{TODAY_S}T05:00:00', eq=777)]
            row = {
                'id': 'R-B2', 'batch': 'B2', 'sample': 'T1',
                'test': test_name, 'display_test': test_name, 'result': '1',
                'qc_record_id': 'DAILY-QC',
            }
            proposed = deepcopy(p); proposed['results'].append(row)
            _bind_required_qc_to_result(proposed, proposed['batches'][1], row, user, db=None, site_id=None)
            assert row['qc_record_id'] == 'DAILY-QC'
            assert row['equipment_asset_id'] == 777

def test_result_actions_lock_only_during_valid_submit_and_disappear_after_completion():
    source = (Path(__file__).parents[1] / 'app' / 'lab_ops' / 'index_template.html').read_text()
    assert "const dgaDone=CFG.dgaComponents.every(c=>!!getResult(s,'DGA:'+c.key))" in source
    assert "dgaDone?'<span class=\"badge ok\">RESULTS SAVED</span>'" in source
    # Validation must occur before disabling the action; invalid input must not strand a dead button.
    water_validate = source.index("if(readings.some(x=>x.num===null))return alert('Enter a valid Water @RT reading for both instruments.')")
    water_lock = source.index("saveBtn.disabled=true;saveBtn.textContent='SAVING…'", water_validate)
    assert water_validate < water_lock
    multi_validate = source.index("if(inputs.some(i=>!i.value.trim()))return alert(kind==='FURAN'?")
    multi_lock = source.index("saveBtn.disabled=true;saveBtn.textContent='SAVING…'", multi_validate)
    assert multi_validate < multi_lock
