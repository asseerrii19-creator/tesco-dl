from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import CommercialCase, ClientSamplingDataForm
from app.services.sampling_data_form import SAMPLE_DETAIL_OPTIONS, data_form_forms, sample_count, sample_rows_by_index


def _login_client(browser: TestClient):
    r = browser.post('/login', data={'email': 'client@sec.local', 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303


def _new_request(browser: TestClient, expected: int, title: str) -> int:
    r = browser.post('/client/requests', data={
        'lead_title': title,
        'expected_samples': str(expected),
        'sample_delivery_mode': 'CLIENT_DELIVERY',
    }, follow_redirects=False)
    assert r.status_code == 303
    return int(r.headers['location'].rstrip('/').split('/')[-1])


def _new_form(browser: TestClient, case_id: int) -> int:
    r = browser.post(f'/client/requests/{case_id}/data-forms/new', follow_redirects=False)
    assert r.status_code == 303
    return int(r.headers['location'].split('edit_data_form=')[1].split('#')[0])


def test_sampling_matrix_has_exact_user_confirmed_leaf_options_and_no_add_sample_ui():
    assert SAMPLE_DETAIL_OPTIONS == {
        'Tap Changer': ['Y', 'B', 'R', '1', '2', '3'],
        'Bushings': ['N', 'Y', 'U', 'V', 'W', 'B'],
        'Cable Box': ['N', 'Y', 'U', 'V', 'W', 'H1', 'H2', 'H3'],
    }
    token = uuid4().hex[:8].upper()
    with TestClient(app) as browser:
        _login_client(browser)
        case_id = _new_request(browser, 4, f'R14.6 sampling matrix {token}')
        _new_form(browser, case_id)
        page = browser.get(f'/client/requests/{case_id}?edit_data_form=1')
        assert page.status_code == 200
        assert 'name="sample_selection_mode" value="1"' in page.text
        assert 'name="sample_selection" value="Tap Changer|Y"' in page.text
        assert 'name="sample_selection" value="Tap Changer|3"' in page.text
        assert 'name="sample_selection" value="Bushings|N"' in page.text
        assert 'name="sample_selection" value="Bushings|B"' in page.text
        assert 'name="sample_selection" value="Cable Box|N"' in page.text
        assert 'name="sample_selection" value="Cable Box|H3"' in page.text
        assert '+ Add Sample' not in page.text
        assert 'Remove Last' not in page.text
        assert 'Selected:' in page.text
        assert 'Each checked sampling identity = one physical sample.' in page.text


def test_four_request_samples_are_created_directly_from_four_checked_sampling_identities():
    token = uuid4().hex[:8].upper()
    serial = f'TR-{token}'
    with TestClient(app) as browser:
        _login_client(browser)
        case_id = _new_request(browser, 4, f'R14.6 same transformer {token}')
        _new_form(browser, case_id)
        payload = {
            'company_name': 'Saudi Electricity Company',
            'serial_number': serial,
            'test_priority': 'Normal',
            'sample_selection_mode': '1',
            'sample_selection': ['Bottom Tank', 'Tap Changer|Y', 'Tap Changer|1', 'Cable Box|H1'],
        }
        r = browser.post(f'/client/requests/{case_id}/data-forms/1', data=payload, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case and case.expected_samples == 4
            row = db.scalar(select(ClientSamplingDataForm).where(ClientSamplingDataForm.commercial_case_id == case_id)); assert row
            assert sample_count(row) == 4
            forms = data_form_forms(row)
            assert len(forms) == 1 and len(forms[0]['samples']) == 4
            rows = sample_rows_by_index(row)
            assert [rows[i]['serial_number'] for i in range(1, 5)] == [serial] * 4
            assert [rows[i]['sampling_point_label'] for i in range(1, 5)] == [
                'Bottom Tank', 'Tap Changer — Y', 'Tap Changer — 1', 'Cable Box — H1'
            ]
        page = browser.get(f'/client/requests/{case_id}')
        assert '4 / 4 mapped in Data Forms' in page.text


def test_backend_rejects_more_checked_samples_than_request_declared_quantity():
    token = uuid4().hex[:8].upper()
    with TestClient(app) as browser:
        _login_client(browser)
        case_id = _new_request(browser, 4, f'R14.6 quantity guard {token}')
        _new_form(browser, case_id)
        payload = {
            'company_name': 'Saudi Electricity Company', 'serial_number': f'TR-{token}',
            'test_priority': 'Normal', 'sample_selection_mode': '1',
            'sample_selection': ['Bottom Tank', 'Top Tank', 'Tap Changer|Y', 'Tap Changer|B', 'Cable Box|H1'],
        }
        r = browser.post(f'/client/requests/{case_id}/data-forms/1', data=payload, follow_redirects=False)
        assert r.status_code == 400
        assert 'cannot exceed the declared request quantity of 4 physical sample(s)' in r.text


def test_same_serial_still_cannot_be_split_across_two_data_forms_with_selection_matrix():
    token = uuid4().hex[:8].upper(); serial = f'TR-DUP-{token}'
    with TestClient(app) as browser:
        _login_client(browser)
        case_id = _new_request(browser, 2, f'R14.6 duplicate serial {token}')
        _new_form(browser, case_id)
        r = browser.post(f'/client/requests/{case_id}/data-forms/1', data={
            'company_name':'Saudi Electricity Company','serial_number':serial,'test_priority':'Normal',
            'sample_selection_mode':'1','sample_selection':['Bottom Tank'],
        }, follow_redirects=False)
        assert r.status_code == 303
        assert _new_form(browser, case_id) == 2
        r = browser.post(f'/client/requests/{case_id}/data-forms/2', data={
            'company_name':'Saudi Electricity Company','serial_number':serial.lower(),'test_priority':'Normal',
            'sample_selection_mode':'1','sample_selection':['Top Tank'],
        }, follow_redirects=False)
        assert r.status_code == 400
        assert 'already belongs to Data Form 1' in r.text
