from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import User
from app.services.lab_operations import _analytical_qc_schedule_state, _bind_required_qc_to_result


def payload(user, group='Water', test='Water Content KF @RT', method='IEC 60814', workstation='Water'):
    return {
        'batches': [
            {'id': 'B1', 'samples': [f'S{i}' for i in range(1, 15)], 'tests': [{'test': test, 'method': method, 'station': workstation}], 'status': 'Testing'},
            {'id': 'B2', 'samples': ['T1'], 'tests': [{'test': test, 'method': method, 'station': workstation}], 'status': 'Testing'},
        ],
        'testAssignments': [
            {'id': 'A1', 'batch_id': 'B1', 'workstation': workstation, 'mode': 'SINGLE', 'primary_user_id': user.id, 'revision': 1},
            {'id': 'A2', 'batch_id': 'B2', 'workstation': workstation, 'mode': 'SINGLE', 'primary_user_id': user.id, 'revision': 1},
        ],
        'qc': [], 'results': [],
    }


def qc(qid, group='Water', test='Water Content KF @RT', method='IEC 60814', workstation='Water', status='PASS', ts='2026-10-02T05:00:00', eq=69):
    return {'id': qid, 'mode': 'routine', 'test': group, 'context_test': test, 'method_name': method, 'workstation': workstation, 'equipment_asset_id': eq, 'equipment_id': f'EQ-{eq}', 'status': status, 'ts': ts, 'qc_day': '2026-10-02'}


def result(rid, sample, ts, qid='Q2', group='Water', method='IEC 60814', workstation='Water', eq=69):
    return {'id': rid, 'batch': 'B1', 'sample': sample, 'test': 'WATER:KF_RT', 'display_test': 'Water Content KF @RT', 'result': '9', 'qc_group': group, 'qc_record_id': qid, 'test_method': method, 'workstation': workstation, 'equipment_asset_id': eq, 'ts': ts}


def test_water_requires_two_startup_qcs_then_blocks_the_11th_result():
    with TestClient(app):
        with SessionLocal() as db:
            user = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert user
            p = payload(user)
            ctx = {'group': 'Water', 'test': 'Water Content KF @RT', 'method': 'IEC 60814', 'workstation': 'Water'}
            now = datetime(2026, 10, 2, 8, 0, tzinfo=timezone.utc)
            s = _analytical_qc_schedule_state(p, ctx, 69, now=now)
            assert s['reason'] == 'WATER_STARTUP_1'
            p['qc'].append(qc('Q1', ts='2026-10-02T05:01:00'))
            s = _analytical_qc_schedule_state(p, ctx, 69, now=now)
            assert s['reason'] == 'WATER_STARTUP_2'
            p['qc'].append(qc('Q2', ts='2026-10-02T05:02:00'))
            assert _analytical_qc_schedule_state(p, ctx, 69, now=now)['ready']
            for i in range(10):
                p['results'].append(result(f'R{i+1}', f'S{i+1}', f'2026-10-02T05:{10+i:02d}:00'))
            s = _analytical_qc_schedule_state(p, ctx, 69, now=now)
            assert s['reason'] == 'WATER_10_RESULT_CHECKPOINT'
            assert s['results_since_qc'] == 10


def test_water_tenth_result_allowed_but_eleventh_is_blocked_until_checkpoint_qc():
    with TestClient(app):
        with SessionLocal() as db:
            user = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert user
            p = payload(user); p['qc'] = [qc('Q1', ts='2026-10-02T05:01:00'), qc('Q2', ts='2026-10-02T05:02:00')]
            for i in range(9): p['results'].append(result(f'R{i+1}', f'S{i+1}', f'2026-10-02T05:{10+i:02d}:00'))
            tenth = {'id':'R10','batch':'B1','sample':'S10','test':'WATER:KF_RT','display_test':'Water Content KF @RT','result':'9','qc_record_id':'Q2'}
            proposed = deepcopy(p); proposed['results'].append(tenth)
            _bind_required_qc_to_result(proposed, proposed['batches'][0], tenth, user, db=None, site_id=None)
            p['results'].append(result('R10','S10','2026-10-02T05:19:00'))
            eleventh = {'id':'R11','batch':'B1','sample':'S11','test':'WATER:KF_RT','display_test':'Water Content KF @RT','result':'9','qc_record_id':'Q2'}
            proposed = deepcopy(p); proposed['results'].append(eleventh)
            with pytest.raises(PermissionError, match='10 results'):
                _bind_required_qc_to_result(proposed, proposed['batches'][0], eleventh, user, db=None, site_id=None)
            p['qc'].append(qc('Q3', ts='2026-10-02T05:20:00'))
            proposed = deepcopy(p); proposed['results'].append(eleventh)
            _bind_required_qc_to_result(proposed, proposed['batches'][0], eleventh, user, db=None, site_id=None)
            assert eleventh['qc_record_id'] == 'Q3'


def test_non_water_daily_qc_spans_batches_but_old_day_does_not():
    with TestClient(app):
        with SessionLocal() as db:
            user = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert user
            p = payload(user, group='DGA', test='Dissolved Gas Analysis (DGA)', method='IEC 60567', workstation='DGA')
            q = qc('DGA-Q', group='DGA', test='Dissolved Gas Analysis (DGA)', method='IEC 60567', workstation='DGA', ts='2026-10-02T05:00:00', eq=1); p['qc']=[q]
            row={'id':'DG-R1','batch':'B2','sample':'T1','test':'DGA:H2','display_test':'Hydrogen','result':'10','qc_record_id':'DGA-Q'}
            proposed=deepcopy(p); proposed['results'].append(row)
            _bind_required_qc_to_result(proposed, proposed['batches'][1], row, user, db=None, site_id=None)
            assert row['qc_record_id']=='DGA-Q'
            p['qc'][0]['qc_day']='2026-10-01'; p['qc'][0]['ts']='2026-10-01T05:00:00'
            row2={'id':'DG-R2','batch':'B2','sample':'T1','test':'DGA:H2','display_test':'Hydrogen','result':'10','qc_record_id':'DGA-Q'}
            proposed=deepcopy(p); proposed['results'].append(row2)
            with pytest.raises(PermissionError, match='Daily Analytical QC required'):
                _bind_required_qc_to_result(proposed, proposed['batches'][1], row2, user, db=None, site_id=None)


def test_latest_failed_qc_blocks_even_when_older_pass_exists():
    with TestClient(app):
        with SessionLocal() as db:
            user = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert user
            p = payload(user, group='TAN', test='Total Acid Number', method='ASTM D664', workstation='TAN / Peroxide / RSH / H2S')
            p['qc']=[qc('PASS1', group='TAN', test='Total Acid Number', method='ASTM D664', workstation='TAN / Peroxide / RSH / H2S', ts='2026-10-02T05:00:00', eq=2), qc('FAIL2', group='TAN', test='Total Acid Number', method='ASTM D664', workstation='TAN / Peroxide / RSH / H2S', status='FAIL', ts='2026-10-02T05:05:00', eq=2)]
            row={'id':'TAN-R','batch':'B1','sample':'S1','test':'Total Acid Number','display_test':'Total Acid Number','result':'0.1','qc_record_id':'PASS1'}
            proposed=deepcopy(p); proposed['results'].append(row)
            with pytest.raises(PermissionError, match='recovery required'):
                _bind_required_qc_to_result(proposed, proposed['batches'][0], row, user, db=None, site_id=None)


def test_workstation_ui_has_fixed_qc_panel_above_batches_and_save_lock():
    with TestClient(app) as browser:
        r=browser.post('/login',data={'email':'technician@tsco.local','password':'Demo123!'},follow_redirects=False); assert r.status_code==303
        page=browser.get('/lab/operations/app?embed=1&section=workstations&workstation=Water'); assert page.status_code==200
        html=page.text
        assert '<div id="wsQcPanel"></div><div id="queues"></div>' in html
        assert 'two acceptable Water QC runs before the first result of the day' in html
        assert "WATER_10_RESULT_CHECKPOINT" in html
        assert "DAILY QC REQUIRED" in html
        assert "saveBtn.disabled=true;saveBtn.textContent='SAVING…'" in html
        assert "goPage('quality');renderQuality()" not in html

@pytest.mark.parametrize(
    ('group', 'test_name', 'method', 'workstation'),
    [
        ('DGA', 'Dissolved Gas Analysis (DGA)', 'IEC 60567', 'DGA'),
        ('Furan', '2-Furfural (2FAL)', 'IEC 61198', 'Furan / Passivator'),
        ('BHT', 'Antioxidant (BHT)', 'IEC 60666', 'DBDS / BHT / Toluene / PCB'),
        ('Toluene', 'Toluene', 'ASTM D5580', 'DBDS / BHT / Toluene / PCB'),
        ('DBDS', 'Dibenzyl Disulfide (DBDS)', 'IEC 62697-1', 'DBDS / BHT / Toluene / PCB'),
        ('TAN', 'Total Acid Number', 'ASTM D664', 'TAN / Peroxide / RSH / H2S'),
    ],
)
def test_named_daily_qc_examples_cover_same_context_across_batches(group, test_name, method, workstation):
    """Daily Analytical QC is test/method/equipment scoped, not batch scoped."""
    with TestClient(app):
        with SessionLocal() as db:
            user = db.scalar(select(User).where(User.email == 'technician@tsco.local')); assert user
            p = payload(user, group=group, test=test_name, method=method, workstation=workstation)
            p['qc'] = [qc('DAILY-QC', group=group, test=test_name, method=method, workstation=workstation,
                          ts='2026-10-02T05:00:00', eq=777)]
            row = {
                'id': 'R-B2', 'batch': 'B2', 'sample': 'T1',
                'test': test_name, 'display_test': test_name, 'result': '1',
                'qc_record_id': 'DAILY-QC',
            }
            proposed = deepcopy(p); proposed['results'].append(row)
            _bind_required_qc_to_result(proposed, proposed['batches'][1], row, user, db=None, site_id=None)
            assert row['qc_record_id'] == 'DAILY-QC'
            assert row['equipment_asset_id'] == 777

def test_result_actions_lock_only_during_valid_submit_and_disappear_after_completion():
    source = (Path(__file__).parents[1] / 'app' / 'lab_ops' / 'index_template.html').read_text()
    assert "const dgaDone=CFG.dgaComponents.every(c=>!!getResult(s,'DGA:'+c.key))" in source
    assert "dgaDone?'<span class=\"badge ok\">RESULTS SAVED</span>'" in source
    # Validation must occur before disabling the action; invalid input must not strand a dead button.
    water_validate = source.index("if(numericValue(wv)===null)return alert('Enter a valid Water @RT value.')")
    water_lock = source.index("saveBtn.disabled=true;saveBtn.textContent='SAVING…'", water_validate)
    assert water_validate < water_lock
    multi_validate = source.index("if(inputs.some(i=>!i.value.trim()))return alert(kind==='FURAN'?")
    multi_lock = source.index("saveBtn.disabled=true;saveBtn.textContent='SAVING…'", multi_validate)
    assert multi_validate < multi_lock
