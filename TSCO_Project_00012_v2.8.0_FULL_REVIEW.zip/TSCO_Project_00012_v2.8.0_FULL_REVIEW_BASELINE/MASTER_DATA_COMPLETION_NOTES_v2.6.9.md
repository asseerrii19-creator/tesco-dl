# Master Data Completion Notes — v2.6.9

This file records test-catalog items for which the packaged source material does not contain an approved method/standard. No ASTM/IEC/UOP method has been invented to fill these fields. The Administration master-data workflow can update them without a source-code change once the laboratory supplies the approved controlled method.

## Non-blocking aggregate/input labels

- `Dissolved Gas Analysis (DGA)` — aggregate workflow label; detailed gas/result handling is implemented separately. Confirm the controlled DGA method at site configuration before production use if the aggregate row must display it.
- `Transformer Oil Temperature` — calculation/input condition, not treated here as an independent analytical method.

## Analytical / special-test rows requiring controlled method confirmation before activation

- `Air Release` — present in: GEN_FULL
- `Demusibility Test` — present in: GEN_FULL
- `Ferrography` — present in: GEN_FULL
- `Fingerprint` — present in: GEN_FULL
- `Foaming Test` — present in: GEN_FULL
- `Gassing Tendancy` — present in: GEN_FULL
- `Insulable Contamination` — present in: GEN_FULL
- `Metals` — present in: ARM_FULL, ARM_TCA, GEN_FULL
- `Methanol` — present in: GEN_FULL
- `Oxidation Satbility` — present in: GEN_FULL
- `Oxidation Stability (RPVOT)` — present in: GEN_FULL
- `Polycyclo aromatics PCA` — present in: GEN_FULL
- `Rams-Bottom Carbon Residue` — present in: GEN_FULL
- `Refractive Index` — present in: GEN_FULL
- `Ruller Test` — present in: GEN_FULL
- `Rust Prevention Test` — present in: GEN_FULL
- `SF6` — present in: GEN_FULL
- `Total Base Number` — present in: GEN_FULL
- `Total Sulfur Content` — present in: GEN_FULL
- `Varnish Test (MPC)` — present in: GEN_FULL
- `Viscosity Index` — present in: GEN_FULL

## Control rule

An unspecified method is a **master-data completion item**, not permission for the system to choose a standard automatically. Before a listed test is used in controlled production work, the approved laboratory Method/SOP should be entered and linked through Administration / Controlled Documents.
