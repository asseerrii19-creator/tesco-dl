"""add controlled document workstation and test links

Revision ID: d9f6a1b2c3d4
Revises: c8e6f5a42b11
"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = "d9f6a1b2c3d4"
down_revision: Union[str, Sequence[str], None] = "c8e6f5a42b11"
branch_labels = None
depends_on = None

def upgrade() -> None:
    op.add_column("controlled_documents", sa.Column("workstation", sa.String(length=120), nullable=False, server_default=""))
    op.add_column("controlled_documents", sa.Column("test_name", sa.String(length=220), nullable=False, server_default=""))
    op.create_index(op.f("ix_controlled_documents_workstation"), "controlled_documents", ["workstation"], unique=False)
    op.create_index(op.f("ix_controlled_documents_test_name"), "controlled_documents", ["test_name"], unique=False)

def downgrade() -> None:
    op.drop_index(op.f("ix_controlled_documents_test_name"), table_name="controlled_documents")
    op.drop_index(op.f("ix_controlled_documents_workstation"), table_name="controlled_documents")
    op.drop_column("controlled_documents", "test_name")
    op.drop_column("controlled_documents", "workstation")
