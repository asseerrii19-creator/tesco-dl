"""add continuous improvement register

Revision ID: a84c2e91d5b7
Revises: f32a9b7c1d20
"""
from alembic import op
import sqlalchemy as sa

revision = "a84c2e91d5b7"
down_revision = "f32a9b7c1d20"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "improvement_items",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("code", sa.String(40), nullable=False, unique=True),
        sa.Column("site_id", sa.Integer(), sa.ForeignKey("sites.id"), nullable=True),
        sa.Column("department_id", sa.Integer(), sa.ForeignKey("departments.id"), nullable=True),
        sa.Column("created_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("owner_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("title", sa.String(220), nullable=False),
        sa.Column("problem_statement", sa.Text(), nullable=True),
        sa.Column("category", sa.String(60), nullable=True),
        sa.Column("source", sa.String(60), nullable=True),
        sa.Column("priority", sa.String(20), nullable=True),
        sa.Column("impact_area", sa.String(120), nullable=True),
        sa.Column("expected_benefit", sa.Text(), nullable=True),
        sa.Column("action_plan", sa.Text(), nullable=True),
        sa.Column("baseline_metric", sa.String(120), nullable=True),
        sa.Column("baseline_value", sa.String(80), nullable=True),
        sa.Column("target_value", sa.String(80), nullable=True),
        sa.Column("metric_unit", sa.String(40), nullable=True),
        sa.Column("status", sa.String(40), nullable=False, server_default="SUBMITTED"),
        sa.Column("due_at", sa.DateTime(), nullable=True),
        sa.Column("result_summary", sa.Text(), nullable=True),
        sa.Column("evidence_reference", sa.String(300), nullable=True),
        sa.Column("approved_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.Column("closed_at", sa.DateTime(), nullable=True),
    )
    for column in ["code", "site_id", "department_id", "created_by_id", "owner_id", "title", "category", "source", "priority", "status", "due_at", "created_at"]:
        op.create_index(f"ix_improvement_items_{column}", "improvement_items", [column])

    op.create_table(
        "improvement_activities",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("improvement_item_id", sa.Integer(), sa.ForeignKey("improvement_items.id"), nullable=False),
        sa.Column("actor_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("action", sa.String(60), nullable=False),
        sa.Column("note", sa.Text(), nullable=True),
        sa.Column("status_snapshot", sa.String(40), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    for column in ["improvement_item_id", "actor_id", "action", "created_at"]:
        op.create_index(f"ix_improvement_activities_{column}", "improvement_activities", [column])


def downgrade():
    op.drop_table("improvement_activities")
    op.drop_table("improvement_items")
