"""add resample assignment link

Revision ID: 7a1c2d3e4f50
Revises: 3d5a83b7c901
Create Date: 2026-09-02
"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = "7a1c2d3e4f50"
down_revision: Union[str, Sequence[str], None] = "3d5a83b7c901"
branch_labels = None
depends_on = None

def upgrade() -> None:
    with op.batch_alter_table("sampling_assignments") as batch_op:
        batch_op.add_column(sa.Column("resample_of_sample_id", sa.Integer(), nullable=True))
        batch_op.create_foreign_key("fk_assignment_resample_source", "sample_requests", ["resample_of_sample_id"], ["id"])
    op.create_index("ix_sampling_assignments_resample_of_sample_id", "sampling_assignments", ["resample_of_sample_id"], unique=True)

def downgrade() -> None:
    op.drop_index("ix_sampling_assignments_resample_of_sample_id", table_name="sampling_assignments")
    with op.batch_alter_table("sampling_assignments") as batch_op:
        batch_op.drop_constraint("fk_assignment_resample_source", type_="foreignkey")
        batch_op.drop_column("resample_of_sample_id")
