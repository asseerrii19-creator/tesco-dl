"""align intake/distribution, sampling requests and quality audit scope

Revision ID: c8e6f5a42b11
Revises: 7a1c2d3e4f50
Create Date: 2026-09-03
"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = "c8e6f5a42b11"
down_revision: Union[str, Sequence[str], None] = "7a1c2d3e4f50"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Direct client-delivered samples may not have an electronic field sampler account.
    with op.batch_alter_table("sample_requests") as batch_op:
        batch_op.alter_column("sampler_id", existing_type=sa.Integer(), nullable=True)

    # Site-scoped read-only audit visibility for Quality / Technical Management.
    with op.batch_alter_table("audit_logs") as batch_op:
        batch_op.add_column(sa.Column("site_id", sa.Integer(), nullable=True))
        batch_op.create_foreign_key("fk_audit_logs_site", "sites", ["site_id"], ["id"])
    op.create_index("ix_audit_logs_site_id", "audit_logs", ["site_id"])

    # Sampling Supervision can raise a request; Operations converts it into the official Sampling Order.
    op.create_table(
        "sampling_request_notices",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("request_code", sa.String(50), nullable=False),
        sa.Column("site_id", sa.Integer(), nullable=False),
        sa.Column("client_id", sa.Integer(), nullable=False),
        sa.Column("requested_by_id", sa.Integer(), nullable=False),
        sa.Column("title", sa.String(200), nullable=False),
        sa.Column("priority", sa.String(30), nullable=False),
        sa.Column("expected_samples", sa.Integer(), nullable=False),
        sa.Column("target_sampling_at", sa.DateTime(), nullable=True),
        sa.Column("notes", sa.Text(), nullable=False),
        sa.Column("status", sa.String(30), nullable=False),
        sa.Column("converted_order_id", sa.Integer(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("converted_at", sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(["site_id"], ["sites.id"]),
        sa.ForeignKeyConstraint(["client_id"], ["clients.id"]),
        sa.ForeignKeyConstraint(["requested_by_id"], ["users.id"]),
        sa.ForeignKeyConstraint(["converted_order_id"], ["sampling_orders.id"]),
        sa.UniqueConstraint("request_code", name="uq_sampling_request_notice_code"),
    )
    for ix, col in [
        ("ix_sampling_request_notices_request_code", "request_code"),
        ("ix_sampling_request_notices_site_id", "site_id"),
        ("ix_sampling_request_notices_client_id", "client_id"),
        ("ix_sampling_request_notices_requested_by_id", "requested_by_id"),
        ("ix_sampling_request_notices_status", "status"),
        ("ix_sampling_request_notices_converted_order_id", "converted_order_id"),
    ]:
        op.create_index(ix, "sampling_request_notices", [col])


def downgrade() -> None:
    for ix in [
        "ix_sampling_request_notices_converted_order_id",
        "ix_sampling_request_notices_status",
        "ix_sampling_request_notices_requested_by_id",
        "ix_sampling_request_notices_client_id",
        "ix_sampling_request_notices_site_id",
        "ix_sampling_request_notices_request_code",
    ]:
        op.drop_index(ix, table_name="sampling_request_notices")
    op.drop_table("sampling_request_notices")

    op.drop_index("ix_audit_logs_site_id", table_name="audit_logs")
    with op.batch_alter_table("audit_logs") as batch_op:
        batch_op.drop_constraint("fk_audit_logs_site", type_="foreignkey")
        batch_op.drop_column("site_id")

    with op.batch_alter_table("sample_requests") as batch_op:
        batch_op.alter_column("sampler_id", existing_type=sa.Integer(), nullable=False)
