"""Project 00012 enterprise closeout modules

Revision ID: f32a9b7c1d20
Revises: e21f7c8d9a01
"""
from alembic import op
import sqlalchemy as sa

revision = 'f32a9b7c1d20'
down_revision = 'e21f7c8d9a01'
branch_labels = None
depends_on = None


def upgrade():
    for name, typ in [
        ('hv_voltage_kv', sa.Float()), ('lv_voltage_kv', sa.Float()),
        ('sealing_system', sa.String(100)), ('cooling_type', sa.String(100)),
        ('manufacturer_country', sa.String(100)), ('manufacture_year', sa.Integer()),
        ('oil_type', sa.String(120)), ('oil_weight_kg', sa.Float()), ('owner_name', sa.String(180)),
        ('tap_changer_type', sa.String(100)), ('tap_changer_chamber', sa.String(100)),
        ('tag_number', sa.String(100)), ('phase', sa.String(40)), ('operating_period', sa.String(100)),
        ('sampling_points_json', sa.Text()),
    ]:
        op.add_column('assets', sa.Column(name, typ, nullable=True))
    for name, typ in [
        ('sample_origin', sa.String(50)), ('priority', sa.String(20)), ('required_tat', sa.String(30)),
        ('due_at', sa.DateTime()), ('equipment_status', sa.String(80)), ('sampling_reason', sa.String(180)),
        ('work_order_number', sa.String(100)), ('sap_number', sa.String(100)),
    ]:
        op.add_column('sample_requests', sa.Column(name, typ, nullable=True))
    op.create_index('ix_sample_requests_sample_origin','sample_requests',['sample_origin'])
    op.create_index('ix_sample_requests_priority','sample_requests',['priority'])
    op.create_index('ix_sample_requests_due_at','sample_requests',['due_at'])

    op.create_table('equipment_assets',
        sa.Column('id',sa.Integer(),primary_key=True), sa.Column('site_id',sa.Integer(),sa.ForeignKey('sites.id'),nullable=False),
        sa.Column('equipment_id',sa.String(40),nullable=False), sa.Column('name',sa.String(180),nullable=False),
        sa.Column('manufacturer',sa.String(120)), sa.Column('model',sa.String(120)), sa.Column('serial_number',sa.String(120)),
        sa.Column('workstation',sa.String(120)), sa.Column('test_method',sa.String(180)), sa.Column('status',sa.String(30)),
        sa.Column('calibration_provider',sa.String(180)), sa.Column('calibration_certificate',sa.String(180)),
        sa.Column('last_calibration_at',sa.DateTime()), sa.Column('next_calibration_at',sa.DateTime()),
        sa.Column('last_verification_at',sa.DateTime()), sa.Column('next_verification_at',sa.DateTime()),
        sa.Column('notes',sa.Text()), sa.Column('active',sa.Boolean()), sa.Column('created_at',sa.DateTime()), sa.Column('updated_at',sa.DateTime()),
        sa.UniqueConstraint('site_id','equipment_id',name='uq_equipment_site_id'))
    op.create_index('ix_equipment_assets_site_id','equipment_assets',['site_id']); op.create_index('ix_equipment_assets_equipment_id','equipment_assets',['equipment_id']); op.create_index('ix_equipment_assets_status','equipment_assets',['status']); op.create_index('ix_equipment_assets_workstation','equipment_assets',['workstation']); op.create_index('ix_equipment_assets_next_calibration_at','equipment_assets',['next_calibration_at']); op.create_index('ix_equipment_assets_active','equipment_assets',['active'])

    op.create_table('equipment_events',
        sa.Column('id',sa.Integer(),primary_key=True), sa.Column('equipment_asset_id',sa.Integer(),sa.ForeignKey('equipment_assets.id'),nullable=False),
        sa.Column('event_type',sa.String(40),nullable=False), sa.Column('status',sa.String(30)), sa.Column('result',sa.String(80)), sa.Column('details',sa.Text()),
        sa.Column('certificate_reference',sa.String(180)), sa.Column('performed_by_id',sa.Integer(),sa.ForeignKey('users.id')),
        sa.Column('event_at',sa.DateTime()), sa.Column('next_due_at',sa.DateTime()))
    op.create_index('ix_equipment_events_equipment_asset_id','equipment_events',['equipment_asset_id']); op.create_index('ix_equipment_events_event_type','equipment_events',['event_type']); op.create_index('ix_equipment_events_status','equipment_events',['status']); op.create_index('ix_equipment_events_event_at','equipment_events',['event_at'])

    op.create_table('competency_records',
        sa.Column('id',sa.Integer(),primary_key=True), sa.Column('site_id',sa.Integer(),sa.ForeignKey('sites.id'),nullable=False), sa.Column('user_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False),
        sa.Column('test_name',sa.String(180),nullable=False), sa.Column('method_name',sa.String(180)), sa.Column('workstation',sa.String(120)), sa.Column('category',sa.Integer()),
        sa.Column('technical_score',sa.Float()), sa.Column('data_processing_score',sa.Float()), sa.Column('overall_score',sa.Float()), sa.Column('authorization',sa.String(30)),
        sa.Column('effective_at',sa.DateTime()), sa.Column('expires_at',sa.DateTime()), sa.Column('evaluated_by_id',sa.Integer(),sa.ForeignKey('users.id')),
        sa.Column('evidence_reference',sa.String(240)), sa.Column('notes',sa.Text()), sa.Column('active',sa.Boolean()), sa.Column('created_at',sa.DateTime()))
    for c in ['site_id','user_id','test_name','method_name','workstation','authorization','active']: op.create_index(f'ix_competency_records_{c}','competency_records',[c])

    op.create_table('quality_cases',
        sa.Column('id',sa.Integer(),primary_key=True), sa.Column('site_id',sa.Integer(),sa.ForeignKey('sites.id'),nullable=False), sa.Column('case_number',sa.String(60),nullable=False,unique=True),
        sa.Column('case_type',sa.String(40),nullable=False), sa.Column('title',sa.String(220),nullable=False), sa.Column('test_name',sa.String(180)), sa.Column('method_name',sa.String(180)),
        sa.Column('equipment_asset_id',sa.Integer(),sa.ForeignKey('equipment_assets.id')), sa.Column('assigned_to_id',sa.Integer(),sa.ForeignKey('users.id')),
        sa.Column('status',sa.String(40)), sa.Column('priority',sa.String(20)), sa.Column('due_at',sa.DateTime()), sa.Column('protocol_json',sa.Text()), sa.Column('raw_runs_json',sa.Text()),
        sa.Column('calculation_json',sa.Text()), sa.Column('root_cause',sa.Text()), sa.Column('corrective_action',sa.Text()), sa.Column('effectiveness_review',sa.Text()),
        sa.Column('scheme_name',sa.String(180)), sa.Column('evaluation_criteria',sa.Text()), sa.Column('evidence_reference',sa.String(240)),
        sa.Column('created_by_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False), sa.Column('reviewed_by_id',sa.Integer(),sa.ForeignKey('users.id')),
        sa.Column('closed_at',sa.DateTime()), sa.Column('created_at',sa.DateTime()), sa.Column('updated_at',sa.DateTime()))
    for c in ['site_id','case_number','case_type','test_name','equipment_asset_id','assigned_to_id','status','due_at','created_at']: op.create_index(f'ix_quality_cases_{c}','quality_cases',[c])

    op.create_table('staff_availability',
        sa.Column('id',sa.Integer(),primary_key=True), sa.Column('site_id',sa.Integer(),sa.ForeignKey('sites.id'),nullable=False), sa.Column('user_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False),
        sa.Column('entry_type',sa.String(30),nullable=False), sa.Column('start_at',sa.DateTime(),nullable=False), sa.Column('end_at',sa.DateTime(),nullable=False), sa.Column('status',sa.String(40)),
        sa.Column('shift_code',sa.String(40)), sa.Column('notes',sa.Text()), sa.Column('approved_by_id',sa.Integer(),sa.ForeignKey('users.id')), sa.Column('created_by_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False), sa.Column('created_at',sa.DateTime()))
    for c in ['site_id','user_id','entry_type','start_at','end_at','status']: op.create_index(f'ix_staff_availability_{c}','staff_availability',[c])

    op.create_table('evidence_records',
        sa.Column('id',sa.Integer(),primary_key=True), sa.Column('site_id',sa.Integer(),sa.ForeignKey('sites.id'),nullable=False), sa.Column('sample_request_id',sa.Integer(),sa.ForeignKey('sample_requests.id')),
        sa.Column('quality_case_id',sa.Integer(),sa.ForeignKey('quality_cases.id')), sa.Column('equipment_asset_id',sa.Integer(),sa.ForeignKey('equipment_assets.id')), sa.Column('evidence_type',sa.String(50),nullable=False),
        sa.Column('title',sa.String(220),nullable=False), sa.Column('original_filename',sa.String(240)), sa.Column('stored_path',sa.String(500)), sa.Column('sha256',sa.String(64)), sa.Column('method_name',sa.String(180)),
        sa.Column('equipment_id_snapshot',sa.String(40)), sa.Column('run_reference',sa.String(100)), sa.Column('parsed_json',sa.Text()), sa.Column('revision',sa.Integer()), sa.Column('status',sa.String(30)), sa.Column('uploaded_by_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False), sa.Column('created_at',sa.DateTime()))
    for c in ['site_id','sample_request_id','quality_case_id','equipment_asset_id','evidence_type','created_at']: op.create_index(f'ix_evidence_records_{c}','evidence_records',[c])

    op.create_table('asset_history_events',
        sa.Column('id',sa.Integer(),primary_key=True), sa.Column('asset_id',sa.Integer(),sa.ForeignKey('assets.id'),nullable=False), sa.Column('event_type',sa.String(60),nullable=False),
        sa.Column('event_at',sa.DateTime(),nullable=False), sa.Column('report_number',sa.String(80)), sa.Column('details',sa.Text()), sa.Column('created_by_id',sa.Integer(),sa.ForeignKey('users.id')), sa.Column('created_at',sa.DateTime()))
    op.create_index('ix_asset_history_events_asset_id','asset_history_events',['asset_id']); op.create_index('ix_asset_history_events_event_type','asset_history_events',['event_type']); op.create_index('ix_asset_history_events_event_at','asset_history_events',['event_at'])

    op.create_table('technical_result_rules',
        sa.Column('id',sa.Integer(),primary_key=True), sa.Column('site_id',sa.Integer(),sa.ForeignKey('sites.id')), sa.Column('test_name',sa.String(180),nullable=False), sa.Column('method_name',sa.String(180)),
        sa.Column('result_field',sa.String(180),nullable=False), sa.Column('unit',sa.String(60)), sa.Column('equipment_id',sa.String(40)), sa.Column('allowed_states',sa.String(120)),
        sa.Column('detection_limit',sa.Float()), sa.Column('working_range_min',sa.Float()), sa.Column('working_range_max',sa.Float()), sa.Column('decimals',sa.Integer()), sa.Column('rounding_rule',sa.String(40)),
        sa.Column('report_display_rule',sa.String(240)), sa.Column('downstream_rule',sa.Text()), sa.Column('source_reference',sa.String(240)), sa.Column('effective_revision',sa.String(40)), sa.Column('status',sa.String(30)), sa.Column('created_at',sa.DateTime()),
        sa.UniqueConstraint('site_id','test_name','method_name','result_field','equipment_id',name='uq_result_rule_scope'))
    for c in ['site_id','test_name','method_name','result_field','status']: op.create_index(f'ix_technical_result_rules_{c}','technical_result_rules',[c])

    op.create_table('troubleshooting_records',
        sa.Column('id',sa.Integer(),primary_key=True), sa.Column('site_id',sa.Integer(),sa.ForeignKey('sites.id'),nullable=False), sa.Column('test_name',sa.String(180)), sa.Column('method_name',sa.String(180)),
        sa.Column('equipment_asset_id',sa.Integer(),sa.ForeignKey('equipment_assets.id')), sa.Column('workstation',sa.String(120)), sa.Column('problem',sa.Text(),nullable=False), sa.Column('symptoms',sa.Text()),
        sa.Column('root_cause',sa.Text()), sa.Column('actions_taken',sa.Text()), sa.Column('safety_impact',sa.Text()), sa.Column('result_integrity_impact',sa.Text()), sa.Column('lessons',sa.Text()),
        sa.Column('status',sa.String(40)), sa.Column('created_by_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False), sa.Column('senior_verified_by_id',sa.Integer(),sa.ForeignKey('users.id')), sa.Column('technical_approved_by_id',sa.Integer(),sa.ForeignKey('users.id')), sa.Column('created_at',sa.DateTime()), sa.Column('updated_at',sa.DateTime()))
    for c in ['site_id','test_name','status']: op.create_index(f'ix_troubleshooting_records_{c}','troubleshooting_records',[c])

    op.create_table('controlled_reports',
        sa.Column('id',sa.Integer(),primary_key=True), sa.Column('site_id',sa.Integer(),sa.ForeignKey('sites.id'),nullable=False), sa.Column('sample_request_id',sa.Integer(),sa.ForeignKey('sample_requests.id'),nullable=False),
        sa.Column('report_number',sa.String(80),nullable=False,unique=True), sa.Column('revision',sa.Integer()), sa.Column('status',sa.String(40)), sa.Column('condition_status',sa.String(30)),
        sa.Column('interpretation',sa.Text()), sa.Column('recommendation',sa.Text()), sa.Column('report_payload_json',sa.Text()), sa.Column('qr_token',sa.String(100),nullable=False,unique=True),
        sa.Column('reviewed_by_id',sa.Integer(),sa.ForeignKey('users.id')), sa.Column('approved_by_id',sa.Integer(),sa.ForeignKey('users.id')), sa.Column('lms_reference',sa.String(120)), sa.Column('created_at',sa.DateTime()), sa.Column('approved_at',sa.DateTime()))
    for c in ['site_id','sample_request_id','report_number','status','qr_token']: op.create_index(f'ix_controlled_reports_{c}','controlled_reports',[c])

    op.create_table('notifications',
        sa.Column('id',sa.Integer(),primary_key=True), sa.Column('site_id',sa.Integer(),sa.ForeignKey('sites.id')), sa.Column('user_id',sa.Integer(),sa.ForeignKey('users.id'),nullable=False),
        sa.Column('category',sa.String(40)), sa.Column('title',sa.String(220),nullable=False), sa.Column('message',sa.Text()), sa.Column('target_url',sa.String(300)), sa.Column('priority',sa.String(20)),
        sa.Column('read_at',sa.DateTime()), sa.Column('email_status',sa.String(30)), sa.Column('created_at',sa.DateTime()))
    for c in ['site_id','user_id','category','created_at']: op.create_index(f'ix_notifications_{c}','notifications',[c])


def downgrade():
    for table in ['notifications','controlled_reports','troubleshooting_records','technical_result_rules','asset_history_events','evidence_records','staff_availability','quality_cases','competency_records','equipment_events','equipment_assets']:
        op.drop_table(table)
    for idx in ['ix_sample_requests_due_at','ix_sample_requests_priority','ix_sample_requests_sample_origin']:
        op.drop_index(idx, table_name='sample_requests')
    for col in ['sap_number','work_order_number','sampling_reason','equipment_status','due_at','required_tat','priority','sample_origin']:
        op.drop_column('sample_requests',col)
    for col in ['sampling_points_json','operating_period','phase','tag_number','tap_changer_chamber','tap_changer_type','owner_name','oil_weight_kg','oil_type','manufacture_year','manufacturer_country','cooling_type','sealing_system','lv_voltage_kv','hv_voltage_kv']:
        op.drop_column('assets',col)
