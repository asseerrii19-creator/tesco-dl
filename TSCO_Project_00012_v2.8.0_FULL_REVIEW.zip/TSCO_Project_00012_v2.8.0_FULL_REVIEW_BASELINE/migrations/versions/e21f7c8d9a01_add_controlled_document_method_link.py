"""add controlled document method link

Revision ID: e21f7c8d9a01
Revises: d9f6a1b2c3d4
"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = "e21f7c8d9a01"
down_revision: Union[str, Sequence[str], None] = "d9f6a1b2c3d4"
branch_labels = None
depends_on = None

def upgrade() -> None:
    op.add_column("controlled_documents", sa.Column("method_name", sa.String(length=160), nullable=False, server_default=""))
    op.create_index(op.f("ix_controlled_documents_method_name"), "controlled_documents", ["method_name"], unique=False)

def downgrade() -> None:
    op.drop_index(op.f("ix_controlled_documents_method_name"), table_name="controlled_documents")
    op.drop_column("controlled_documents", "method_name")
