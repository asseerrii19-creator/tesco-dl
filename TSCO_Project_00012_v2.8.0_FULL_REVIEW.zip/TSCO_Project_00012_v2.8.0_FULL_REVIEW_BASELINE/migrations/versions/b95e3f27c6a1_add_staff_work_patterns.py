"""add configurable staff work patterns

Revision ID: b95e3f27c6a1
Revises: a84c2e91d5b7
"""
from alembic import op
import sqlalchemy as sa

revision = "b95e3f27c6a1"
down_revision = "a84c2e91d5b7"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "staff_work_patterns",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("site_id", sa.Integer(), sa.ForeignKey("sites.id"), nullable=False),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("weekdays_json", sa.Text(), nullable=False),
        sa.Column("shift_start", sa.String(5), nullable=False),
        sa.Column("shift_end", sa.String(5), nullable=False),
        sa.Column("effective_from", sa.DateTime(), nullable=True),
        sa.Column("effective_to", sa.DateTime(), nullable=True),
        sa.Column("active", sa.Boolean(), nullable=False),
        sa.Column("created_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("site_id", "user_id", name="uq_staff_work_pattern_user_site"),
    )
    for col in ["site_id", "user_id", "active", "created_by_id"]:
        op.create_index(f"ix_staff_work_patterns_{col}", "staff_work_patterns", [col])


def downgrade():
    op.drop_table("staff_work_patterns")
