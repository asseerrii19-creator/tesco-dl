"""add identifier sequences

Revision ID: 3d5a83b7c901
Revises: b71d9a2e7f60
Create Date: 2026-09-02
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "3d5a83b7c901"
down_revision: Union[str, Sequence[str], None] = "b71d9a2e7f60"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "identifier_sequences",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("namespace", sa.String(length=40), nullable=False),
        sa.Column("site_id", sa.Integer(), nullable=False),
        sa.Column("year", sa.String(length=4), nullable=False),
        sa.Column("current_value", sa.Integer(), nullable=False),
        sa.ForeignKeyConstraint(["site_id"], ["sites.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("namespace", "site_id", "year", name="uq_identifier_sequence_scope"),
    )
    op.create_index(op.f("ix_identifier_sequences_namespace"), "identifier_sequences", ["namespace"], unique=False)
    op.create_index(op.f("ix_identifier_sequences_site_id"), "identifier_sequences", ["site_id"], unique=False)
    op.create_index(op.f("ix_identifier_sequences_year"), "identifier_sequences", ["year"], unique=False)


def downgrade() -> None:
    op.drop_index(op.f("ix_identifier_sequences_year"), table_name="identifier_sequences")
    op.drop_index(op.f("ix_identifier_sequences_site_id"), table_name="identifier_sequences")
    op.drop_index(op.f("ix_identifier_sequences_namespace"), table_name="identifier_sequences")
    op.drop_table("identifier_sequences")
