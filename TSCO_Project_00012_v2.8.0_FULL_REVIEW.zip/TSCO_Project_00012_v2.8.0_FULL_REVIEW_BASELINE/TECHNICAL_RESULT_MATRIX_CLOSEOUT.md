# Technical Result Matrix — Closeout Rules

## Global result-state rule

- Canonical reporting state: **LTD — Less Than Detection**.
- New entries `LDT` or `LDL` are normalized to `LTD` at the application boundary; historical controlled source files are not rewritten.
- `LTD` is not zero, null, or a numeric result.
- Numeric values below a **confirmed laboratory Detection Limit (DL)** are normalized to LTD.
- A threshold is never invented for a method/test that does not have a confirmed laboratory DL in the supplied controlled material.

## Confirmed detection-limit rules from current TSCO Analysis Report

| Result field | Method/context | Unit | Confirmed DL | Platform behavior |
|---|---|---:|---:|---|
| 2-Furfural (2FAL) | IEC 61198 / Furan | mg/kg | **0.01** | `<0.01` → LTD |
| Total Acid Number | Current Analysis Report | mg KOH/g | **0.010** | `<0.010` → LTD |
| DGA H2 | DGA report | ppm | **1** | `<1` → LTD |
| DGA CH4 | DGA report | ppm | **1** | `<1` → LTD |
| DGA C2H4 | DGA report | ppm | **1** | `<1` → LTD |
| DGA C2H6 | DGA report | ppm | **1** | `<1` → LTD |
| DGA C2H2 | DGA report | ppm | **1** | `<1` → LTD |
| DGA CO | DGA report | ppm | **1** | `<1` → LTD |
| DGA CO2 | DGA report | ppm | **1** | `<1` → LTD |
| DGA O2 / N2 | Report shows no DL | ppm | — | No invented LTD threshold |

## Furan controlled derived-output rule

When 2FAL is LTD under the current report rule:

- `2FAL = LTD`
- `Total Furanic Compounds = LTD`
- `Indirect DP = >1000`
- `Paper Lifetime Remaining = >30 Years`

For numeric Furan results, the precise calculated value is retained internally. Paper-life display is rounded to a whole year using half-up reporting: `.5` and above rounds upward.

## Field-level formatting principle

Every result field is controlled by:

`Test + Method + Result Field + Unit + Allowed State + DL (if applicable) + Decimal/Significant-Figure Rule + Calculation Dependency + Report Display Rule + Effective Revision`

The framework is implemented as the relational `TechnicalResultRule` register and is editable by Quality/Technical Manager during review. Confirmed DLs are pre-seeded. Fields whose supplied controlled source does not support an exact DL/range/precision remain intentionally blank/source-controlled rather than guessed; they can be completed without code changes when Quality confirms them.
