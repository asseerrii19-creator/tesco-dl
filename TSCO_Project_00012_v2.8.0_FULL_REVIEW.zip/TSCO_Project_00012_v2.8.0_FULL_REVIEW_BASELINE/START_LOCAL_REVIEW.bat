@echo off
setlocal
cd /d %~dp0
where py >nul 2>nul
if %errorlevel%==0 (set PYTHON=py) else (set PYTHON=python)
if not exist .venv (%PYTHON% -m venv .venv)
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt
set APP_ENV=development
if not defined APP_SECRET for /f "delims=" %%i in ('python -c "import secrets; print(secrets.token_urlsafe(48))"') do set APP_SECRET=%%i
if not defined DATABASE_URL set DATABASE_URL=sqlite:///./app/data/tsco_platform.db
if not defined SEED_DEMO_DATA set SEED_DEMO_DATA=true
set SHOW_DEMO_ACCOUNTS=false
if not defined BOOTSTRAP_ADMIN_EMAIL set BOOTSTRAP_ADMIN_EMAIL=admin@tsco.local
if not defined BOOTSTRAP_ADMIN_NAME set BOOTSTRAP_ADMIN_NAME=System Administrator
if not defined LOCAL_REVIEW_PASSWORD for /f "delims=" %%i in ('python -c "import secrets; print(secrets.token_urlsafe(18))"') do set LOCAL_REVIEW_PASSWORD=%%i
if not defined BOOTSTRAP_ADMIN_PASSWORD set BOOTSTRAP_ADMIN_PASSWORD=%LOCAL_REVIEW_PASSWORD%
if not defined DEMO_USER_PASSWORD set DEMO_USER_PASSWORD=%LOCAL_REVIEW_PASSWORD%
set REQUIRE_BOOTSTRAP_PASSWORD_CHANGE=false
set LMS_MODE=mock
set ENABLE_API_DOCS=true
echo.
echo Local review credentials (generated for this run)
echo   Email: %BOOTSTRAP_ADMIN_EMAIL%
echo   Password: %LOCAL_REVIEW_PASSWORD%
echo.
start "" http://127.0.0.1:8000
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
endlocal
