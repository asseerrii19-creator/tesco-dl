from app.services.lab_operations import (
    _normalize_result_state,
    _numeric_result,
    _round_half_up_int,
    _validate_calculated_result,
    _normalize_result_for_test,
    _confirmed_detection_limit,
)


def _furan_payload(source_result: str):
    return {
        "results": [
            {"id": "R1", "sample": "DM-26000001", "test": "FURAN:2FAL", "result": source_result}
        ]
    }


def _batch():
    return {"id": "B1", "samples": ["DM-26000001"], "tests": [{"test": "Furanic Compounds"}]}


def test_detection_state_is_normalized_to_tsco_ltd():
    assert _normalize_result_state("LTD") == "LTD"
    assert _normalize_result_state("ldt") == "LTD"
    assert _normalize_result_state("LDL") == "LTD"
    assert _numeric_result("LTD") is None


def test_furan_ltd_requires_fixed_report_outputs():
    payload = _furan_payload("LTD")
    _validate_calculated_result(
        payload,
        _batch(),
        {"sample": "DM-26000001", "test": "FURAN_CALC:TOTAL", "result": "LTD", "calculated": True},
    )
    _validate_calculated_result(
        payload,
        _batch(),
        {"sample": "DM-26000001", "test": "FURAN_CALC:INDIRECT_DP", "result": ">1000", "calculated": True},
    )
    _validate_calculated_result(
        payload,
        _batch(),
        {"sample": "DM-26000001", "test": "FURAN_CALC:PAPER_LIFE", "result": ">30", "calculated": True},
    )


def test_paper_life_rounding_is_half_up_to_whole_year():
    assert _round_half_up_int(27.49) == 27
    assert _round_half_up_int(27.50) == 28
    assert _round_half_up_int(27.99) == 28


def test_confirmed_detection_limits_and_below_dl_normalization():
    assert _confirmed_detection_limit("FURAN:2FAL") == 0.01
    assert _confirmed_detection_limit("Total Acid Number") == 0.010
    assert _confirmed_detection_limit("DGA:C2H2") == 1.0
    assert _normalize_result_for_test("FURAN:2FAL", "2-Furfural (2FAL)", "0.009") == "LTD"
    assert _normalize_result_for_test("Total Acid Number", "", "0.009") == "LTD"
    assert _normalize_result_for_test("DGA:C2H2", "Acetylene (C2H2)", "0.5") == "LTD"
    assert _normalize_result_for_test("DGA:C2H2", "Acetylene (C2H2)", "1") == "1"


def test_unconfirmed_test_does_not_invent_detection_limit():
    assert _confirmed_detection_limit("Water Content KF @RT") is None
    assert _normalize_result_for_test("Water Content KF @RT", "", "0.1") == "0.1"
