from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.lab_sections import LAB_ROLE_SECTIONS
from app.models import Client, Quotation, Role


def test_retained_samples_is_consistent_for_quality_role():
    with TestClient(app) as client:
        login = client.post('/login/employee', data={'email': 'quality@tsco.local', 'password': 'Demo123!'})
        assert login.status_code in {200, 303}
        wrapper = client.get('/lab/operations?section=retained')
        assert wrapper.status_code == 200
        assert 'Retained Samples' in wrapper.text
        embedded = client.get('/lab/operations/app?embed=1&section=retained')
        assert embedded.status_code == 200
        assert 'window.TSCO_PLATFORM_SECTION="retained"' in embedded.text
        assert 'retained' in LAB_ROLE_SECTIONS[Role.QUALITY.value]
        assert 'window.TSCO_PLATFORM_ALLOWED_SECTIONS=' in embedded.text


def test_mismatched_quotation_returns_user_facing_validation_instead_of_500():
    with TestClient(app) as client:
        client.post('/login/employee', data={'email': 'admin@tsco.local', 'password': 'Demo123!'})
        db = SessionLocal()
        arm = db.scalar(select(Client).where(Client.code == 'ARM'))
        sec_quote = db.scalar(select(Quotation).join(Client).where(Client.code == 'SEC'))
        db.close()
        response = client.post('/operations/orders', data={
            'client_id': str(arm.id),
            'quotation_id': str(sec_quote.id),
            'purchase_order_id': '',
            'supervisor_id': '',
            'title': 'Validation test',
            'priority': 'Normal',
            'due_at': '',
            'notes': '',
        }, follow_redirects=False)
        assert response.status_code == 303
        assert 'error=' in response.headers['location']
        final = client.get(response.headers['location'])
        assert final.status_code == 200
        assert 'Quotation does not belong to the selected client' in final.text


def test_lab_sidebar_navigation_forces_requested_iframe_section():
    template = (Path(__file__).resolve().parents[1] / 'app' / 'templates' / 'lab_operations.html').read_text(encoding='utf-8')
    assert "frame.setAttribute('src',target)" in template
    assert "window.innerWidth<520" not in template
