from __future__ import annotations

from datetime import datetime
from pathlib import Path
import uuid

from fastapi.testclient import TestClient
from sqlalchemy import select, text

from app.database import SessionLocal
from app.main import app
from app.models import (
    Asset,
    Client,
    Role,
    SampleRequest,
    SampleStatus,
    Site,
    TechnicalAssessmentRecord,
    User,
)
from app.security import hash_password
from app.services.lab_operations import package_catalog


def login(client: TestClient, email: str, password: str = "Demo123!") -> None:
    response = client.post("/login", data={"email": email, "password": password}, follow_redirects=False)
    assert response.status_code == 303, (email, response.status_code, response.text[:300])


def make_sample(*, status: str = SampleStatus.SUBMITTED.value, barcode: str | None = None) -> int:
    token = uuid.uuid4().hex[:16].upper()
    with SessionLocal() as db:
        site = db.scalar(select(Site).where(Site.code == "DMM"))
        client = db.scalar(select(Client).where(Client.code == "SEC"))
        asset = db.scalar(select(Asset).where(Asset.client_id == client.id, Asset.active.is_(True)))
        sampler = db.scalar(select(User).where(User.email == "fieldman@tsco.local"))
        assert site and client and asset and sampler
        sample = SampleRequest(
            request_number=f"QA264-{token}",
            public_token=f"PUB-{token}",
            barcode_value=barcode or f"QA264-BAR-{token}",
            status=status,
            site_id=site.id,
            client_id=client.id,
            asset_id=asset.id,
            sampler_id=sampler.id,
            sample_date_time=datetime.utcnow(),
            sampling_point="Main Tank Bottom",
            requested_package="QA regression",
            container_count=1,
            submitted_at=datetime.utcnow(),
        )
        db.add(sample)
        db.commit()
        return sample.id


def test_sqlite_test_database_enforces_foreign_keys():
    with SessionLocal() as db:
        assert db.execute(text("PRAGMA foreign_keys")).scalar_one() == 1


def test_disabled_site_and_disabled_client_revoke_authentication_at_login():
    with TestClient(app) as client:
        suffix = uuid.uuid4().hex[:8]
        with SessionLocal() as db:
            disabled_site = Site(code=f"X{suffix[:6].upper()}", name="Disabled Site", laboratory_name="Disabled Lab", active=False)
            disabled_client = Client(code=f"C{suffix[:6].upper()}", name="Disabled Client", active=False)
            db.add_all([disabled_site, disabled_client])
            db.flush()
            site_user = User(
                email=f"disabled.site.{suffix}@tsco.local",
                full_name="Disabled Site User",
                password_hash=hash_password("TempPass123!"),
                role=Role.LAB_TECHNICIAN.value,
                site_id=disabled_site.id,
                active=True,
            )
            client_user = User(
                email=f"disabled.client.{suffix}@example.local",
                full_name="Disabled Client User",
                password_hash=hash_password("TempPass123!"),
                role=Role.CLIENT.value,
                client_id=disabled_client.id,
                active=True,
            )
            db.add_all([site_user, client_user])
            db.commit()
            emails = (site_user.email, client_user.email)
        for email in emails:
            denied = client.post("/login", data={"email": email, "password": "TempPass123!"}, follow_redirects=False)
            assert denied.status_code == 401
            assert "Invalid email or password" in denied.text


def test_invalid_technical_decision_is_rejected_without_state_change():
    sample_id = make_sample(status=SampleStatus.TECHNICAL_REVIEW.value)
    with TestClient(app) as client:
        login(client, "senior@tsco.local")
        response = client.post(
            f"/assessment/{sample_id}",
            data={"decision": "FORGED_DECISION", "recommendation": "must not save"},
            follow_redirects=False,
        )
        assert response.status_code == 400
    with SessionLocal() as db:
        sample = db.get(SampleRequest, sample_id)
        record = db.scalar(select(TechnicalAssessmentRecord).where(TechnicalAssessmentRecord.sample_request_id == sample_id))
        assert sample.status == SampleStatus.TECHNICAL_REVIEW.value
        assert record is None


def test_intake_cannot_register_lms_after_receipt_and_requires_return_reason():
    received_id = make_sample(status=SampleStatus.RECEIVED.value)
    submitted_id = make_sample(status=SampleStatus.SUBMITTED.value)
    with TestClient(app) as client:
        login(client, "intake@tsco.local")
        late_register = client.post(
            f"/intake/{received_id}/decision",
            data={"action": "REGISTER_LMS", "note": ""},
            follow_redirects=False,
        )
        assert late_register.status_code == 400
        no_reason = client.post(
            f"/intake/{submitted_id}/decision",
            data={"action": "RETURN", "note": "", "issue_type": "FIELD_DATA_ERROR"},
            follow_redirects=False,
        )
        assert no_reason.status_code == 400
    with SessionLocal() as db:
        received = db.get(SampleRequest, received_id)
        submitted = db.get(SampleRequest, submitted_id)
        assert received.status == SampleStatus.RECEIVED.value and received.lms_number is None
        assert submitted.status == SampleStatus.SUBMITTED.value and not submitted.return_reason


def test_receiving_rejects_unrecognized_seal_status_without_receiving_sample():
    sample_id = make_sample(status=SampleStatus.AWAITING_RECEIPT.value)
    with SessionLocal() as db:
        sample = db.get(SampleRequest, sample_id)
        sample.lms_number = f"LMS-{uuid.uuid4().hex[:10]}"
        db.commit()
    with TestClient(app) as client:
        login(client, "receiving@tsco.local")
        response = client.post(
            f"/receiving/{sample_id}/receive",
            data={"seal_status": "FORGED", "condition_note": ""},
            follow_redirects=False,
        )
        assert response.status_code == 400
    with SessionLocal() as db:
        assert db.get(SampleRequest, sample_id).status == SampleStatus.AWAITING_RECEIPT.value


def test_offline_idempotency_does_not_disclose_another_samplers_submission():
    barcode = f"QA264-OFF-{uuid.uuid4().hex[:16].upper()}"
    make_sample(status=SampleStatus.SUBMITTED.value, barcode=barcode)
    with TestClient(app) as client:
        login(client, "clientsampler@sec.local")
        response = client.post("/field/offline-sync", json={"offline_barcode": barcode, "fields": {}, "photos": []})
        assert response.status_code == 403
        assert "another submission" in response.json()["error"]
        assert "sample_id" not in response.json()


def test_field_numeric_domain_validation_blocks_impossible_humidity_and_coordinates():
    with TestClient(app) as client:
        login(client, "fieldman@tsco.local")
        with SessionLocal() as db:
            sec = db.scalar(select(Client).where(Client.code == "SEC"))
            asset = db.scalar(select(Asset).where(Asset.client_id == sec.id, Asset.active.is_(True)))
            user = db.scalar(select(User).where(User.email == "fieldman@tsco.local"))
            package_name = package_catalog(db, user.site_id)[0]["name"]
            sec_id, asset_id = sec.id, asset.id

        common = {
            "client_id": str(sec_id),
            "existing_asset_id": str(asset_id),
            "sample_date_time": "2026-09-02T12:00",
            "sampling_point": "Main Tank Bottom",
            "requested_package": package_name,
            "container_count": "1",
        }
        bad_humidity = client.post("/field/new", data={**common, "ambient_humidity_pct": "101"}, follow_redirects=False)
        assert bad_humidity.status_code == 400
        assert "Ambient humidity" in bad_humidity.text

        offline_barcode = f"QA264-GPS-{uuid.uuid4().hex[:16].upper()}"
        bad_gps = client.post(
            "/field/offline-sync",
            json={
                "offline_barcode": offline_barcode,
                "fields": {
                    **common,
                    "existing_asset_id": str(asset_id),
                    "gps_latitude": "91",
                },
                "photos": [],
            },
        )
        assert bad_gps.status_code == 400
        assert "GPS latitude" in bad_gps.json()["error"]


def test_admin_rejects_invalid_foreign_key_ids_before_database_error():
    suffix = uuid.uuid4().hex[:8]
    with TestClient(app) as client:
        login(client, "admin@tsco.local")
        response = client.post(
            "/admin/users",
            data={
                "email": f"bad.fk.{suffix}@tsco.local",
                "full_name": "Bad FK User",
                "role": Role.LAB_TECHNICIAN.value,
                "password": "TempPass123!",
                "site_id": "99999999",
            },
            follow_redirects=False,
        )
        assert response.status_code == 303
        assert "error=" in response.headers.get("location", "")
    with SessionLocal() as db:
        assert db.scalar(select(User).where(User.email == f"bad.fk.{suffix}@tsco.local")) is None


def test_lab_formula_engine_has_no_dynamic_code_execution_primitive():
    template = Path(__file__).resolve().parents[1] / "app" / "lab_ops" / "index_template.html"
    source = template.read_text(encoding="utf-8")
    assert "Function(" not in source
    assert "eval(" not in source
    assert "function safeFormula" in source


def test_lab_inline_platform_json_escapes_script_termination_from_master_data():
    marker = f"XSS{uuid.uuid4().hex[:8]}"
    malicious_name = f"{marker}</script><script>globalThis.__tsco_xss=1</script>"
    with SessionLocal() as db:
        db.add(Client(code=marker.upper()[:20], name=malicious_name, active=True))
        db.commit()
    with TestClient(app) as client:
        login(client, "admin@tsco.local")
        response = client.get("/lab/operations/app?embed=1&section=labprogress")
        assert response.status_code == 200
        assert malicious_name not in response.text
        assert marker in response.text
        assert "\\u003c/script\\u003e" in response.text


def test_uat_schema_is_migration_owned_not_create_all_owned():
    main_source = (Path(__file__).resolve().parents[1] / "app" / "main.py").read_text(encoding="utf-8")
    lifespan_source = main_source.split("async def lifespan", 1)[1].split("app = FastAPI", 1)[0]
    assert 'if APP_ENV in {"development", "testing", "local"}' in lifespan_source
    assert 'if APP_ENV != "production"' not in lifespan_source


def test_uat_container_defaults_do_not_enable_demo_seed_or_api_docs():
    compose = (Path(__file__).resolve().parents[1] / "docker-compose.yml").read_text(encoding="utf-8")
    assert "SEED_DEMO_DATA: ${SEED_DEMO_DATA:-false}" in compose
    assert "ENABLE_API_DOCS: ${ENABLE_API_DOCS:-false}" in compose
    assert "SEED_DEMO_DATA: ${SEED_DEMO_DATA:-true}" not in compose


def test_deployable_source_has_no_hard_coded_demo_password():
    root = Path(__file__).resolve().parents[1]
    checked = [
        root / "app" / "seed.py",
        root / "START_LOCAL_REVIEW.sh",
        root / "START_LOCAL_REVIEW.bat",
        root / "docker-compose.yml",
        root / "render.yaml",
    ]
    for path in checked:
        assert "Demo123!" not in path.read_text(encoding="utf-8"), path.name


def test_all_state_changing_routes_have_an_explicit_authentication_boundary():
    import inspect
    from app.main import app as platform_app

    unauthenticated = {"/login", "/login/{portal}"}
    guard_tokens = ("require_user(", "_admin(", "current_user(")
    unguarded = []
    for route in platform_app.routes:
        methods = set(getattr(route, "methods", set()) or set()) & {"POST", "PUT", "PATCH", "DELETE"}
        if not methods or getattr(route, "path", "") in unauthenticated:
            continue
        endpoint = getattr(route, "endpoint", None)
        try:
            source = inspect.getsource(endpoint) if endpoint else ""
        except (OSError, TypeError):
            source = ""
        if not any(token in source for token in guard_tokens):
            unguarded.append((sorted(methods), getattr(route, "path", ""), getattr(endpoint, "__name__", "?")))
    assert not unguarded, unguarded


def test_password_change_page_is_explicitly_non_cacheable():
    with TestClient(app) as client:
        login(client, "admin@tsco.local")
        response = client.get("/change-password")
        assert response.status_code == 200
        assert response.headers.get("cache-control") == "no-store"
