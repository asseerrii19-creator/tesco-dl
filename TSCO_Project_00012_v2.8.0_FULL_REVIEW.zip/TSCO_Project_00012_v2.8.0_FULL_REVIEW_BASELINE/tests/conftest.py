import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# Every pytest invocation gets a completely clean, disposable data root before
# application modules import database/storage configuration.
TEST_DATA_DIR = Path(tempfile.mkdtemp(prefix="tsco-v264-tests-"))
os.environ["APP_ENV"] = "testing"
os.environ["TSCO_DATA_DIR"] = str(TEST_DATA_DIR)
os.environ["DATABASE_URL"] = f"sqlite:///{(TEST_DATA_DIR / 'tsco_test.db').as_posix()}"
os.environ["APP_SECRET"] = "pytest-only-session-secret-not-for-deployment"
os.environ["SEED_DEMO_DATA"] = "true"
os.environ["SHOW_DEMO_ACCOUNTS"] = "false"
os.environ["DEMO_USER_PASSWORD"] = "Demo123!"
os.environ["BOOTSTRAP_ADMIN_EMAIL"] = "admin@tsco.local"
os.environ["BOOTSTRAP_ADMIN_NAME"] = "System Administrator"
os.environ["BOOTSTRAP_ADMIN_PASSWORD"] = "Demo123!"
os.environ["REQUIRE_BOOTSTRAP_PASSWORD_CHANGE"] = "false"
os.environ["ENABLE_API_DOCS"] = "true"
os.environ["ENABLE_PUBLIC_TRACKING"] = "false"
