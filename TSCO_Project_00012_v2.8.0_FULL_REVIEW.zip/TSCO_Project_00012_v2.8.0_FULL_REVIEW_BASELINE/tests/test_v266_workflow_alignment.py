import json
from datetime import datetime

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import (
    Asset,
    Client,
    OperationsState,
    PurchaseOrder,
    Quotation,
    Role,
    SampleRequest,
    SampleStatus,
    SamplingOrder,
    SamplingRequestNotice,
    User,
)
from app.services.workflow import confirm_lms_official_report_issued


def login(client: TestClient, email: str):
    response = client.post("/login/employee", data={"email": email, "password": "Demo123!"}, follow_redirects=False)
    assert response.status_code == 303


def seeded_sec_context():
    with SessionLocal() as db:
        client = db.scalar(select(Client).where(Client.code == "SEC"))
        quote = db.scalar(select(Quotation).where(Quotation.client_id == client.id, Quotation.status == "ACTIVE"))
        po = db.scalar(select(PurchaseOrder).where(PurchaseOrder.client_id == client.id, PurchaseOrder.status == "ACTIVE"))
        asset = db.scalar(select(Asset).where(Asset.client_id == client.id, Asset.active.is_(True)))
        supervisor = db.scalar(select(User).where(User.email == "supervisor@tsco.local"))
        assert client and quote and po and asset and supervisor
        return client.id, quote.id, po.id, asset.id, supervisor.id


def create_direct_sample(client: TestClient, reference: str) -> int:
    client_id, quote_id, po_id, asset_id, _ = seeded_sec_context()
    response = client.post(
        "/intake/direct",
        data={
            "client_id": str(client_id),
            "asset_id": str(asset_id),
            "quotation_id": str(quote_id),
            "purchase_order_id": str(po_id),
            "requested_package": "Routine Test",
            "sampling_point": "Main Tank / Bottom",
            "sample_date_time": datetime.now().strftime("%Y-%m-%dT%H:%M"),
            "container_count": "1",
            "client_sample_reference": reference,
            "notes": "Direct client paper submission received at Sample Intake",
        },
        follow_redirects=False,
    )
    assert response.status_code == 303
    with SessionLocal() as db:
        sample = db.scalar(select(SampleRequest).where(SampleRequest.client_sample_reference == reference))
        assert sample is not None
        return sample.id


def advance_direct_sample_to_received(client: TestClient, sample_id: int):
    accepted = client.post(
        f"/intake/{sample_id}/decision",
        data={"action": "ACCEPT_AND_REGISTER", "note": "Data verified", "issue_type": ""},
        follow_redirects=False,
    )
    assert accepted.status_code == 303
    client.post("/logout")
    login(client, "receiving@tsco.local")
    received = client.post(
        f"/receiving/{sample_id}/receive",
        data={"seal_status": "Intact", "condition_note": "Direct client container received in good condition"},
        follow_redirects=False,
    )
    assert received.status_code == 303
    client.post("/logout")
    login(client, "intake@tsco.local")


def test_sampling_supervisor_request_is_formally_converted_by_operations():
    title = "V266 planned transformer sampling"
    with TestClient(app) as client:
        client_id, quote_id, po_id, _, supervisor_id = seeded_sec_context()
        login(client, "supervisor@tsco.local")
        submitted = client.post(
            "/sampling-supervision/requests",
            data={
                "client_id": str(client_id),
                "title": title,
                "priority": "High",
                "expected_samples": "3",
                "target_sampling_at": "",
                "notes": "Supervisor operational request to Operations",
            },
            follow_redirects=False,
        )
        assert submitted.status_code == 303
        with SessionLocal() as db:
            notice = db.scalar(select(SamplingRequestNotice).where(SamplingRequestNotice.title == title))
            assert notice is not None
            assert notice.status == "PENDING_OPERATIONS"
            notice_id = notice.id
            request_code = notice.request_code

        client.post("/logout")
        login(client, "operations@tsco.local")
        dashboard = client.get(f"/operations?request_id={notice_id}")
        assert dashboard.status_code == 200
        assert request_code in dashboard.text
        converted = client.post(
            "/operations/orders",
            data={
                "sampling_request_id": str(notice_id),
                "client_id": str(client_id),
                "quotation_id": str(quote_id),
                "purchase_order_id": str(po_id),
                "supervisor_id": str(supervisor_id),
                "title": title,
                "priority": "High",
                "due_at": "",
                "notes": "Converted after commercial/operational validation",
            },
            follow_redirects=False,
        )
        assert converted.status_code == 303
        with SessionLocal() as db:
            notice = db.get(SamplingRequestNotice, notice_id)
            assert notice.status == "CONVERTED"
            assert notice.converted_order_id is not None
            order = db.get(SamplingOrder, notice.converted_order_id)
            assert order and order.title == title and order.supervisor_id == supervisor_id


def test_direct_client_sample_uses_intake_receiving_then_batch_distribution_before_lab():
    reference = "V266-DIRECT-CLIENT-001"
    with TestClient(app) as client:
        login(client, "intake@tsco.local")
        sample_id = create_direct_sample(client, reference)
        with SessionLocal() as db:
            sample = db.get(SampleRequest, sample_id)
            assert sample.sampler_id is None
            assert sample.submission_channel == "CLIENT_DELIVERED"
            assert sample.status == SampleStatus.SUBMITTED.value

        advance_direct_sample_to_received(client, sample_id)
        with SessionLocal() as db:
            sample = db.get(SampleRequest, sample_id)
            sample_key = sample.lms_number
            assert sample.status == SampleStatus.RECEIVED.value
            assert sample_key
            state = db.scalar(select(OperationsState).where(OperationsState.site_id == sample.site_id))
            if state:
                payload = json.loads(state.json_data)
                assert not any(sample_key in batch.get("samples", []) for batch in payload.get("batches", []))

        # Laboratory must not start before Intake has batched/distributed the physical sample.
        client.post("/logout")
        login(client, "chemist@tsco.local")
        client.post(f"/lab/{sample_id}/status", data={"action": "START_TESTING", "note": "Too early"}, follow_redirects=False)
        with SessionLocal() as db:
            assert db.get(SampleRequest, sample_id).status == SampleStatus.RECEIVED.value

        client.post("/logout")
        login(client, "intake@tsco.local")
        distributed = client.post(
            f"/intake/{sample_id}/decision",
            data={"action": "DISTRIBUTE_TO_LAB", "note": "Batch prepared; released to Laboratory", "issue_type": ""},
            follow_redirects=False,
        )
        assert distributed.status_code == 303
        with SessionLocal() as db:
            sample = db.get(SampleRequest, sample_id)
            assert sample.status == SampleStatus.READY_FOR_LAB.value
            state = db.scalar(select(OperationsState).where(OperationsState.site_id == sample.site_id))
            payload = json.loads(state.json_data)
            assert any(sample.lms_number in batch.get("samples", []) for batch in payload.get("batches", []))
            storage = next(row for row in payload.get("storageAssignments", []) if row.get("sample") == sample.lms_number)
            assert storage["status"] == "Reserved"


def test_quality_audit_is_read_only_and_retained_role_ownership_is_explicit():
    with TestClient(app) as client:
        login(client, "quality@tsco.local")
        audit = client.get("/admin/audit")
        assert audit.status_code == 200
        assert "Quality &amp; Audit Trail" in audit.text or "Quality & Audit Trail" in audit.text
        assert "Read-only" in audit.text or "read-only" in audit.text
        assert client.get("/admin").status_code == 403
        retained = client.get("/lab/operations?section=retained")
        assert retained.status_code == 200 and "Retained Samples" in retained.text

        client.post("/logout")
        login(client, "senior@tsco.local")
        retained = client.get("/lab/operations?section=retained")
        assert retained.status_code == 200 and "Retained Samples" in retained.text

        client.post("/logout")
        login(client, "chemist@tsco.local")
        embedded = client.get("/lab/operations/app?embed=1&section=retained")
        assert embedded.status_code == 403


def test_retention_clock_activates_only_after_official_lms_report():
    reference = "V266-RETENTION-LMS-001"
    with TestClient(app) as client:
        login(client, "intake@tsco.local")
        sample_id = create_direct_sample(client, reference)
        advance_direct_sample_to_received(client, sample_id)
        client.post(
            f"/intake/{sample_id}/decision",
            data={"action": "DISTRIBUTE_TO_LAB", "note": "Reserve retained storage", "issue_type": ""},
            follow_redirects=False,
        )

    with SessionLocal() as db:
        sample = db.get(SampleRequest, sample_id)
        sample_key = sample.lms_number
        state = db.scalar(select(OperationsState).where(OperationsState.site_id == sample.site_id))
        payload = json.loads(state.json_data)
        storage = next(row for row in payload["storageAssignments"] if row.get("sample") == sample_key)
        assert storage["status"] == "Reserved"
        assert not any(row.get("sample") == sample_key for row in payload.get("retained", []))

        sample.status = SampleStatus.READY_FOR_LMS.value
        confirm_lms_official_report_issued(db, sample, report_reference="LMS-V266-RPT-001")
        db.commit()

    with SessionLocal() as db:
        sample = db.get(SampleRequest, sample_id)
        assert sample.status == SampleStatus.REPORT_RELEASED.value
        state = db.scalar(select(OperationsState).where(OperationsState.site_id == sample.site_id))
        payload = json.loads(state.json_data)
        storage = next(row for row in payload["storageAssignments"] if row.get("sample") == sample.lms_number)
        retained = next(row for row in payload["retained"] if row.get("sample") == sample.lms_number)
        assert storage["status"] == "Active"
        assert retained["trigger"] == "LMS_OFFICIAL_REPORT"
        assert retained["report_reference"] == "LMS-V266-RPT-001"
        assert retained["due_date"]


def test_direct_client_paper_document_is_preserved_as_controlled_intake_evidence():
    from app.models import SamplePhoto

    client_id, quote_id, po_id, asset_id, _ = seeded_sec_context()
    reference = "V266-DIRECT-PAPER-001"
    with TestClient(app) as client:
        login(client, "intake@tsco.local")
        response = client.post(
            "/intake/direct",
            data={
                "client_id": str(client_id),
                "asset_id": str(asset_id),
                "quotation_id": str(quote_id),
                "purchase_order_id": str(po_id),
                "requested_package": "Routine Test",
                "sampling_point": "Main Tank / Bottom",
                "sample_date_time": datetime.now().strftime("%Y-%m-%dT%H:%M"),
                "container_count": "1",
                "client_sample_reference": reference,
                "notes": "Paper request supplied by client",
            },
            files={"submission_document": ("client-request.pdf", b"%PDF-1.4\n% controlled UAT evidence\n", "application/pdf")},
            follow_redirects=False,
        )
        assert response.status_code == 303
        with SessionLocal() as db:
            sample = db.scalar(select(SampleRequest).where(SampleRequest.client_sample_reference == reference))
            assert sample is not None
            photo = db.scalar(select(SamplePhoto).where(SamplePhoto.sample_request_id == sample.id, SamplePhoto.kind == "CLIENT_SUBMISSION_DOCUMENT"))
            assert photo is not None
            photo_id = photo.id
        evidence = client.get(f"/field/photo/{photo_id}")
        assert evidence.status_code == 200
        assert evidence.headers["content-type"].startswith("application/pdf")
        assert evidence.headers.get("cache-control") == "private, no-store"


def test_direct_client_intake_rejects_missing_commercial_handover_and_origin_as_sampling_point():
    with TestClient(app) as client:
        client_id, quote_id, po_id, asset_id, _ = seeded_sec_context()
        login(client, "intake@tsco.local")
        missing_po = client.post(
            "/intake/direct",
            data={
                "client_id": str(client_id), "asset_id": str(asset_id),
                "quotation_id": str(quote_id), "purchase_order_id": "",
                "requested_package": "Routine Test", "sampling_point": "Main Tank / Bottom",
                "container_count": "1", "client_sample_reference": "CLOSEOUT-NO-PO",
            }, follow_redirects=False,
        )
        assert missing_po.status_code >= 400

        bad_point = client.post(
            "/intake/direct",
            data={
                "client_id": str(client_id), "asset_id": str(asset_id),
                "quotation_id": str(quote_id), "purchase_order_id": str(po_id),
                "requested_package": "Routine Test", "sampling_point": "Client Delivered",
                "container_count": "1", "client_sample_reference": "CLOSEOUT-BAD-POINT",
            }, follow_redirects=False,
        )
        assert bad_point.status_code >= 400
