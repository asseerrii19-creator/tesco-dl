# TSCO Digital Laboratory Platform — v2.6.4 Verification Report

Date: 2026-09-02
Build identity: `2.6.4-uat-candidate`
Migration head: `7a1c2d3e4f50`
Status: **Controlled UAT candidate — not an unconditional production go-live declaration.**

## Automated verification

- Full pytest suite: **65 passed / 0 failed** on the final working tree before packaging.
- Static JavaScript: `app.js`, `field-form.js`, and `service-worker.js` passed `node --check`.
- Rendered-page JavaScript: inline scripts extracted from representative authenticated Admin, Field, Operations and Laboratory pages passed `node --check`.
- Reversible migration cycle: `upgrade head -> downgrade base -> upgrade head` passed on a fresh SQLite database and returned to `7a1c2d3e4f50 (head)`.
- Authenticated visible-link crawl: **131 GET requests across 14 seeded roles, 0 unexpected 5xx failures**.
- Python compile check completed successfully across application, migrations, scripts and tests.
- UAT-mode startup simulation passed with migration-owned schema, API docs disabled, secure-session behavior, bootstrap password-change enforcement and health endpoint reporting v2.6.4.
- Fresh-unpacked candidate ZIP verification: **65 passed / 0 failed**; static JavaScript passed and the reversible migration cycle returned to `7a1c2d3e4f50 (head)`.

## Security/integrity hygiene verified

- Only `/static` is publicly mounted; uploads, barcode labels and controlled documents use authenticated/scoped routes.
- UAT/production require a strong `APP_SECRET` and an explicit bootstrap-admin password.
- `SEED_DEMO_DATA=true` is rejected in UAT/production.
- Docker Compose defaults now keep demo data and API docs disabled.
- Deployable source/launch configuration no longer contains the historical hard-coded demo password.
- Service Worker caching is static-only; authenticated HTML/API responses are not persisted in Cache Storage.
- Field and Laboratory browser stores are scoped by authenticated user/site.
- Laboratory writes use server-authoritative revisions and return 409 on synchronization conflicts.
- Result/QC history is append-only with explicit revisions; retest/resample/report release integrity remains enforced.
- Controlled documents are size/type/signature checked and protected downloads use `no-store`.
- Field evidence has per-file/aggregate limits and decoded image validation.
- Password-change and authenticated operational routes are explicitly non-cacheable.
- Every registered state-changing application route has an explicit authentication boundary except the sign-in endpoints.

## Verification boundary

The execution container available for this audit is Python 3.13 with newer installed libraries, while the deployment definition pins Python 3.12 and the versions in `requirements.txt`. Therefore this report does **not** claim exact dependency-environment equivalence. The Dockerfile/Render deployment must still build and execute the suite/smoke tests in the real UAT environment.

Additional production gates: official LMS, PostgreSQL/Render storage/backup behavior, real-device browser UAT, SSO/TLS/monitoring, JSON-state scalability refactor, process-shared login throttling for multi-instance deployments, and removal of inline-script CSP allowances.
