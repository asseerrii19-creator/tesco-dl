# LMS Reporting System Boundary — v2.6.8

## Confirmed operating model

The TSCO Digital Laboratory Platform manages the operational laboratory journey and prepares approved results for transfer to the existing **LMS**.

The **LMS remains the system of record for final job closure and the official client-facing report**.

The intended production flow is:

`Sampling Request / Direct Client Delivery → Operations / Sample Intake → Data Review → LMS Registration → Physical Receiving → Batch & Distribution → Laboratory Testing → QC → Technical Review → Senior Chemist Approval → Technical Manager Approval for LMS Submission → LMS Job Closure / Official Report Issue → Client Portal`

## Responsibility split

### TSCO Digital Laboratory Platform
- Sampling and field capture.
- Sample Intake & Distribution: data verification, LMS sample registration, physical receiving, sample batching and laboratory handoff.
- Direct client-delivered paper/document intake without a field-sampler requirement.
- Laboratory workstations, results and QC after controlled intake release.
- Technical assessment/review.
- Senior Chemist technical approval.
- Technical Manager approval that the result set is **Ready for LMS**.
- Operational status tracking and client visibility.
- Retained-sample storage reservation at laboratory handoff; retention period activation after official LMS report issue.
- Receiving the official LMS report status/reference/file when the approved LMS interface supports it.

### LMS
- Existing official laboratory/business record boundary as confirmed by the project owner.
- Receives the approved result/report payload according to the interface agreed with IT.
- Final job/sample closure in LMS.
- Generates/issues the official client report.
- Returns the official report status, report number/reference and preferably the approved PDF/link to the platform.

## Status semantics in v2.6.8

- `REPORT_APPROVED` — Senior Chemist technical approval is complete.
- `READY_FOR_LMS` — Technical Manager has approved the completed result set for LMS submission. **This is not an official report release.**
- `REPORT_RELEASED` — Reserved for confirmation that the **official LMS report has been issued**.

The local Laboratory Operations workspace can therefore prepare an internal worksheet/report package and approve it for LMS submission, but it cannot create the terminal official client-report state by itself.

## Integration questions for IT / Islam

The meeting should confirm:

1. What LMS product/version is in use and who owns its administration.
2. Whether the interface is API, database integration, file import/export, SFTP, middleware, or another approved mechanism.
3. Which common identifier links the platform sample to the LMS job/sample.
4. Exact fields required for approved result submission: test code, method, result, unit, analyst, QC status, comments, timestamps, etc.
5. Whether the LMS expects structured results, an approved worksheet/report file, or both.
6. Who/what performs final closure inside LMS.
7. How the platform receives closure confirmation.
8. How the official LMS report number, issue date and PDF/link can be returned to the platform/client portal.
9. Retry, duplicate-prevention, error-handling and reconciliation rules.
10. LMS sandbox/UAT credentials and test data for integration acceptance.

## Production rule

No client-facing report should be described as officially released by the TSCO platform until the LMS has confirmed the official report issuance through the approved integration or an approved controlled process.
