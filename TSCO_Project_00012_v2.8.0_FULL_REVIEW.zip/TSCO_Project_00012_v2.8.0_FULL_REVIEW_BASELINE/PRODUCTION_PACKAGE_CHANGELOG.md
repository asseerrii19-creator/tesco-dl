# Production Package Changelog

## v2.6.7 — Monthly Quality Control Distribution

- Digitized the existing monthly Quality Control Distribution into the Quality workspace.
- Added Equipment & Safety and Materials, Gases & Storage routine-check groups.
- Added server-generated monthly Primary/Backup chemist rotation with immutable published monthly snapshots.
- Added assigned-chemist completion controls for PASS / ATTENTION / FAIL; ATTENTION and FAIL require a note.
- Added central `QUALITY_ROUTINE_CHECK_RECORDED` audit events.
- Preserved analytical QC, retained-sample ownership, intake/batching workflow and LMS official-report boundary.
- Full regression after final persistence hardening: **80 / 80 passed**.

## v2.6.6 — Operational workflow alignment

- Added Sampling Supervisor → Operations request/order handoff.
- Added controlled direct client-delivered sample intake.
- Unified Sample Intake & Distribution through Data Review, LMS Registration, Physical Receiving and Batch/Distribution.
- Added `READY_FOR_LAB` to prevent Laboratory processing before Intake handoff.
- Assigned Retained Samples operational ownership to Senior Chemist and compliance/read-only audit visibility to Quality.
- Activated retained-sample timing only after official LMS report issue.
- Preserved LMS reporting boundary and production infrastructure package.
- Test suite result: **72 passed / 0 failed**.

## v2.6.5 — LMS reporting-boundary alignment

- Confirmed LMS, not the TSCO platform, as the official final job-closure/client-report boundary.
- Added `READY_FOR_LMS` between internal technical approval and official LMS report issue.
- Technical Manager action now approves the completed result set for LMS submission; it no longer claims final client-report release.
- Reserved `REPORT_RELEASED` for confirmation that the official LMS report has been issued.
- Updated Client Portal, Management, workflow labels and Laboratory Operations terminology.
- Added a controlled service boundary for future LMS confirmation of official report issue.
- Added dedicated LMS-boundary regression tests.
- Test suite result after alignment: **67 passed / 0 failed**.
- Added `SYSTEM_BOUNDARY_LMS_REPORTING.md` and expanded IT integration inputs.

## Previous production packaging

- Production Docker Compose topology.
- TLS reverse proxy.
- PostgreSQL and persistent application-data volume.
- Preflight, backup/restore and smoke-test scripts.
- IT ownership/infrastructure guidance.
