# Short handover wording for IT

> We have a functional v2.6.8 Digital Laboratory Platform that has completed internal workflow/regression testing and is packaged for controlled UAT deployment. The operational workflow is already defined; we need IT to recommend the correct company-owned hosting/ownership model, establish the UAT environment, and confirm the official LMS integration method.
>
> Operationally, the platform prepares and approves laboratory results, but LMS remains the final job-closure and official client-report system. The platform stops at **Ready for LMS** until LMS confirms official report issuance.

If IT asks a deep infrastructure question, the project owner can say:

> I can confirm the operational requirement and workflow. I would like IT to select the infrastructure/security implementation that meets company standards.

For the LMS discussion:

> We need to confirm how approved results are transferred to LMS, how the LMS job is closed, and how the official report number/PDF or report status is returned to the platform for client visibility.

For the Quality workflow:

> The platform also digitizes the existing monthly Quality Control Distribution. Primary and Backup chemist assignments rotate automatically each month, while Quality retains oversight and every completion is audited.
