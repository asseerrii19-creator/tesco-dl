# TSCO Analytical Lab — Branding Stage 2

This visual-only pass continues from the verified v2.6.4 Controlled UAT baseline.

## Applied
- Unified authenticated dashboard density, cards, table hierarchy, page headers and form controls.
- Added a compact topbar assurance/user identity layer using the existing role/site context.
- Refined Sample Details / field evidence presentation without changing sample data or actions.
- Harmonized the embedded Laboratory Operations interface with the corporate navy / blue / teal / restrained-violet design language.
- Improved responsive behavior for tablet and mobile layouts.

## Functional boundary
No intentional workflow, role authorization, database, migration, API, integration or state-transition logic changes. Application version remains 2.6.4; this package is a design-stage derivative of the same functional baseline.
