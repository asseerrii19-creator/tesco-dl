Place the company-approved TLS certificate and private key here before deployment:

  tls.crt   - certificate/full chain in PEM format
  tls.key   - matching private key in PEM format

Do not email or commit the private key. IT should source these from the corporate PKI / approved certificate provider.
