# Render Deploy Fix v2.6.1

This package keeps the v2.6 application logic unchanged and adds deployment compatibility for Render.

## Root cause of the failed build
New Render Python services currently default to a newer Python runtime unless the project pins one. The v2.6 Docker baseline targets Python 3.12. The package now includes `.python-version` with `3.12` so Render's native Python runtime stays aligned with the tested baseline.

## Recommended Render settings
- Runtime: Python 3
- Build Command: `pip install -r requirements.txt`
- Start Command: `alembic upgrade head && uvicorn app.main:app --host 0.0.0.0 --port $PORT`

A `render.yaml` is included with the same settings.

## Important
For a quick online review, the application can start with its default SQLite database. Render's local filesystem is not durable, so use managed PostgreSQL and `DATABASE_URL` before treating this as persistent UAT/production data.
