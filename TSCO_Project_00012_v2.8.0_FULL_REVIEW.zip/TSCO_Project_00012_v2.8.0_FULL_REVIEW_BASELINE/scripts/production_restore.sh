#!/bin/sh
set -eu
[ $# -ge 1 ] || { echo "Usage: $0 <backup.sql.gz> [env-file]" >&2; exit 2; }
BACKUP=$1
ENV_FILE=${2:-.env.production}
[ -f "$BACKUP" ] || { echo "Backup file not found: $BACKUP" >&2; exit 1; }
set -a; . "$ENV_FILE"; set +a
printf 'DESTRUCTIVE RESTORE: type RESTORE to replace database %s: ' "$POSTGRES_DB"
read answer
[ "$answer" = "RESTORE" ] || { echo "Cancelled."; exit 1; }
docker compose --env-file "$ENV_FILE" -f docker-compose.production.yml exec -T db \
  psql -U "$POSTGRES_USER" -d postgres -v ON_ERROR_STOP=1 \
  -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='${POSTGRES_DB}' AND pid <> pg_backend_pid();" \
  -c "DROP DATABASE IF EXISTS \"${POSTGRES_DB}\";" \
  -c "CREATE DATABASE \"${POSTGRES_DB}\" OWNER \"${POSTGRES_USER}\";"
gunzip -c "$BACKUP" | docker compose --env-file "$ENV_FILE" -f docker-compose.production.yml exec -T db \
  psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -v ON_ERROR_STOP=1
echo "Database restore completed. Restore the matching /var/data backup before reopening service."
