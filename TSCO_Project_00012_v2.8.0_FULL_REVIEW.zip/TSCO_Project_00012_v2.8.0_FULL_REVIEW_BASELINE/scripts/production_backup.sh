#!/bin/sh
set -eu
ENV_FILE=${1:-.env.production}
BACKUP_DIR=${BACKUP_DIR:-backups}
mkdir -p "$BACKUP_DIR"
set -a; . "$ENV_FILE"; set +a
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
OUT="$BACKUP_DIR/tsco_platform_${STAMP}.sql.gz"
docker compose --env-file "$ENV_FILE" -f docker-compose.production.yml exec -T db \
  pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" --no-owner --no-privileges | gzip -9 > "$OUT"
[ -s "$OUT" ] || { echo "Backup failed or empty: $OUT" >&2; exit 1; }
sha256sum "$OUT" > "$OUT.sha256"
echo "Database backup created: $OUT"
echo "NOTE: /var/data uploads/documents must also be included in the company's volume/filesystem backup policy."
