#!/usr/bin/env python3
import ssl
import sys
import urllib.request

if len(sys.argv) != 2:
    print("Usage: production_smoke_test.py https://lab.company.com", file=sys.stderr)
    raise SystemExit(2)
base = sys.argv[1].rstrip("/")
ctx = ssl.create_default_context()
checks = ["/api/v1/health", "/login"]
failed = 0
for path in checks:
    try:
        req = urllib.request.Request(base + path, headers={"User-Agent": "TSCO-Production-Smoke-Test/1.0"})
        with urllib.request.urlopen(req, context=ctx, timeout=10) as r:
            print(f"PASS {path}: HTTP {r.status}")
            if r.status >= 400:
                failed += 1
    except Exception as exc:
        failed += 1
        print(f"FAIL {path}: {exc}")
raise SystemExit(1 if failed else 0)
