#!/bin/sh
set -eu

ENV_FILE=${1:-.env.production}
COMPOSE_FILE=${COMPOSE_FILE:-docker-compose.production.yml}

fail() { echo "ERROR: $*" >&2; exit 1; }
pass() { echo "PASS: $*"; }

[ -f "$ENV_FILE" ] || fail "$ENV_FILE not found. Copy .env.production.template and fill the IT-owned values."
command -v docker >/dev/null 2>&1 || fail "Docker is not installed."
docker compose version >/dev/null 2>&1 || fail "Docker Compose v2 is not available."
[ -f deploy/certs/tls.crt ] || fail "deploy/certs/tls.crt is missing."
[ -f deploy/certs/tls.key ] || fail "deploy/certs/tls.key is missing."

set -a
. "$ENV_FILE"
set +a

for v in SERVER_NAME APP_SECRET BOOTSTRAP_ADMIN_EMAIL POSTGRES_DB POSTGRES_USER POSTGRES_PASSWORD; do
  eval "value=\${$v:-}"
  [ -n "$value" ] || fail "$v is empty."
done

[ ${#APP_SECRET} -ge 64 ] || fail "APP_SECRET must be at least 64 characters for this deployment package."
[ ${#POSTGRES_PASSWORD} -ge 20 ] || fail "POSTGRES_PASSWORD must be at least 20 characters."
if [ -n "${BOOTSTRAP_ADMIN_PASSWORD:-}" ]; then
  [ ${#BOOTSTRAP_ADMIN_PASSWORD} -ge 16 ] || fail "BOOTSTRAP_ADMIN_PASSWORD must be at least 16 characters when supplied."
else
  echo "WARNING: BOOTSTRAP_ADMIN_PASSWORD is empty. This is valid only when the bootstrap administrator already exists in the target database."
fi
[ "${ENABLE_PUBLIC_TRACKING:-false}" = "false" ] || echo "WARNING: public tracking is enabled; confirm corporate approval."

case "$SERVER_NAME" in
  *.example|company.example|lab.company.example) fail "SERVER_NAME still contains an example placeholder." ;;
esac

COMPOSE_ENV_FILES="$ENV_FILE" docker compose --env-file "$ENV_FILE" -f "$COMPOSE_FILE" config >/dev/null
pass "Docker Compose production configuration validates."
pass "Required TLS files are present."
pass "Mandatory environment values are populated."
echo "Preflight complete."
