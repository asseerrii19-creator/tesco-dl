# Verification Report — v2.6.6 Operational Workflow Alignment

Date: 2026-09-03

## Scope

Verification focused on the final business-process corrections requested before IT handover. The v2.6.5 LMS reporting boundary and production deployment topology were preserved.

## Automated result

**72 passed / 0 failed**

The full regression suite includes all previous workflow, authorization, client-isolation, offline, audit, laboratory, technical review and LMS-boundary checks plus the new v2.6.6 workflow-alignment cases.

## New verified cases

1. Sampling Supervisor creates a Sampling Request; Operations converts it to the official Sampling Order.
2. Direct client-delivered sample can be created with `sampler_id = NULL` and source `CLIENT_DELIVERED`.
3. LMS registration does not prematurely create a Laboratory batch.
4. Physical receipt leaves the sample at `RECEIVED` until Intake Batch & Distribution.
5. Laboratory `START_TESTING` cannot advance a merely `RECEIVED` sample.
6. Intake Batch & Distribution sets `READY_FOR_LAB`, creates the Laboratory handoff and reserves retained-sample storage.
7. Quality can open the site-scoped read-only Audit Trail and Retained Samples compliance view but cannot enter System Administration.
8. Senior Chemist can access Retained Samples; Chemist cannot.
9. LMS official-report confirmation changes the terminal status to `REPORT_RELEASED` and activates the retained-sample clock/reference.
10. Direct client paper/PDF submission evidence is preserved and securely retrievable by authorized internal roles.

## Static / migration validation

- Python compile: PASS.
- Static JavaScript: PASS.
- Rendered embedded Laboratory JavaScript: PASS.
- Alembic upgrade to `c8e6f5a42b11`: PASS.
- NGINX template syntax after test substitution: PASS.

Evidence is stored under `evidence/v2.6.6_workflow_alignment/`.
