# TSCO Digital Laboratory Platform — v2.6.8 Final Verification

Date: 2026-09-09
Build identity: `v2.6.8-final-uat-candidate`
Baseline: frozen v2.6.7 IT-review package retained unchanged for traceability.
Status: **Final UAT Candidate — not production go-live authorization.**

## Final functional corrections verified

- Server-enforced analytical assignment scope: Single, Primary + Backup, and All Laboratory Chemists.
- Reassignment is append-only and preserves the previous assignee/history.
- The authenticated user is the server-authoritative analyst for result records.
- Lab Technician payload/result/QC actions are assignment-scoped; direct API attempts for unassigned analytical work are rejected.
- Analytical/Test QC is separate from Monthly/Routine Quality Control Distribution.
- Operational workstation grouping is normalized to Water; Electrical; DGA; Furan/Passivator; DBDS/BHT/Toluene/PCB; TAN/Peroxide/RSH/H2S; Corrosion/CCD; Physical/Chemistry; and remaining Additives/Special Tests.
- Electrical keeps method-specific test identity. Alternate BDV methods remain optional/catalogued; the generic Full Test does not force all alternatives.
- QDF [7]-07-E method fidelity was rechecked. Total Acid Number is ASTM D974. The legacy D664 browser calculator was removed rather than applying the wrong method formula.
- Controlled document revisions support site/workstation/test/method linkage and retain superseded history.
- Technical Assessment links moisture/dielectric, oxidation/ageing, corrosive-sulfur/passivation, cellulose/paper-ageing and advisory DGA evidence while keeping the Senior Chemist as the final technical recommendation owner.
- LMS remains the official final report/closure system; the TSCO platform ends at Approved for LMS until the LMS confirms official report release.

## Automated verification

- Python compile check: **PASS**.
- Full pytest regression: **92 passed / 0 failed**.
- Focused v2.6.8 assignment/interpretation/method tests: included in the full suite.
- Alembic migration topology: **single head `e21f7c8d9a01`**.
- Live application code contains no ASTM D664/TAN_D664 analytical calculator; the only D664 string retained is a negative regression assertion.

The test suite emits deprecation warnings from existing Python/Starlette datetime/template APIs. They are technical-debt warnings, not test failures.

## Production boundary

Production go-live still requires company-controlled infrastructure, approved SSO/identity approach, security review, approved permission matrix, PostgreSQL/backup/restore validation, official LMS interface/UAT, and formal Operations/Quality/IT acceptance.
