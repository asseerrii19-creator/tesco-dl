# Release Candidate Status — v2.6.9

- Product version: **2.6.9**
- Package status: **LMS-Aligned Production Deployment Candidate — ready for IT-controlled UAT planning**
- Design baseline: **Branded Stage 5 retained**
- Automated regression after LMS + operational workflow alignment: **97 / 97 passed**
- Historical RC1 internal UAT: **79 / 79 passed**, with the original local-report-release boundary explicitly superseded by the current LMS-aligned model.
- Workflow alignment: **Sample Intake & Distribution + Direct Client Intake + Sampling Request handoff + Quality/Retained ownership + Monthly Primary/Backup Quality rotation**
- Official client report owner: **LMS**
- Platform terminal pre-LMS state: **READY_FOR_LMS**
- Production go-live: **NOT YET AUTHORIZED** — infrastructure, official LMS integration, security and organizational acceptance remain open.

Start with:
1. `QUALITY_CONTROL_DISTRIBUTION_v2.6.8.md`
2. `WORKFLOW_ALIGNMENT_v2.6.6.md` (prior workflow-alignment baseline)
3. `SYSTEM_BOUNDARY_LMS_REPORTING.md`
4. `IT_INPUTS_REQUIRED.md`
5. `IT_HANDOVER.md`
6. `PRODUCTION_DEPLOYMENT_RUNBOOK.md`
7. `UAT_ACCEPTANCE_CHECKLIST.md`
