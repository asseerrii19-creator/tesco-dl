# UAT Acceptance Checklist — TSCO Digital Laboratory Platform v2.6.8

## Environment

- [ ] UAT domain and HTTPS configured
- [ ] PostgreSQL database available
- [ ] Application secrets replaced
- [ ] Demo data enabled only in UAT
- [ ] Public tracking disabled unless approved
- [ ] Database, uploads and barcode storage included in backup scope

## Portal and access separation

- [ ] Public landing shows Client, Employee and Field portals only
- [ ] Client user sees only the linked company
- [ ] TSCO field sampler sees only assigned companies/work
- [ ] Client sampler submits only for the linked client
- [ ] Chemist cannot access Technical Supervision, Retained Samples or Management
- [ ] Senior Chemist can access review, assessment and operational Retained Samples
- [ ] Quality can access QC, Retained Samples compliance view and read-only site Audit Trail
- [ ] System Administrator can manage master data and accounts

## End-to-end sample workflow

- [ ] Sampling Supervisor can raise a Sampling Request to Operations
- [ ] Operations validates client/quotation/PO and converts it into the official Sampling Order
- [ ] Sampling Supervisor assigns approved field work to the sampler
- [ ] Sampler captures asset, serial number, GPS and required photos
- [ ] Barcode/tag is generated
- [ ] Offline submission survives connection loss and syncs once online
- [ ] Direct client-delivered samples can be created in Sample Intake without a sampler account and paper/PDF/image evidence can be attached
- [ ] Sample Intake Data Review can Accept, Return or Reject
- [ ] Accepted submission receives a mock/official LMS number
- [ ] Status becomes Awaiting Physical Receipt
- [ ] Physical Receiving confirms the same sample without duplicating LMS registration
- [ ] Physically received sample remains outside Laboratory until Batch & Distribution is completed
- [ ] Batch & Distribution changes status to `READY_FOR_LAB` and creates the Laboratory handoff
- [ ] Retained-sample storage is reserved at Laboratory handoff
- [ ] Chemist cannot start a merely `RECEIVED` sample; testing can start after `READY_FOR_LAB`
- [ ] Chemist records results and completes required QC
- [ ] Senior Chemist reviews results/assessment, handles retest/resample and operates Retained Samples
- [ ] Quality has QC/compliance and read-only site audit visibility
- [ ] Senior Chemist approval sets the controlled technical-approval state
- [ ] Technical Manager approval sets `READY_FOR_LMS` and does not claim official release
- [ ] Approved result payload transfers to LMS through the approved interface
- [ ] LMS job closure is confirmed
- [ ] Official LMS report number/status and PDF/link are returned where supported
- [ ] LMS-confirmed official report issuance activates the retained-sample retention clock
- [ ] Only LMS-confirmed official report issuance becomes visible as the final client-report milestone

## Laboratory module

- [ ] Laboratory Progress opens inside the unified platform shell
- [ ] Technical Supervision opens only for authorized roles
- [ ] Retained Samples is directly accessible to authorized roles
- [ ] Test Workstations and calculations are available
- [ ] Methods & Procedures open correctly
- [ ] Operations Records preserve user/time/action trace
- [ ] Report print output is compared with the approved QDF form

## Monthly Quality Control Distribution

- [ ] Current month distribution is generated automatically for the site
- [ ] Balances, Electrode, Gas Supplies, Gas Cylinder, Chemical Inventory, Sample Storage and Shower/Eye Wash duties are present
- [ ] Every assignment shows Primary and Backup chemist where at least two eligible chemists exist
- [ ] Primary/Backup assignments change on the next monthly schedule without rewriting the prior month
- [ ] Only assigned Primary/Backup can record the check; Quality has oversight/read visibility
- [ ] ATTENTION / FAIL cannot be saved without an observation
- [ ] Routine-check completion appears in central Audit Trail

## Integration and production readiness

- [ ] Official LMS product/version documented
- [ ] Official LMS interface type and sandbox/UAT environment supplied
- [ ] Client/test/quotation/PO/result/unit/sample identifier mapping approved
- [ ] Duplicate and retry behavior validated
- [ ] SSO/MFA decision completed
- [ ] Security review and penetration testing completed
- [ ] File retention, malware validation and encryption policy approved
- [ ] Backup restore test completed
- [ ] Monitoring, alerting and log-retention configured
- [ ] Quality, Laboratory, Operations and IT sign-off completed
