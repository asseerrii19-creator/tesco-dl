# IT Inputs Required — Production/UAT Hosting & LMS Integration

The application is already built and internally tested, including the v2.6.9 operational workflow and monthly Quality Distribution alignment. These are **environment/integration decisions owned by IT**, not questions the project owner is expected to solve technically.

## Infrastructure inputs

IT should provide/confirm:

1. **Hosting target** — company VM/server, approved private cloud, or approved cloud subscription.
2. **Company ownership model** — whether the environment is provided by the parent company or is a dedicated TSCO-controlled environment.
3. **Corporate hostname/domain/subdomain** — created and owned through the approved company process.
4. **TLS certificate** — corporate PKI or approved certificate for the selected hostname.
5. **Network exposure** — internal staff only, VPN, or approved external client access through the corporate edge/WAF.
6. **PostgreSQL model** — containerized PostgreSQL from this package or company-managed PostgreSQL service.
7. **Secrets location** — corporate vault/secret manager and authorized administrators.
8. **Backup target & retention** — company backup platform, retention period, and restore-test owner.
9. **Corporate identity** — local UAT authentication or future SSO/Entra/AD.
10. **Security approval path** — application/security review, vulnerability scan/penetration test, and go-live approval owners.

## LMS integration inputs — required system boundary

The LMS is the official final-report boundary. IT should confirm:

1. LMS product/version and technical owner.
2. UAT/sandbox environment and credentials.
3. Integration interface: API / middleware / database / file exchange / other approved interface.
4. Authentication method and network path.
5. Common sample/job identifier and field mappings.
6. Approved-result submission format and required fields.
7. How LMS job closure is triggered/confirmed.
8. How the official report number, issue date and PDF/link are returned.
9. Duplicate prevention, retry, failure and reconciliation behavior.
10. Whether the client portal may retrieve/display the official LMS report directly or via a controlled copy/reference.

See `SYSTEM_BOUNDARY_LMS_REPORTING.md` for the exact responsibility split.

## Information the project owner can provide

The project owner only needs to confirm business/operational items:

- Preferred platform name.
- Pilot laboratory/site.
- Which user groups need access.
- Whether client access is included in the first controlled UAT phase.
- Business owner / Technical Manager / Quality approver for UAT acceptance.
- Operational confirmation of which data/results need to be transferred to LMS.
- Quality/Senior Chemist confirmation of retained-sample retention period and disposal policy during UAT.

The project owner does **not** need to choose firewall rules, certificates, DNS mechanics, PostgreSQL administration, Docker networking, backup technology, or the LMS technical interface. Those belong to IT.
