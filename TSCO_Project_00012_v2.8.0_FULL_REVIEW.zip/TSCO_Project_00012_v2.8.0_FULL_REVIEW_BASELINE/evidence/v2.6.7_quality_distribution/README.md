# v2.6.7 release evidence

Evidence captured for the final monthly Quality Control Distribution release candidate:

- full 79-test regression output,
- clean Alembic upgrade output,
- local application smoke output,
- NGINX syntax test output,
- static release-verification summary.

See the package-root `VERIFICATION_REPORT_v2.6.7.md` for interpretation.
