# Quality Control Distribution — v2.6.7

## Purpose
Digitize the laboratory's monthly **Quality Control Distribution** without losing the operational ownership used in the approved paper chart.

## Controlled routine duties
The platform publishes the following recurring duties:

### Equipment & Safety
- Balances Check
- Electrode Check
- Shower & Eye Wash Check

### Materials, Gases & Storage
- Gas Supplies Check
- Gas Cylinder Status / Daily Record
- Chemical Inventory Check
- Sample Storage Check

The first six duties are assigned across the laboratory's four operational periods:
- Week 1: days 1–11
- Week 2: days 12–18
- Week 3: days 19–25
- Week 4: day 26 through end of month

Shower & Eye Wash Check is represented as a monthly duty.

## Monthly Primary / Backup rotation
- A new distribution is generated automatically for each month.
- Every assignment has a **Primary** chemist and a **Backup** chemist when at least two eligible staff are available.
- Gas Supplies Check and Gas Cylinder Status / Daily Record share the same Primary/Backup pair for each period, matching the source distribution chart.
- Rotation is deterministic and changes month-to-month; it is not a random browser assignment.
- Eligible operational assignees are active Laboratory Chemist/Technician and Senior Chemist accounts for the site.
- The schedule is server-owned and a published historical month cannot be rewritten by the browser.
- The generated month is persisted on the first normal Quality/Laboratory API load, preserving the monthly snapshot for history and audit.

## Completion control
Only the assigned Primary or Backup chemist (or System Administrator for controlled support) can record the routine check. Allowed results are:
- `PASS`
- `ATTENTION`
- `FAIL`

`ATTENTION` and `FAIL` require an observation note. The server stamps the task identity, period, user, user ID and completion time.

## Quality role
Quality has oversight/read visibility of the distribution and completion status. Quality does not impersonate the assigned chemist to complete the routine task. Quality continues to own QC/compliance functions and has read-only site Audit visibility.

## Audit
Every new routine quality completion creates a central SQL audit event:

`QUALITY_ROUTINE_CHECK_RECORDED`

This is separate from analytical QC records, calibration/maintenance records and retained-sample operational ownership.
