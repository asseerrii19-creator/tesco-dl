# TSCO Digital Laboratory Platform v2.6.4 — Controlled UAT Hardening

Date: 2026-09-02
Build identity: `2.6.4-uat-candidate`

v2.6.4 is the final code-hardening pass before visual-design work. It is a controlled UAT candidate, not a production go-live declaration.

## Closed in v2.6.4

- Corrected Docker Compose safety defaults so UAT does not enable demo seeding or API docs unless explicitly requested.
- Removed hard-coded local-review passwords from deployable source and launch scripts; local review credentials are generated per run.
- Added explicit `DEMO_USER_PASSWORD` configuration for demo-only seed accounts and retained the UAT/production prohibition on demo seeding.
- Updated runtime/version identity consistently to v2.6.4.
- Added explicit no-store caching for the password-change flow.
- Added regression coverage that every state-changing route has an explicit authentication boundary, except the two sign-in endpoints.
- Re-ran full workflow, RBAC, offline, multi-site, document, report/retest, backup/restore, migration and validation regressions.
- Re-ran static and rendered JavaScript syntax validation.
- Re-ran a role-visible-link crawl across seeded operational roles.
- Re-ran reversible migration testing and a UAT-mode startup simulation with migration-owned schema, generated secret behavior, disabled docs and forced first-password change.

## UAT boundary

The following remain environment/production gates rather than code-audit claims:

- Official LMS integration (`LMS_MODE=mock` remains intentional for UAT).
- Actual PostgreSQL + Render deployment verification under Python 3.12 and the pinned requirements file.
- Real Chromium/mobile visual UAT and responsive/layout acceptance.
- Corporate SSO/identity, TLS/domain, monitoring, backup policy and restore drill.
- Laboratory OperationsState is still synchronized as a site-level JSON payload with a 5 MB server limit; this is acceptable for controlled UAT but should be decomposed into relational event/result records before high-scale production use.
- CSP still permits inline script/style execution because the inherited Laboratory Operations UI is inline-script heavy; a later production hardening phase should externalize those scripts/styles and remove `unsafe-inline`.
- Login throttling is process-local; if production runs multiple application instances/workers, throttling should move to a shared store or edge identity layer.
