# Final Internal UAT / Release Candidate Audit — v2.6.4

> **Historical evidence notice — superseded reporting boundary:** RC1 originally modeled Technical Manager local release as `REPORT_RELEASED`. The project owner later confirmed that LMS performs final job closure and issues the official client report. v2.6.5 corrected this boundary by introducing `READY_FOR_LMS`, and the current v2.6.7 preserves it while aligning intake/retained and monthly Quality Distribution workflows; the RC1 evidence below remains historical test evidence only and must not be read as the current production reporting model. See `SYSTEM_BOUNDARY_LMS_REPORTING.md`.

**Baseline:** Branded Stage 5  
**Candidate status:** RC1 — Internal UAT passed; external infrastructure / organizational sign-offs remain pending.  
**Functional code changed during this audit:** No. The RC1 package freezes the Stage 5 functional/design baseline and adds verification evidence.

## Executive result

- Automated regression suite: **65 passed / 0 failed**.
- Live end-to-end internal UAT: **79 passed / 0 failed**.
- Python compile: **PASS**.
- Static JavaScript syntax: **PASS**.
- Fresh Alembic migration chain to head `7a1c2d3e4f50`: **PASS**.
- UAT-mode startup on a clean migrated database with demo seeding disabled: **PASS**.
- Core security-header / cross-site state-change checks: **PASS**.

## End-to-end sample used for final UAT

- Sampling order: `SO-DMM-26-00001`
- Assignment: `DMM-12AB201A7B`
- Field request: `FS-DMM-26-000001`
- Mock LMS number: `DMM26-000001`
- Barcode: `TSCO-DMM-26-00000001`

The audited lifecycle was:

`Operations Order → Sampling Assignment → Supervisor Assignment → Field Capture → Data Entry / LMS Registration → Physical Receiving → Laboratory Testing → QC → Technical Review → Senior Chemist Approval → Technical Manager Release → Client Visibility`

## Detailed internal UAT results

1. **PASS** — Public welcome loads
2. **PASS** — Unified sign-in CTA exists
3. **PASS** — Unified login loads
4. **PASS** — Login operations@tsco.local
5. **PASS** — Operations workspace loads
6. **PASS** — Operations creates sampling order
7. **PASS** — Sampling order persisted
8. **PASS** — Operations creates unassigned sampling task
9. **PASS** — Assignment initially UNASSIGNED
10. **PASS** — Login supervisor@tsco.local
11. **PASS** — Sampling Supervision loads assignment
12. **PASS** — Supervisor assigns sampler
13. **PASS** — Assignment state becomes ASSIGNED
14. **PASS** — Login fieldman@tsco.local
15. **PASS** — Field dashboard shows assigned task
16. **PASS** — Assigned field capture form loads
17. **PASS** — Field submits assigned sample
18. **PASS** — Field sample persisted as SUBMITTED
19. **PASS** — Assignment closes against same sample
20. **PASS** — Field sample detail loads
21. **PASS** — Login intake@tsco.local
22. **PASS** — Intake queue sees submitted sample
23. **PASS** — Intake accepts and registers
24. **PASS** — LMS identity created / awaiting receipt
25. **PASS** — Login receiving@tsco.local
26. **PASS** — Receiving scan resolves barcode/LMS sample
27. **PASS** — Receiving confirms physical receipt
28. **PASS** — Sample state RECEIVED
29. **PASS** — Login chemist@tsco.local
30. **PASS** — Chemist unified Laboratory Progress loads
31. **PASS** — Chemist Workstations loads
32. **PASS** — Chemist starts testing
33. **PASS** — Lab operations API readable by chemist
34. **PASS** — Central sample synchronized into Lab Operations
35. **PASS** — Lab batch uses central request/LMS identity
36. **PASS** — Chemist saves controlled results + QC
37. **PASS** — Chemist blocked from final report release
38. **PASS** — Chemist submits completed sample for technical review
39. **PASS** — Sample state TECHNICAL_REVIEW
40. **PASS** — Login quality@tsco.local
41. **PASS** — Quality Control section loads for Quality role
42. **PASS** — Quality cannot forge lab lifecycle action
43. **PASS** — Login senior@tsco.local
44. **PASS** — Senior assessment screen loads selected sample
45. **PASS** — Senior approves technical assessment
46. **PASS** — Sample state REPORT_APPROVED
47. **PASS** — Senior Chemist blocked from final release
48. **PASS** — Login technical@tsco.local
49. **PASS** — Technical Manager cannot create sampling transaction
50. **PASS** — Technical Manager releases report
51. **PASS** — Release actor is server-owned
52. **PASS** — Central sample state REPORT_RELEASED
53. **PASS** — Login client@sec.local
54. **PASS** — SEC client sees released sample
55. **PASS** — Login client@aramco.local
56. **PASS** — Aramco client cannot see SEC sample
57. **PASS** — Public token tracking shows released milestone
58. **PASS** — Invalid public tracking token does not disclose sample
59. **PASS** — Login manager@tsco.local
60. **PASS** — Management dashboard loads
61. **PASS** — Unauthorized management lab section normalized, not 403
62. **PASS** — Login admin@tsco.local
63. **PASS** — Administrator route /admin
64. **PASS** — Administrator route /operations
65. **PASS** — Administrator route /sampling-supervision
66. **PASS** — Administrator route /intake
67. **PASS** — Administrator route /receiving
68. **PASS** — Administrator route /lab/operations?section=dashboard
69. **PASS** — Administrator route /assessment
70. **PASS** — Administrator route /management
71. **PASS** — Audit log contains SAMPLING_ORDER_CREATED
72. **PASS** — Audit log contains SAMPLING_ASSIGNMENT_CREATED
73. **PASS** — Audit log contains SAMPLING_ASSIGNMENT_ASSIGNED
74. **PASS** — Audit log contains FIELD_SAMPLE_SUBMITTED
75. **PASS** — Audit log contains PHYSICAL_SAMPLE_RECEIVED
76. **PASS** — Audit log contains SAMPLE_STATUS_CHANGED
77. **PASS** — Security header X-Content-Type-Options
78. **PASS** — Security header CSP present
79. **PASS** — Cross-site state-changing request rejected

## Role / control boundaries explicitly verified

- Unified authentication selects workspace from the account role; portal URL does not select a role.
- Field sampler only completes the assignment allocated to that account.
- Quality has QC/review visibility but cannot change the sample laboratory lifecycle.
- Laboratory Chemist cannot perform final report release.
- Senior Chemist can approve the technical assessment but cannot perform final report release.
- Technical Manager can release an approved report but cannot create Sampling Operations transactions.
- SEC client can see its released sample; Saudi Aramco client cannot see the SEC sample.
- Management requests for unauthorized Laboratory sections are normalized to permitted content instead of exposing a forbidden section.
- Audit records were created for order creation, assignment creation/assignment, field submission, physical receipt, and sample status changes.

## Release-candidate scope boundary

RC1 means the **application baseline passed internal code/UAT verification**. It does **not** mean production go-live is authorized. The following items require the target IT / Quality environment and cannot be honestly closed in this isolated review:

- UAT/production domain and HTTPS termination.
- PostgreSQL target database provisioning and operational backup policy.
- Official LMS interface, sandbox, mappings, duplicate/retry behavior and ownership boundaries.
- SSO/MFA decision and corporate identity integration.
- Independent security review / penetration testing.
- File retention, malware validation and encryption-at-rest policy.
- Backup restore drill in the actual target infrastructure.
- Monitoring, alerting and log-retention configuration.
- Formal Quality, Laboratory, Operations and IT acceptance/sign-off.

## Non-blocking technical debt observed

The regression suite reports deprecation warnings around naive `datetime.utcnow()` usage and the older Starlette `TemplateResponse` call signature. They do not fail v2.6.4 today, but should be scheduled before a future Python / Starlette major-version upgrade. They were intentionally **not** changed during RC1 to avoid altering a stable, fully passing baseline.

## Design baseline

The Branded Stage 5 UI is the frozen visual baseline for RC1. Samples & Batches, Workstations, Quality Control and Reports reference renders remain under `design_review/stage5/`.

## Recommendation

Proceed with **controlled IT UAT deployment** of this RC1 package. Do not reopen business workflow or visual design unless UAT identifies a reproducible defect or an approved change request.
