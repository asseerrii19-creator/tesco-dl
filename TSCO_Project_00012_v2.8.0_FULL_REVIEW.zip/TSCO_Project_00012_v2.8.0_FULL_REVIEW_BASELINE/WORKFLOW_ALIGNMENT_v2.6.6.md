# v2.6.6 — Operational Workflow Alignment

## Why this revision exists

This revision captures final business-process details identified before IT deployment. It does **not** redesign the analytical engine, QC calculations, client isolation, LMS reporting boundary, production topology or security model.

## 1. Sampling requirement → Operations order

- Sampling Supervisor can create a **Sampling Request** when field work is required.
- Operations receives that request and remains responsible for the **official Sampling Order**, including client/quotation/PO/priority validation.
- The approved order returns to Sampling Supervision for assignment to the Sampling Man.

Flow: `Sampling Request → Operations validation/order → Sampling Supervisor assignment → Field Sampling`.

## 2. Sample Intake & Distribution

Data Entry, LMS Registration, Physical Receiving and sample Batch/Distribution are now presented as one operational workspace:

`Data Review → LMS Registration → Physical Receiving → Batch & Distribution → READY_FOR_LAB`

The accountable roles remain distinguishable in the audit trail even though they work in one operational section. A physically received sample does **not** enter Laboratory Operations until Batch & Distribution is completed.

## 3. Direct client-delivered samples

When the client brings bottles/samples directly with paper documentation:

- Intake can create the sample directly without a field-sampler account.
- Source is recorded as `CLIENT_DELIVERED`.
- PDF/JPEG/PNG/WebP client submission evidence can be attached.
- The sample then follows the same controlled Data Review → LMS → Receiving → Batch/Distribution flow.

This prevents fake Field Sampling events from being created for work TSCO did not sample.

## 4. Laboratory batch ownership

Operational sample batching/distribution belongs to **Sample Intake & Distribution**, immediately before release to Laboratory. Instrument/test-run grouping remains a Laboratory Workstation concern. The old Laboratory batch screen is retained only as an admin compatibility/diagnostic surface and is not the operational handoff owner.

## 5. Quality, Audit and Retained Samples

- **Senior Chemist:** operational owner of Retained Samples and laboratory supervision.
- **Quality:** QC/compliance oversight, Retained Samples visibility and **read-only site Audit Trail**.
- **Technical Manager:** oversight and LMS-submission approval.
- **Chemist/Lab Technician:** no retained-sample operational ownership.

Retained storage is reserved when Intake releases the sample to Laboratory. The configured retention period begins when LMS confirms issuance of the official client report, aligning retention with the official report boundary.

## 6. LMS reporting boundary remains unchanged

`REPORT_APPROVED → READY_FOR_LMS → LMS official report → REPORT_RELEASED`

The TSCO platform does not independently claim official client-report release.

## Verification

Dedicated v2.6.6 tests verify:

- Sampling Supervisor request → Operations official order conversion.
- Direct client sample with no sampler account.
- Direct client paper/PDF submission evidence preservation and authorized retrieval.
- Physical receipt cannot bypass Intake Batch & Distribution.
- `READY_FOR_LAB` handoff creates Laboratory batch and reserves retained storage.
- Quality read-only audit access and Retained Samples visibility.
- Senior Chemist retained visibility; Chemist retained exclusion.
- LMS official report confirmation activates retained-sample retention.

See `VERIFICATION_REPORT_v2.6.6.md`.
