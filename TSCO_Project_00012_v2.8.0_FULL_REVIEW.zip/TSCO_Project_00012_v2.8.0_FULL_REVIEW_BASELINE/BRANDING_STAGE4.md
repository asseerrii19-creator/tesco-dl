# Branding Stage 4 — Final Visual QA

This pass is visual-only and preserves the v2.6.4 UAT functional baseline.

## Changes
- Corrected the Sampling Orders dark summary heading contrast after a later global heading rule overrode it.
- Added a styled legacy `.alert.error` state so validation feedback matches the platform design system.
- Improved empty-table presentation across role portals.
- Kept the Field assignment lookup aligned on one row at desktop widths with a clean mobile collapse.
- Removed the half-width empty state on Technical Assessment when no sample is selected.
- Added subtle sidebar scrollbar/focus treatment and micro-typography consistency.
- Added intentional empty states and final interaction polish inside the embedded Laboratory Operations surface.

No workflow, RBAC, route, persistence, API, integration or laboratory-calculation logic was changed.
