# Role and Visibility Matrix

| Role | Primary workspace | Scope |
|---|---|---|
| Operations Manager | Sampling orders | Assigned site; clients/projects allowed by policy |
| Sampling Supervisor | Sampling assignments | Assigned site and orders |
| TSCO Field Sampler | Field PWA | Companies assigned to the user |
| Client Sampler / Operations | Field PWA | Own client company only |
| Data Entry | Intake review | Assigned laboratory site |
| Sample Receiving | Barcode receipt | Assigned laboratory site |
| Laboratory Technician | Progress, assigned workstations, analytical QC, methods | Assigned site + current workstation/test assignment |
| Senior Chemist | Full laboratory supervision, assignment/reassignment, assessment, reports | Assigned laboratory site; bench result entry still requires explicit assignment |
| Quality | QC, reports, retained samples, controlled references | Assigned laboratory site |
| Technical Manager | Cross-workflow technical oversight | Assigned site(s) per IT policy |
| Management | Management dashboard and approved high-level laboratory views | Assigned site(s) |
| Client User | Client dashboard | Own company only |
| System Administrator | Master data and platform administration | Defined by IT; not automatically business approval authority |

**Control rule:** role defines allowed functions; current assignment defines the analytical work a chemist may view/execute. SINGLE, PRIMARY+BACKUP and ALL-qualified-staff assignment modes are supported, with append-only reassignment/audit. Analytical/Test QC is separate from the Monthly/Routine Quality assignment domain.

The final production permission matrix should be approved by IT, Quality and process owners.
