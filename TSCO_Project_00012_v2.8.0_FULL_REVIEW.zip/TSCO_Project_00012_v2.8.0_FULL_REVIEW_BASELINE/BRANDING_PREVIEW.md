# TSCO Analytical Lab — Branded UI Preview

This package preserves the v2.6.4 Controlled UAT functional baseline and applies the first approved corporate visual direction.

## Brand hierarchy
- Corporate laboratory identity: **TSCO Analytical Lab**
- System name: **TSCO Digital Laboratory Platform**
- Site/laboratory context remains dynamic (for example Dammam — Transformer Oil Laboratory, Jubail — Hydrocarbon Laboratory, Bahrain — Analytical Laboratory).

## Visual direction
- Enterprise Industrial structure + Modern Laboratory clarity.
- Primary palette derived from the supplied TSCO Analytical Lab visual: deep navy, corporate blue, teal, restrained violet accent, cool gray and white.
- The supplied TSCO Analytical Lab wordmark/background is used as a visual brand plate on public access and navigation surfaces.
- Operational pages remain predominantly white/high-contrast for laboratory readability.

## Functional scope
No workflow, authorization, database, API or migration behavior was intentionally changed by this branding pass.
