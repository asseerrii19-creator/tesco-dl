# Final Architecture Review — v2.6.9

Developer/IT review should confirm these structural decisions:

1. One platform, multiple sites: Corporate → Dammam / Jubail / Bahrain → Department → User.
2. Client isolation by company, with optional client hierarchy below each company.
3. Site-scoped and corporate-scoped configuration rather than separate site copies.
4. Runtime administration for sites, departments, clients, users/access, assets, controlled documents, test packages, workflows and approval policies.
5. Immutable operational identifiers are integration keys; display names are not integration keys.
6. Sampling Supervisor raises the operational requirement; Operations creates the official Sampling Order.
7. Direct client-delivered samples bypass field sampling and enter the same controlled Sample Intake & Distribution workspace.
8. Data Review, LMS Registration, Physical Receiving and Batch/Distribution are one operational workspace with distinct accountable audit events.
9. Laboratory processing begins only after `READY_FOR_LAB`.
10. Senior Chemist owns retained-sample operations; Quality owns compliance/QC oversight and read-only site audit visibility.
11. Quality routine duties are digitized as a server-published monthly distribution with rotating Primary/Backup chemists; published historical schedules are immutable from the browser and completions are audited.
12. **LMS is the official final job-closure and client-report system boundary.**
13. The platform can approve a result set as `READY_FOR_LMS`; that status is not an official report release.
14. `REPORT_RELEASED` is reserved for LMS-confirmed official report issuance.
15. Integration transactions require status/error/retry/reconciliation visibility.
16. Operational data lives in the configured database and is not replaced during application upgrades.
17. Production changes must be migration-backed and deployed with backup/rollback controls.
18. Phase-2 modules can be added without creating separate platform copies per site/client.

Detailed LMS boundary: `SYSTEM_BOUNDARY_LMS_REPORTING.md`.  
Quality rotation boundary: `QUALITY_CONTROL_DISTRIBUTION_v2.6.8.md`.
