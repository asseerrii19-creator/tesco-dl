# Branding Stage 5 — Laboratory Core Workspace

This pass completes the design refinement of the highest-frequency Laboratory Operations surfaces while preserving the v2.6.4 UAT functional baseline.

## Scope
- Samples & Batches: denser batch builder, corrected two-column balance, stronger requested-test hierarchy, and clearer sample-detail cards.
- Test Workstations: four-column operational launcher on wide screens, stronger station identity, cleaner batch/result-entry surfaces, and intentional empty states.
- Quality Control: clearer separation between QC entry and current QC decision state, denser material register, and improved QC-history presentation.
- Reports: two-column batch-review queue on wide screens, more focused individual-sample report view, and report-table visual normalization.
- Responsive behavior: explicit breakpoints for the laboratory core screens.

## Functional constraint
No workflow state, RBAC rule, route, persistence behavior, API/integration contract, calculation, QC rule, report release authorization, or laboratory method logic was changed.
