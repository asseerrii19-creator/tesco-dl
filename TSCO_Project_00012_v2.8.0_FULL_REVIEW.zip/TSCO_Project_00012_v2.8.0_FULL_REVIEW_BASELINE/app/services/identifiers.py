from __future__ import annotations

import secrets
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.dialects.sqlite import insert as sqlite_insert
from sqlalchemy.orm import Session

from ..models import IdentifierSequence, Site


def _next_sequence(db: Session, *, namespace: str, site: Site, year: str) -> int:
    """Allocate a monotonic sequence atomically inside the caller's transaction."""
    values = {"namespace": namespace, "site_id": site.id, "year": year, "current_value": 1}
    dialect = db.get_bind().dialect.name

    if dialect == "postgresql":
        stmt = pg_insert(IdentifierSequence).values(**values)
        stmt = stmt.on_conflict_do_update(
            constraint="uq_identifier_sequence_scope",
            set_={"current_value": IdentifierSequence.current_value + 1},
        ).returning(IdentifierSequence.current_value)
        return int(db.scalar(stmt))

    if dialect == "sqlite":
        stmt = sqlite_insert(IdentifierSequence).values(**values)
        stmt = stmt.on_conflict_do_update(
            index_elements=[IdentifierSequence.namespace, IdentifierSequence.site_id, IdentifierSequence.year],
            set_={"current_value": IdentifierSequence.current_value + 1},
        ).returning(IdentifierSequence.current_value)
        return int(db.scalar(stmt))

    row = db.scalar(
        select(IdentifierSequence)
        .where(
            IdentifierSequence.namespace == namespace,
            IdentifierSequence.site_id == site.id,
            IdentifierSequence.year == year,
        )
        .with_for_update()
    )
    if row is None:
        row = IdentifierSequence(**values)
        db.add(row)
        db.flush()
        return 1
    row.current_value += 1
    db.flush()
    return int(row.current_value)


def next_request_identifiers(db: Session, site: Site) -> tuple[str, str, str]:
    year = datetime.utcnow().strftime("%y")
    sequence = _next_sequence(db, namespace="sample_request", site=site, year=year)
    request_number = f"FS-{site.code}-{year}-{sequence:06d}"
    barcode_value = f"TSCO-{site.code}-{year}-{sequence:08d}"
    public_token = secrets.token_urlsafe(24)
    return request_number, barcode_value, public_token



def next_sampling_request_code(db: Session, site: Site) -> str:
    year = datetime.utcnow().strftime("%y")
    sequence = _next_sequence(db, namespace="sampling_request_notice", site=site, year=year)
    return f"SR-{site.code}-{year}-{sequence:05d}"


def next_sampling_order_identifiers(db: Session, site: Site) -> tuple[str, str]:
    year = datetime.utcnow().strftime("%y")
    sequence = _next_sequence(db, namespace="sampling_order", site=site, year=year)
    order_number = f"SO-{site.code}-{year}-{sequence:05d}"
    assignment_code = f"{site.code}-{secrets.token_hex(4).upper()}"
    return order_number, assignment_code


def next_assignment_code(site: Site) -> str:
    return f"{site.code}-{secrets.token_hex(5).upper()}"
