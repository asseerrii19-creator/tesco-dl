from __future__ import annotations

from pathlib import Path

from fastapi.templating import Jinja2Templates

from .lab_sections import lab_section_allowed

BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
templates.env.globals["lab_section_allowed"] = lab_section_allowed
