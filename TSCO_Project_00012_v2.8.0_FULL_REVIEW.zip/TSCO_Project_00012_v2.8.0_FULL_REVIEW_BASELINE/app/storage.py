from __future__ import annotations

import os
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("TSCO_DATA_DIR", str(APP_DIR / "data"))).expanduser().resolve()
UPLOAD_DIR = DATA_DIR / "uploads"
BARCODE_DIR = DATA_DIR / "barcodes"
CONTROLLED_DOCUMENT_DIR = DATA_DIR / "controlled_documents"

for directory in (DATA_DIR, UPLOAD_DIR, BARCODE_DIR, CONTROLLED_DOCUMENT_DIR):
    directory.mkdir(parents=True, exist_ok=True)
