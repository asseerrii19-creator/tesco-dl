from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import Role, User
from ..role_matrix import ROLE_REVIEW_MATRIX
from ..security import require_user

router = APIRouter(prefix="/review-guide", tags=["review guide"])
ALLOWED = {Role.SYSTEM_ADMIN.value}

@router.get("")
def review_guide(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    users = db.scalars(select(User).where(User.active.is_(True)).order_by(User.role, User.full_name)).all()
    rows = []
    for role, spec in ROLE_REVIEW_MATRIX.items():
        rows.append({"role": role, **spec, "accounts": [u for u in users if u.role == role]})
    return templates.TemplateResponse("review_guide.html", {"request": request, "user": user, "roles": rows})
