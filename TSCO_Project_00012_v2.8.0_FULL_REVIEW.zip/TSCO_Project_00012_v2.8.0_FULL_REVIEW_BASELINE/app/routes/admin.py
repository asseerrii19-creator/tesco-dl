from __future__ import annotations

import csv
import io
import json
import re
import secrets
import zipfile
from pathlib import Path
from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from urllib.parse import urlencode
from fastapi.responses import RedirectResponse
from sqlalchemy import func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import (
    Asset,
    AuditLog,
    Client,
    ClientUnit,
    ControlledDocument,
    Department,
    PurchaseOrder,
    SamplingOrder,
    Quotation,
    Role,
    SampleRequest,
    Site,
    TestPackageConfig,
    WorkflowDefinition,
    WorkflowStep,
    ApprovalPolicy,
    IntegrationQueueItem,
    User,
    UserClientAssignment,
    UserClientUnitAssignment,
)
from ..security import hash_password, require_user
from ..services.audit import add_audit
from ..storage import CONTROLLED_DOCUMENT_DIR

router = APIRouter(prefix="/admin", tags=["administration"])
ALLOWED = {Role.SYSTEM_ADMIN.value}
ROLE_OPTIONS = [role.value for role in Role]


def _admin(request: Request, db: Session) -> User:
    return require_user(request, db, ALLOWED)


def _redirect(path: str, *, ok: str = "", error: str = "") -> RedirectResponse:
    params = {}
    if ok:
        params["ok"] = ok
    if error:
        params["error"] = error
    return RedirectResponse(path + (("?" + urlencode(params)) if params else ""), status_code=303)


def _active_site(db: Session, site_id: int | None) -> Site | None:
    if site_id is None:
        return None
    site = db.get(Site, site_id)
    return site if site and site.active else None


def _active_client(db: Session, client_id: int | None) -> Client | None:
    if client_id is None:
        return None
    client = db.get(Client, client_id)
    return client if client and client.active else None


def _active_ids(db: Session, model, ids: set[int]) -> set[int]:
    if not ids:
        return set()
    return set(db.scalars(select(model.id).where(model.id.in_(ids), model.active.is_(True))).all())


_CODE_RE = re.compile(r"^[A-Z0-9][A-Z0-9_-]*$")


def _parse_optional_int(value: str, label: str) -> int | None:
    clean = (value or "").strip()
    if not clean:
        return None
    if not clean.isdigit():
        raise ValueError(f"{label} is invalid")
    return int(clean)


def _bounded(value: str, label: str, maximum: int, *, required: bool = False) -> str:
    clean = (value or "").strip()
    if required and not clean:
        raise ValueError(f"{label} is required")
    if len(clean) > maximum:
        raise ValueError(f"{label} must be {maximum} characters or fewer")
    return clean


def _bounded_code(value: str, label: str, maximum: int, *, minimum: int = 1) -> str:
    clean = (value or "").strip().upper()
    if not (minimum <= len(clean) <= maximum) or not _CODE_RE.fullmatch(clean):
        raise ValueError(f"{label} must be {minimum}-{maximum} characters using A-Z, 0-9, _ or -")
    return clean


@router.get("")
def dashboard(request: Request, db: Session = Depends(get_db)):
    user = _admin(request, db)
    counts = {
        "clients": db.scalar(select(func.count()).select_from(Client)) or 0,
        "sites": db.scalar(select(func.count()).select_from(Site)) or 0,
        "departments": db.scalar(select(func.count()).select_from(Department).where(Department.active.is_(True))) or 0,
        "client_units": db.scalar(select(func.count()).select_from(ClientUnit).where(ClientUnit.active.is_(True))) or 0,
        "workflows": db.scalar(select(func.count()).select_from(WorkflowDefinition).where(WorkflowDefinition.active.is_(True))) or 0,
        "integration_pending": db.scalar(select(func.count()).select_from(IntegrationQueueItem).where(IntegrationQueueItem.status.in_(["PENDING","FAILED"]))) or 0,
        "documents": db.scalar(select(func.count()).select_from(ControlledDocument).where(ControlledDocument.status == "ACTIVE")) or 0,
        "packages": db.scalar(select(func.count()).select_from(TestPackageConfig).where(TestPackageConfig.active.is_(True))) or 0,
        "users": db.scalar(select(func.count()).select_from(User)) or 0,
        "assets": db.scalar(select(func.count()).select_from(Asset)) or 0,
        "samples": db.scalar(select(func.count()).select_from(SampleRequest)) or 0,
        "orders": db.scalar(select(func.count()).select_from(SamplingOrder)) or 0,
        "open_orders": db.scalar(select(func.count()).select_from(SamplingOrder).where(SamplingOrder.status != "COMPLETED")) or 0,
        "intake_pending": db.scalar(select(func.count()).select_from(SampleRequest).where(SampleRequest.status.in_(["SUBMITTED", "RETURNED", "ACCEPTED", "AWAITING_RECEIPT", "RECEIVED"]))) or 0,
        "lab_active": db.scalar(select(func.count()).select_from(SampleRequest).where(SampleRequest.status.in_(["READY_FOR_LAB", "REGISTERED", "TESTING"]))) or 0,
        "technical_review": db.scalar(select(func.count()).select_from(SampleRequest).where(SampleRequest.status == "TECHNICAL_REVIEW")) or 0,
    }
    sites = db.scalars(select(Site).order_by(Site.code)).all()
    recent = db.scalars(select(AuditLog).order_by(AuditLog.created_at.desc()).limit(12)).all()
    return templates.TemplateResponse(
        "admin_dashboard.html",
        {"request": request, "user": user, "counts": counts, "sites": sites, "recent": recent},
    )


@router.get("/clients")
def clients_page(request: Request, ok: str = "", error: str = "", db: Session = Depends(get_db)):
    user = _admin(request, db)
    clients = db.scalars(select(Client).order_by(Client.active.desc(), Client.name)).all()
    return templates.TemplateResponse(
        "admin_clients.html",
        {"request": request, "user": user, "clients": clients, "ok": ok, "error": error},
    )


@router.post("/clients")
def create_client(
    request: Request,
    code: str = Form(...),
    name: str = Form(...),
    contact_email: str = Form(""),
    contact_phone: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    user = _admin(request, db)
    try:
        code = _bounded_code(code, "Company code", 24, minimum=2)
        name = _bounded(name, "Company name", 180, required=True)
        contact_email = _bounded(contact_email, "Contact email", 180)
        contact_phone = _bounded(contact_phone, "Contact phone", 60)
    except ValueError as exc:
        return _redirect("/admin/clients", error=str(exc))
    client = Client(
        code=code,
        name=name,
        contact_email=contact_email,
        contact_phone=contact_phone,
        notes=notes.strip(),
    )
    db.add(client)
    try:
        db.flush()
        add_audit(
            db,
            actor=user,
            request=request,
            action="CLIENT_CREATED",
            entity_type="Client",
            entity_id=client.id,
            summary=f"Created client {client.code} — {client.name}",
        )
        db.commit()
    except IntegrityError:
        db.rollback()
        return _redirect("/admin/clients", error="Company code already exists")
    return _redirect("/admin/clients", ok="Company added")


@router.post("/clients/{client_id}/update")
def update_client(
    client_id: int,
    request: Request,
    name: str = Form(...),
    contact_email: str = Form(""),
    contact_phone: str = Form(""),
    notes: str = Form(""),
    db: Session = Depends(get_db),
):
    user = _admin(request, db)
    client = db.get(Client, client_id)
    if not client:
        return _redirect("/admin/clients", error="Company not found")
    try:
        client.name = _bounded(name, "Company name", 180, required=True)
        client.contact_email = _bounded(contact_email, "Contact email", 180)
        client.contact_phone = _bounded(contact_phone, "Contact phone", 60)
    except ValueError as exc:
        return _redirect("/admin/clients", error=str(exc))
    client.notes = notes.strip()
    add_audit(
        db,
        actor=user,
        request=request,
        action="CLIENT_UPDATED",
        entity_type="Client",
        entity_id=client.id,
        summary=f"Updated client {client.code}",
    )
    db.commit()
    return _redirect("/admin/clients", ok="Company updated")


@router.post("/clients/{client_id}/toggle")
def toggle_client(client_id: int, request: Request, db: Session = Depends(get_db)):
    user = _admin(request, db)
    client = db.get(Client, client_id)
    if client:
        client.active = not client.active
        add_audit(
            db,
            actor=user,
            request=request,
            action="CLIENT_STATUS_CHANGED",
            entity_type="Client",
            entity_id=client.id,
            summary=f"{client.code} set to {'Active' if client.active else 'Inactive'}",
        )
        db.commit()
    return RedirectResponse("/admin/clients", status_code=303)


@router.get("/users")
def users_page(request: Request, ok: str = "", error: str = "", db: Session = Depends(get_db)):
    user = _admin(request, db)
    users = db.scalars(select(User).order_by(User.active.desc(), User.full_name)).all()
    clients = db.scalars(select(Client).where(Client.active.is_(True)).order_by(Client.name)).all()
    sites = db.scalars(select(Site).order_by(Site.code)).all()
    departments = db.scalars(select(Department).order_by(Department.name)).all()
    client_units = db.scalars(select(ClientUnit).where(ClientUnit.active.is_(True)).order_by(ClientUnit.client_id, ClientUnit.unit_type, ClientUnit.name)).all()
    return templates.TemplateResponse(
        "admin_users.html",
        {
            "request": request,
            "user": user,
            "users": users,
            "clients": clients,
            "sites": sites,
            "departments": departments,
            "client_units": client_units,
            "roles": ROLE_OPTIONS,
            "ok": ok,
            "error": error,
        },
    )


@router.post("/users")
def create_user(
    request: Request,
    email: str = Form(...),
    full_name: str = Form(...),
    role: str = Form(...),
    password: str = Form(...),
    job_title: str = Form(""),
    phone: str = Form(""),
    site_id: str = Form(""),
    department_id: str = Form(""),
    client_id: str = Form(""),
    assigned_client_ids: list[int] = Form(default=[]),
    assigned_client_unit_ids: list[int] = Form(default=[]),
    db: Session = Depends(get_db),
):
    actor = _admin(request, db)
    if role not in ROLE_OPTIONS:
        return _redirect("/admin/users", error="Invalid role")
    if len(password) < 10:
        return _redirect("/admin/users", error="Temporary password must be at least 10 characters")
    try:
        email = _bounded(email.lower(), "Email", 180, required=True)
        full_name = _bounded(full_name, "Full name", 160, required=True)
        job_title = _bounded(job_title, "Job title", 120)
        phone = _bounded(phone, "Phone", 60)
        linked_client_id = _parse_optional_int(client_id, "Client")
        linked_site_id = _parse_optional_int(site_id, "Site")
        linked_department_id = _parse_optional_int(department_id, "Department")
    except ValueError as exc:
        return _redirect("/admin/users", error=str(exc))
    if "@" not in email:
        return _redirect("/admin/users", error="Valid email is required")
    if linked_site_id is not None and not _active_site(db, linked_site_id):
        return _redirect("/admin/users", error="Selected site is missing or inactive")
    linked_client = _active_client(db, linked_client_id) if linked_client_id is not None else None
    if role in {Role.CLIENT.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value} and not linked_client:
        return _redirect("/admin/users", error="Client users must be linked to an active company")
    department = db.get(Department, linked_department_id) if linked_department_id is not None else None
    if linked_department_id is not None and (not department or not department.active):
        return _redirect("/admin/users", error="Selected department is missing or inactive")
    if department and department.site_id is not None and department.site_id != linked_site_id:
        return _redirect("/admin/users", error="Department must belong to the selected site")
    requested_clients = set(assigned_client_ids)
    if role not in {Role.CLIENT.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value} and _active_ids(db, Client, requested_clients) != requested_clients:
        return _redirect("/admin/users", error="One or more assigned companies are missing or inactive")
    new_user = User(
        email=email,
        full_name=full_name,
        password_hash=hash_password(password),
        role=role,
        job_title=job_title,
        phone=phone,
        client_id=linked_client_id if role in {Role.CLIENT.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value} else None,
        site_id=linked_site_id,
        department_id=linked_department_id,
        must_change_password=True,
    )
    db.add(new_user)
    try:
        db.flush()
        if role not in {Role.CLIENT.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value}:
            for cid in sorted(set(assigned_client_ids)):
                db.add(UserClientAssignment(user_id=new_user.id, client_id=cid))
        else:
            valid_units = db.scalars(select(ClientUnit).where(ClientUnit.id.in_(set(assigned_client_unit_ids)), ClientUnit.client_id == linked_client_id, ClientUnit.active.is_(True))).all() if assigned_client_unit_ids else []
            if len(valid_units) != len(set(assigned_client_unit_ids)):
                db.rollback()
                return _redirect("/admin/users", error="One or more client organization units are invalid or inactive")
            for unit in valid_units:
                db.add(UserClientUnitAssignment(user_id=new_user.id, client_unit_id=unit.id))
        add_audit(
            db,
            actor=actor,
            request=request,
            action="USER_CREATED",
            entity_type="User",
            entity_id=new_user.id,
            summary=f"Created {new_user.email} as {new_user.role}",
        )
        db.commit()
    except IntegrityError:
        db.rollback()
        return _redirect("/admin/users", error="Email already exists or assignment is duplicated")
    return _redirect("/admin/users", ok="User created")


@router.post("/users/{user_id}/toggle")
def toggle_user(user_id: int, request: Request, db: Session = Depends(get_db)):
    actor = _admin(request, db)
    target = db.get(User, user_id)
    if target and target.id != actor.id:
        target.active = not target.active
        add_audit(
            db,
            actor=actor,
            request=request,
            action="USER_STATUS_CHANGED",
            entity_type="User",
            entity_id=target.id,
            summary=f"{target.email} set to {'Active' if target.active else 'Inactive'}",
        )
        db.commit()
    return RedirectResponse("/admin/users", status_code=303)




@router.post("/users/{user_id}/profile")
def update_user_profile(
    user_id: int,
    request: Request,
    full_name: str = Form(...),
    role: str = Form(...),
    job_title: str = Form(""),
    phone: str = Form(""),
    site_id: str = Form(""),
    department_id: str = Form(""),
    client_id: str = Form(""),
    db: Session = Depends(get_db),
):
    actor = _admin(request, db)
    target = db.get(User, user_id)
    if not target:
        return _redirect("/admin/users", error="User not found")
    if role not in ROLE_OPTIONS:
        return _redirect("/admin/users", error="Invalid role")
    try:
        full_name = _bounded(full_name, "Full name", 160, required=True)
        job_title = _bounded(job_title, "Job title", 120)
        phone = _bounded(phone, "Phone", 60)
        linked_client_id = _parse_optional_int(client_id, "Client")
        linked_site_id = _parse_optional_int(site_id, "Site")
        linked_department_id = _parse_optional_int(department_id, "Department")
    except ValueError as exc:
        return _redirect("/admin/users", error=str(exc))
    if linked_site_id is not None and not _active_site(db, linked_site_id):
        return _redirect("/admin/users", error="Selected site is missing or inactive")
    linked_client = _active_client(db, linked_client_id) if linked_client_id is not None else None
    if role in {Role.CLIENT.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value} and not linked_client:
        return _redirect("/admin/users", error="Client accounts must be linked to an active company")
    department = db.get(Department, linked_department_id) if linked_department_id is not None else None
    if linked_department_id is not None and (not department or not department.active):
        return _redirect("/admin/users", error="Selected department is missing or inactive")
    if department and department.site_id is not None and department.site_id != linked_site_id:
        return _redirect("/admin/users", error="Department must belong to the selected site")
    target.full_name = full_name
    target.role = role
    target.job_title = job_title
    target.phone = phone
    target.site_id = linked_site_id
    target.department_id = linked_department_id
    target.client_id = linked_client_id if role in {Role.CLIENT.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value} else None
    if target.client_id is not None:
        for row in list(target.client_assignments):
            db.delete(row)
        for row in list(target.client_unit_assignments):
            if row.client_unit.client_id != target.client_id:
                db.delete(row)
    else:
        for row in list(target.client_unit_assignments):
            db.delete(row)
    add_audit(db, actor=actor, request=request, action="USER_PROFILE_UPDATED", entity_type="User", entity_id=target.id, summary=f"Updated role/site profile for {target.email}")
    db.commit()
    return _redirect("/admin/users", ok="User profile updated")

@router.post("/users/{user_id}/password")
def reset_password(
    user_id: int,
    request: Request,
    temporary_password: str = Form(...),
    db: Session = Depends(get_db),
):
    actor = _admin(request, db)
    target = db.get(User, user_id)
    if not target:
        return _redirect("/admin/users", error="User not found")
    if len(temporary_password) < 10:
        return _redirect("/admin/users", error="Temporary password must be at least 10 characters")
    target.password_hash = hash_password(temporary_password)
    target.must_change_password = True
    add_audit(
        db,
        actor=actor,
        request=request,
        action="PASSWORD_RESET",
        entity_type="User",
        entity_id=target.id,
        summary=f"Temporary password issued for {target.email}",
    )
    db.commit()
    return _redirect("/admin/users", ok="Temporary password set")


@router.post("/users/{user_id}/assignments")
def update_assignments(
    user_id: int,
    request: Request,
    assigned_client_ids: list[int] = Form(default=[]),
    db: Session = Depends(get_db),
):
    actor = _admin(request, db)
    target = db.get(User, user_id)
    if not target or target.role in {Role.CLIENT.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value}:
        return _redirect("/admin/users", error="Assignments apply to employee users only")
    requested_clients = set(assigned_client_ids)
    if _active_ids(db, Client, requested_clients) != requested_clients:
        return _redirect("/admin/users", error="One or more assigned companies are missing or inactive")
    existing = db.scalars(select(UserClientAssignment).where(UserClientAssignment.user_id == target.id)).all()
    for row in existing:
        db.delete(row)
    db.flush()  # enforce delete-before-insert ordering for unique user/client pairs
    for cid in sorted(set(assigned_client_ids)):
        db.add(UserClientAssignment(user_id=target.id, client_id=cid))
    add_audit(
        db,
        actor=actor,
        request=request,
        action="CLIENT_ASSIGNMENTS_UPDATED",
        entity_type="User",
        entity_id=target.id,
        summary=f"Updated company scope for {target.email}",
        details={"client_ids": assigned_client_ids},
    )
    db.commit()
    return _redirect("/admin/users", ok="Company assignments updated")


@router.post("/users/{user_id}/client-unit-scope")
def update_client_unit_scope(
    user_id: int,
    request: Request,
    assigned_client_unit_ids: list[int] = Form(default=[]),
    db: Session = Depends(get_db),
):
    actor = _admin(request, db)
    target = db.get(User, user_id)
    if not target or target.role not in {Role.CLIENT.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value} or not target.client_id:
        return _redirect("/admin/users", error="Unit scope applies to client accounts only")
    existing = db.scalars(select(UserClientUnitAssignment).where(UserClientUnitAssignment.user_id == target.id)).all()
    for row in existing:
        db.delete(row)
    db.flush()  # enforce delete-before-insert ordering for unique user/unit pairs
    requested_unit_ids = set(assigned_client_unit_ids)
    valid_units = db.scalars(
        select(ClientUnit).where(
            ClientUnit.id.in_(requested_unit_ids),
            ClientUnit.client_id == target.client_id,
            ClientUnit.active.is_(True),
        )
    ).all() if requested_unit_ids else []
    if {unit.id for unit in valid_units} != requested_unit_ids:
        db.rollback()
        return _redirect("/admin/users", error="One or more client organization units are invalid or inactive")
    for unit in valid_units:
        db.add(UserClientUnitAssignment(user_id=target.id, client_unit_id=unit.id))
    add_audit(
        db, actor=actor, request=request, action="CLIENT_UNIT_SCOPE_UPDATED", entity_type="User", entity_id=target.id,
        summary=f"Updated organization scope for {target.email}", details={"client_unit_ids": [u.id for u in valid_units]},
    )
    db.commit()
    return _redirect("/admin/users", ok="Client organization scope updated")


@router.get("/commercial")
def commercial_page(request: Request, ok: str = "", error: str = "", db: Session = Depends(get_db)):
    user = _admin(request, db)
    clients = db.scalars(select(Client).where(Client.active.is_(True)).order_by(Client.name)).all()
    quotes = db.scalars(select(Quotation).order_by(Quotation.id.desc()).limit(150)).all()
    pos = db.scalars(select(PurchaseOrder).order_by(PurchaseOrder.id.desc()).limit(150)).all()
    return templates.TemplateResponse(
        "admin_commercial.html",
        {"request": request, "user": user, "clients": clients, "quotes": quotes, "pos": pos, "ok": ok, "error": error},
    )


@router.post("/commercial/quotation")
def create_quotation(
    request: Request,
    client_id: int = Form(...),
    number: str = Form(...),
    description: str = Form(""),
    db: Session = Depends(get_db),
):
    actor = _admin(request, db)
    client = _active_client(db, client_id)
    try:
        number = _bounded(number, "Quotation number", 80, required=True)
        description = _bounded(description, "Quotation description", 240)
    except ValueError as exc:
        return _redirect("/admin/commercial", error=str(exc))
    if not client:
        return _redirect("/admin/commercial", error="Active company is required")
    quote = Quotation(client_id=client_id, number=number, description=description)
    db.add(quote)
    try:
        db.flush()
        add_audit(db, actor=actor, request=request, action="QUOTATION_CREATED", entity_type="Quotation", entity_id=quote.id, summary=f"Created quotation {quote.number}")
        db.commit()
    except IntegrityError:
        db.rollback()
        return _redirect("/admin/commercial", error="Quotation already exists for this company")
    return _redirect("/admin/commercial", ok="Quotation added")


@router.post("/commercial/po")
def create_po(
    request: Request,
    client_id: int = Form(...),
    number: str = Form(...),
    quotation_id: str = Form(""),
    db: Session = Depends(get_db),
):
    actor = _admin(request, db)
    client = _active_client(db, client_id)
    try:
        quote_id = _parse_optional_int(quotation_id, "Quotation")
        number = _bounded(number, "PO number", 80, required=True)
    except ValueError as exc:
        return _redirect("/admin/commercial", error=str(exc))
    quote = db.get(Quotation, quote_id) if quote_id else None
    if not client:
        return _redirect("/admin/commercial", error="Active company is required")
    if quotation_id and (not quote or quote.client_id != client_id or quote.status != "ACTIVE"):
        return _redirect("/admin/commercial", error="Quotation must be active and belong to the selected company")
    po = PurchaseOrder(client_id=client_id, number=number, quotation_id=quote.id if quote else None)
    db.add(po)
    try:
        db.flush()
        add_audit(db, actor=actor, request=request, action="PO_CREATED", entity_type="PurchaseOrder", entity_id=po.id, summary=f"Created PO {po.number}")
        db.commit()
    except IntegrityError:
        db.rollback()
        return _redirect("/admin/commercial", error="PO already exists for this company")
    return _redirect("/admin/commercial", ok="Purchase order added")


@router.get("/assets")
def assets_page(request: Request, ok: str = "", error: str = "", db: Session = Depends(get_db)):
    user = _admin(request, db)
    clients = db.scalars(select(Client).where(Client.active.is_(True)).order_by(Client.name)).all()
    client_units = db.scalars(select(ClientUnit).where(ClientUnit.active.is_(True)).order_by(ClientUnit.client_id, ClientUnit.unit_type, ClientUnit.name)).all()
    assets = db.scalars(select(Asset).order_by(Asset.id.desc()).limit(250)).all()
    return templates.TemplateResponse(
        "admin_assets.html",
        {"request": request, "user": user, "clients": clients, "client_units": client_units, "assets": assets, "ok": ok, "error": error},
    )


@router.post("/assets")
def create_asset(
    request: Request,
    client_id: int = Form(...),
    client_unit_id: str = Form(""),
    asset_code: str = Form(...),
    serial_number: str = Form(...),
    equipment_type: str = Form("Power Transformer"),
    manufacturer: str = Form(""),
    voltage_kv: str = Form(""),
    rated_mva: str = Form(""),
    hv_voltage_kv: str = Form(""),
    lv_voltage_kv: str = Form(""),
    sealing_system: str = Form(""),
    cooling_type: str = Form(""),
    manufacturer_country: str = Form(""),
    manufacture_year: str = Form(""),
    oil_type: str = Form(""),
    oil_weight_kg: str = Form(""),
    owner_name: str = Form(""),
    tap_changer_type: str = Form(""),
    tap_changer_chamber: str = Form(""),
    tag_number: str = Form(""),
    phase: str = Form(""),
    operating_period: str = Form(""),
    sampling_points: str = Form(""),
    station_name: str = Form(""),
    asset_location_label: str = Form(""),
    latitude: str = Form(""),
    longitude: str = Form(""),
    db: Session = Depends(get_db),
):
    actor = _admin(request, db)
    client = _active_client(db, client_id)
    if not client:
        return _redirect("/admin/assets", error="Selected company is missing or inactive")
    try:
        asset_code = _bounded(asset_code, "Asset code", 80, required=True)
        serial_number = _bounded(serial_number, "Serial number", 120, required=True)
        equipment_type = _bounded(equipment_type, "Equipment type", 80) or "Power Transformer"
        manufacturer = _bounded(manufacturer, "Manufacturer", 120)
        station_name = _bounded(station_name, "Station name", 160)
        asset_location_label = _bounded(asset_location_label, "Asset location", 200)
        unit_id = _parse_optional_int(client_unit_id, "Organization unit")
    except ValueError as exc:
        return _redirect("/admin/assets", error=str(exc))
    if unit_id:
        unit = db.get(ClientUnit, unit_id)
        if not unit or not unit.active or unit.client_id != client_id:
            return _redirect("/admin/assets", error="Active organization unit must belong to the selected company")
    def f(value: str):
        return float(value) if value.strip() else None
    try:
        latitude_value, longitude_value = f(latitude), f(longitude)
        if latitude_value is not None and not -90 <= latitude_value <= 90:
            raise ValueError("Latitude must be between -90 and 90")
        if longitude_value is not None and not -180 <= longitude_value <= 180:
            raise ValueError("Longitude must be between -180 and 180")
    except ValueError:
        return _redirect("/admin/assets", error="Asset numeric fields or coordinates are invalid")
    asset = Asset(
        client_id=client_id,
        client_unit_id=unit_id,
        asset_code=asset_code,
        serial_number=serial_number,
        equipment_type=equipment_type,
        manufacturer=manufacturer,
        voltage_kv=f(voltage_kv),
        rated_mva=f(rated_mva),
        hv_voltage_kv=f(hv_voltage_kv),
        lv_voltage_kv=f(lv_voltage_kv),
        sealing_system=sealing_system.strip()[:100],
        cooling_type=cooling_type.strip()[:100],
        manufacturer_country=manufacturer_country.strip()[:100],
        manufacture_year=int(manufacture_year) if manufacture_year.strip() else None,
        oil_type=oil_type.strip()[:120],
        oil_weight_kg=f(oil_weight_kg),
        owner_name=owner_name.strip()[:180],
        tap_changer_type=tap_changer_type.strip()[:100],
        tap_changer_chamber=tap_changer_chamber.strip()[:100],
        tag_number=tag_number.strip()[:100],
        phase=phase.strip()[:40],
        operating_period=operating_period.strip()[:100],
        sampling_points_json=json.dumps([x.strip() for x in sampling_points.split(",") if x.strip()]),
        station_name=station_name,
        asset_location_label=asset_location_label,
        latitude=latitude_value,
        longitude=longitude_value,
    )
    db.add(asset)
    try:
        db.flush()
        add_audit(db, actor=actor, request=request, action="ASSET_CREATED", entity_type="Asset", entity_id=asset.id, summary=f"Created asset {asset.asset_code}")
        db.commit()
    except (IntegrityError, ValueError):
        db.rollback()
        return _redirect("/admin/assets", error="Asset code exists or numeric fields are invalid")
    return _redirect("/admin/assets", ok="Asset added")


@router.post("/assets/{asset_id}/toggle")
def toggle_asset(asset_id: int, request: Request, db: Session = Depends(get_db)):
    actor = _admin(request, db)
    asset = db.get(Asset, asset_id)
    if asset:
        asset.active = not asset.active
        add_audit(db, actor=actor, request=request, action="ASSET_STATUS_CHANGED", entity_type="Asset", entity_id=asset.id, summary=f"{asset.asset_code} set to {'Active' if asset.active else 'Inactive'}")
        db.commit()
    return RedirectResponse("/admin/assets", status_code=303)


@router.get("/import")
def import_page(request: Request, db: Session = Depends(get_db)):
    user = _admin(request, db)
    return templates.TemplateResponse(
        "admin_import.html",
        {"request": request, "user": user, "result": None, "errors": []},
    )


@router.post("/import")
def import_master_data(
    request: Request,
    import_type: str = Form(...),
    csv_file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    actor = _admin(request, db)
    max_csv_bytes = 5_000_000
    raw_bytes = csv_file.file.read(max_csv_bytes + 1)
    if len(raw_bytes) > max_csv_bytes:
        return templates.TemplateResponse(
            "admin_import.html",
            {"request": request, "user": actor, "result": None, "errors": ["CSV file must be 5 MB or smaller"]},
            status_code=413,
        )
    try:
        raw = raw_bytes.decode("utf-8-sig")
    except UnicodeDecodeError:
        return templates.TemplateResponse(
            "admin_import.html",
            {"request": request, "user": actor, "result": None, "errors": ["CSV must use UTF-8 encoding"]},
            status_code=400,
        )
    reader = csv.DictReader(io.StringIO(raw))
    inserted = 0
    skipped = 0
    errors: list[str] = []

    def num(value: str | None):
        return float(value) if value and value.strip() else None

    for row_number, row in enumerate(reader, start=2):
        if row_number > 10_001:
            errors.append("CSV import is limited to 10,000 data rows")
            inserted = 0
            db.rollback()
            break
        try:
            if import_type == "clients":
                code = _bounded_code(row.get("code") or "", "client code", 24, minimum=2)
                name = _bounded(row.get("name") or "", "client name", 180, required=True)
                contact_email = _bounded(row.get("contact_email") or "", "contact email", 180)
                contact_phone = _bounded(row.get("contact_phone") or "", "contact phone", 60)
                if db.scalar(select(Client).where(Client.code == code)):
                    skipped += 1
                    continue
                db.add(
                    Client(
                        code=code,
                        name=name,
                        contact_email=contact_email,
                        contact_phone=contact_phone,
                        notes=(row.get("notes") or "").strip(),
                    )
                )
                db.flush()
                inserted += 1
            elif import_type == "assets":
                client_code = _bounded_code(row.get("client_code") or "", "client code", 24, minimum=2)
                asset_code = _bounded(row.get("asset_code") or "", "asset code", 80, required=True)
                serial_number = _bounded(row.get("serial_number") or "", "serial number", 120, required=True)
                equipment_type = _bounded(row.get("equipment_type") or "Power Transformer", "equipment type", 80) or "Power Transformer"
                manufacturer = _bounded(row.get("manufacturer") or "", "manufacturer", 120)
                station_name = _bounded(row.get("station_name") or "", "station name", 160)
                asset_location_label = _bounded(row.get("asset_location_label") or "", "asset location", 200)
                client = db.scalar(select(Client).where(Client.code == client_code, Client.active.is_(True)))
                if not client:
                    raise ValueError(f"unknown or inactive client_code {client_code}")
                if db.scalar(select(Asset).where(Asset.client_id == client.id, Asset.asset_code == asset_code)):
                    skipped += 1
                    continue
                latitude_value, longitude_value = num(row.get("latitude")), num(row.get("longitude"))
                if latitude_value is not None and not -90 <= latitude_value <= 90:
                    raise ValueError("latitude must be between -90 and 90")
                if longitude_value is not None and not -180 <= longitude_value <= 180:
                    raise ValueError("longitude must be between -180 and 180")
                db.add(
                    Asset(
                        client_id=client.id,
                        asset_code=asset_code,
                        serial_number=serial_number,
                        equipment_type=equipment_type,
                        manufacturer=manufacturer,
                        voltage_kv=num(row.get("voltage_kv")),
                        rated_mva=num(row.get("rated_mva")),
                        station_name=station_name,
                        asset_location_label=asset_location_label,
                        latitude=latitude_value,
                        longitude=longitude_value,
                    )
                )
                db.flush()
                inserted += 1
            else:
                raise ValueError("unsupported import type")
        except (ValueError, IntegrityError) as exc:
            db.rollback()
            errors.append(f"Row {row_number}: {exc}")
            # A rollback clears prior uncommitted rows; commit successful rows per batch below is avoided.
            # Restart the count conservatively and stop to prevent a misleading partial import.
            inserted = 0
            break

    if not errors:
        add_audit(
            db,
            actor=actor,
            request=request,
            action="MASTER_DATA_IMPORTED",
            entity_type=import_type,
            summary=f"Imported {inserted} {import_type}; skipped {skipped}",
            details={"filename": csv_file.filename, "inserted": inserted, "skipped": skipped},
        )
        db.commit()
    return templates.TemplateResponse(
        "admin_import.html",
        {
            "request": request,
            "user": actor,
            "result": {"inserted": inserted, "skipped": skipped, "type": import_type} if not errors else None,
            "errors": errors,
        },
        status_code=400 if errors else 200,
    )


@router.get("/audit")
def audit_page(request: Request, q: str = "", db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.QUALITY.value, Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value})
    stmt = select(AuditLog).order_by(AuditLog.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        stmt = stmt.where(
            or_(AuditLog.site_id == user.site_id, AuditLog.actor.has(User.site_id == user.site_id))
        )
    if q.strip():
        term = f"%{q.strip()}%"
        stmt = stmt.where(
            AuditLog.summary.ilike(term) | AuditLog.action.ilike(term) | AuditLog.entity_type.ilike(term)
        )
    rows = db.scalars(stmt.limit(500)).all()
    return templates.TemplateResponse("admin_audit.html", {"request": request, "user": user, "rows": rows, "q": q})


DOC_DIR = CONTROLLED_DOCUMENT_DIR
MAX_CONTROLLED_DOCUMENT_BYTES = 10 * 1024 * 1024


def _document_scope_filter(stmt, site_id: int | None):
    return stmt.where(ControlledDocument.site_id.is_(None)) if site_id is None else stmt.where(ControlledDocument.site_id == site_id)


def _document_bytes_valid(suffix: str, payload: bytes) -> bool:
    if not payload or len(payload) > MAX_CONTROLLED_DOCUMENT_BYTES:
        return False
    if suffix == ".pdf":
        return payload.startswith(b"%PDF-")
    if suffix in {".docx", ".xlsx"}:
        if not payload.startswith(b"PK\x03\x04"):
            return False
        try:
            with zipfile.ZipFile(io.BytesIO(payload)) as archive:
                names = set(archive.namelist())
                if "[Content_Types].xml" not in names:
                    return False
                required_prefix = "word/" if suffix == ".docx" else "xl/"
                return any(name.startswith(required_prefix) for name in names)
        except (zipfile.BadZipFile, OSError):
            return False
    if suffix in {".doc", ".xls"}:
        return payload.startswith(bytes.fromhex("D0CF11E0A1B11AE1"))
    if suffix == ".txt":
        if b"\x00" in payload[:4096]:
            return False
        try:
            payload[:65536].decode("utf-8")
            return True
        except UnicodeDecodeError:
            try:
                payload[:65536].decode("latin-1")
                return True
            except UnicodeDecodeError:
                return False
    return False


@router.get("/sites")
def sites_page(request: Request, ok: str = "", error: str = "", db: Session = Depends(get_db)):
    user = _admin(request, db)
    sites = db.scalars(select(Site).order_by(Site.active.desc(), Site.code)).all()
    return templates.TemplateResponse("admin_sites.html", {"request": request, "user": user, "sites": sites, "ok": ok, "error": error})


@router.post("/sites")
def create_site(
    request: Request,
    code: str = Form(...),
    name: str = Form(...),
    laboratory_name: str = Form(...),
    db: Session = Depends(get_db),
):
    actor = _admin(request, db)
    try:
        code = _bounded_code(code, "Site code", 12, minimum=2)
        name = _bounded(name, "Site name", 120, required=True)
        laboratory_name = _bounded(laboratory_name, "Laboratory name", 160, required=True)
    except ValueError as exc:
        return _redirect("/admin/sites", error=str(exc))
    site = Site(code=code, name=name, laboratory_name=laboratory_name, active=True)
    db.add(site)
    try:
        db.flush()
        add_audit(db, actor=actor, request=request, action="SITE_CREATED", entity_type="Site", entity_id=site.id, summary=f"Created site {site.code} — {site.name}")
        db.commit()
    except IntegrityError:
        db.rollback()
        return _redirect("/admin/sites", error="Site code already exists")
    return _redirect("/admin/sites", ok="Site added")


@router.post("/sites/{site_id}/update")
def update_site(site_id: int, request: Request, name: str = Form(...), laboratory_name: str = Form(...), db: Session = Depends(get_db)):
    actor = _admin(request, db)
    site = db.get(Site, site_id)
    if not site:
        return _redirect("/admin/sites", error="Site not found")
    try:
        site.name = _bounded(name, "Site name", 120, required=True)
        site.laboratory_name = _bounded(laboratory_name, "Laboratory name", 160, required=True)
    except ValueError as exc:
        return _redirect("/admin/sites", error=str(exc))
    add_audit(db, actor=actor, request=request, action="SITE_UPDATED", entity_type="Site", entity_id=site.id, summary=f"Updated site {site.code}")
    db.commit()
    return _redirect("/admin/sites", ok="Site updated")


@router.post("/sites/{site_id}/toggle")
def toggle_site(site_id: int, request: Request, db: Session = Depends(get_db)):
    actor = _admin(request, db)
    site = db.get(Site, site_id)
    if site:
        site.active = not site.active
        add_audit(db, actor=actor, request=request, action="SITE_STATUS_CHANGED", entity_type="Site", entity_id=site.id, summary=f"{site.code} set to {'Active' if site.active else 'Inactive'}")
        db.commit()
    return RedirectResponse("/admin/sites", status_code=303)


@router.get("/documents")
def documents_page(request: Request, ok: str = "", error: str = "", db: Session = Depends(get_db)):
    user = _admin(request, db)
    documents = db.scalars(select(ControlledDocument).order_by(ControlledDocument.created_at.desc())).all()
    sites = db.scalars(select(Site).order_by(Site.code)).all()
    return templates.TemplateResponse("admin_documents.html", {"request": request, "user": user, "documents": documents, "sites": sites, "ok": ok, "error": error})


@router.post("/documents")
def upload_document(
    request: Request,
    document_type: str = Form(...),
    code: str = Form(...),
    title: str = Form(...),
    revision: str = Form("00"),
    effective_date: str = Form(""),
    site_id: str = Form(""),
    workstation: str = Form(""),
    test_name: str = Form(""),
    method_name: str = Form(""),
    notes: str = Form(""),
    document_file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    actor = _admin(request, db)
    doc_type = document_type.strip().upper()
    if doc_type not in {"SOP", "METHOD", "EOP", "QUICK GUIDE", "FORM", "OTHER"}:
        return _redirect("/admin/documents", error="Unsupported document type")
    try:
        clean_code = _bounded_code(code, "Document code", 80, minimum=1)
        clean_revision = _bounded(revision or "00", "Revision", 40) or "00"
        title = _bounded(title, "Document title", 220, required=True)
        effective_date = _bounded(effective_date, "Effective date", 20)
        workstation = _bounded(workstation, "Workstation", 120)
        test_name = _bounded(test_name, "Test name", 220)
        method_name = _bounded(method_name, "Method name", 160)
    except ValueError as exc:
        return _redirect("/admin/documents", error=str(exc))
    if not document_file.filename:
        return _redirect("/admin/documents", error="Document file is required")
    suffix = Path(document_file.filename).suffix.lower()
    if suffix not in {".pdf", ".doc", ".docx", ".xlsx", ".xls", ".txt"}:
        return _redirect("/admin/documents", error="Allowed files: PDF, Word, Excel or TXT")
    try:
        linked_site_id = _parse_optional_int(site_id, "Site")
    except ValueError as exc:
        return _redirect("/admin/documents", error=str(exc))
    if linked_site_id is not None and not _active_site(db, linked_site_id):
        return _redirect("/admin/documents", error="Selected site is missing or inactive")

    duplicate_stmt = select(ControlledDocument).where(
        ControlledDocument.code == clean_code,
        ControlledDocument.revision == clean_revision,
    )
    duplicate_stmt = _document_scope_filter(duplicate_stmt, linked_site_id)
    if db.scalar(duplicate_stmt.limit(1)):
        return _redirect("/admin/documents", error="This document revision already exists for the selected scope")

    payload = document_file.file.read(MAX_CONTROLLED_DOCUMENT_BYTES + 1)
    if len(payload) > MAX_CONTROLLED_DOCUMENT_BYTES:
        return _redirect("/admin/documents", error="Controlled document exceeds the 10 MB limit")
    if not _document_bytes_valid(suffix, payload):
        return _redirect("/admin/documents", error="File content does not match the selected document type")

    previous_stmt = select(ControlledDocument).where(ControlledDocument.code == clean_code, ControlledDocument.status == "ACTIVE")
    previous_stmt = _document_scope_filter(previous_stmt, linked_site_id)
    for previous in db.scalars(previous_stmt).all():
        previous.status = "SUPERSEDED"

    stored = f"{clean_code.replace('/', '-')}_{clean_revision}_{secrets.token_hex(5)}{suffix}"
    path = DOC_DIR / stored
    DOC_DIR.mkdir(parents=True, exist_ok=True)
    try:
        path.write_bytes(payload)
        doc = ControlledDocument(
            site_id=linked_site_id, document_type=doc_type, code=clean_code, title=title.strip(), revision=clean_revision,
            status="ACTIVE", effective_date=effective_date.strip(), workstation=workstation.strip(), test_name=test_name.strip(), method_name=method_name.strip(),
            original_filename=Path(document_file.filename).name, stored_filename=stored, notes=notes.strip(), uploaded_by_id=actor.id,
        )
        db.add(doc)
        db.flush()
        add_audit(db, actor=actor, request=request, action="CONTROLLED_DOCUMENT_UPLOADED", entity_type="ControlledDocument", entity_id=doc.id, summary=f"{doc.code} Rev {doc.revision} uploaded")
        db.commit()
    except Exception:
        db.rollback()
        path.unlink(missing_ok=True)
        raise
    return _redirect("/admin/documents", ok="Controlled document published")


@router.post("/documents/{document_id}/status")
def document_status(document_id: int, request: Request, status: str = Form(...), db: Session = Depends(get_db)):
    actor = _admin(request, db)
    doc = db.get(ControlledDocument, document_id)
    new_status = status.strip().upper()
    if not doc or new_status not in {"ACTIVE", "SUPERSEDED", "WITHDRAWN"}:
        return _redirect("/admin/documents", error="Invalid document or status")
    if new_status == "ACTIVE":
        active_stmt = select(ControlledDocument).where(
            ControlledDocument.code == doc.code,
            ControlledDocument.status == "ACTIVE",
            ControlledDocument.id != doc.id,
        )
        active_stmt = _document_scope_filter(active_stmt, doc.site_id)
        for other in db.scalars(active_stmt).all():
            other.status = "SUPERSEDED"
    doc.status = new_status
    add_audit(db, actor=actor, request=request, action="DOCUMENT_STATUS_CHANGED", entity_type="ControlledDocument", entity_id=doc.id, summary=f"{doc.code} Rev {doc.revision} → {new_status}")
    db.commit()
    return _redirect("/admin/documents", ok="Document status updated")


@router.get("/test-packages")
def test_packages_page(request: Request, ok: str = "", error: str = "", db: Session = Depends(get_db)):
    user = _admin(request, db)
    packages = db.scalars(select(TestPackageConfig).order_by(TestPackageConfig.active.desc(), TestPackageConfig.name)).all()
    for package in packages:
        try:
            rows = json.loads(package.tests_json or "[]")
        except Exception:
            rows = []
        package.tests_text = "\n".join(
            " | ".join([str(row.get("test", "")), str(row.get("method", "")), str(row.get("station", "")), str(row.get("unit", ""))]).rstrip(" |")
            for row in rows if isinstance(row, dict)
        )
    sites = db.scalars(select(Site).order_by(Site.code)).all()
    return templates.TemplateResponse("admin_test_packages.html", {"request": request, "user": user, "packages": packages, "sites": sites, "ok": ok, "error": error})


def _tests_from_lines(raw: str) -> list[dict]:
    tests = []
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        parts = [part.strip() for part in line.split("|")]
        parts += [""] * (4 - len(parts))
        tests.append({"test": parts[0], "method": parts[1], "station": parts[2], "unit": parts[3]})
    return tests


@router.post("/test-packages")
def create_test_package(
    request: Request,
    code: str = Form(...), name: str = Form(...), scope: str = Form("GENERAL"), site_id: str = Form(""), tests: str = Form(""),
    db: Session = Depends(get_db),
):
    actor = _admin(request, db)
    try:
        linked_site_id = _parse_optional_int(site_id, "Site")
        clean_code = _bounded_code(code, "Package code", 80, minimum=1)
        clean_name = _bounded(name, "Package name", 120, required=True)
        clean_scope = _bounded(scope.upper() or "GENERAL", "Package scope", 80) or "GENERAL"
    except ValueError as exc:
        return _redirect("/admin/test-packages", error=str(exc))
    if linked_site_id is not None and not _active_site(db, linked_site_id):
        return _redirect("/admin/test-packages", error="Selected site is missing or inactive")
    test_rows = _tests_from_lines(tests)
    if any(not row.get("test") for row in test_rows):
        return _redirect("/admin/test-packages", error="Every test package row requires a test name")
    item = TestPackageConfig(
        code=clean_code, name=clean_name, scope=clean_scope,
        site_id=linked_site_id, tests_json=json.dumps(test_rows, ensure_ascii=False), active=True,
    )
    if not item.code or not item.name or not test_rows:
        return _redirect("/admin/test-packages", error="Package code, name and at least one test are required")
    db.add(item)
    try:
        db.flush()
        add_audit(db, actor=actor, request=request, action="TEST_PACKAGE_CREATED", entity_type="TestPackageConfig", entity_id=item.id, summary=f"Created test package {item.name}")
        db.commit()
    except IntegrityError:
        db.rollback()
        return _redirect("/admin/test-packages", error="Package code already exists")
    return _redirect("/admin/test-packages", ok="Test package added")


@router.post("/test-packages/{package_id}/update")
def update_test_package(
    package_id: int, request: Request, name: str = Form(...), scope: str = Form("GENERAL"), site_id: str = Form(""), tests: str = Form(""), db: Session = Depends(get_db),
):
    actor = _admin(request, db)
    item = db.get(TestPackageConfig, package_id)
    if not item:
        return _redirect("/admin/test-packages", error="Package not found")
    try:
        linked_site_id = _parse_optional_int(site_id, "Site")
        clean_name = _bounded(name, "Package name", 120, required=True)
        clean_scope = _bounded(scope.upper() or "GENERAL", "Package scope", 80) or "GENERAL"
    except ValueError as exc:
        return _redirect("/admin/test-packages", error=str(exc))
    if linked_site_id is not None and not _active_site(db, linked_site_id):
        return _redirect("/admin/test-packages", error="Selected site is missing or inactive")
    test_rows = _tests_from_lines(tests)
    if not test_rows or any(not row.get("test") for row in test_rows):
        return _redirect("/admin/test-packages", error="Package name and valid test rows are required")
    item.name = clean_name; item.scope = clean_scope; item.site_id = linked_site_id
    item.tests_json = json.dumps(test_rows, ensure_ascii=False)
    add_audit(db, actor=actor, request=request, action="TEST_PACKAGE_UPDATED", entity_type="TestPackageConfig", entity_id=item.id, summary=f"Updated test package {item.code}")
    db.commit()
    return _redirect("/admin/test-packages", ok="Test package updated")


@router.post("/test-packages/{package_id}/toggle")
def toggle_test_package(package_id: int, request: Request, db: Session = Depends(get_db)):
    actor = _admin(request, db)
    item = db.get(TestPackageConfig, package_id)
    if item:
        item.active = not item.active
        add_audit(db, actor=actor, request=request, action="TEST_PACKAGE_STATUS_CHANGED", entity_type="TestPackageConfig", entity_id=item.id, summary=f"{item.code} set to {'Active' if item.active else 'Inactive'}")
        db.commit()
    return RedirectResponse("/admin/test-packages", status_code=303)


@router.get("/master-data")
def master_data_page(request: Request, db: Session = Depends(get_db)):
    user = _admin(request, db)
    counts = {
        "sites": db.scalar(select(func.count()).select_from(Site)) or 0,
        "departments": db.scalar(select(func.count()).select_from(Department)) or 0,
        "clients": db.scalar(select(func.count()).select_from(Client)) or 0,
        "client_units": db.scalar(select(func.count()).select_from(ClientUnit)) or 0,
        "assets": db.scalar(select(func.count()).select_from(Asset)) or 0,
        "documents": db.scalar(select(func.count()).select_from(ControlledDocument)) or 0,
        "packages": db.scalar(select(func.count()).select_from(TestPackageConfig)) or 0,
        "workflows": db.scalar(select(func.count()).select_from(WorkflowDefinition)) or 0,
    }
    return templates.TemplateResponse("admin_master_data.html", {"request":request,"user":user,"counts":counts})


@router.get("/hierarchy")
def hierarchy_page(request: Request, ok: str = "", error: str = "", db: Session = Depends(get_db)):
    user = _admin(request, db)
    sites = db.scalars(select(Site).order_by(Site.code)).all()
    departments = db.scalars(select(Department).order_by(Department.site_id, Department.name)).all()
    clients = db.scalars(select(Client).order_by(Client.name)).all()
    units = db.scalars(select(ClientUnit).order_by(ClientUnit.client_id, ClientUnit.parent_id, ClientUnit.name)).all()
    return templates.TemplateResponse("admin_hierarchy.html", {"request":request,"user":user,"sites":sites,"departments":departments,"clients":clients,"units":units,"ok":ok,"error":error})


@router.post("/hierarchy/departments")
def create_department(request: Request, code: str = Form(...), name: str = Form(...), site_id: str = Form(""), db: Session = Depends(get_db)):
    actor = _admin(request, db)
    try:
        linked_site_id = _parse_optional_int(site_id, "Site")
        clean_code = _bounded_code(code, "Department code", 40, minimum=1)
        clean_name = _bounded(name, "Department name", 160, required=True)
    except ValueError as exc:
        return _redirect("/admin/hierarchy", error=str(exc))
    if linked_site_id is not None and not _active_site(db, linked_site_id):
        return _redirect("/admin/hierarchy", error="Selected site is missing or inactive")
    item = Department(site_id=linked_site_id, code=clean_code, name=clean_name, active=True)
    db.add(item)
    try:
        db.flush(); add_audit(db, actor=actor, request=request, action="DEPARTMENT_CREATED", entity_type="Department", entity_id=item.id, summary=f"Created department {item.code} — {item.name}"); db.commit()
    except IntegrityError:
        db.rollback(); return _redirect("/admin/hierarchy", error="Department code already exists in this scope")
    return _redirect("/admin/hierarchy", ok="Department added")


@router.post("/hierarchy/departments/{item_id}/toggle")
def toggle_department(item_id: int, request: Request, db: Session = Depends(get_db)):
    actor=_admin(request,db); item=db.get(Department,item_id)
    if item:
        item.active=not item.active; add_audit(db,actor=actor,request=request,action="DEPARTMENT_STATUS_CHANGED",entity_type="Department",entity_id=item.id,summary=f"{item.code} set to {'Active' if item.active else 'Inactive'}"); db.commit()
    return RedirectResponse("/admin/hierarchy",status_code=303)


@router.post("/hierarchy/client-units")
def create_client_unit(request: Request, client_id: int = Form(...), unit_type: str = Form("SITE"), code: str = Form(...), name: str = Form(...), parent_id: str = Form(""), db: Session = Depends(get_db)):
    actor=_admin(request,db)
    client=_active_client(db,client_id)
    if not client:
        return _redirect("/admin/hierarchy", error="Selected client is missing or inactive")
    try:
        parent=_parse_optional_int(parent_id, "Parent unit")
    except ValueError as exc:
        return _redirect("/admin/hierarchy", error=str(exc))
    if parent:
        p=db.get(ClientUnit,parent)
        if not p or not p.active or p.client_id != client_id:
            return _redirect("/admin/hierarchy", error="Parent unit must be active and belong to the same client")
    try:
        clean_type=_bounded(unit_type.strip().upper() or "SITE", "Unit type", 40) or "SITE"
        clean_code=_bounded_code(code, "Client unit code", 80, minimum=1)
        clean_name=_bounded(name, "Client unit name", 180, required=True)
    except ValueError as exc:
        return _redirect("/admin/hierarchy", error=str(exc))
    item=ClientUnit(client_id=client_id,parent_id=parent,unit_type=clean_type,code=clean_code,name=clean_name,active=True)
    db.add(item)
    try:
        db.flush(); add_audit(db,actor=actor,request=request,action="CLIENT_UNIT_CREATED",entity_type="ClientUnit",entity_id=item.id,summary=f"Created {item.unit_type} {item.code} for {item.client.name}"); db.commit()
    except IntegrityError:
        db.rollback(); return _redirect("/admin/hierarchy",error="Client unit code already exists for this client")
    return _redirect("/admin/hierarchy",ok="Client organization unit added")


@router.post("/hierarchy/client-units/{item_id}/toggle")
def toggle_client_unit(item_id:int, request:Request, db:Session=Depends(get_db)):
    actor=_admin(request,db); item=db.get(ClientUnit,item_id)
    if item:
        item.active=not item.active; add_audit(db,actor=actor,request=request,action="CLIENT_UNIT_STATUS_CHANGED",entity_type="ClientUnit",entity_id=item.id,summary=f"{item.code} set to {'Active' if item.active else 'Inactive'}"); db.commit()
    return RedirectResponse("/admin/hierarchy",status_code=303)


def _workflow_steps_from_lines(raw: str) -> list[dict]:
    rows=[]
    for i,line in enumerate(raw.splitlines(), start=1):
        line=line.strip()
        if not line: continue
        parts=[p.strip() for p in line.split("|")]; parts += [""]*(4-len(parts))
        flags={x.strip().lower() for x in parts[3].split(",") if x.strip()}
        rows.append({"step_order":i,"step_key":parts[0].lower().replace(" ","_"),"label":parts[1] or parts[0],"responsible_role":parts[2],"approval_required":"approval" in flags,"terminal":"terminal" in flags})
    return rows


@router.get("/workflows")
def workflows_page(request: Request, ok: str = "", error: str = "", db: Session = Depends(get_db)):
    user=_admin(request,db); sites=db.scalars(select(Site).order_by(Site.code)).all(); flows=db.scalars(select(WorkflowDefinition).order_by(WorkflowDefinition.active.desc(), WorkflowDefinition.code, WorkflowDefinition.version.desc())).all(); policies=db.scalars(select(ApprovalPolicy).order_by(ApprovalPolicy.active.desc(),ApprovalPolicy.code)).all()
    for f in flows:
        f.steps_text="\n".join(f"{x.step_key} | {x.label} | {x.responsible_role} | {','.join([v for v,b in [('approval',x.approval_required),('terminal',x.terminal)] if b])}" for x in f.steps)
    for p in policies:
        try: rows=json.loads(p.stages_json or "[]")
        except Exception: rows=[]
        p.stages_text="\n".join(f"{x.get('stage','')} | {x.get('role','')}" for x in rows if isinstance(x,dict))
    return templates.TemplateResponse("admin_workflows.html",{"request":request,"user":user,"sites":sites,"flows":flows,"policies":policies,"roles":ROLE_OPTIONS,"ok":ok,"error":error})


@router.post("/workflows")
def create_workflow(request:Request, code:str=Form(...), name:str=Form(...), sample_type:str=Form("GENERAL"), site_id:str=Form(""), steps:str=Form(""), db:Session=Depends(get_db)):
    actor=_admin(request,db); sid=int(site_id) if site_id else None; clean=code.strip().upper()
    if sid is not None and not _active_site(db,sid): return _redirect("/admin/workflows",error="Selected site is missing or inactive")
    rows=_workflow_steps_from_lines(steps)
    if not clean or not name.strip() or len(rows)<2: return _redirect("/admin/workflows",error="Workflow requires a code, name and at least two steps")
    if len({row["step_key"] for row in rows}) != len(rows): return _redirect("/admin/workflows",error="Workflow step keys must be unique")
    if any(row.get("responsible_role") not in ROLE_OPTIONS for row in rows): return _redirect("/admin/workflows",error="Every workflow step must use a valid platform role")
    version=(db.scalar(select(func.max(WorkflowDefinition.version)).where(WorkflowDefinition.code==clean, WorkflowDefinition.site_id==sid)) or 0)+1
    for old in db.scalars(select(WorkflowDefinition).where(WorkflowDefinition.code==clean, WorkflowDefinition.site_id==sid, WorkflowDefinition.active.is_(True))).all(): old.active=False
    flow=WorkflowDefinition(site_id=sid,code=clean,name=name.strip(),sample_type=sample_type.strip().upper() or "GENERAL",version=version,active=True); db.add(flow); db.flush()
    for row in rows: db.add(WorkflowStep(workflow_id=flow.id,**row))
    add_audit(db,actor=actor,request=request,action="WORKFLOW_PUBLISHED",entity_type="WorkflowDefinition",entity_id=flow.id,summary=f"Published {flow.code} v{flow.version}",details={"steps":rows}); db.commit()
    return _redirect("/admin/workflows",ok="Workflow version published")


@router.post("/workflows/{flow_id}/toggle")
def toggle_workflow(flow_id:int,request:Request,db:Session=Depends(get_db)):
    actor=_admin(request,db); flow=db.get(WorkflowDefinition,flow_id)
    if flow:
        flow.active=not flow.active; add_audit(db,actor=actor,request=request,action="WORKFLOW_STATUS_CHANGED",entity_type="WorkflowDefinition",entity_id=flow.id,summary=f"{flow.code} v{flow.version} set to {'Active' if flow.active else 'Inactive'}"); db.commit()
    return RedirectResponse("/admin/workflows",status_code=303)


def _approval_stages_from_lines(raw: str) -> list[dict]:
    rows=[]
    for line in raw.splitlines():
        line=line.strip()
        if not line: continue
        parts=[p.strip() for p in line.split("|")]; parts += [""]*(2-len(parts)); rows.append({"stage":parts[0],"role":parts[1]})
    return rows


@router.post("/workflows/approval-policies")
def create_approval_policy(request:Request, code:str=Form(...), name:str=Form(...), entity_type:str=Form("SAMPLE_REPORT"), site_id:str=Form(""), stages:str=Form(""), db:Session=Depends(get_db)):
    actor=_admin(request,db); sid=int(site_id) if site_id else None; clean=code.strip().upper(); rows=_approval_stages_from_lines(stages)
    if sid is not None and not _active_site(db,sid): return _redirect("/admin/workflows",error="Selected site is missing or inactive")
    if not clean or not name.strip() or not rows: return _redirect("/admin/workflows",error="Approval policy requires stages")
    if any(not row.get("stage") or row.get("role") not in ROLE_OPTIONS for row in rows): return _redirect("/admin/workflows",error="Every approval stage requires a name and valid role")
    old=db.scalar(select(ApprovalPolicy).where(ApprovalPolicy.code==clean,ApprovalPolicy.site_id==sid))
    if old:
        old.name=name.strip(); old.entity_type=entity_type.strip().upper(); old.stages_json=json.dumps(rows,ensure_ascii=False); old.active=True; item=old
    else:
        item=ApprovalPolicy(site_id=sid,code=clean,name=name.strip(),entity_type=entity_type.strip().upper(),stages_json=json.dumps(rows,ensure_ascii=False),active=True); db.add(item); db.flush()
    add_audit(db,actor=actor,request=request,action="APPROVAL_POLICY_SAVED",entity_type="ApprovalPolicy",entity_id=item.id,summary=f"Saved approval policy {item.code}",details={"stages":rows}); db.commit(); return _redirect("/admin/workflows",ok="Approval policy saved")


@router.get("/integrations")
def integrations_page(request:Request,ok:str="",error:str="",db:Session=Depends(get_db)):
    user=_admin(request,db); rows=db.scalars(select(IntegrationQueueItem).order_by(IntegrationQueueItem.created_at.desc()).limit(300)).all(); sync_rows=db.scalars(select(__import__('app.models',fromlist=['LmsSyncLog']).LmsSyncLog).order_by(__import__('app.models',fromlist=['LmsSyncLog']).LmsSyncLog.created_at.desc()).limit(100)).all()
    return templates.TemplateResponse("admin_integrations.html",{"request":request,"user":user,"rows":rows,"sync_rows":sync_rows,"ok":ok,"error":error})


@router.post("/integrations/{item_id}/retry")
def retry_integration(item_id:int,request:Request,db:Session=Depends(get_db)):
    actor=_admin(request,db); item=db.get(IntegrationQueueItem,item_id)
    if not item: return _redirect("/admin/integrations",error="Queue item not found")
    from ..services.integration_queue import retry_item
    success=retry_item(db,item); add_audit(db,actor=actor,request=request,action="INTEGRATION_RETRY",entity_type="IntegrationQueueItem",entity_id=item.id,summary=f"{item.integration} {item.operation} → {item.status}"); db.commit(); return _redirect("/admin/integrations",ok="Integration retry completed" if success else "",error="Integration retry failed — review error" if not success else "")
