from __future__ import annotations

import os
import time
from collections import defaultdict, deque
from datetime import datetime
from threading import Lock

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..security import authenticate, current_user, hash_password, require_user, verify_password
from ..services.audit import add_audit

router = APIRouter()

_LOGIN_WINDOW_SECONDS = int(os.getenv("LOGIN_RATE_WINDOW_SECONDS", "900"))
_LOGIN_MAX_FAILURES = int(os.getenv("LOGIN_RATE_MAX_FAILURES", "5"))
_LOGIN_ATTEMPTS: dict[str, deque[float]] = defaultdict(deque)
_LOGIN_LOCK = Lock()


def _truthy(name: str, default: str = "false") -> bool:
    return os.getenv(name, default).strip().lower() in {"1", "true", "yes", "on"}


def _login_key(request: Request, email: str) -> str:
    ip = request.client.host if request.client else "unknown"
    return f"{ip}|{email.lower().strip()}"


def _prune_attempts(key: str, now: float) -> deque[float]:
    attempts = _LOGIN_ATTEMPTS[key]
    cutoff = now - _LOGIN_WINDOW_SECONDS
    while attempts and attempts[0] < cutoff:
        attempts.popleft()
    return attempts


def _rate_limited(request: Request, email: str) -> tuple[bool, int]:
    now = time.monotonic()
    key = _login_key(request, email)
    with _LOGIN_LOCK:
        attempts = _prune_attempts(key, now)
        if len(attempts) < _LOGIN_MAX_FAILURES:
            return False, 0
        retry_after = max(1, int(_LOGIN_WINDOW_SECONDS - (now - attempts[0])))
        return True, retry_after


def _record_failure(request: Request, email: str) -> None:
    now = time.monotonic()
    key = _login_key(request, email)
    with _LOGIN_LOCK:
        attempts = _prune_attempts(key, now)
        attempts.append(now)


def _clear_failures(request: Request, email: str) -> None:
    key = _login_key(request, email)
    with _LOGIN_LOCK:
        _LOGIN_ATTEMPTS.pop(key, None)


def _login_context(request: Request, error: str = "") -> dict:
    demo_accounts = []
    if _truthy("SHOW_DEMO_ACCOUNTS", "false"):
        demo_accounts = [("System Administrator", os.getenv("BOOTSTRAP_ADMIN_EMAIL", "admin@tsco.local"))]
    return {
        "request": request,
        "error": error,
        "portal": "secure",
        "portal_title": "Secure Sign In",
        "portal_subtitle": "Use your assigned account. Your role and workspace are selected automatically.",
        "demo_accounts": demo_accounts,
    }


@router.get("/welcome")
def welcome(request: Request, db: Session = Depends(get_db)):
    if current_user(request, db):
        return RedirectResponse("/", status_code=303)
    return templates.TemplateResponse("welcome.html", {"request": request})


@router.get("/login")
def login_page(request: Request, db: Session = Depends(get_db)):
    if current_user(request, db):
        return RedirectResponse("/", status_code=303)
    return templates.TemplateResponse("login.html", _login_context(request))


@router.get("/login/{portal}")
def legacy_login_page(portal: str):
    # Legacy entry points are intentionally retained only as redirects so old bookmarks keep working.
    return RedirectResponse("/login", status_code=303)


def _perform_login(request: Request, email: str, password: str, db: Session, legacy_portal: str = ""):
    limited, retry_after = _rate_limited(request, email)
    if limited:
        add_audit(
            db,
            actor=None,
            request=request,
            action="LOGIN_RATE_LIMITED",
            entity_type="Authentication",
            summary=f"Rate-limited sign-in attempt for {email.lower().strip()[:180]}",
            details={"retry_after_seconds": retry_after, "legacy_portal": legacy_portal},
        )
        db.commit()
        response = templates.TemplateResponse(
            "login.html",
            _login_context(request, "Too many unsuccessful attempts. Wait before trying again."),
            status_code=429,
        )
        response.headers["Retry-After"] = str(retry_after)
        return response

    user = authenticate(db, email, password)
    if not user:
        _record_failure(request, email)
        add_audit(
            db,
            actor=None,
            request=request,
            action="LOGIN_FAILED",
            entity_type="Authentication",
            summary=f"Failed sign-in for {email.lower().strip()[:180]}",
            details={"legacy_portal": legacy_portal},
        )
        db.commit()
        return templates.TemplateResponse(
            "login.html",
            _login_context(request, "Invalid email or password"),
            status_code=401,
        )

    _clear_failures(request, email)
    request.session.clear()
    request.session["user_id"] = user.id
    request.session["auth_time"] = int(time.time())
    user.last_login_at = datetime.utcnow()
    add_audit(
        db,
        actor=user,
        request=request,
        action="LOGIN",
        entity_type="User",
        entity_id=user.id,
        summary="Signed in through unified authentication",
        details={"legacy_portal": legacy_portal} if legacy_portal else {},
    )
    db.commit()
    if user.must_change_password:
        return RedirectResponse("/change-password", status_code=303)
    return RedirectResponse("/", status_code=303)


@router.post("/login")
def login(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    return _perform_login(request, email, password, db)


@router.post("/login/{portal}")
def legacy_login(
    portal: str,
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    # Backward-compatible POST endpoint; role is never selected by the URL.
    return _perform_login(request, email, password, db, legacy_portal=portal[:40])


@router.get("/change-password")
def change_password_page(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    return templates.TemplateResponse("change_password.html", {"request": request, "user": user, "error": "", "ok": ""})


@router.post("/change-password")
def change_password(
    request: Request,
    current_password: str = Form(...),
    new_password: str = Form(...),
    confirm_password: str = Form(...),
    db: Session = Depends(get_db),
):
    user = require_user(request, db)
    error = ""
    if not verify_password(current_password, user.password_hash):
        error = "Current password is incorrect"
    elif len(new_password) < 10:
        error = "New password must be at least 10 characters"
    elif new_password != confirm_password:
        error = "Password confirmation does not match"
    if error:
        return templates.TemplateResponse("change_password.html", {"request": request, "user": user, "error": error, "ok": ""}, status_code=400)
    user.password_hash = hash_password(new_password)
    user.must_change_password = False
    add_audit(db, actor=user, request=request, action="PASSWORD_CHANGED", entity_type="User", entity_id=user.id, summary="User changed password")
    db.commit()
    return templates.TemplateResponse("change_password.html", {"request": request, "user": user, "error": "", "ok": "Password updated successfully"})


@router.post("/logout")
def logout(request: Request, db: Session = Depends(get_db)):
    user = current_user(request, db)
    if user:
        add_audit(db, actor=user, request=request, action="LOGOUT", entity_type="User", entity_id=user.id, summary="Signed out")
        db.commit()
    request.session.clear()
    return RedirectResponse("/welcome", status_code=303)
