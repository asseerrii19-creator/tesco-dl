from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import Client, Role, SamplingAssignment, SamplingOrder, SamplingRequestNotice, User
from ..security import require_user
from ..services.audit import add_audit
from ..services.identifiers import next_sampling_request_code

router = APIRouter(prefix="/sampling-supervision", tags=["sampling supervision"])
ALLOWED = {Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value, Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value}
WRITE_ALLOWED = {Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value, Role.SYSTEM_ADMIN.value}
REQUEST_WRITE_ALLOWED = {Role.SAMPLING_SUPERVISOR.value, Role.SYSTEM_ADMIN.value}


@router.get("")
def dashboard(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    stmt = select(SamplingAssignment).join(SamplingOrder).order_by(SamplingAssignment.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        stmt = stmt.where(SamplingOrder.site_id == user.site_id)
    if user.role == Role.SAMPLING_SUPERVISOR.value:
        stmt = stmt.where(SamplingOrder.supervisor_id == user.id)
    assignments = db.scalars(stmt.limit(200)).all()
    samplers_stmt = select(User).where(User.role.in_([Role.FIELD_SAMPLER.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value]), User.active.is_(True))
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        samplers_stmt = samplers_stmt.where(User.site_id == user.site_id)
    samplers = db.scalars(samplers_stmt.order_by(User.full_name)).all()
    clients = db.scalars(select(Client).where(Client.active.is_(True)).order_by(Client.name)).all()
    notices_stmt = select(SamplingRequestNotice).order_by(SamplingRequestNotice.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        notices_stmt = notices_stmt.where(SamplingRequestNotice.site_id == user.site_id)
    if user.role == Role.SAMPLING_SUPERVISOR.value:
        notices_stmt = notices_stmt.where(SamplingRequestNotice.requested_by_id == user.id)
    notices = db.scalars(notices_stmt.limit(100)).all()
    return templates.TemplateResponse("sampling_supervision.html", {
        "request": request, "user": user, "assignments": assignments, "samplers": samplers,
        "clients": clients, "notices": notices,
    })


@router.post("/requests")
def create_sampling_request(
    request: Request, client_id: int = Form(...), title: str = Form("Sampling request"),
    priority: str = Form("Normal"), expected_samples: int = Form(1), target_sampling_at: str = Form(""),
    notes: str = Form(""), db: Session = Depends(get_db),
):
    user = require_user(request, db, REQUEST_WRITE_ALLOWED)
    client = db.get(Client, client_id)
    if not client or not client.active:
        raise ValueError("Active client is required")
    if not user.site_id:
        raise ValueError("Sampling Supervisor must be assigned to a site")
    priority = priority.strip().title()
    if priority not in {"Normal", "High", "Urgent"}:
        raise ValueError("Unsupported priority")
    if expected_samples < 1 or expected_samples > 500:
        raise ValueError("Expected sample count must be between 1 and 500")
    clean_title = (title or "Sampling request").strip()[:200] or "Sampling request"
    try:
        target = datetime.fromisoformat(target_sampling_at) if target_sampling_at else None
    except ValueError:
        raise ValueError("Target sampling date/time is invalid")
    notice = SamplingRequestNotice(
        request_code=next_sampling_request_code(db, user.site), site_id=user.site_id, client_id=client.id,
        requested_by_id=user.id, title=clean_title, priority=priority, expected_samples=expected_samples,
        target_sampling_at=target, notes=(notes or "").strip()[:4000], status="PENDING_OPERATIONS",
    )
    db.add(notice); db.flush()
    add_audit(db, actor=user, request=request, action="SAMPLING_REQUEST_SUBMITTED", entity_type="SamplingRequestNotice",
              entity_id=notice.id, summary=f"{notice.request_code} submitted to Operations",
              details={"client_id": client.id, "expected_samples": expected_samples, "priority": priority})
    db.commit()
    return RedirectResponse("/sampling-supervision", status_code=303)


@router.post("/assignment/{assignment_id}/assign")
def assign(assignment_id: int, request: Request, sampler_id: int = Form(...), note: str = Form(""), db: Session = Depends(get_db)):
    user = require_user(request, db, WRITE_ALLOWED)
    assignment = db.get(SamplingAssignment, assignment_id)
    sampler = db.get(User, sampler_id)
    if not assignment or not sampler:
        return RedirectResponse("/sampling-supervision", status_code=303)
    if assignment.status == "COMPLETED" or assignment.completed_sample_id:
        raise ValueError("Completed sampling assignments cannot be reassigned")
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id and assignment.order.site_id != user.site_id:
        return RedirectResponse("/sampling-supervision", status_code=303)
    if user.role == Role.SAMPLING_SUPERVISOR.value and assignment.order.supervisor_id != user.id:
        return RedirectResponse("/sampling-supervision", status_code=303)
    if not sampler.active or sampler.role not in {Role.FIELD_SAMPLER.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value}:
        raise ValueError("Selected user is not an active authorized sampler")
    if assignment.source_party == "CLIENT" and sampler.client_id != assignment.order.client_id:
        raise ValueError("Client-side sampler must belong to the order client")
    if assignment.source_party == "TSCO" and sampler.client_id is not None:
        raise ValueError("TSCO assignment cannot be allocated to a client-side account")
    if sampler.site_id != assignment.order.site_id:
        raise ValueError("Sampler and sampling order must belong to the same site")
    assignment.assigned_sampler_id = sampler.id
    assignment.assigned_at = datetime.utcnow()
    assignment.status = "ASSIGNED"
    if note.strip():
        assignment.instructions = (assignment.instructions + "\n" + note.strip()).strip()
    add_audit(db, actor=user, request=request, action="SAMPLING_ASSIGNMENT_ASSIGNED", entity_type="SamplingAssignment", entity_id=assignment.id, summary=f"Assigned {assignment.assignment_code} to {sampler.full_name}")
    db.commit()
    return RedirectResponse("/sampling-supervision", status_code=303)
