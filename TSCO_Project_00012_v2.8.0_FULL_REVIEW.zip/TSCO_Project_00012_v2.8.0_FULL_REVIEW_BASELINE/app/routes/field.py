from __future__ import annotations

from datetime import datetime
from io import BytesIO
from pathlib import Path
import json

from PIL import Image, UnidentifiedImageError

from fastapi import APIRouter, Depends, File, Form, Request, UploadFile
from fastapi.responses import FileResponse, RedirectResponse, JSONResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import Asset, Client, CustodyEvent, PurchaseOrder, Quotation, Role, SamplePhoto, SampleRequest, SampleStatus, SamplingAssignment, Site
from ..security import require_user
from ..services.barcodes import generate_assets
from ..services.identifiers import next_request_identifiers
from ..services.workflow import add_event
from ..services.audit import add_audit
from ..services.lab_operations import package_catalog
from ..services.scope import assigned_client_ids, can_access_client
from ..storage import UPLOAD_DIR, BARCODE_DIR

router = APIRouter(prefix="/field", tags=["field"])
FIELD_ROLES = {Role.FIELD_SAMPLER.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value, Role.SYSTEM_ADMIN.value}
PHOTO_INTERNAL_ROLES = {
    Role.DATA_ENTRY.value, Role.SAMPLE_RECEIVING.value, Role.OPERATIONS_MANAGER.value,
    Role.SAMPLING_SUPERVISOR.value, Role.LAB_TECHNICIAN.value, Role.SENIOR_CHEMIST.value,
    Role.QUALITY.value, Role.TECHNICAL_MANAGER.value, Role.MANAGEMENT.value, Role.SYSTEM_ADMIN.value,
}
MAX_PHOTO_BYTES = 10_000_000
MAX_PHOTO_TOTAL_BYTES = 25_000_000


def _detected_image_ext(raw: bytes) -> str | None:
    if raw.startswith(b"\xff\xd8\xff"):
        return ".jpg"
    if raw.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if len(raw) >= 12 and raw[:4] == b"RIFF" and raw[8:12] == b"WEBP":
        return ".webp"
    if len(raw) >= 12 and raw[4:8] == b"ftyp" and raw[8:12] in {b"heic", b"heix", b"hevc", b"hevx", b"mif1", b"msf1"}:
        return ".heic"
    return None


def _validate_image_bytes(raw: bytes) -> str:
    ext = _detected_image_ext(raw)
    if not ext:
        raise ValueError("Unsupported or invalid image file")
    if ext == ".heic":
        raise ValueError("HEIC field evidence is not accepted until server-side decoding/verification is available; use JPEG, PNG or WebP")
    try:
        with Image.open(BytesIO(raw)) as image:
            image.verify()
    except (UnidentifiedImageError, OSError, SyntaxError, ValueError):
        raise ValueError("Image file is corrupt or does not match a supported image format")
    return ext


def _read_validated_photo(upload: UploadFile) -> tuple[bytes, str]:
    if not (upload.content_type or "").lower().startswith("image/"):
        raise ValueError("Field evidence files must be images")
    raw = upload.file.read(MAX_PHOTO_BYTES + 1)
    if len(raw) > MAX_PHOTO_BYTES:
        raise ValueError("Each field photo must be 10 MB or smaller")
    return raw, _validate_image_bytes(raw)


def _float(value: str | None) -> float | None:
    if value is None or value.strip() == "":
        return None
    return float(value)


def _bounded_float(value: str | None, label: str, minimum: float, maximum: float) -> float | None:
    parsed = _float(value)
    if parsed is not None and not (minimum <= parsed <= maximum):
        raise ValueError(f"{label} must be between {minimum:g} and {maximum:g}")
    return parsed


def _nonnegative_float(value: str | None, label: str) -> float | None:
    parsed = _float(value)
    if parsed is not None and parsed < 0:
        raise ValueError(f"{label} cannot be negative")
    return parsed


def _bounded_text(value: str | None, label: str, maximum: int, *, required: bool = False) -> str:
    clean = (value or "").strip()
    if required and not clean:
        raise ValueError(f"{label} is required")
    if len(clean) > maximum:
        raise ValueError(f"{label} must be {maximum} characters or fewer")
    return clean


@router.get("")
def dashboard(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, FIELD_ROLES)
    samples = db.scalars(
        select(SampleRequest).where(SampleRequest.sampler_id == user.id).order_by(SampleRequest.created_at.desc()).limit(50)
    ).all()
    assignments = db.scalars(
        select(SamplingAssignment).where(
            SamplingAssignment.assigned_sampler_id == user.id,
            SamplingAssignment.status.in_(["ASSIGNED", "IN_PROGRESS", "RETURNED"]),
        ).order_by(SamplingAssignment.created_at.desc()).limit(100)
    ).all()
    return templates.TemplateResponse("field_dashboard.html", {"request": request, "user": user, "samples": samples, "assignments": assignments})


@router.get("/new")
def new_sample(request: Request, assignment_id: int | None = None, code: str = "", db: Session = Depends(get_db)):
    user = require_user(request, db, FIELD_ROLES)
    assignment = None
    if assignment_id:
        assignment = db.get(SamplingAssignment, assignment_id)
    elif code.strip():
        assignment = db.scalar(select(SamplingAssignment).where(SamplingAssignment.assignment_code == code.strip().upper()))
    if assignment and user.role != Role.SYSTEM_ADMIN.value and assignment.assigned_sampler_id != user.id:
        assignment = None
    client_stmt = select(Client).where(Client.active.is_(True)).order_by(Client.name)
    allowed_client_ids = assigned_client_ids(db, user)
    if user.client_id:
        allowed_client_ids = {user.client_id}
    if user.role != Role.SYSTEM_ADMIN.value:
        if allowed_client_ids:
            client_stmt = client_stmt.where(Client.id.in_(allowed_client_ids))
        else:
            client_stmt = client_stmt.where(False)
    clients = db.scalars(client_stmt).all()
    visible_ids = [client.id for client in clients]
    quote_stmt = select(Quotation).where(Quotation.status == "ACTIVE").order_by(Quotation.number)
    po_stmt = select(PurchaseOrder).where(PurchaseOrder.status == "ACTIVE").order_by(PurchaseOrder.number)
    asset_stmt = select(Asset).where(Asset.active.is_(True)).order_by(Asset.asset_code)
    if visible_ids:
        quote_stmt = quote_stmt.where(Quotation.client_id.in_(visible_ids))
        po_stmt = po_stmt.where(PurchaseOrder.client_id.in_(visible_ids))
        asset_stmt = asset_stmt.where(Asset.client_id.in_(visible_ids))
    elif user.role != Role.SYSTEM_ADMIN.value:
        quote_stmt = quote_stmt.where(False)
        po_stmt = po_stmt.where(False)
        asset_stmt = asset_stmt.where(False)
    quotes = db.scalars(quote_stmt).all()
    pos = db.scalars(po_stmt).all()
    assets = db.scalars(asset_stmt).all()
    return templates.TemplateResponse(
        "field_new.html",
        {"request": request, "user": user, "clients": clients, "quotes": quotes, "pos": pos, "assets": assets, "assignment": assignment, "package_names": [p["name"] for p in package_catalog(db, user.site_id)]},
    )


@router.post("/new")
def create_sample(
    request: Request,
    assignment_id: str = Form(""),
    client_id: int = Form(...),
    quotation_id: str = Form(""),
    purchase_order_id: str = Form(""),
    existing_asset_id: str = Form(""),
    asset_code: str = Form(""),
    serial_number: str = Form(""),
    equipment_type: str = Form("Transformer"),
    manufacturer: str = Form(""),
    station_name: str = Form(""),
    asset_location_label: str = Form(""),
    voltage_kv: str = Form(""),
    rated_mva: str = Form(""),
    sample_date_time: str = Form(...),
    sampling_point: str = Form(...),
    requested_package: str = Form(...),
    client_sample_reference: str = Form(""),
    oil_temperature_c: str = Form(""),
    ambient_temperature_c: str = Form(""),
    ambient_humidity_pct: str = Form(""),
    gps_latitude: str = Form(""),
    gps_longitude: str = Form(""),
    gps_accuracy_m: str = Form(""),
    field_notes: str = Form(""),
    container_count: int = Form(1),
    photo_kind: list[str] = Form(default=[]),
    photos: list[UploadFile] = File(default=[]),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, FIELD_ROLES)
    try:
        assignment_key = int(assignment_id) if assignment_id else None
    except (TypeError, ValueError):
        raise ValueError("Invalid sampling assignment")
    assignment = db.get(SamplingAssignment, assignment_key) if assignment_key else None
    if assignment and user.role != Role.SYSTEM_ADMIN.value and assignment.assigned_sampler_id != user.id:
        raise ValueError("Assignment is not allocated to this sampler")
    if assignment and (assignment.status == "COMPLETED" or assignment.completed_sample_id):
        raise ValueError("This sampling assignment has already been completed")
    if assignment:
        client_id = assignment.order.client_id
        quotation_id = assignment.order.quotation_id
        purchase_order_id = assignment.order.purchase_order_id
        if assignment.asset_id:
            existing_asset_id = assignment.asset_id
        container_count = assignment.container_count
        requested_package = assignment.requested_package
        sampling_point = assignment.sampling_point
        container_count = assignment.container_count
    site = db.get(Site, user.site_id) if user.site_id else (assignment.order.site if assignment else db.scalar(select(Site).where(Site.code == "DMM")))
    client = db.get(Client, client_id)
    if not site or not site.active or not client or not client.active:
        raise ValueError("Active site and client are required")
    if not can_access_client(db, user, client_id):
        raise ValueError("Sampler is not assigned to this client")
    quote = db.get(Quotation, quotation_id) if quotation_id else None
    po = db.get(PurchaseOrder, purchase_order_id) if purchase_order_id else None
    if quotation_id and not quote:
        raise ValueError("Quotation was not found")
    if purchase_order_id and not po:
        raise ValueError("Purchase order was not found")
    if quote and (quote.client_id != client_id or quote.status != "ACTIVE"):
        raise ValueError("Quotation is not active for the selected client")
    if po and (po.client_id != client_id or po.status != "ACTIVE"):
        raise ValueError("Purchase order is not active for the selected client")
    if po and quote and po.quotation_id and po.quotation_id != quote.id:
        raise ValueError("Purchase order is linked to a different quotation")
    try:
        sampling_point = _bounded_text(sampling_point, "Sampling point", 100, required=True)
        requested_package = _bounded_text(requested_package, "Requested package", 120, required=True)
        client_sample_reference = _bounded_text(client_sample_reference, "Client sample reference", 100)
        asset_code = _bounded_text(asset_code, "Asset code", 80)
        serial_number = _bounded_text(serial_number, "Serial number", 120)
        equipment_type = _bounded_text(equipment_type, "Equipment type", 80) or "Transformer"
        manufacturer = _bounded_text(manufacturer, "Manufacturer", 120)
        station_name = _bounded_text(station_name, "Station name", 160)
        asset_location_label = _bounded_text(asset_location_label, "Asset location", 200)
        sample_dt = datetime.fromisoformat(sample_date_time)
        humidity_value = _bounded_float(ambient_humidity_pct, "Ambient humidity", 0, 100)
        latitude_value = _bounded_float(gps_latitude, "GPS latitude", -90, 90)
        longitude_value = _bounded_float(gps_longitude, "GPS longitude", -180, 180)
        gps_accuracy_value = _nonnegative_float(gps_accuracy_m, "GPS accuracy")
        voltage_value = _float(voltage_kv)
        rated_mva_value = _float(rated_mva)
        oil_temperature_value = _float(oil_temperature_c)
        ambient_temperature_value = _float(ambient_temperature_c)
    except (TypeError, ValueError) as exc:
        raise ValueError(str(exc) or "Invalid field data")
    if not assignment:
        allowed_packages = {row["name"] for row in package_catalog(db, site.id)}
        if requested_package not in allowed_packages:
            raise ValueError("Requested test package is not active for this laboratory site")
    if container_count < 1 or container_count > 100:
        raise ValueError("Container count must be between 1 and 100")

    # Validate all evidence before creating database rows or writing any files.
    validated_photos: list[tuple[bytes, str, str, str]] = []
    total_photo_bytes = 0
    for idx, upload in enumerate(photos):
        if not upload.filename:
            continue
        raw, ext = _read_validated_photo(upload)
        total_photo_bytes += len(raw)
        if total_photo_bytes > MAX_PHOTO_TOTAL_BYTES:
            raise ValueError("Total field photo upload must be 25 MB or smaller")
        kind = photo_kind[idx] if idx < len(photo_kind) and photo_kind[idx].strip() else "General"
        validated_photos.append((raw, ext, kind[:80], Path(upload.filename).name[:220]))

    if existing_asset_id:
        asset = db.get(Asset, existing_asset_id)
        if not asset or not asset.active or asset.client_id != client_id:
            raise ValueError("Asset is not active for the selected client")
    else:
        if not asset_code or not serial_number:
            raise ValueError("Asset code and serial number are required for a new asset")
        duplicate_asset = db.scalar(select(Asset).where(Asset.client_id == client_id, Asset.asset_code == asset_code))
        if duplicate_asset:
            raise ValueError("Asset code already exists for this client; select the existing asset instead")
        asset = Asset(
            client_id=client_id,
            asset_code=asset_code,
            serial_number=serial_number,
            equipment_type=equipment_type,
            manufacturer=manufacturer,
            station_name=station_name,
            asset_location_label=asset_location_label,
            voltage_kv=voltage_value,
            rated_mva=rated_mva_value,
            latitude=latitude_value,
            longitude=longitude_value,
        )
        db.add(asset)
        db.flush()

    request_number, barcode_value, public_token = next_request_identifiers(db, site)
    sample = SampleRequest(
        request_number=request_number,
        public_token=public_token,
        barcode_value=barcode_value,
        status=SampleStatus.SUBMITTED.value,
        site_id=site.id,
        client_id=client_id,
        quotation_id=quote.id if quote else None,
        purchase_order_id=po.id if po else None,
        asset_id=asset.id,
        sampler_id=user.id,
        sampling_assignment_id=assignment.id if assignment else None,
        submission_channel="CLIENT_FIELD" if user.role in {Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value} else "TSCO_FIELD",
        sample_date_time=sample_dt,
        sampling_point=sampling_point,
        requested_package=requested_package,
        sample_origin="TSCO Field-Sampled" if user.role not in {Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value} else "Client-Originated / Direct Delivery",
        priority=(assignment.order.priority.upper() if assignment and assignment.order and assignment.order.priority else "NORMAL"),
        due_at=(assignment.order.due_at if assignment and assignment.order else None),
        client_sample_reference=client_sample_reference,
        oil_temperature_c=oil_temperature_value,
        ambient_temperature_c=ambient_temperature_value,
        ambient_humidity_pct=humidity_value,
        gps_latitude=latitude_value,
        gps_longitude=longitude_value,
        gps_accuracy_m=gps_accuracy_value,
        field_notes=field_notes.strip(),
        container_count=max(1, container_count),
        submitted_at=datetime.utcnow(),
    )
    db.add(sample)
    db.flush()
    if assignment:
        assignment.status = "COMPLETED"
        assignment.completed_at = datetime.utcnow()
        assignment.completed_sample_id = sample.id
        if assignment.resample_of_sample_id:
            original_sample = db.get(SampleRequest, assignment.resample_of_sample_id)
            if original_sample:
                add_event(
                    db, original_sample, user, "TECHNICAL_RESAMPLE_COLLECTED", original_sample.status,
                    f"Replacement field sample {sample.request_number} collected under {assignment.assignment_code}",
                    sample.gps_latitude, sample.gps_longitude,
                )
    add_event(
        db,
        sample,
        user,
        "FIELD_SUBMISSION",
        sample.status,
        "Sample captured and submitted from field",
        sample.gps_latitude,
        sample.gps_longitude,
    )

    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    written_paths: list[Path] = []
    barcode_artifacts: dict[str, str] = {}
    try:
        for idx, (raw, ext, kind, original_name) in enumerate(validated_photos):
            stored = UPLOAD_DIR / f"sample_{sample.id}_{idx}_{datetime.utcnow().timestamp():.0f}{ext}"
            stored.write_bytes(raw)
            written_paths.append(stored)
            db.add(SamplePhoto(sample_request_id=sample.id, kind=kind, original_name=original_name, stored_path=str(stored)))

        barcode_artifacts = generate_assets(barcode_value, request_number, client.name, asset.asset_code, BARCODE_DIR)
        add_audit(
            db,
            actor=user,
            request=request,
            action="FIELD_SAMPLE_SUBMITTED",
            entity_type="SampleRequest",
            entity_id=sample.id,
            summary=f"Submitted {sample.request_number} for {client.code}",
            details={"barcode": barcode_value, "asset": asset.asset_code, "photo_count": len(validated_photos)},
        )
        db.commit()
    except Exception:
        db.rollback()
        for path in written_paths:
            path.unlink(missing_ok=True)
        for artifact in barcode_artifacts.values():
            Path(artifact).unlink(missing_ok=True)
        raise
    return RedirectResponse(f"/field/sample/{sample.id}", status_code=303)


@router.get("/sample/{sample_id}")
def sample_detail(sample_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, FIELD_ROLES)
    sample = db.get(SampleRequest, sample_id)
    if not sample or (user.role != Role.SYSTEM_ADMIN.value and sample.sampler_id != user.id):
        return RedirectResponse("/field", status_code=303)
    return templates.TemplateResponse("field_detail.html", {"request": request, "user": user, "sample": sample})


@router.get("/photo/{photo_id}")
def photo_evidence(photo_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db)
    photo = db.get(SamplePhoto, photo_id)
    if not photo:
        return JSONResponse({"error": "Photo not found"}, status_code=404)
    sample = photo.sample
    allowed = user.role == Role.SYSTEM_ADMIN.value or sample.sampler_id == user.id
    if not allowed and user.role in PHOTO_INTERNAL_ROLES:
        allowed = user.site_id is None or sample.site_id == user.site_id
    if not allowed:
        return JSONResponse({"error": "Photo not found"}, status_code=404)
    path = Path(photo.stored_path)
    if not path.exists() or path.parent.resolve() != UPLOAD_DIR.resolve():
        return JSONResponse({"error": "Photo not found"}, status_code=404)
    media = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".heic": "image/heic", ".pdf": "application/pdf"}.get(path.suffix.lower(), "application/octet-stream")
    response = FileResponse(path, media_type=media, filename=Path(photo.original_name).name, content_disposition_type="inline")
    response.headers["Cache-Control"] = "private, no-store"
    return response


@router.get("/sample/{sample_id}/label")
def label(sample_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.FIELD_SAMPLER.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value, Role.DATA_ENTRY.value, Role.SAMPLE_RECEIVING.value, Role.SYSTEM_ADMIN.value})
    sample = db.get(SampleRequest, sample_id)
    if not sample:
        raise ValueError("Sample not found")
    if user.role in {Role.FIELD_SAMPLER.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value} and sample.sampler_id != user.id:
        return RedirectResponse("/field", status_code=303)
    if user.role in {Role.DATA_ENTRY.value, Role.SAMPLE_RECEIVING.value} and user.site_id and sample.site_id != user.site_id:
        return RedirectResponse("/", status_code=303)
    path = BARCODE_DIR / f"{sample.barcode_value}_label.pdf"
    if not path.exists():
        generate_assets(sample.barcode_value, sample.request_number, sample.client.name, sample.asset.asset_code, BARCODE_DIR)
    if not path.exists():
        return JSONResponse({"error": "Sample label could not be generated"}, status_code=404)
    response = FileResponse(path, media_type="application/pdf", filename=f"{sample.request_number}_tag.pdf")
    response.headers["Cache-Control"] = "private, no-store"
    return response

@router.post("/offline-sync")
async def offline_sync(request: Request, db: Session = Depends(get_db)):
    """Synchronize a field record captured while the device was offline.

    The device creates a globally unique Code 39-compatible barcode. The server preserves
    that barcode, issues the official portal request number and creates the normal custody trail.
    Replaying the same payload is idempotent.
    """
    import base64
    import re

    user = require_user(request, db, FIELD_ROLES)
    try:
        declared_size = int(request.headers.get("content-length") or 0)
    except ValueError:
        declared_size = 0
    max_payload_bytes = 38_000_000
    if declared_size > max_payload_bytes:
        return JSONResponse({"error": "Offline synchronization payload is too large"}, status_code=413)
    chunks: list[bytes] = []
    total_payload_bytes = 0
    async for chunk in request.stream():
        total_payload_bytes += len(chunk)
        if total_payload_bytes > max_payload_bytes:
            return JSONResponse({"error": "Offline synchronization payload is too large"}, status_code=413)
        chunks.append(chunk)
    try:
        body = json.loads(b"".join(chunks) or b"{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return JSONResponse({"error": "Invalid offline synchronization JSON"}, status_code=400)
    if not isinstance(body, dict):
        return JSONResponse({"error": "Invalid offline synchronization request"}, status_code=400)
    fields = body.get("fields") or {}
    if not isinstance(fields, dict):
        return JSONResponse({"error": "Invalid offline field data"}, status_code=400)
    offline_barcode = str(body.get("offline_barcode") or "").strip().upper()
    if not re.fullmatch(r"[A-Z0-9.-]{12,80}", offline_barcode):
        return JSONResponse({"error": "Invalid offline barcode"}, status_code=400)
    existing = db.scalar(select(SampleRequest).where(SampleRequest.barcode_value == offline_barcode))
    if existing:
        if user.role != Role.SYSTEM_ADMIN.value and existing.sampler_id != user.id:
            return JSONResponse({"error": "Offline barcode already belongs to another submission"}, status_code=403)
        return {
            "ok": True,
            "idempotent": True,
            "sample_id": existing.id,
            "request_number": existing.request_number,
            "barcode": existing.barcode_value,
            "status": existing.status,
        }

    try:
        assignment_id = int(fields.get("assignment_id")) if str(fields.get("assignment_id") or "").strip() else None
        client_id = int(fields.get("client_id") or 0)
        quotation_id = int(fields.get("quotation_id")) if str(fields.get("quotation_id") or "").strip() else None
        purchase_order_id = int(fields.get("purchase_order_id")) if str(fields.get("purchase_order_id") or "").strip() else None
        existing_asset_id = int(fields.get("existing_asset_id")) if str(fields.get("existing_asset_id") or "").strip() else None
        container_count = int(fields.get("container_count") or 1)
    except (TypeError, ValueError):
        return JSONResponse({"error": "Invalid numeric field in offline submission"}, status_code=400)
    assignment = db.get(SamplingAssignment, assignment_id) if assignment_id else None
    if assignment and user.role != Role.SYSTEM_ADMIN.value and assignment.assigned_sampler_id != user.id:
        return JSONResponse({"error": "Assignment is not allocated to this sampler"}, status_code=403)
    if assignment and (assignment.status == "COMPLETED" or assignment.completed_sample_id):
        return JSONResponse({"error": "This sampling assignment has already been completed"}, status_code=409)
    if assignment:
        client_id = assignment.order.client_id
        quotation_id = assignment.order.quotation_id
        purchase_order_id = assignment.order.purchase_order_id
        if assignment.asset_id:
            existing_asset_id = assignment.asset_id
        container_count = assignment.container_count

    site = db.get(Site, user.site_id) if user.site_id else (assignment.order.site if assignment else db.scalar(select(Site).where(Site.code == "DMM")))
    client = db.get(Client, client_id)
    if not site or not site.active or not client or not client.active:
        return JSONResponse({"error": "Active site and client are required"}, status_code=400)
    if not can_access_client(db, user, client_id):
        return JSONResponse({"error": "Sampler is not assigned to this client"}, status_code=403)
    quote = db.get(Quotation, quotation_id) if quotation_id else None
    po = db.get(PurchaseOrder, purchase_order_id) if purchase_order_id else None
    if quotation_id and not quote:
        return JSONResponse({"error": "Quotation was not found"}, status_code=400)
    if purchase_order_id and not po:
        return JSONResponse({"error": "Purchase order was not found"}, status_code=400)
    if quote and (quote.client_id != client_id or quote.status != "ACTIVE"):
        return JSONResponse({"error": "Quotation is not active for selected client"}, status_code=400)
    if po and (po.client_id != client_id or po.status != "ACTIVE"):
        return JSONResponse({"error": "Purchase order is not active for selected client"}, status_code=400)
    if po and quote and po.quotation_id and po.quotation_id != quote.id:
        return JSONResponse({"error": "Purchase order is linked to a different quotation"}, status_code=400)
    try:
        sampling_point = _bounded_text(assignment.sampling_point if assignment else str(fields.get("sampling_point") or ""), "Sampling point", 100, required=True)
        requested_package = _bounded_text(assignment.requested_package if assignment else str(fields.get("requested_package") or "Routine Test"), "Requested package", 120, required=True)
        client_sample_reference = _bounded_text(str(fields.get("client_sample_reference") or ""), "Client sample reference", 100)
        asset_code = _bounded_text(str(fields.get("asset_code") or ""), "Asset code", 80)
        serial_number = _bounded_text(str(fields.get("serial_number") or ""), "Serial number", 120)
        equipment_type = _bounded_text(str(fields.get("equipment_type") or "Transformer"), "Equipment type", 80) or "Transformer"
        manufacturer = _bounded_text(str(fields.get("manufacturer") or ""), "Manufacturer", 120)
        station_name = _bounded_text(str(fields.get("station_name") or ""), "Station name", 160)
        asset_location_label = _bounded_text(str(fields.get("asset_location_label") or ""), "Asset location", 200)
        humidity_value = _bounded_float(str(fields.get("ambient_humidity_pct") or ""), "Ambient humidity", 0, 100)
        latitude_value = _bounded_float(str(fields.get("gps_latitude") or ""), "GPS latitude", -90, 90)
        longitude_value = _bounded_float(str(fields.get("gps_longitude") or ""), "GPS longitude", -180, 180)
        gps_accuracy_value = _nonnegative_float(str(fields.get("gps_accuracy_m") or ""), "GPS accuracy")
        voltage_value = _float(str(fields.get("voltage_kv") or ""))
        rated_mva_value = _float(str(fields.get("rated_mva") or ""))
        oil_temperature_value = _float(str(fields.get("oil_temperature_c") or ""))
        ambient_temperature_value = _float(str(fields.get("ambient_temperature_c") or ""))
        sample_dt = datetime.fromisoformat(str(fields.get("sample_date_time") or ""))
    except ValueError as exc:
        return JSONResponse({"error": str(exc) or "Invalid offline field data"}, status_code=400)
    if not assignment:
        allowed_packages = {row["name"] for row in package_catalog(db, site.id)}
        if requested_package not in allowed_packages:
            return JSONResponse({"error": "Requested test package is not active for this laboratory site"}, status_code=400)
    if container_count < 1 or container_count > 100:
        return JSONResponse({"error": "Container count must be between 1 and 100"}, status_code=400)

    photos = body.get("photos") or []
    if not isinstance(photos, list):
        return JSONResponse({"error": "Invalid offline photo list"}, status_code=400)
    validated_offline_photos: list[tuple[bytes, str, str, str]] = []
    total_bytes = 0
    for idx, photo in enumerate(photos):
        if not isinstance(photo, dict):
            return JSONResponse({"error": "Invalid offline photo record"}, status_code=400)
        data_url = str(photo.get("data") or "")
        if not data_url.startswith("data:image/") or "," not in data_url:
            return JSONResponse({"error": "Invalid offline photo data"}, status_code=400)
        _, encoded = data_url.split(",", 1)
        try:
            raw = base64.b64decode(encoded, validate=True)
        except Exception:
            return JSONResponse({"error": "Invalid offline photo encoding"}, status_code=400)
        total_bytes += len(raw)
        if total_bytes > MAX_PHOTO_TOTAL_BYTES:
            return JSONResponse({"error": "Offline photo payload exceeds 25 MB"}, status_code=413)
        if len(raw) > MAX_PHOTO_BYTES:
            return JSONResponse({"error": "Each offline photo must be 10 MB or smaller"}, status_code=413)
        try:
            ext = _validate_image_bytes(raw)
        except ValueError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)
        validated_offline_photos.append((raw, ext, str(photo.get("kind") or "General")[:60], Path(str(photo.get("name") or f"offline_{idx}{ext}")).name[:220]))

    if existing_asset_id:
        asset = db.get(Asset, existing_asset_id)
        if not asset or not asset.active or asset.client_id != client_id:
            return JSONResponse({"error": "Asset is not active for selected client"}, status_code=400)
    else:
        if not asset_code or not serial_number:
            return JSONResponse({"error": "Asset code and serial number are required"}, status_code=400)
        duplicate_asset = db.scalar(select(Asset).where(Asset.client_id == client_id, Asset.asset_code == asset_code))
        if duplicate_asset:
            return JSONResponse({"error": "Asset code already exists for this client; select the existing asset"}, status_code=400)
        asset = Asset(
            client_id=client_id,
            asset_code=asset_code,
            serial_number=serial_number,
            equipment_type=equipment_type,
            manufacturer=manufacturer,
            station_name=station_name,
            asset_location_label=asset_location_label,
            voltage_kv=voltage_value,
            rated_mva=rated_mva_value,
            latitude=latitude_value,
            longitude=longitude_value,
        )
        db.add(asset)
        db.flush()

    request_number, _, public_token = next_request_identifiers(db, site)
    sample = SampleRequest(
        request_number=request_number,
        public_token=public_token,
        barcode_value=offline_barcode,
        status=SampleStatus.SUBMITTED.value,
        site_id=site.id,
        client_id=client_id,
        quotation_id=quote.id if quote else None,
        purchase_order_id=po.id if po else None,
        asset_id=asset.id,
        sampler_id=user.id,
        sampling_assignment_id=assignment.id if assignment else None,
        submission_channel="CLIENT_FIELD_OFFLINE" if user.role in {Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value} else "TSCO_FIELD_OFFLINE",
        sample_date_time=sample_dt,
        sampling_point=sampling_point,
        requested_package=requested_package,
        sample_origin="TSCO Field-Sampled" if user.role not in {Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value} else "Client-Originated / Direct Delivery",
        priority=(assignment.order.priority.upper() if assignment and assignment.order and assignment.order.priority else "NORMAL"),
        due_at=(assignment.order.due_at if assignment and assignment.order else None),
        client_sample_reference=client_sample_reference,
        oil_temperature_c=oil_temperature_value,
        ambient_temperature_c=ambient_temperature_value,
        ambient_humidity_pct=humidity_value,
        gps_latitude=latitude_value,
        gps_longitude=longitude_value,
        gps_accuracy_m=gps_accuracy_value,
        field_notes=str(fields.get("field_notes") or "").strip(),
        container_count=max(1, int(container_count)),
        submitted_at=datetime.utcnow(),
    )
    db.add(sample)
    db.flush()
    if assignment:
        assignment.status = "COMPLETED"
        assignment.completed_at = datetime.utcnow()
        assignment.completed_sample_id = sample.id
        if assignment.resample_of_sample_id:
            original_sample = db.get(SampleRequest, assignment.resample_of_sample_id)
            if original_sample:
                add_event(
                    db, original_sample, user, "TECHNICAL_RESAMPLE_COLLECTED", original_sample.status,
                    f"Replacement offline field sample {sample.request_number} collected under {assignment.assignment_code}",
                    sample.gps_latitude, sample.gps_longitude,
                )
    add_event(db, sample, user, "OFFLINE_FIELD_SYNC", sample.status, "Offline field record synchronized to server", sample.gps_latitude, sample.gps_longitude)

    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    written_paths: list[Path] = []
    barcode_artifacts: dict[str, str] = {}
    accepted_photos = len(validated_offline_photos)
    try:
        for idx, (raw, ext, kind, original_name) in enumerate(validated_offline_photos):
            stored = UPLOAD_DIR / f"sample_{sample.id}_offline_{idx}_{datetime.utcnow().timestamp():.0f}{ext}"
            stored.write_bytes(raw)
            written_paths.append(stored)
            db.add(SamplePhoto(sample_request_id=sample.id, kind=kind, original_name=original_name, stored_path=str(stored)))

        barcode_artifacts = generate_assets(offline_barcode, request_number, client.name, asset.asset_code, BARCODE_DIR)
        add_audit(
            db,
            actor=user,
            request=request,
            action="OFFLINE_FIELD_SAMPLE_SYNCHRONIZED",
            entity_type="SampleRequest",
            entity_id=sample.id,
            summary=f"Synchronized {sample.request_number} for {client.code}",
            details={"barcode": offline_barcode, "asset": asset.asset_code, "photo_count": accepted_photos, "local_id": body.get("id")},
        )
        db.commit()
    except Exception:
        db.rollback()
        for path in written_paths:
            path.unlink(missing_ok=True)
        for artifact in barcode_artifacts.values():
            Path(artifact).unlink(missing_ok=True)
        raise
    return {
        "ok": True,
        "sample_id": sample.id,
        "request_number": sample.request_number,
        "barcode": sample.barcode_value,
        "status": sample.status,
        "photo_count": accepted_photos,
    }
