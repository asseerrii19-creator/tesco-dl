from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import Role, User
from ..security import require_user
from ..role_matrix import ROLE_REVIEW_MATRIX

router = APIRouter(prefix="/organization", tags=["organization and roles"])
INTERNAL = {
    Role.FIELD_SAMPLER.value, Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value,
    Role.DATA_ENTRY.value, Role.SAMPLE_RECEIVING.value, Role.LAB_TECHNICIAN.value,
    Role.SENIOR_CHEMIST.value, Role.QUALITY.value, Role.TECHNICAL_MANAGER.value,
    Role.MANAGEMENT.value, Role.SYSTEM_ADMIN.value,
}

ORG = {
    "general_manager": "Salah Al-Shajira",
    "excellence": "Ohood Al Hareeqi",
    "secretary": "Renad Al Qahtani",
    "field_manager": "Abdulmajeed",
    "lab_manager": "Rwad",
    "data_entry": "Ahmed Al Qahtani",
    "samplemen": ["Mohammed Amir", "Matiullah Khan", "Rahmatullah Abdul Momin", "Mohammed Majid", "Mubarak Abdullah"],
    "client_coordination": ["Malindu Eranda", "Mohammed Athaf", "Muhammed Arsalan"],
    "external_coordination": ["Sara Al Otaibi"],
    "seniors": ["Mohammed Al Yahya", "Tara Al Ghamdi", "Reem Al Otaibi"],
    "chemists": ["Ali Al Orain", "Syed Azhar", "Hadeel Al Rashidi", "Anandhu Krishna", "Subindev Valuparampil", "Abdullah Al Hindi", "Ziyad Al-Harbi"],
    "technicians": ["Faisal Al Shihri", "Sultan Al Subaie", "Anas Asiri", "Muhanand Al Azhri"],
    "glassware": ["Sahid Husain"],
    "sales_specialist": "Humayoon",
    "salesman": "Khalid Alali",
    "shared_services": ["HR", "QHSE", "Legal Affairs", "Procurement", "Finance", "IT", "ERB"],
}

@router.get("")
def organization(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, INTERNAL)
    users = db.scalars(select(User).where(User.active.is_(True)).order_by(User.full_name)).all()
    mapped_roles = []
    for role, spec in ROLE_REVIEW_MATRIX.items():
        mapped_roles.append({"role": role, **spec, "accounts": [u for u in users if u.role == role]})
    return templates.TemplateResponse(
        "organization.html",
        {"request": request, "user": user, "org": ORG, "role_matrix": mapped_roles},
    )
