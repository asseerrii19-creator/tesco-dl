# TSCO Digital Laboratory Platform v2.6.3 — UAT Hardening Summary

v2.6.3 is the hardening successor to v2.6.2. It closes defects discovered by source review, workflow testing and clean-environment verification rather than relying on HTTP-200 checks alone.

## Material corrections

1. Unified authentication entry and role-driven routing.
2. Server-enforced role/write boundaries across sampling, intake, receiving, laboratory, assessment and release workflows.
3. Server-authoritative Laboratory synchronization with conflict detection.
4. Append-only Result/QC evidence and explicit retest/result revision behavior.
5. Controlled resampling handoff from technical assessment to Sampling Operations and Field capture.
6. SQL/admin master-data authority for clients, staff, test packages and controlled documents.
7. Controlled-document revision/content validation and protected delivery.
8. Server backup/restore and atomic identifiers.
9. Authenticated offline data isolation and static-only Service Worker cache.
10. Multi-site corrections so Laboratory and Field offline identifiers follow the authenticated/assigned site rather than silently forcing DMM.
11. Packaging cleanup removes runtime SQLite, generated barcodes/documents and Python/test caches from the delivery artifact.

## UAT boundary

This package is suitable for controlled UAT. It is not a production go-live approval. Real Render/mobile browser acceptance and official LMS integration remain mandatory before production use.
## Additional final-pass hardening
- Backup restore is laboratory-site bound and rejects malformed operational collections before persistence.
- Retest IDs are unique, retest requests must reference an existing controlled result, and completion requires a linked retest result.
- Duplicate report-release rows for the same sample are rejected.
- DOCX/XLSX controlled-document uploads validate the internal Office container structure.
- Common field image formats are decoded/verified before evidence is stored.
- Docker Compose persistence now maps the complete `TSCO_DATA_DIR` so uploads, barcode labels and controlled documents survive container replacement.

