# IT / Developer Handover — v2.6.8 LMS-Aligned Production Candidate

## Purpose

Preserve the working operational platform while connecting it to TSCO/company infrastructure and the existing **LMS**.

## Application boundary

The platform contains the functional sample lifecycle, roles, client isolation, multi-site structure, Sampling Supervisor → Operations request handoff, direct client-delivered intake, unified Sample Intake & Distribution, laboratory operations, QC, technical review, retained-sample control, audit, barcode, client tracking and database-backed operational configuration.

The platform does **not** replace the LMS as the official final-report system.

## v2.6.8 operational ownership alignment

- **Sampling Supervisor** may raise a Sampling Request to Operations; **Operations** remains the owner of the official Sampling Order and commercial/operational validation.
- **Sample Intake & Distribution** owns Data Review, LMS Registration, Physical Receiving, Sample Batch/Distribution and release to Laboratory. Data Entry and Receiving remain separate accountable roles inside the same workspace for audit traceability.
- **Direct client-delivered samples** can be created at Sample Intake without a sampler account and can carry the client paper/PDF/image as evidence.
- **Laboratory Operations** receives a platform sample only after Intake sets `READY_FOR_LAB`.
- **Senior Chemist** is the operational owner of Retained Samples; **Quality** has retained/QC compliance visibility and read-only site audit visibility.
- Retained storage is reserved at laboratory handoff; the configured retention clock activates when LMS confirms the official report.

## v2.6.8 Quality Control Distribution

The Quality workspace digitizes the laboratory monthly Quality Control Distribution. The server publishes the monthly Primary/Backup chemist rotation for Balances, Electrode, Gas Supplies, Gas Cylinder daily-record responsibility, Chemical Inventory, Sample Storage and Shower/Eye Wash checks. Published schedules are server-controlled; assigned chemists record PASS/ATTENTION/FAIL and the completion is written to the central audit trail. Quality retains oversight/read visibility. See `QUALITY_CONTROL_DISTRIBUTION_v2.6.8.md`.

## LMS connector boundary

`app/integrations/lms/` contains the current connector abstraction and mock sample-registration adapter. The official connector must be implemented only after IT confirms the real LMS interface and sandbox.

The confirmed reporting boundary is:

`Platform technical approval → Technical Manager approval for LMS submission → LMS closure/report issue → LMS confirmation/report returned to platform`

v2.6.8 preserves `READY_FOR_LMS` so the platform cannot confuse internal approval with official client report issuance. `REPORT_RELEASED` is reserved for LMS-confirmed official issuance.

See `SYSTEM_BOUNDARY_LMS_REPORTING.md`.

## Multi-tenant / multi-site intent

- Client users are isolated by company and optional organization scope.
- Local operational users are scoped by site.
- Corporate management may receive consolidated visibility.
- Sites, clients and users are administered from the platform.

## Production items for IT

- UAT hosting/server/cloud decision and ownership model.
- PostgreSQL production/UAT database and migrations.
- Corporate hostname/domain/subdomain and HTTPS/TLS.
- Network segmentation and approved external client access model.
- Backup/restore, persistent document storage, monitoring and logs.
- Secret management and production environment variables.
- Corporate identity / SSO decision.
- Official LMS integration for:
  - sample/job identity,
  - approved result transfer,
  - job closure confirmation,
  - official report number/status,
  - official report PDF/link retrieval where supported.
- Quality/Laboratory/Operations/IT UAT acceptance before production go-live.

## Important implementation rule

Do not redesign the validated laboratory workflow merely to connect LMS. Map the approved workflow to the official LMS interface through the integration boundary unless UAT identifies a genuine business-process gap.
