# TSCO Digital Laboratory Platform — Production Deployment Runbook

## Purpose
This package converts the internally validated v2.6.9 workflow/quality-aligned application into an install-ready corporate deployment package. The package includes the v2.6.9 operational workflow and monthly Quality Distribution alignment and the confirmed LMS reporting boundary; the deployment layer provides production hosting, TLS termination, PostgreSQL, persistent data volumes, preflight validation, backup/restore scripts, and a controlled handover checklist.

## Recommended topology

Corporate DNS / approved hostname
→ Corporate firewall / WAF (if required)
→ NGINX TLS reverse proxy (this package or an existing corporate reverse proxy)
→ TSCO application container
→ PostgreSQL
→ Persistent `/var/data` volume for uploads, barcodes, and controlled documents

The PostgreSQL network is internal-only. The application container is not published directly to the host; HTTPS is exposed through the reverse proxy.

## First deployment

1. Copy `.env.production.template` to `.env.production`.
2. IT fills the hostname, database credentials, application secret, and one-time bootstrap administrator password. Store production secrets in the approved company vault/process.
3. Put the approved certificate at `deploy/certs/tls.crt` and private key at `deploy/certs/tls.key`.
4. Run:

   `./scripts/production_preflight.sh .env.production`

5. Start:

   `docker compose --env-file .env.production -f docker-compose.production.yml up -d --build`

6. Confirm containers:

   `docker compose --env-file .env.production -f docker-compose.production.yml ps`

7. Run external smoke test from a workstation that trusts the company certificate:

   `python scripts/production_smoke_test.py https://<SERVER_NAME>`

8. Sign in using the bootstrap administrator account and immediately change the one-time password.
9. Configure sites, users, clients, hierarchy, master data, test packages, and controlled documents in the approved UAT process.
10. Keep `LMS_MODE=mock` until the official integration test environment is supplied and approved.

## Update procedure

- Take a verified database backup and `/var/data` backup.
- Deploy only a versioned, approved release package.
- Rebuild application container.
- Database migrations run automatically at container startup (`alembic upgrade head`).
- Run smoke tests and business regression/UAT checks.
- Keep rollback package and matching backups until acceptance closes.

## Backup

Database:

`./scripts/production_backup.sh .env.production`

The database backup does **not** include `/var/data`. IT must include the named `tsco_data` volume (uploads, barcodes, controlled documents) in the corporate backup policy. Database and file backups should be taken as one restore set where possible.

## Restore
Use only during an approved restore window:

`./scripts/production_restore.sh backups/<file>.sql.gz .env.production`

Then restore the matching `/var/data` backup and run smoke/UAT checks before reopening access.

## Production gates still owned by the company

A technically install-ready package is not, by itself, authorization for production go-live. Before external/production release, complete the company's required security review, vulnerability/penetration testing, backup/restore test, access review, SSO decision, official LMS integration UAT, and business/Quality/IT approvals.


## LMS reporting boundary

During controlled UAT, keep `LMS_MODE=mock` unless IT provides the approved LMS sandbox/interface. The platform may reach `READY_FOR_LMS` after Technical Manager approval, but the terminal official client-report state must only be applied after LMS confirms job closure/report issuance. See `SYSTEM_BOUNDARY_LMS_REPORTING.md`.
