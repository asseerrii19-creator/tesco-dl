# TSCO Digital Laboratory Platform — v2.6.3 Verification Report

Date: 2026-09-02
Build identity: `2.6.3-uat-hardened`
Migration head: `7a1c2d3e4f50`
Status: **Controlled UAT candidate — not an unconditional production go-live declaration.**

## Automated verification

- Full pytest suite: **50 passed / 0 failed**.
- Current warning count: 739 deprecation warnings; these are technical-debt warnings, not failing assertions.
- Reversible migration cycle: `upgrade head -> downgrade base -> upgrade head` passed on a fresh SQLite database.
- Active static JavaScript: all files passed `node --check`.
- Rendered Laboratory Operations console: all extracted inline scripts passed `node --check`.
- Fresh-unpacked release ZIP verification: **50 passed / 0 failed**, migration cycle returned to `7a1c2d3e4f50 (head)`, and static JavaScript checks passed.
- Role navigation crawl: every link visible to each seeded role opens without an unexpected 403/500.
- Direct workflow boundary tests verify forbidden role actions are rejected server-side.

## High-risk functional areas verified

- Unified sign-in and role-directed routing.
- Login throttling/audit and cross-site state-change rejection.
- Field direct and offline capture validation, payload limits, assignment scoping and idempotency.
- User+site-scoped Field draft/IndexedDB storage.
- Static-only Service Worker cache; authenticated HTML/API is not cached.
- Laboratory user+site browser mirror with server-authoritative synchronization and revision conflicts.
- Result/QC append-only integrity and explicit result revision linkage.
- Controlled retest request/completion while preserving the original result.
- Senior Chemist RESAMPLE decision -> Operations resample order/assignment -> Field replacement sample, preserving the original sample record.
- Senior Chemist technical review separated from Technical Manager final report release/revision.
- Report release prerequisites and unauthorized-release rejection.
- Admin user/site/test-package/document CRUD regressions.
- Controlled-document duplicate revision prevention, supersession/reactivation lifecycle, content-signature validation, size limits and protected no-store download.
- Atomic request/order identifiers under concurrency.
- Laboratory OperationsState backup -> reset -> restore round-trip with authorization, revision control, site-binding and backup-shape validation.
- Retest records require unique IDs, a valid existing result/batch/test reference, and cannot transition to Completed without the linked retest result.
- Final report state rejects duplicate release records for the same sample.
- Controlled Office uploads validate real DOCX/XLSX container structure instead of accepting a generic ZIP signature.
- Field JPG/PNG/WebP evidence is decoded/verified before persistence; signature-only corrupt images are rejected.
- Multi-site Laboratory console state uses the authenticated site; Field offline barcode prefix uses the authenticated site.
- Legacy bundled Laboratory controlled-document files removed; `/lab-ops/documents/...` is a protected redirect to the central library.

## Package/security hygiene checks

- Only `/static` is mounted as a public static directory.
- Uploads, barcode labels and controlled documents are served through authenticated/scoped routes rather than public file mounts.
- Legacy `/login/employee`, `/login/field`, `/login/client` references were removed from application navigation; compatibility routes remain server-side.
- Render UAT explicitly uses generated secrets, `SEED_DEMO_DATA=false`, `SHOW_DEMO_ACCOUNTS=false`, `ENABLE_PUBLIC_TRACKING=false`, and `ENABLE_API_DOCS=false`.
- Development/local-review demo credentials remain in local-only bootstrap/test tooling and are not activated by the Render UAT configuration.
- Docker Compose now persists the actual `TSCO_DATA_DIR` (`/var/data`) in one named volume, covering uploads, barcode artifacts and controlled documents; the previous unused `/app/app/data/...` mounts were removed.
- `.dockerignore`/`.gitignore` exclude runtime controlled-document content; deployment Docker builds also exclude the test suite.

## Verification boundary still requiring environment UAT

- Real Chromium/mobile rendering could not be completed in the audit container because local browser navigation is blocked by an environment administrator policy (`ERR_BLOCKED_BY_ADMINISTRATOR`). JavaScript syntax/static responsive checks were completed, but real-device rendering still requires Render/mobile UAT.
- `LMS_MODE=mock` remains enabled in Render UAT. Official LMS integration, credentials, retry behavior and production data exchange require environment-specific acceptance.
- PostgreSQL/Render disk backup policy, restore drill, corporate SSO/identity policy, TLS/domain configuration and operational monitoring are deployment-owner acceptance items.
- Visual identity, final palette and logo treatment are intentionally deferred until functional UAT hardening is frozen.
