
## v2.8.0 Full Review Baseline — 14 Sep 2026

Use `FINAL_VERIFICATION_v2.8.0.md` and `/review-guide` as the current review authority. Earlier verification documents remain historical evidence for prior baselines.

# TSCO Digital Laboratory Platform — v2.7.0 Review Implementation

This is the corrected final UAT candidate for functional/developer review before company IT connects the official LMS interface and approves production deployment.

## Fastest local start — Windows

Double-click:

`START_LOCAL_REVIEW.bat`

Then open:

`http://127.0.0.1:8000`

Primary review administrator:

- Email: `admin@tsco.local`
- Password: shown in the terminal/command window when the local-review launcher starts

The administrator can review the complete platform and configure sites, clients, users, controlled documents and test packages from the web interface.

## Useful review accounts

All seeded local-review accounts use the same **generated per-run password** printed by `START_LOCAL_REVIEW.bat` / `START_LOCAL_REVIEW.sh`. No fixed demo password is stored in the launcher or deployment configuration.

- Corporate management: `corporate@tsco.local`
- Dammam management: `manager@tsco.local`
- Operations: `operations@tsco.local`
- Sampling supervisor: `supervisor@tsco.local`
- Field sampler: `fieldman@tsco.local`
- Sample Intake — Data Review: `intake@tsco.local`
- Sample Intake — Physical Receiving: `receiving@tsco.local`
- Laboratory: `chemist@tsco.local`
- Senior chemist: `senior@tsco.local`
- Quality: `quality@tsco.local`
- SEC client: `client@sec.local`
- Saudi Aramco client: `client@aramco.local`

Client portal accounts are company-isolated: a client user is scoped to its own `client_id`.

## Multi-site review

Dammam is active by default. Jubail and Bahrain are seeded as future sites and can be activated from:

`Administration → Sites & Laboratories`

Assign local users to a site from:

`Administration → Users & Access`

A management account with no single site assignment receives the consolidated corporate view.

## Live operational configuration

The following are managed from the running platform without editing source code:

- Sites / laboratories
- Clients
- Users, roles, site assignment and client scope
- Assets, quotations and purchase orders
- Controlled SOP / Method / EOP / Quick Guide revisions
- Test packages and their test lists

Publishing a new controlled-document revision supersedes the previous active revision with the same code/scope while keeping revision history.

## v2.7.0 laboratory assignment review

Before reviewing results entry, sign in as Senior Chemist and configure **Test Workstation Assignment**. Use Single, Primary + Backup, or All Laboratory Chemists. A Laboratory Technician receives only current assigned analytical work and the server rejects unassigned result entry. Analytical/Test QC follows analytical assignment; Monthly/Routine QC remains a separate Quality assignment.

Operational workstations are: Water; Electrical; DGA; Furan / Passivator; DBDS / BHT / Toluene / PCB; TAN / Peroxide / RSH / H2S; Corrosion / CCD; Physical / Chemistry; plus remaining Special Tests.

Controlled SOP/Method/EOP revisions can be linked to workstation, test and method/standard.

## Main review path

Sampling Supervisor Request → Operations Sampling Order → Field Capture → Sample Intake & Distribution (Data Review → LMS Registration → Physical Receiving → Batch/Distribution) → Laboratory Operations → QC → Technical Assessment → Senior Chemist Approval → Technical Manager Approval for LMS → LMS Official Report → Client tracking. Direct client-delivered samples enter directly at Sample Intake & Distribution and bypass field sampling.

## Quality Control Distribution review

Open `Laboratory → Quality` to review the current monthly server-generated Quality Control Distribution. It includes Equipment & Safety and Materials, Gases & Storage duties with rotating Primary + Backup chemists, completion status, historical monthly snapshots and central audit events. See `QUALITY_CONTROL_DISTRIBUTION_v2.6.8.md`.

## Mac / Linux

Run:

`./START_LOCAL_REVIEW.sh`

Then open `http://127.0.0.1:8000`.

## Shared server / company environment

Use `docker-compose.yml` with PostgreSQL. IT then supplies/approves the official LMS connector, including approved-result transfer, LMS closure confirmation and official report return, plus company authentication/SSO, server/domain/HTTPS, backup/monitoring and production deployment controls.


For developer review, validate `/admin/master-data`, `/admin/hierarchy`, `/admin/workflows`, and `/admin/integrations` before LMS connector work.

## Laboratory review in v2.6
Open any Laboratory item from the main sidebar. The full Laboratory Operations functions now stay visually inside the same TSCO Digital Laboratory shell rather than appearing as a second site inside the platform.


## v2.6 client hierarchy demo accounts
- Saudi Aramco corporate: `client@aramco.local` — company-wide.
- Saudi Aramco Abqaiq: `abqaiq@aramco.local` — Abqaiq subtree only.
- SEC Eastern Region: `eastern@sec.local` — Eastern Region subtree only.

Client hierarchy and account scope are managed under Admin → Organization Hierarchy and Admin → Users & Access.

## v2.7.0 review-ready closeout
Before review, read:
1. `REVIEW_READY_CLOSEOUT.md`
2. `MASTER_REQUIREMENTS_TRACEABILITY_CLOSEOUT.md`
3. `TECHNICAL_RESULT_MATRIX_CLOSEOUT.md`
4. `PENDING_EXTERNAL_INPUTS.md`
5. `FINAL_VERIFICATION_v2.7.0.md`

## v2.7.0 Operational & Quality Control review

Sign in as Quality / Senior Chemist / Technical Manager / Management / System Admin and open **Review & Control -> Operational & Quality Control**. Review Equipment, Validation/Verification, ILC/PT, NCR/CAPA, Competency, Leave/Shift/On-call, Result Rules/LTD, Controlled Evidence, Troubleshooting, Asset History and Reports/LMS.

Laboratory staff also receive **My QC / Validation Tasks** and **My Availability & Leave Plan** in the Laboratory navigation.
