#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -d .venv ]; then python3 -m venv .venv; fi
source .venv/bin/activate
python -m pip install -r requirements.txt
export APP_ENV=development
export APP_SECRET="${APP_SECRET:-$(python -c 'import secrets; print(secrets.token_urlsafe(48))')}"
export DATABASE_URL="${DATABASE_URL:-sqlite:///./app/data/tsco_platform.db}"
export SEED_DEMO_DATA="${SEED_DEMO_DATA:-true}"
export SHOW_DEMO_ACCOUNTS=false
export BOOTSTRAP_ADMIN_EMAIL="${BOOTSTRAP_ADMIN_EMAIL:-admin@tsco.local}"
export BOOTSTRAP_ADMIN_NAME="${BOOTSTRAP_ADMIN_NAME:-System Administrator}"
export LOCAL_REVIEW_PASSWORD="${LOCAL_REVIEW_PASSWORD:-$(python -c 'import secrets; print(secrets.token_urlsafe(18))')}"
export BOOTSTRAP_ADMIN_PASSWORD="${BOOTSTRAP_ADMIN_PASSWORD:-$LOCAL_REVIEW_PASSWORD}"
export DEMO_USER_PASSWORD="${DEMO_USER_PASSWORD:-$LOCAL_REVIEW_PASSWORD}"
export REQUIRE_BOOTSTRAP_PASSWORD_CHANGE=false
export LMS_MODE=mock
export ENABLE_API_DOCS=true
printf '\nLocal review credentials (generated for this run)\n  Email: %s\n  Password: %s\n\n' "$BOOTSTRAP_ADMIN_EMAIL" "$LOCAL_REVIEW_PASSWORD"
if command -v open >/dev/null 2>&1; then (sleep 2; open http://127.0.0.1:8000 >/dev/null 2>&1 || true) & fi
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
