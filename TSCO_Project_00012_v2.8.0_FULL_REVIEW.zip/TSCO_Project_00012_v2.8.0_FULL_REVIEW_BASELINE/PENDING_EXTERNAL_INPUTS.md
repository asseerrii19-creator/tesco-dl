# Pending External Inputs Before Production Freeze

These do **not** block review of the current package, but they block a truthful Production-Final declaration where applicable.

1. Revised Quality documents from Ahood for items still under review.
2. Final approved Detection Limit / decimal / significant-figure register for fields not explicitly supported by the current supplied report/method records.
3. Confirmed numeric Furan Total calculation rule/source when 2FAL is not LTD (current operational UI intentionally captures 2FAL only).
4. Final transformer Asset Master field ownership and source-of-truth approval.
5. Final LMS API/connector contract, credentials, callback and official report-file/reference behavior.
6. Final IT deployment decisions: SSO, PostgreSQL host, secrets, network/DMZ, backup retention, monitoring and repository/CI/CD ownership.
7. Final HR confirmation for leave-planning and on-call business rules.
8. Final Quality confirmation for PT/ILC planning-period discrepancy and record-retention discrepancy identified in source documents.
