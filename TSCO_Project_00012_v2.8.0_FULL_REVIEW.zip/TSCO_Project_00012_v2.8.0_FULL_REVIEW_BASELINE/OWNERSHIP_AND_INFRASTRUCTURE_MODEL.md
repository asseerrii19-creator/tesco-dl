# Ownership & Infrastructure Model

## Recommended ownership state
For the platform to be clearly inside the company technology estate:

- The root domain and subdomain are controlled by the company.
- Hosting/server/cloud subscription is controlled and billed by the company.
- DNS, TLS certificates, firewall/WAF, backups, monitoring, and privileged credentials are controlled by IT.
- PostgreSQL data and persistent application files remain in company-controlled infrastructure.
- Source/release packages are stored in the company-approved repository or document/software archive.
- Named business, technical, and Quality owners approve changes and releases.

## Domain vs hosting
The **domain/subdomain** is the address users visit. **Hosting** is the server/environment where the application actually runs. They are separate assets. A corporate subdomain such as `lab.company.com` is normally preferable to buying an unrelated new domain for an internal corporate system.

## External client access
If clients need access, expose only the approved HTTPS entry point through the company's normal external-access architecture (firewall/WAF/reverse proxy/DMZ as required). The database must never be exposed directly to the internet.
