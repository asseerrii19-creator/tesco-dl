from __future__ import annotations

from collections import Counter, defaultdict

from fastapi import APIRouter, Depends, Request, Form, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from fastapi.responses import RedirectResponse

from ..database import get_db
from ..dependencies import templates
from ..models import DataQualityIssue, Role, SampleRequest, SampleStatus, Site, User, AuditLog, QualityCase, StaffAvailability, EquipmentAsset, ControlledReport, OperationalProject
from ..security import require_user
from ..services.lab_operations import get_operations_state, platform_sample_lab_projection_from_payload, reconcile_operations_to_platform
from ..services.technical_review_assignments import CANONICAL_SENIOR_EMAILS, active_review_assignment, ensure_site_review_assignments, reassign_review
from ..services.audit import add_audit

router = APIRouter(prefix="/management", tags=["management"])
ALLOWED = {Role.MANAGEMENT.value, Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value}


@router.get("")
def dashboard(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    sample_stmt = select(SampleRequest).order_by(SampleRequest.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        sample_stmt = sample_stmt.where(SampleRequest.site_id == user.site_id)
    samples = db.scalars(sample_stmt).all()
    payload_by_site = {}
    for visible_site_id in {row.site_id for row in samples}:
        site_row = db.get(Site, visible_site_id)
        if not site_row:
            continue
        _, site_payload = get_operations_state(db, site_row)
        if reconcile_operations_to_platform(db, site_payload, site_row.id, actor=None):
            db.commit()
        payload_by_site[visible_site_id] = site_payload
    workflow_rows = []
    workflow_statuses = {SampleStatus.READY_FOR_LAB.value, SampleStatus.REGISTERED.value, SampleStatus.TESTING.value, SampleStatus.TECHNICAL_REVIEW.value, SampleStatus.REPORT_APPROVED.value, SampleStatus.REPORT_RELEASED.value}
    for row in samples:
        if row.status not in workflow_statuses:
            continue
        payload = payload_by_site.get(row.site_id)
        projection = platform_sample_lab_projection_from_payload(payload, row) if payload else {"blocker": "Laboratory workflow state unavailable", "tests_complete": 0, "tests_required": 0, "workstations_closed": 0, "workstations_required": 0}
        workflow_rows.append({"sample": row, "projection": projection})
    review_assignments = ensure_site_review_assignments(db, [row for row in samples if row.status == SampleStatus.TECHNICAL_REVIEW.value], actor=None)
    for item in workflow_rows:
        item["review_assignment"] = review_assignments.get(item["sample"].id) or active_review_assignment(db, item["sample"].id)
    status_counts = Counter(sample.status for sample in samples)
    sampler_stmt = select(User).where(User.role.in_([Role.FIELD_SAMPLER.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value]))
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        sampler_stmt = sampler_stmt.where(User.site_id == user.site_id)
    samplers = db.scalars(sampler_stmt).all()
    all_issues = db.scalars(select(DataQualityIssue).order_by(DataQualityIssue.created_at.desc())).all()
    visible_sample_ids = {sample.id for sample in samples}
    issues = [issue for issue in all_issues if issue.sample_request_id in visible_sample_ids]
    issue_counts = Counter(issue.issue_type for issue in issues)

    sites = db.scalars(select(Site).order_by(Site.code)).all()
    site_breakdown = []
    for site in sites:
        site_samples = [sample for sample in samples if sample.site_id == site.id]
        site_breakdown.append({
            "code": site.code,
            "name": site.name,
            "laboratory": site.laboratory_name,
            "active": site.active,
            "total": len(site_samples),
            "testing": sum(1 for sample in site_samples if sample.status in {"READY_FOR_LAB", "REGISTERED", "TESTING"}),
            "review": sum(1 for sample in site_samples if sample.status == "TECHNICAL_REVIEW"),
            "released": sum(1 for sample in site_samples if sample.status == "REPORT_RELEASED"),
        })

    performance = []
    for sampler in samplers:
        own = [sample for sample in samples if sample.sampler_id == sampler.id]
        own_issues = [issue for issue in issues if issue.sample.sampler_id == sampler.id]
        performance.append(
            {
                "name": sampler.full_name,
                "role": sampler.role,
                "organization": sampler.client.name if sampler.client else "TSCO",
                "samples": len(own),
                "returned": sum(1 for sample in own if sample.status == "RETURNED"),
                "rejected": sum(1 for sample in own if sample.status == "REJECTED"),
                "missing_gps": sum(1 for sample in own if sample.gps_latitude is None or sample.gps_longitude is None),
                "missing_photos": sum(1 for sample in own if not sample.photos),
                "issues": len(own_issues),
            }
        )

    # Cross-functional activity evidence: actions, reviews and approvals are summarized without ranking by sample count alone.
    audit_stmt = select(AuditLog).order_by(AuditLog.created_at.desc()).limit(2000)
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        audit_stmt = audit_stmt.where(AuditLog.site_id == user.site_id)
    audits = db.scalars(audit_stmt).all()
    activity = {}
    for row in audits:
        if not row.actor_id: continue
        item = activity.setdefault(row.actor_id, {"name": row.actor.full_name if row.actor else f"User {row.actor_id}", "actions":0, "reviews":0, "handoffs":0, "technical_approvals":0, "final_releases":0, "quality":0})
        item["actions"] += 1
        a=(row.action or "").upper()
        item["reviews"] += int("REVIEW" in a or "VERIFY" in a)
        item["handoffs"] += int(any(k in a for k in ["HANDOFF","INTAKE","RECEIV","DISTRIBUT","FIELD_COMPLETE","SAMPLE_ACCEPT"]))
        item["technical_approvals"] += int(("TECHNICAL" in a and "APPROV" in a) or a in {"REPORT_SENIOR_REVIEW_COMPLETED","DOCUMENT_TECHNICAL_REVIEW"})
        item["final_releases"] += int(a in {"REPORT_MANAGER_APPROVED_RELEASED","REPORT_CLIENT_SUBMISSION"})
        item["quality"] += int(any(k in a for k in ["QUALITY","QC","CAPA","VALIDATION","COMPETENCY","EQUIPMENT"]))
    project_statuses = ["PENDING_GM_APPROVAL", "APPROVED", "ACTIVE"] if user.role in {Role.MANAGEMENT.value, Role.SYSTEM_ADMIN.value} else ["APPROVED", "ACTIVE"]
    projects_stmt = select(OperationalProject).where(OperationalProject.status.in_(project_statuses))
    if user.role == Role.TECHNICAL_MANAGER.value:
        projects_stmt = projects_stmt.where(OperationalProject.laboratory_scope.is_(True))
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        projects_stmt = projects_stmt.where(OperationalProject.site_id == user.site_id)
    upcoming_projects = list(db.scalars(projects_stmt.order_by(OperationalProject.planned_start_at, OperationalProject.created_at.desc()).limit(100)).all())
    control_metrics = {
        "open_quality": db.query(QualityCase).filter(QualityCase.site_id==user.site_id, ~QualityCase.status.in_(["CLOSED","APPROVED"])).count() if user.site_id else db.query(QualityCase).filter(~QualityCase.status.in_(["CLOSED","APPROVED"])).count(),
        "blocked_equipment": db.query(EquipmentAsset).filter(EquipmentAsset.site_id==user.site_id, EquipmentAsset.status!="IN_SERVICE").count() if user.site_id else db.query(EquipmentAsset).filter(EquipmentAsset.status!="IN_SERVICE").count(),
        "pending_report_approval": db.query(ControlledReport).filter(ControlledReport.site_id==user.site_id, ControlledReport.status=="PENDING_MANAGER_APPROVAL").count() if user.site_id else db.query(ControlledReport).filter(ControlledReport.status=="PENDING_MANAGER_APPROVAL").count(),
        "released_reports": db.query(ControlledReport).filter(ControlledReport.site_id==user.site_id, ControlledReport.status==SampleStatus.REPORT_RELEASED.value).count() if user.site_id else db.query(ControlledReport).filter(ControlledReport.status==SampleStatus.REPORT_RELEASED.value).count(),
    }

    return templates.TemplateResponse(
        "management.html",
        {
            "request": request,
            "user": user,
            "samples": samples,
            "status_counts": status_counts,
            "issue_counts": issue_counts,
            "performance": performance,
            "site_breakdown": site_breakdown,
            "corporate_view": user.site_id is None or user.role == Role.SYSTEM_ADMIN.value,
            "activity": sorted(activity.values(), key=lambda x: x["actions"], reverse=True),
            "control_metrics": control_metrics, "upcoming_projects": upcoming_projects, "workflow_rows": workflow_rows[:100],
            "senior_reviewers": list(db.scalars(select(User).where(User.active.is_(True), User.role == Role.SENIOR_CHEMIST.value, User.site_id == user.site_id, User.email.in_(sorted(CANONICAL_SENIOR_EMAILS))).order_by(User.full_name)).all()) if user.site_id else [],
        },
    )


@router.post("/review-assignment/{sample_id}")
def manager_review_reassignment(
    sample_id: int, request: Request, primary_senior_id: int = Form(...), secondary_senior_id: str = Form(""),
    reason: str = Form(...), db: Session = Depends(get_db),
):
    user = require_user(request, db, {Role.TECHNICAL_MANAGER.value})
    sample = db.get(SampleRequest, sample_id)
    if not sample or (user.site_id and sample.site_id != user.site_id):
        raise HTTPException(status_code=404, detail="Sample not found")
    if sample.status != SampleStatus.TECHNICAL_REVIEW.value:
        raise ValueError("Senior review assignment can be changed only while the sample is in Technical Review")
    primary = db.get(User, primary_senior_id)
    secondary = db.get(User, int(secondary_senior_id)) if secondary_senior_id.strip().isdigit() else None
    if not primary:
        raise ValueError("Primary Senior Chemist is required")
    row = reassign_review(db, sample, primary=primary, secondary=secondary, actor=user, reason=reason)
    add_audit(db, actor=user, request=request, action="TECHNICAL_REVIEW_REASSIGNED", entity_type="TechnicalReviewAssignment", entity_id=row.id,
              summary=f"{sample.request_number} review reassigned to {primary.full_name}", details={"secondary": secondary.full_name if secondary else "", "reason": reason.strip(), "revision": row.revision})
    db.commit()
    return RedirectResponse("/management#workflow-monitor", status_code=303)
