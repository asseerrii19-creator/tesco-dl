from __future__ import annotations

from pathlib import Path

from datetime import datetime

from fastapi import APIRouter, Depends, Request, HTTPException
from fastapi.responses import FileResponse, RedirectResponse
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import ControlledDocument, Role, User
from ..security import require_user
from ..storage import CONTROLLED_DOCUMENT_DIR
from ..services.audit import add_audit
from ..services.capabilities import is_senior_technical, is_lab_manager

from ..services.document_catalog import document_matches

router = APIRouter(tags=["controlled documents"])
ALLOWED = {
    Role.FIELD_SAMPLER.value, Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value,
    Role.LAB_TECHNICIAN.value, Role.SENIOR_CHEMIST.value,
    Role.QUALITY.value, Role.TECHNICAL_MANAGER.value, Role.MANAGEMENT.value,
    Role.EXCELLENCE.value, Role.LAB_SUPPORT.value, Role.SYSTEM_ADMIN.value,
}
DOC_DIR = CONTROLLED_DOCUMENT_DIR


def _user(request: Request, db: Session) -> User:
    return require_user(request, db, ALLOWED)


@router.get("/documents")
def document_library(
    request: Request,
    workstation: str = "",
    test: str = "",
    method: str = "",
    q: str = "",
    document_type: str = "",
    db: Session = Depends(get_db),
):
    user = _user(request, db)
    stmt = select(ControlledDocument).where(ControlledDocument.status.in_(["ACTIVE", "REFERENCE"]))
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        stmt = stmt.where(or_(ControlledDocument.site_id.is_(None), ControlledDocument.site_id == user.site_id))
    clean_ws = workstation.strip()[:120]
    clean_test = test.strip()[:220]
    clean_method = method.strip()[:160]
    clean_q = q.strip()[:220]
    clean_type = document_type.strip().upper()[:40]
    if clean_type and clean_type not in {"METHOD", "SOP", "EOP", "QUICK GUIDE", "FORM", "OTHER"}:
        raise HTTPException(status_code=400, detail="Unsupported controlled-document type filter")
    documents = list(db.scalars(stmt.order_by(ControlledDocument.document_type, ControlledDocument.code)).all())
    documents = [d for d in documents if document_matches(d, clean_ws, clean_test, clean_method)]
    if clean_type:
        documents = [d for d in documents if (d.document_type or "").upper() == clean_type]
    if clean_q:
        terms = [part.lower() for part in clean_q.split() if part.strip()]
        def _hay(doc):
            return " ".join(str(value or "") for value in (
                doc.document_type, doc.code, doc.title, doc.revision, doc.workstation,
                doc.test_name, doc.method_name, doc.original_filename, doc.notes,
            )).lower()
        documents = [d for d in documents if all(term in _hay(d) for term in terms)]
    type_counts = {}
    for doc in documents:
        type_counts[doc.document_type] = type_counts.get(doc.document_type, 0) + 1
    return templates.TemplateResponse(
        "documents.html",
        {
            "request": request, "user": user, "documents": documents,
            "workstation": clean_ws, "test": clean_test, "method": clean_method,
            "q": clean_q, "document_type": clean_type, "type_counts": type_counts,
        },
    )


@router.get("/documents/by-code/{code}")
def open_document_code(code: str, request: Request, db: Session = Depends(get_db)):
    user = _user(request, db)
    stmt = select(ControlledDocument).where(ControlledDocument.code == code, ControlledDocument.status.in_(["ACTIVE", "REFERENCE"]))
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        stmt = stmt.where(or_(ControlledDocument.site_id.is_(None), ControlledDocument.site_id == user.site_id))
    rows = list(db.scalars(stmt).all())
    rows.sort(key=lambda d: (d.status == "ACTIVE", d.site_id == user.site_id, d.created_at), reverse=True)
    if not rows:
        return templates.TemplateResponse("not_found.html", {"request": request, "user": user, "not_found_title": "Controlled document unavailable", "not_found_message": "The controlled document is not available for this session or its controlled file is missing."}, status_code=404)
    return RedirectResponse(f"/documents/{rows[0].id}/download", status_code=303)


@router.get("/documents/{document_id}/download")
def download_document(document_id: int, request: Request, db: Session = Depends(get_db)):
    user = _user(request, db)
    doc = db.get(ControlledDocument, document_id)
    if not doc:
        return templates.TemplateResponse("not_found.html", {"request": request, "user": user, "not_found_title": "Controlled document unavailable", "not_found_message": "The controlled document is not available for this session or its controlled file is missing."}, status_code=404)
    if user.role != Role.SYSTEM_ADMIN.value and doc.status not in {"ACTIVE", "REFERENCE"}:
        return templates.TemplateResponse("not_found.html", {"request": request, "user": user, "not_found_title": "Controlled document unavailable", "not_found_message": "The controlled document is not available for this session or its controlled file is missing."}, status_code=404)
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id and doc.site_id not in {None, user.site_id}:
        return templates.TemplateResponse("not_found.html", {"request": request, "user": user, "not_found_title": "Controlled document unavailable", "not_found_message": "The controlled document is not available for this session or its controlled file is missing."}, status_code=404)
    path = DOC_DIR / Path(doc.stored_filename).name
    if not path.exists():
        return templates.TemplateResponse("not_found.html", {"request": request, "user": user, "not_found_title": "Controlled document unavailable", "not_found_message": "The controlled document is not available for this session or its controlled file is missing."}, status_code=404)
    response = FileResponse(path, filename=doc.original_filename)
    response.headers["Cache-Control"] = "private, no-store"
    return response


@router.get("/documents/governance")
def document_governance(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value})
    if not (is_senior_technical(user) or is_lab_manager(user)):
        raise HTTPException(status_code=403, detail="Controlled-document governance belongs to Senior Technical and the Technical Manager")
    stmt = select(ControlledDocument).where(ControlledDocument.status.in_(["DRAFT", "TECHNICAL_REVIEWED", "PENDING_MANAGER_APPROVAL", "ACTIVE", "SUPERSEDED", "WITHDRAWN"]))
    if user.site_id:
        stmt = stmt.where(or_(ControlledDocument.site_id.is_(None), ControlledDocument.site_id == user.site_id))
    rows = list(db.scalars(stmt.order_by(ControlledDocument.code, ControlledDocument.created_at.desc())).all())
    return templates.TemplateResponse("document_governance.html", {"request": request, "user": user, "documents": rows, "is_senior_technical": is_senior_technical(user), "is_lab_manager": is_lab_manager(user)})


@router.post("/documents/{document_id}/technical-review")
def technical_review_document(document_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.SENIOR_CHEMIST.value})
    if not is_senior_technical(user):
        raise HTTPException(status_code=403, detail="Method/SOP/EOP technical review belongs to Senior Chemist — Technical")
    doc = db.get(ControlledDocument, document_id)
    if not doc or (user.site_id and doc.site_id not in {None, user.site_id}):
        raise HTTPException(status_code=404, detail="Controlled document not found")
    if doc.status not in {"DRAFT", "RETURNED"}:
        raise HTTPException(status_code=409, detail=f"Document cannot be technically reviewed from {doc.status}")
    doc.technical_reviewed_by_id = user.id
    doc.technical_reviewed_at = datetime.utcnow()
    doc.status = "PENDING_MANAGER_APPROVAL"
    add_audit(db, actor=user, request=request, action="DOCUMENT_TECHNICAL_REVIEW", entity_type="ControlledDocument", entity_id=doc.id, summary=f"{doc.code} Rev {doc.revision} technically reviewed; pending Technical Manager approval")
    db.commit()
    return RedirectResponse("/documents/governance", status_code=303)


@router.post("/documents/{document_id}/manager-approve")
def manager_approve_document(document_id: int, request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, {Role.TECHNICAL_MANAGER.value})
    if not is_lab_manager(user):
        raise HTTPException(status_code=403, detail="Final controlled-document adoption belongs to the Lab Operational & Technical Manager")
    doc = db.get(ControlledDocument, document_id)
    if not doc or (user.site_id and doc.site_id not in {None, user.site_id}):
        raise HTTPException(status_code=404, detail="Controlled document not found")
    if doc.status != "PENDING_MANAGER_APPROVAL" or not doc.technical_reviewed_by_id:
        raise HTTPException(status_code=409, detail="Senior Technical review is required before manager approval")
    active_stmt = select(ControlledDocument).where(ControlledDocument.code == doc.code, ControlledDocument.status == "ACTIVE", ControlledDocument.id != doc.id)
    if doc.site_id is None:
        active_stmt = active_stmt.where(ControlledDocument.site_id.is_(None))
    else:
        active_stmt = active_stmt.where(ControlledDocument.site_id == doc.site_id)
    for previous in db.scalars(active_stmt).all():
        previous.status = "SUPERSEDED"
    doc.status = "ACTIVE"
    doc.manager_approved_by_id = user.id
    doc.manager_approved_at = datetime.utcnow()
    add_audit(db, actor=user, request=request, action="DOCUMENT_MANAGER_APPROVAL", entity_type="ControlledDocument", entity_id=doc.id, summary=f"{doc.code} Rev {doc.revision} approved and EFFECTIVE")
    db.commit()
    return RedirectResponse("/documents/governance", status_code=303)
