from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from ..database import get_db
from ..security import current_user, require_user
from ..dependencies import templates
from ..models import Role
from ..org_structure import employee_spec, SHARED_SERVICE_FUNCTIONS
from ..role_matrix import ROLE_REVIEW_MATRIX

router = APIRouter()


@router.get("/")
def home(request: Request, db: Session = Depends(get_db)):
    user = current_user(request, db)
    if not user:
        return RedirectResponse("/welcome", status_code=303)
    if user.must_change_password:
        return RedirectResponse("/change-password", status_code=303)
    route = {
        "field_sampler": "/field",
        "client_sampler": "/field",
        "client_operations": "/field",
        "sampling_supervisor": "/sampling-supervision",
        "operations_manager": "/operations",
        "data_entry": "/intake",
        "sample_receiving": "/intake?view=receiving",
        "lab_technician": "/lab/operations?section=workstations",
        "quality": "/quality",
        "client": "/client",
        "management": "/management",
        "sales_marketing": "/commercial",
        "client_coordinator": "/commercial",
        "finance": "/commercial",
        "excellence": "/improvement",
        "corporate_support": "/gm-office",
        "shared_services": "/workspace",
        "lab_support": "/lab-support",
        "technical_manager": "/management",
        "senior_chemist": "/lab",
        "system_admin": "/admin",
    }.get(user.role, "/welcome")
    return RedirectResponse(route, status_code=303)



@router.get("/workspace")
def company_workspace(request: Request, db: Session = Depends(get_db)):
    allowed = {
        Role.CORPORATE_SUPPORT.value, Role.SHARED_SERVICES.value, Role.LAB_SUPPORT.value,
        Role.EXCELLENCE.value, Role.MANAGEMENT.value, Role.SALES_MARKETING.value,
        Role.OPERATIONS_MANAGER.value, Role.DATA_ENTRY.value, Role.CLIENT_COORDINATOR.value,
        Role.FIELD_SAMPLER.value, Role.LAB_TECHNICIAN.value, Role.SENIOR_CHEMIST.value,
        Role.TECHNICAL_MANAGER.value, Role.QUALITY.value, Role.FINANCE.value, Role.SYSTEM_ADMIN.value,
    }
    user = require_user(request, db, allowed)
    spec = employee_spec(user.email)
    shared = None
    for function_name, email, access_role, needs in SHARED_SERVICE_FUNCTIONS:
        if email.lower() == user.email.lower():
            shared = {"function": function_name, "role": access_role, "needs": needs}
            break
    role_spec = ROLE_REVIEW_MATRIX.get(user.role, {})
    return templates.TemplateResponse("my_company_workspace.html", {
        "request": request, "user": user, "spec": spec, "shared": shared, "role_spec": role_spec,
    })

@router.get("/verify/report/{token}")
def verify_report(token: str, request: Request, db: Session = Depends(get_db)):
    from ..models import ControlledReport
    report = db.query(ControlledReport).filter(ControlledReport.qr_token == token).first()
    viewer = current_user(request, db)
    if report and report.status != "REPORT_RELEASED" and not viewer:
        report = None
    return templates.TemplateResponse("report_verify.html", {"request": request, "user": None, "report": report})
