from __future__ import annotations

from datetime import datetime
import json
import re
from sqlalchemy import select, func
from sqlalchemy.orm import Session

from ..services.capabilities import is_client_account_coordinator, is_sales_specialist
from ..models import (
    CommercialCase, CommercialEvent, CommercialRequestLine, ControlledReport, PurchaseOrder, Quotation,
    Role, SampleRequest, SampleStatus, SamplingOrder, User,
)

# Printed TSCO Communication Flow translated into a controlled state machine.
COMMERCIAL_STAGES = [
    ("LEAD_GENERATION", "Client Request / Lead", "SALES & MARKETING"),
    ("QUOTATION", "Quotation", "CLIENT ACCOUNT & COORDINATION"),
    ("CLIENT_FOLLOW_UP", "Client Decision / Follow-up", "CLIENT ACCOUNT & COORDINATION"),
    ("PURCHASE_ORDER_RECEIVED", "Purchase Order Received", "CLIENT ACCOUNT & COORDINATION"),
    ("COMPLETE_HANDOVER", "Complete Handover", "CLIENT ACCOUNT & COORDINATION"),
    ("CLIENT_COORDINATION", "Client Coordination", "FIELD OPERATIONS & CLIENT COORDINATION"),
    ("SAMPLING", "Sampling", "FIELD OPERATIONS & CLIENT COORDINATION"),
    ("SAMPLE_DELIVERY", "Sample Delivery to Laboratory", "FIELD OPERATIONS & CLIENT COORDINATION"),
    ("TESTING", "Testing", "LABORATORY OPERATIONS"),
    ("REVIEW", "Senior Technical Review", "LABORATORY OPERATIONS"),
    ("FINAL_REPORT_RELEASE", "Final Report Approval & Release", "LABORATORY OPERATIONS"),
    ("REPORT_SUBMISSION", "Report Submission to Client", "CLIENT ACCOUNT & COORDINATION"),
    # Legacy corporate-finance stages are retained in the data model only for historical records.
    # Local TSCO workflow ends at controlled report submission / parent-administration handoff.
    ("INVOICING", "Corporate Invoicing (External)", "PARENT COMPANY ADMINISTRATION"),
    ("PAYMENT_COLLECTION", "Corporate Payment Processing (External)", "PARENT COMPANY ADMINISTRATION"),
    ("CLOSED", "Corporate Closure (External)", "PARENT COMPANY ADMINISTRATION"),
]
STAGE_KEYS = [x[0] for x in COMMERCIAL_STAGES]
STAGE_LABELS = {k: label for k, label, _ in COMMERCIAL_STAGES}
STAGE_LANES = {k: lane for k, _, lane in COMMERCIAL_STAGES}

# Historical database events may contain the former two-step report boundary.
# Runtime/UI canonicalizes both to the single standalone final-release stage.
LEGACY_STAGE_ALIASES = {
    "PROPOSAL": "CLIENT_FOLLOW_UP",
    "PURCHASE_ORDER": "PURCHASE_ORDER_RECEIVED",
    "REPORT_APPROVAL": "FINAL_REPORT_RELEASE",
    "REPORT_RELEASE": "FINAL_REPORT_RELEASE",
}
for _legacy, _current in LEGACY_STAGE_ALIASES.items():
    STAGE_LABELS[_legacy] = STAGE_LABELS[_current]
    STAGE_LANES[_legacy] = STAGE_LANES[_current]

def canonical_stage(stage: str | None) -> str:
    value = str(stage or "LEAD_GENERATION")
    return LEGACY_STAGE_ALIASES.get(value, value)

SALES_STAGES = {"LEAD_GENERATION"}
COORDINATOR_STAGES = {"QUOTATION", "CLIENT_FOLLOW_UP", "PURCHASE_ORDER_RECEIVED", "COMPLETE_HANDOVER"}
OPS_STAGES = {"CLIENT_COORDINATION", "SAMPLING", "SAMPLE_DELIVERY"}
LAB_STAGES = {"TESTING", "REVIEW", "FINAL_REPORT_RELEASE"}
FINANCE_STAGES = {"INVOICING", "PAYMENT_COLLECTION", "CLOSED"}


def stage_index(stage: str) -> int:
    try:
        return STAGE_KEYS.index(canonical_stage(stage))
    except ValueError:
        return 0


def next_stage(stage: str) -> str | None:
    # TSCO local workflow terminates after the structured released-report submission.
    # Historical corporate finance stages remain readable but are never local actions.
    current = canonical_stage(stage)
    if current in {"REPORT_SUBMISSION", "INVOICING", "PAYMENT_COLLECTION", "CLOSED"}:
        return None
    idx = stage_index(current)
    return STAGE_KEYS[idx + 1] if idx + 1 < len(STAGE_KEYS) else None


def role_can_transition(user: User, target_stage: str) -> bool:
    if target_stage in SALES_STAGES:
        return is_sales_specialist(user)
    if target_stage in COORDINATOR_STAGES:
        return is_client_account_coordinator(user)
    # Operational / laboratory stages are derived from authoritative records.
    if target_stage in OPS_STAGES or target_stage in LAB_STAGES:
        return False
    # Client report submission is a structured ReportSubmission transaction tied
    # to the released ControlledReport; it is not a free-form stage action here.
    if target_stage == "REPORT_SUBMISSION":
        return False
    # Finance / payment processing is a parent-company boundary, not a local role.
    if target_stage in FINANCE_STAGES:
        return False
    return False


def _sample_stage(sample: SampleRequest | None) -> str | None:
    if not sample:
        return None
    mapping = {
        SampleStatus.SUBMITTED.value: "SAMPLING",
        SampleStatus.ACCEPTED.value: "SAMPLING",
        SampleStatus.AWAITING_RECEIPT.value: "SAMPLING",
        SampleStatus.IN_TRANSIT.value: "SAMPLING",
        SampleStatus.RECEIVED.value: "SAMPLE_DELIVERY",
        SampleStatus.READY_FOR_LAB.value: "SAMPLE_DELIVERY",
        SampleStatus.REGISTERED.value: "SAMPLE_DELIVERY",
        SampleStatus.TESTING.value: "TESTING",
        SampleStatus.TECHNICAL_REVIEW.value: "REVIEW",
        SampleStatus.REPORT_APPROVED.value: "FINAL_REPORT_RELEASE",
        SampleStatus.READY_FOR_LMS.value: "FINAL_REPORT_RELEASE",  # legacy state
        SampleStatus.REPORT_RELEASED.value: "FINAL_REPORT_RELEASE",
    }
    return mapping.get(sample.status)


def effective_stage(db: Session, case: CommercialCase) -> str:
    """Return the furthest trustworthy stage without allowing manual skipping.

    Operational stages are derived from linked order/sample state, so the business case
    stays synchronized with the actual sample lifecycle instead of duplicating status.
    Post-release commercial closure remains explicitly controlled on the case.
    """
    base = canonical_stage(case.current_stage or "LEAD_GENERATION")
    if stage_index(base) >= stage_index("REPORT_SUBMISSION"):
        return base
    linked_samples = list(db.scalars(select(SampleRequest).where(SampleRequest.commercial_case_id == case.id)).all())
    if not linked_samples:
        fallback = case.sample_request or (db.get(SampleRequest, case.sample_request_id) if case.sample_request_id else None)
        linked_samples = [fallback] if fallback else []
    derived_stages = [stage for stage in (_sample_stage(sample) for sample in linked_samples) if stage]
    derived = max(derived_stages, key=stage_index) if derived_stages else None
    if derived and stage_index(derived) > stage_index(base):
        return derived
    if case.sampling_order_id and stage_index(base) < stage_index("SAMPLING"):
        return "SAMPLING"
    return base


def add_commercial_event(
    db: Session, case: CommercialCase, actor: User | None, to_stage: str,
    *, note: str = "", reference: str = "", from_stage: str | None = None,
) -> CommercialEvent:
    event = CommercialEvent(
        commercial_case_id=case.id,
        actor_id=actor.id if actor else None,
        from_stage=canonical_stage(from_stage) if from_stage is not None else canonical_stage(case.current_stage or ""),
        to_stage=canonical_stage(to_stage),
        note=(note or "").strip(), reference=(reference or "").strip(),
    )
    db.add(event)
    return event




def parse_expected_serials(value: str) -> list[str]:
    """Normalize optional transformer serial numbers supplied with the client request.

    Serial numbers are an optional physical matching aid; the commercial request remains valid
    when they are not known at quotation time.
    """
    parts = re.split(r"[\n,;]+", value or "")
    out: list[str] = []
    seen: set[str] = set()
    for raw in parts:
        clean = str(raw or "").strip()[:120]
        key = clean.upper()
        if not clean or key in seen:
            continue
        seen.add(key); out.append(clean)
    return out[:10000]


def request_line_expected_serials(line: CommercialRequestLine) -> list[str]:
    try:
        rows = json.loads(line.expected_serials_json or "[]")
    except Exception:
        return []
    if not isinstance(rows, list):
        return []
    return parse_expected_serials("\n".join(str(x) for x in rows))

def request_scope_lines(db: Session, case: CommercialCase) -> list[CommercialRequestLine]:
    return list(db.scalars(
        select(CommercialRequestLine).where(
            CommercialRequestLine.commercial_case_id == case.id,
            CommercialRequestLine.status == "ACTIVE",
        ).order_by(CommercialRequestLine.line_number)
    ).all())


def refresh_case_request_summary(db: Session, case: CommercialCase) -> None:
    lines = request_scope_lines(db, case)
    if not lines:
        case.expected_samples = None
        case.requested_test_package = ""
        case.default_priority = "NORMAL"
        case.required_tat = ""
        return
    case.expected_samples = sum(int(row.quantity or 0) for row in lines)
    packages = {str(row.requested_package or "").strip() for row in lines}
    priorities = {str(row.priority or "NORMAL").strip().upper() for row in lines}
    tats = {str(row.required_tat or "").strip().upper() for row in lines}
    case.requested_test_package = next(iter(packages)) if len(packages) == 1 else "Mixed Request Scope"
    case.default_priority = next(iter(priorities)) if len(priorities) == 1 else "MIXED"
    case.required_tat = next(iter(tats)) if len(tats) == 1 else "MIXED"


def advance_case(
    db: Session, case: CommercialCase, actor: User, *, target_stage: str,
    note: str = "", reference: str = "", quotation_number: str = "",
    purchase_order_number: str = "", handover_commercial: str = "",
    handover_technical: str = "", handover_client_info: str = "",
    expected_samples: str = "", requested_test_package: str = "",
    default_priority: str = "NORMAL", required_tat: str = "",
) -> None:
    current = effective_stage(db, case)
    expected = next_stage(current)
    if target_stage != expected:
        raise ValueError(f"Next required stage is {STAGE_LABELS.get(expected, expected or 'complete')}; stages cannot be skipped")
    if not role_can_transition(actor, target_stage):
        raise ValueError(f"{STAGE_LABELS[target_stage]} is not an action for the active role")

    ref = (reference or "").strip()
    text = (note or "").strip()

    if target_stage == "QUOTATION":
        scope_lines = request_scope_lines(db, case)
        if not scope_lines:
            raise ValueError("Client Request Scope must be recorded before creating the quotation")
        number = (quotation_number or ref).strip()
        if not number:
            raise ValueError("Quotation number is required")
        scope_summary = "; ".join(
            f"{row.quantity} x {row.requested_package} / {row.method_family or 'DEFAULT'} / {row.priority}{(' / ' + row.required_tat) if row.required_tat else ''}"
            for row in scope_lines
        )[:240]
        quote = db.scalar(select(Quotation).where(Quotation.client_id == case.client_id, Quotation.number == number))
        if not quote:
            quote = Quotation(client_id=case.client_id, number=number, status="ACTIVE", description=scope_summary or case.lead_title)
            db.add(quote); db.flush()
        else:
            quote.description = scope_summary or quote.description
        refresh_case_request_summary(db, case)
        case.quotation_id = quote.id
        if case.request_source == "CLIENT_PORTAL":
            case.request_status = "QUOTATION_CREATED"
        ref = number
    elif target_stage == "CLIENT_FOLLOW_UP":
        if case.quotation and case.quotation.status == "CLIENT_REJECTED":
            raise ValueError("Client requested a quotation revision; issue the revised quotation before progressing")
        if not text:
            raise ValueError("Client decision / follow-up note is required")
        case.client_follow_up = text
    elif target_stage == "PURCHASE_ORDER_RECEIVED":
        number = (purchase_order_number or ref).strip()
        if not number and not case.purchase_order_id:
            raise ValueError("Client purchase order number is required")
        if not case.quotation_id:
            raise ValueError("Quotation must be completed before purchase order receipt")
        po = db.get(PurchaseOrder, case.purchase_order_id) if case.purchase_order_id else None
        if not po:
            po = db.scalar(select(PurchaseOrder).where(PurchaseOrder.client_id == case.client_id, PurchaseOrder.number == number))
        if not po:
            po = PurchaseOrder(client_id=case.client_id, quotation_id=case.quotation_id, number=number, status="ACTIVE")
            db.add(po); db.flush()
        else:
            if po.quotation_id and po.quotation_id != case.quotation_id:
                raise ValueError("Purchase order is linked to a different quotation")
            po.quotation_id = case.quotation_id
            po.status = "ACTIVE"
        case.purchase_order_id = po.id
        case.po_received_reference = ref or po.number
        ref = po.number
        if case.request_source == "CLIENT_PORTAL":
            case.request_status = "PO_RECEIVED"
    elif target_stage == "COMPLETE_HANDOVER":
        c = handover_commercial.strip(); t = handover_technical.strip(); ci = handover_client_info.strip()
        if not (c and t and ci):
            raise ValueError("Complete Handover requires Commercial, Technical and Client Information")
        scope_lines = request_scope_lines(db, case)
        if scope_lines:
            refresh_case_request_summary(db, case)
        else:
            # Backward-compatible path for cases created before structured Client Request Scope.
            exp_text = (expected_samples or "").strip()
            if exp_text:
                if not exp_text.isdigit() or int(exp_text) < 1 or int(exp_text) > 10000:
                    raise ValueError("Expected sample quantity must be between 1 and 10000")
                case.expected_samples = int(exp_text)
            else:
                case.expected_samples = None
            package = (requested_test_package or "").strip()[:160]
            priority = (default_priority or "NORMAL").strip().upper()
            tat = (required_tat or "").strip().upper()
            if priority not in {"NORMAL", "HIGH", "URGENT"}:
                raise ValueError("Default priority must be NORMAL, HIGH or URGENT")
            if tat not in {"", "12H", "24H", "EXACT_DUE"}:
                raise ValueError("Required TAT must be Standard, 12H, 24H or Exact Due")
            case.requested_test_package = package
            case.default_priority = priority
            case.required_tat = tat
        case.handover_commercial, case.handover_technical, case.handover_client_info = c, t, ci
        if case.request_source == "CLIENT_PORTAL":
            case.request_status = "HANDOVER_COMPLETE"
    elif target_stage == "REPORT_SUBMISSION":
        if not ref:
            raise ValueError("Client submission reference is required")
        case.report_submission_reference = ref
    elif target_stage == "INVOICING":
        if not ref:
            raise ValueError("Invoice number is required")
        case.invoice_number = ref
    elif target_stage == "PAYMENT_COLLECTION":
        if not ref:
            raise ValueError("Payment reference is required")
        case.payment_reference = ref
    elif target_stage == "CLOSED":
        case.status = "CLOSED"
        case.closed_at = datetime.utcnow()

    add_commercial_event(db, case, actor, target_stage, note=text, reference=ref, from_stage=current)
    case.current_stage = canonical_stage(target_stage)
    case.updated_at = datetime.utcnow()


def resolve_handover_case(db: Session, *, site_id: int, client_id: int, quotation_id: int | None, purchase_order_id: int | None) -> CommercialCase | None:
    if not purchase_order_id:
        return None
    stmt = select(CommercialCase).where(
        CommercialCase.site_id == site_id,
        CommercialCase.client_id == client_id,
        CommercialCase.purchase_order_id == purchase_order_id,
        CommercialCase.status == "ACTIVE",
    ).order_by(CommercialCase.created_at.desc())
    case = db.scalar(stmt)
    if case and quotation_id and case.quotation_id and case.quotation_id != quotation_id:
        raise ValueError("Commercial handover quotation does not match the selected quotation")
    return case


def require_complete_handover(case: CommercialCase | None) -> None:
    if not case:
        return
    if stage_index(case.current_stage) < stage_index("COMPLETE_HANDOVER"):
        raise ValueError("Commercial case must complete Purchase Order receipt and Complete Handover before operations begin")


def link_sampling_order(db: Session, case: CommercialCase, order: SamplingOrder, actor: User | None = None) -> None:
    require_complete_handover(case)
    case.sampling_order_id = order.id
    order.commercial_case_id = case.id
    current = effective_stage(db, case)
    if stage_index(current) < stage_index("CLIENT_COORDINATION"):
        add_commercial_event(db, case, actor, "CLIENT_COORDINATION", note="Operations accepted commercial handover", from_stage=current)
        case.current_stage = "CLIENT_COORDINATION"
    if stage_index(case.current_stage) < stage_index("SAMPLING"):
        add_commercial_event(db, case, actor, "SAMPLING", note=f"Sampling order {order.order_number} linked", reference=order.order_number, from_stage=case.current_stage)
        case.current_stage = "SAMPLING"


def link_sample(db: Session, case: CommercialCase, sample: SampleRequest, actor: User | None = None) -> None:
    case.sample_request_id = sample.id
    sample.commercial_case_id = case.id
    if case.request_source == "CLIENT_PORTAL":
        case.request_status = "IN_PROGRESS"
    case.updated_at = datetime.utcnow()
    # Stage itself is derived from the actual SampleStatus; event adds audit context only.
    derived = _sample_stage(sample)
    if derived and stage_index(derived) > stage_index(case.current_stage):
        add_commercial_event(db, case, actor, derived, note=f"Sample {sample.request_number} linked to business case", reference=sample.request_number, from_stage=case.current_stage)
        case.current_stage = derived


def reconcile_client_portal_request_statuses(db: Session) -> int:
    """Repair stale client-portal display status from authoritative workflow state.

    This is intentionally conservative and only advances stale early-journey display
    states. It never rewinds or alters report-submission/final-release status.
    """
    changed = 0
    cases = list(db.scalars(select(CommercialCase).where(CommercialCase.request_source == "CLIENT_PORTAL")).all())
    for case in cases:
        current = canonical_stage(case.current_stage or "LEAD_GENERATION")
        linked_count = db.scalar(select(func.count()).select_from(SampleRequest).where(SampleRequest.commercial_case_id == case.id)) or 0
        target = None
        if linked_count and stage_index(current) >= stage_index("SAMPLING") and stage_index(current) < stage_index("FINAL_REPORT_RELEASE"):
            target = "IN_PROGRESS"
        elif stage_index(current) >= stage_index("COMPLETE_HANDOVER") and stage_index(current) < stage_index("SAMPLING"):
            target = "HANDOVER_COMPLETE"
        if target and case.request_status not in {target, "REPORT_RELEASED", "REPORT_SUBMITTED", "CLOSED"}:
            case.request_status = target
            changed += 1
    if changed:
        db.commit()
    return changed


def sync_case_from_sample(db: Session, sample: SampleRequest, actor: User | None = None, note: str = "") -> CommercialCase | None:
    if not sample.commercial_case_id:
        return None
    case = db.get(CommercialCase, sample.commercial_case_id)
    if not case:
        return None
    derived = _sample_stage(sample)
    if derived and stage_index(derived) > stage_index(case.current_stage) and stage_index(case.current_stage) < stage_index("REPORT_SUBMISSION"):
        add_commercial_event(db, case, actor, derived, note=note or f"Operational lifecycle reached {STAGE_LABELS[derived]}", reference=sample.request_number, from_stage=case.current_stage)
        case.current_stage = derived
        case.updated_at = datetime.utcnow()

    # Keep the client-facing service-request status synchronized with the same
    # authoritative SampleRequest state. The client must not see an old
    # IN_PROGRESS label after the laboratory has reached Senior review or
    # official report release. Internal QC/blocker detail remains restricted.
    if case.request_source == "CLIENT_PORTAL" and case.request_status not in {"REPORT_SUBMITTED", "CLOSED"}:
        client_status_by_sample = {
            SampleStatus.SUBMITTED.value: "IN_PROGRESS",
            SampleStatus.ACCEPTED.value: "IN_PROGRESS",
            SampleStatus.AWAITING_RECEIPT.value: "IN_PROGRESS",
            SampleStatus.IN_TRANSIT.value: "IN_PROGRESS",
            SampleStatus.RECEIVED.value: "IN_PROGRESS",
            SampleStatus.READY_FOR_LAB.value: "IN_PROGRESS",
            SampleStatus.REGISTERED.value: "IN_PROGRESS",
            SampleStatus.TESTING.value: "IN_PROGRESS",
            SampleStatus.TECHNICAL_REVIEW.value: "TECHNICAL_REVIEW",
            SampleStatus.REPORT_APPROVED.value: "PENDING_FINAL_APPROVAL",
            SampleStatus.READY_FOR_LMS.value: "PENDING_FINAL_APPROVAL",  # legacy data only
            SampleStatus.REPORT_RELEASED.value: "REPORT_RELEASED",
        }
        target_status = client_status_by_sample.get(sample.status)
        if target_status:
            case.request_status = target_status
            case.updated_at = datetime.utcnow()
    return case
