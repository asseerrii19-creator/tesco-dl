from __future__ import annotations

from collections import Counter
from datetime import datetime

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..models import Role, SampleRequest, SampleStatus, StaffAvailability, TechnicalReviewAssignment, User

ACTIVE = "ACTIVE"
CLOSED = {"COMPLETED", "SUPERSEDED", "CANCELLED"}
CANONICAL_SENIOR_EMAILS = {"senior.technical@tsco.local", "senior.equipment@tsco.local", "senior.improvement@tsco.local"}


def active_review_assignment(db: Session, sample_id: int) -> TechnicalReviewAssignment | None:
    return db.scalar(
        select(TechnicalReviewAssignment)
        .where(TechnicalReviewAssignment.sample_request_id == sample_id, TechnicalReviewAssignment.status == ACTIVE)
        .order_by(TechnicalReviewAssignment.revision.desc(), TechnicalReviewAssignment.assigned_at.desc())
    )


def _available_seniors(db: Session, sample: SampleRequest) -> list[User]:
    now = datetime.utcnow()
    seniors = list(db.scalars(
        select(User).where(
            User.active.is_(True),
            User.role == Role.SENIOR_CHEMIST.value,
            User.site_id == sample.site_id,
            User.email.in_(sorted(CANONICAL_SENIOR_EMAILS)),
        ).order_by(User.full_name)
    ).all())
    available = []
    for person in seniors:
        conflict = db.scalar(select(StaffAvailability.id).where(
            StaffAvailability.user_id == person.id,
            StaffAvailability.entry_type.in_(["LEAVE", "HOLIDAY", "TRAINING", "UNAVAILABLE"]),
            ~StaffAvailability.status.in_(["CANCELLED", "REJECTED"]),
            StaffAvailability.start_at <= now,
            StaffAvailability.end_at >= now,
        ))
        if not conflict:
            available.append(person)
    return available or seniors


def _workload(db: Session, site_id: int) -> Counter:
    rows = list(db.scalars(select(TechnicalReviewAssignment).where(
        TechnicalReviewAssignment.site_id == site_id,
        TechnicalReviewAssignment.status == ACTIVE,
    )).all())
    counts: Counter = Counter()
    for row in rows:
        counts[row.primary_senior_id] += 2
        if row.secondary_senior_id:
            counts[row.secondary_senior_id] += 1
    return counts


def ensure_review_assignment(db: Session, sample: SampleRequest, actor: User | None = None) -> TechnicalReviewAssignment | None:
    current = active_review_assignment(db, sample.id)
    if current:
        return current
    if sample.status != SampleStatus.TECHNICAL_REVIEW.value:
        return None
    seniors = _available_seniors(db, sample)
    if not seniors:
        return None
    loads = _workload(db, sample.site_id)
    domain_order = {"TECHNICAL": 0, "EQUIPMENT": 1, "IMPROVEMENT": 2, "": 3}
    ranked = sorted(
        seniors,
        key=lambda p: (loads.get(p.id, 0), domain_order.get((p.senior_responsibility_domain or "").upper(), 9), p.full_name.lower()),
    )
    primary = ranked[0]
    priority = (sample.priority or "").upper()
    secondary = ranked[1] if len(ranked) > 1 and priority in {"URGENT", "HIGH", "CRITICAL"} else None
    revision = 1 + int(db.scalar(select(TechnicalReviewAssignment.revision).where(
        TechnicalReviewAssignment.sample_request_id == sample.id
    ).order_by(TechnicalReviewAssignment.revision.desc()).limit(1)) or 0)
    row = TechnicalReviewAssignment(
        sample_request_id=sample.id, site_id=sample.site_id,
        primary_senior_id=primary.id, secondary_senior_id=secondary.id if secondary else None,
        assigned_by_id=actor.id if actor else None, assignment_mode="AUTO_WORKLOAD",
        reason="Automatic workload-balanced Senior review assignment; urgent/high samples receive a supporting secondary reviewer when available.",
        status=ACTIVE, revision=revision, assigned_at=datetime.utcnow(),
    )
    db.add(row); db.flush()
    return row


def ensure_site_review_assignments(db: Session, samples: list[SampleRequest], actor: User | None = None) -> dict[int, TechnicalReviewAssignment]:
    out: dict[int, TechnicalReviewAssignment] = {}
    for sample in samples:
        if sample.status == SampleStatus.TECHNICAL_REVIEW.value:
            row = ensure_review_assignment(db, sample, actor=actor)
            if row:
                out[sample.id] = row
        else:
            row = active_review_assignment(db, sample.id)
            if row:
                out[sample.id] = row
    return out


def assigned_to_user(row: TechnicalReviewAssignment | None, user: User) -> bool:
    return bool(row and user.role == Role.SENIOR_CHEMIST.value and user.id in {row.primary_senior_id, row.secondary_senior_id})


def primary_reviewer(row: TechnicalReviewAssignment | None, user: User) -> bool:
    return bool(row and user.role == Role.SENIOR_CHEMIST.value and row.primary_senior_id == user.id)


def close_review_assignment(db: Session, sample_id: int) -> None:
    row = active_review_assignment(db, sample_id)
    if row:
        row.status = "COMPLETED"
        row.completed_at = datetime.utcnow()


def reassign_review(db: Session, sample: SampleRequest, *, primary: User, secondary: User | None, actor: User, reason: str) -> TechnicalReviewAssignment:
    reason = (reason or "").strip()
    if not reason:
        raise ValueError("Reassignment reason is required")
    if (
        primary.role != Role.SENIOR_CHEMIST.value
        or primary.site_id != sample.site_id
        or not primary.active
        or (primary.email or '').lower() not in CANONICAL_SENIOR_EMAILS
    ):
        raise ValueError("Primary reviewer must be one of the canonical active Senior Chemists from the sample site")
    if secondary and (
        secondary.role != Role.SENIOR_CHEMIST.value
        or secondary.site_id != sample.site_id
        or not secondary.active
        or (secondary.email or '').lower() not in CANONICAL_SENIOR_EMAILS
    ):
        raise ValueError("Secondary reviewer must be one of the canonical active Senior Chemists from the sample site")
    if secondary and secondary.id == primary.id:
        raise ValueError("Primary and secondary reviewers must be different")
    current = active_review_assignment(db, sample.id)
    revision = 1
    if current:
        current.status = "SUPERSEDED"; current.completed_at = datetime.utcnow(); revision = current.revision + 1
    row = TechnicalReviewAssignment(
        sample_request_id=sample.id, site_id=sample.site_id,
        primary_senior_id=primary.id, secondary_senior_id=secondary.id if secondary else None,
        assigned_by_id=actor.id, assignment_mode="MANUAL_MANAGER_REASSIGNMENT", reason=reason,
        status=ACTIVE, revision=revision, assigned_at=datetime.utcnow(),
    )
    db.add(row); db.flush()
    return row
