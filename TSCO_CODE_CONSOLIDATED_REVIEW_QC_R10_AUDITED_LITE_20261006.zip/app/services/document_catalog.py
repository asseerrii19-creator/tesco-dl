"""Install supplied source bytes without declaring them approved or replacing revisions."""
import hashlib
import json
import re
import shutil
from pathlib import Path
from sqlalchemy import select
from ..models import ControlledDocument
from ..storage import CONTROLLED_DOCUMENT_DIR

SOURCE_DIR = Path(__file__).resolve().parents[1] / 'reference_documents'


def install_reference_documents(db):
    rows = json.loads((SOURCE_DIR / 'catalog.json').read_text())
    added = 0
    for row in rows:
        source = SOURCE_DIR / row['stored_filename']
        if hashlib.sha256(source.read_bytes()).hexdigest() != row['sha256']:
            raise ValueError('Reference document integrity mismatch: ' + row['code'])
        existing = db.scalar(select(ControlledDocument).where(ControlledDocument.stored_filename == row['stored_filename']))
        if existing:
            # The database register can outlive the persistent file (for example after
            # an earlier deployment/storage incident). Restore the exact bundled bytes
            # without changing status, revision, approvals, or any controlled metadata.
            destination = CONTROLLED_DOCUMENT_DIR / row['stored_filename']
            if not destination.exists():
                shutil.copyfile(source, destination)
            # A withdrawn/superseded record must never be reactivated at startup.
            continue
        if db.scalar(select(ControlledDocument.id).where(ControlledDocument.code == row['code'], ControlledDocument.site_id.is_(None))):
            continue  # Existing controlled revisions take precedence over bundled references.
        destination = CONTROLLED_DOCUMENT_DIR / row['stored_filename']
        shutil.copyfile(source, destination)
        fields = {k: row[k] for k in ('code','document_type','title','revision','status','workstation','test_name','method_name','original_filename','stored_filename','notes')}
        fields['notes'] += '\nSource SHA-256: ' + row['sha256']
        db.add(ControlledDocument(**fields))
        added += 1
    db.commit()
    return added


def method_key(value):
    return re.sub(r'[^A-Z0-9]', '', value.upper())


def document_matches(doc, workstation='', test='', method=''):
    if workstation and doc.workstation and workstation not in doc.workstation.split('|'):
        return False
    if test and doc.test_name and test != doc.test_name:
        return False
    if method and doc.method_name and method_key(method) != method_key(doc.method_name):
        return False
    return True
