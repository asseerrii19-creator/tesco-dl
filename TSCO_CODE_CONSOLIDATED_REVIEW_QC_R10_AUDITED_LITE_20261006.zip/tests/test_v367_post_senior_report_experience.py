from pathlib import Path


def test_post_senior_report_experience_contracts():
    base = Path('app/templates/base.html').read_text(encoding='utf-8')
    worksheets = Path('app/templates/internal_worksheets.html').read_text(encoding='utf-8')
    reports = Path('app/templates/controlled_reports.html').read_text(encoding='utf-8')
    review = Path('app/templates/senior_final_report_review.html').read_text(encoding='utf-8')
    client = Path('app/templates/client_dashboard.html').read_text(encoding='utf-8')
    records = Path('app/templates/operations_records.html').read_text(encoding='utf-8')
    lab_route = Path('app/routes/lab_operations.py').read_text(encoding='utf-8')
    assessment = Path('app/services/technical_assessment.py').read_text(encoding='utf-8')
    control_route = Path('app/routes/control_center.py').read_text(encoding='utf-8')

    assert 'Internal Result Worksheets' in base
    assert 'QDF [7]-07-E' in worksheets and 'Internal · Not for client release' in worksheets
    assert 'QDF-[7]-08-A' in reports and 'Two reports' not in reports  # visual split, not duplicate report content
    assert 'Supporting detail stays collapsed' in review
    assert 'Grouped Result Review' in review and '<details' in review
    assert 'Sample Status & Reports' in client and 'CLIENT OUTCOME' in client
    assert 'One compact record per sample' in records and 'Analytical QC Run History' in records
    assert '/lab/result-worksheets' in lab_route
    assert '"rsd" not in str(row.get("test") or "").lower()' in assessment
    assert "report_number_clean=f\"{sample.request_number.replace('FS-','FSR-',1)}-R" in control_route
    assert 'auto_dga' in control_route and 'auto_corrosive' in control_route and 'auto_paper' in control_route
