from pathlib import Path
import math
import base64
import pytest

from app.services.lab_operations import _server_qc_status, _validate_bdv_series_result
from app.services.final_report_data import _report_display_result
from app.routes.control_center import _report_result_review_cards, _report_result_review_groups

ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / 'app/lab_ops/index_template.html').read_text(encoding='utf-8')
SENIOR = (ROOT / 'app/templates/senior_final_report_review.html').read_text(encoding='utf-8')


def test_blind_qc_uses_server_profile_and_returns_binary_fail_outside_2sigma():
    payload = {
        'settings': {'qcProfileSelections': {'Water': 'W1'}},
        'qualifiedQcProfiles': [{
            'id': 'W1', 'test': 'Water', 'active': True,
            'mean': 100.0, 'sd': 2.0, 'lcl2': 96.0, 'ucl2': 104.0, 'lcl3': 94.0, 'ucl3': 106.0,
        }],
    }
    row = {'test': 'Water', 'result': '105', 'target': 999999, 'profile_id': 'FAKE', 'blind_entry': True}
    status, detail, profile = _server_qc_status(payload, row)
    assert status == 'FAIL'
    assert profile['id'] == 'W1'
    assert row['profile_id'] == 'W1'
    assert 'failed' in detail.lower()


def test_blind_qc_without_approved_profile_is_blocked_not_manual_targeted():
    with pytest.raises(PermissionError, match='Approved QC profile/lot is required'):
        _server_qc_status({'qualifiedQcProfiles': [], 'settings': {}}, {
            'test': 'BDV', 'result': '80', 'target': '80', 'blind_entry': True,
        })


def test_blind_dga_qc_requires_original_source_file():
    keys = ['H2','O2','N2','CH4','CO','CO2','C2H4','C2H6','C2H2']
    row = {'test': 'DGA', 'blind_entry': True, 'qc_components': [
        {'key': k, 'name': k, 'target': 25, 'result': 25} for k in keys
    ]}
    with pytest.raises(PermissionError, match='original QC/CRM source file'):
        _server_qc_status({}, row)




def _dga_source_data(result_override=None):
    keys = ['H2','O2','N2','CH4','CO','CO2','C2H4','C2H6','C2H2']
    lines = ['Gas,Certified Target,Actual QC Result']
    for key in keys:
        result = 25 if key != result_override else 26
        lines.append(f'{key},25,{result}')
    raw = '\n'.join(lines).encode()
    return 'data:text/csv;base64,' + base64.b64encode(raw).decode()


def test_blind_dga_qc_source_file_is_server_verified_against_submitted_components():
    keys = ['H2','O2','N2','CH4','CO','CO2','C2H4','C2H6','C2H2']
    row = {
        'test':'DGA','blind_entry':True,'source_file':'crm.csv','source_data':_dga_source_data(),
        'qc_components':[{'key':k,'name':k,'target':25,'result':25} for k in keys],
    }
    status, _, _ = _server_qc_status({}, row)
    assert status == 'PASS'
    tampered = {
        'test':'DGA','blind_entry':True,'source_file':'crm.csv','source_data':_dga_source_data(),
        'qc_components':[{'key':k,'name':k,'target':25,'result':(24 if k=='H2' else 25)} for k in keys],
    }
    with pytest.raises(PermissionError, match='do not match the original imported'):
        _server_qc_status({}, tampered)


def _accepted_stats(values):
    mean = sum(values) / len(values)
    sd = math.sqrt(sum((x - mean) ** 2 for x in values) / (len(values) - 1))
    rsd = sd / mean * 100.0
    return round(mean, 2), int(math.floor(rsd + 0.5))


def test_iec60156_one_controlled_exclusion_retains_six_runs_and_recalculates_integer_rsd():
    raw = [70, 71, 72, 73, 74, 120]
    accepted = raw[:5]
    avg, rsd = _accepted_stats(accepted)
    calc = {
        'method': 'IEC 60156',
        'inputs': {f'R{i+1}': v for i, v in enumerate(raw)},
        'excluded_runs': [{'run': 'R6', 'index': 6, 'value': 120, 'reason': 'Instrument anomaly'}],
        'accepted_run_count': 5,
        'rsd_display_integer': True,
    }
    _validate_bdv_series_result({
        'test': 'Breakdown Voltage @2.5mm- AVG', 'result': str(avg),
        'calculation': calc, 'source': 'BDV instrument CSV',
    })
    _validate_bdv_series_result({
        'test': 'RSD% of BDV @2.5mm', 'result': str(rsd), 'calculated': True,
        'calculation': calc, 'source': 'Derived from BDV run set',
    })
    assert len(calc['inputs']) == 6
    assert calc['accepted_run_count'] == 5


def test_bdv_exclusion_requires_reason():
    raw = [70, 71, 72, 73, 74, 120]
    calc = {
        'method': 'IEC 60156',
        'inputs': {f'R{i+1}': v for i, v in enumerate(raw)},
        'excluded_runs': [{'run': 'R6', 'index': 6, 'value': 120, 'reason': ''}],
        'accepted_run_count': 5,
        'rsd_display_integer': True,
    }
    with pytest.raises(PermissionError, match='documented reason'):
        _validate_bdv_series_result({
            'test': 'Breakdown Voltage @2.5mm- AVG', 'result': '72',
            'calculation': calc, 'source': 'BDV instrument CSV',
        })


def test_report_display_rounds_rsd_and_paper_life_without_mutating_source_precision():
    assert _report_display_result('RSD% of BDV @2.5mm', '0.66') == '1'
    assert _report_display_result('RSD% of BDV @2.5mm', '1.4') == '1'
    assert _report_display_result('RSD% of BDV @2.5mm', '1.5') == '2'
    assert _report_display_result('Paper Lifetime Remaining Years', '27.3') == '27'
    assert _report_display_result('Paper Lifetime Remaining Years', '27.6') == '28'


def test_senior_review_groups_water_and_bdv_pf_and_keeps_rsd_informational():
    sid = 3
    payload = {
        'dga': {'rows': []}, 'furan': {'rows': []},
        'oil': {'rows': [
            {'test':'Water Content KF @RT','values':{'3':'24'},'unit':'mg/kg','method':'IEC 60814','normal':'<30','caution':'>40'},
            {'test':'Breakdown Voltage @2.5mm AVG','values':{'3':'68.05'},'unit':'kV','method':'IEC 60156','normal':'>40','caution':'<30'},
            {'test':'RSD% of BDV @2.5mm','values':{'3':'1'},'unit':'%','method':'Calculated','normal':'—','caution':'—'},
            {'test':'Power Factor @100°C/60Hz','values':{'3':'0.0085'},'unit':'%','method':'ASTM D924','normal':'—','caution':'>5.0'},
        ]},
        'corrosion': {'rows': []},
    }
    cards = _report_result_review_cards(payload, sid)
    groups = _report_result_review_groups(cards)
    keys = [g['key'] for g in groups]
    assert 'water' in keys and 'electrical' in keys
    rsd = next(c for c in cards if 'RSD%' in c['test'])
    assert rsd['status'] == 'INFO'
    assert rsd['trend']['tone'] == 'neutral'


def test_routine_qc_ui_is_blind_and_compact_and_senior_detail_is_collapsible():
    assert 'Server-controlled · target and limits hidden until submit' in HTML
    assert 'Routine analysts enter the observed result only' in HTML
    assert 'QC PROFILE REQUIRED' in HTML
    assert 'qc-context-compact' in HTML
    assert 'row[\"blind_entry\"] = True' in (ROOT / 'app/services/lab_operations.py').read_text(encoding='utf-8')
    assert 'dga-qc-target' not in HTML
    assert 'Grouped Result Review' in SENIOR
    assert 'result-group-list' in SENIOR
    assert 'Full client Analysis Report preview' in SENIOR
    assert '<details class="compact-details"' in SENIOR
