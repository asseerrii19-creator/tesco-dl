from __future__ import annotations

from datetime import datetime
from pathlib import Path
from uuid import uuid4

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import Asset, Client, SampleRequest, Site, User
from app.services.technical_review_assignments import (
    CANONICAL_SENIOR_EMAILS,
    ensure_review_assignment,
    reassign_review,
)


def login(client: TestClient, email: str) -> None:
    response = client.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert response.status_code == 303, (email, response.status_code, response.text[:300])


def test_review_assignment_uses_only_canonical_three_seniors_and_rejects_legacy_aliases():
    token = uuid4().hex[:8].upper()
    with TestClient(app):
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            client = db.scalar(select(Client).where(Client.code == 'SEC')); assert client
            asset = db.scalar(select(Asset).where(Asset.client_id == client.id)); assert asset
            sample = SampleRequest(
                request_number=f'V366-{token}', public_token=f'PUB-V366-{token}', barcode_value=f'BAR-V366-{token}',
                status='TECHNICAL_REVIEW', site_id=site.id, client_id=client.id, asset_id=asset.id,
                sample_date_time=datetime.utcnow(), sampling_point='Main Tank',
                sample_origin='Client-Originated / Direct Delivery', priority='URGENT',
            )
            db.add(sample); db.flush()
            assignment = ensure_review_assignment(db, sample)
            assert assignment is not None
            primary = db.get(User, assignment.primary_senior_id); assert primary
            assert primary.email.lower() in CANONICAL_SENIOR_EMAILS
            if assignment.secondary_senior_id:
                secondary = db.get(User, assignment.secondary_senior_id); assert secondary
                assert secondary.email.lower() in CANONICAL_SENIOR_EMAILS
                assert secondary.id != primary.id

            legacy = db.scalar(select(User).where(User.email == 'senior@tsco.local'))
            manager = db.scalar(select(User).where(User.email == 'lab.manager@tsco.local'))
            assert legacy and manager
            with pytest.raises(ValueError, match='canonical active Senior Chemists'):
                reassign_review(db, sample, primary=legacy, secondary=None, actor=manager, reason='UAT legacy alias rejection')
            db.rollback()


def test_testing_sample_is_not_actionable_in_senior_technical_assessment():
    token = uuid4().hex[:8].upper()
    with TestClient(app) as client_http:
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            client = db.scalar(select(Client).where(Client.code == 'SEC')); assert client
            asset = db.scalar(select(Asset).where(Asset.client_id == client.id)); assert asset
            sample = SampleRequest(
                request_number=f'V366-TESTING-{token}', public_token=f'PUB-V366-T-{token}', barcode_value=f'BAR-V366-T-{token}',
                status='TESTING', site_id=site.id, client_id=client.id, asset_id=asset.id,
                sample_date_time=datetime.utcnow(), sampling_point='Main Tank',
                sample_origin='Client-Originated / Direct Delivery',
            )
            db.add(sample); db.commit(); request_number = sample.request_number
        login(client_http, 'senior.technical@tsco.local')
        page = client_http.get('/assessment')
        assert page.status_code == 200
        assert request_number not in page.text


def test_phase1_role_and_workflow_surface_contracts_are_present():
    assessment = Path('app/routes/assessment.py').read_text(encoding='utf-8')
    ops_records = Path('app/templates/operations_records.html').read_text(encoding='utf-8')
    operations = Path('app/templates/operations_overview.html').read_text(encoding='utf-8')
    client = Path('app/templates/client_dashboard.html').read_text(encoding='utf-8')
    commercial = Path('app/templates/commercial_flow.html').read_text(encoding='utf-8')
    quality = Path('app/templates/quality_center.html').read_text(encoding='utf-8')
    management = Path('app/templates/management.html').read_text(encoding='utf-8')
    report_review = Path('app/templates/senior_final_report_review.html').read_text(encoding='utf-8')
    sampling_route = Path('app/routes/sampling_supervision.py').read_text(encoding='utf-8')
    lab_service = Path('app/services/lab_operations.py').read_text(encoding='utf-8')

    # Senior queue/assessment authority.
    assert 'assigned_to_user' in assessment and 'primary_reviewer' in assessment
    assert 'sample.status != SampleStatus.TECHNICAL_REVIEW.value' in assessment
    assert 'SERVER-AUTHORITATIVE LABORATORY RECORDS' in ops_records
    assert 'No browser-only counters' in ops_records

    # Client logistics -> Operations route decision.
    for label in ('Client delivery to TSCO', 'TSCO pickup of ready samples', 'TSCO performs on-site sampling', 'To be confirmed'):
        assert label in client or label in commercial
    assert 'ROUTE DECISION REQUIRED' in operations
    assert 'Completed lab handoffs' in operations
    assert 'Field Team Availability / Operational Roster' in operations

    # Field-manager override remains audited/controlled rather than routine ownership.
    assert '_require_manager_override_reason' in sampling_route
    assert 'Manager override reason is required' in sampling_route

    # Exact analytical equipment ownership is monthly; run history is distinct from routine responsibility history.
    assert 'MONTHLY_ANALYTICAL_PRIMARY_BACKUP_V4' in lab_service
    assert 'AUTO_MONTHLY_ANALYTICAL_PRIMARY_BACKUP' in lab_service
    assert 'MONTHLY ANALYTICAL EQUIPMENT OWNERSHIP' in quality
    assert 'Analytical QC Run History' in quality
    assert 'Routine QC Responsibility Completion History' in quality

    # Lab Operational & Technical Manager has controlled report authority after Senior review.
    assert 'Assigned Senior(s)' in management
    assert 'Operational handoffs' in management
    assert 'Technical approvals' in management
    assert 'Final releases' in management
    assert 'Lab Operational & Technical Manager' in management
    assert 'Lab Operational & Technical Manager · Internal Final Review Package' in report_review
    assert 'APPROVE INTERNAL REVIEW → FINAL TSCO REPORT' in report_review
    assert 'RETURN TO SENIOR FOR CORRECTION' in report_review
    assert 'APPROVE & RELEASE OFFICIAL TSCO REPORT' in report_review

    # No ambiguous shorthand survives in active user-facing templates.
    template_text = ''.join(
        p.read_text(encoding='utf-8')
        for p in Path('app/templates').rglob('*.html')
    )
    assert 'Lab Manager' not in template_text
