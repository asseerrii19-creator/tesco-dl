from types import SimpleNamespace

from app.services.lab_operations import _ensure_server_derived_oqi, platform_sample_lab_projection_from_payload


def _payload(tan='0.03', ift='36.0'):
    sample='FS-DMM-26-000003'
    batch={
        'id':'LB-1','samples':[sample], 'platform_sample_id':'3',
        'tests':[
            {'test':'Total Acid Number','method':'ASTM D664','station':'TAN / Peroxide / RSH / H2S'},
            {'test':'Interfacial Tension (IFT)','method':'ASTM D971','station':'Physical / Chemistry'},
            {'test':'Oil Quality Index','method':'calculation','station':'Physical / Chemistry'},
        ],
    }
    return {
        'batches':[batch],
        'results':[
            {'id':'R-TAN','batch':'LB-1','sample':sample,'test':'Total Acid Number','display_test':'Total Acid Number','result':tan,'ts':'2026-10-05T10:00:00'},
            {'id':'R-IFT','batch':'LB-1','sample':sample,'test':'Interfacial Tension (IFT)','display_test':'Interfacial Tension (IFT)','result':ift,'ts':'2026-10-05T11:00:00'},
        ],
        'testAssignments':[
            {'id':'A-TAN','batch_id':'LB-1','workstation':'TAN / Peroxide / RSH / H2S'},
            {'id':'A-PHYS','batch_id':'LB-1','workstation':'Physical / Chemistry'},
        ],
        'assignmentCompletions':[
            {'id':'C-TAN','batch_id':'LB-1','workstation':'TAN / Peroxide / RSH / H2S','assignment_id':'A-TAN','completed_at':'2026-10-05T12:00:00'},
            {'id':'C-PHYS','batch_id':'LB-1','workstation':'Physical / Chemistry','assignment_id':'A-PHYS','completed_at':'2026-10-05T12:00:00'},
        ],
        'qc':[], 'retests':[],
    }


def test_server_backfills_oqi_from_existing_ift_and_tan_without_browser_mutation():
    payload=_payload()
    _ensure_server_derived_oqi(payload)
    rows=[r for r in payload['results'] if r.get('test')=='Oil Quality Index']
    assert len(rows)==1
    assert rows[0]['result']=='1200'
    assert rows[0]['calculated'] is True
    assert rows[0]['server_derived'] is True
    assert rows[0]['source']=='Server calculation: IFT ÷ TAN'

    # Re-reading the same state must be deterministic/idempotent, not append another child row.
    _ensure_server_derived_oqi(payload)
    assert len([r for r in payload['results'] if r.get('test')=='Oil Quality Index'])==1


def test_server_backfill_removes_oqi_blocker_from_canonical_projection():
    payload=_payload()
    sample=SimpleNamespace(id=3, request_number='FS-DMM-26-000003', lms_number=None, status='TESTING')
    before=platform_sample_lab_projection_from_payload(payload,sample)
    assert before['tests_complete']==2
    assert before['missing_tests']==['Oil Quality Index']

    _ensure_server_derived_oqi(payload)
    after=platform_sample_lab_projection_from_payload(payload,sample)
    assert after['tests_complete']==3
    assert after['missing_tests']==[]
    assert after['workstations_closed']==2
    assert after['ready_for_technical_review'] is True


def test_server_backfill_preserves_tan_less_than_detection_reporting_rule():
    payload=_payload(tan='LTD', ift='35.0')
    _ensure_server_derived_oqi(payload)
    row=next(r for r in payload['results'] if r.get('test')=='Oil Quality Index')
    assert row['result']=='>3500'
