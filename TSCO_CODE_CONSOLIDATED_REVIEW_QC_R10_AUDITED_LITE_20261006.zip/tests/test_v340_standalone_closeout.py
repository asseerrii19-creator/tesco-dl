from __future__ import annotations

from datetime import datetime
from pathlib import Path
from uuid import uuid4

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
import app.routes.control_center as cc
from app.database import SessionLocal
from app.models import (
    Asset, Client, CommercialAttachment, CommercialCase, ControlledReport,
    PurchaseOrder, Quotation, SampleRequest, Site, User, WorkflowDefinition, WorkflowStep, IntegrationQueueItem,
    TechnicalAssessmentRecord,
)
from app.services.commercial import COMMERCIAL_STAGES, next_stage
from app.services.technical_review_assignments import ensure_review_assignment


def login(client: TestClient, email: str) -> None:
    r = client.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303, (email, r.status_code, r.text[:300])


def logout(client: TestClient) -> None:
    client.post('/logout', follow_redirects=False)


def test_v340_is_standalone_and_commercial_flow_has_no_duplicate_report_or_po_stages():
    stage_keys = [key for key, _, _ in COMMERCIAL_STAGES]
    assert 'PROPOSAL' not in stage_keys
    assert 'PURCHASE_ORDER' not in stage_keys
    assert stage_keys.count('PURCHASE_ORDER_RECEIVED') == 1
    assert 'REPORT_APPROVAL' not in stage_keys
    assert 'REPORT_RELEASE' not in stage_keys
    assert stage_keys.count('FINAL_REPORT_RELEASE') == 1
    assert next_stage('REPORT_SUBMISSION') is None
    active_paths = {getattr(route, 'path', '') for route in app.routes}
    assert not any('lms-confirm' in path.lower() for path in active_paths)


def test_client_request_auto_assigns_coordinator_and_client_can_accept_quote_and_upload_po():
    token = uuid4().hex[:8].upper()
    with TestClient(app) as browser:
        login(browser, 'client@sec.local')
        r = browser.post('/client/requests', data={
            'lead_title': f'V340 standalone request {token}', 'client_message': '',
            'sample_delivery_mode': 'CLIENT_DELIVERY', 'sample_delivery_notes': 'Deliver to TSCO',
        }, follow_redirects=False)
        assert r.status_code == 303
        case_id = int(r.headers['location'].rstrip('/').split('/')[-1])
        assert browser.post(f'/client/requests/{case_id}/lines', data={
            'quantity': 2, 'requested_package': 'Routine Test', 'method_family': 'IEC',
            'priority': 'HIGH', 'required_tat': '24H', 'due_at': '',
        }, follow_redirects=False).status_code == 303
        assert browser.post(f'/client/requests/{case_id}/submit', data={'client_message': ''}, follow_redirects=False).status_code == 303
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case
            assert case.assigned_coordinator_id is not None
            coordinator = db.get(User, case.assigned_coordinator_id); assert coordinator
            coordinator_email = coordinator.email

        logout(browser); login(browser, coordinator_email)
        browser.get(f'/commercial?case_id={case_id}')
        quote_no = f'QT-V340-{token}'
        r = browser.post(f'/commercial/cases/{case_id}/advance', data={
            'target_stage': 'QUOTATION', 'quotation_number': quote_no, 'note': '', 'reference': '',
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case and case.quotation
            assert case.current_stage == 'QUOTATION'
            assert case.quotation.status == 'ACTIVE'

        logout(browser); login(browser, 'client@sec.local')
        page = browser.get(f'/client/requests/{case_id}')
        assert page.status_code == 200
        assert quote_no in page.text
        assert 'Accept Quotation' in page.text and 'Request Revision' in page.text
        r = browser.post(f'/client/requests/{case_id}/quotation-decision', data={'decision': 'ACCEPT', 'note': 'Approved'}, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case
            assert case.request_status == 'QUOTATION_ACCEPTED'
            assert case.current_stage == 'CLIENT_FOLLOW_UP'
            assert case.quotation.status == 'CLIENT_ACCEPTED'

        po_no = f'PO-V340-{token}'
        r = browser.post(
            f'/client/requests/{case_id}/purchase-order',
            data={'purchase_order_number': po_no},
            files={'upload': ('po.pdf', b'%PDF-1.4\n% TSCO UAT purchase order\n', 'application/pdf')},
            follow_redirects=False,
        )
        assert r.status_code == 303, r.text[:300]
        with SessionLocal() as db:
            case = db.get(CommercialCase, case_id); assert case and case.purchase_order
            assert case.purchase_order.number == po_no and case.purchase_order.status == 'ACTIVE'
            assert case.current_stage == 'PURCHASE_ORDER_RECEIVED'
            assert case.request_status == 'PO_RECEIVED'
            doc = db.scalar(select(CommercialAttachment).where(
                CommercialAttachment.commercial_case_id == case_id,
                CommercialAttachment.document_type == 'PURCHASE_ORDER',
            ))
            assert doc and Path(doc.stored_path).is_file()


def test_final_controlled_report_manager_approval_is_the_official_tsco_release(monkeypatch):
    token = uuid4().hex[:8].upper()
    with TestClient(app) as browser:
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM')); assert site
            client = db.scalar(select(Client).where(Client.code == 'SEC')); assert client
            asset = db.scalar(select(Asset).where(Asset.client_id == client.id)); assert asset
            sample = SampleRequest(
                request_number=f'V340-{token}', public_token=f'PUB-V340-{token}', barcode_value=f'BAR-V340-{token}',
                status='TECHNICAL_REVIEW', site_id=site.id, client_id=client.id, asset_id=asset.id,
                sample_date_time=datetime.utcnow(), sampling_point='Main Tank', sample_origin='Client-Originated / Direct Delivery',
            )
            db.add(sample); db.flush()
            assignment = ensure_review_assignment(db, sample)
            assert assignment is not None
            senior = db.get(User, assignment.primary_senior_id); assert senior
            db.add(TechnicalAssessmentRecord(
                sample_request_id=sample.id, decision='APPROVED', recommendation='Routine monitoring', reviewed_by_id=senior.id,
            ))
            db.commit(); sample_id = sample.id; senior_email = senior.email

        login(browser, senior_email)
        report_no = f'TSCO-V340-{token}'
        r = browser.post('/control/report', data={
            'sample_request_id': sample_id, 'report_number': report_no,
            'condition_status': 'NORMAL', 'interpretation': 'Controlled technical review',
            'recommendation': 'Routine monitoring', 'dga_requested': '', 'corrosive_requested': '', 'paper_requested': '',
            'supersedes_report_id': '', 'amendment_reason': '',
        }, follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            report = db.scalar(select(ControlledReport).where(ControlledReport.report_number == report_no)); assert report
            report_id = report.id
            assert report.status == 'TECHNICAL_REVIEW' and report.reviewed_by_id is None
            sample = db.get(SampleRequest, sample_id); assert sample.status == 'TECHNICAL_REVIEW'
        monkeypatch.setattr(cc, '_report_review_requirements', lambda db,row,payload,cards: [{'ok':True,'detail':'ok'}])
        monkeypatch.setattr(cc, '_report_result_review_cards', lambda payload,sample_id: [{'test':'Water Content','result':'12','unit':'ppm','method':'IEC','normal':'<30','caution':'>40','group':'Oil Quality'}])
        reviewed=browser.post(f'/control/report/{report_id}/review',data={'action':'COMPLETE','condition_status':'NORMAL','interpretation':'Controlled technical review','recommendation':'Routine monitoring','confirm_results':'1','confirm_identity':'1','confirm_interpretation':'1','confirm_evidence':'1','confirm_recommendation':'1'},follow_redirects=False)
        assert reviewed.status_code==303
        with SessionLocal() as db:
            report=db.get(ControlledReport,report_id); sample=db.get(SampleRequest,sample_id)
            assert report.status=='PENDING_MANAGER_APPROVAL' and sample.status=='REPORT_APPROVED'

        logout(browser); login(browser, 'technical@tsco.local')
        blocked = browser.post(f'/control/report/{report_id}/approve', follow_redirects=False)
        assert blocked.status_code == 400
        internal = browser.post(
            f'/control/report/{report_id}/manager-review',
            data={'action': 'APPROVE_INTERNAL', 'comment': 'Internal package reviewed and accepted.'},
            follow_redirects=False,
        )
        assert internal.status_code == 303
        r = browser.post(f'/control/report/{report_id}/approve', follow_redirects=False)
        assert r.status_code == 303
        with SessionLocal() as db:
            report = db.get(ControlledReport, report_id); sample = db.get(SampleRequest, sample_id)
            assert report.status == 'REPORT_RELEASED'
            assert sample.status == 'REPORT_RELEASED'
            assert report.lms_status == 'NOT_APPLICABLE'
            assert not report.lms_reference
            assert 'TSCO_DIGITAL_LABORATORY_PLATFORM' in report.approved_snapshot_json
            assert report.report_template_code == 'QDF-[7]-08-A'
            assert report.official_pdf_sha256 and len(report.official_pdf_sha256) == 64
            assert report.official_pdf_path and Path(report.official_pdf_path).is_file()
        pdf = browser.get(f'/control/report/{report_id}/pdf')
        assert pdf.status_code == 200 and pdf.content.startswith(b'%PDF-')
        assert pdf.headers.get('x-tsco-report-sha256')
        preview = browser.get(f'/control/report/{report_id}/preview')
        assert preview.status_code == 200
        assert 'QDF-[7]-08-A' in preview.text and 'Final Analysis Report' in preview.text


def test_result_worksheet_has_no_release_button_and_group_definitions_are_complete():
    source = Path('app/lab_ops/index_template.html').read_text(encoding='utf-8')
    assert 'APPROVE FOR LMS' not in source
    assert 'APPROVE ALL FOR LMS' not in source
    assert 'Final Analysis Reports' in source
    for group in (
        'Oil Quality / Electrical / Physical', 'Dissolved Gas Analysis',
        'Furan / Passivator / Paper Ageing', 'Paper / Corrosive Diagnostics',
        'DBDS / BHT / Toluene / PCB',
    ):
        assert group in source
    assert 'orderedGroups' in source


def test_seeded_business_workflow_has_one_canonical_po_and_one_final_report_stage():
    with TestClient(app):
        with SessionLocal() as db:
            flow = db.scalar(select(WorkflowDefinition).where(
                WorkflowDefinition.code == 'BUSINESS-COMMUNICATION-FLOW',
                WorkflowDefinition.site_id.is_(None),
                WorkflowDefinition.active.is_(True),
            ))
            assert flow is not None
            assert flow.version == 6
            steps = list(db.scalars(select(WorkflowStep).where(WorkflowStep.workflow_id == flow.id).order_by(WorkflowStep.step_order)).all())
            keys = [row.step_key for row in steps]
            assert keys == [
                'lead_generation', 'quotation', 'client_follow_up', 'purchase_order_received',
                'complete_handover', 'client_coordination', 'sampling', 'sample_delivery',
                'testing', 'review', 'final_report_release', 'report_submission',
                'invoicing', 'payment_collection',
            ]
            assert 'proposal' not in keys
            assert 'purchase_order' not in keys
            assert keys.count('purchase_order_received') == 1
            assert keys.count('final_report_release') == 1


def test_legacy_external_connector_is_not_exposed_in_active_admin_integration_ui():
    token = uuid4().hex[:8].upper()
    with TestClient(app) as browser:
        with SessionLocal() as db:
            row = IntegrationQueueItem(
                integration='LMS', direction='OUTBOUND', operation=f'LEGACY-{token}', status='FAILED',
                payload_json='{}', attempts=1, last_error='historical row',
            )
            db.add(row); db.commit(); legacy_id = row.id
        login(browser, 'admin@tsco.local')
        page = browser.get('/admin/integrations')
        assert page.status_code == 200
        assert f'LEGACY-{token}' not in page.text
        retry = browser.post(f'/admin/integrations/{legacy_id}/retry', follow_redirects=False)
        assert retry.status_code == 404


def test_active_user_facing_templates_use_technical_manager_terminology_and_no_lms_label():
    roots = [Path('app/templates'), Path('app/lab_ops/index_template.html')]
    text = ''
    for root in roots:
        if root.is_file():
            text += root.read_text(encoding='utf-8')
        else:
            for path in root.rglob('*'):
                if path.is_file() and path.suffix in {'.html', '.js', '.css'}:
                    text += path.read_text(encoding='utf-8')
    assert 'Lab Manager' not in text
    assert 'APPROVE FOR LMS' not in text
    assert 'APPROVE ALL FOR LMS' not in text
    assert 'Ready for LMS' not in text
