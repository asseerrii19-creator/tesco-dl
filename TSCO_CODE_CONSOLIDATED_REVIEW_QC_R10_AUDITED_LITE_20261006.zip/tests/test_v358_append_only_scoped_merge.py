"""Regression: a second equipment QC must append without rewriting the first server QC record."""
from copy import deepcopy
from types import SimpleNamespace

from app.services.lab_operations import merge_scoped_operations_update, scope_operations_payload, _validate_append_only


def _state():
    assignments = [
        {
            'id': 'A-DGA', 'batch_id': '*', 'scope': 'WORKSTATION', 'workstation': 'DGA',
            'mode': 'SINGLE', 'revision': 1, 'primary_user_id': 18, 'backup_user_id': None,
        }
    ]
    first_qc = {
        'id': 'QC-EQ64', 'test': 'DGA', 'mode': 'routine', 'batch_id': 'B1',
        'assignment_id': 'A-DGA', 'workstation': 'DGA', 'context_test': 'Dissolved Gas Analysis (DGA)',
        'method_name': 'IEC 60567', 'equipment_asset_id': 64, 'equipment_id': 'EQ-64',
        'equipment_name': 'DGA GC-TOGA', 'status': 'PASS', 'detail': 'server canonical',
        'analyst': 'Technician', 'recorded_by_user_id': 18, 'ts': '2026-10-05T11:00:00',
        'qc_day': '2026-10-05', 'schedule_reason': 'DAILY_START', 'schedule_label': 'DAILY QC REQUIRED',
        'results_since_previous_qc': 0,
    }
    return {
        'batches': [{'id': 'B1', 'samples': ['S1'], 'tests': [
            {'test': 'Dissolved Gas Analysis (DGA)', 'method': 'IEC 60567', 'station': 'DGA'}
        ]}],
        'results': [], 'qc': [first_qc], 'qualifiedQcProfiles': [], 'retests': [],
        'dgaAttachments': [], 'resultEvidence': [], 'testAssignments': assignments,
        'assignmentCompletions': [], 'qualityDistributions': [], 'qualityTaskEvents': [],
        'reports': [], 'retained': [], 'storageAssignments': [], 'batchHistory': [],
        'cancelledSamples': [], 'supervisorNotes': [], 'standards': [],
        'staff': [{'id': 18, 'name': 'Technician', 'role': 'lab_technician'}],
        'clients': [], 'samplePoints': [], 'customPackages': [], 'formulaDefinitions': [],
        'testUnits': {}, 'settings': {}, 'meta': {'revision': 7},
        'drafts': {}, 'calculationDrafts': {},
    }


def test_scoped_second_equipment_qc_preserves_first_server_record_and_appends_new_id():
    user = SimpleNamespace(id=18, role='lab_technician')
    current = _state()
    incoming = deepcopy(scope_operations_payload(current, user))

    # Simulate a browser/scoped stale representation of the already accepted first QC record.
    # Before R5 this same ID overlaid the canonical server row and append-only validation failed.
    incoming['qc'][0]['detail'] = 'older browser copy'
    incoming['qc'][0].pop('recorded_by_user_id', None)

    incoming['qc'].insert(0, {
        'id': 'QC-EQ23', 'test': 'DGA', 'mode': 'routine', 'batch_id': 'B1',
        'assignment_id': 'A-DGA', 'workstation': 'DGA', 'context_test': 'Dissolved Gas Analysis (DGA)',
        'method_name': 'IEC 60567', 'equipment_asset_id': 23, 'equipment_id': 'EQ-23',
        'equipment_name': 'DGA GC-TOGA', 'status': 'PASS', 'ts': 'client-time',
    })

    merged = merge_scoped_operations_update(current, incoming, user)

    server_first = next(row for row in merged['qc'] if row['id'] == 'QC-EQ64')
    new_second = next(row for row in merged['qc'] if row['id'] == 'QC-EQ23')
    assert server_first == current['qc'][0]
    assert new_second['equipment_id'] == 'EQ-23'
    assert len(merged['qc']) == 2

    # The canonical current history remains an exact subset, so normal append-only validation
    # now identifies only the newly appended second-equipment QC record.
    new_rows = _validate_append_only(current['qc'], merged['qc'], 'QC')
    assert [row['id'] for row in new_rows] == ['QC-EQ23']
