from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import Site, User
from app.services.lab_operations import get_operations_state, save_operations_state


def login(client: TestClient, email: str) -> None:
    r = client.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303


def test_operations_app_forces_server_first_bootstrap_and_hides_additives_by_default():
    with TestClient(app) as client:
        login(client, 'chemist@tsco.local')
        # /lab/operations is the platform shell. The integrated laboratory console that owns
        # cloudLoad/localStorage/IndexedDB runs inside this iframe endpoint.
        page = client.get('/lab/operations/app?embed=1&section=workstations')
        assert page.status_code == 200
        html = page.text
        assert 'const online=await cloudLoad(true);' in html
        assert "if((STORAGE.dirty||STORAGE.saving)&&!force)return false;" in html
        assert 'id="additiveHead" style="display:none"' in html
        assert "(DB.testAssignments||[]).forEach(a=>{if(assignmentAllowsUser(a)&&a.workstation)out.add(canonicalWs(a.workstation))})" in html


def test_scoped_payload_returns_server_authoritative_global_bench_assignments_for_user():
    with TestClient(app) as client:
        # Reproduce the authoritative server state that the live browser must consume. This test
        # deliberately does not rely on a browser/localStorage mirror or on release-time auto-
        # assignment side effects in a clean test database.
        with SessionLocal() as db:
            site = db.scalar(select(Site).where(Site.code == 'DMM'))
            chemist = db.scalar(select(User).where(User.email == 'chemist@tsco.local'))
            assert site and chemist
            state, payload = get_operations_state(db, site)
            payload['testAssignments'] = [
                {
                    'id': 'WSA-AUTH-ELECTRICAL', 'batch_id': '*', 'scope': 'WORKSTATION',
                    'workstation': 'Electrical', 'mode': 'SINGLE',
                    'primary_user_id': chemist.id, 'primary_name': chemist.full_name,
                    'backup_user_id': None, 'backup_name': '', 'revision': 1,
                    'assigned_by_user_id': None, 'assigned_by': 'TSCO Auto Assignment',
                    'assigned_at': '2026-10-04T00:00:00', 'access_scope': 'NAMED_USERS',
                    'source': 'AUTO_14_DAY_ROTATION', 'cycle_key': '20260927-20261010',
                    'cycle_start': '2026-09-27T00:00:00', 'cycle_end': '2026-10-10T23:59:59',
                },
                {
                    'id': 'WSA-AUTH-TAN', 'batch_id': '*', 'scope': 'WORKSTATION',
                    'workstation': 'TAN / Peroxide / RSH / H2S', 'mode': 'SINGLE',
                    'primary_user_id': chemist.id, 'primary_name': chemist.full_name,
                    'backup_user_id': None, 'backup_name': '', 'revision': 1,
                    'assigned_by_user_id': None, 'assigned_by': 'TSCO Auto Assignment',
                    'assigned_at': '2026-10-04T00:00:00', 'access_scope': 'NAMED_USERS',
                    'source': 'AUTO_14_DAY_ROTATION', 'cycle_key': '20260927-20261010',
                    'cycle_start': '2026-09-27T00:00:00', 'cycle_end': '2026-10-10T23:59:59',
                },
            ]
            save_operations_state(db, state, payload, actor=None)
            db.commit()
            chemist_id = chemist.id

        login(client, 'chemist@tsco.local')
        response = client.get('/api/lab-operations/data')
        assert response.status_code == 200
        data = response.json()['db']
        global_rows = [
            a for a in data.get('testAssignments', [])
            if str(a.get('batch_id')) == '*'
            and chemist_id in {int(a.get('primary_user_id') or 0), int(a.get('backup_user_id') or 0)}
        ]
        assert {a.get('workstation') for a in global_rows} == {
            'Electrical', 'TAN / Peroxide / RSH / H2S'
        }
        assert all(a.get('workstation') != 'Additives / Special Tests' for a in global_rows)
