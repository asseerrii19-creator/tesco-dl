# TSCO Digital Laboratory Platform — R10 Deployment Runbook

1. Keep the existing Render PostgreSQL database, persistent disk, uploads/reference assets, and environment variables.
2. Deploy `TSCO_CODE_CONSOLIDATED_REVIEW_QC_R10_AUDITED_LITE_20261006.zip` over the current code baseline.
3. Do not edit the Render commands when the service already uses the commands below.

Build Command:
`pip install -r requirements.txt`

Start Command:
`alembic upgrade head && uvicorn app.main:app --host 0.0.0.0 --port $PORT --proxy-headers --forwarded-allow-ips '*'`

4. Do not reset/recreate UAT case, samples, chain of custody, Lab Batch, or controlled report records.
5. Current Alembic head: `d65f7a9b2c10` (same as R8).
6. After deployment, verify `/api/v1/health`, sign-in, the existing Senior queue, Internal QDF [7]-07-E access, and Final Analysis Report routing using the existing UAT samples.
