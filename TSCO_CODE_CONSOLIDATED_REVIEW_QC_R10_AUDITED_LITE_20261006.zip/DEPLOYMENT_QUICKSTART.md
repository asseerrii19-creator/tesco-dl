# Deployment Quick Start — v3.6.8 / R10

Deploy over the existing Render service and PostgreSQL database. Do not reset or recreate the database.

Keep the existing Render commands unchanged:

Build Command:
`pip install -r requirements.txt`

Start Command:
`alembic upgrade head && uvicorn app.main:app --host 0.0.0.0 --port $PORT --proxy-headers --forwarded-allow-ips '*'`

Current Alembic head: `d65f7a9b2c10`.
The R10 package does not introduce a new migration head relative to R8.
