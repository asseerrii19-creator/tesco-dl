# Final Verification — v3.6.8 / R10

Release: `3.6.8-R10-CONSOLIDATED-REVIEW-QC-CLOSEOUT`
Baseline: v3.6.7 / R9 Post-Senior Report Experience.

## Verification completed
- `BUILD_RELEASE_CHECK.sh`: PASS for the LITE package mode.
- Python application compilation: PASS.
- Static JavaScript syntax (`app.js`, `field-form.js`, `service-worker.js`): PASS.
- Embedded Laboratory Operations JavaScript syntax: PASS (`node --check`).
- Jinja application templates: 68 / 68 parse successfully.
- R10 code-only regression set: 36 PASS.
  - Blind/server-authoritative routine QC.
  - DGA source-file integrity and tamper rejection.
  - IEC 60156 six-run retention + one controlled exclusion + accepted-set recalculation.
  - Whole-number RSD and paper-life presentation.
  - Electrical / DGA / append-only QC regressions.
  - R9 post-Senior/report UX regression.
  - Technical-assessment/QC blocker rules.
- R9 official client report layout/PDF renderer retained byte-for-byte:
  - `app/templates/controlled_report_preview.html`
  - `app/services/final_report_pdf.py`
- R9 internal QDF [7]-07-E worksheet template retained byte-for-byte:
  - `app/templates/internal_worksheets.html`
- `final_report_data.py` changed only where required for whole-number RSD/paper-life presentation and grouped review data consumption.

## LITE package boundary
The LITE code package intentionally does not include the heavy `app/reference_documents` catalog/assets. The release-check script detects this boundary and runs the code-only regression set instead of falsely failing application-lifespan tests for missing bundled references. Production deployment must retain the existing reference-document assets/persistent deployment content and must not reset the database.
