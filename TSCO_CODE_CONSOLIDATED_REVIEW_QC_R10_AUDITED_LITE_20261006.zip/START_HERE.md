# START HERE — Project 00012 v3.6.8 / R10

Current release: `3.6.8-R10-CONSOLIDATED-REVIEW-QC-CLOSEOUT`.
Baseline: v3.6.7 / R9, with the consolidated review/QC closeout changes retained.

## Deploy this release
1. Deploy over the existing Render service and PostgreSQL database.
2. Do **not** reset/recreate the database, UAT case, samples, chain of custody, Lab Batch, uploads, or reference assets.
3. Keep the existing environment variables.
4. Keep the existing Render Build and Start commands unchanged.
5. Continue the existing UAT journey after deployment; do not recreate samples.

## Render commands (must remain exactly as currently configured)
Build Command:
`pip install -r requirements.txt`

Start Command:
`alembic upgrade head && uvicorn app.main:app --host 0.0.0.0 --port $PORT --proxy-headers --forwarded-allow-ips '*'`

Current Alembic head: `d65f7a9b2c10`.
This is unchanged between the deployed R8 baseline and R10.

See `FINAL_VERIFICATION_v3.6.8.md`, `FINAL_PACKAGE_MANIFEST_v3.6.8.md`, and `V3.6.8_CONSOLIDATED_REVIEW_QC_CLOSEOUT.md`.
