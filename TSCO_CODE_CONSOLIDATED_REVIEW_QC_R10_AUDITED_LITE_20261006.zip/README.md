# TSCO Digital Laboratory Platform — Project 00012 v3.6.8 / R10

Current package: **3.6.8-R10-CONSOLIDATED-REVIEW-QC-CLOSEOUT**.
Baseline: v3.6.7 / R9 Post-Senior Report Experience.

R10 preserves the current PostgreSQL UAT journey and all R9 report/workflow improvements, then adds consolidated Senior-review grouping, blind/server-authoritative routine QC, controlled IEC 60156 run exclusion, whole-number RSD presentation, compact QC equipment presentation, and review trend cues.

The internal `QDF [7]-07-E` worksheet and official client `QDF-[7]-08-A` report remain separate controlled outputs.

## Deployment
Use the existing Render configuration. No Build/Start command change is required from R8 to R10.

Build Command:
`pip install -r requirements.txt`

Start Command:
`alembic upgrade head && uvicorn app.main:app --host 0.0.0.0 --port $PORT --proxy-headers --forwarded-allow-ips '*'`

Current database migration head: `d65f7a9b2c10` (same as R8).

See `START_HERE.md`, `FINAL_VERIFICATION_v3.6.8.md`, `FINAL_PACKAGE_MANIFEST_v3.6.8.md`, and `V3.6.8_CONSOLIDATED_REVIEW_QC_CLOSEOUT.md`.

Historical release records are retained in the package for traceability and may mention migration heads that were current at those historical release points; use the current R10 files above for deployment instructions.
