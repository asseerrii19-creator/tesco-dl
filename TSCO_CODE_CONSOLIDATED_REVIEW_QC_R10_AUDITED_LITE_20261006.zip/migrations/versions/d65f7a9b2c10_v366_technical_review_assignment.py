"""v3.6.6 controlled senior technical-review assignment

Revision ID: d65f7a9b2c10
Revises: c43a7d9e2f10
"""
from alembic import op
import sqlalchemy as sa

revision = "d65f7a9b2c10"
down_revision = "c43a7d9e2f10"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "technical_review_assignments",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("sample_request_id", sa.Integer(), sa.ForeignKey("sample_requests.id"), nullable=False),
        sa.Column("site_id", sa.Integer(), sa.ForeignKey("sites.id"), nullable=False),
        sa.Column("primary_senior_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("secondary_senior_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("assigned_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("assignment_mode", sa.String(length=40), nullable=False, server_default="AUTO_WORKLOAD"),
        sa.Column("reason", sa.Text(), nullable=False, server_default=""),
        sa.Column("status", sa.String(length=30), nullable=False, server_default="ACTIVE"),
        sa.Column("revision", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("assigned_at", sa.DateTime(), nullable=False),
        sa.Column("completed_at", sa.DateTime(), nullable=True),
    )
    op.create_index("ix_technical_review_assignments_sample_request_id", "technical_review_assignments", ["sample_request_id"])
    op.create_index("ix_technical_review_assignments_site_id", "technical_review_assignments", ["site_id"])
    op.create_index("ix_technical_review_assignments_primary_senior_id", "technical_review_assignments", ["primary_senior_id"])
    op.create_index("ix_technical_review_assignments_secondary_senior_id", "technical_review_assignments", ["secondary_senior_id"])
    op.create_index("ix_technical_review_assignments_assigned_by_id", "technical_review_assignments", ["assigned_by_id"])
    op.create_index("ix_technical_review_assignments_status", "technical_review_assignments", ["status"])
    op.create_index("ix_technical_review_assignments_assigned_at", "technical_review_assignments", ["assigned_at"])


def downgrade():
    op.drop_table("technical_review_assignments")
