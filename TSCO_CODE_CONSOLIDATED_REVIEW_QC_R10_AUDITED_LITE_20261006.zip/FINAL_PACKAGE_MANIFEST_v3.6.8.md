# Final Package Manifest — v3.6.8 / R10

## Baseline
Direct continuation of v3.6.7 / R9. No R9 report-separation, client-card, internal worksheet, operations-record or post-Senior workflow improvement was removed.

## Controlled changes
1. Blind routine analytical QC: result/source entry only; target and limits hidden; server returns PASS/FAIL.
2. Server-enforced blind policy for every new routine QC record.
3. DGA QC/CRM source CSV is required and server-verified against submitted gas values.
4. Compact/collapsible QC equipment view, including BDV/PF workstations.
5. IEC 60156 six-run evidence retained; max one controlled exclusion with mandatory reason; accepted-set AVG/RSD recalculation.
6. RSD presentation is whole-number while exact RSD remains in calculation metadata.
7. Existing Furan Paper Lifetime whole-year behavior verified and retained.
8. Senior/Manager review results grouped into collapsible Water, BDV/PF/Dielectric, DGA, Furan/Paper, Corrosion, Oil Quality and Other sections.
9. Review trend arrows use previous released asset history when available; no-history state is neutral.
10. Internal QDF [7]-07-E and official client QDF-[7]-08-A remain separate documents.

## Deployment boundary
Code-only LITE package. Preserve current database, uploads/reference assets, environment variables and deployment commands.
