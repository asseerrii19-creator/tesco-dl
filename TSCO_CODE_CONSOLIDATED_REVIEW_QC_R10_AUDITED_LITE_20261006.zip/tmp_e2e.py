from fastapi.testclient import TestClient
from sqlalchemy import select
from datetime import datetime
from app.main import app
from app.database import SessionLocal
from app.models import *
from app.services.lab_operations import get_operations_state
import re

def login(c,email):
    c.get('/logout')
    r=c.post('/login',data={'email':email,'password':'Demo123!'},follow_redirects=False)
    assert r.status_code==303,(email,r.status_code,r.text[:200])

with TestClient(app) as c:
    login(c,'client@sec.local')
    r=c.post('/client/requests',data={'lead_title':'E2E current','client_message':'','sample_delivery_mode':'TSCO_COLLECTION','sample_delivery_notes':'Collect'},follow_redirects=False); cid=int(r.headers['location'].split('/')[-1])
    c.post(f'/client/requests/{cid}/lines',data={'quantity':1,'requested_package':'CUSTOM','method_family':'IEC','priority':'NORMAL','required_tat':'','due_at':'','expected_serials':'','requested_tests':['Water Content KF @RT']},follow_redirects=False)
    c.post(f'/client/requests/{cid}/submit',data={'client_message':''},follow_redirects=False)
    with SessionLocal() as db:
        case=db.get(CommercialCase,cid); coord=db.get(User,case.assigned_coordinator_id); lineid=case.request_lines[0].id
    login(c,coord.email)
    c.post(f'/commercial/cases/{cid}/advance',data={'target_stage':'QUOTATION','quotation_number':'QT-E2E-1','note':'','reference':''},follow_redirects=False)
    login(c,'client@sec.local')
    c.post(f'/client/requests/{cid}/quotation-decision',data={'decision':'ACCEPT','note':'Approved'},follow_redirects=False)
    c.post(f'/client/requests/{cid}/purchase-order',data={'purchase_order_number':'PO-E2E-1'},files={'upload':('po.pdf',b'%PDF-1.4\nE2E','application/pdf')},follow_redirects=False)
    with SessionLocal() as db:
        case=db.get(CommercialCase,cid); qid=case.quotation_id; poid=case.purchase_order_id
    login(c,coord.email)
    c.post(f'/commercial/cases/{cid}/advance',data={'target_stage':'COMPLETE_HANDOVER','handover_commercial':'Quote+PO ok','handover_technical':'Water Content KF @RT','handover_client_info':'SEC','expected_samples':'1','requested_test_package':'','default_priority':'NORMAL','required_tat':'','note':'','reference':''},follow_redirects=False)
    with SessionLocal() as db:
        supervisor=db.scalar(select(User).where(User.email=='sampling.supervisor@tsco.local')); sec=db.scalar(select(Client).where(Client.code=='SEC')); asset=db.scalar(select(Asset).where(Asset.client_id==sec.id)); clientid=sec.id; assetid=asset.id; supid=supervisor.id
    login(c,'field.manager@tsco.local')
    r=c.post('/operations/orders',data={'client_id':clientid,'quotation_id':qid,'purchase_order_id':poid,'operational_project_id':'','supervisor_id':supid,'title':'E2E Sampling','priority':'Normal','due_at':'','notes':'','sampling_request_id':''},follow_redirects=False); print('order',r.status_code,r.headers.get('location'))
    with SessionLocal() as db:
        order=db.scalar(select(SamplingOrder).where(SamplingOrder.commercial_case_id==cid).order_by(SamplingOrder.id.desc())); oid=order.id
    r=c.post(f'/operations/orders/{oid}/assignments',data={'asset_id':assetid,'sample_label':'E2E Sample','source_party':'TSCO','task_type':'ON_SITE_SAMPLING','requested_package':'CUSTOM','commercial_request_line_id':lineid,'sample_count':1,'sampling_point':'Main Tank','container_count':1,'instructions':''},follow_redirects=False); print('assignmentcreate',r.status_code)
    with SessionLocal() as db:
        a=db.scalar(select(SamplingAssignment).where(SamplingAssignment.order_id==oid).order_by(SamplingAssignment.id.desc())); aid=a.id; sm=db.scalar(select(User).where(User.email=='sampleman@tsco.local')); smid=sm.id
    login(c,'sampling.supervisor@tsco.local')
    print('assign sampler',c.post(f'/sampling-supervision/assignment/{aid}/assign',data={'sampler_id':smid,'note':'E2E'},follow_redirects=False).status_code)
    login(c,'sampleman@tsco.local')
    r=c.post('/field/new',data={'assignment_id':aid,'client_id':clientid,'quotation_id':'','purchase_order_id':'','existing_asset_id':assetid,'asset_code':'','serial_number':'','equipment_type':'Transformer','manufacturer':'','station_name':'','asset_location_label':'','voltage_kv':'','rated_mva':'','sample_date_time':datetime.utcnow().isoformat(timespec='minutes'),'sampling_point':'Main Tank','requested_package':'CUSTOM','client_sample_reference':'E2E-REF','oil_temperature_c':'45','ambient_temperature_c':'30','ambient_humidity_pct':'40','gps_latitude':'','gps_longitude':'','gps_accuracy_m':'','field_notes':'','container_count':1},follow_redirects=False)
    print('field',r.status_code,r.headers.get('location'))
    if r.status_code!=303:
        m=re.search(r"<div class='box'><h1>.*?</h1><p>(.*?)</p>",r.text,re.S)
        print('ERROR', re.sub('<.*?>','',m.group(1)) if m else r.text[:1000])
        raise SystemExit(2)
    sid=int(r.headers['location'].rstrip('/').split('/')[-1])
    print('sid',sid)
    login(c,'data.entry@tsco.local')
    r=c.post('/intake/bulk-decision',data={'sample_ids':sid,'note':'accepted'},follow_redirects=False); print('bulk decision',r.status_code)
    with SessionLocal() as db: print('status after decision',db.get(SampleRequest,sid).status)
    r=c.post('/intake/bulk-receive',data={'sample_ids':sid,'seal_status':'Intact','condition_note':'received'},follow_redirects=False); print('bulk receive',r.status_code)
    with SessionLocal() as db: print('status after receive',db.get(SampleRequest,sid).status)
    r=c.post('/intake/batch-release',data={'sample_ids':sid,'note':'release to lab'},follow_redirects=False); print('batch release',r.status_code)
    with SessionLocal() as db:
        s=db.get(SampleRequest,sid); site=db.get(Site,s.site_id); state,p=get_operations_state(db,site)
        print('status after release',s.status)
        matches=[b for b in p.get('batches',[]) if sid in (b.get('platform_sample_ids') or [])]
        print('matching batches',[(b.get('id'),b.get('samples'),b.get('tests')) for b in matches])
        bid=matches[-1]['id']
        print('assignments',[a for a in p.get('testAssignments',[]) if a.get('batch_id') in {bid,'*'} and a.get('workstation')=='Water'])
