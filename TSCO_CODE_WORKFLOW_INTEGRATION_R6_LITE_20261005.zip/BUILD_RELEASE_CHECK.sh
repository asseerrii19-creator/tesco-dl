#!/usr/bin/env bash
set -euo pipefail
MARKER="TSCO-WORKFLOW-INTEGRATION-CLOSEOUT-20261005-R6"
echo "TSCO_BUILD_MARKER=${MARKER}"
if [[ -f ../TSCO_CODE_UAT_BEHAVIORAL_CLOSEOUT_20261003_G.zip ]]; then
  echo "TSCO_CODE_UAT_BEHAVIORAL_CLOSEOUT_SHA256=$(sha256sum ../TSCO_CODE_UAT_BEHAVIORAL_CLOSEOUT_20261003_G.zip | awk '{print $1}')"
fi
python - <<'PY'
from pathlib import Path
p=Path('app/lab_ops/index_template.html')
html=p.read_text(encoding='utf-8')
required=[
    'Analytical QC — Result Validity',
    'Analytical QC readiness',
    "$('queues').innerHTML=qcHtml+",
    'function applyAnalyticalQcActionLocks()',
    'STARTUP QC',
    'SAVE BOTH READINGS + AVERAGE',
    'WATER_DUAL_AVERAGE',
    'EQUIPMENT NOT READY',
    'DGA CRM / Gas Standard',
    'DGA QC / CRM Instrument CSV',
    'DGA results</b> · Import the GC/TOGA CSV when available.',
    'DGA RESULTS COMPLETE',
    'Required gases:',
    'IEC 60156 uses 6 breakdowns; ASTM D1816/D877 use 5.',
    'BDV method / gap',
    'PF Instrument Result File (CSV)',
    'function renderGroupedSampleTests',
    "const CORROSIVE_STATUS_OPTIONS=['Non-corrosive','Corrosive']",
    'Workstation closeout',
    'function reconcile409AndRetry(localPayload)',
    'function equipmentClassSupportsContext',
    'const online=await cloudLoad(true);',
    "if((STORAGE.dirty||STORAGE.saving)&&!force)return false;",
    "const READ_ONLY_PLATFORM_VIEW=['dashboard','labprogress','tracking','finalreport','knowledge'].includes(CURRENT_PLATFORM_SECTION);",
    'if(!READ_ONLY_PLATFORM_VIEW)scheduleCloudSave()',
    'id="additiveHead" style="display:none"',
]
missing=[x for x in required if x not in html]
if missing:
    raise SystemExit('QC UI deployment assertion failed; missing: '+', '.join(missing))
print('TSCO_QC_UI_ASSERTION=PASS')
PY
python - <<'PY_CLOCK'
from pathlib import Path
files=[
    Path('tests/test_v350_daily_analytical_qc_control.py'),
    Path('tests/test_v351_dual_water_workflow.py'),
    Path('tests/test_v352_report_path_closeout.py'),
    Path('tests/test_qc_framework_global.py'),
]
legacy='2026-10-02'
found=[str(p) for p in files if legacy in p.read_text(encoding='utf-8')]
if found:
    raise SystemExit('QC release tests still contain a fixed lab-day date: '+', '.join(found))
print('TSCO_QC_CLOCK_ASSERTION=PASS')
PY_CLOCK
pytest -q \
  tests/test_v285_document_responsibility_recovery.py \
  tests/test_server_authority_bootstrap.py \
  tests/test_v340_standalone_closeout.py \
  tests/test_v341_final_analysis_report.py \
  tests/test_v342_senior_final_report_review.py \
  tests/test_v343_intake_continuity_hotfix.py \
  tests/test_v344_data_form_backfill.py \
  tests/test_v345_consolidated_intake_closeout.py \
  tests/test_v346_live_intake_projection.py \
  tests/test_v347_controlled_intake_amendment.py \
  tests/test_v349_qc_workstation_entrypoint.py \
  tests/test_v350_daily_analytical_qc_control.py \
  tests/test_v351_dual_water_workflow.py \
  tests/test_v352_report_path_closeout.py \
  tests/test_v353_uat_blocker_closeout.py \
  tests/test_v354_electrical_qc_closeout.py \
  tests/test_v355_uat_behavioral_closeout.py \
  tests/test_v356_dga_results_closeout.py \
  tests/test_v357_pre_report_workstation_closeout.py \
  tests/test_v358_append_only_scoped_merge.py \
  tests/test_v359_qc_append_only_matrix.py \
  tests/test_qc_framework_global.py \
  tests/test_workflow_integration_closeout.py
