from __future__ import annotations

from datetime import datetime
from urllib.parse import quote_plus

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import (
    Asset, Client, CommercialCase, CommercialRequestLine, OperationalProject, PurchaseOrder, Quotation, Role, SamplingAssignment, SamplingOrder, SamplingRequestNotice,
    SampleRequest, SampleStatus, Site, TechnicalAssessmentRecord, User,
)
from ..security import require_user
from ..services.audit import add_audit
from ..services.identifiers import next_assignment_code, next_sampling_order_identifiers
from ..services.workflow import add_event
from ..services.lab_operations import package_catalog, get_operations_state, platform_sample_lab_projection_from_payload, reconcile_operations_to_platform
from ..services.commercial import canonical_stage, resolve_handover_case, require_complete_handover, link_sampling_order
from ..services.month_close import assert_site_period_open

router = APIRouter(prefix="/operations", tags=["sampling operations"])
ALLOWED = {Role.OPERATIONS_MANAGER.value, Role.TECHNICAL_MANAGER.value, Role.MANAGEMENT.value, Role.SYSTEM_ADMIN.value}
WRITE_ALLOWED = {Role.OPERATIONS_MANAGER.value}


def _validation_redirect(message: str) -> RedirectResponse:
    return RedirectResponse(f"/operations/orders?error={quote_plus(message)}", status_code=303)


def _optional_int(value: str, label: str) -> int | None:
    clean = (value or "").strip()
    if not clean:
        return None
    if not clean.isdigit():
        raise ValueError(f"{label} is invalid")
    return int(clean)


def _bounded(value: str, label: str, maximum: int, *, required: bool = False) -> str:
    clean = (value or "").strip()
    if required and not clean:
        raise ValueError(f"{label} is required")
    if len(clean) > maximum:
        raise ValueError(f"{label} must be {maximum} characters or fewer")
    return clean


@router.get("/orders")
def orders_dashboard(request: Request, error: str = "", request_id: int | None = None, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    site_id = user.site_id
    orders_stmt = select(SamplingOrder).order_by(SamplingOrder.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and site_id:
        orders_stmt = orders_stmt.where(SamplingOrder.site_id == site_id)
    orders = db.scalars(orders_stmt.limit(100)).all()
    clients = db.scalars(select(Client).where(Client.active.is_(True)).order_by(Client.name)).all()
    quotes = db.scalars(select(Quotation).where(Quotation.status.in_(["ACTIVE", "CLIENT_ACCEPTED"])).order_by(Quotation.number)).all()
    pos = db.scalars(select(PurchaseOrder).where(PurchaseOrder.status == "ACTIVE").order_by(PurchaseOrder.number)).all()
    assets = db.scalars(select(Asset).where(Asset.active.is_(True)).order_by(Asset.asset_code)).all()
    projects_stmt = select(OperationalProject).where(OperationalProject.status == "ACTIVE")
    if user.role != Role.SYSTEM_ADMIN.value and site_id:
        projects_stmt = projects_stmt.where(OperationalProject.site_id == site_id)
    projects = db.scalars(projects_stmt.order_by(OperationalProject.project_reference)).all()
    supervisors_stmt = select(User).where(User.role == Role.SAMPLING_SUPERVISOR.value, User.active.is_(True))
    if user.role != Role.SYSTEM_ADMIN.value and site_id:
        supervisors_stmt = supervisors_stmt.where(User.site_id == site_id)
    supervisors = db.scalars(supervisors_stmt.order_by(User.full_name)).all()
    resample_stmt = (
        select(TechnicalAssessmentRecord)
        .join(SampleRequest, TechnicalAssessmentRecord.sample_request_id == SampleRequest.id)
        .where(
            TechnicalAssessmentRecord.decision == "RESAMPLE",
            SampleRequest.status == SampleStatus.TECHNICAL_REVIEW.value,
        )
        .order_by(TechnicalAssessmentRecord.updated_at.desc())
    )
    if user.role != Role.SYSTEM_ADMIN.value and site_id:
        resample_stmt = resample_stmt.where(SampleRequest.site_id == site_id)
    resample_records = db.scalars(resample_stmt.limit(100)).all()
    existing_resample_sources = set(
        db.scalars(select(SamplingAssignment.resample_of_sample_id).where(SamplingAssignment.resample_of_sample_id.is_not(None))).all()
    )
    pending_resamples = [record for record in resample_records if record.sample_request_id not in existing_resample_sources]
    notices_stmt = select(SamplingRequestNotice).where(SamplingRequestNotice.status == "PENDING_OPERATIONS").order_by(SamplingRequestNotice.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and site_id:
        notices_stmt = notices_stmt.where(SamplingRequestNotice.site_id == site_id)
    pending_sampling_requests = db.scalars(notices_stmt.limit(100)).all()
    selected_sampling_request = db.get(SamplingRequestNotice, request_id) if request_id else None
    if selected_sampling_request and selected_sampling_request.status != "PENDING_OPERATIONS":
        selected_sampling_request = None
    if selected_sampling_request and user.role != Role.SYSTEM_ADMIN.value and site_id and selected_sampling_request.site_id != site_id:
        selected_sampling_request = None
    request_lines = list(db.scalars(
        select(CommercialRequestLine).where(CommercialRequestLine.status == "ACTIVE").order_by(CommercialRequestLine.commercial_case_id, CommercialRequestLine.line_number)
    ).all())
    for line in request_lines:
        completed = len(line.samples)
        pending = db.query(SamplingAssignment).filter(
            SamplingAssignment.commercial_request_line_id == line.id,
            SamplingAssignment.completed_sample_id.is_(None),
            SamplingAssignment.status.notin_(["CANCELLED", "VOID"]),
        ).count()
        line.remaining_for_field = max(0, int(line.quantity or 0) - completed - pending)
    return templates.TemplateResponse(
        "operations_dashboard.html",
        {
            "request": request, "user": user, "orders": orders, "clients": clients, "quotes": quotes,
            "pos": pos, "assets": assets, "projects": projects, "supervisors": supervisors,
            "package_names": [p["name"] for p in package_catalog(db, user.site_id)], "error": error,
            "pending_resamples": pending_resamples, "pending_sampling_requests": pending_sampling_requests,
            "selected_sampling_request": selected_sampling_request, "request_lines": request_lines,
        },
    )


@router.get("")
def operations_overview(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    site_id = user.site_id
    order_stmt = select(SamplingOrder).order_by(SamplingOrder.created_at.desc())
    sample_stmt = select(SampleRequest).order_by(SampleRequest.created_at.desc())
    notice_stmt = select(SamplingRequestNotice).order_by(SamplingRequestNotice.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and site_id:
        order_stmt = order_stmt.where(SamplingOrder.site_id == site_id)
        sample_stmt = sample_stmt.where(SampleRequest.site_id == site_id)
        notice_stmt = notice_stmt.where(SamplingRequestNotice.site_id == site_id)
    orders = db.scalars(order_stmt.limit(300)).all()
    samples = db.scalars(sample_stmt.limit(500)).all()
    # Use the same server OperationsState projection as the Senior laboratory queue. Operations
    # gets read-only tracking; it never edits analytical state.
    payload_by_site = {}
    visible_site_ids = {row.site_id for row in samples}
    for visible_site_id in visible_site_ids:
        site_row = db.get(Site, visible_site_id)
        if not site_row:
            continue
        _, site_payload = get_operations_state(db, site_row)
        if reconcile_operations_to_platform(db, site_payload, site_row.id, actor=None):
            db.commit()
        payload_by_site[visible_site_id] = site_payload
    lab_statuses = {
        SampleStatus.READY_FOR_LAB.value, SampleStatus.REGISTERED.value, SampleStatus.TESTING.value,
        SampleStatus.TECHNICAL_REVIEW.value, SampleStatus.REPORT_APPROVED.value, SampleStatus.REPORT_RELEASED.value,
    }
    lab_tracking = []
    for row in samples:
        if row.status not in lab_statuses:
            continue
        site_payload = payload_by_site.get(row.site_id)
        projection = platform_sample_lab_projection_from_payload(site_payload, row) if site_payload else {
            "blocker": "Laboratory workflow state unavailable", "blockers": ["Laboratory workflow state unavailable"],
            "tests_complete": 0, "tests_required": 0, "test_progress_pct": 0,
            "workstations_closed": 0, "workstations_required": 0, "workstation_progress_pct": 0,
        }
        lab_tracking.append({"sample": row, "projection": projection})
    notices = db.scalars(notice_stmt.limit(200)).all()
    pending_sampling_requests = [n for n in notices if n.status == "PENDING_OPERATIONS"]
    commercial_stmt = select(CommercialCase).where(CommercialCase.status == "ACTIVE").order_by(CommercialCase.updated_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and site_id:
        commercial_stmt = commercial_stmt.where(CommercialCase.site_id == site_id)
    commercial_cases = list(db.scalars(commercial_stmt.limit(300)).all())
    pending_operational_cases = [
        c for c in commercial_cases
        if canonical_stage(c.current_stage) in {"COMPLETE_HANDOVER", "CLIENT_COORDINATION"}
        and not c.sampling_order_id
    ]
    project_stmt = select(OperationalProject).where(
        OperationalProject.status.in_(["APPROVED", "ACTIVE"]),
        OperationalProject.field_scope.is_(True),
    )
    if user.role != Role.SYSTEM_ADMIN.value and site_id:
        project_stmt = project_stmt.where(OperationalProject.site_id == site_id)
    upcoming_projects = list(db.scalars(
        project_stmt.order_by(OperationalProject.planned_start_at, OperationalProject.created_at.desc()).limit(100)
    ).all())
    resample_stmt = (select(TechnicalAssessmentRecord).join(SampleRequest, TechnicalAssessmentRecord.sample_request_id == SampleRequest.id).where(TechnicalAssessmentRecord.decision == "RESAMPLE", SampleRequest.status == SampleStatus.TECHNICAL_REVIEW.value).order_by(TechnicalAssessmentRecord.updated_at.desc()))
    if user.role != Role.SYSTEM_ADMIN.value and site_id:
        resample_stmt = resample_stmt.where(SampleRequest.site_id == site_id)
    resample_records = db.scalars(resample_stmt.limit(100)).all()
    existing_resample_sources = set(db.scalars(select(SamplingAssignment.resample_of_sample_id).where(SamplingAssignment.resample_of_sample_id.is_not(None))).all())
    pending_resamples = [record for record in resample_records if record.sample_request_id not in existing_resample_sources]
    assignments = [a for o in orders for a in o.assignments]
    now = datetime.utcnow()
    overdue_orders = [o for o in orders if o.due_at and o.due_at < now and o.status != "COMPLETED"]
    urgent_samples = [s for s in samples if (s.priority or "").upper() == "URGENT" and s.status != SampleStatus.REPORT_RELEASED.value]
    handoff_statuses = {SampleStatus.SUBMITTED.value, SampleStatus.ACCEPTED.value, SampleStatus.AWAITING_RECEIPT.value, SampleStatus.RECEIVED.value, SampleStatus.READY_FOR_LAB.value}
    handoff = [s for s in samples if s.status in handoff_statuses]
    metrics = {
        "requests": len(pending_sampling_requests) + len(pending_operational_cases),
        "orders": sum(1 for o in orders if o.status != "COMPLETED"),
        "unassigned": sum(1 for a in assignments if a.status == "UNASSIGNED"),
        "field_active": sum(1 for a in assignments if a.status in {"ASSIGNED", "IN_PROGRESS"}),
        "awaiting_intake": sum(1 for s in samples if s.status in {SampleStatus.SUBMITTED.value, SampleStatus.ACCEPTED.value, SampleStatus.AWAITING_RECEIPT.value}),
        "received": sum(1 for s in samples if s.status == SampleStatus.RECEIVED.value),
        "ready_lab": sum(1 for s in samples if s.status == SampleStatus.READY_FOR_LAB.value),
        "testing": sum(1 for s in samples if s.status == SampleStatus.TESTING.value),
        "technical_review": sum(1 for s in samples if s.status == SampleStatus.TECHNICAL_REVIEW.value),
        "pending_report_approval": sum(1 for s in samples if s.status == SampleStatus.REPORT_APPROVED.value),
        "released": sum(1 for s in samples if s.status == SampleStatus.REPORT_RELEASED.value),
        "overdue": len(overdue_orders),
    }
    return templates.TemplateResponse("operations_overview.html", {
        "request": request, "user": user, "metrics": metrics, "orders": orders[:12], "assignments": assignments[:30],
        "handoff": handoff[:30], "overdue_orders": overdue_orders[:20], "urgent_samples": urgent_samples[:20],
        "pending_sampling_requests": pending_sampling_requests, "pending_operational_cases": pending_operational_cases, "pending_resamples": pending_resamples,
        "upcoming_projects": upcoming_projects, "lab_tracking": lab_tracking[:100],
    })


@router.get("/field-progress")
def field_progress(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED | {Role.SAMPLING_SUPERVISOR.value})
    stmt = select(SamplingOrder).order_by(SamplingOrder.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        stmt = stmt.where(SamplingOrder.site_id == user.site_id)
    orders = db.scalars(stmt.limit(300)).all()
    assignments = [a for o in orders for a in o.assignments]
    return templates.TemplateResponse("operations_field_progress.html", {"request": request, "user": user, "assignments": assignments})


@router.get("/handover")
def intake_handover(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    statuses = [SampleStatus.SUBMITTED.value, SampleStatus.ACCEPTED.value, SampleStatus.AWAITING_RECEIPT.value, SampleStatus.RECEIVED.value, SampleStatus.READY_FOR_LAB.value, SampleStatus.REGISTERED.value, SampleStatus.TESTING.value, SampleStatus.TECHNICAL_REVIEW.value]
    stmt = select(SampleRequest).where(SampleRequest.status.in_(statuses)).order_by(SampleRequest.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        stmt = stmt.where(SampleRequest.site_id == user.site_id)
    samples = db.scalars(stmt.limit(300)).all()
    return templates.TemplateResponse("operations_handover.html", {"request": request, "user": user, "samples": samples})


@router.post("/orders")
def create_order(
    request: Request,
    client_id: int = Form(...), quotation_id: str = Form(""), purchase_order_id: str = Form(""), operational_project_id: str = Form(""),
    supervisor_id: str = Form(""), title: str = Form("Sampling request"), priority: str = Form("Normal"),
    due_at: str = Form(""), notes: str = Form(""), sampling_request_id: str = Form(""), db: Session = Depends(get_db),
):
    user = require_user(request, db, WRITE_ALLOWED)
    site = db.get(Site, user.site_id) if user.site_id else db.scalar(select(Site).where(Site.code == "DMM"))
    client = db.get(Client, client_id)
    try:
        quote_id = _optional_int(quotation_id, "Quotation")
        po_id = _optional_int(purchase_order_id, "Purchase order")
        supervisor_key = _optional_int(supervisor_id, "Sampling supervisor")
        request_notice_id = _optional_int(sampling_request_id, "Sampling request")
        project_key = _optional_int(operational_project_id, "Operational Project")
        clean_title = _bounded(title, "Order title", 200) or "Sampling request"
        due_value = datetime.fromisoformat(due_at) if due_at else None
    except ValueError as exc:
        return _validation_redirect(str(exc))
    quote = db.get(Quotation, quote_id) if quote_id else None
    po = db.get(PurchaseOrder, po_id) if po_id else None
    supervisor = db.get(User, supervisor_key) if supervisor_key else None
    project = db.get(OperationalProject, project_key) if project_key else None
    if not site or not site.active:
        return _validation_redirect("Active operational site is required")
    try:
        assert_site_period_open(db, site.id)
    except ValueError as exc:
        return _validation_redirect(str(exc))
    if not client or not client.active:
        return _validation_redirect("Active client is required")
    if quotation_id and not quote:
        return _validation_redirect("Quotation was not found")
    if purchase_order_id and not po:
        return _validation_redirect("Purchase order was not found")
    if quote and quote.client_id != client_id:
        return _validation_redirect("Quotation does not belong to the selected client")
    if quote and quote.status != "ACTIVE":
        return _validation_redirect("Quotation is not active")
    if po and po.client_id != client_id:
        return _validation_redirect("Purchase order does not belong to the selected client")
    if po and po.status != "ACTIVE":
        return _validation_redirect("Purchase order is not active")
    if po and quote and po.quotation_id and po.quotation_id != quote.id:
        return _validation_redirect("Purchase order is linked to a different quotation")
    try:
        commercial_case = resolve_handover_case(db, site_id=site.id, client_id=client_id, quotation_id=quote_id, purchase_order_id=po_id)
        require_complete_handover(commercial_case)
    except ValueError as exc:
        return _validation_redirect(str(exc))
    if project_key and (not project or project.status != "ACTIVE" or project.site_id != site.id or project.client_id != client_id):
        return _validation_redirect("Operational Project must be active and match the order site/client")
    if commercial_case and commercial_case.operational_project_id:
        case_project = db.get(OperationalProject, commercial_case.operational_project_id)
        if not case_project or case_project.status != "ACTIVE":
            return _validation_redirect("The linked Operational Project is not active")
        if project and project.id != case_project.id:
            return _validation_redirect("Selected Operational Project does not match the Business Case")
        project = case_project
    if supervisor_id and not supervisor:
        return _validation_redirect("Sampling supervisor was not found")
    if supervisor and (not supervisor.active or supervisor.role != Role.SAMPLING_SUPERVISOR.value):
        return _validation_redirect("Selected user is not an active sampling supervisor")
    if supervisor and supervisor.site_id != site.id:
        return _validation_redirect("Sampling supervisor must belong to the order site")
    priority = priority.strip().title()
    if priority not in {"Normal", "High", "Urgent"}:
        return _validation_redirect("Unsupported sampling priority")
    request_notice = db.get(SamplingRequestNotice, request_notice_id) if request_notice_id else None
    if request_notice_id and not request_notice:
        return _validation_redirect("Sampling request was not found")
    if request_notice and request_notice.status != "PENDING_OPERATIONS":
        return _validation_redirect("Sampling request has already been converted/closed")
    if request_notice and (request_notice.site_id != site.id or request_notice.client_id != client_id):
        return _validation_redirect("Sampling request site/client does not match this order")
    order_number, _ = next_sampling_order_identifiers(db, site)
    order = SamplingOrder(
        order_number=order_number, site_id=site.id, client_id=client_id,
        quotation_id=quote_id,
        purchase_order_id=po_id, operational_project_id=project.id if project else None,
        created_by_id=user.id, supervisor_id=supervisor_key,
        title=clean_title, priority=priority, due_at=due_value,
        notes=notes.strip(), status="OPEN",
    )
    db.add(order); db.flush()
    if commercial_case:
        link_sampling_order(db, commercial_case, order, user)
    if request_notice:
        request_notice.status = "CONVERTED"
        request_notice.converted_order_id = order.id
        request_notice.converted_at = datetime.utcnow()
    add_audit(db, actor=user, request=request, action="SAMPLING_ORDER_CREATED", entity_type="SamplingOrder", entity_id=order.id, summary=f"Created {order.order_number}", details={"client_id": client_id, "supervisor_id": supervisor_id})
    db.commit()
    return RedirectResponse(f"/operations/orders#order-{order.id}", status_code=303)


@router.post("/orders/{order_id}/assignments")
def add_assignment(
    order_id: int, request: Request, asset_id: str = Form(""), sample_label: str = Form(""),
    source_party: str = Form("TSCO"), task_type: str = Form("ON_SITE_SAMPLING"), requested_package: str = Form("Routine Test"),
    commercial_request_line_id: str = Form(""), sample_count: int = Form(1),
    sampling_point: str = Form("Main Tank Bottom"), container_count: int = Form(1), instructions: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, WRITE_ALLOWED)
    order = db.get(SamplingOrder, order_id)
    if not order:
        return RedirectResponse("/operations/orders", status_code=303)
    if user.site_id and order.site_id != user.site_id:
        return _validation_redirect("Sampling order is outside your assigned site")
    if order.status == "COMPLETED":
        return _validation_redirect("Completed sampling orders cannot receive new assignments")
    source_party = source_party.strip().upper()
    if source_party not in {"TSCO", "CLIENT"}:
        return _validation_redirect("Source party must be TSCO or CLIENT")
    task_type = task_type.strip().upper()
    if task_type not in {"ON_SITE_SAMPLING", "READY_SAMPLE_PICKUP", "COLLECTION_DELIVERY", "RESAMPLE"}:
        return _validation_redirect("Unsupported sampling Task Type")
    try:
        asset_key = _optional_int(asset_id, "Asset")
    except ValueError as exc:
        return _validation_redirect(str(exc))
    asset = db.get(Asset, asset_key) if asset_key else None
    if asset_id and not asset:
        return _validation_redirect("Asset was not found")
    if asset and (not asset.active or asset.client_id != order.client_id):
        return _validation_redirect("Asset is not active for the order client")
    active_packages = {row["name"] for row in package_catalog(db, order.site_id)}
    try:
        line_id = _optional_int(commercial_request_line_id, "Client Request Scope")
        sample_label = _bounded(sample_label, "Sample / collection label", 180, required=True)
        requested_package = _bounded(requested_package, "Requested package", 120, required=True)
        sampling_point = _bounded(sampling_point, "Sampling point", 100, required=True)
    except ValueError as exc:
        return _validation_redirect(str(exc))
    if sample_count < 1 or sample_count > 100:
        return _validation_redirect("Sample count must be between 1 and 100")
    if container_count < 1 or container_count > 100:
        return _validation_redirect("Container count must be between 1 and 100")

    request_line = db.get(CommercialRequestLine, line_id) if line_id else None
    if request_line:
        if request_line.status != "ACTIVE" or not order.commercial_case_id or request_line.commercial_case_id != order.commercial_case_id:
            return _validation_redirect("Client Request Scope does not belong to this sampling order")
        completed = len(request_line.samples)
        pending = db.query(SamplingAssignment).filter(
            SamplingAssignment.commercial_request_line_id == request_line.id,
            SamplingAssignment.completed_sample_id.is_(None),
            SamplingAssignment.status.notin_(["CANCELLED", "VOID"]),
        ).count()
        remaining = max(0, int(request_line.quantity or 0) - completed - pending)
        if sample_count > remaining:
            return _validation_redirect(f"Client Request Scope has only {remaining} sample(s) remaining")
        requested_package = request_line.requested_package
        requested_method_family = request_line.method_family or "DEFAULT"
        requested_tests_json = request_line.requested_tests_json or "[]"
        line_priority = (request_line.priority or "NORMAL").upper()
        line_tat = request_line.required_tat or ""
        line_due = request_line.due_at
    else:
        if requested_package not in active_packages:
            return _validation_redirect("Requested test package is not active for the order site")
        requested_method_family = "DEFAULT"
        requested_tests_json = "[]"
        line_priority = (order.priority or "NORMAL").upper()
        line_tat = ""
        line_due = order.due_at

    created = []
    for index in range(sample_count):
        label = sample_label if sample_count == 1 else f"{sample_label} {index + 1:02d}"
        assignment = SamplingAssignment(
            order_id=order.id, asset_id=asset_key, assigned_sampler_id=None,
            assignment_code=next_assignment_code(order.site), sample_label=label, source_party=source_party, task_type=task_type,
            commercial_request_line_id=request_line.id if request_line else None,
            requested_package=requested_package, requested_method_family=requested_method_family, requested_tests_json=requested_tests_json,
            priority=line_priority, required_tat=line_tat, due_at=line_due,
            sampling_point=sampling_point, container_count=max(1, container_count),
            status="UNASSIGNED", instructions=instructions.strip(), assigned_at=None,
        )
        db.add(assignment); db.flush(); created.append(assignment)
        add_audit(db, actor=user, request=request, action="SAMPLING_ASSIGNMENT_CREATED", entity_type="SamplingAssignment", entity_id=assignment.id, summary=f"{order.order_number} / {assignment.assignment_code}", details={"source_party": source_party, "sample_label": label, "request_scope_line_id": request_line.id if request_line else None, "staff_assignment": "SAMPLING_SUPERVISOR"})
    db.commit()
    return RedirectResponse(f"/operations/orders#order-{order.id}", status_code=303)


@router.post("/resample/{sample_id}")
def create_resample_assignment(sample_id: int, request: Request, db: Session = Depends(get_db)):
    """Convert a Senior Chemist RESAMPLE decision into a controlled sampling order/assignment.

    Technical review requests the resample; Sampling Operations remains the authority that creates
    the replacement field work. The original analytical record is never overwritten.
    """
    user = require_user(request, db, WRITE_ALLOWED)
    sample = db.get(SampleRequest, sample_id)
    if not sample:
        return _validation_redirect("Original sample was not found")
    if user.site_id and sample.site_id != user.site_id:
        return _validation_redirect("Resample request is outside your assigned site")
    assessment = db.scalar(
        select(TechnicalAssessmentRecord).where(TechnicalAssessmentRecord.sample_request_id == sample.id)
    )
    if not assessment or assessment.decision != "RESAMPLE" or sample.status != SampleStatus.TECHNICAL_REVIEW.value:
        return _validation_redirect("A current Senior Chemist RESAMPLE decision is required")
    existing = db.scalar(
        select(SamplingAssignment).where(SamplingAssignment.resample_of_sample_id == sample.id)
    )
    if existing:
        return RedirectResponse(f"/operations/orders#order-{existing.order_id}", status_code=303)

    original_assignment = sample.sampling_assignment
    original_order = original_assignment.order if original_assignment else None
    supervisor_id = original_order.supervisor_id if original_order else None
    source_party = original_assignment.source_party if original_assignment else ("CLIENT" if sample.sampler and sample.sampler.client_id else "TSCO")
    sampler = sample.sampler if sample.sampler and sample.sampler.active else None
    if source_party == "TSCO" and sampler and sampler.client_id is not None:
        sampler = None
    if source_party == "CLIENT" and sampler and sampler.client_id != sample.client_id:
        sampler = None

    order_number, _ = next_sampling_order_identifiers(db, sample.site)
    order = SamplingOrder(
        order_number=order_number, site_id=sample.site_id, client_id=sample.client_id,
        quotation_id=sample.quotation_id, purchase_order_id=sample.purchase_order_id, commercial_case_id=sample.commercial_case_id,
        operational_project_id=(original_order.operational_project_id if original_order else None), created_by_id=user.id,
        supervisor_id=supervisor_id, title=f"Resample — {sample.request_number}", priority="High", status="OPEN",
        notes=f"Controlled resampling requested from technical assessment for {sample.request_number}.",
    )
    db.add(order); db.flush()
    assignment = SamplingAssignment(
        order_id=order.id, asset_id=sample.asset_id, assigned_sampler_id=sampler.id if sampler else None,
        assignment_code=next_assignment_code(sample.site), source_party=source_party, task_type="RESAMPLE",
        commercial_request_line_id=sample.commercial_request_line_id, requested_package=sample.requested_package,
        requested_method_family=sample.requested_method_family, requested_tests_json=sample.requested_tests_json,
        priority="URGENT", required_tat=sample.required_tat, due_at=sample.due_at, sampling_point=sample.sampling_point,
        container_count=max(1, sample.container_count), status="ASSIGNED" if sampler else "UNASSIGNED",
        instructions=(f"RESAMPLE OF {sample.request_number}. " + (assessment.recommendation or "Follow technical assessment instructions.")).strip(),
        assigned_at=datetime.utcnow() if sampler else None, resample_of_sample_id=sample.id,
    )
    db.add(assignment); db.flush()
    add_event(
        db, sample, user, "TECHNICAL_RESAMPLE_ORDERED", sample.status,
        f"Replacement sampling order {order.order_number} / {assignment.assignment_code} created",
    )
    add_audit(
        db, actor=user, request=request, action="RESAMPLE_ASSIGNMENT_CREATED", entity_type="SamplingAssignment",
        entity_id=assignment.id, summary=f"{sample.request_number} → {order.order_number} / {assignment.assignment_code}",
        details={"original_sample_id": sample.id, "assessment_id": assessment.id, "source_party": source_party},
    )
    db.commit()
    return RedirectResponse(f"/operations/orders#order-{order.id}", status_code=303)
