from pathlib import Path
from types import SimpleNamespace

from fastapi.testclient import TestClient

from app.main import app
from app.services.lab_operations import platform_sample_lab_projection_from_payload


def _sample():
    return SimpleNamespace(id=777, request_number='FS-DMM-26-TEST777', lms_number=None, status='TESTING')


def _payload(complete=False):
    sample = _sample()
    batch = {
        'id': 'LB-INTEGRATION-1',
        'platform_sample_id': sample.id,
        'samples': [sample.request_number],
        'tests': [
            {'test': 'Total Acid Number', 'method': 'ASTM D664', 'station': 'TAN / Peroxide / RSH / H2S'},
            {'test': 'Breakdown Voltage @2.5mm- AVG', 'method': 'IEC 60156', 'station': 'Electrical'},
        ],
        'status': 'Testing',
    }
    payload = {
        'batches': [batch],
        'results': [
            {'id': 'R-TAN', 'sample': sample.request_number, 'test': 'Total Acid Number', 'result': '0.03', 'qc_status': 'PASS'},
        ],
        'testAssignments': [
            {'id': 'A-TAN', 'batch_id': batch['id'], 'workstation': 'TAN / Peroxide / RSH / H2S', 'revision': 1},
            {'id': 'A-EL', 'batch_id': batch['id'], 'workstation': 'Electrical', 'revision': 1},
        ],
        'assignmentCompletions': [
            {'id': 'C-TAN', 'batch_id': batch['id'], 'workstation': 'TAN / Peroxide / RSH / H2S', 'assignment_id': 'A-TAN', 'completed_at': '2026-10-05T12:00:00'},
        ],
        'retests': [],
        'qc': [],
    }
    if complete:
        payload['results'].append({'id': 'R-BDV', 'sample': sample.request_number, 'test': 'Breakdown Voltage @2.5mm- AVG', 'result': '68.0', 'qc_status': 'PASS'})
        payload['assignmentCompletions'].append({'id': 'C-EL', 'batch_id': batch['id'], 'workstation': 'Electrical', 'assignment_id': 'A-EL', 'completed_at': '2026-10-05T12:01:00'})
    return sample, payload


def test_canonical_projection_exposes_exact_missing_result_and_workstation_blockers():
    sample, payload = _payload(False)
    row = platform_sample_lab_projection_from_payload(payload, sample)
    assert row['tests_complete'] == 1
    assert row['tests_required'] == 2
    assert row['workstations_closed'] == 1
    assert row['workstations_required'] == 2
    assert 'Breakdown Voltage @2.5mm- AVG' in row['missing_tests']
    assert row['open_workstations'] == ['Electrical']
    assert row['ready_for_technical_review'] is False
    assert row['blocker'].startswith('Missing laboratory result(s):')
    assert any('Workstation closeout pending: Electrical' in x for x in row['blockers'])


def test_canonical_projection_becomes_review_ready_only_after_results_and_closeouts_are_complete():
    sample, payload = _payload(True)
    row = platform_sample_lab_projection_from_payload(payload, sample)
    assert row['tests_complete'] == 2
    assert row['workstations_closed'] == 2
    assert row['blockers'] == []
    assert row['ready_for_technical_review'] is True


def test_senior_primary_navigation_uses_server_queue_not_browser_supervisor_mirror():
    base = (Path(__file__).resolve().parents[1] / 'app' / 'templates' / 'base.html').read_text()
    queue = (Path(__file__).resolve().parents[1] / 'app' / 'templates' / 'lab_workspace.html').read_text()
    assert "item('/lab','My Technical Review','TR','/lab')" in base
    assert "item('/lab/operations?section=supervisor','My Technical Review'" not in base
    assert 'Canonical Laboratory Workflow' in queue
    assert 'Current blocker / next action' in queue


def test_embedded_console_boot_is_server_first_and_read_only_tracking_does_not_autosave():
    source = (Path(__file__).resolve().parents[1] / 'app' / 'lab_ops' / 'index_template.html').read_text()
    assert 'autoDerivedCalculations();renderAll();bootstrapStorage();' not in source
    assert 'bootstrapStorage();' in source
    assert "const READ_ONLY_PLATFORM_VIEW=['dashboard','labprogress','tracking','finalreport','knowledge'].includes(CURRENT_PLATFORM_SECTION);" in source
    assert 'if(!READ_ONLY_PLATFORM_VIEW)scheduleCloudSave()' in source


def test_operations_and_management_use_same_server_workflow_language():
    ops = (Path(__file__).resolve().parents[1] / 'app' / 'templates' / 'operations_overview.html').read_text()
    mgmt = (Path(__file__).resolve().parents[1] / 'app' / 'templates' / 'management.html').read_text()
    assert 'Laboratory & Report Journey' in ops
    assert 'Current blocker / next step' in ops
    assert 'Sample Workflow Monitor' in mgmt
    assert 'Current blocker / next step' in mgmt


def _login(client: TestClient, email: str):
    r = client.post('/login', data={'email': email, 'password': 'Demo123!'}, follow_redirects=False)
    assert r.status_code == 303


def test_server_rendered_tracking_surfaces_render_for_senior_operations_and_manager():
    with TestClient(app) as client:
        _login(client, 'senior.technical@tsco.local')
        senior = client.get('/lab')
        assert senior.status_code == 200
        assert 'Canonical Laboratory Workflow' in senior.text
        assert 'NO BROWSER STATE' in senior.text

        client.get('/logout')
        _login(client, 'operations@tsco.local')
        ops = client.get('/operations')
        assert ops.status_code == 200
        assert 'Laboratory &amp; Report Journey' in ops.text or 'Laboratory & Report Journey' in ops.text

        client.get('/logout')
        _login(client, 'technical@tsco.local')
        mgmt = client.get('/management')
        assert mgmt.status_code == 200
        assert 'Sample Workflow Monitor' in mgmt.text
