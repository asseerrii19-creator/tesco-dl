# TSCO Digital Laboratory Platform — Project 00012 v3.4.8

Current UAT package: **v3.4.8 — Global Analytical/Test QC Framework + Controlled Intake Amendment**.

The release preserves the existing PostgreSQL UAT journey and consolidates live defects found from Client Request through Data Entry and first Laboratory Workstation execution. It does not reintroduce LMS.

See `START_HERE.md`, `V3.4.8_GLOBAL_ANALYTICAL_QC.md`, and the retained v3.4.7 intake amendment record.

Database migration head: `c43a7d9e2f10` (unchanged from v3.4.4).
