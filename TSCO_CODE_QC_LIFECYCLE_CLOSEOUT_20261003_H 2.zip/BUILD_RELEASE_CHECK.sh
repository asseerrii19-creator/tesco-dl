#!/usr/bin/env bash
set -euo pipefail
MARKER="TSCO-WORKSTATION-CONTINUITY-CLOSEOUT-20261003-I"
echo "TSCO_BUILD_MARKER=${MARKER}"
[[ "$(tr -d '\r\n' < VERSION)" == "3.5.7" ]] || { echo "VERSION assertion failed" >&2; exit 1; }
python -m py_compile app/services/lab_operations.py app/routes/lab_operations.py app/services/document_catalog.py
python - <<'PY'
from pathlib import Path
import re
p=Path('app/lab_ops/index_template.html')
html=p.read_text(encoding='utf-8')
required=[
    'QC Material / Lot Control',
    'LOT LIFECYCLE',
    'FILE-FIRST',
    'SAVE QC FILE & RESULT',
    'SUBMIT LOT FOR SENIOR APPROVAL',
    'APPROVED LOT REQUIRED',
    'PENDING_SENIOR',
    'Requested Test / Method Context + Exact Equipment ID',
]
missing=[x for x in required if x not in html]
if missing:
    raise SystemExit('v3.5.7 QC UI assertion failed; missing: '+', '.join(missing))
scripts=re.findall(r'<script[^>]*>(.*?)</script>',html,flags=re.S|re.I)
Path('/tmp/tsco_v357_release.js').write_text('\n'.join(scripts),encoding='utf-8')
required_continuity=['TSCO_LAB_WORKSTATION_CHANGE',"localStorage.setItem(KEY+'-last-workstation'","{name:'Additives / Special Tests',desc:"]
missing2=[x for x in required_continuity if x not in html]
if missing2: raise SystemExit('v3.5.7 workstation continuity assertion failed; missing: '+', '.join(missing2))
print('TSCO_QC_UI_ASSERTION=PASS')
print('TSCO_WORKSTATION_CONTINUITY_ASSERTION=PASS')
PY
node --check /tmp/tsco_v357_release.js
python - <<'PY'
from pathlib import Path
src=Path('app/services/lab_operations.py').read_text(encoding='utf-8')
required=[
    '_QC_ACCEPTABLE = {"PASS"}',
    'def _parse_qc_csv_measurement(',
    'def _sanitize_qc_lots(',
    'def _sanitize_qc_lot_events(',
    'def _qc_record_has_lifecycle_evidence(',
]
missing=[x for x in required if x not in src]
if missing:
    raise SystemExit('v3.5.7 server QC assertion failed; missing: '+', '.join(missing))
print('TSCO_QC_SERVER_ASSERTION=PASS')
PY
pytest -q -W ignore --tb=no \
  tests/test_v347_controlled_intake_amendment.py::test_lab_technician_has_analytical_qc_workspace_and_clear_qc_gate \
  tests/test_v349_qc_workstation_entrypoint.py \
  tests/test_v350_daily_analytical_qc_control.py \
  tests/test_v351_dual_water_workflow.py \
  tests/test_v352_report_path_closeout.py \
  tests/test_v354_electrical_qc_closeout.py \
  tests/test_v355_uat_behavioral_closeout.py \
  tests/test_v356_qc_lifecycle_file_first.py \
  tests/test_v357_workstation_continuity.py
