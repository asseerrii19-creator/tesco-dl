

## v2.8.4 FINAL HANDOVER
- Consolidated Project 00012 into one final handover baseline rather than incremental review copies.
- Added controlled TSCO Communication Flow from lead generation through payment collection and linked it to Sampling / Sample / Review / LMS lifecycle states.
- Prevented manual skipping of operational/laboratory business stages; those stages synchronize from authoritative records.
- Added Sales & Marketing, Finance and Excellence roles plus fixed Senior responsibility domains (Technical / Equipment / Improvement).
- Added controlled Monthly Close and server-side closed-period guards.
- Preserved configurable staff work patterns and availability-aware scheduling.
- Corrected Chemist QC to personal current-period tasks only with future/sequential window enforcement.
- Corrected TAN method integrity to ASTM D664 and Direct Paper DP to IEC 60450; preserved DGA / Corrosive / Paper reporting/evidence gates.
- Repaired clean migration support for the new end-to-end business-flow schema.
- Final verification: 159 tests passed, Python/JavaScript checks passed, one Alembic head, fresh and reversible migrations passed.
# v2.8.4 — Review Coherence Fix

- Rebuilt the public welcome as a single-screen hero composition; removed stacked newspaper-style sections from the visible homepage.
- Kept engineering drafting outside the hero/content cards as a low-contrast page backdrop.
- Reduced Who We Are / Our Vision to a compact identity strip inside the hero.
- Chemist My QC / Validation Tasks now exposes only the active calendar month; future months are hidden.
- Future routine-QC windows cannot be recorded before they open.
- Later windows of the same routine check cannot be recorded until earlier windows are completed.
- The same sequencing rules are enforced server-side, not only in the UI.
- Chemists remain excluded from the broad QC governance console.
- Full regression: 148 tests passed before release packaging.


## v2.8.4 Review Coherence Fix
- Rebuilt public welcome as a single-screen composition: hero + system path + integrated Who We Are / Vision strip; removed stacked flow/pillar sections.
- Chemist QC now resolves only the active calendar month; future months/windows are hidden.
- Server rejects future-period recording and blocks a later window of the same QC check until earlier windows are completed.
- Chemist QC remains a personal execution queue only; governance stays outside the Chemist workspace.
# v2.8.3 — QC Integrity & Visual Closeout (2026-09-14)

- Removed the legacy broad Quality Control workspace from Laboratory Chemist authorization, navigation and direct-section access.
- Chemist now receives one personal `My QC / Validation Tasks` queue only; monthly distribution, staff rotation and quality governance remain outside the Chemist workspace.
- Replaced validation raw-JSON entry with controlled numeric Run 1..N fields and automatic Mean / SD / RSD / Range calculations returned to Quality review.
- Asset-specific routine QC requires the exact verified Equipment ID. Arbitrary equipment is rejected; unverified balance assets remain blocked until mapped in Equipment Master rather than guessed.
- Added verified Metrohm 907 Titrando assets EQ-79 / EQ-80 for electrode-related work; retained verified instrument mappings already present in the baseline.
- Simplified Laboratory Chemist navigation: one Test Workstations entry, no Organization & Roles, no standalone Asset Structure, and employee-only Submit Improvement rather than the full Continuous Improvement governance workspace.
- Employee improvement access is register-only and scoped to the employee's own submissions.
- Corrected sidebar corporate-logo rendering to `contain` so the TSCO Analytical Lab mark is never cropped.
- Preserved the redesigned welcome composition with engineering schematic artwork in page whitespace/corners and side-by-side identity / vision treatment.
- Added v2.8.3 regression coverage for sidebar integrity, direct QC authorization, employee CI scope, asset-specific QC evidence and visual contract.
- Final automated regression: **144 passed / 0 failed**; Python compile, static JavaScript syntax and Alembic single-head checks passed.

# v2.8.2 — Polished Review Baseline (2026-09-14)

- Unified typography and increased UI legibility across shell and laboratory workspace.
- Rebuilt public welcome experience with formal classic/modern composition and engineering blueprint corner artwork.
- Reworked controlled report grouping for DGA, Furan/Indirect DP, Direct Paper DP, oil condition and corrosive-sulfur evidence.
- Added method-specific Corrosive Sulfur / CCD evidence sets and grouped Direct Paper + Corrosive Sulfur under one Special Diagnostic Tests report panel when requested.
- Added controlled report abbreviation legend and DGA ratio screening context without changing Senior Chemist decision authority.
- Reduced empty report sections by rendering only requested/available blocks.

# v2.8.1 — Review Corrections & Workspace Consolidation (2026-09-14)

- Consolidated Continuous Improvement into one role-aware workspace covering Improvement Register, Quality/QC governance, Equipment & History, Validation/Verification, ILC/PT, NCR/CAPA, Competency, Evidence, Audit and Troubleshooting Governance.
- Added a fixed Senior Chemist responsibility model: Technical Affairs, Equipment/Maintenance, and Continuous Improvement/Excellence coordination; the underlying job role remains Senior Chemist.
- Added review accounts for Equipment/Maintenance and Continuous Improvement Senior responsibilities and retained `senior@tsco.local` as Technical responsibility.
- Added employee-facing Troubleshooting Knowledge with controlled issue submission; instrument issues route to Equipment/Maintenance responsibility, technical/method issues route to Technical responsibility, and publication remains Technical Manager/Admin controlled.
- Removed the broad Quality Control governance page from Laboratory Chemist and Senior Chemist navigation. Chemists now use `My QC / Validation Tasks` for only their assigned routine QC and validation/verification/ILC work.
- Monthly routine QC remains server-owned and technician-only; added a second review chemist so Primary + Backup rotation can be reviewed. Existing invalid Senior/back-up distributions are superseded by a new published revision rather than silently rewritten.
- Corrected Transformer / Asset Structure visibility by role; Laboratory Chemist no longer receives a separate asset-structure menu. Senior/Quality/Technical/Management receive oversight/read-only context.
- Fixed `client_id=` empty-query handling and rebuilt the asset hierarchy view as a real controlled Client → Unit/Station → Transformer tree. Added clearly marked UAT example assets for SEC, Aramco and GPEL review data.
- Replaced raw browser 401/403/404 JSON pages with a branded TSCO access/session-change page while preserving JSON behavior for API requests.
- Preserved Senior Chemist Reports/Technical Review authorization and the LMS official-report release boundary.
- Version identity aligned to **2.8.1** across runtime health, backup metadata and embedded Laboratory Operations.
- Automated regression: **129 passed / 0 failed** (47 targeted review/legacy tests + 82 remaining regression tests).
- Python compileall, static JavaScript syntax, embedded Laboratory JavaScript syntax and Alembic single-head verification: **PASS**.
- Status: **Review Corrections Baseline** for renewed role-by-role functional review.

# v2.8.0 — Full Review Baseline (2026-09-14)

- Rebuilt the review baseline around an explicit role/authority matrix rather than inherited menu access.
- Senior Chemist is supervisory: Technical Supervision, progress, retest/resample, retained samples, technical assessment, QC oversight, reports/methods/records; no routine result entry and no personal QC/Validation task execution.
- Laboratory Chemist/Technician owns assigned analytical result entry and assigned QC/validation execution.
- Separated Data Entry from Physical Receiving: Data Entry owns review/LMS registration and post-receipt batch/distribution; Sample Receiving owns custody/container sign-off.
- Reworked Sample Intake tabs into distinct Data Review, Physical Receiving Queue, Batch & Distribution, Released to Lab and All Intake Records views.
- Added Operations ownership/hand-off clarity and read-only Management boundaries.
- Added controlled Continuous Improvement register, Project 00012 roadmap and department-review model with explicit submit/progress/govern/read-only authority.
- Added public Welcome / Vision / Journey experience and end-to-end lifecycle explanation.
- Added first-class Transformer / Asset Structure and Organization & System Roles review pages.
- Added TSCO-branded controlled Transformer Oil report preview with transformer context, analytical result groups, interpretation, authorization and LMS release boundary.
- Restored controlled DGA offline parser for H2/O2/N2/CH4/CO/CO2/C2H4/C2H6/C2H2 and limited import/confirmation execution to laboratory technician/admin review accounts.
- Added staff Work Pattern / Shift Template model used by the night-roster generator; leave/training/unavailability conflicts are excluded.
- Corrected visible-navigation/direct-URL mismatches and strengthened role-specific review tests.
- Full automated regression: **122 passed / 0 failed**.
- Python compileall, static JavaScript syntax, embedded Laboratory JavaScript syntax and Alembic single-head verification: **PASS**.
- Status: **Full Review Baseline** for department-by-department functional review; LMS/production infrastructure remains an IT/UAT gate.

# v2.6.9 — Final Integrity & Configurability Hardening (2026-09-09)

- Closed forced-password-change direct-URL bypass at the central protected-route guard.
- Preserved explicit Admin-configured test methods and valid workstation assignments; only known legacy/blank values are normalized.
- Made the one-time bootstrap administrator password unnecessary after the administrator already exists.
- Aligned runtime, health, backup, Laboratory UI and package version identity to 2.6.9.
- Added five dedicated v2.6.9 integrity regression tests.
- Final automated regression: **97 passed, 0 failed**.
- Preserved advisory linked technical assessment and the LMS official-report boundary.
- Status: **Final UAT Candidate**; production still requires IT/security/LMS/UAT approval.

# v2.6.8 — Assignment Scope, Workstation & Interpretation Hardening (2026-09-09)

- Added server-enforced role + analytical assignment scope for laboratory result entry and technician data visibility.
- Added Single, Primary+Backup, All-Lab-Chemists and audited reassignment workflows.
- Kept actual authenticated result/QC actor and timestamp server-owned.
- Separated Analytical/Test QC authorization from Monthly/Routine Quality Control Distribution assignments.
- Corrected operational workstation grouping: Electrical; Furan/Passivator; DBDS/BHT/Toluene/PCB; TAN/Peroxide/RSH/H2S; Corrosion/CCD; Water; DGA; Physical/Chemistry.
- Preserved method-specific execution inside workstations, including IEC/ASTM BDV variants and PF/DDF/Resistivity methods.
- Added workstation/test/method linkage for controlled SOP/Method/EOP revisions.
- Expanded Senior Chemist linked technical screening across moisture/dielectric, oxidation/ageing, corrosive sulfur/passivation, cellulose/furan/DGA evidence.
- Preserved the LMS official-report boundary.
- Status: **Final UAT Candidate**; production still requires IT/security/LMS/UAT approval.

# v2.6.7 — Monthly Quality Control Distribution (2026-09-03)

- Digitized the approved laboratory Quality Control Distribution duties.
- Added automatic monthly Primary/Backup chemist rotation with server-owned published schedules.
- Added Equipment & Safety and Materials, Gases & Storage views under Quality.
- Added controlled routine-check completion with PASS/ATTENTION/FAIL and mandatory observations for exceptions.
- Added SQL audit event `QUALITY_ROUTINE_CHECK_RECORDED`.
- Preserved v2.6.6 intake/receiving/batching alignment and v2.6.5 LMS official-report boundary.
- Final regression suite: **80 passed, 0 failed**.

# v2.6.6 — Operational Workflow Alignment

- Added Sampling Supervisor request → Operations official Sampling Order handoff.
- Unified Data Review, LMS Registration, Physical Receiving and Batch/Distribution under Sample Intake & Distribution.
- Added direct client-delivered sample intake with optional paper/PDF/image evidence and no field-sampler requirement.
- Verified controlled preservation and authorized retrieval of direct-client paper/PDF submission evidence.
- Added `READY_FOR_LAB` as the controlled handoff between physical receiving and Laboratory Operations.
- Moved operational sample batching ownership out of Laboratory and into Intake; Laboratory batch page retained only as admin diagnostics/compatibility.
- Senior Chemist is the operational Retained Samples owner; Quality has QC/retained compliance visibility and read-only site Audit Trail.
- Retained storage is reserved at Laboratory handoff and the configured retention clock activates after official LMS report issuance.
- Preserved the v2.6.5 LMS official-report boundary and production deployment architecture.
- Automated suite: 72 passed / 0 failed.

# v2.6.5 — LMS Reporting Boundary Alignment

- Confirmed LMS as the official final job-closure and client-report system.
- Added `READY_FOR_LMS` between Senior Chemist technical approval and LMS-confirmed official report issuance.
- Technical Manager now approves completed results for LMS submission rather than locally releasing the official client report.
- `REPORT_RELEASED` is reserved for LMS confirmation of official report issuance.
- Updated client/management/workflow/Laboratory terminology and added LMS boundary regression tests.
- Automated suite: 67 passed / 0 failed.
- Added `SYSTEM_BOUNDARY_LMS_REPORTING.md` and expanded IT integration inputs.

# v2.6.4 — Branded Design Stage 3 (Visual Derivative)

- Continued the approved TSCO Analytical Lab corporate identity across authenticated operational surfaces.
- Standardized role-page headers and explanatory context across Field, Intake, Receiving, Sampling Supervision, Management, Client and Technical Review views.
- Refined dashboard/KPI density, table hierarchy, action controls, Sample Detail surfaces and Administration tiles.
- Further harmonized the embedded Laboratory Operations interface with the main platform shell.
- Functional version, workflow, permissions, database, APIs and integrations remain unchanged.
- Regression suite: 65 passed / 0 failed.

---

# v2.6.4 — Final Functional/UAT Hardening Before Visual Design

- Corrected Docker Compose UAT defaults: demo seeding and API docs are now disabled by default.
- Removed hard-coded local-review passwords from deployable source/launch scripts and generate local review credentials per run.
- Added explicit demo-user password configuration while retaining the UAT/production ban on demo data.
- Added explicit no-store behavior to the password-change flow.
- Added mutation-route authentication-boundary regression coverage.
- Updated application, health, backup and Laboratory build identity to v2.6.4.
- Final pre-package suite: 65 passed / 0 failed; reversible migrations, JavaScript checks, UAT-mode startup simulation and a 14-role visible-link crawl passed.
- Visual identity remains intentionally deferred until after this functional freeze.

This remains a controlled UAT candidate. LMS, exact Python 3.12/pinned-dependency deployment, PostgreSQL/Render behavior, real browser/mobile UAT and production infrastructure controls remain environment acceptance gates.

---

# v2.6.3 — UAT Integrity & Workflow Hardening

- Added site-bound backup restore validation and strict backup collection shapes.
- Hardened retest/report identity integrity and linked completion rules.
- Strengthened controlled Office document and field image content validation.
- Corrected Docker Compose persistent data mapping to `TSCO_DATA_DIR=/var/data`.
- Unified sign-in with server-directed role routing; legacy portal-specific login URLs remain compatibility redirects only.
- Added login throttling/audit and cross-site state-change rejection.
- Isolated Field and Laboratory browser storage by authenticated user and site; authenticated pages are never placed in Service Worker cache.
- Hardened Laboratory synchronization with server-authoritative revisions and 409 conflict handling.
- Enforced append-only Result/QC history with explicit result revisions and server-stamped actor/time.
- Added controlled Retest and Resample workflows without overwriting original analytical records.
- Separated Senior Chemist technical review from Technical Manager final report release/revision.
- Centralized Clients, Staff, Test Packages and Controlled Documents in SQL/admin sources; removed duplicate bundled laboratory documents.
- Added controlled-document signature/type validation, revision lifecycle enforcement and protected no-store downloads.
- Added server backup/restore, atomic identifier sequences and reversible migrations through `7a1c2d3e4f50`.
- Corrected multi-site Laboratory state/UI defaults and Field offline barcode generation to use the authenticated site rather than forcing DMM.
- Added direct-URL/role boundary, navigation crawl, payload-size, malformed-input, multi-site and offline-cache regression coverage.

This build is a controlled UAT candidate. `LMS_MODE=mock` remains configured for Render UAT, and real browser/mobile/Render acceptance is still required before production go-live.

---

# v2.6.0 — Client Hierarchical Access

- Client → Region/Area/Project → Facility/Plant/Station/Substation → Asset → Sample hierarchy.
- Company-wide or scoped client accounts with descendant inheritance.
- Asset-to-client-unit placement.
- Client portal and protected sample tracking enforce unit scope.
- Admin-managed organization permissions without code changes.
- Preserves v2.5 seamless Laboratory Workspace.

# v2.5.0 — Seamless Laboratory Workspace

- Integrated the full Laboratory Operations application visually into the main TSCO Digital Laboratory shell.
- Removed the duplicate laboratory header/navigation when embedded.
- Removed the bordered “site inside a site” presentation.
- Added automatic embedded-page height synchronization to eliminate nested scrolling.
- Laboratory section changes update the main platform URL, top bar and active sidebar item.
- Added Laboratory Settings to the unified sidebar for Technical Manager / System Admin.
- Updated visible laboratory persistence wording from legacy Netlify terminology to platform-server terminology.
- Preserved the existing Laboratory Operations data key and server API contract.

# v2.4.0 — Enterprise Architecture Baseline

- Corporate -> Site -> Department -> User hierarchy.
- Client organization hierarchy (Project / Region / Plant / Station / Site).
- Asset-to-client-unit association.
- Master Data Center for runtime configuration.
- Versioned workflow definitions and ordered steps.
- Configurable approval policies.
- Integration control queue with status, attempts, errors and retry boundary.
- Existing multi-client isolation, site scoping, controlled documents, test packages and audit retained.
- LMS remains the official pending external connector; no fake live connection is claimed.

# v2.3 — Scalable Developer Review Build

- Preserved the complete v2.2 operational workflow and full Laboratory Operations module.
- Added web-based Site & Laboratory administration for Dammam, Jubail, Bahrain and future sites.
- Added corporate management aggregation across sites while retaining site-scoped local operations.
- Retained company-isolated client accounts and added separate seeded SEC and Saudi Aramco client review logins.
- Added user profile administration for role, site and client-account scope changes without editing code.
- Added database-backed Controlled Document management for SOP, METHOD, EOP, QUICK GUIDE, FORM and OTHER document types.
- Added controlled revision behavior: publishing a new active revision supersedes the prior active revision for the same code/site scope without deleting history.
- Added a site-aware Controlled Document Library for laboratory/quality/technical/management users.
- Added database-backed Test Package configuration; newly configured active packages are immediately available to sampling operations and laboratory synchronization.
- Added an Alembic migration for the new controlled-document and test-package tables.
- Preserved the isolated LMS connector boundary under `app/integrations/lms/` for official IT integration.
- No IT/UAT narration was added to normal user-facing operational pages.


## v2.6.0 — Client hierarchical access
- Recursive client organization hierarchy and descendant-scoped visibility.
- Region/area/facility-level client accounts.
- Asset-to-client-unit placement and portal filtering.
- Admin-managed client unit permissions.


## v2.6.4 BRANDED STAGE 4
- Final visual QA and density pass.
- Fixed Sampling Orders summary contrast.
- Improved empty states, Technical Assessment layout, Field lookup alignment and embedded laboratory visual consistency.
- Functional baseline unchanged.

## Branded Stage 5 — Laboratory Core Workspace
- Refined Samples & Batches, Test Workstations, QC and Reports as one consistent operational design system.
- Corrected the oversized empty Batch Logic column by making the secondary card content-sized.
- Rebalanced core workstation cards to a four-column wide-screen launcher with responsive fallbacks.
- Improved workstation queue/result-entry hierarchy and empty states.
- Rebalanced QC entry/current-status panels and report review cards.
- Preserved all v2.6.4 workflow, authorization, persistence and integration behavior.

## v2.6.4 RC1 — Internal UAT Evidence Freeze
- Branded Stage 5 functional/design baseline frozen without application-code changes.
- 65/65 automated regression tests passed.
- 79/79 live end-to-end internal UAT checks passed across Operations, Sampling Supervision, Field, Intake, Receiving, Laboratory, Quality, Senior Chemist review, Technical Manager release, Client, Management and Administration.
- Fresh migration-to-head and UAT-mode clean-database startup validated.
- Added final UAT evidence and explicit separation between internal RC readiness and production infrastructure/sign-off readiness.

## 2.7.0-REVIEW-READY — Closeout hardening
- Standardized controlled LTD result state and confirmed detection-limit normalization.
- Enforced Furan LTD derived outputs and whole-year paper-life rounding.
- Corrected direct-client commercial handover and Sample Origin vs Sampling Point semantics.
- Corrected default transformer sampling-point taxonomy.
- Added closeout traceability, technical result matrix, review-ready status and pending external-input register.
