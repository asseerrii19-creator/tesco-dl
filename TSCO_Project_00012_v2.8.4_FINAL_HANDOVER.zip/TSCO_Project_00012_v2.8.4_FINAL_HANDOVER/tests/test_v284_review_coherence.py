from datetime import datetime

from app.routes.control_center import (
    _active_quality_distribution,
    _routine_period_state,
    _routine_sequence_ready,
)


def test_quality_queue_uses_active_calendar_month_not_latest_future_month():
    payload={"qualityDistributions":[
        {"month":"2026-09","revision":1,"id":"SEP-R1"},
        {"month":"2026-09","revision":2,"id":"SEP-R2"},
        {"month":"2026-10","revision":1,"id":"OCT-R1"},
    ]}
    row=_active_quality_distribution(payload,datetime(2026,9,15))
    assert row["id"]=="SEP-R2"


def test_future_qc_period_is_locked_until_its_window_opens():
    assignment={"start_day":19,"end_day":25}
    assert _routine_period_state(assignment,datetime(2026,9,15))=="FUTURE"
    assert _routine_period_state(assignment,datetime(2026,9,20))=="OPEN"


def test_later_qc_window_requires_earlier_same_check_completion():
    w1={"id":"A-W1","task_key":"balances","start_day":1,"end_day":11}
    w2={"id":"A-W2","task_key":"balances","start_day":12,"end_day":18}
    distribution={"assignments":[w1,w2]}
    assert _routine_sequence_ready(distribution,w2,{}) is False
    assert _routine_sequence_ready(distribution,w2,{"A-W1":{"status":"PASS"}}) is True


def test_unrelated_qc_check_does_not_block_current_check():
    gas={"id":"G-W1","task_key":"gas_supplies","start_day":1,"end_day":11}
    balances={"id":"B-W2","task_key":"balances","start_day":12,"end_day":18}
    distribution={"assignments":[gas,balances]}
    assert _routine_sequence_ready(distribution,balances,{}) is True
