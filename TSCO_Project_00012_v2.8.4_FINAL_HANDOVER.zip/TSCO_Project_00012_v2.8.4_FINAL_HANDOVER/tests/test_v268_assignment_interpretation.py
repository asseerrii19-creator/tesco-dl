from __future__ import annotations

import json
from datetime import datetime

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import SessionLocal
from app.main import app
from app.models import Asset, AuditLog, Client, ControlledDocument, OperationsState, Role, SampleRequest, Site, User
from app.security import hash_password
from app.services.lab_operations import _station_from_name, sync_sample_to_operations
from app.services.technical_assessment import assess_sample


def login(client: TestClient, email: str) -> None:
    response = client.post("/login", data={"email": email, "password": "Demo123!"}, follow_redirects=False)
    assert response.status_code == 303


def create_sample(marker: str, package: str = "Routine Test") -> tuple[int, str]:
    with SessionLocal() as db:
        sec = db.scalar(select(Client).where(Client.code == "SEC"))
        asset = db.scalar(select(Asset).where(Asset.client_id == sec.id))
        sampler = db.scalar(select(User).where(User.email == "fieldman@tsco.local"))
        actor = db.scalar(select(User).where(User.email == "admin@tsco.local"))
        dmm = db.scalar(select(Site).where(Site.code == "DMM"))
        sample = SampleRequest(
            request_number=f"V268-{marker}-REQ", public_token=f"V268-{marker}-TOKEN",
            barcode_value=f"V268-{marker}-BAR", status="TESTING", site_id=dmm.id,
            client_id=sec.id, asset_id=asset.id, sampler_id=sampler.id,
            sample_date_time=datetime.now(), sampling_point="Main Tank Bottom",
            requested_package=package, lms_number=f"V268-{marker}-LMS",
        )
        db.add(sample); db.flush(); sync_sample_to_operations(db, sample, actor=actor, phase="TESTING"); db.commit()
        return sample.id, sample.lms_number


def ensure_backup_user() -> int:
    with SessionLocal() as db:
        existing = db.scalar(select(User).where(User.email == "backup268@tsco.local"))
        if existing:
            return existing.id
        dmm = db.scalar(select(Site).where(Site.code == "DMM"))
        user = User(email="backup268@tsco.local", full_name="Backup Chemist 268", role=Role.LAB_TECHNICIAN.value,
                    site_id=dmm.id, active=True, password_hash=hash_password("Demo123!"), must_change_password=False)
        db.add(user); db.commit(); db.refresh(user); return user.id


def load(client: TestClient) -> dict:
    response = client.get("/api/lab-operations/data")
    assert response.status_code == 200
    return response.json()


def assign(client: TestClient, sample_key: str, workstation: str, mode: str, primary: int | None = None, backup: int | None = None, marker: str = "A") -> dict:
    client.post("/logout"); login(client, "senior@tsco.local")
    loaded = load(client); payload = loaded["db"]
    batch = next(b for b in payload["batches"] if sample_key in b.get("samples", []))
    payload["testAssignments"].append({
        "id": f"V268-{marker}-{batch['id']}-{len(payload['testAssignments'])}",
        "batch_id": batch["id"], "workstation": workstation, "mode": mode,
        "primary_user_id": primary, "backup_user_id": backup,
    })
    saved = client.put("/api/lab-operations/data", json={"db": payload, "clientRevision": loaded["revision"]})
    assert saved.status_code == 200, saved.text
    return saved.json()


def result_for(client: TestClient, sample_key: str, test: str, value: str, rid: str) -> object:
    loaded = load(client); payload = loaded["db"]
    batch = next(b for b in payload["batches"] if sample_key in b.get("samples", []))
    payload["results"].append({"id": rid, "sample": sample_key, "batch": batch["id"], "test": test,
                               "result": value, "unit": "", "analyst": "FORGED"})
    return client.put("/api/lab-operations/data", json={"db": payload, "clientRevision": loaded["revision"]})


def test_unassigned_technician_is_blocked_and_primary_is_allowed_with_server_actor_identity():
    with TestClient(app) as client:
        _, key = create_sample("PRIMARY")
        login(client, "chemist@tsco.local")
        unassigned = load(client)
        assert not any(key in b.get("samples", []) for b in unassigned["db"]["batches"])
        with SessionLocal() as db:
            chemist = db.scalar(select(User).where(User.email == "chemist@tsco.local"))
            chemist_id = chemist.id
        assign(client, key, "Water", "SINGLE", primary=chemist_id, marker="PRIMARY")
        client.post("/logout"); login(client, "chemist@tsco.local")
        saved = result_for(client, key, "Water Content KF @RT", "12", "V268-PRIMARY-OK")
        assert saved.status_code == 200, saved.text
        row = next(r for r in saved.json()["db"]["results"] if r["id"] == "V268-PRIMARY-OK")
        assert row["analyst"] == "Laboratory Chemist"
        assert row["recorded_by_user_id"] == chemist_id


def test_primary_backup_both_authorized_and_assignment_is_audited():
    with TestClient(app) as client:
        _, key = create_sample("BACKUP")
        backup_id = ensure_backup_user()
        with SessionLocal() as db:
            chemist_id = db.scalar(select(User.id).where(User.email == "chemist@tsco.local"))
        saved = assign(client, key, "Water", "PRIMARY_BACKUP", primary=chemist_id, backup=backup_id, marker="PB")
        assignment = saved["db"]["testAssignments"][-1]
        assert assignment["primary_name"] == "Laboratory Chemist"
        assert assignment["backup_name"] == "Backup Chemist 268"
        assert assignment["revision"] == 1
        with SessionLocal() as db:
            audit = db.scalar(select(AuditLog).where(AuditLog.action == "LAB_WORKSTATION_ASSIGNED").order_by(AuditLog.id.desc()))
            assert audit is not None and "Water" in audit.summary
        client.post("/logout"); login(client, "backup268@tsco.local")
        result = result_for(client, key, "Water Content KF @RT", "13", "V268-BACKUP-OK")
        assert result.status_code == 200, result.text
        row = next(r for r in result.json()["db"]["results"] if r["id"] == "V268-BACKUP-OK")
        assert row["analyst"] == "Backup Chemist 268"


def test_reassignment_blocks_old_chemist_and_all_mode_can_open_workstation():
    with TestClient(app) as client:
        _, key = create_sample("REASSIGN")
        backup_id = ensure_backup_user()
        with SessionLocal() as db:
            chemist_id = db.scalar(select(User.id).where(User.email == "chemist@tsco.local"))
        assign(client, key, "Electrical", "SINGLE", primary=chemist_id, marker="R1")
        # Reassign the same workstation to the backup user; server must create revision 2.
        reassigned = assign(client, key, "Electrical", "SINGLE", primary=backup_id, marker="R2")
        current = [a for a in reassigned["db"]["testAssignments"] if a["workstation"] == "Electrical" and a["batch_id"]][ -1]
        assert current["revision"] == 2
        client.post("/logout"); login(client, "chemist@tsco.local")
        old_view = load(client)
        assert not any(key in b.get("samples", []) and any("Breakdown Voltage" in t.get("test", "") for t in b.get("tests", [])) for b in old_view["db"]["batches"])
        client.post("/logout"); login(client, "backup268@tsco.local")
        allowed = result_for(client, key, "Breakdown Voltage @2.5mm- AVG", "55", "V268-NEW-OK")
        assert allowed.status_code == 200, allowed.text

        # ALL is an explicit operational choice; it is not the implicit default.
        assign(client, key, "Water", "ALL", marker="ALL")
        client.post("/logout"); login(client, "chemist@tsco.local")
        water = result_for(client, key, "Water Content KF @RT", "10", "V268-ALL-OK")
        assert water.status_code == 200, water.text


def test_analytical_qc_requires_test_assignment_but_monthly_qc_remains_independent():
    with TestClient(app) as client:
        _, key = create_sample("QC")
        with SessionLocal() as db:
            chemist_id = db.scalar(select(User.id).where(User.email == "chemist@tsco.local"))
        assign(client, key, "Water", "SINGLE", primary=chemist_id, marker="QC")
        client.post("/logout"); login(client, "chemist@tsco.local")
        loaded = load(client); payload = loaded["db"]
        water_assignment = next(a for a in payload["testAssignments"] if a["workstation"] == "Water")
        payload["qc"].append({"id": "V268-WATER-QC", "test": "Water", "result": "10", "status": "PASS",
                              "assignment_id": water_assignment["id"], "batch_id": water_assignment["batch_id"], "workstation": "Water"})
        saved = client.put("/api/lab-operations/data", json={"db": payload, "clientRevision": loaded["revision"]})
        assert saved.status_code == 200, saved.text
        fresh = load(client); bad = fresh["db"]
        bad["qc"].append({"id": "V268-DGA-QC-BLOCK", "test": "DGA", "result": "25", "status": "PASS",
                          "assignment_id": "FORGED", "batch_id": "*", "workstation": "DGA"})
        blocked = client.put("/api/lab-operations/data", json={"db": bad, "clientRevision": fresh["revision"]})
        assert blocked.status_code == 403
        assert "current" in blocked.json()["error"].lower() or "DGA" in blocked.json()["error"]



def test_workstation_default_assignment_applies_to_current_and_future_batches():
    with TestClient(app) as client:
        _, first = create_sample("GLOBAL1")
        with SessionLocal() as db:
            chemist_id = db.scalar(select(User.id).where(User.email == "chemist@tsco.local"))
        client.post("/logout"); login(client, "senior@tsco.local")
        loaded = load(client); payload = loaded["db"]
        payload["testAssignments"].append({
            "id": "V268-GLOBAL-WATER", "batch_id": "*", "scope": "WORKSTATION", "workstation": "Water",
            "mode": "PRIMARY_BACKUP", "primary_user_id": chemist_id, "backup_user_id": ensure_backup_user(),
        })
        saved = client.put("/api/lab-operations/data", json={"db": payload, "clientRevision": loaded["revision"]})
        assert saved.status_code == 200, saved.text
        assert next(a for a in saved.json()["db"]["testAssignments"] if a["id"] == "V268-GLOBAL-WATER")["batch_id"] == "*"
        _, second = create_sample("GLOBAL2")
        client.post("/logout"); login(client, "chemist@tsco.local")
        assert result_for(client, first, "Water Content KF @RT", "11", "V268-GLOBAL-FIRST").status_code == 200
        assert result_for(client, second, "Water Content KF @RT", "12", "V268-GLOBAL-SECOND").status_code == 200


def test_lab_technician_get_is_server_scoped_and_scoped_save_preserves_unseen_work():
    with TestClient(app) as client:
        _, key = create_sample("SCOPE", package="Full Test")
        backup_id = ensure_backup_user()
        with SessionLocal() as db:
            chemist_id = db.scalar(select(User.id).where(User.email == "chemist@tsco.local"))
        assign(client, key, "Water", "SINGLE", primary=chemist_id, marker="SCOPE-W")
        assign(client, key, "DGA", "SINGLE", primary=backup_id, marker="SCOPE-D")

        client.post("/logout"); login(client, "backup268@tsco.local")
        dga = result_for(client, key, "DGA:H2", "5", "V268-SCOPE-DGA")
        assert dga.status_code == 200, dga.text

        client.post("/logout"); login(client, "chemist@tsco.local")
        scoped = load(client)
        assert scoped["db"]["batches"]
        target_batch = next(b for b in scoped["db"]["batches"] if key in b.get("samples", []))
        tests = {row["test"] for row in target_batch.get("tests", [])}
        assert any("Water" in t for t in tests)
        assert all("DGA" not in t and "Dissolved Gas" not in t for t in tests)
        assert not any(r["id"] == "V268-SCOPE-DGA" for r in scoped["db"]["results"])
        assert not any(a["workstation"] == "DGA" and str(a.get("batch_id")) in {str(target_batch["id"]), "*"} for a in scoped["db"]["testAssignments"])

        water = result_for(client, key, "Water Content KF @RT", "9", "V268-SCOPE-WATER")
        assert water.status_code == 200, water.text
        client.post("/logout"); login(client, "senior@tsco.local")
        full = load(client)["db"]
        assert any(r["id"] == "V268-SCOPE-DGA" for r in full["results"])
        assert any(r["id"] == "V268-SCOPE-WATER" for r in full["results"])


def test_superseded_assignment_cannot_be_reused_for_analytical_qc():
    with TestClient(app) as client:
        _, key = create_sample("QCSTALE")
        backup_id = ensure_backup_user()
        with SessionLocal() as db:
            chemist_id = db.scalar(select(User.id).where(User.email == "chemist@tsco.local"))
        first = assign(client, key, "Water", "SINGLE", primary=chemist_id, marker="QCS1")
        stale = next(a for a in reversed(first["db"]["testAssignments"]) if a["workstation"] == "Water" and a["primary_user_id"] == chemist_id and a.get("batch_id") != "*")
        assign(client, key, "Water", "SINGLE", primary=backup_id, marker="QCS2")
        client.post("/logout"); login(client, "chemist@tsco.local")
        loaded = load(client)
        # User is no longer assigned to this sample's Water work, even if other assignments exist in the test database.
        assert not any(key in b.get("samples", []) for b in loaded["db"]["batches"])
        forged = loaded["db"]
        forged["qc"].append({"id": "V268-STALE-QC", "test": "Water", "result": "10", "status": "PASS",
                             "assignment_id": stale["id"], "batch_id": stale["batch_id"], "workstation": "Water"})
        blocked = client.put("/api/lab-operations/data", json={"db": forged, "clientRevision": loaded["revision"]})
        assert blocked.status_code == 403


def test_operational_grouping_keeps_method_variants_and_tan_family_together():
    assert _station_from_name("Breakdown Voltage @2.5mm- AVG") == "Electrical"
    assert _station_from_name("Breakdown Voltage @1mm- AVG") == "Electrical"
    assert _station_from_name("Power Factor @25°C/60Hz") == "Electrical"
    assert _station_from_name("Dissipation Factor @90°C/60Hz") == "Electrical"
    assert _station_from_name("Resistivity @25°C/60Hz") == "Electrical"
    for name in ("Total Acid Number", "Peroxide Number", "Total Mercaptan (RSH)", "Hydrogen Sulfide Gas (H2S)"):
        assert _station_from_name(name) == "TAN / Peroxide / RSH / H2S"
    for name in ("2-Furfural (2FAL)", "Indirect DP-value", "Passivator (Irgamet 39)"):
        assert _station_from_name(name) == "Furan / Passivator"
    for name in ("Dibenzyl Disulfide (DBDS)", "Antioxidant (BHT)", "Toluene", "Polychlorinated Biphenyls (PCBs)"):
        assert _station_from_name(name) == "DBDS / BHT / Toluene / PCB"
    for name in ("Potentially Corrosive Sulfur (CCD)", "Corrosive Sulfur", "Tarnish Level", "ASTM Copper Corrosion (Cu Strip)"):
        assert _station_from_name(name) == "Corrosion / CCD"
    for name in ("Transformer Oil Temperature", "Humidity in Cellulose"):
        assert _station_from_name(name) == "Water"
    assert _station_from_name("Oil Quality Index") == "Physical / Chemistry"


def test_technician_ui_is_assignment_focused_and_supports_primary_backup_all_reassignment():
    with TestClient(app) as client:
        login(client, "chemist@tsco.local")
        shell = client.get("/lab/operations")
        assert shell.status_code == 200
        assert "section=workstations" in shell.text
        app_html = client.get("/lab/operations/app?embed=1&section=workstations").text
        assert "No analytical workstation is assigned to this account" in app_html
        assert "assignmentAllowsCurrent" in app_html
        assert "TAN / Peroxide / RSH / H2S" in app_html
        assert "pruneUnauthorizedPages" in app_html
        client.post("/logout"); login(client, "senior@tsco.local")
        senior_html = client.get("/lab/operations/app?embed=1&section=supervisor").text
        assert "Test Workstation Assignment" in senior_html
        assert "Primary + Backup" in senior_html
        assert "All Laboratory Chemists" in senior_html
        assert "SAVE / REASSIGN" in senior_html


def test_controlled_documents_can_be_linked_to_workstation_and_test_and_filtered():
    with TestClient(app) as client:
        login(client, "admin@tsco.local")
        response = client.post(
            "/admin/documents",
            data={"document_type": "SOP", "code": "SOP-WATER-V268", "title": "Water SOP v2.6.8", "revision": "01",
                  "effective_date": "2026-09-09", "site_id": "", "workstation": "Water", "test_name": "Water Content KF @RT", "method_name": "IEC 60814", "notes": "linked"},
            files={"document_file": ("water.txt", b"controlled water sop", "text/plain")},
            follow_redirects=False,
        )
        assert response.status_code == 303
        with SessionLocal() as db:
            doc = db.scalar(select(ControlledDocument).where(ControlledDocument.code == "SOP-WATER-V268"))
            assert doc.workstation == "Water" and doc.test_name == "Water Content KF @RT" and doc.method_name == "IEC 60814"
        client.post("/logout"); login(client, "chemist@tsco.local")
        library = client.get("/documents?workstation=Water&test=Water%20Content%20KF%20%40RT&method=IEC%2060814")
        assert library.status_code == 200
        assert "SOP-WATER-V268" in library.text
        assert "Water Content KF @RT" in library.text


def test_linked_interpretation_connects_corrosive_sulfur_oxidation_cellulose_and_electrical_evidence():
    with TestClient(app):
        sample_id, key = create_sample("ASSESS", package="Full Test")
    with SessionLocal() as db:
        sample = db.get(SampleRequest, sample_id)
        state = db.scalar(select(OperationsState).where(OperationsState.site_id == sample.site_id))
        payload = json.loads(state.json_data)
        rows = [
            ("Dibenzyl Disulfide (DBDS)", "120", "mg/kg"), ("Passivator (Irgamet 39)", "50", "mg/kg"),
            ("Potentially Corrosive Sulfur (CCD)", "Non-corrosive", ""), ("Total Mercaptan (RSH)", "2", "mg/kg"),
            ("Total Acid Number", "0.20", "mg KOH/g"), ("Peroxide Number", "5", "mg/kg"),
            ("Antioxidant (BHT)", "0.08", "%"), ("Interfacial Tension (IFT)", "20", "mN/m"),
            ("Water Content KF @RT", "20", "mg/kg"), ("Breakdown Voltage @2.5mm- AVG", "45", "kV"),
            ("Dissipation Factor @90°C/60Hz", "0.25", ""), ("FURAN:2FAL", "0.5", "mg/kg"),
            ("FURAN_CALC:INDIRECT_DP", "400", ""), ("DGA:CO", "200", "ppm"), ("DGA:CO2", "1200", "ppm"),
        ]
        payload["results"] = [{"id": f"ASSESS-{i}", "sample": key, "test": t, "result": v, "unit": u, "ts": f"2026-09-09T10:{i:02d}:00"} for i,(t,v,u) in enumerate(rows)]
        state.json_data = json.dumps(payload); db.commit()
        assessment = assess_sample(db, sample)
        groups = {g["title"]: g for g in assessment["linked_assessments"]}
        assert groups["Corrosive Sulfur / Passivation"]["status"] == "ATTENTION"
        assert any("passivation can mask" in n.lower() for n in groups["Corrosive Sulfur / Passivation"]["notes"])
        assert "Oil Oxidation / Ageing" in groups
        assert "Cellulose / Paper Ageing" in groups
        assert "Moisture / Dielectric Condition" in groups


def test_v268_qdf_method_fidelity_and_optional_bdv_variants_are_not_forced():
    import json
    from pathlib import Path
    package_file = Path(__file__).resolve().parents[1] / "app" / "data" / "lab_packages.json"
    packages = json.loads(package_file.read_text(encoding="utf-8"))["packages"]
    routine = next(p for p in packages if p["name"] == "Routine Test")
    full = next(p for p in packages if p["name"] == "Full Test")
    def row(pkg, name):
        return next(x for x in pkg["tests"] if x["test"] == name)
    assert row(routine, "Total Acid Number")["method"] == "ASTM D664"
    assert row(full, "Total Acid Number")["method"] == "ASTM D664"
    assert row(full, "H2S")["method"] == "UOP 163"
    forced = {x["test"] for x in full["tests"]}
    assert "Breakdown Voltage @2mm- AVG" not in forced
    assert "Breakdown Voltage @2.54mm- AVG" not in forced
    # Those alternatives remain available in the UI master catalogue for a custom/client request.
    html = (Path(__file__).resolve().parents[1] / "app" / "lab_ops" / "index_template.html").read_text(encoding="utf-8")
    assert '"test":"Breakdown Voltage @2mm- AVG","method":"ASTM D1816"' in html
    assert '"test":"Breakdown Voltage @2.54mm- AVG","method":"ASTM D877"' in html
    assert '"test":"Total Acid Number","method":"ASTM D664"' in html
    assert 'TAN_D664' not in html and 'Acid Number — ASTM D664' not in html
    assert '"id":"tan","title":"Total Acid Number (TAN)"' in html
    assert '"station":"TAN / Peroxide / RSH / H2S","methods":["ASTM D664"]' in html
