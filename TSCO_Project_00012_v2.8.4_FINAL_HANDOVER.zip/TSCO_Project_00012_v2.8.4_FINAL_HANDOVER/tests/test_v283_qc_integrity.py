from fastapi.testclient import TestClient
from sqlalchemy import select

from app.main import app
from app.database import SessionLocal
from app.models import QualityCase, Site, User


def login(client, email, password="Demo123!"):
    response = client.post("/login", data={"email": email, "password": password}, follow_redirects=False)
    assert response.status_code == 303, response.text


def test_chemist_operations_payload_contains_no_monthly_distribution_or_events():
    with TestClient(app) as client:
        login(client, "chemist@tsco.local")
        payload = client.get("/api/lab-operations/data")
        assert payload.status_code == 200
        db = payload.json()["db"]
        assert db["qualityDistributions"] == []
        assert db["qualityTaskEvents"] == []


def test_chemist_validation_ui_uses_numeric_runs_not_json_and_submission_calculates_stats():
    with SessionLocal() as db:
        user = db.scalar(select(User).where(User.email == "chemist@tsco.local"))
        site = db.scalar(select(Site).where(Site.code == "DMM"))
        creator = db.scalar(select(User).where(User.email == "quality@tsco.local"))
        old = db.scalar(select(QualityCase).where(QualityCase.case_number == "VAL-V283-UI"))
        if old:
            db.delete(old); db.commit()
        row = QualityCase(
            site_id=site.id, case_number="VAL-V283-UI", case_type="VALIDATION",
            title="Water repeatability review", test_name="Water Content KF @RT", method_name="IEC 60814",
            assigned_to_id=user.id, status="ASSIGNED", priority="NORMAL", protocol_json='{"required_runs":3}',
            created_by_id=creator.id,
        )
        db.add(row); db.commit(); cid=row.id

    with TestClient(app) as client:
        login(client, "chemist@tsco.local")
        page = client.get("/control/my-quality-tasks")
        assert page.status_code == 200
        assert 'name="run_1"' in page.text and 'name="run_2"' in page.text and 'name="run_3"' in page.text
        assert "Raw runs JSON" not in page.text
        submitted = client.post(
            f"/control/my-quality-tasks/{cid}/submit",
            data={"run_1":"10.0","run_2":"10.2","run_3":"9.8","evidence_reference":"VAL-SHEET-001"},
            follow_redirects=False,
        )
        assert submitted.status_code == 303

    with SessionLocal() as db:
        row=db.get(QualityCase,cid)
        assert row.status == "QUALITY_REVIEW"
        assert '"n": 3' in row.calculation_json
        assert row.evidence_reference == "VAL-SHEET-001"
        db.delete(row); db.commit()


def _side_nav(html: str) -> str:
    start = html.index('<nav class="side-nav">')
    end = html.index('</nav>', start)
    return html[start:end]


def test_chemist_sidebar_has_one_workstation_and_no_governance_links():
    with TestClient(app) as client:
        login(client, "chemist@tsco.local")
        page = client.get("/control/my-quality-tasks")
        assert page.status_code == 200
        nav = _side_nav(page.text)
        assert nav.count("Test Workstations") == 1
        assert "My QC / Validation Tasks" in nav
        assert "Improvement Proposal" in nav
        assert ">Continuous Improvement<" not in nav
        assert "Organization &amp; Roles" not in nav and "Organization & Roles" not in nav
        assert "Transformer / Asset Structure" not in nav


def test_chemist_improvement_workspace_is_submit_only():
    with TestClient(app) as client:
        login(client, "chemist@tsco.local")
        page = client.get("/improvement?tab=quality")
        assert page.status_code == 200
        assert "Improvement Opportunity" in page.text
        assert "My submitted opportunities" in page.text
        assert "Senior responsibility board" not in page.text
        assert "Quality &amp; QC" not in _side_nav(page.text)
        assert 'href="/improvement?tab=quality"' not in page.text


def test_equipment_specific_qc_rejects_arbitrary_eq_and_accepts_verified_titrator():
    with TestClient(app) as client:
        login(client, "quality@tsco.local")
        governed = client.get("/api/lab-operations/data").json()["db"]
        month = __import__('datetime').datetime.utcnow().strftime("%Y-%m")
        distribution = next(row for row in governed["qualityDistributions"] if row["month"] == month)
        with SessionLocal() as db:
            chemist = db.scalar(select(User).where(User.email == "chemist@tsco.local"))
            electrode = next(row for row in distribution["assignments"] if row.get("task_key") == "electrode" and chemist.id in {row.get("primary_user_id"), row.get("backup_user_id")})
            wrong = db.scalar(select(__import__('app.models', fromlist=['EquipmentAsset']).EquipmentAsset).where(__import__('app.models', fromlist=['EquipmentAsset']).EquipmentAsset.equipment_id == "EQ-69"))
            right = db.scalar(select(__import__('app.models', fromlist=['EquipmentAsset']).EquipmentAsset).where(__import__('app.models', fromlist=['EquipmentAsset']).EquipmentAsset.equipment_id == "EQ-79"))
            assert wrong and right
        client.post("/logout")
        login(client, "chemist@tsco.local")
        missing = client.post(f"/control/my-quality-tasks/routine/{electrode['id']}", data={"status":"PASS","note":""}, follow_redirects=False)
        assert missing.status_code == 400
        assert "exact Equipment ID" in missing.text
        bad = client.post(f"/control/my-quality-tasks/routine/{electrode['id']}", data={"status":"PASS","note":"","equipment_asset_id":str(wrong.id)}, follow_redirects=False)
        assert bad.status_code == 400
        assert "does not match this QC check" in bad.text
        good = client.post(f"/control/my-quality-tasks/routine/{electrode['id']}", data={"status":"PASS","note":"","equipment_asset_id":str(right.id)}, follow_redirects=False)
        assert good.status_code == 303


def test_chemist_cannot_open_legacy_broad_quality_section_directly():
    with TestClient(app) as client:
        login(client, "chemist@tsco.local")
        blocked = client.get("/lab/operations?section=quality", follow_redirects=False)
        assert blocked.status_code == 403
        assert "Quality Control" not in blocked.text


def test_v283_visual_contract_keeps_logo_uncropped_and_engineering_art_outside_hero():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    css = (root / "app/static/styles.css").read_text()
    welcome = (root / "app/templates/welcome.html").read_text()
    assert "object-fit:contain!important" in css
    assert "welcome-engineering-backdrop" in welcome
    assert "welcome-identity-stage" in welcome
    assert "WHO WE ARE" in welcome and "OUR VISION" in welcome
