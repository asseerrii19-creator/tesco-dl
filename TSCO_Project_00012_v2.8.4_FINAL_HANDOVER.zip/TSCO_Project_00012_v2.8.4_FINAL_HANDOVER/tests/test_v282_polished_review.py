import json
from datetime import datetime
from pathlib import Path

from fastapi.testclient import TestClient

from app.main import app
from app.database import SessionLocal
from app.models import Asset, Client, ControlledReport, EvidenceRecord, SampleRequest, Site, User
from app.services.lab_operations import get_operations_state, save_operations_state

PASSWORD = "Demo123!"


def ensure_sample(db, site):
    sample=db.query(SampleRequest).filter(SampleRequest.site_id==site.id).first()
    if sample is not None:
        return sample
    client=db.query(Client).filter(Client.code=='SEC').first() or db.query(Client).first()
    asset=db.query(Asset).filter(Asset.client_id==client.id).first() or db.query(Asset).first()
    sample=SampleRequest(
        request_number='TSCO-V282-SAMPLE', public_token='TSCO-V282-PUBLIC', barcode_value='TSCO-V282-BAR',
        status='TECHNICAL_REVIEW', site_id=site.id, client_id=client.id, asset_id=asset.id,
        sample_date_time=datetime(2026,9,14,12,0,0), sampling_point='Main Tank / Bottom',
        sample_origin='Client-Originated / Direct Delivery', requested_package='Full Test', priority='NORMAL'
    )
    db.add(sample); db.commit(); db.refresh(sample)
    return sample


def login(client, email):
    r=client.post('/login',data={'email':email,'password':PASSWORD},follow_redirects=False)
    assert r.status_code==303


def test_welcome_polish_and_engineering_visuals_are_present():
    with TestClient(app) as client:
        page=client.get('/welcome')
        assert page.status_code==200
        for text in ('One sample journey','WHO WE ARE','OUR VISION','OUR JOURNEY','From organization to transformer to report','Quality & Continuous Improvement'):
            assert text in page.text
        assert '/static/engineering-corner.svg' in (Path('app/static/styles.css').read_text())
        assert 'Segoe UI Variable' in Path('app/static/styles.css').read_text()


def test_report_preview_groups_direct_paper_separately_and_special_panel_combines_with_corrosion():
    with TestClient(app) as client:
        login(client,'senior@tsco.local')
        db=SessionLocal()
        try:
            senior=db.query(User).filter(User.email=='senior@tsco.local').one()
            site=db.query(Site).filter(Site.id==senior.site_id).one()
            sample=ensure_sample(db,site)
            state,payload=get_operations_state(db,site)
            payload.setdefault('results',[]).extend([
                {'sample':sample.request_number,'test':'Direct DP-value','display_test':'DP-value of Paper','result':'742','unit':'','method':'IEC 60450','analyst':'Analyst A','ts':'2026-09-14T10:00:00'},
                {'sample':sample.request_number,'test':'Corrosive Sulfur','result':'Non-corrosive','unit':'Pass/Fail','method':'ASTM D1275B','analyst':'Analyst B','ts':'2026-09-14T10:05:00'},
                {'sample':sample.request_number,'test':'Tarnish Level','result':'1b','unit':'','method':'ASTM D130','analyst':'Analyst B','ts':'2026-09-14T10:05:00'},
                {'sample':sample.request_number,'test':'DGA:H2','display_test':'Hydrogen (H2)','result':'42','unit':'ppm','method':'IEC 60567','analyst':'Analyst C','ts':'2026-09-14T10:10:00'},
                {'sample':sample.request_number,'test':'DGA:CH4','display_test':'Methane (CH4)','result':'59','unit':'ppm','method':'IEC 60567','analyst':'Analyst C','ts':'2026-09-14T10:10:00'},
                {'sample':sample.request_number,'test':'DGA:C2H6','display_test':'Ethane (C2H6)','result':'68','unit':'ppm','method':'IEC 60567','analyst':'Analyst C','ts':'2026-09-14T10:10:00'},
                {'sample':sample.request_number,'test':'DGA:C2H4','display_test':'Ethylene (C2H4)','result':'12','unit':'ppm','method':'IEC 60567','analyst':'Analyst C','ts':'2026-09-14T10:10:00'},
                {'sample':sample.request_number,'test':'DGA:C2H2','display_test':'Acetylene (C2H2)','result':'0','unit':'ppm','method':'IEC 60567','analyst':'Analyst C','ts':'2026-09-14T10:10:00'},
            ])
            save_operations_state(db,state,payload,actor=senior)
            report=ControlledReport(site_id=site.id,sample_request_id=sample.id,report_number='V282-PREVIEW',condition_status='NORMAL',interpretation='Technical interpretation.',recommendation='Routine monitoring.',report_payload_json=json.dumps({'dga_requested':True,'corrosive_sulfur_requested':True,'paper_dp_requested':True}),qr_token='V282-TOKEN',reviewed_by_id=senior.id,status='TECHNICAL_REVIEW')
            db.add(report); db.commit(); rid=report.id
        finally: db.close()
        page=client.get(f'/control/report/{rid}/preview')
        assert page.status_code==200
        assert 'Direct DP-value on Paper Sample' in page.text
        assert 'Corrosive Sulfur / CCD / Tarnish' in page.text
        assert 'Shown together when requested' in page.text
        assert 'Dissolved Gas Analysis' in page.text
        assert 'Gas ratios & diagnostic context' in page.text
        assert 'Degree of Polymerization' in page.text
        assert 'Less Than Detection' in page.text


def test_corrosive_approval_accepts_ccd_copper_and_paper_evidence_set():
    with TestClient(app) as client:
        db=SessionLocal()
        try:
            admin=db.query(User).filter(User.email=='admin@tsco.local').first()
            site=db.query(Site).filter(Site.id==admin.site_id).one()
            sample=ensure_sample(db,site)
            report=ControlledReport(site_id=site.id,sample_request_id=sample.id,report_number='V282-CCD-GATE',condition_status='NORMAL',report_payload_json=json.dumps({'corrosive_sulfur_requested':True}),qr_token='V282-CCD-TOKEN',reviewed_by_id=admin.id,status='TECHNICAL_REVIEW')
            db.add(report); db.flush()
            for typ in ('CORROSIVE_COPPER','CORROSIVE_PAPER_INNER','CORROSIVE_PAPER_OUTER'):
                db.add(EvidenceRecord(site_id=site.id,sample_request_id=sample.id,evidence_type=typ,title=typ,original_filename=f'{typ}.jpg',stored_path=f'/tmp/{typ}.jpg',sha256='a'*64,uploaded_by_id=admin.id,status='CONTROLLED'))
            db.commit(); rid=report.id
        finally: db.close()
        login(client,'admin@tsco.local')
        r=client.post(f'/control/report/{rid}/approve',follow_redirects=False)
        assert r.status_code==303


def test_dga_assessment_finds_results_by_request_number_even_when_lms_number_exists():
    from app.services.technical_assessment import assess_sample
    with SessionLocal() as db:
        site=db.query(Site).filter(Site.code=='DMM').first() or db.query(Site).first()
        sample=ensure_sample(db,site)
        sample.lms_number='LMS-ALT-282'
        senior=db.query(User).filter(User.email=='senior@tsco.local').one()
        state,payload=get_operations_state(db,site)
        gases={'H2':42,'O2':9149,'N2':81687,'CH4':59,'CO':459,'CO2':1385,'C2H4':12,'C2H6':68,'C2H2':0}
        payload.setdefault('results',[]).extend([
            {'sample':sample.request_number,'test':f'DGA:{gas}','result':str(value),'unit':'ppm','method':'IEC 60567','ts':'2026-09-14T12:00:00'}
            for gas,value in gases.items()
        ])
        save_operations_state(db,state,payload,actor=senior)
        db.commit(); db.refresh(sample)
        a=assess_sample(db,sample)
        assert len(a['gases']) == 9
        assert a['gases']['CO'] == 459
        assert a['dga'] is not None
        assert 'CO2/CO' in a['dga']['ratios']


def test_catalog_direct_paper_and_corrosive_methods_are_controlled():
    import json as _json
    catalog=_json.loads(Path('app/data/lab_packages.json').read_text())['tests']
    by_name={row['test']:row for row in catalog}
    assert by_name['Direct DP-value']['method']=='IEC 60450'
    assert by_name['DP-value of Paper']['method']=='IEC 60450'
    assert by_name['Corrosive Sulfur']['method'].upper()=='ASTM D1275B'
    assert by_name['Tarnish Level']['method'].upper()=='ASTM D130'
    assert by_name['Potentially Corrosive Sulfur (CCD)']['method'].upper()=='IEC 62535'


def test_role_specific_visible_backlinks_do_not_point_to_forbidden_legacy_pages():
    with TestClient(app) as client:
        login(client,'supervisor@tsco.local')
        page=client.get('/operations/field-progress')
        assert page.status_code==200
        assert 'href="/sampling-supervision"' in page.text
        assert '>Operations Overview</a>' not in page.text
        client.post('/logout')
        login(client,'receiving@tsco.local')
        page=client.get('/receiving')
        assert page.status_code==200
        assert '<a href="/intake">' not in page.text
        client.post('/logout')
        login(client,'manager@tsco.local')
        page=client.get('/management')
        assert page.status_code==200
        assert 'href="/improvement?tab=quality"' in page.text
        assert 'href="/control"' not in page.text


def test_client_topbar_does_not_expose_internal_notification_route():
    with TestClient(app) as client:
        login(client,'client@sec.local')
        page=client.get('/client')
        assert page.status_code==200
        assert 'href="/control/notifications"' not in page.text


def test_report_aliases_are_deduplicated_into_controlled_display_names():
    from app.routes.control_center import _polish_report_buckets
    buckets={
        'dga':[
            {'test':'DGA:CH4','result':'58','ts':'2026-09-14T09:00:00'},
            {'test':'Methane (CH4)','result':'59','ts':'2026-09-14T10:00:00'},
            {'test':'DGA:C2H6','result':'68','ts':'2026-09-14T10:00:00'},
        ],
        'paper':[
            {'test':'Direct DP-value','result':'730','ts':'2026-09-14T09:00:00'},
            {'test':'DP-value of Paper','result':'742','ts':'2026-09-14T10:00:00'},
        ],
        'corrosion':[
            {'test':'ASTM Copper Corrosion (Cu Strip)','result':'Corrosive','ts':'2026-09-14T09:00:00'},
            {'test':'Corrosive Sulfur','result':'Non-corrosive','ts':'2026-09-14T10:00:00'},
            {'test':'Tarnish Level','result':'1b','ts':'2026-09-14T10:00:00'},
            {'test':'Potentially Corrosive Sulfur (CCD)','result':'Pass','ts':'2026-09-14T10:00:00'},
        ],
        'additives':[
            {'test':'DBDS','result':'11','ts':'2026-09-14T09:00:00'},
            {'test':'Dibenzyl Disulfide (DBDS)','result':'12','ts':'2026-09-14T10:00:00'},
        ],
        'furan':[],'oil':[],'other':[],
    }
    out=_polish_report_buckets(buckets)
    assert [r['display_test'] for r in out['dga']] == ['Ethane (C2H6)','Methane (CH4)']
    assert out['paper'][0]['display_test']=='DP-value of Paper' and out['paper'][0]['result']=='742'
    assert [r['display_test'] for r in out['corrosion']] == ['Corrosive Sulfur Status','Tarnish Level','Potentially Corrosive Sulfur (CCD)']
    assert out['corrosion'][0]['result']=='Non-corrosive'
    assert out['additives'][0]['display_test']=='Dibenzyl Disulfide (DBDS)' and out['additives'][0]['result']=='12'
