import json, re
from pathlib import Path

from app.routes.control_center import _polish_report_buckets
from app.services.lab_operations import _normalize_package_test

ROOT = Path(__file__).resolve().parents[1]

def _cfg():
    text=(ROOT/'app/lab_ops/index_template.html').read_text()
    return json.loads(re.search(r"const CFG=(\{.*?\});\n", text, re.S).group(1))

def test_tan_method_is_astm_d664_everywhere_current_packages_use_it():
    cfg=_cfg()
    qdf=[r for r in cfg['qdf'] if r['test']=='Total Acid Number']
    assert qdf and all(r['method']=='ASTM D664' for r in qdf)
    for package in cfg['packages']:
        for row in package.get('tests',[]):
            if row.get('test')=='Total Acid Number':
                assert row.get('method')=='ASTM D664'
    assert _normalize_package_test({'test':'Total Acid Number','method':'ASTM D974','station':'TAN / Peroxide / RSH / H2S'})['method']=='ASTM D664'

def test_corrosive_report_does_not_conflate_astm_d130_copper_corrosion_with_d1275b_status():
    buckets={'dga':[],'furan':[],'paper':[],'oil':[],'additives':[],'corrosion':[
        {'test':'ASTM Copper Corrosion (Cu Strip)','result':'1a','method':'ASTM D130','unit':'1a–4c','ts':'1'},
        {'test':'Corrosive Sulfur','result':'Non-corrosive','method':'ASTM D1275B','unit':'Pass/Fail','ts':'2'},
        {'test':'Tarnish Level','result':'1b','method':'ASTM D1275B','unit':'','ts':'3'},
        {'test':'Potentially Corrosive Sulfur (CCD)','result':'Pass','method':'IEC 62535','unit':'Pass/Fail','ts':'4'},
    ],'other':[]}
    out=_polish_report_buckets(buckets)
    rows=out['corrosion']
    assert [r['display_test'] for r in rows]==['Corrosive Sulfur Status','Tarnish Level','Potentially Corrosive Sulfur (CCD)']
    assert rows[0]['method']=='ASTM D1275B' and rows[1]['method']=='ASTM D1275B' and rows[2]['method']=='IEC 62535'

def test_navigation_uses_professional_text_icons_and_no_mobile_arrow_for_improvement():
    base=(ROOT/'app/templates/base.html').read_text()
    assert "'Improvement Proposal','CI'" in base
    assert "'Continuous Improvement','CI'" in base
    assert "'↗'" not in base

def test_improvement_and_organization_pages_have_no_decorative_arrow_glyphs():
    improvement=(ROOT/'app/templates/improvement.html').read_text()
    organization=(ROOT/'app/templates/organization.html').read_text()
    assert 'SUBMIT →' not in improvement and '<i>→</i>' not in improvement
    assert 'Business role → platform workspace' not in organization


def test_direct_paper_dp_remains_independent_from_furan_workstation():
    from app.services.lab_operations import _normalize_package_test, _station_from_name
    assert _station_from_name('Direct DP-value') == 'Paper DP / Furan'
    row=_normalize_package_test({'test':'Direct DP-value','method':'IEC 60450','station':'Paper DP / Furan'})
    assert row['station']=='Paper DP / Furan' and row['method']=='IEC 60450'
    html=Path('app/lab_ops/index_template.html').read_text()
    assert '"Direct DP-value","method":"IEC 60450","station":"Paper DP / Furan"' in html


def test_internal_report_places_direct_paper_and_corrosion_in_one_diagnostic_panel():
    html=Path('app/lab_ops/index_template.html').read_text()
    assert "return'Paper / Corrosive Diagnostics'" in html
    assert "'Direct Paper Test'" not in html
    assert "'Corrosive Sulfur / CCD'" not in html.split('function reportGroupName',1)[1].split('function reportSheet',1)[0]


def test_sidebar_uses_professional_text_markers_not_decorative_symbol_icons():
    base=Path('app/templates/base.html').read_text()
    for symbol in ('↗','▦','⌂','⌘','◌','♙','▨','⬡','▣','⚗','⇄','⇆','⇧','⌁'):
        assert symbol not in base
    improvement=Path('app/templates/improvement.html').read_text()
    assert '→' not in improvement
    assert 'Improvement Proposal' in base

def test_professional_ui_language_and_visual_glyph_guard():
    role_matrix=Path('app/role_matrix.py').read_text()
    improvement=Path('app/templates/improvement.html').read_text()
    welcome=Path('app/templates/welcome.html').read_text()
    handover=Path('app/templates/operations_handover.html').read_text()
    assert 'Submit Improvement Opportunity' not in role_matrix
    assert 'Improvement Proposal' in role_matrix
    assert '<h1>Improvement Opportunity</h1>' not in improvement
    assert 'Arial,sans-serif' not in welcome
    assert '<i>→</i>' not in handover
