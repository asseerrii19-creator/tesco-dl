# TSCO Digital Laboratory Platform - Master Requirements Traceability Closeout

Status: **v2.8.4 FINAL HANDOVER BASELINE — IMPLEMENTATION COMPLETE**  
Project: **00012 - TSCO Digital Laboratory Platform**  
Rule: the latest confirmed project decision supersedes conflicting older wording. Department review may change configuration/master data, but no known project requirement is intentionally left as an unbuilt placeholder in this review package.

| Area | Final implemented review behavior | Status |
|---|---|---|
| Unified login / RBAC / site scope | One secure sign-in, role/site/client-scoped workspaces and direct-URL enforcement | Implemented + regression tested |
| End-to-end Communication Flow | Lead Generation -> Quotation -> Proposal -> Client Follow-up -> Purchase Order -> PO Received -> Complete Handover -> Client Coordination -> Sampling -> Sample Delivery -> Testing -> Review -> Report Approval -> LMS Report Release -> Report Submission -> Invoicing -> Payment Collection | Implemented + controlled state machine |
| Commercial handover | Quotation + PO + Commercial/Technical/Client handover evidence bind business cases to operations; operational/lab stages synchronize from authoritative sampling/sample/LMS records rather than manual status skipping | Implemented + server enforced |
| Sample origin | `TSCO Field-Sampled` vs `Client-Originated / Direct Delivery` stored separately from sampling point | Implemented |
| Sampling points | Main Tank / Bottom; Tap Changer 1/2/3/H1/H2/H3; Cable Box H1/H2/H3/Y/R/N/B; Other | Implemented + configurable per Asset Master |
| Serial-first Asset Master | Static transformer identity plus expanded QDF report fields: HV/LV, sealing, cooling, country/year, oil, owner, TC, tag, phase, operating period, configured sampling points | Implemented |
| Asset history | Fluid treatment/replacement, tap-changer maintenance, supplement, repair/modification, observations and report reference | Implemented |
| Sample labels | TSCO barcode/label generation and reprint capability retained | Implemented |
| Intake / receiving / distribution | Data Review -> LMS registration -> Physical Receiving -> Batch & Distribution -> Laboratory | Implemented |
| Priority / TAT | NORMAL/HIGH/URGENT; 12H/24H/exact due fields on direct intake; due-time propagated from field sampling orders | Implemented; final SLA policy configurable |
| Analytical batches | Client request package remains separate from analytical Test + Method + Workstation execution | Implemented |
| Chemist workspace | Assigned/qualified workstation access, Start/Continue workflow, contextual methods/quick guidance | Implemented |
| Competency gate | Skill/competence records; 75% technical + 25% data processing; 91-100 Independent, 75-90 Supervised, below 75 Failed; configured benches enforce authorization | Implemented + server enforced |
| Staff availability gate | Approved/confirmed leave/holiday prevents current analytical assignment | Implemented |
| Senior supervision | Technical review, retest/resample, workload/retained-sample oversight and responsibility-scoped supervision; Senior cannot perform final LMS/report release | Implemented + role enforced |
| Chemist QC workspace | Chemist sees only personal current-month QC / Validation tasks; no global QC governance, future months or out-of-sequence routine windows; exact Equipment ID required where controlled asset exists | Implemented + server enforced |
| QC governance | Quality / Continuous Improvement owns monthly Primary + Backup distribution, rotations, equipment/safety/material controls and review/closure | Implemented |
| Equipment | EQ asset master, method/workstation, status, provider/certificate, calibration/verification due dates, QC/calibration/maintenance/failure timeline | Implemented |
| Equipment blocking | Failed/out-of-tolerance equipment becomes OUT_OF_SERVICE; configured workstation assignment requires in-service calibration-valid equipment | Implemented + server enforced |
| Validation / Verification | Quality creates test+method+equipment task, assigns employee, employee submits raw runs/evidence, platform calculates basic repeatability statistics, Quality reviews/closes | Implemented |
| ILC / PT | Scheme, criteria, assignment, evidence and controlled closeout | Implemented; final planning-cycle rule configurable |
| NCR / CAPA | Unique case, root cause, corrective action, responsibility/due date, effectiveness and closure gate | Implemented + closure validation |
| Controlled documents | Method/SOP/EOP/spec revisions and contextual links retained | Implemented |
| Troubleshooting | Employee submit -> Senior Verified -> Technical Manager Approved/Published; test/method/equipment/workstation and integrity/safety context | Implemented + transition enforcement |
| Result entry | Sample-centric existing laboratory result architecture retained | Implemented |
| LTD terminology | Canonical new-record state is `LTD`; legacy LDT/LDL input normalizes to LTD | Implemented + tested |
| Confirmed DL rules | Furan 2FAL 0.01 mg/kg; TAN 0.010 mg KOH/g; applicable DGA gases 1 ppm; below confirmed DL -> LTD | Implemented + seeded controlled Result Rules |
| Furan LTD | 2FAL LTD -> Total Furan LTD -> Indirect DP >1000 -> Paper Lifetime >30 Years | Implemented + tested |
| Paper lifetime rounding | Numeric display uses whole years, half-up (.50 rounds upward); precise calculation retained internally | Implemented + tested |
| Technical Result Matrix | Relational rule register supports Test + Method + Field + Unit + Equipment + States + DL + Range + decimals + rounding + downstream/report rule + revision/source | Implemented; unknown values remain editable for Quality review rather than guessed |
| DGA offline workflow | Approved offline file path supported as Upload -> Parse -> Preview -> employee confirmation; original source hash/equipment/method/run preserved; CSV/TSV/TXT/XLSX parser recognizes 9 gases | Implemented; exact vendor-export mapping remains configurable during technical review |
| DGA evidence | Original source + chromatogram evidence types, SHA-256 and equipment snapshot | Implemented |
| Corrosive Sulfur evidence | Mandatory Front + Back controlled evidence gate before a report marked as containing Corrosive Sulfur can move READY_FOR_LMS | Implemented + tested |
| Controlled reporting | Structured report record, condition, interpretation, recommendation, asset/sampling context, evidence, asset history, previous report references and QR verification preview | Implemented |
| LMS boundary | Technical approval moves to READY_FOR_LMS only; official REPORT_RELEASED remains LMS confirmation boundary | Implemented + preserved |
| Annual Leave Planning | Employee request -> Senior -> Management annual-plan approval -> MenaME confirmation; platform is planning layer, not HR system | Implemented |
| Work patterns / Night shift | Per-employee configurable work-pattern / shift template; night roster generation respects each employee pattern, leave, holidays, training/unavailability and competency, with Senior review/approval | Implemented; final HR/management policy configurable |
| On-call / holiday | Fair roster generator, configurable staff/day, conflict rejection and audit | Implemented |
| Notifications | Role-aware in-system notifications for assigned Quality tasks, review return and LMS-ready reports; email state is explicit pending company mail configuration | Implemented; SMTP is external configuration |
| Employee activity | Management evidence summary of actions, reviews, approvals and quality/equipment work; no sample-count-only ranking | Implemented |
| Homepage / visual system | TSCO brand mark uncropped; unified typography; concise enterprise hero; engineering drafting remains outside content cards; professional text markers replace decorative emoji/mobile glyphs | Implemented + visual regression guards |
| Public / client identity | TSCO-branded public landing with analytical capability, quality/accreditation, digital reporting and asset-reliability framing | Implemented |
| QR verification | Public controlled-report verification token/QR endpoint | Implemented |
| Attachments / evidence | Business-record evidence with type, sample/case/equipment link, method, run, revision/status and SHA-256 | Implemented |
| Audit / amendments | Existing append/revision controls retained; new enterprise actions write audit events | Implemented |
| Backup / restore | Existing server backup/restore and recoverability controls retained | Implemented |
| Multi-site / client isolation / offline field | Existing hardened controls retained | Implemented + regression tested |

## Review-only configuration items

Items in `PENDING_EXTERNAL_INPUTS.md` are **not missing software modules**. They are controlled values or external interfaces that must be confirmed by Quality/HR/IT during review: revised documents, unconfirmed DL/range/precision values, exact vendor DGA export mapping, LMS API/credentials, SSO/infrastructure, HR roster rules and conflicting retention/PT-cycle source decisions.
