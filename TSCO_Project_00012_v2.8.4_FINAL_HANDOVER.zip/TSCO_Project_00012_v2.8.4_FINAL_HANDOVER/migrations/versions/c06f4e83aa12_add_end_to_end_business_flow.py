"""add end to end business communication flow and controlled month close

Revision ID: c06f4e83aa12
Revises: b95e3f27c6a1
"""
from alembic import op
import sqlalchemy as sa

revision = "c06f4e83aa12"
down_revision = "b95e3f27c6a1"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("users", sa.Column("senior_responsibility_domain", sa.String(30), nullable=False, server_default=""))
    op.create_index("ix_users_senior_responsibility_domain", "users", ["senior_responsibility_domain"])
    op.execute("UPDATE users SET senior_responsibility_domain='TECHNICAL' WHERE role='senior_chemist' AND (lower(email)='senior@tsco.local' OR lower(job_title) LIKE '%technical%')")
    op.execute("UPDATE users SET senior_responsibility_domain='EQUIPMENT' WHERE role='senior_chemist' AND (lower(email) LIKE '%maintenance%' OR lower(job_title) LIKE '%maintenance%' OR lower(job_title) LIKE '%equipment%')")
    op.execute("UPDATE users SET senior_responsibility_domain='IMPROVEMENT' WHERE role='senior_chemist' AND (lower(email) LIKE '%improvement%' OR lower(job_title) LIKE '%improvement%')")

    op.create_table(
        "commercial_cases",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("case_code", sa.String(50), nullable=False),
        sa.Column("site_id", sa.Integer(), sa.ForeignKey("sites.id"), nullable=False),
        sa.Column("client_id", sa.Integer(), sa.ForeignKey("clients.id"), nullable=False),
        sa.Column("owner_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("quotation_id", sa.Integer(), sa.ForeignKey("quotations.id"), nullable=True),
        sa.Column("purchase_order_id", sa.Integer(), sa.ForeignKey("purchase_orders.id"), nullable=True),
        sa.Column("sampling_order_id", sa.Integer(), nullable=True),
        sa.Column("sample_request_id", sa.Integer(), nullable=True),
        sa.Column("current_stage", sa.String(50), nullable=False, server_default="LEAD_GENERATION"),
        sa.Column("status", sa.String(30), nullable=False, server_default="ACTIVE"),
        sa.Column("lead_title", sa.String(220), nullable=False, server_default=""),
        sa.Column("lead_source", sa.String(120), nullable=False, server_default=""),
        sa.Column("proposal_reference", sa.String(160), nullable=False, server_default=""),
        sa.Column("client_follow_up", sa.Text(), nullable=False, server_default=""),
        sa.Column("po_received_reference", sa.String(160), nullable=False, server_default=""),
        sa.Column("handover_commercial", sa.Text(), nullable=False, server_default=""),
        sa.Column("handover_technical", sa.Text(), nullable=False, server_default=""),
        sa.Column("handover_client_info", sa.Text(), nullable=False, server_default=""),
        sa.Column("report_submission_reference", sa.String(180), nullable=False, server_default=""),
        sa.Column("invoice_number", sa.String(120), nullable=False, server_default=""),
        sa.Column("payment_reference", sa.String(120), nullable=False, server_default=""),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.Column("closed_at", sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(["sampling_order_id"], ["sampling_orders.id"], name="fk_commercial_sampling_order", use_alter=True),
        sa.ForeignKeyConstraint(["sample_request_id"], ["sample_requests.id"], name="fk_commercial_sample_request", use_alter=True),
        sa.UniqueConstraint("case_code", name="uq_commercial_cases_case_code"),
    )
    for col in ["case_code","site_id","client_id","owner_id","quotation_id","purchase_order_id","sampling_order_id","sample_request_id","current_stage","status","created_at"]:
        op.create_index(f"ix_commercial_cases_{col}", "commercial_cases", [col])

    op.create_table(
        "commercial_events",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("commercial_case_id", sa.Integer(), sa.ForeignKey("commercial_cases.id"), nullable=False),
        sa.Column("actor_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("from_stage", sa.String(50), nullable=False, server_default=""),
        sa.Column("to_stage", sa.String(50), nullable=False),
        sa.Column("note", sa.Text(), nullable=False, server_default=""),
        sa.Column("reference", sa.String(180), nullable=False, server_default=""),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    for col in ["commercial_case_id","actor_id","to_stage","created_at"]:
        op.create_index(f"ix_commercial_events_{col}", "commercial_events", [col])

    # Use batch operations so fresh SQLite UAT/test databases and PostgreSQL upgrades
    # both receive the same controlled foreign-key shape.
    with op.batch_alter_table("sampling_orders") as batch_op:
        batch_op.add_column(sa.Column("commercial_case_id", sa.Integer(), nullable=True))
        batch_op.create_foreign_key("fk_sampling_orders_commercial_case", "commercial_cases", ["commercial_case_id"], ["id"])
        batch_op.create_index("ix_sampling_orders_commercial_case_id", ["commercial_case_id"])
    with op.batch_alter_table("sample_requests") as batch_op:
        batch_op.add_column(sa.Column("commercial_case_id", sa.Integer(), nullable=True))
        batch_op.create_foreign_key("fk_sample_requests_commercial_case", "commercial_cases", ["commercial_case_id"], ["id"])
        batch_op.create_index("ix_sample_requests_commercial_case_id", ["commercial_case_id"])

    op.create_table(
        "monthly_close_periods",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("site_id", sa.Integer(), sa.ForeignKey("sites.id"), nullable=False),
        sa.Column("year", sa.Integer(), nullable=False),
        sa.Column("month", sa.Integer(), nullable=False),
        sa.Column("status", sa.String(20), nullable=False, server_default="OPEN"),
        sa.Column("archive_reference", sa.String(180), nullable=False, server_default=""),
        sa.Column("close_note", sa.Text(), nullable=False, server_default=""),
        sa.Column("closed_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("closed_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.UniqueConstraint("site_id", "year", "month", name="uq_monthly_close_site_period"),
    )
    for col in ["site_id","year","month","status"]:
        op.create_index(f"ix_monthly_close_periods_{col}", "monthly_close_periods", [col])


def downgrade():
    op.drop_table("monthly_close_periods")
    with op.batch_alter_table("sample_requests") as batch_op:
        batch_op.drop_index("ix_sample_requests_commercial_case_id")
        batch_op.drop_constraint("fk_sample_requests_commercial_case", type_="foreignkey")
        batch_op.drop_column("commercial_case_id")
    with op.batch_alter_table("sampling_orders") as batch_op:
        batch_op.drop_index("ix_sampling_orders_commercial_case_id")
        batch_op.drop_constraint("fk_sampling_orders_commercial_case", type_="foreignkey")
        batch_op.drop_column("commercial_case_id")
    op.drop_table("commercial_events")
    op.drop_table("commercial_cases")
    op.drop_index("ix_users_senior_responsibility_domain", table_name="users")
    op.drop_column("users", "senior_responsibility_domain")
