from __future__ import annotations

from datetime import datetime
from urllib.parse import quote_plus

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import (
    Asset, Client, PurchaseOrder, Quotation, Role, SamplingAssignment, SamplingOrder, SamplingRequestNotice,
    SampleRequest, SampleStatus, Site, TechnicalAssessmentRecord, User,
)
from ..security import require_user
from ..services.audit import add_audit
from ..services.identifiers import next_assignment_code, next_sampling_order_identifiers
from ..services.workflow import add_event
from ..services.lab_operations import package_catalog
from ..services.commercial import resolve_handover_case, require_complete_handover, link_sampling_order
from ..services.month_close import assert_site_period_open

router = APIRouter(prefix="/operations", tags=["sampling operations"])
ALLOWED = {Role.OPERATIONS_MANAGER.value, Role.TECHNICAL_MANAGER.value, Role.MANAGEMENT.value, Role.SYSTEM_ADMIN.value}
WRITE_ALLOWED = {Role.OPERATIONS_MANAGER.value, Role.SYSTEM_ADMIN.value}


def _validation_redirect(message: str) -> RedirectResponse:
    return RedirectResponse(f"/operations/orders?error={quote_plus(message)}", status_code=303)


def _optional_int(value: str, label: str) -> int | None:
    clean = (value or "").strip()
    if not clean:
        return None
    if not clean.isdigit():
        raise ValueError(f"{label} is invalid")
    return int(clean)


def _bounded(value: str, label: str, maximum: int, *, required: bool = False) -> str:
    clean = (value or "").strip()
    if required and not clean:
        raise ValueError(f"{label} is required")
    if len(clean) > maximum:
        raise ValueError(f"{label} must be {maximum} characters or fewer")
    return clean


@router.get("/orders")
def orders_dashboard(request: Request, error: str = "", request_id: int | None = None, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    site_id = user.site_id
    orders_stmt = select(SamplingOrder).order_by(SamplingOrder.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and site_id:
        orders_stmt = orders_stmt.where(SamplingOrder.site_id == site_id)
    orders = db.scalars(orders_stmt.limit(100)).all()
    clients = db.scalars(select(Client).where(Client.active.is_(True)).order_by(Client.name)).all()
    quotes = db.scalars(select(Quotation).where(Quotation.status == "ACTIVE").order_by(Quotation.number)).all()
    pos = db.scalars(select(PurchaseOrder).where(PurchaseOrder.status == "ACTIVE").order_by(PurchaseOrder.number)).all()
    assets = db.scalars(select(Asset).where(Asset.active.is_(True)).order_by(Asset.asset_code)).all()
    supervisors_stmt = select(User).where(User.role == Role.SAMPLING_SUPERVISOR.value, User.active.is_(True))
    samplers_stmt = select(User).where(User.role.in_([Role.FIELD_SAMPLER.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value]), User.active.is_(True))
    if user.role != Role.SYSTEM_ADMIN.value and site_id:
        supervisors_stmt = supervisors_stmt.where(User.site_id == site_id)
        samplers_stmt = samplers_stmt.where(User.site_id == site_id)
    supervisors = db.scalars(supervisors_stmt.order_by(User.full_name)).all()
    samplers = db.scalars(samplers_stmt.order_by(User.full_name)).all()
    resample_stmt = (
        select(TechnicalAssessmentRecord)
        .join(SampleRequest, TechnicalAssessmentRecord.sample_request_id == SampleRequest.id)
        .where(
            TechnicalAssessmentRecord.decision == "RESAMPLE",
            SampleRequest.status == SampleStatus.TECHNICAL_REVIEW.value,
        )
        .order_by(TechnicalAssessmentRecord.updated_at.desc())
    )
    if user.role != Role.SYSTEM_ADMIN.value and site_id:
        resample_stmt = resample_stmt.where(SampleRequest.site_id == site_id)
    resample_records = db.scalars(resample_stmt.limit(100)).all()
    existing_resample_sources = set(
        db.scalars(select(SamplingAssignment.resample_of_sample_id).where(SamplingAssignment.resample_of_sample_id.is_not(None))).all()
    )
    pending_resamples = [record for record in resample_records if record.sample_request_id not in existing_resample_sources]
    notices_stmt = select(SamplingRequestNotice).where(SamplingRequestNotice.status == "PENDING_OPERATIONS").order_by(SamplingRequestNotice.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and site_id:
        notices_stmt = notices_stmt.where(SamplingRequestNotice.site_id == site_id)
    pending_sampling_requests = db.scalars(notices_stmt.limit(100)).all()
    selected_sampling_request = db.get(SamplingRequestNotice, request_id) if request_id else None
    if selected_sampling_request and selected_sampling_request.status != "PENDING_OPERATIONS":
        selected_sampling_request = None
    if selected_sampling_request and user.role != Role.SYSTEM_ADMIN.value and site_id and selected_sampling_request.site_id != site_id:
        selected_sampling_request = None
    return templates.TemplateResponse(
        "operations_dashboard.html",
        {
            "request": request, "user": user, "orders": orders, "clients": clients, "quotes": quotes,
            "pos": pos, "assets": assets, "supervisors": supervisors, "samplers": samplers,
            "package_names": [p["name"] for p in package_catalog(db, user.site_id)], "error": error,
            "pending_resamples": pending_resamples, "pending_sampling_requests": pending_sampling_requests,
            "selected_sampling_request": selected_sampling_request,
        },
    )


@router.get("")
def operations_overview(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    site_id = user.site_id
    order_stmt = select(SamplingOrder).order_by(SamplingOrder.created_at.desc())
    sample_stmt = select(SampleRequest).order_by(SampleRequest.created_at.desc())
    notice_stmt = select(SamplingRequestNotice).order_by(SamplingRequestNotice.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and site_id:
        order_stmt = order_stmt.where(SamplingOrder.site_id == site_id)
        sample_stmt = sample_stmt.where(SampleRequest.site_id == site_id)
        notice_stmt = notice_stmt.where(SamplingRequestNotice.site_id == site_id)
    orders = db.scalars(order_stmt.limit(300)).all()
    samples = db.scalars(sample_stmt.limit(500)).all()
    notices = db.scalars(notice_stmt.limit(200)).all()
    pending_sampling_requests = [n for n in notices if n.status == "PENDING_OPERATIONS"]
    resample_stmt = (select(TechnicalAssessmentRecord).join(SampleRequest, TechnicalAssessmentRecord.sample_request_id == SampleRequest.id).where(TechnicalAssessmentRecord.decision == "RESAMPLE", SampleRequest.status == SampleStatus.TECHNICAL_REVIEW.value).order_by(TechnicalAssessmentRecord.updated_at.desc()))
    if user.role != Role.SYSTEM_ADMIN.value and site_id:
        resample_stmt = resample_stmt.where(SampleRequest.site_id == site_id)
    resample_records = db.scalars(resample_stmt.limit(100)).all()
    existing_resample_sources = set(db.scalars(select(SamplingAssignment.resample_of_sample_id).where(SamplingAssignment.resample_of_sample_id.is_not(None))).all())
    pending_resamples = [record for record in resample_records if record.sample_request_id not in existing_resample_sources]
    assignments = [a for o in orders for a in o.assignments]
    now = datetime.utcnow()
    overdue_orders = [o for o in orders if o.due_at and o.due_at < now and o.status != "COMPLETED"]
    urgent_samples = [s for s in samples if (s.priority or "").upper() == "URGENT" and s.status != SampleStatus.REPORT_RELEASED.value]
    handoff_statuses = {SampleStatus.SUBMITTED.value, SampleStatus.ACCEPTED.value, SampleStatus.AWAITING_RECEIPT.value, SampleStatus.RECEIVED.value, SampleStatus.READY_FOR_LAB.value}
    handoff = [s for s in samples if s.status in handoff_statuses]
    metrics = {
        "requests": sum(1 for n in notices if n.status == "PENDING_OPERATIONS"),
        "orders": sum(1 for o in orders if o.status != "COMPLETED"),
        "unassigned": sum(1 for a in assignments if a.status == "UNASSIGNED"),
        "field_active": sum(1 for a in assignments if a.status in {"ASSIGNED", "IN_PROGRESS"}),
        "awaiting_intake": sum(1 for s in samples if s.status in {SampleStatus.SUBMITTED.value, SampleStatus.ACCEPTED.value, SampleStatus.AWAITING_RECEIPT.value}),
        "received": sum(1 for s in samples if s.status == SampleStatus.RECEIVED.value),
        "ready_lab": sum(1 for s in samples if s.status == SampleStatus.READY_FOR_LAB.value),
        "overdue": len(overdue_orders),
    }
    return templates.TemplateResponse("operations_overview.html", {
        "request": request, "user": user, "metrics": metrics, "orders": orders[:12], "assignments": assignments[:30],
        "handoff": handoff[:30], "overdue_orders": overdue_orders[:20], "urgent_samples": urgent_samples[:20],
        "pending_sampling_requests": pending_sampling_requests, "pending_resamples": pending_resamples,
    })


@router.get("/field-progress")
def field_progress(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED | {Role.SAMPLING_SUPERVISOR.value})
    stmt = select(SamplingOrder).order_by(SamplingOrder.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        stmt = stmt.where(SamplingOrder.site_id == user.site_id)
    orders = db.scalars(stmt.limit(300)).all()
    assignments = [a for o in orders for a in o.assignments]
    return templates.TemplateResponse("operations_field_progress.html", {"request": request, "user": user, "assignments": assignments})


@router.get("/handover")
def intake_handover(request: Request, db: Session = Depends(get_db)):
    user = require_user(request, db, ALLOWED)
    statuses = [SampleStatus.SUBMITTED.value, SampleStatus.ACCEPTED.value, SampleStatus.AWAITING_RECEIPT.value, SampleStatus.RECEIVED.value, SampleStatus.READY_FOR_LAB.value, SampleStatus.REGISTERED.value, SampleStatus.TESTING.value, SampleStatus.TECHNICAL_REVIEW.value]
    stmt = select(SampleRequest).where(SampleRequest.status.in_(statuses)).order_by(SampleRequest.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        stmt = stmt.where(SampleRequest.site_id == user.site_id)
    samples = db.scalars(stmt.limit(300)).all()
    return templates.TemplateResponse("operations_handover.html", {"request": request, "user": user, "samples": samples})


@router.post("/orders")
def create_order(
    request: Request,
    client_id: int = Form(...), quotation_id: str = Form(""), purchase_order_id: str = Form(""),
    supervisor_id: str = Form(""), title: str = Form("Sampling request"), priority: str = Form("Normal"),
    due_at: str = Form(""), notes: str = Form(""), sampling_request_id: str = Form(""), db: Session = Depends(get_db),
):
    user = require_user(request, db, WRITE_ALLOWED)
    site = db.get(Site, user.site_id) if user.site_id else db.scalar(select(Site).where(Site.code == "DMM"))
    client = db.get(Client, client_id)
    try:
        quote_id = _optional_int(quotation_id, "Quotation")
        po_id = _optional_int(purchase_order_id, "Purchase order")
        supervisor_key = _optional_int(supervisor_id, "Sampling supervisor")
        request_notice_id = _optional_int(sampling_request_id, "Sampling request")
        clean_title = _bounded(title, "Order title", 200) or "Sampling request"
        due_value = datetime.fromisoformat(due_at) if due_at else None
    except ValueError as exc:
        return _validation_redirect(str(exc))
    quote = db.get(Quotation, quote_id) if quote_id else None
    po = db.get(PurchaseOrder, po_id) if po_id else None
    supervisor = db.get(User, supervisor_key) if supervisor_key else None
    if not site or not site.active:
        return _validation_redirect("Active operational site is required")
    try:
        assert_site_period_open(db, site.id)
    except ValueError as exc:
        return _validation_redirect(str(exc))
    if not client or not client.active:
        return _validation_redirect("Active client is required")
    if quotation_id and not quote:
        return _validation_redirect("Quotation was not found")
    if purchase_order_id and not po:
        return _validation_redirect("Purchase order was not found")
    if quote and quote.client_id != client_id:
        return _validation_redirect("Quotation does not belong to the selected client")
    if quote and quote.status != "ACTIVE":
        return _validation_redirect("Quotation is not active")
    if po and po.client_id != client_id:
        return _validation_redirect("Purchase order does not belong to the selected client")
    if po and po.status != "ACTIVE":
        return _validation_redirect("Purchase order is not active")
    if po and quote and po.quotation_id and po.quotation_id != quote.id:
        return _validation_redirect("Purchase order is linked to a different quotation")
    try:
        commercial_case = resolve_handover_case(db, site_id=site.id, client_id=client_id, quotation_id=quote_id, purchase_order_id=po_id)
        require_complete_handover(commercial_case)
    except ValueError as exc:
        return _validation_redirect(str(exc))
    if supervisor_id and not supervisor:
        return _validation_redirect("Sampling supervisor was not found")
    if supervisor and (not supervisor.active or supervisor.role != Role.SAMPLING_SUPERVISOR.value):
        return _validation_redirect("Selected user is not an active sampling supervisor")
    if supervisor and supervisor.site_id != site.id:
        return _validation_redirect("Sampling supervisor must belong to the order site")
    priority = priority.strip().title()
    if priority not in {"Normal", "High", "Urgent"}:
        return _validation_redirect("Unsupported sampling priority")
    request_notice = db.get(SamplingRequestNotice, request_notice_id) if request_notice_id else None
    if request_notice_id and not request_notice:
        return _validation_redirect("Sampling request was not found")
    if request_notice and request_notice.status != "PENDING_OPERATIONS":
        return _validation_redirect("Sampling request has already been converted/closed")
    if request_notice and (request_notice.site_id != site.id or request_notice.client_id != client_id):
        return _validation_redirect("Sampling request site/client does not match this order")
    order_number, _ = next_sampling_order_identifiers(db, site)
    order = SamplingOrder(
        order_number=order_number, site_id=site.id, client_id=client_id,
        quotation_id=quote_id,
        purchase_order_id=po_id,
        created_by_id=user.id, supervisor_id=supervisor_key,
        title=clean_title, priority=priority, due_at=due_value,
        notes=notes.strip(), status="OPEN",
    )
    db.add(order); db.flush()
    if commercial_case:
        link_sampling_order(db, commercial_case, order, user)
    if request_notice:
        request_notice.status = "CONVERTED"
        request_notice.converted_order_id = order.id
        request_notice.converted_at = datetime.utcnow()
    add_audit(db, actor=user, request=request, action="SAMPLING_ORDER_CREATED", entity_type="SamplingOrder", entity_id=order.id, summary=f"Created {order.order_number}", details={"client_id": client_id, "supervisor_id": supervisor_id})
    db.commit()
    return RedirectResponse(f"/operations/orders#order-{order.id}", status_code=303)


@router.post("/orders/{order_id}/assignments")
def add_assignment(
    order_id: int, request: Request, asset_id: str = Form(""), assigned_sampler_id: str = Form(""),
    source_party: str = Form("TSCO"), requested_package: str = Form("Routine Test"),
    sampling_point: str = Form("Main Tank Bottom"), container_count: int = Form(1), instructions: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, WRITE_ALLOWED)
    order = db.get(SamplingOrder, order_id)
    if not order:
        return RedirectResponse("/operations/orders", status_code=303)
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id and order.site_id != user.site_id:
        return _validation_redirect("Sampling order is outside your assigned site")
    if order.status == "COMPLETED":
        return _validation_redirect("Completed sampling orders cannot receive new assignments")
    source_party = source_party.strip().upper()
    if source_party not in {"TSCO", "CLIENT"}:
        return _validation_redirect("Source party must be TSCO or CLIENT")
    try:
        asset_key = _optional_int(asset_id, "Asset")
        sampler_id = _optional_int(assigned_sampler_id, "Sampler")
    except ValueError as exc:
        return _validation_redirect(str(exc))
    asset = db.get(Asset, asset_key) if asset_key else None
    sampler = db.get(User, sampler_id) if sampler_id else None
    if asset_id and not asset:
        return _validation_redirect("Asset was not found")
    if asset and (not asset.active or asset.client_id != order.client_id):
        return _validation_redirect("Asset is not active for the order client")
    if assigned_sampler_id and not sampler:
        return _validation_redirect("Sampler was not found")
    if sampler and (not sampler.active or sampler.role not in {Role.FIELD_SAMPLER.value, Role.CLIENT_SAMPLER.value, Role.CLIENT_OPERATIONS.value}):
        return _validation_redirect("Selected user is not an active sampler")
    if source_party == "CLIENT" and sampler and sampler.client_id != order.client_id:
        return _validation_redirect("Client-side sampler must belong to the order client")
    if source_party == "TSCO" and sampler and sampler.client_id is not None:
        return _validation_redirect("TSCO assignment cannot be allocated to a client-side account")
    if sampler and sampler.site_id != order.site_id:
        return _validation_redirect("Sampler and sampling order must belong to the same site")
    active_packages = {row["name"] for row in package_catalog(db, order.site_id)}
    try:
        requested_package = _bounded(requested_package, "Requested package", 120, required=True)
        sampling_point = _bounded(sampling_point, "Sampling point", 100, required=True)
    except ValueError as exc:
        return _validation_redirect(str(exc))
    if requested_package not in active_packages:
        return _validation_redirect("Requested test package is not active for the order site")
    if container_count < 1 or container_count > 100:
        return _validation_redirect("Container count must be between 1 and 100")
    assignment = SamplingAssignment(
        order_id=order.id, asset_id=asset_key, assigned_sampler_id=sampler_id,
        assignment_code=next_assignment_code(order.site), source_party=source_party,
        requested_package=requested_package, sampling_point=sampling_point, container_count=max(1, container_count),
        status="ASSIGNED" if sampler_id else "UNASSIGNED", instructions=instructions.strip(),
        assigned_at=datetime.utcnow() if sampler_id else None,
    )
    db.add(assignment); db.flush()
    add_audit(db, actor=user, request=request, action="SAMPLING_ASSIGNMENT_CREATED", entity_type="SamplingAssignment", entity_id=assignment.id, summary=f"{order.order_number} / {assignment.assignment_code}", details={"source_party": source_party, "sampler_id": sampler_id})
    db.commit()
    return RedirectResponse(f"/operations/orders#order-{order.id}", status_code=303)


@router.post("/resample/{sample_id}")
def create_resample_assignment(sample_id: int, request: Request, db: Session = Depends(get_db)):
    """Convert a Senior Chemist RESAMPLE decision into a controlled sampling order/assignment.

    Technical review requests the resample; Sampling Operations remains the authority that creates
    the replacement field work. The original analytical record is never overwritten.
    """
    user = require_user(request, db, WRITE_ALLOWED)
    sample = db.get(SampleRequest, sample_id)
    if not sample:
        return _validation_redirect("Original sample was not found")
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id and sample.site_id != user.site_id:
        return _validation_redirect("Resample request is outside your assigned site")
    assessment = db.scalar(
        select(TechnicalAssessmentRecord).where(TechnicalAssessmentRecord.sample_request_id == sample.id)
    )
    if not assessment or assessment.decision != "RESAMPLE" or sample.status != SampleStatus.TECHNICAL_REVIEW.value:
        return _validation_redirect("A current Senior Chemist RESAMPLE decision is required")
    existing = db.scalar(
        select(SamplingAssignment).where(SamplingAssignment.resample_of_sample_id == sample.id)
    )
    if existing:
        return RedirectResponse(f"/operations/orders#order-{existing.order_id}", status_code=303)

    original_assignment = sample.sampling_assignment
    original_order = original_assignment.order if original_assignment else None
    supervisor_id = original_order.supervisor_id if original_order else None
    source_party = original_assignment.source_party if original_assignment else ("CLIENT" if sample.sampler and sample.sampler.client_id else "TSCO")
    sampler = sample.sampler if sample.sampler and sample.sampler.active else None
    if source_party == "TSCO" and sampler and sampler.client_id is not None:
        sampler = None
    if source_party == "CLIENT" and sampler and sampler.client_id != sample.client_id:
        sampler = None

    order_number, _ = next_sampling_order_identifiers(db, sample.site)
    order = SamplingOrder(
        order_number=order_number, site_id=sample.site_id, client_id=sample.client_id,
        quotation_id=sample.quotation_id, purchase_order_id=sample.purchase_order_id, commercial_case_id=sample.commercial_case_id, created_by_id=user.id,
        supervisor_id=supervisor_id, title=f"Resample — {sample.request_number}", priority="High", status="OPEN",
        notes=f"Controlled resampling requested from technical assessment for {sample.request_number}.",
    )
    db.add(order); db.flush()
    assignment = SamplingAssignment(
        order_id=order.id, asset_id=sample.asset_id, assigned_sampler_id=sampler.id if sampler else None,
        assignment_code=next_assignment_code(sample.site), source_party=source_party,
        requested_package=sample.requested_package, sampling_point=sample.sampling_point,
        container_count=max(1, sample.container_count), status="ASSIGNED" if sampler else "UNASSIGNED",
        instructions=(f"RESAMPLE OF {sample.request_number}. " + (assessment.recommendation or "Follow technical assessment instructions.")).strip(),
        assigned_at=datetime.utcnow() if sampler else None, resample_of_sample_id=sample.id,
    )
    db.add(assignment); db.flush()
    add_event(
        db, sample, user, "TECHNICAL_RESAMPLE_ORDERED", sample.status,
        f"Replacement sampling order {order.order_number} / {assignment.assignment_code} created",
    )
    add_audit(
        db, actor=user, request=request, action="RESAMPLE_ASSIGNMENT_CREATED", entity_type="SamplingAssignment",
        entity_id=assignment.id, summary=f"{sample.request_number} → {order.order_number} / {assignment.assignment_code}",
        details={"original_sample_id": sample.id, "assessment_id": assessment.id, "source_party": source_party},
    )
    db.commit()
    return RedirectResponse(f"/operations/orders#order-{order.id}", status_code=303)
