from __future__ import annotations

from datetime import datetime
from fastapi import APIRouter, Depends, Form, Request, HTTPException
from fastapi.responses import RedirectResponse
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import (
    AuditLog, CompetencyRecord, Department, EquipmentAsset, EquipmentEvent, EvidenceRecord,
    ImprovementActivity, ImprovementItem, QualityCase, Role, Site, TroubleshootingRecord, User,
)
from ..responsibilities import responsibility_label, senior_responsibility, troubleshooting_domain
from ..security import require_user
from ..services.audit import add_audit
from ..services.lab_operations import get_operations_state

router = APIRouter(prefix="/improvement", tags=["continuous improvement"])
INTERNAL = {
    Role.FIELD_SAMPLER.value, Role.SAMPLING_SUPERVISOR.value, Role.OPERATIONS_MANAGER.value,
    Role.DATA_ENTRY.value, Role.SAMPLE_RECEIVING.value, Role.LAB_TECHNICIAN.value,
    Role.SENIOR_CHEMIST.value, Role.QUALITY.value, Role.TECHNICAL_MANAGER.value,
    Role.MANAGEMENT.value, Role.SALES_MARKETING.value, Role.FINANCE.value, Role.EXCELLENCE.value, Role.SYSTEM_ADMIN.value,
}
GOVERN = {Role.OPERATIONS_MANAGER.value, Role.QUALITY.value, Role.TECHNICAL_MANAGER.value, Role.EXCELLENCE.value, Role.SYSTEM_ADMIN.value}
ACTION = GOVERN | {Role.SENIOR_CHEMIST.value}
STATUSES = ["SUBMITTED", "UNDER_REVIEW", "APPROVED", "IN_PROGRESS", "VALIDATION", "IMPLEMENTED", "CLOSED", "DEFERRED"]
CATEGORIES = ["OPERATIONS", "QUALITY", "SAFETY", "DIGITALIZATION", "WORKFLOW", "DOCUMENTATION", "EQUIPMENT", "CLIENT_SERVICE", "COST", "OTHER"]

TAB_LABELS = [
    ("overview", "Overview"), ("register", "Improvement Register"), ("quality", "Quality & QC"),
    ("equipment", "Equipment & History"), ("materials", "Materials / Gases / Storage"), ("validation", "Validation / Verification"),
    ("ilc_pt", "ILC / PT"), ("capa", "NCR / CAPA"), ("competency", "Competency"),
    ("evidence", "Evidence"), ("audit", "Audit"), ("troubleshooting", "Troubleshooting Governance"),
    ("roadmap", "Project 00012 Roadmap"), ("review-model", "Department Review Model"),
]

ROADMAP = [
    ("MAR 2026", "Problem identification", "Operational observation, workflow gaps, paper dependency and sample visibility."),
    ("APR 2026", "Practical improvement concepts", "Orientation, troubleshooting support, quick references and easier technical knowledge access."),
    ("05–06 MAY", "Operational Improvement Roadmap", "Digital operational support, future dashboards, workflow tracking, LMS integration and monitoring."),
    ("24–25 MAY", "Retained sample tracking", "Receiving → storage → laboratory workflow, retention/disposal, retrieval and barcode/QR direction."),
    ("16 JUN", "Workflow prototype", "Sample tracking, priority, assignment, routing, result consolidation and supervisor visibility."),
    ("27–28 JUL", "Working web platform", "Operational web system with supervisory monitoring, laboratory workflow, quality and retained samples."),
    ("03–05 AUG", "Integrated multi-role platform", "Full Laboratory Operations expanded into the TSCO Digital Laboratory Platform and UAT architecture."),
    ("CURRENT", "Department review & controlled UAT", "Validate each department workflow, close gaps, preserve one architecture and prepare LMS/IT integration."),
]


def _site(db: Session, user) -> Site:
    site = db.get(Site, user.site_id) if user.site_id else None
    return site or db.scalar(select(Site).where(Site.code == "DMM"))


def _can_govern_improvement(user) -> bool:
    return user.role in GOVERN or (user.role == Role.SENIOR_CHEMIST.value and senior_responsibility(user) == "IMPROVEMENT")


def _allowed_tabs(user) -> set[str]:
    common = {"overview", "register", "roadmap", "review-model"}
    submit_only_roles = {Role.FIELD_SAMPLER.value, Role.SAMPLING_SUPERVISOR.value, Role.DATA_ENTRY.value, Role.SAMPLE_RECEIVING.value, Role.LAB_TECHNICIAN.value, Role.SALES_MARKETING.value, Role.FINANCE.value}
    if user.role in submit_only_roles:
        return {"register"}
    if user.role == Role.SYSTEM_ADMIN.value or user.role == Role.TECHNICAL_MANAGER.value:
        return {k for k, _ in TAB_LABELS}
    if user.role == Role.QUALITY.value:
        return common | {"quality", "equipment", "materials", "validation", "ilc_pt", "capa", "competency", "evidence", "audit", "troubleshooting"}
    if user.role == Role.EXCELLENCE.value:
        return common | {"materials", "equipment", "evidence", "audit", "troubleshooting"}
    if user.role == Role.MANAGEMENT.value:
        return common | {"quality", "equipment", "materials", "audit"}
    if user.role == Role.OPERATIONS_MANAGER.value:
        return common | {"audit"}
    if user.role == Role.SENIOR_CHEMIST.value:
        scope = senior_responsibility(user)
        if scope == "EQUIPMENT":
            return common | {"equipment", "materials", "troubleshooting", "audit"}
        if scope == "IMPROVEMENT":
            return common | {"evidence", "audit", "troubleshooting"}
        return common | {"validation", "evidence", "audit", "troubleshooting"}
    return common


def _next_code(db: Session) -> str:
    year = datetime.utcnow().year
    count = db.scalar(select(func.count()).select_from(ImprovementItem).where(ImprovementItem.code.like(f"CI-{year}-%"))) or 0
    return f"CI-{year}-{count + 1:04d}"


@router.get("")
def dashboard(request: Request, tab: str = "overview", status: str = "", db: Session = Depends(get_db)):
    user = require_user(request, db, INTERNAL)
    site = _site(db, user)
    allowed_tabs = _allowed_tabs(user)
    tab = tab if tab in allowed_tabs else ("overview" if "overview" in allowed_tabs else "register")

    stmt = select(ImprovementItem).order_by(ImprovementItem.created_at.desc())
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id:
        stmt = stmt.where((ImprovementItem.site_id == user.site_id) | (ImprovementItem.site_id.is_(None)))
    if status in STATUSES:
        stmt = stmt.where(ImprovementItem.status == status)
    submit_only = user.role in {Role.FIELD_SAMPLER.value, Role.SAMPLING_SUPERVISOR.value, Role.DATA_ENTRY.value, Role.SAMPLE_RECEIVING.value, Role.LAB_TECHNICIAN.value, Role.SALES_MARKETING.value, Role.FINANCE.value}
    if submit_only:
        stmt = stmt.where(ImprovementItem.created_by_id == user.id)
    items = db.scalars(stmt.limit(300)).all()

    staff_stmt = select(User).where(User.active.is_(True)).order_by(User.full_name)
    if user.site_id:
        staff_stmt = staff_stmt.where((User.site_id == user.site_id) | (User.site_id.is_(None)))
    staff = db.scalars(staff_stmt).all()
    departments = db.scalars(select(Department).where(Department.active.is_(True)).order_by(Department.name)).all()
    sites = db.scalars(select(Site).where(Site.active.is_(True)).order_by(Site.code)).all()
    metrics = {s: sum(1 for x in items if x.status == s) for s in STATUSES}

    equipment = db.scalars(select(EquipmentAsset).where(EquipmentAsset.site_id == site.id, EquipmentAsset.active.is_(True)).order_by(EquipmentAsset.equipment_id)).all()
    equipment_events = db.scalars(select(EquipmentEvent).join(EquipmentAsset).where(EquipmentAsset.site_id == site.id).order_by(EquipmentEvent.event_at.desc()).limit(120)).all()
    cases = db.scalars(select(QualityCase).where(QualityCase.site_id == site.id).order_by(QualityCase.created_at.desc()).limit(250)).all()
    competencies = db.scalars(select(CompetencyRecord).where(CompetencyRecord.site_id == site.id, CompetencyRecord.active.is_(True)).order_by(CompetencyRecord.created_at.desc()).limit(250)).all()
    evidence = db.scalars(select(EvidenceRecord).where(EvidenceRecord.site_id == site.id).order_by(EvidenceRecord.created_at.desc()).limit(150)).all()
    troubleshooting = db.scalars(select(TroubleshootingRecord).where(TroubleshootingRecord.site_id == site.id).order_by(TroubleshootingRecord.updated_at.desc()).limit(200)).all()
    troubleshooting_rows = [{"row": t, "domain": troubleshooting_domain(t)} for t in troubleshooting]
    audits = db.scalars(select(AuditLog).where((AuditLog.site_id == site.id) | (AuditLog.site_id.is_(None))).order_by(AuditLog.created_at.desc()).limit(150)).all()

    # Monthly routine QC is server-owned but belongs in this governance workspace, not on a chemist's broad QC page.
    _, ops_payload = get_operations_state(db, site)
    quality_distributions = sorted(ops_payload.get("qualityDistributions", []), key=lambda x: str(x.get("month", "")), reverse=True)
    current_distribution = quality_distributions[0] if quality_distributions else None
    materials_assignments = []
    if current_distribution:
        materials_assignments = [a for a in current_distribution.get("assignments", []) if str(a.get("domain", "")) == "Materials, Gases & Storage"]
    controlled_materials = list(ops_payload.get("standards", []))
    quality_events = ops_payload.get("qualityTaskEvents", [])
    quality_event_map = {}
    for ev in quality_events:
        aid = str(ev.get("assignment_id") or "")
        if aid and (aid not in quality_event_map or str(ev.get("completed_at") or "") > str(quality_event_map[aid].get("completed_at") or "")):
            quality_event_map[aid] = ev

    seniors = []
    for person in [x for x in staff if x.role == Role.SENIOR_CHEMIST.value]:
        scope = senior_responsibility(person)
        seniors.append({"person": person, "scope": scope, "label": responsibility_label(scope)})
    # Keep the responsibility model visible even when the live review database has not yet populated all demo senior accounts.
    present = {row["scope"] for row in seniors}
    for scope in ("TECHNICAL", "EQUIPMENT", "IMPROVEMENT"):
        if scope not in present:
            seniors.append({"person": None, "scope": scope, "label": responsibility_label(scope)})

    return templates.TemplateResponse(
        "improvement.html",
        {
            "request": request, "user": user, "site": site, "tab": tab, "status_filter": status, "items": items,
            "staff": staff, "departments": departments, "sites": sites, "metrics": metrics,
            "statuses": STATUSES, "categories": CATEGORIES, "manage": user.role in ACTION,
            "govern": _can_govern_improvement(user), "roadmap": ROADMAP,
            "visible_tabs": [(k, label) for k, label in TAB_LABELS if k in allowed_tabs],
            "senior_scope": senior_responsibility(user), "senior_responsibilities": seniors,
            "equipment": equipment, "equipment_events": equipment_events, "cases": cases,
            "competencies": competencies, "evidence_rows": evidence, "troubleshooting": troubleshooting, "troubleshooting_rows": troubleshooting_rows,
            "audits": audits, "quality_distribution": current_distribution, "materials_assignments": materials_assignments, "controlled_materials": controlled_materials, "quality_events": quality_events, "quality_event_map": quality_event_map,
            "submit_only": submit_only, "now": datetime.utcnow(),
        },
    )


@router.post("")
def create_item(
    request: Request,
    title: str = Form(...), problem_statement: str = Form(""), category: str = Form("OPERATIONS"),
    priority: str = Form("NORMAL"), impact_area: str = Form(""), expected_benefit: str = Form(""),
    department_id: str = Form(""), owner_id: str = Form(""), due_at: str = Form(""),
    baseline_metric: str = Form(""), baseline_value: str = Form(""), target_value: str = Form(""), metric_unit: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, INTERNAL)
    clean_title = title.strip()[:220]
    if not clean_title:
        raise ValueError("Improvement title is required")
    category = category.strip().upper()
    if category not in CATEGORIES:
        category = "OTHER"
    priority = priority.strip().upper()
    if priority not in {"LOW", "NORMAL", "HIGH", "URGENT"}:
        priority = "NORMAL"
    dep_id = int(department_id) if department_id.isdigit() else user.department_id
    own_id = int(owner_id) if owner_id.isdigit() and _can_govern_improvement(user) else None
    row = ImprovementItem(
        code=_next_code(db), site_id=user.site_id, department_id=dep_id, created_by_id=user.id, owner_id=own_id,
        title=clean_title, problem_statement=problem_statement.strip()[:6000], category=category, source="EMPLOYEE",
        priority=priority, impact_area=impact_area.strip()[:120], expected_benefit=expected_benefit.strip()[:4000],
        baseline_metric=baseline_metric.strip()[:120], baseline_value=baseline_value.strip()[:80],
        target_value=target_value.strip()[:80], metric_unit=metric_unit.strip()[:40],
        due_at=datetime.fromisoformat(due_at) if due_at else None,
    )
    db.add(row); db.flush()
    db.add(ImprovementActivity(improvement_item_id=row.id, actor_id=user.id, action="SUBMITTED", note="Improvement opportunity submitted", status_snapshot=row.status))
    add_audit(db, actor=user, request=request, action="IMPROVEMENT_SUBMITTED", entity_type="ImprovementItem", entity_id=row.id, summary=f"{row.code}: {row.title}")
    db.commit()
    return RedirectResponse("/improvement?tab=register", status_code=303)


@router.post("/{item_id}/update")
def update_item(
    item_id: int, request: Request, status: str = Form(...), owner_id: str = Form(""), due_at: str = Form(""),
    action_plan: str = Form(""), result_summary: str = Form(""), evidence_reference: str = Form(""), note: str = Form(""),
    db: Session = Depends(get_db),
):
    user = require_user(request, db, ACTION)
    row = db.get(ImprovementItem, item_id)
    if not row:
        raise ValueError("Improvement item not found")
    if user.role != Role.SYSTEM_ADMIN.value and user.site_id and row.site_id not in {None, user.site_id}:
        raise ValueError("Improvement item is outside your site scope")
    new_status = status.strip().upper()
    if new_status not in STATUSES:
        raise ValueError("Unsupported improvement status")
    is_governor = _can_govern_improvement(user)
    if not is_governor:
        if row.owner_id != user.id:
            raise HTTPException(status_code=403, detail="Only the assigned improvement owner or an improvement governor can update this item")
        if new_status not in {"IN_PROGRESS", "VALIDATION"}:
            raise HTTPException(status_code=403, detail="Assigned improvement owners can progress work to IN_PROGRESS or VALIDATION; governance closes or defers the item")
        if owner_id and int(owner_id) != user.id:
            raise HTTPException(status_code=403, detail="Assigned improvement owners cannot reassign the item")
    row.status = new_status
    if is_governor:
        row.owner_id = int(owner_id) if owner_id.isdigit() else None
    row.due_at = datetime.fromisoformat(due_at) if due_at else None
    row.action_plan = action_plan.strip()[:6000]
    row.result_summary = result_summary.strip()[:6000]
    row.evidence_reference = evidence_reference.strip()[:300]
    if new_status in {"APPROVED", "IMPLEMENTED", "CLOSED", "DEFERRED"} and not is_governor:
        raise HTTPException(status_code=403, detail="Only improvement governance can approve, implement, close or defer an item")
    if new_status == "CLOSED":
        row.closed_at = datetime.utcnow(); row.approved_by_id = user.id
    db.add(ImprovementActivity(improvement_item_id=row.id, actor_id=user.id, action="UPDATED", note=note.strip()[:4000], status_snapshot=row.status))
    add_audit(db, actor=user, request=request, action="IMPROVEMENT_UPDATED", entity_type="ImprovementItem", entity_id=row.id, summary=f"{row.code}: {row.status}")
    db.commit()
    return RedirectResponse(f"/improvement?tab=register#item-{row.id}", status_code=303)
