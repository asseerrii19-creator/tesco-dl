from __future__ import annotations

from calendar import monthrange
from datetime import datetime
from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import templates
from ..models import MonthlyClosePeriod, Role, SampleRequest, SampleStatus, Site
from ..security import require_user
from ..services.audit import add_audit

router = APIRouter(prefix="/lab/month-close", tags=["monthly close"])
VIEW = {Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value, Role.MANAGEMENT.value, Role.SYSTEM_ADMIN.value}
CLOSE = {Role.SENIOR_CHEMIST.value, Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value}
REOPEN = {Role.TECHNICAL_MANAGER.value, Role.SYSTEM_ADMIN.value}
TERMINAL = {SampleStatus.REPORT_RELEASED.value, SampleStatus.REJECTED.value}


def _site(db: Session, user):
    site = db.get(Site, user.site_id) if user.site_id else db.scalar(select(Site).where(Site.code == "DMM"))
    if not site: raise ValueError("Active site is required")
    return site


def _period_bounds(year: int, month: int):
    if month < 1 or month > 12: raise ValueError("Month must be between 1 and 12")
    start = datetime(year, month, 1)
    if month == 12: end = datetime(year + 1, 1, 1)
    else: end = datetime(year, month + 1, 1)
    return start, end


def _period_samples(db: Session, site_id: int, year: int, month: int):
    start, end = _period_bounds(year, month)
    return list(db.scalars(select(SampleRequest).where(SampleRequest.site_id==site_id, SampleRequest.created_at>=start, SampleRequest.created_at<end).order_by(SampleRequest.created_at)).all())


@router.get("")
def page(request: Request, year: int | None = None, month: int | None = None, db: Session = Depends(get_db)):
    user = require_user(request, db, VIEW)
    site = _site(db, user); now=datetime.utcnow(); year=year or now.year; month=month or now.month
    samples=_period_samples(db,site.id,year,month); blockers=[s for s in samples if s.status not in TERMINAL]
    record=db.scalar(select(MonthlyClosePeriod).where(MonthlyClosePeriod.site_id==site.id,MonthlyClosePeriod.year==year,MonthlyClosePeriod.month==month))
    periods=list(db.scalars(select(MonthlyClosePeriod).where(MonthlyClosePeriod.site_id==site.id).order_by(MonthlyClosePeriod.year.desc(),MonthlyClosePeriod.month.desc()).limit(24)).all())
    return templates.TemplateResponse("month_close.html",{"request":request,"user":user,"site":site,"year":year,"month":month,"samples":samples,"blockers":blockers,"record":record,"periods":periods,"can_close":user.role in CLOSE,"can_reopen":user.role in REOPEN,"terminal":TERMINAL})


@router.post("/close")
def close_period(request:Request,year:int=Form(...),month:int=Form(...),note:str=Form(""),db:Session=Depends(get_db)):
    user=require_user(request,db,CLOSE); site=_site(db,user); start,end=_period_bounds(year,month)
    if start > datetime.utcnow(): raise ValueError("A future month cannot be closed")
    samples=_period_samples(db,site.id,year,month); blockers=[s for s in samples if s.status not in TERMINAL]
    if blockers:
        refs=", ".join(s.request_number for s in blockers[:8]); more=f" (+{len(blockers)-8} more)" if len(blockers)>8 else ""
        raise ValueError(f"Month cannot close: {len(blockers)} sample(s) are not completed / verified: {refs}{more}")
    row=db.scalar(select(MonthlyClosePeriod).where(MonthlyClosePeriod.site_id==site.id,MonthlyClosePeriod.year==year,MonthlyClosePeriod.month==month))
    if not row:
        row=MonthlyClosePeriod(site_id=site.id,year=year,month=month,status="OPEN");db.add(row);db.flush()
    if row.status=="CLOSED": return RedirectResponse(f"/lab/month-close?year={year}&month={month}",303)
    row.status="CLOSED";row.closed_by_id=user.id;row.closed_at=datetime.utcnow();row.close_note=note.strip();row.archive_reference=f"TSCO_{site.code}_{year}_{month:02d}_CLOSED"
    add_audit(db,actor=user,request=request,action="MONTHLY_CLOSE",entity_type="MonthlyClosePeriod",entity_id=row.id,summary=row.archive_reference,details={"samples":len(samples),"qc_standard_history":"PRESERVED"})
    db.commit();return RedirectResponse(f"/lab/month-close?year={year}&month={month}",303)


@router.post("/reopen")
def reopen_period(request:Request,year:int=Form(...),month:int=Form(...),reason:str=Form(...),db:Session=Depends(get_db)):
    user=require_user(request,db,REOPEN);site=_site(db,user);row=db.scalar(select(MonthlyClosePeriod).where(MonthlyClosePeriod.site_id==site.id,MonthlyClosePeriod.year==year,MonthlyClosePeriod.month==month))
    if not row or row.status!="CLOSED": raise ValueError("Closed month was not found")
    if not reason.strip(): raise ValueError("Controlled reopen reason is required")
    row.status="OPEN";row.close_note=f"REOPENED: {reason.strip()}";row.closed_by_id=None;row.closed_at=None
    add_audit(db,actor=user,request=request,action="MONTHLY_REOPEN",entity_type="MonthlyClosePeriod",entity_id=row.id,summary=f"{year}-{month:02d}",details={"reason":reason.strip()})
    db.commit();return RedirectResponse(f"/lab/month-close?year={year}&month={month}",303)
