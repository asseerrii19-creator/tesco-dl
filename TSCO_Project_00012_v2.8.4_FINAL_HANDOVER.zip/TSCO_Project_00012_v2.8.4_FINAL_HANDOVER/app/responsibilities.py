from __future__ import annotations

from .models import Role


def senior_responsibility(user) -> str:
    """Return the fixed extra-responsibility domain for a Senior Chemist.

    The employment role remains Senior Chemist; this domain only controls the additional
    cross-laboratory ownership layer requested for Technical, Equipment/Maintenance and
    Continuous Improvement work.
    """
    if not user or getattr(user, "role", "") != Role.SENIOR_CHEMIST.value:
        return ""
    explicit = (getattr(user, "senior_responsibility_domain", "") or "").strip().upper()
    if explicit in {"TECHNICAL", "EQUIPMENT", "IMPROVEMENT"}:
        return explicit
    marker = f"{getattr(user, 'job_title', '')} {getattr(user, 'email', '')}".lower()
    if any(k in marker for k in ("maintenance", "equipment")):
        return "EQUIPMENT"
    if any(k in marker for k in ("continuous improvement", "improvement")):
        return "IMPROVEMENT"
    # Existing senior@ review account is the fixed Technical responsibility slot.
    return "TECHNICAL"


def responsibility_label(scope: str) -> str:
    return {
        "TECHNICAL": "Technical Affairs · Methods · Troubleshooting",
        "EQUIPMENT": "Equipment · Maintenance · Calibration Follow-up",
        "IMPROVEMENT": "Continuous Improvement · Excellence Coordination",
    }.get(scope, "Senior Chemist")


def troubleshooting_domain(record) -> str:
    # Instrument-linked problems are owned by the Equipment/Maintenance Senior.
    # Analytical/method/workstation problems are owned by the Technical Senior.
    return "EQUIPMENT" if getattr(record, "equipment_asset_id", None) else "TECHNICAL"
