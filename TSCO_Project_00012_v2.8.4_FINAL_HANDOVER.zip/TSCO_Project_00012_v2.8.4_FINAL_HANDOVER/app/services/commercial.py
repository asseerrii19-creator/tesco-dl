from __future__ import annotations

from datetime import datetime
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import (
    CommercialCase, CommercialEvent, ControlledReport, PurchaseOrder, Quotation,
    Role, SampleRequest, SampleStatus, SamplingOrder, User,
)

# Printed TSCO Communication Flow translated into a controlled state machine.
COMMERCIAL_STAGES = [
    ("LEAD_GENERATION", "Lead Generation", "SALES & MARKETING"),
    ("QUOTATION", "Quotation", "SALES & MARKETING"),
    ("PROPOSAL", "Proposal", "SALES & MARKETING"),
    ("CLIENT_FOLLOW_UP", "Client Follow-up", "SALES & MARKETING"),
    ("PURCHASE_ORDER", "Purchase Order", "SALES & MARKETING"),
    ("PURCHASE_ORDER_RECEIVED", "Purchase Order Received", "SALES & MARKETING"),
    ("COMPLETE_HANDOVER", "Complete Handover", "SALES & MARKETING"),
    ("CLIENT_COORDINATION", "Client Coordination", "FIELD OPERATIONS & CLIENT COORDINATION"),
    ("SAMPLING", "Sampling", "FIELD OPERATIONS & CLIENT COORDINATION"),
    ("SAMPLE_DELIVERY", "Sample Delivery to Laboratory", "FIELD OPERATIONS & CLIENT COORDINATION"),
    ("TESTING", "Testing", "LABORATORY OPERATIONS"),
    ("REVIEW", "Review", "LABORATORY OPERATIONS"),
    ("REPORT_APPROVAL", "Report Approval", "LABORATORY OPERATIONS"),
    ("REPORT_RELEASE", "Report Release", "LABORATORY OPERATIONS"),
    ("REPORT_SUBMISSION", "Report Submission to Client", "CLIENT & COMMERCIAL CLOSURE"),
    ("INVOICING", "Invoicing", "CLIENT & COMMERCIAL CLOSURE"),
    ("PAYMENT_COLLECTION", "Payment Collection", "CLIENT & COMMERCIAL CLOSURE"),
    ("CLOSED", "Closed", "CLIENT & COMMERCIAL CLOSURE"),
]
STAGE_KEYS = [x[0] for x in COMMERCIAL_STAGES]
STAGE_LABELS = {k: label for k, label, _ in COMMERCIAL_STAGES}
STAGE_LANES = {k: lane for k, _, lane in COMMERCIAL_STAGES}

SALES_STAGES = {
    "LEAD_GENERATION", "QUOTATION", "PROPOSAL", "CLIENT_FOLLOW_UP",
    "PURCHASE_ORDER", "PURCHASE_ORDER_RECEIVED", "COMPLETE_HANDOVER",
}
OPS_STAGES = {"CLIENT_COORDINATION", "SAMPLING", "SAMPLE_DELIVERY"}
LAB_STAGES = {"TESTING", "REVIEW", "REPORT_APPROVAL", "REPORT_RELEASE"}
FINANCE_STAGES = {"REPORT_SUBMISSION", "INVOICING", "PAYMENT_COLLECTION", "CLOSED"}


def stage_index(stage: str) -> int:
    try:
        return STAGE_KEYS.index(stage)
    except ValueError:
        return 0


def next_stage(stage: str) -> str | None:
    idx = stage_index(stage)
    return STAGE_KEYS[idx + 1] if idx + 1 < len(STAGE_KEYS) else None


def role_can_transition(user: User, target_stage: str) -> bool:
    if user.role == Role.SYSTEM_ADMIN.value:
        return True
    if target_stage in SALES_STAGES:
        return user.role == Role.SALES_MARKETING.value
    # Operational / laboratory stages are never manually advanced from the
    # communication-flow page. They synchronize from the authoritative
    # Sampling Order / Sample / Review / LMS lifecycle.
    if target_stage in OPS_STAGES or target_stage in LAB_STAGES:
        return False
    if target_stage == "REPORT_SUBMISSION":
        return user.role in {Role.SALES_MARKETING.value, Role.CLIENT_OPERATIONS.value}
    if target_stage in {"INVOICING", "PAYMENT_COLLECTION", "CLOSED"}:
        return user.role == Role.FINANCE.value
    return False


def _sample_stage(sample: SampleRequest | None) -> str | None:
    if not sample:
        return None
    mapping = {
        SampleStatus.SUBMITTED.value: "SAMPLING",
        SampleStatus.ACCEPTED.value: "SAMPLING",
        SampleStatus.AWAITING_RECEIPT.value: "SAMPLING",
        SampleStatus.IN_TRANSIT.value: "SAMPLING",
        SampleStatus.RECEIVED.value: "SAMPLE_DELIVERY",
        SampleStatus.READY_FOR_LAB.value: "SAMPLE_DELIVERY",
        SampleStatus.REGISTERED.value: "SAMPLE_DELIVERY",
        SampleStatus.TESTING.value: "TESTING",
        SampleStatus.TECHNICAL_REVIEW.value: "REVIEW",
        SampleStatus.REPORT_APPROVED.value: "REPORT_APPROVAL",
        SampleStatus.READY_FOR_LMS.value: "REPORT_APPROVAL",
        SampleStatus.REPORT_RELEASED.value: "REPORT_RELEASE",
    }
    return mapping.get(sample.status)


def effective_stage(db: Session, case: CommercialCase) -> str:
    """Return the furthest trustworthy stage without allowing manual skipping.

    Operational stages are derived from linked order/sample state, so the business case
    stays synchronized with the actual sample lifecycle instead of duplicating status.
    Post-release commercial closure remains explicitly controlled on the case.
    """
    base = case.current_stage or "LEAD_GENERATION"
    if stage_index(base) >= stage_index("REPORT_SUBMISSION"):
        return base
    sample = case.sample_request or (db.get(SampleRequest, case.sample_request_id) if case.sample_request_id else None)
    derived = _sample_stage(sample)
    if derived and stage_index(derived) > stage_index(base):
        return derived
    if case.sampling_order_id and stage_index(base) < stage_index("SAMPLING"):
        return "SAMPLING"
    return base


def add_commercial_event(
    db: Session, case: CommercialCase, actor: User | None, to_stage: str,
    *, note: str = "", reference: str = "", from_stage: str | None = None,
) -> CommercialEvent:
    event = CommercialEvent(
        commercial_case_id=case.id,
        actor_id=actor.id if actor else None,
        from_stage=from_stage if from_stage is not None else (case.current_stage or ""),
        to_stage=to_stage,
        note=(note or "").strip(), reference=(reference or "").strip(),
    )
    db.add(event)
    return event


def advance_case(
    db: Session, case: CommercialCase, actor: User, *, target_stage: str,
    note: str = "", reference: str = "", quotation_number: str = "",
    purchase_order_number: str = "", handover_commercial: str = "",
    handover_technical: str = "", handover_client_info: str = "",
) -> None:
    current = effective_stage(db, case)
    expected = next_stage(current)
    if target_stage != expected:
        raise ValueError(f"Next required stage is {STAGE_LABELS.get(expected, expected or 'complete')}; stages cannot be skipped")
    if not role_can_transition(actor, target_stage):
        raise ValueError(f"{STAGE_LABELS[target_stage]} is not an action for the active role")

    ref = (reference or "").strip()
    text = (note or "").strip()

    if target_stage == "QUOTATION":
        number = (quotation_number or ref).strip()
        if not number:
            raise ValueError("Quotation number is required")
        quote = db.scalar(select(Quotation).where(Quotation.client_id == case.client_id, Quotation.number == number))
        if not quote:
            quote = Quotation(client_id=case.client_id, number=number, status="ACTIVE", description=case.lead_title)
            db.add(quote); db.flush()
        case.quotation_id = quote.id
        ref = number
    elif target_stage == "PROPOSAL":
        if not ref:
            raise ValueError("Proposal reference is required")
        case.proposal_reference = ref
    elif target_stage == "CLIENT_FOLLOW_UP":
        if not text:
            raise ValueError("Client follow-up note is required")
        case.client_follow_up = text
    elif target_stage == "PURCHASE_ORDER":
        number = (purchase_order_number or ref).strip()
        if not number:
            raise ValueError("Purchase order number is required")
        if not case.quotation_id:
            raise ValueError("Quotation must be completed before purchase order")
        po = db.scalar(select(PurchaseOrder).where(PurchaseOrder.client_id == case.client_id, PurchaseOrder.number == number))
        if not po:
            po = PurchaseOrder(client_id=case.client_id, quotation_id=case.quotation_id, number=number, status="PENDING_RECEIPT")
            db.add(po); db.flush()
        case.purchase_order_id = po.id
        ref = number
    elif target_stage == "PURCHASE_ORDER_RECEIVED":
        if not case.purchase_order_id:
            raise ValueError("Purchase order must exist before receipt confirmation")
        po = db.get(PurchaseOrder, case.purchase_order_id)
        if po:
            po.status = "ACTIVE"
        case.po_received_reference = ref or (po.number if po else "")
    elif target_stage == "COMPLETE_HANDOVER":
        c = handover_commercial.strip(); t = handover_technical.strip(); ci = handover_client_info.strip()
        if not (c and t and ci):
            raise ValueError("Complete Handover requires Commercial, Technical and Client Information")
        case.handover_commercial, case.handover_technical, case.handover_client_info = c, t, ci
    elif target_stage == "REPORT_SUBMISSION":
        if not ref:
            raise ValueError("Client submission reference is required")
        case.report_submission_reference = ref
    elif target_stage == "INVOICING":
        if not ref:
            raise ValueError("Invoice number is required")
        case.invoice_number = ref
    elif target_stage == "PAYMENT_COLLECTION":
        if not ref:
            raise ValueError("Payment reference is required")
        case.payment_reference = ref
    elif target_stage == "CLOSED":
        case.status = "CLOSED"
        case.closed_at = datetime.utcnow()

    add_commercial_event(db, case, actor, target_stage, note=text, reference=ref, from_stage=current)
    case.current_stage = target_stage
    case.updated_at = datetime.utcnow()


def resolve_handover_case(db: Session, *, site_id: int, client_id: int, quotation_id: int | None, purchase_order_id: int | None) -> CommercialCase | None:
    if not purchase_order_id:
        return None
    stmt = select(CommercialCase).where(
        CommercialCase.site_id == site_id,
        CommercialCase.client_id == client_id,
        CommercialCase.purchase_order_id == purchase_order_id,
        CommercialCase.status == "ACTIVE",
    ).order_by(CommercialCase.created_at.desc())
    case = db.scalar(stmt)
    if case and quotation_id and case.quotation_id and case.quotation_id != quotation_id:
        raise ValueError("Commercial handover quotation does not match the selected quotation")
    return case


def require_complete_handover(case: CommercialCase | None) -> None:
    if not case:
        return
    if stage_index(case.current_stage) < stage_index("COMPLETE_HANDOVER"):
        raise ValueError("Commercial case must complete Purchase Order receipt and Complete Handover before operations begin")


def link_sampling_order(db: Session, case: CommercialCase, order: SamplingOrder, actor: User | None = None) -> None:
    require_complete_handover(case)
    case.sampling_order_id = order.id
    order.commercial_case_id = case.id
    current = effective_stage(db, case)
    if stage_index(current) < stage_index("CLIENT_COORDINATION"):
        add_commercial_event(db, case, actor, "CLIENT_COORDINATION", note="Operations accepted commercial handover", from_stage=current)
        case.current_stage = "CLIENT_COORDINATION"
    if stage_index(case.current_stage) < stage_index("SAMPLING"):
        add_commercial_event(db, case, actor, "SAMPLING", note=f"Sampling order {order.order_number} linked", reference=order.order_number, from_stage=case.current_stage)
        case.current_stage = "SAMPLING"


def link_sample(db: Session, case: CommercialCase, sample: SampleRequest, actor: User | None = None) -> None:
    case.sample_request_id = sample.id
    sample.commercial_case_id = case.id
    case.updated_at = datetime.utcnow()
    # Stage itself is derived from the actual SampleStatus; event adds audit context only.
    derived = _sample_stage(sample)
    if derived and stage_index(derived) > stage_index(case.current_stage):
        add_commercial_event(db, case, actor, derived, note=f"Sample {sample.request_number} linked to business case", reference=sample.request_number, from_stage=case.current_stage)
        case.current_stage = derived


def sync_case_from_sample(db: Session, sample: SampleRequest, actor: User | None = None, note: str = "") -> CommercialCase | None:
    if not sample.commercial_case_id:
        return None
    case = db.get(CommercialCase, sample.commercial_case_id)
    if not case:
        return None
    derived = _sample_stage(sample)
    if derived and stage_index(derived) > stage_index(case.current_stage) and stage_index(case.current_stage) < stage_index("REPORT_SUBMISSION"):
        add_commercial_event(db, case, actor, derived, note=note or f"Operational lifecycle reached {STAGE_LABELS[derived]}", reference=sample.request_number, from_stage=case.current_stage)
        case.current_stage = derived
        case.updated_at = datetime.utcnow()
    return case
