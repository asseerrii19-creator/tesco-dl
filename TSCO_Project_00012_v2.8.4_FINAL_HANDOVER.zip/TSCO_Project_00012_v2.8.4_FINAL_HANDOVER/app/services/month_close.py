from __future__ import annotations
from datetime import datetime
from sqlalchemy import select
from sqlalchemy.orm import Session
from ..models import MonthlyClosePeriod, SampleRequest


def closed_period(db: Session, site_id: int, when: datetime) -> MonthlyClosePeriod | None:
    return db.scalar(select(MonthlyClosePeriod).where(
        MonthlyClosePeriod.site_id == site_id,
        MonthlyClosePeriod.year == when.year,
        MonthlyClosePeriod.month == when.month,
        MonthlyClosePeriod.status == "CLOSED",
    ))


def assert_site_period_open(db: Session, site_id: int, when: datetime | None = None) -> None:
    when = when or datetime.utcnow()
    row = closed_period(db, site_id, when)
    if row:
        raise ValueError(f"{when.year}-{when.month:02d} is a closed operational archive; use controlled Monthly Close to reopen it before editing")


def assert_sample_period_open(db: Session, sample: SampleRequest) -> None:
    when = sample.created_at or sample.sample_date_time or datetime.utcnow()
    assert_site_period_open(db, sample.site_id, when)
