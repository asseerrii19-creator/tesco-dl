from __future__ import annotations

from datetime import datetime
from enum import Enum

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


class Role(str, Enum):
    FIELD_SAMPLER = "field_sampler"
    CLIENT_SAMPLER = "client_sampler"
    CLIENT_OPERATIONS = "client_operations"
    SAMPLING_SUPERVISOR = "sampling_supervisor"
    OPERATIONS_MANAGER = "operations_manager"
    DATA_ENTRY = "data_entry"
    SAMPLE_RECEIVING = "sample_receiving"
    LAB_TECHNICIAN = "lab_technician"
    SENIOR_CHEMIST = "senior_chemist"
    QUALITY = "quality"
    TECHNICAL_MANAGER = "technical_manager"
    MANAGEMENT = "management"
    SALES_MARKETING = "sales_marketing"
    FINANCE = "finance"
    EXCELLENCE = "excellence"
    CLIENT = "client"
    SYSTEM_ADMIN = "system_admin"


class SampleStatus(str, Enum):
    DRAFT = "DRAFT"
    SUBMITTED = "SUBMITTED"
    RETURNED = "RETURNED"
    REJECTED = "REJECTED"
    ACCEPTED = "ACCEPTED"
    AWAITING_RECEIPT = "AWAITING_RECEIPT"
    IN_TRANSIT = "IN_TRANSIT"
    RECEIVED = "RECEIVED"
    READY_FOR_LAB = "READY_FOR_LAB"
    REGISTERED = "REGISTERED"
    TESTING = "TESTING"
    TECHNICAL_REVIEW = "TECHNICAL_REVIEW"
    REPORT_APPROVED = "REPORT_APPROVED"
    READY_FOR_LMS = "READY_FOR_LMS"
    REPORT_RELEASED = "REPORT_RELEASED"


class Site(Base):
    __tablename__ = "sites"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(12), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(120))
    laboratory_name: Mapped[str] = mapped_column(String(160))
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class IdentifierSequence(Base):
    __tablename__ = "identifier_sequences"
    id: Mapped[int] = mapped_column(primary_key=True)
    namespace: Mapped[str] = mapped_column(String(40), index=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    year: Mapped[str] = mapped_column(String(4), index=True)
    current_value: Mapped[int] = mapped_column(Integer, default=0)
    site: Mapped[Site] = relationship()
    __table_args__ = (UniqueConstraint("namespace", "site_id", "year", name="uq_identifier_sequence_scope"),)


class Client(Base):
    __tablename__ = "clients"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(24), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    contact_email: Mapped[str] = mapped_column(String(180), default="")
    contact_phone: Mapped[str] = mapped_column(String(60), default="")
    notes: Mapped[str] = mapped_column(Text, default="")
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class Department(Base):
    __tablename__ = "departments"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    code: Mapped[str] = mapped_column(String(40), index=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    site: Mapped[Site | None] = relationship()
    __table_args__ = (UniqueConstraint("site_id", "code", name="uq_department_site_code"),)


class ClientUnit(Base):
    __tablename__ = "client_units"
    id: Mapped[int] = mapped_column(primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    parent_id: Mapped[int | None] = mapped_column(ForeignKey("client_units.id"), nullable=True, index=True)
    unit_type: Mapped[str] = mapped_column(String(40), default="SITE", index=True)
    code: Mapped[str] = mapped_column(String(80), index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    client: Mapped[Client] = relationship()
    parent: Mapped["ClientUnit | None"] = relationship(remote_side="ClientUnit.id")
    __table_args__ = (UniqueConstraint("client_id", "code", name="uq_client_unit_code"),)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(180), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(160))
    password_hash: Mapped[str] = mapped_column(String(300))
    role: Mapped[str] = mapped_column(String(40), index=True)
    job_title: Mapped[str] = mapped_column(String(120), default="")
    senior_responsibility_domain: Mapped[str] = mapped_column(String(30), default="", index=True)
    phone: Mapped[str] = mapped_column(String(60), default="")
    client_id: Mapped[int | None] = mapped_column(ForeignKey("clients.id"), nullable=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True)
    department_id: Mapped[int | None] = mapped_column(ForeignKey("departments.id"), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    must_change_password: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    client: Mapped[Client | None] = relationship(foreign_keys=[client_id])
    site: Mapped[Site | None] = relationship()
    department: Mapped["Department | None"] = relationship()
    client_assignments: Mapped[list["UserClientAssignment"]] = relationship(
        back_populates="user", cascade="all, delete-orphan", foreign_keys="UserClientAssignment.user_id"
    )
    client_unit_assignments: Mapped[list["UserClientUnitAssignment"]] = relationship(
        back_populates="user", cascade="all, delete-orphan", foreign_keys="UserClientUnitAssignment.user_id"
    )


class UserClientAssignment(Base):
    __tablename__ = "user_client_assignments"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    user: Mapped[User] = relationship(back_populates="client_assignments", foreign_keys=[user_id])
    client: Mapped[Client] = relationship()
    __table_args__ = (UniqueConstraint("user_id", "client_id", name="uq_user_client_assignment"),)




class UserClientUnitAssignment(Base):
    __tablename__ = "user_client_unit_assignments"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    client_unit_id: Mapped[int] = mapped_column(ForeignKey("client_units.id"), index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    user: Mapped[User] = relationship(back_populates="client_unit_assignments", foreign_keys=[user_id])
    client_unit: Mapped[ClientUnit] = relationship()
    __table_args__ = (UniqueConstraint("user_id", "client_unit_id", name="uq_user_client_unit_assignment"),)


class Quotation(Base):
    __tablename__ = "quotations"
    id: Mapped[int] = mapped_column(primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    number: Mapped[str] = mapped_column(String(80), index=True)
    status: Mapped[str] = mapped_column(String(30), default="ACTIVE")
    description: Mapped[str] = mapped_column(String(240), default="")
    client: Mapped[Client] = relationship()
    __table_args__ = (UniqueConstraint("client_id", "number", name="uq_quote_client_number"),)


class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"
    id: Mapped[int] = mapped_column(primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    quotation_id: Mapped[int | None] = mapped_column(ForeignKey("quotations.id"), nullable=True)
    number: Mapped[str] = mapped_column(String(80), index=True)
    status: Mapped[str] = mapped_column(String(30), default="ACTIVE")
    client: Mapped[Client] = relationship()
    quotation: Mapped[Quotation | None] = relationship()
    __table_args__ = (UniqueConstraint("client_id", "number", name="uq_po_client_number"),)



class CommercialCase(Base):
    """End-to-end business communication case.

    This record spans the business journey before and after the laboratory sample
    lifecycle. Sampling/laboratory data remain in their dedicated tables and are
    linked here instead of duplicated.
    """
    __tablename__ = "commercial_cases"
    id: Mapped[int] = mapped_column(primary_key=True)
    case_code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    owner_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    quotation_id: Mapped[int | None] = mapped_column(ForeignKey("quotations.id"), nullable=True, index=True)
    purchase_order_id: Mapped[int | None] = mapped_column(ForeignKey("purchase_orders.id"), nullable=True, index=True)
    sampling_order_id: Mapped[int | None] = mapped_column(ForeignKey("sampling_orders.id", use_alter=True, name="fk_commercial_sampling_order"), nullable=True, index=True)
    sample_request_id: Mapped[int | None] = mapped_column(ForeignKey("sample_requests.id", use_alter=True, name="fk_commercial_sample_request"), nullable=True, index=True)
    current_stage: Mapped[str] = mapped_column(String(50), default="LEAD_GENERATION", index=True)
    status: Mapped[str] = mapped_column(String(30), default="ACTIVE", index=True)

    lead_title: Mapped[str] = mapped_column(String(220), default="")
    lead_source: Mapped[str] = mapped_column(String(120), default="")
    proposal_reference: Mapped[str] = mapped_column(String(160), default="")
    client_follow_up: Mapped[str] = mapped_column(Text, default="")
    po_received_reference: Mapped[str] = mapped_column(String(160), default="")
    handover_commercial: Mapped[str] = mapped_column(Text, default="")
    handover_technical: Mapped[str] = mapped_column(Text, default="")
    handover_client_info: Mapped[str] = mapped_column(Text, default="")
    report_submission_reference: Mapped[str] = mapped_column(String(180), default="")
    invoice_number: Mapped[str] = mapped_column(String(120), default="")
    payment_reference: Mapped[str] = mapped_column(String(120), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    site: Mapped[Site] = relationship(foreign_keys=[site_id])
    client: Mapped[Client] = relationship(foreign_keys=[client_id])
    owner: Mapped[User | None] = relationship(foreign_keys=[owner_id])
    quotation: Mapped[Quotation | None] = relationship(foreign_keys=[quotation_id])
    purchase_order: Mapped[PurchaseOrder | None] = relationship(foreign_keys=[purchase_order_id])
    sampling_order: Mapped["SamplingOrder | None"] = relationship(foreign_keys=[sampling_order_id], post_update=True)
    sample_request: Mapped["SampleRequest | None"] = relationship(foreign_keys=[sample_request_id], post_update=True)
    events: Mapped[list["CommercialEvent"]] = relationship(back_populates="case", cascade="all, delete-orphan")


class CommercialEvent(Base):
    __tablename__ = "commercial_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    commercial_case_id: Mapped[int] = mapped_column(ForeignKey("commercial_cases.id"), index=True)
    actor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    from_stage: Mapped[str] = mapped_column(String(50), default="")
    to_stage: Mapped[str] = mapped_column(String(50), index=True)
    note: Mapped[str] = mapped_column(Text, default="")
    reference: Mapped[str] = mapped_column(String(180), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    case: Mapped[CommercialCase] = relationship(back_populates="events")
    actor: Mapped[User | None] = relationship(foreign_keys=[actor_id])


class Asset(Base):
    __tablename__ = "assets"
    id: Mapped[int] = mapped_column(primary_key=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    client_unit_id: Mapped[int | None] = mapped_column(ForeignKey("client_units.id"), nullable=True, index=True)
    asset_code: Mapped[str] = mapped_column(String(80), index=True)
    serial_number: Mapped[str] = mapped_column(String(120), index=True)
    equipment_type: Mapped[str] = mapped_column(String(80), default="Transformer")
    manufacturer: Mapped[str] = mapped_column(String(120), default="")
    voltage_kv: Mapped[float | None] = mapped_column(Float, nullable=True)
    rated_mva: Mapped[float | None] = mapped_column(Float, nullable=True)
    hv_voltage_kv: Mapped[float | None] = mapped_column(Float, nullable=True)
    lv_voltage_kv: Mapped[float | None] = mapped_column(Float, nullable=True)
    sealing_system: Mapped[str] = mapped_column(String(100), default="")
    cooling_type: Mapped[str] = mapped_column(String(100), default="")
    manufacturer_country: Mapped[str] = mapped_column(String(100), default="")
    manufacture_year: Mapped[int | None] = mapped_column(Integer, nullable=True)
    oil_type: Mapped[str] = mapped_column(String(120), default="")
    oil_weight_kg: Mapped[float | None] = mapped_column(Float, nullable=True)
    owner_name: Mapped[str] = mapped_column(String(180), default="")
    tap_changer_type: Mapped[str] = mapped_column(String(100), default="")
    tap_changer_chamber: Mapped[str] = mapped_column(String(100), default="")
    tag_number: Mapped[str] = mapped_column(String(100), default="")
    phase: Mapped[str] = mapped_column(String(40), default="")
    operating_period: Mapped[str] = mapped_column(String(100), default="")
    sampling_points_json: Mapped[str] = mapped_column(Text, default="[]")
    station_name: Mapped[str] = mapped_column(String(160), default="")
    asset_location_label: Mapped[str] = mapped_column(String(200), default="")
    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    client: Mapped[Client] = relationship()
    client_unit: Mapped["ClientUnit | None"] = relationship()
    __table_args__ = (
        UniqueConstraint("client_id", "asset_code", name="uq_asset_client_code"),
    )


class SamplingRequestNotice(Base):
    __tablename__ = "sampling_request_notices"
    id: Mapped[int] = mapped_column(primary_key=True)
    request_code: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    requested_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    title: Mapped[str] = mapped_column(String(200), default="Sampling request")
    priority: Mapped[str] = mapped_column(String(30), default="Normal")
    expected_samples: Mapped[int] = mapped_column(Integer, default=1)
    target_sampling_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(30), default="PENDING_OPERATIONS", index=True)
    converted_order_id: Mapped[int | None] = mapped_column(ForeignKey("sampling_orders.id"), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    converted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    site: Mapped[Site] = relationship()
    client: Mapped[Client] = relationship()
    requested_by: Mapped[User] = relationship(foreign_keys=[requested_by_id])
    converted_order: Mapped["SamplingOrder | None"] = relationship(foreign_keys=[converted_order_id])


class SamplingOrder(Base):
    __tablename__ = "sampling_orders"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_number: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    quotation_id: Mapped[int | None] = mapped_column(ForeignKey("quotations.id"), nullable=True)
    purchase_order_id: Mapped[int | None] = mapped_column(ForeignKey("purchase_orders.id"), nullable=True)
    commercial_case_id: Mapped[int | None] = mapped_column(ForeignKey("commercial_cases.id"), nullable=True, index=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    supervisor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    title: Mapped[str] = mapped_column(String(200), default="Sampling request")
    priority: Mapped[str] = mapped_column(String(30), default="Normal")
    status: Mapped[str] = mapped_column(String(30), default="OPEN", index=True)
    due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    site: Mapped[Site] = relationship()
    client: Mapped[Client] = relationship()
    quotation: Mapped[Quotation | None] = relationship()
    purchase_order: Mapped[PurchaseOrder | None] = relationship()
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])
    supervisor: Mapped[User | None] = relationship(foreign_keys=[supervisor_id])
    assignments: Mapped[list["SamplingAssignment"]] = relationship(back_populates="order", cascade="all, delete-orphan")


class SamplingAssignment(Base):
    __tablename__ = "sampling_assignments"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("sampling_orders.id"), index=True)
    asset_id: Mapped[int | None] = mapped_column(ForeignKey("assets.id"), nullable=True, index=True)
    assigned_sampler_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    assignment_code: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    source_party: Mapped[str] = mapped_column(String(30), default="TSCO")
    requested_package: Mapped[str] = mapped_column(String(120), default="Routine Test")
    sampling_point: Mapped[str] = mapped_column(String(100), default="Main Tank Bottom")
    container_count: Mapped[int] = mapped_column(Integer, default=1)
    status: Mapped[str] = mapped_column(String(30), default="UNASSIGNED", index=True)
    instructions: Mapped[str] = mapped_column(Text, default="")
    assigned_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_sample_id: Mapped[int | None] = mapped_column(ForeignKey("sample_requests.id", use_alter=True, name="fk_assignment_completed_sample"), nullable=True)
    resample_of_sample_id: Mapped[int | None] = mapped_column(
        ForeignKey("sample_requests.id", use_alter=True, name="fk_assignment_resample_source"),
        nullable=True, unique=True, index=True,
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    order: Mapped[SamplingOrder] = relationship(back_populates="assignments")
    asset: Mapped[Asset | None] = relationship()
    assigned_sampler: Mapped[User | None] = relationship(foreign_keys=[assigned_sampler_id])


class OperationsState(Base):
    __tablename__ = "operations_states"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), unique=True, index=True)
    json_data: Mapped[str] = mapped_column(Text, default="{}")
    revision: Mapped[int] = mapped_column(Integer, default=0)
    updated_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    site: Mapped[Site] = relationship()
    updated_by: Mapped[User | None] = relationship()


class SampleRequest(Base):
    __tablename__ = "sample_requests"
    id: Mapped[int] = mapped_column(primary_key=True)
    request_number: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    public_token: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    barcode_value: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    status: Mapped[str] = mapped_column(String(40), default=SampleStatus.DRAFT.value, index=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    client_id: Mapped[int] = mapped_column(ForeignKey("clients.id"), index=True)
    quotation_id: Mapped[int | None] = mapped_column(ForeignKey("quotations.id"), nullable=True)
    purchase_order_id: Mapped[int | None] = mapped_column(ForeignKey("purchase_orders.id"), nullable=True)
    commercial_case_id: Mapped[int | None] = mapped_column(ForeignKey("commercial_cases.id"), nullable=True, index=True)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), index=True)
    sampler_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    sampling_assignment_id: Mapped[int | None] = mapped_column(ForeignKey("sampling_assignments.id"), nullable=True, index=True)
    submission_channel: Mapped[str] = mapped_column(String(30), default="TSCO_FIELD")

    sample_date_time: Mapped[datetime] = mapped_column(DateTime, index=True)
    sampling_point: Mapped[str] = mapped_column(String(100))
    requested_package: Mapped[str] = mapped_column(String(120), default="Routine Test")
    sample_origin: Mapped[str] = mapped_column(String(50), default="TSCO Field-Sampled", index=True)
    priority: Mapped[str] = mapped_column(String(20), default="NORMAL", index=True)
    required_tat: Mapped[str] = mapped_column(String(30), default="")
    due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    equipment_status: Mapped[str] = mapped_column(String(80), default="")
    sampling_reason: Mapped[str] = mapped_column(String(180), default="")
    work_order_number: Mapped[str] = mapped_column(String(100), default="")
    sap_number: Mapped[str] = mapped_column(String(100), default="")
    oil_temperature_c: Mapped[float | None] = mapped_column(Float, nullable=True)
    ambient_temperature_c: Mapped[float | None] = mapped_column(Float, nullable=True)
    ambient_humidity_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    gps_latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    gps_longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    gps_accuracy_m: Mapped[float | None] = mapped_column(Float, nullable=True)
    field_notes: Mapped[str] = mapped_column(Text, default="")
    container_count: Mapped[int] = mapped_column(Integer, default=1)

    lms_number: Mapped[str | None] = mapped_column(String(80), nullable=True, index=True)
    client_sample_reference: Mapped[str] = mapped_column(String(100), default="")
    data_entry_note: Mapped[str] = mapped_column(Text, default="")
    return_reason: Mapped[str] = mapped_column(Text, default="")
    rejection_reason: Mapped[str] = mapped_column(Text, default="")

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    submitted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    accepted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    received_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    registered_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    released_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    site: Mapped[Site] = relationship()
    client: Mapped[Client] = relationship()
    quotation: Mapped[Quotation | None] = relationship()
    purchase_order: Mapped[PurchaseOrder | None] = relationship()
    asset: Mapped[Asset] = relationship()
    sampler: Mapped[User | None] = relationship(foreign_keys=[sampler_id])
    sampling_assignment: Mapped[SamplingAssignment | None] = relationship(foreign_keys=[sampling_assignment_id])
    photos: Mapped[list["SamplePhoto"]] = relationship(back_populates="sample", cascade="all, delete-orphan")
    events: Mapped[list["CustodyEvent"]] = relationship(back_populates="sample", cascade="all, delete-orphan")
    issues: Mapped[list["DataQualityIssue"]] = relationship(back_populates="sample", cascade="all, delete-orphan")


class SamplePhoto(Base):
    __tablename__ = "sample_photos"
    id: Mapped[int] = mapped_column(primary_key=True)
    sample_request_id: Mapped[int] = mapped_column(ForeignKey("sample_requests.id"), index=True)
    kind: Mapped[str] = mapped_column(String(60), default="General")
    original_name: Mapped[str] = mapped_column(String(220))
    stored_path: Mapped[str] = mapped_column(String(500))
    uploaded_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    sample: Mapped[SampleRequest] = relationship(back_populates="photos")


class CustodyEvent(Base):
    __tablename__ = "custody_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    sample_request_id: Mapped[int] = mapped_column(ForeignKey("sample_requests.id"), index=True)
    event_type: Mapped[str] = mapped_column(String(60), index=True)
    status: Mapped[str] = mapped_column(String(40), index=True)
    actor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    note: Mapped[str] = mapped_column(Text, default="")
    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    event_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    sample: Mapped[SampleRequest] = relationship(back_populates="events")
    actor: Mapped[User | None] = relationship()


class DataQualityIssue(Base):
    __tablename__ = "data_quality_issues"
    id: Mapped[int] = mapped_column(primary_key=True)
    sample_request_id: Mapped[int] = mapped_column(ForeignKey("sample_requests.id"), index=True)
    issue_type: Mapped[str] = mapped_column(String(80), index=True)
    severity: Mapped[str] = mapped_column(String(20), default="MEDIUM")
    description: Mapped[str] = mapped_column(Text)
    reported_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    sample: Mapped[SampleRequest] = relationship(back_populates="issues")
    reported_by: Mapped[User | None] = relationship()


class LmsSyncLog(Base):
    __tablename__ = "lms_sync_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    sample_request_id: Mapped[int] = mapped_column(ForeignKey("sample_requests.id"), index=True)
    direction: Mapped[str] = mapped_column(String(20))
    operation: Mapped[str] = mapped_column(String(80))
    status: Mapped[str] = mapped_column(String(30))
    external_reference: Mapped[str] = mapped_column(String(120), default="")
    request_payload: Mapped[str] = mapped_column(Text, default="")
    response_payload: Mapped[str] = mapped_column(Text, default="")
    error_message: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class TechnicalAssessmentRecord(Base):
    __tablename__ = "technical_assessment_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    sample_request_id: Mapped[int] = mapped_column(ForeignKey("sample_requests.id"), unique=True, index=True)
    profile: Mapped[str] = mapped_column(String(80), default="IEC 60422 / IEC 60599")
    system_findings_json: Mapped[str] = mapped_column(Text, default="{}")
    recommendation: Mapped[str] = mapped_column(Text, default="")
    decision: Mapped[str] = mapped_column(String(40), default="DRAFT", index=True)
    reviewed_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    sample: Mapped[SampleRequest] = relationship()
    reviewed_by: Mapped[User | None] = relationship()


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    actor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    action: Mapped[str] = mapped_column(String(80), index=True)
    entity_type: Mapped[str] = mapped_column(String(80), index=True)
    entity_id: Mapped[str] = mapped_column(String(80), default="", index=True)
    summary: Mapped[str] = mapped_column(String(260), default="")
    details: Mapped[str] = mapped_column(Text, default="")
    ip_address: Mapped[str] = mapped_column(String(80), default="")
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    actor: Mapped[User | None] = relationship(foreign_keys=[actor_id])
    site: Mapped[Site | None] = relationship()


class ControlledDocument(Base):
    __tablename__ = "controlled_documents"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    document_type: Mapped[str] = mapped_column(String(40), index=True)
    code: Mapped[str] = mapped_column(String(80), index=True)
    title: Mapped[str] = mapped_column(String(220), index=True)
    revision: Mapped[str] = mapped_column(String(40), default="00")
    status: Mapped[str] = mapped_column(String(30), default="ACTIVE", index=True)
    effective_date: Mapped[str] = mapped_column(String(20), default="")
    workstation: Mapped[str] = mapped_column(String(120), default="", index=True)
    test_name: Mapped[str] = mapped_column(String(220), default="", index=True)
    method_name: Mapped[str] = mapped_column(String(160), default="", index=True)
    original_filename: Mapped[str] = mapped_column(String(240))
    stored_filename: Mapped[str] = mapped_column(String(300), unique=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    uploaded_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    site: Mapped[Site | None] = relationship()
    uploaded_by: Mapped[User | None] = relationship()


class TestPackageConfig(Base):
    __tablename__ = "test_package_configs"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    code: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    scope: Mapped[str] = mapped_column(String(80), default="GENERAL")
    tests_json: Mapped[str] = mapped_column(Text, default="[]")
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    site: Mapped[Site | None] = relationship()


class WorkflowDefinition(Base):
    __tablename__ = "workflow_definitions"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    code: Mapped[str] = mapped_column(String(80), index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    sample_type: Mapped[str] = mapped_column(String(80), default="GENERAL")
    version: Mapped[int] = mapped_column(Integer, default=1)
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    site: Mapped[Site | None] = relationship()
    steps: Mapped[list["WorkflowStep"]] = relationship(back_populates="workflow", cascade="all, delete-orphan", order_by="WorkflowStep.step_order")
    __table_args__ = (UniqueConstraint("site_id", "code", "version", name="uq_workflow_site_code_version"),)


class WorkflowStep(Base):
    __tablename__ = "workflow_steps"
    id: Mapped[int] = mapped_column(primary_key=True)
    workflow_id: Mapped[int] = mapped_column(ForeignKey("workflow_definitions.id"), index=True)
    step_order: Mapped[int] = mapped_column(Integer)
    step_key: Mapped[str] = mapped_column(String(80))
    label: Mapped[str] = mapped_column(String(160))
    responsible_role: Mapped[str] = mapped_column(String(40), default="")
    approval_required: Mapped[bool] = mapped_column(Boolean, default=False)
    terminal: Mapped[bool] = mapped_column(Boolean, default=False)
    workflow: Mapped[WorkflowDefinition] = relationship(back_populates="steps")
    __table_args__ = (UniqueConstraint("workflow_id", "step_order", name="uq_workflow_step_order"),)


class ApprovalPolicy(Base):
    __tablename__ = "approval_policies"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    code: Mapped[str] = mapped_column(String(80), index=True)
    name: Mapped[str] = mapped_column(String(180), index=True)
    entity_type: Mapped[str] = mapped_column(String(80), default="SAMPLE_REPORT")
    stages_json: Mapped[str] = mapped_column(Text, default="[]")
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    site: Mapped[Site | None] = relationship()
    __table_args__ = (UniqueConstraint("site_id", "code", name="uq_approval_site_code"),)


class IntegrationQueueItem(Base):
    __tablename__ = "integration_queue"
    id: Mapped[int] = mapped_column(primary_key=True)
    sample_request_id: Mapped[int | None] = mapped_column(ForeignKey("sample_requests.id"), nullable=True, index=True)
    integration: Mapped[str] = mapped_column(String(40), default="LMS", index=True)
    direction: Mapped[str] = mapped_column(String(20), default="OUTBOUND")
    operation: Mapped[str] = mapped_column(String(80), index=True)
    status: Mapped[str] = mapped_column(String(30), default="PENDING", index=True)
    payload_json: Mapped[str] = mapped_column(Text, default="{}")
    attempts: Mapped[int] = mapped_column(Integer, default=0)
    external_reference: Mapped[str] = mapped_column(String(120), default="")
    last_error: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    sample: Mapped[SampleRequest | None] = relationship()

# --- Project 00012 enterprise closeout modules (v2.7) ---
class EquipmentAsset(Base):
    __tablename__ = "equipment_assets"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    equipment_id: Mapped[str] = mapped_column(String(40), index=True)
    name: Mapped[str] = mapped_column(String(180))
    manufacturer: Mapped[str] = mapped_column(String(120), default="")
    model: Mapped[str] = mapped_column(String(120), default="")
    serial_number: Mapped[str] = mapped_column(String(120), default="")
    workstation: Mapped[str] = mapped_column(String(120), default="", index=True)
    test_method: Mapped[str] = mapped_column(String(180), default="")
    status: Mapped[str] = mapped_column(String(30), default="IN_SERVICE", index=True)
    calibration_provider: Mapped[str] = mapped_column(String(180), default="")
    calibration_certificate: Mapped[str] = mapped_column(String(180), default="")
    last_calibration_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    next_calibration_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    last_verification_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    next_verification_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    notes: Mapped[str] = mapped_column(Text, default="")
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    site: Mapped[Site] = relationship()
    __table_args__ = (UniqueConstraint("site_id", "equipment_id", name="uq_equipment_site_id"),)


class EquipmentEvent(Base):
    __tablename__ = "equipment_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    equipment_asset_id: Mapped[int] = mapped_column(ForeignKey("equipment_assets.id"), index=True)
    event_type: Mapped[str] = mapped_column(String(40), index=True)  # QC/CALIBRATION/MAINTENANCE/FAILURE/VERIFICATION
    status: Mapped[str] = mapped_column(String(30), default="OPEN", index=True)
    result: Mapped[str] = mapped_column(String(80), default="")
    details: Mapped[str] = mapped_column(Text, default="")
    certificate_reference: Mapped[str] = mapped_column(String(180), default="")
    performed_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    event_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    next_due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    equipment: Mapped[EquipmentAsset] = relationship()
    performed_by: Mapped[User | None] = relationship()


class CompetencyRecord(Base):
    __tablename__ = "competency_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    test_name: Mapped[str] = mapped_column(String(180), index=True)
    method_name: Mapped[str] = mapped_column(String(180), default="", index=True)
    workstation: Mapped[str] = mapped_column(String(120), default="", index=True)
    category: Mapped[int] = mapped_column(Integer, default=1)  # Skill Matrix Cat1-Cat5
    technical_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    data_processing_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    overall_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    authorization: Mapped[str] = mapped_column(String(30), default="TRAINING", index=True)  # INDEPENDENT/SUPERVISED/FAILED/TRAINING
    effective_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    evaluated_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    evidence_reference: Mapped[str] = mapped_column(String(240), default="")
    notes: Mapped[str] = mapped_column(Text, default="")
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    site: Mapped[Site] = relationship()
    user: Mapped[User] = relationship(foreign_keys=[user_id])
    evaluated_by: Mapped[User | None] = relationship(foreign_keys=[evaluated_by_id])


class QualityCase(Base):
    __tablename__ = "quality_cases"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    case_number: Mapped[str] = mapped_column(String(60), unique=True, index=True)
    case_type: Mapped[str] = mapped_column(String(40), index=True)  # VALIDATION/VERIFICATION/ILC_PT/CAPA/NCR
    title: Mapped[str] = mapped_column(String(220))
    test_name: Mapped[str] = mapped_column(String(180), default="", index=True)
    method_name: Mapped[str] = mapped_column(String(180), default="")
    equipment_asset_id: Mapped[int | None] = mapped_column(ForeignKey("equipment_assets.id"), nullable=True, index=True)
    assigned_to_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    status: Mapped[str] = mapped_column(String(40), default="OPEN", index=True)
    priority: Mapped[str] = mapped_column(String(20), default="NORMAL")
    due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    protocol_json: Mapped[str] = mapped_column(Text, default="{}")
    raw_runs_json: Mapped[str] = mapped_column(Text, default="[]")
    calculation_json: Mapped[str] = mapped_column(Text, default="{}")
    root_cause: Mapped[str] = mapped_column(Text, default="")
    corrective_action: Mapped[str] = mapped_column(Text, default="")
    effectiveness_review: Mapped[str] = mapped_column(Text, default="")
    scheme_name: Mapped[str] = mapped_column(String(180), default="")
    evaluation_criteria: Mapped[str] = mapped_column(Text, default="")
    evidence_reference: Mapped[str] = mapped_column(String(240), default="")
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    reviewed_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    site: Mapped[Site] = relationship()
    equipment: Mapped[EquipmentAsset | None] = relationship()
    assigned_to: Mapped[User | None] = relationship(foreign_keys=[assigned_to_id])
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])
    reviewed_by: Mapped[User | None] = relationship(foreign_keys=[reviewed_by_id])


class StaffAvailability(Base):
    __tablename__ = "staff_availability"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    entry_type: Mapped[str] = mapped_column(String(30), index=True)  # LEAVE/SHIFT/ON_CALL/HOLIDAY/HANDOVER
    start_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    end_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    status: Mapped[str] = mapped_column(String(40), default="PLANNED", index=True)
    shift_code: Mapped[str] = mapped_column(String(40), default="")
    notes: Mapped[str] = mapped_column(Text, default="")
    approved_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    site: Mapped[Site] = relationship()
    user: Mapped[User] = relationship(foreign_keys=[user_id])
    approved_by: Mapped[User | None] = relationship(foreign_keys=[approved_by_id])
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])


class EvidenceRecord(Base):
    __tablename__ = "evidence_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    sample_request_id: Mapped[int | None] = mapped_column(ForeignKey("sample_requests.id"), nullable=True, index=True)
    quality_case_id: Mapped[int | None] = mapped_column(ForeignKey("quality_cases.id"), nullable=True, index=True)
    equipment_asset_id: Mapped[int | None] = mapped_column(ForeignKey("equipment_assets.id"), nullable=True, index=True)
    evidence_type: Mapped[str] = mapped_column(String(50), index=True)  # DGA_SOURCE/DGA_CHROMATOGRAM/CORROSIVE_FRONT/CORROSIVE_BACK/CORROSIVE_COPPER/CORROSIVE_PAPER_INNER/CORROSIVE_PAPER_OUTER/PAPER_DP_EVIDENCE/VALIDATION/QC
    title: Mapped[str] = mapped_column(String(220))
    original_filename: Mapped[str] = mapped_column(String(240), default="")
    stored_path: Mapped[str] = mapped_column(String(500), default="")
    sha256: Mapped[str] = mapped_column(String(64), default="")
    method_name: Mapped[str] = mapped_column(String(180), default="")
    equipment_id_snapshot: Mapped[str] = mapped_column(String(40), default="")
    run_reference: Mapped[str] = mapped_column(String(100), default="")
    parsed_json: Mapped[str] = mapped_column(Text, default="{}")
    revision: Mapped[int] = mapped_column(Integer, default=1)
    status: Mapped[str] = mapped_column(String(30), default="CONTROLLED")
    uploaded_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    site: Mapped[Site] = relationship()
    sample: Mapped[SampleRequest | None] = relationship()
    quality_case: Mapped[QualityCase | None] = relationship()
    equipment: Mapped[EquipmentAsset | None] = relationship()
    uploaded_by: Mapped[User] = relationship()


class AssetHistoryEvent(Base):
    __tablename__ = "asset_history_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), index=True)
    event_type: Mapped[str] = mapped_column(String(60), index=True)
    event_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    report_number: Mapped[str] = mapped_column(String(80), default="")
    details: Mapped[str] = mapped_column(Text, default="")
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    asset: Mapped[Asset] = relationship()
    created_by: Mapped[User | None] = relationship()


class TechnicalResultRule(Base):
    __tablename__ = "technical_result_rules"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    test_name: Mapped[str] = mapped_column(String(180), index=True)
    method_name: Mapped[str] = mapped_column(String(180), default="", index=True)
    result_field: Mapped[str] = mapped_column(String(180), index=True)
    unit: Mapped[str] = mapped_column(String(60), default="")
    equipment_id: Mapped[str] = mapped_column(String(40), default="")
    allowed_states: Mapped[str] = mapped_column(String(120), default="NUMERIC,LTD")
    detection_limit: Mapped[float | None] = mapped_column(Float, nullable=True)
    working_range_min: Mapped[float | None] = mapped_column(Float, nullable=True)
    working_range_max: Mapped[float | None] = mapped_column(Float, nullable=True)
    decimals: Mapped[int | None] = mapped_column(Integer, nullable=True)
    rounding_rule: Mapped[str] = mapped_column(String(40), default="SOURCE_CONTROLLED")
    report_display_rule: Mapped[str] = mapped_column(String(240), default="")
    downstream_rule: Mapped[str] = mapped_column(Text, default="")
    source_reference: Mapped[str] = mapped_column(String(240), default="")
    effective_revision: Mapped[str] = mapped_column(String(40), default="")
    status: Mapped[str] = mapped_column(String(30), default="ACTIVE", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    __table_args__ = (UniqueConstraint("site_id", "test_name", "method_name", "result_field", "equipment_id", name="uq_result_rule_scope"),)


class TroubleshootingRecord(Base):
    __tablename__ = "troubleshooting_records"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    test_name: Mapped[str] = mapped_column(String(180), default="", index=True)
    method_name: Mapped[str] = mapped_column(String(180), default="")
    equipment_asset_id: Mapped[int | None] = mapped_column(ForeignKey("equipment_assets.id"), nullable=True)
    workstation: Mapped[str] = mapped_column(String(120), default="")
    problem: Mapped[str] = mapped_column(Text)
    symptoms: Mapped[str] = mapped_column(Text, default="")
    root_cause: Mapped[str] = mapped_column(Text, default="")
    actions_taken: Mapped[str] = mapped_column(Text, default="")
    safety_impact: Mapped[str] = mapped_column(Text, default="")
    result_integrity_impact: Mapped[str] = mapped_column(Text, default="")
    lessons: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(40), default="DRAFT", index=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    senior_verified_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    technical_approved_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    site: Mapped[Site] = relationship()
    equipment: Mapped[EquipmentAsset | None] = relationship()
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])
    senior_verified_by: Mapped[User | None] = relationship(foreign_keys=[senior_verified_by_id])
    technical_approved_by: Mapped[User | None] = relationship(foreign_keys=[technical_approved_by_id])


class ControlledReport(Base):
    __tablename__ = "controlled_reports"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    sample_request_id: Mapped[int] = mapped_column(ForeignKey("sample_requests.id"), index=True)
    report_number: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    revision: Mapped[int] = mapped_column(Integer, default=1)
    status: Mapped[str] = mapped_column(String(40), default="DRAFT", index=True)
    condition_status: Mapped[str] = mapped_column(String(30), default="")
    interpretation: Mapped[str] = mapped_column(Text, default="")
    recommendation: Mapped[str] = mapped_column(Text, default="")
    report_payload_json: Mapped[str] = mapped_column(Text, default="{}")
    qr_token: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    reviewed_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    approved_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    lms_reference: Mapped[str] = mapped_column(String(120), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    approved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    site: Mapped[Site] = relationship()
    sample: Mapped[SampleRequest] = relationship()
    reviewed_by: Mapped[User | None] = relationship(foreign_keys=[reviewed_by_id])
    approved_by: Mapped[User | None] = relationship(foreign_keys=[approved_by_id])

class Notification(Base):
    __tablename__ = "notifications"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    category: Mapped[str] = mapped_column(String(40), default="WORK", index=True)
    title: Mapped[str] = mapped_column(String(220))
    message: Mapped[str] = mapped_column(Text, default="")
    target_url: Mapped[str] = mapped_column(String(300), default="")
    priority: Mapped[str] = mapped_column(String(20), default="NORMAL")
    read_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    email_status: Mapped[str] = mapped_column(String(30), default="PENDING_CONFIGURATION")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    site: Mapped[Site | None] = relationship()
    user: Mapped[User] = relationship()


class ImprovementItem(Base):
    __tablename__ = "improvement_items"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    site_id: Mapped[int | None] = mapped_column(ForeignKey("sites.id"), nullable=True, index=True)
    department_id: Mapped[int | None] = mapped_column(ForeignKey("departments.id"), nullable=True, index=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    owner_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True, index=True)
    title: Mapped[str] = mapped_column(String(220), index=True)
    problem_statement: Mapped[str] = mapped_column(Text, default="")
    category: Mapped[str] = mapped_column(String(60), default="OPERATIONS", index=True)
    source: Mapped[str] = mapped_column(String(60), default="EMPLOYEE", index=True)
    priority: Mapped[str] = mapped_column(String(20), default="NORMAL", index=True)
    impact_area: Mapped[str] = mapped_column(String(120), default="")
    expected_benefit: Mapped[str] = mapped_column(Text, default="")
    action_plan: Mapped[str] = mapped_column(Text, default="")
    baseline_metric: Mapped[str] = mapped_column(String(120), default="")
    baseline_value: Mapped[str] = mapped_column(String(80), default="")
    target_value: Mapped[str] = mapped_column(String(80), default="")
    metric_unit: Mapped[str] = mapped_column(String(40), default="")
    status: Mapped[str] = mapped_column(String(40), default="SUBMITTED", index=True)
    due_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True, index=True)
    result_summary: Mapped[str] = mapped_column(Text, default="")
    evidence_reference: Mapped[str] = mapped_column(String(300), default="")
    approved_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    site: Mapped[Site | None] = relationship(foreign_keys=[site_id])
    department: Mapped[Department | None] = relationship(foreign_keys=[department_id])
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])
    owner: Mapped[User | None] = relationship(foreign_keys=[owner_id])
    approved_by: Mapped[User | None] = relationship(foreign_keys=[approved_by_id])
    activities: Mapped[list["ImprovementActivity"]] = relationship(back_populates="item", cascade="all, delete-orphan")


class ImprovementActivity(Base):
    __tablename__ = "improvement_activities"
    id: Mapped[int] = mapped_column(primary_key=True)
    improvement_item_id: Mapped[int] = mapped_column(ForeignKey("improvement_items.id"), index=True)
    actor_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    action: Mapped[str] = mapped_column(String(60), index=True)
    note: Mapped[str] = mapped_column(Text, default="")
    status_snapshot: Mapped[str] = mapped_column(String(40), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    item: Mapped[ImprovementItem] = relationship(back_populates="activities")
    actor: Mapped[User] = relationship()



class MonthlyClosePeriod(Base):
    __tablename__ = "monthly_close_periods"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    year: Mapped[int] = mapped_column(Integer, index=True)
    month: Mapped[int] = mapped_column(Integer, index=True)
    status: Mapped[str] = mapped_column(String(20), default="OPEN", index=True)
    archive_reference: Mapped[str] = mapped_column(String(180), default="")
    close_note: Mapped[str] = mapped_column(Text, default="")
    closed_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    closed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    site: Mapped[Site] = relationship()
    closed_by: Mapped[User | None] = relationship(foreign_keys=[closed_by_id])
    __table_args__ = (UniqueConstraint("site_id", "year", "month", name="uq_monthly_close_site_period"),)


class StaffWorkPattern(Base):
    __tablename__ = "staff_work_patterns"
    id: Mapped[int] = mapped_column(primary_key=True)
    site_id: Mapped[int] = mapped_column(ForeignKey("sites.id"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    name: Mapped[str] = mapped_column(String(100), default="Standard")
    weekdays_json: Mapped[str] = mapped_column(Text, default="[6,0,1,2,3]")
    shift_start: Mapped[str] = mapped_column(String(5), default="08:00")
    shift_end: Mapped[str] = mapped_column(String(5), default="16:00")
    effective_from: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    effective_to: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_by_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    site: Mapped[Site] = relationship(foreign_keys=[site_id])
    user: Mapped[User] = relationship(foreign_keys=[user_id])
    created_by: Mapped[User] = relationship(foreign_keys=[created_by_id])
    __table_args__ = (UniqueConstraint("site_id", "user_id", name="uq_staff_work_pattern_user_site"),)
